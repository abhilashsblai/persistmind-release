from __future__ import annotations

from pathlib import Path


def encryption_status(db_path: Path, enabled: bool) -> dict[str, object]:
    return {
        "enabled": enabled,
        "db_path": str(db_path),
        "mode": "external-key-provider-required" if enabled else "disabled",
        "note": "SQLite SQLCipher integration is not active unless deployed with an encrypted SQLite build.",
    }
