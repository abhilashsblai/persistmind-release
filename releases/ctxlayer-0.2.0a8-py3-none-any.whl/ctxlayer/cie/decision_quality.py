from __future__ import annotations

from ctxlayer.cie.contracts import DecisionQualityRecord, deterministic_id


def assess_decision_quality(
    options: list[str],
    selected_option: str,
    *,
    outcome_quality: float = 0.8,
    review_source: str = "self_review",
) -> DecisionQualityRecord:
    alternatives = [option for option in options if option != selected_option]
    coverage = min(1.0, len(options) / 3) if options else 0.0
    quality_gap = max(0.0, 1.0 - outcome_quality) if alternatives else 0.0
    signal = "adequate_exploration" if len(options) > 1 else "low_exploration"
    return DecisionQualityRecord(
        decision_quality_id=deterministic_id(
            "decision_quality", options, selected_option, outcome_quality
        ),
        options_considered=options,
        selected_option=selected_option,
        alternative_options=alternatives,
        outcome_quality=round(outcome_quality, 3),
        quality_gap=round(quality_gap, 3),
        option_set_coverage=round(coverage, 3),
        exploration_signal=signal,
        review_source=review_source,
        evidence_refs=[],
    )
