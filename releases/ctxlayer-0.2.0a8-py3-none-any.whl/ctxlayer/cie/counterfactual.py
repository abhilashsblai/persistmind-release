from __future__ import annotations

from ctxlayer.cie.contracts import NearMissEvent, deterministic_id


def record_near_miss(
    proposed_action: str, blocked_by: str, *, evidence_refs: list[str] | None = None
) -> NearMissEvent:
    text = f"{proposed_action} {blocked_by}".lower()
    severity = (
        "critical"
        if any(token in text for token in ("secret", "security", "canary"))
        else "medium"
    )
    if any(
        token in text for token in ("checkpoint", "check-diff", "policy", "blocked")
    ):
        severity = "high" if severity != "critical" else severity
    debt = {"low": 4.0, "medium": 8.0, "high": 16.0, "critical": 32.0}[severity]
    return NearMissEvent(
        near_miss_id=deterministic_id(
            "near_miss", proposed_action, blocked_by, evidence_refs or []
        ),
        proposed_action=proposed_action,
        blocked_by=blocked_by,
        potential_impact="blocked before user-visible failure",
        potential_severity=severity,
        confidence_before=0.5,
        confidence_after=0.8,
        counterfactual_outcome="risk likely would have reached final output without blocker",
        cognitive_debt_score=debt,
        evidence_refs=evidence_refs or [],
    )
