from __future__ import annotations

from ctxlayer.cie.complexity import estimate_complexity
from ctxlayer.cie.contracts import MistakeRecurrencePrediction, deterministic_id


def predict_mistakes(
    task: str = "", paths: list[str] | None = None, history: list[dict] | None = None
) -> MistakeRecurrencePrediction:
    complexity = estimate_complexity(task, paths or [], history or [])
    modes = ["verification_gap"] if complexity["task_complexity_score"] >= 25 else []
    if complexity["task_type"] in {"security_sensitive", "database", "migration"}:
        modes.append("risk_calibration_failure")
    if complexity["surface_count"]:
        modes.append("surface_parity")
    behavior = "normal"
    if complexity["complexity_band"] in {"critical", "high"}:
        behavior = "ask_for_review"
    elif modes:
        behavior = "expand_tests"
    confidence = 0.35 + min(0.45, len(history or []) * 0.05)
    return MistakeRecurrencePrediction(
        prediction_id=deterministic_id(
            "prediction", task, paths or [], modes, complexity["complexity_band"]
        ),
        task_signature=deterministic_id("task_signature", task, paths or []),
        task_type=complexity["task_type"],
        likely_failure_modes=sorted(set(modes)),
        recommended_behavior=behavior,
        task_complexity_score=complexity["task_complexity_score"],
        complexity_band=complexity["complexity_band"],
        confidence=round(confidence, 3),
        provisional=len(history or []) < 5,
        evidence_refs=complexity["evidence_refs"],
    )
