from __future__ import annotations


def rule_effectiveness(
    prevention_baseline: float, post_adoption_failure_rate: float
) -> dict[str, float | str]:
    baseline = max(float(prevention_baseline or 0.0), 0.0001)
    value = 1 - (float(post_adoption_failure_rate or 0.0) / baseline)
    status = "active" if value >= 0.2 else "stale"
    if value < 0:
        status = "retired"
    return {"effectiveness": round(value, 6), "status": status}


def prediction_accuracy(
    true_positive: int, false_positive: int, false_negative: int
) -> dict[str, float | int]:
    precision = true_positive / max(1, true_positive + false_positive)
    recall = true_positive / max(1, true_positive + false_negative)
    return {
        "precision": round(precision, 6),
        "recall": round(recall, 6),
        "false_positive_count": int(false_positive),
        "false_negative_count": int(false_negative),
    }


def checklist_compliance(
    shown: int, fulfilled: int, failures_after: int = 0
) -> dict[str, float | int]:
    return {
        "items_shown": int(shown),
        "items_fulfilled": int(fulfilled),
        "related_failures_after": int(failures_after),
        "compliance_rate": round(fulfilled / max(1, shown), 6),
    }
