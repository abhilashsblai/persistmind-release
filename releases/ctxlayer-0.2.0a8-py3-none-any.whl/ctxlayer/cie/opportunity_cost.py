from __future__ import annotations

from ctxlayer.cie.contracts import OpportunityCostRecord, deterministic_id


def measure_opportunity_cost(
    task_type: str,
    complexity_band: str,
    options_considered: int,
    *,
    agent_profile_id: str = "unknown",
) -> OpportunityCostRecord:
    exploration_rate = min(1.0, options_considered / 3)
    safe_default_rate = 1.0 - exploration_rate
    status = "observed"
    if complexity_band in {"medium", "high"} and exploration_rate < 0.5:
        status = "actionable"
    return OpportunityCostRecord(
        opportunity_cost_id=deterministic_id(
            "opportunity_cost",
            task_type,
            complexity_band,
            options_considered,
            agent_profile_id,
        ),
        task_type=task_type,
        task_complexity_band=complexity_band,
        agent_profile_id=agent_profile_id,
        options_considered_count=options_considered,
        option_diversity_score=exploration_rate,
        exploration_rate=exploration_rate,
        safe_default_rate=safe_default_rate,
        missed_option_type=(
            "simpler_or_safer_alternative" if status == "actionable" else "unknown"
        ),
        estimated_cost={
            "maintainability": round(safe_default_rate * 10, 3),
            "user_value": round(safe_default_rate * 5, 3),
        },
        status=status,
    )
