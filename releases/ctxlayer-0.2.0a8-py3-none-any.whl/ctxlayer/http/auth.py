from __future__ import annotations

import os


def authorize(header: str | None, token_env: str) -> bool:
    expected = os.environ.get(token_env)
    if not expected:
        return True
    return header == f"Bearer {expected}"
