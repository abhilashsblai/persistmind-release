from __future__ import annotations

import re
from fnmatch import fnmatch

from ctxlayer.codex import BROAD_TASK_TERMS
from ctxlayer.workflow.playbook import PLAYBOOK

READ_TERMS = {
    "audit",
    "explain",
    "investigate",
    "read",
    "review",
    "understand",
    "analyze",
}
WRITE_TERMS = {"add", "build", "change", "edit", "fix", "implement", "update", "wire"}


def classify(
    task: str,
    paths: list[str] | None = None,
    capabilities: list[str] | None = None,
    mode: str = "write",
    impact_risk: float | None = None,
) -> list[str]:
    normalized_mode = infer_mode(task, mode)
    terms = _terms(task)
    paths = [path.replace("\\", "/") for path in paths or []]
    capabilities = [item.strip().lower() for item in capabilities or [] if item]

    task_types = ["core_session"]
    if normalized_mode == "read":
        if (
            terms & set(PLAYBOOK["investigation"]["match"]["keywords"])
            or terms & READ_TERMS
        ):
            task_types.append("investigation")
        return _dedupe(task_types)

    task_types.append("standard_edit")
    for task_type_id, entry in PLAYBOOK.items():
        if task_type_id in {"core_session", "standard_edit", "investigation"}:
            continue
        match = entry.get("match", {})
        if match.get("mode") and match["mode"] != normalized_mode:
            continue
        if terms & set(match.get("keywords", [])):
            task_types.append(task_type_id)

    if any(cap in {"modify_migration", "edit_critical_path"} for cap in capabilities):
        task_types.append(
            "data_migration"
            if "modify_migration" in capabilities
            else "architecture_change"
        )
    if any(cap in {"touch_env_secrets", "security_review"} for cap in capabilities):
        task_types.append("security_change")
    if any(
        fnmatch(path, pattern)
        for path in paths
        for pattern in ("**/migrations/**", "migrations/**")
    ):
        task_types.append("data_migration")
    if any(
        fnmatch(path, pattern)
        for path in paths
        for pattern in ("**/auth/**", "auth/**", "**/security/**")
    ):
        task_types.append("security_change")
    if (impact_risk or 0.0) >= 7.0 or terms & BROAD_TASK_TERMS:
        task_types.append("architecture_change" if len(paths) >= 3 else "standard_edit")
    return _dedupe(task_types)


def infer_mode(task: str, mode: str = "write") -> str:
    requested = (mode or "write").strip().lower()
    if requested in {"read", "write"}:
        return requested
    terms = _terms(task)
    return "read" if terms & READ_TERMS and not terms & WRITE_TERMS else "write"


def _terms(task: str) -> set[str]:
    return {part.lower() for part in re.findall(r"[A-Za-z0-9_/-]+", task or "")}


def _dedupe(items: list[str]) -> list[str]:
    result: list[str] = []
    for item in items:
        if item not in result:
            result.append(item)
    return result
