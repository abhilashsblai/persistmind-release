from __future__ import annotations

from typing import Any

PLAYBOOK_VERSION = "ctxlayer.workflow_playbook.v1"

GATE_KINDS: dict[str, str] = {
    "preflight_ready": "durable",
    "plan_active": "durable",
    "checkpoints_present": "durable",
    "check_diff_clean": "volatile",
    "dirty_set_in_scope": "volatile",
    "tests_pass": "durable",
    "outcome_recorded": "durable",
    "security_scan_pass": "durable",
    "release_validated": "durable",
}

PLAYBOOK: dict[str, dict[str, Any]] = {
    "core_session": {
        "match": {"base": True},
        "required_features": ["pack"],
        "optional_features": ["continuation", "workflow_next"],
        "gates": ["preflight_ready"],
        "stop_when": "context pack has been served and any requested read-only task is answered",
    },
    "standard_edit": {
        "match": {"default_write": True},
        "required_features": [
            "plan",
            "checkpoint",
            "impact",
            "check_diff",
            "tests",
            "outcome",
        ],
        "optional_features": ["agent_route"],
        "gates": [
            "plan_active",
            "checkpoints_present",
            "check_diff_clean",
            "tests_pass",
            "outcome_recorded",
        ],
        "escalate_when": {
            "risk_score": ">=7",
            "touches": ["**/auth/**", "**/billing/**", "**/migrations/**"],
        },
        "stop_when": "plan, checkpoints, diff gates, tests, and outcome are recorded",
    },
    "investigation": {
        "match": {
            "keywords": [
                "investigate",
                "analyze",
                "read",
                "understand",
                "audit",
                "explain",
            ],
            "mode": "read",
        },
        "required_features": [],
        "optional_features": ["impact"],
        "gates": [],
        "stop_when": "question is answered from the served context",
    },
    "architecture_change": {
        "match": {
            "keywords": ["architecture", "design", "refactor", "cross-cutting"],
            "mode": "write",
        },
        "required_features": ["decision", "agent_route"],
        "optional_features": [],
        "gates": [],
        "stop_when": "architecture decision and standard edit gates are complete",
    },
    "release": {
        "match": {
            "keywords": ["release", "publish", "version", "wheel"],
            "mode": "write",
        },
        "required_features": ["release_validate"],
        "optional_features": [],
        "gates": ["release_validated"],
        "stop_when": "release validation and standard edit gates are complete",
    },
    "memory_curation": {
        "match": {
            "keywords": ["memory", "remember", "recall", "curate"],
            "mode": "write",
        },
        "required_features": ["continuation"],
        "optional_features": [],
        "gates": [],
        "stop_when": "memory work and standard edit gates are complete",
    },
    "decision": {
        "match": {"keywords": ["decide", "decision", "tradeoff"], "mode": "write"},
        "required_features": ["decision"],
        "optional_features": [],
        "gates": [],
        "stop_when": "decision evidence is recorded",
    },
    "data_migration": {
        "match": {"keywords": ["migration", "schema", "database"], "mode": "write"},
        "required_features": ["agent_route"],
        "optional_features": [],
        "gates": [],
        "stop_when": "migration-specific review and standard edit gates are complete",
    },
    "security_change": {
        "match": {
            "keywords": ["security", "auth", "secret", "permission"],
            "mode": "write",
        },
        "required_features": ["security_scan", "agent_route"],
        "optional_features": [],
        "gates": ["security_scan_pass"],
        "stop_when": "security scan and standard edit gates are complete",
    },
    "maintenance_ops": {
        "match": {
            "keywords": ["maintenance", "ops", "doctor", "health"],
            "mode": "write",
        },
        "required_features": ["impact"],
        "optional_features": ["agent_route"],
        "gates": [],
        "stop_when": "operations change and standard edit gates are complete",
    },
}

FEATURE_COVERAGE: dict[str, dict[str, str]] = {
    "pack": {"classification": "required", "reason": "universal context substrate"},
    "plan": {"classification": "required", "reason": "write tasks need scoped plans"},
    "checkpoint": {
        "classification": "required",
        "reason": "write files must be tied to plan steps",
    },
    "impact": {
        "classification": "required",
        "reason": "write completion needs impact evidence",
    },
    "check_diff": {
        "classification": "required",
        "reason": "write completion needs pack-scope validation",
    },
    "tests": {
        "classification": "required",
        "reason": "write completion needs verification evidence",
    },
    "outcome": {
        "classification": "required",
        "reason": "workflow memory needs explicit outcome",
    },
    "continuation": {
        "classification": "optional",
        "reason": "useful for resume and memory curation",
    },
    "agent_route": {
        "classification": "escalation_only",
        "reason": "only high-risk or specific task types need routing",
    },
    "decision": {
        "classification": "required",
        "reason": "architecture and trade-off work needs decision evidence",
    },
    "security_scan": {
        "classification": "required",
        "reason": "security-sensitive work needs scan evidence",
    },
    "release_validate": {
        "classification": "required",
        "reason": "release work needs packaging validation",
    },
    "workflow_next": {
        "classification": "optional",
        "reason": "advisory projection over existing workflow evidence",
    },
}


def task_type(task_type_id: str) -> dict[str, Any]:
    return PLAYBOOK[task_type_id]
