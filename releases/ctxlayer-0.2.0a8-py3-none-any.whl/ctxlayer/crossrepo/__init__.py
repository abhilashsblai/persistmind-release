__all__ = ["WorkspaceManager"]


def __getattr__(name: str):
    if name == "WorkspaceManager":
        from .workspace import WorkspaceManager

        return WorkspaceManager
    raise AttributeError(name)
