from __future__ import annotations

import ast
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# Mutation testing answers "is this gate actually strong?" — a test suite that passes but
# fails to catch planted faults is a vacuous gate (Meta ACH, FSE 2025, arXiv:2501.12862).
# We use deterministic AST mutants so generation is pure/reproducible; an LLM-assisted mutant
# source can be layered on later behind the learning flag.


@dataclass(frozen=True)
class Mutant:
    mutant_id: str
    description: str
    lineno: int
    source: str


# Single-node operator swaps. Each produces exactly one mutant per matching node.
_CMP_SWAP: dict[type[ast.cmpop], type[ast.cmpop]] = {
    ast.Eq: ast.NotEq,
    ast.NotEq: ast.Eq,
    ast.Lt: ast.GtE,
    ast.LtE: ast.Gt,
    ast.Gt: ast.LtE,
    ast.GtE: ast.Lt,
    ast.Is: ast.IsNot,
    ast.IsNot: ast.Is,
}
_BINOP_SWAP: dict[type[ast.operator], type[ast.operator]] = {
    ast.Add: ast.Sub,
    ast.Sub: ast.Add,
    ast.Mult: ast.Div,
    ast.Div: ast.Mult,
}
_BOOLOP_SWAP: dict[type[ast.boolop], type[ast.boolop]] = {
    ast.And: ast.Or,
    ast.Or: ast.And,
}


def generate_mutants(source: str, *, max_mutants: int = 50) -> list[Mutant]:
    """Deterministically generate single-node AST mutants of Python ``source``.

    Each mutable operator/constant occurrence yields its OWN distinct mutant — including
    multiple operators on one line and nested operators that share a source position (e.g.
    ``a + b - c`` produces two different mutants). Returns an empty list if the source cannot
    be parsed/unparsed (e.g. not Python).
    """
    try:
        ast.parse(source)
    except SyntaxError:
        return []

    descriptors = _candidate_descriptors(source)
    mutants: list[Mutant] = []
    for index, (kind, lineno) in enumerate(descriptors):
        if len(mutants) >= max(0, max_mutants):
            break
        mutated = _apply_mutation(source, index)
        if mutated is None or mutated == source:
            continue
        mutants.append(
            Mutant(
                mutant_id=f"m{index}",
                description=f"{kind}@L{lineno}",
                lineno=lineno,
                source=mutated,
            )
        )
    return mutants


def _candidate_descriptors(source: str) -> list[tuple[str, int]]:
    """Enumerate mutation candidates in deterministic ``ast.walk`` order.

    Returns one ``(kind, lineno)`` per candidate. The ordinal position in this list is the key
    used by :func:`_apply_mutation`; both functions traverse identically so ordinals align even
    for operator nodes that carry no source location of their own.
    """
    tree = ast.parse(source)
    descriptors: list[tuple[str, int]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Compare):
            for op in node.ops:
                if type(op) in _CMP_SWAP:
                    descriptors.append(("compare", int(getattr(node, "lineno", 0))))
        elif isinstance(node, ast.BinOp) and type(node.op) in _BINOP_SWAP:
            descriptors.append(("binop", int(getattr(node, "lineno", 0))))
        elif isinstance(node, ast.BoolOp) and type(node.op) in _BOOLOP_SWAP:
            descriptors.append(("boolop", int(getattr(node, "lineno", 0))))
        elif isinstance(node, ast.Constant) and isinstance(node.value, bool):
            descriptors.append(("const_bool", int(getattr(node, "lineno", 0))))
    return descriptors


def _apply_mutation(source: str, target_index: int) -> str | None:
    """Apply exactly the ``target_index``-th candidate mutation from a fresh parse.

    Walks in the same order as :func:`_candidate_descriptors`, counting candidates, and mutates
    only the one at ``target_index`` in place before unparsing.
    """
    tree = ast.parse(source)
    counter = -1
    for node in ast.walk(tree):
        if isinstance(node, ast.Compare):
            for i, op in enumerate(node.ops):
                if type(op) in _CMP_SWAP:
                    counter += 1
                    if counter == target_index:
                        node.ops[i] = _CMP_SWAP[type(op)]()
                        return _unparse(tree)
        elif isinstance(node, ast.BinOp) and type(node.op) in _BINOP_SWAP:
            counter += 1
            if counter == target_index:
                node.op = _BINOP_SWAP[type(node.op)]()
                return _unparse(tree)
        elif isinstance(node, ast.BoolOp) and type(node.op) in _BOOLOP_SWAP:
            counter += 1
            if counter == target_index:
                node.op = _BOOLOP_SWAP[type(node.op)]()
                return _unparse(tree)
        elif isinstance(node, ast.Constant) and isinstance(node.value, bool):
            counter += 1
            if counter == target_index:
                node.value = not node.value
                return _unparse(tree)
    return None


def _unparse(tree: ast.AST) -> str | None:
    ast.fix_missing_locations(tree)
    try:
        return ast.unparse(tree)
    except Exception:  # noqa: BLE001
        return None


class MutationTester:
    def __init__(self, repo_root: Path):
        self.repo_root = repo_root

    def run(
        self,
        *,
        target_file: str,
        test_command: str,
        max_mutants: int = 25,
        timeout: int = 120,
    ) -> dict[str, Any]:
        """Apply mutants to ``target_file`` one at a time, run ``test_command``, and report
        the mutation score (fraction of mutants the suite kills). A high score means the gate
        is strong; a low score means tests pass without actually constraining behavior.
        """
        path = self.repo_root / target_file
        if not path.is_file():
            return {"ok": False, "reason": "target_not_found", "target": target_file}
        original = path.read_text(encoding="utf-8")
        mutants = generate_mutants(original, max_mutants=max_mutants)
        if not mutants:
            return {
                "ok": True,
                "reason": "no_mutants",
                "target": target_file,
                "mutants": 0,
                "killed": 0,
                "mutation_score": None,
            }
        killed = 0
        survived: list[str] = []
        try:
            for mutant in mutants:
                path.write_text(mutant.source, encoding="utf-8")
                result = subprocess.run(
                    test_command,
                    cwd=self.repo_root,
                    shell=True,
                    text=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=timeout,
                )
                if result.returncode != 0:
                    killed += 1  # tests failed -> mutant caught
                else:
                    survived.append(mutant.description)
        finally:
            path.write_text(original, encoding="utf-8")
        score = round(killed / len(mutants), 4)
        return {
            "ok": True,
            "schema_version": "ctxlayer.mutation_report.v1",
            "target": target_file,
            "mutants": len(mutants),
            "killed": killed,
            "survived": survived,
            "mutation_score": score,
            "gate_strength": _gate_strength(score),
        }


def _gate_strength(score: float) -> str:
    if score >= 0.8:
        return "strong"
    if score >= 0.5:
        return "moderate"
    return "weak"
