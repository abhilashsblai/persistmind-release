GITLAB_CI_YAML = """ctxlayer:
  image: python:3.12
  script:
    - pip install ctxlayer
    - ctxlayer ci check --base origin/main --head HEAD
"""
