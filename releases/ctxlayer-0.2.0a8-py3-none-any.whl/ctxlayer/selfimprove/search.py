from __future__ import annotations

from typing import Any


def run_archive_search(engine: Any, *, max_iters: int, budget_tokens: int) -> dict[str, Any]:
    prereq = engine.prerequisites_ready()
    if not prereq["ok"]:
        return {
            "ok": False,
            "status": "blocked",
            "reason": "self_improve_prerequisites_not_ready",
            "prerequisites": prereq,
            "max_iters": max_iters,
            "budget_tokens": budget_tokens,
        }
    return {
        "ok": True,
        "status": "not_implemented",
        "reason": "autonomous proposer and propose-evaluate-adopt loop are not implemented",
        "max_iters": max_iters,
        "budget_tokens": budget_tokens,
    }
