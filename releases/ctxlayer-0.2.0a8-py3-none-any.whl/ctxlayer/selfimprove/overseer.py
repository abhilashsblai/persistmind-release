from __future__ import annotations

import fnmatch
import re
from typing import Any

from ctxlayer.selfimprove.contracts import OVERSEER_SCHEMA


def inspect_proposal(
    proposal: dict[str, Any], *, protected_globs: list[str]
) -> dict[str, Any]:
    flags: list[dict[str, Any]] = []
    for path in proposal.get("target_files", []):
        if any(fnmatch.fnmatch(path, glob) for glob in protected_globs):
            flags.append(
                {
                    "kind": "protected-path",
                    "severity": "block",
                    "detail": f"proposal touches protected path {path}",
                }
            )
    diff = str((proposal.get("evidence") or {}).get("diff") or "")
    if re.search(r"(?m)^--- a/tests/.*\n\+\+\+ /dev/null", diff):
        flags.append(
            {
                "kind": "test-deletion",
                "severity": "block",
                "detail": "proposal deletes a test file",
            }
        )
    if "eval/gate.py" in diff.replace("\\", "/"):
        flags.append(
            {
                "kind": "metric-gaming",
                "severity": "block",
                "detail": "proposal edits eval gate logic",
            }
        )
    return {
        "schema_version": OVERSEER_SCHEMA,
        "ok": not any(item["severity"] == "block" for item in flags),
        "flags": flags,
    }
