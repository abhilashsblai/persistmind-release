from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from ctxlayer.parsing.tree_sitter_registry import status as tree_sitter_status
from ctxlayer.semantic.confidence import confidence_tier
from ctxlayer.semantic.extractors import SemanticGraphBuilder
from ctxlayer.snapshot import SnapshotInfo
from ctxlayer.store import SQLiteStore


class SemanticGraphIndexer:
    def __init__(self, repo_root: Path, store: SQLiteStore):
        self.repo_root = repo_root
        self.store = store

    def index(self, snapshot: SnapshotInfo) -> dict[str, Any]:
        file_rows = self.store.snapshot_files(snapshot.snapshot_id)
        files = [row["path"] for row in file_rows]
        current_versions = {row["path"]: row["file_version_id"] for row in file_rows}
        previous_versions = {
            row["path"]: row["file_version_id"]
            for row in self.store.semantic_file_index(snapshot.repo_id)
        }
        parser = _parser_status()
        builder = SemanticGraphBuilder(self.repo_root, snapshot.repo_id)
        nodes, edges, evidence = builder.scan_files(files)
        file_index = [
            {
                "path": path,
                "file_version_id": file_version_id,
                "parser_backend": parser["backend"],
            }
            for path, file_version_id in sorted(current_versions.items())
        ]
        self.store.replace_semantic_graph(
            repo_id=snapshot.repo_id,
            nodes=nodes,
            edges=edges,
            evidence=evidence,
            file_index=file_index,
        )
        counts: dict[str, int] = {}
        for node in nodes:
            counts[node["node_type"]] = counts.get(node["node_type"], 0) + 1
        removed_paths = sorted(set(previous_versions) - set(current_versions))
        return {
            "ok": True,
            "repo_id": snapshot.repo_id,
            "snapshot_id": snapshot.snapshot_id,
            "nodes": len(nodes),
            "edges": len(edges),
            "evidence": len(evidence),
            "node_counts": dict(sorted(counts.items())),
            "parser": parser,
            "incremental": {
                "strategy": "snapshot_file_version_delta",
                "tracked_files": len(current_versions),
                "previously_tracked_files": len(previous_versions),
                "added_paths": sorted(set(current_versions) - set(previous_versions)),
                "changed_paths": sorted(
                    path
                    for path, file_version_id in current_versions.items()
                    if path in previous_versions
                    and previous_versions[path] != file_version_id
                ),
                "unchanged_paths": sorted(
                    path
                    for path, file_version_id in current_versions.items()
                    if previous_versions.get(path) == file_version_id
                ),
                "removed_paths": removed_paths,
                "stale_paths_deleted": removed_paths,
            },
            "health": self.health(snapshot.repo_id, snapshot=snapshot),
        }

    def search(self, repo_id: str, query: str, limit: int = 20) -> dict[str, Any]:
        return {
            "ok": True,
            "repo_id": repo_id,
            "results": [
                self._node_dict(row)
                for row in self.store.semantic_search(repo_id, query, limit)
            ],
        }

    def search_repo(
        self,
        snapshot: SnapshotInfo,
        query: str,
        *,
        max_hops: int = 2,
        limit: int = 20,
    ) -> dict[str, Any]:
        repo_id = snapshot.repo_id
        semantic_nodes = self.store.semantic_search(repo_id, query, limit)
        symbols = self.store.symbols_named(repo_id, _query_terms(query))[:limit]
        chunks = self.store.search_chunks(snapshot.snapshot_id, query, limit=limit)

        definitions: list[dict[str, Any]] = []
        for row in semantic_nodes:
            item = self._node_dict(row)
            item["source"] = "semantic"
            definitions.append(item)
        for row in symbols:
            definitions.append(
                {
                    "source": "symbol",
                    "symbol_identity_id": row["symbol_identity_id"],
                    "repo_id": row["repo_id"],
                    "path": row["path"],
                    "symbol_type": row["kind"],
                    "qualname": row["qualname"],
                    "is_test": bool(row["is_test"]),
                }
            )

        references: dict[tuple[Any, ...], dict[str, Any]] = {}
        for row in semantic_nodes:
            for evidence in self.store.semantic_evidence(node_id=row["node_id"]):
                item = self._evidence_dict(evidence)
                item["source"] = "semantic_evidence"
                references[
                    (
                        item.get("path"),
                        item.get("line_start"),
                        item.get("line_end"),
                        item.get("evidence_kind"),
                        item.get("node_id"),
                    )
                ] = item
        for row in chunks:
            references[
                (
                    row["path"],
                    row["start_line"],
                    row["end_line"],
                    row["category"],
                    row["chunk_id"],
                )
            ] = {
                "source": "chunk",
                "chunk_id": row["chunk_id"],
                "repo_id": row["repo_id"],
                "path": row["path"],
                "symbol_identity_id": row["symbol_identity_id"],
                "line_start": row["start_line"],
                "line_end": row["end_line"],
                "evidence_kind": row["category"],
            }

        seed_paths = sorted(
            {
                item["path"]
                for item in references.values()
                if item.get("path")
            }
            | {row["path"] for row in symbols if row["path"]}
        )
        neighbors = self.store.graph_walk(
            repo_id=repo_id,
            start_paths=seed_paths[:10],
            max_hops=max_hops,
            limit=max(25, limit * 5),
        )
        return {
            "ok": True,
            "repo_id": repo_id,
            "snapshot_id": snapshot.snapshot_id,
            "query": query,
            "definitions": definitions[:limit],
            "references": sorted(
                references.values(),
                key=lambda item: (
                    item.get("path") or "",
                    item.get("line_start") or 0,
                    item.get("evidence_kind") or "",
                ),
            )[:limit],
            "neighbors": neighbors,
        }

    def stats(self, repo_id: str) -> dict[str, Any]:
        return self.store.graph_stats(repo_id)

    def health(self, repo_id: str, snapshot: SnapshotInfo | None = None) -> dict[str, Any]:
        indexed_rows = self.store.semantic_file_index(repo_id)
        indexed_paths = {row["path"] for row in indexed_rows}
        snapshot_paths: set[str] = set()
        if snapshot is not None:
            snapshot_paths = {
                row["path"] for row in self.store.snapshot_files(snapshot.snapshot_id)
            }
        stats = self.stats(repo_id)
        indexed_ratio = 1.0
        if snapshot_paths:
            indexed_ratio = round(len(indexed_paths & snapshot_paths) / len(snapshot_paths), 6)
        return {
            "ok": True,
            "repo_id": repo_id,
            "parser": _parser_status(),
            "indexed_files": len(indexed_rows),
            "semantic_nodes": sum(int(value) for value in stats.get("semantic_nodes", {}).values()),
            "semantic_edges": sum(int(value) for value in stats.get("semantic_edges", {}).values()),
            "coverage": {
                "snapshot_files": len(snapshot_paths),
                "indexed_ratio": indexed_ratio,
            },
            "stale_index_paths": sorted(indexed_paths - snapshot_paths)
            if snapshot is not None
            else [],
        }

    def explain(self, node_id: str) -> dict[str, Any]:
        node = self.store.semantic_node(node_id)
        if not node:
            raise KeyError(f"semantic node not found: {node_id}")
        edges = [self._edge_dict(row) for row in self.store.semantic_edges_for_node(node_id)]
        evidence = [
            self._evidence_dict(row)
            for row in self.store.semantic_evidence(node_id=node_id)
        ]
        return {
            "ok": True,
            "node": self._node_dict(node),
            "edges": edges,
            "evidence": evidence,
        }

    def graph_for_path(self, repo_id: str, path: str) -> dict[str, Any]:
        evidence = [
            row
            for row in self.store.semantic_evidence()
            if row["repo_id"] == repo_id and row["path"] == path and row["node_id"]
        ]
        node_ids = sorted({row["node_id"] for row in evidence})
        nodes = [
            self._node_dict(row)
            for row in self.store.semantic_nodes(repo_id)
            if row["node_id"] in node_ids
        ]
        edges = []
        for node_id in node_ids:
            edges.extend(
                self._edge_dict(row)
                for row in self.store.semantic_edges_for_node(node_id)
            )
        return {
            "ok": True,
            "repo_id": repo_id,
            "path": path,
            "nodes": nodes,
            "edges": sorted(
                {edge["edge_id"]: edge for edge in edges}.values(),
                key=lambda item: (item["kind"], item["src_name"], item["dst_name"]),
            ),
            "evidence": [self._evidence_dict(row) for row in evidence],
        }

    def neighbors_for_path(
        self,
        repo_id: str,
        path: str,
        *,
        max_hops: int = 1,
        limit: int = 20,
        kinds: list[str] | None = None,
    ) -> dict[str, Any]:
        normalized = path.replace("\\", "/").removeprefix("./")
        return {
            "ok": True,
            "repo_id": repo_id,
            "path": normalized,
            "max_hops": max_hops,
            "neighbors": self.store.graph_walk(
                repo_id=repo_id,
                start_paths=[normalized],
                kinds=kinds,
                max_hops=max_hops,
                limit=limit,
            ),
        }

    def path_between(
        self,
        repo_id: str,
        source_path: str,
        target_path: str,
        *,
        max_hops: int = 4,
    ) -> dict[str, Any]:
        source = source_path.replace("\\", "/").removeprefix("./")
        target = target_path.replace("\\", "/").removeprefix("./")
        walk = self.store.graph_walk(
            repo_id=repo_id,
            start_paths=[source],
            max_hops=max_hops,
            limit=250,
        )
        matches = [
            edge
            for edge in walk
            if edge.get("to", {}).get("path") == target
            or target in edge.get("route", [])
        ]
        matches.sort(
            key=lambda item: (
                int(item.get("depth") or 0),
                -float(item.get("confidence") or 0.0),
            )
        )
        return {
            "ok": True,
            "repo_id": repo_id,
            "source_path": source,
            "target_path": target,
            "max_hops": max_hops,
            "found": bool(matches),
            "path": matches[0]["route"] if matches else [],
            "edge": matches[0] if matches else None,
            "explored": len(walk),
        }

    def contracts_for_path(self, repo_id: str, path: str) -> dict[str, Any]:
        graph = self.graph_for_path(repo_id, path.replace("\\", "/").removeprefix("./"))
        contract_types = {
            "api",
            "api_endpoint",
            "contract",
            "dataclass",
            "model",
            "route",
            "schema",
            "table",
        }
        contract_nodes = [
            node for node in graph["nodes"] if str(node.get("node_type") or "") in contract_types
        ]
        contract_ids = {node["node_id"] for node in contract_nodes}
        return {
            "ok": True,
            "repo_id": repo_id,
            "path": graph["path"],
            "contracts": contract_nodes,
            "edges": [
                edge
                for edge in graph["edges"]
                if edge.get("src_node_id") in contract_ids
                or edge.get("dst_node_id") in contract_ids
            ],
            "evidence": [
                item for item in graph["evidence"] if item.get("node_id") in contract_ids
            ],
        }

    def list_nodes(self, repo_id: str) -> dict[str, Any]:
        return {
            "ok": True,
            "repo_id": repo_id,
            "nodes": [self._node_dict(row) for row in self.store.semantic_nodes(repo_id)],
        }

    def low_confidence_regions(self, repo_id: str, threshold: float = 0.5) -> dict[str, Any]:
        nodes = [
            self._node_dict(row)
            for row in self.store.semantic_nodes(repo_id)
            if float(row["confidence"] or 0.0) < threshold
        ]
        edges = [
            self._edge_dict(row)
            for row in self.store.semantic_edges(repo_id)
            if float(row["confidence"] or 0.0) < threshold
        ]
        return {
            "ok": True,
            "repo_id": repo_id,
            "threshold": threshold,
            "nodes": nodes,
            "edges": edges,
            "count": len(nodes) + len(edges),
        }

    def _node_dict(self, row: Any) -> dict[str, Any]:
        metadata = json.loads(row["metadata_json"] or "{}")
        provenance = metadata.get("provenance") if isinstance(metadata, dict) else {}
        if not isinstance(provenance, dict):
            provenance = {}
        confidence = float(row["confidence"] or 0.0)
        return {
            "node_id": row["node_id"],
            "repo_id": row["repo_id"],
            "node_type": row["node_type"],
            "name": row["name"],
            "stable_key": row["stable_key"],
            "confidence": confidence,
            "confidence_tier": confidence_tier(confidence),
            "source": row["source"],
            "metadata": metadata,
            "trust_tier": row["trust_tier"] if "trust_tier" in row.keys() else None,
            "status": row["status"] if "status" in row.keys() else None,
            "governance_provenance": json.loads(row["provenance_json"] or "{}")
            if "provenance_json" in row.keys()
            else {},
            "provenance": provenance,
            "inference_method": provenance.get("inference_method"),
            "calibration_version": provenance.get("calibration_version"),
        }

    def _edge_dict(self, row: Any) -> dict[str, Any]:
        metadata = json.loads(row["metadata_json"] or "{}")
        provenance = metadata.get("provenance") if isinstance(metadata, dict) else {}
        if not isinstance(provenance, dict):
            provenance = {}
        confidence = float(row["confidence"] or 0.0)
        return {
            "edge_id": row["edge_id"],
            "src_node_id": row["src_node_id"],
            "dst_node_id": row["dst_node_id"],
            "kind": row["kind"],
            "confidence": confidence,
            "confidence_tier": confidence_tier(confidence),
            "src_type": row["src_type"],
            "src_name": row["src_name"],
            "dst_type": row["dst_type"],
            "dst_name": row["dst_name"],
            "src_trust_tier": row["src_trust_tier"] if "src_trust_tier" in row.keys() else None,
            "dst_trust_tier": row["dst_trust_tier"] if "dst_trust_tier" in row.keys() else None,
            "src_status": row["src_status"] if "src_status" in row.keys() else None,
            "dst_status": row["dst_status"] if "dst_status" in row.keys() else None,
            "evidence": json.loads(row["evidence_json"] or "[]"),
            "metadata": metadata,
            "provenance": provenance,
            "inference_method": provenance.get("inference_method"),
            "calibration_version": provenance.get("calibration_version"),
        }

    def _evidence_dict(self, row: Any) -> dict[str, Any]:
        return {
            "evidence_id": row["evidence_id"],
            "node_id": row["node_id"],
            "edge_id": row["edge_id"],
            "repo_id": row["repo_id"],
            "path": row["path"],
            "symbol_identity_id": row["symbol_identity_id"],
            "line_start": row["line_start"],
            "line_end": row["line_end"],
            "evidence_kind": row["evidence_kind"],
            "evidence_hash": row["evidence_hash"],
        }


def _query_terms(query: str) -> list[str]:
    return [
        term
        for term in re.split(r"[^A-Za-z0-9_]+", query)
        if len(term) > 1
    ]


def _parser_status() -> dict[str, Any]:
    current = tree_sitter_status()
    return {
        "backend": "tree_sitter" if current.available else "regex_fallback",
        "tree_sitter_available": current.available,
        "tree_sitter_languages": current.languages,
        "fallback": not current.available,
        "error": current.error,
    }
