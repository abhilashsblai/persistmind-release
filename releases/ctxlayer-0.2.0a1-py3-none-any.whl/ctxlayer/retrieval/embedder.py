from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Protocol

from ctxlayer.utils import sha256_bytes, split_identifier_text


class Embedder(Protocol):
    model_name: str
    dims: int

    def embed(self, text: str) -> list[float]: ...

    def embed_many(self, texts: list[str]) -> list[list[float]]: ...


@dataclass(frozen=True)
class LocalHashEmbedder:
    """Deterministic CPU-only embedding fallback.

    The production plan calls for sentence-transformers plus sqlite-vec. This
    class gives the same interface and stable vector leg without downloading a
    model during local bootstrap.
    """

    model_name: str = "local-hash-embedder-v1"
    dims: int = 128

    def embed(self, text: str) -> list[float]:
        vector = [0.0] * self.dims
        for token in split_identifier_text(text).split():
            digest = sha256_bytes(token.encode("utf-8"))
            bucket = int(digest[:8], 16) % self.dims
            sign = -1.0 if int(digest[8:10], 16) % 2 else 1.0
            vector[bucket] += sign
        norm = math.sqrt(sum(value * value for value in vector)) or 1.0
        return [round(value / norm, 6) for value in vector]

    def embed_many(self, texts: list[str]) -> list[list[float]]:
        return [self.embed(text) for text in texts]


class SentenceTransformerEmbedder:
    def __init__(self, model_name: str = "sentence-transformers/all-MiniLM-L6-v2"):
        try:
            from sentence_transformers import SentenceTransformer
        except Exception as exc:  # noqa: BLE001
            raise RuntimeError(
                "sentence-transformers is not installed; install ctxlayer[full] or set embed_backend='local'"
            ) from exc
        self.model_name = model_name
        self._model = SentenceTransformer(model_name)
        dims = self._model.get_sentence_embedding_dimension()
        self.dims = int(dims or 384)

    def embed(self, text: str) -> list[float]:
        return self.embed_many([text])[0]

    def embed_many(self, texts: list[str]) -> list[list[float]]:
        vectors = self._model.encode(
            texts,
            batch_size=64,
            normalize_embeddings=True,
            show_progress_bar=False,
        )
        return [[round(float(value), 6) for value in vector] for vector in vectors]


def make_embedder(*, model_name: str, backend: str = "auto") -> Embedder:
    if backend == "local":
        return LocalHashEmbedder(model_name=model_name)
    if backend == "sentence-transformers":
        return SentenceTransformerEmbedder(model_name=model_name)
    if backend != "auto":
        raise ValueError(f"unknown embed backend: {backend}")
    if model_name.startswith("local-"):
        return LocalHashEmbedder(model_name=model_name)
    try:
        return SentenceTransformerEmbedder(model_name=model_name)
    except RuntimeError:
        return LocalHashEmbedder(model_name=f"local-fallback-for:{model_name}")


def cosine(left: list[float], right: list[float]) -> float:
    if not left or not right or len(left) != len(right):
        return 0.0
    return sum(a * b for a, b in zip(left, right, strict=True))
