from __future__ import annotations

from typing import Any

from ctxlayer.utils import stable_id, utc_now


def derive_goals(
    *,
    intent_id: str,
    problem: str,
    evidence: list[dict[str, Any]],
    hypotheses: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    refs = sorted({ref for row in hypotheses for ref in row.get("evidence_refs", [])})
    top_path = str((evidence[0].get("path") if evidence else "") or "")
    statement = (
        f"Resolve '{problem}' by changing the evidence-backed scope around {top_path}"
        if top_path
        else f"Clarify and scope implementation for '{problem}' before changing code"
    )
    success_metric = _success_metric(problem)
    goals = [
        {
            "goal_id": stable_id("intent_goal", intent_id, "deterministic", statement),
            "intent_id": intent_id,
            "statement": statement,
            "success_metric": success_metric,
            "metric_source": "extracted" if success_metric else "none",
            "confidence": 0.8 if top_path and success_metric else 0.55,
            "origin": "deterministic",
            "evidence_refs": refs,
            "created_at": utc_now(),
        }
    ]
    questions: list[dict[str, Any]] = []
    if success_metric is None:
        questions.append(_question(intent_id, "how will we know this worked?", "no success metric"))
    if not top_path or float(goals[0]["confidence"]) < 0.7:
        questions.append(_question(intent_id, "is this actually the problem?", "low-confidence framing"))
    return goals, questions


def _success_metric(problem: str) -> str | None:
    lowered = problem.casefold()
    if any(word in lowered for word in ("test", "fail", "bug", "error", "broken", "reliability")):
        return "Targeted regression tests pass and no new impact warnings are introduced"
    if any(word in lowered for word in ("slow", "latency", "performance", "timeout")):
        return "Measured latency or runtime for the impacted path improves against the current baseline"
    if any(word in lowered for word in ("reduce", "cleanup", "simplify")):
        return "Out-of-scope edit count does not increase and targeted tests continue to pass"
    return None


def _question(intent_id: str, question: str, reason: str) -> dict[str, Any]:
    return {
        "question_id": stable_id("intent_question", intent_id, question, reason),
        "intent_id": intent_id,
        "question": question,
        "reason": reason,
        "created_at": utc_now(),
    }
