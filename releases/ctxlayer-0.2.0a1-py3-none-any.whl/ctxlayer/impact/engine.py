from __future__ import annotations

import json
import fnmatch
from collections import deque
from pathlib import Path
from typing import Any

from ctxlayer.config import Settings
from ctxlayer.snapshot import SnapshotInfo
from ctxlayer.store import SQLiteStore

RISK_WEIGHTS = {
    "changed_files": 2.0,
    "impacted_files": 2.0,
    "untested_files": 3.0,
    "low_confidence_edges": 1.5,
    "critical_paths": 4.5,
    "graph_centrality": 1.0,
}
RISK_CHANGED_FILE_BUDGET = 3
TESTABLE_EXTENSIONS = {
    ".py",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".mjs",
    ".cjs",
    ".go",
    ".java",
    ".php",
    ".rb",
    ".rs",
    ".sql",
}


class ImpactEngine:
    def __init__(self, repo_root: Path, store: SQLiteStore, settings: Settings):
        self.repo_root = repo_root
        self.store = store
        self.settings = settings

    def report(
        self,
        *,
        snapshot: SnapshotInfo,
        paths: list[str],
        pack_id: str | None = None,
        business: bool = False,
    ) -> dict[str, Any]:
        normalized_input_paths = sorted({_normalize_path(path) for path in paths if path})
        excluded_paths = [
            {"path": path, "reason": "matches configured impact ignore_globs"}
            for path in normalized_input_paths
            if self._is_ignored_path(path)
        ]
        excluded_path_set = {item["path"] for item in excluded_paths}
        normalized_paths = [path for path in normalized_input_paths if path not in excluded_path_set]
        impacted, paths_detail = self._reverse_closure(snapshot, normalized_paths)
        tests = self._select_tests(snapshot, impacted)
        untested = sorted(path for path in impacted if path not in tests["covered_paths"])
        critical = [
            path
            for path in impacted
            if any(fnmatch.fnmatch(path, glob) for glob in self.settings.eval.critical_paths)
        ]
        centrality = {
            row["path"]: row
            for row in self.store.graph_file_centrality(snapshot.repo_id)
        }
        graph_central_paths = sorted(
            path
            for path in impacted
            if float(centrality.get(path, {}).get("score") or 0.0) >= 0.5
            and int(centrality.get(path, {}).get("degree") or 0) >= 2
        )
        components, metrics = _risk_components(
            changed=normalized_paths,
            impacted=impacted,
            paths_detail=paths_detail,
            untested=untested,
            critical=critical,
            graph_central_paths=graph_central_paths,
            weights=impact_risk_weights(self.settings),
            changed_file_budget=int(self.settings.learning.optimize.impact_changed_file_budget),
        )
        risk_score = min(10.0, round(sum(components.values()), 2))
        report = {
            "schema_version": "ctxlayer.impact_report.v1",
            "repo_id": snapshot.repo_id,
            "snapshot_id": snapshot.snapshot_id,
            "scope": f"single-repo: {snapshot.repo_id}; cross-repo consumers not indexed",
            "input_paths": normalized_input_paths,
            "analyzed_paths": normalized_paths,
            "excluded_paths": excluded_paths,
            "impacted_paths": sorted(impacted),
            "dependency_paths": paths_detail,
            "tests": tests["tests"],
            "risk": {
                "score": risk_score,
                "components": components,
                "metrics": metrics,
                "untested_paths": untested,
                "critical_paths": critical,
                "graph_central_paths": graph_central_paths,
            },
        }
        if pack_id:
            pack = self.store.get_pack(pack_id)
            if pack:
                manifest = json.loads(pack["manifest_json"])
                pack_paths = {_normalize_path(item["path"]) for item in manifest.get("items", [])}
                seed_paths = {_normalize_path(path) for path in manifest.get("seed_paths", [])}
                context_paths = pack_paths | seed_paths
                report["pack_awareness"] = {
                    "pack_id": pack_id,
                    "pack_paths": sorted(pack_paths),
                    "seed_paths": sorted(seed_paths),
                    "out_of_pack_paths": sorted(set(normalized_paths) - context_paths),
                    "out_of_impact_paths": sorted(set(normalized_paths) - impacted),
                }
        if business:
            exposure = self.store.business_exposure_walk(
                snapshot.repo_id,
                sorted(impacted),
                active_only=True,
            )
            report["business_exposure"] = exposure
            self.store.append_audit(
                pack_id=pack_id or f"business-exposure:{snapshot.snapshot_id}",
                payload={
                    "event": "business_exposure_served",
                    "repo_id": snapshot.repo_id,
                    "snapshot_id": snapshot.snapshot_id,
                    "input_paths": normalized_input_paths,
                    "analyzed_paths": normalized_paths,
                    "impacted_count": len(impacted),
                    "lowest_trust_tier": exposure.get("lowest_trust_tier"),
                    "exposure_summary": exposure.get("exposure_summary", {}),
                    "authoritative": False,
                    "requires_human_review": True,
                },
            )
        return report

    def check_diff_against_pack(
        self, *, snapshot: SnapshotInfo, pack_id: str, paths: list[str]
    ) -> dict[str, Any]:
        normalized_input_paths = sorted({_normalize_path(path) for path in paths if path})
        excluded_paths = [
            {"path": path, "reason": "matches configured impact ignore_globs"}
            for path in normalized_input_paths
            if self._is_ignored_path(path)
        ]
        excluded_path_set = {item["path"] for item in excluded_paths}
        normalized_paths = [path for path in normalized_input_paths if path not in excluded_path_set]
        report = {
            "schema_version": "ctxlayer.impact_report.v1",
            "repo_id": snapshot.repo_id,
            "snapshot_id": snapshot.snapshot_id,
            "scope": f"single-repo: {snapshot.repo_id}; scoped check-diff preflight",
            "input_paths": normalized_input_paths,
            "analyzed_paths": normalized_paths,
            "excluded_paths": excluded_paths,
            "impacted_paths": normalized_paths,
            "dependency_paths": [],
            "tests": [],
            "risk": {
                "score": 0.0,
                "components": {},
                "metrics": {"changed_files": len(normalized_paths)},
                "untested_paths": [],
                "critical_paths": [],
                "graph_central_paths": [],
            },
            "performance": {
                "mode": "scoped_check_diff",
                "closure_traversal": False,
            },
        }
        pack = self.store.get_pack(pack_id)
        if pack:
            manifest = json.loads(pack["manifest_json"])
            pack_paths = {_normalize_path(item["path"]) for item in manifest.get("items", [])}
            seed_paths = {_normalize_path(path) for path in manifest.get("seed_paths", [])}
            context_paths = pack_paths | seed_paths
            report["pack_awareness"] = {
                "pack_id": pack_id,
                "pack_paths": sorted(pack_paths),
                "seed_paths": sorted(seed_paths),
                "out_of_pack_paths": sorted(set(normalized_paths) - context_paths),
                "out_of_impact_paths": [],
            }
        pack_awareness = report.get("pack_awareness", {})
        violations = []
        for path in pack_awareness.get("out_of_pack_paths", []):
            violations.append({"kind": "out_of_pack", "path": path})
        for path in pack_awareness.get("out_of_impact_paths", []):
            violations.append({"kind": "out_of_impact", "path": path})
        return {"ok": not violations, "violations": violations, "impact_report": report}

    def select_minimal_tests(
        self, *, snapshot: SnapshotInfo, paths: list[str]
    ) -> dict[str, Any]:
        """Change-driven regression test selection (RTS).

        Computes the minimal affected test set via a firewall closure over the existing
        test->symbol graph: the reverse-closure of the changed files, then the tests linked to
        anything in that closure (Ekstazi/STARTS class-firewall idea). Includes an explicit
        unsafe-fallback note because regex/structural resolution can miss dynamic dispatch and
        reflection, so callers should treat the selection as a fast path, not a guarantee.
        """
        normalized = sorted({_normalize_path(path) for path in paths if path})
        analyzed = [path for path in normalized if not self._is_ignored_path(path)]
        impacted, _detail = self._reverse_closure(snapshot, analyzed)
        selection = self._select_tests(snapshot, impacted)
        selected_tests = sorted({item["path"] for item in selection["tests"]})
        # Changed/impacted testable files with no linked test are an RTS blind spot.
        uncovered = sorted(
            path
            for path in impacted
            if _is_testable_path(path) and path not in selection["covered_paths"]
        )
        return {
            "schema_version": "ctxlayer.rts_selection.v1",
            "repo_id": snapshot.repo_id,
            "changed_paths": analyzed,
            "impacted_paths": sorted(impacted),
            "selected_tests": selected_tests,
            "test_details": selection["tests"],
            "uncovered_impacted_paths": uncovered,
            "safety": (
                "fast-path selection over structural test links; may miss tests reachable only "
                "via dynamic dispatch/reflection — run the full suite when correctness is critical"
            ),
        }

    def _reverse_closure(
        self, snapshot: SnapshotInfo, paths: list[str], max_depth: int = 4
    ) -> tuple[set[str], list[dict[str, Any]]]:
        impacted = set(paths)
        detail: dict[tuple[str, str, str, tuple[str, ...]], dict[str, Any]] = {}
        queue: deque[tuple[str, int, float, list[str]]] = deque(
            (path, 0, 1.0, [path]) for path in paths
        )
        while queue:
            path, depth, confidence, route = queue.popleft()
            if depth >= max_depth:
                continue
            for neighbor in self.store.neighbors(
                repo_id=snapshot.repo_id,
                node_type="file",
                node_id=path,
                kinds=["imports", "tests"],
                direction="in",
            ):
                if neighbor.node_type != "file":
                    continue
                if self._is_ignored_path(neighbor.node_id):
                    continue
                edge_confidence = confidence * neighbor.confidence
                if edge_confidence < 0.2:
                    continue
                new_route = [neighbor.node_id, *route]
                detail_key = (neighbor.node_id, path, neighbor.kind, tuple(new_route))
                existing = detail.get(detail_key)
                rounded_confidence = round(edge_confidence, 4)
                if existing is None:
                    detail[detail_key] = {
                        "from": neighbor.node_id,
                        "to": path,
                        "kind": neighbor.kind,
                        "confidence": rounded_confidence,
                        "route": new_route,
                    }
                else:
                    existing["confidence"] = max(float(existing["confidence"]), rounded_confidence)
                if neighbor.node_id not in impacted:
                    impacted.add(neighbor.node_id)
                    queue.append((neighbor.node_id, depth + 1, edge_confidence, new_route))
        return impacted, sorted(
            detail.values(),
            key=lambda item: (item["from"], item["to"], item["kind"], item["route"]),
        )

    def _select_tests(self, snapshot: SnapshotInfo, impacted: set[str]) -> dict[str, Any]:
        tests: list[dict[str, Any]] = []
        covered: set[str] = set()
        for path in sorted(impacted):
            for neighbor in self.store.neighbors(
                repo_id=snapshot.repo_id,
                node_type="file",
                node_id=path,
                kinds=["tests"],
                direction="in",
            ):
                if self._is_ignored_path(neighbor.node_id):
                    continue
                covered.add(path)
                tests.append(
                    {
                        "path": neighbor.node_id,
                        "covers": path,
                        "confidence": neighbor.confidence,
                        "command": self._default_test_command(snapshot.repo_id, neighbor.node_id),
                    }
                )
        unique = {
            f"{item['path']}:{item['covers']}": item
            for item in sorted(tests, key=lambda item: (item["path"], item["covers"]))
        }
        return {"tests": list(unique.values()), "covered_paths": covered}

    def _default_test_command(self, repo_id: str, path: str) -> str:
        for row in self.store.test_commands(repo_id):
            if fnmatch.fnmatch(path, row["path_glob"]):
                return row["command"].replace("{path}", path)
        if path.endswith(".py"):
            return f"pytest {path}"
        if path.endswith((".ts", ".tsx", ".js", ".jsx")):
            return "npm test -- " + path
        return "run relevant tests"

    def _is_ignored_path(self, path: str) -> bool:
        normalized = _normalize_path(path)
        for glob in self.settings.eval.ignore_globs:
            if fnmatch.fnmatch(normalized, glob) or fnmatch.fnmatch(f"./{normalized}", glob):
                return True
            if glob.startswith("**/") and fnmatch.fnmatch(normalized, glob[3:]):
                return True
        return False


def _normalize_path(path: str) -> str:
    return path.replace("\\", "/").removeprefix("./")


def _risk_components(
    *,
    changed: list[str],
    impacted: set[str],
    paths_detail: list[dict[str, Any]],
    untested: list[str],
    critical: list[str],
    graph_central_paths: list[str] | None = None,
    weights: dict[str, float] | None = None,
    changed_file_budget: int = RISK_CHANGED_FILE_BUDGET,
) -> tuple[dict[str, float], dict[str, Any]]:
    changed_count = len(changed)
    impacted_count = len(impacted)
    transitive_count = max(0, impacted_count - changed_count)
    edge_count = len(paths_detail)
    low_confidence_count = sum(1 for item in paths_detail if item["confidence"] < 0.7)
    critical_count = len(critical)
    graph_central_count = len(graph_central_paths or [])
    testable_impacted = sorted(path for path in impacted if _is_testable_path(path))
    testable_untested = sorted(path for path in untested if path in testable_impacted)

    ratios = {
        "changed_files": _ratio(changed_count, max(1, changed_file_budget)),
        "impacted_files": _ratio(transitive_count, impacted_count),
        "untested_files": _ratio(len(testable_untested), len(testable_impacted)),
        "low_confidence_edges": _ratio(low_confidence_count, edge_count),
        "critical_paths": 1.0 if critical_count else 0.0,
        "graph_centrality": _ratio(graph_central_count, impacted_count),
    }
    risk_weights = weights or RISK_WEIGHTS
    components = {
        key: round(ratios[key] * weight, 2)
        for key, weight in risk_weights.items()
    }
    metrics = {
        "changed_files": changed_count,
        "changed_file_budget": max(1, changed_file_budget),
        "impacted_files": impacted_count,
        "transitive_files": transitive_count,
        "untested_files": len(untested),
        "testable_impacted_files": len(testable_impacted),
        "testable_untested_files": len(testable_untested),
        "dependency_edges": edge_count,
        "low_confidence_edges": low_confidence_count,
        "critical_paths": critical_count,
        "graph_central_files": graph_central_count,
        "changed_breadth_ratio": round(ratios["changed_files"], 4),
        "impacted_ratio": round(ratios["impacted_files"], 4),
        "untested_ratio": round(ratios["untested_files"], 4),
        "low_confidence_ratio": round(ratios["low_confidence_edges"], 4),
        "critical_presence": round(ratios["critical_paths"], 4),
        "graph_centrality_ratio": round(ratios["graph_centrality"], 4),
    }
    return components, metrics


def impact_risk_weights(settings: Settings) -> dict[str, float]:
    optimize = settings.learning.optimize
    return {
        "changed_files": float(optimize.impact_changed_files_weight),
        "impacted_files": float(optimize.impact_impacted_files_weight),
        "untested_files": float(optimize.impact_untested_files_weight),
        "low_confidence_edges": float(optimize.impact_low_confidence_edges_weight),
        "critical_paths": float(optimize.impact_critical_paths_weight),
        "graph_centrality": float(optimize.impact_graph_centrality_weight),
    }


def _ratio(numerator: int, denominator: int) -> float:
    if denominator <= 0:
        return 0.0
    return min(1.0, numerator / denominator)


def _is_testable_path(path: str) -> bool:
    suffix = Path(path).suffix.lower()
    return suffix in TESTABLE_EXTENSIONS
