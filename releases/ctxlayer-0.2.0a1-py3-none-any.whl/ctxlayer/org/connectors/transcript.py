from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable, Mapping

from ctxlayer.org.connector import ConnectorItem, load_text_files


class TranscriptConnector:
    kind = "transcript"

    def is_local_first(self) -> bool:
        return True

    def fetch(self, *, since: str | None, config: Mapping[str, Any]) -> Iterable[ConnectorItem]:
        _ = since
        path = Path(str(config.get("path") or config.get("folder") or "."))
        return load_text_files(path, suffixes=(".vtt", ".md", ".txt", ".json"))
