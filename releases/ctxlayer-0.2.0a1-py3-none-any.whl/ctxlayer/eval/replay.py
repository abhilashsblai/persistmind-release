from __future__ import annotations

import fnmatch
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ctxlayer.config import Settings
from ctxlayer.compiler import ContextCompiler
from ctxlayer.eval.providers import fetch_provider_prs
from ctxlayer.snapshot import SnapshotInfo
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import stable_id

EDIT_SCOPE_PROXY_MAX_FILES = 5


@dataclass(frozen=True)
class ReplayCase:
    sha: str
    parent_sha: str
    subject: str
    files: list[str]


class PRReplayHarness:
    def __init__(
        self,
        repo_root: Path,
        store: SQLiteStore,
        settings: Settings,
        compiler: ContextCompiler,
    ):
        self.repo_root = repo_root
        self.store = store
        self.settings = settings
        self.compiler = compiler

    def run(
        self,
        *,
        snapshot: SnapshotInfo,
        limit: int = 50,
        holdout_ratio: float = 0.3,
        mode: str = "git-only",
    ) -> dict[str, Any]:
        cases = self.harvest(limit)
        provider_text = fetch_provider_prs(
            self.settings.eval.provider,
            self.settings.eval.provider_project,
            limit,
        )
        if provider_text:
            cases = [
                ReplayCase(
                    sha=case.sha,
                    parent_sha=case.parent_sha,
                    subject=(
                        provider_text[case.sha].title + "\n\n" + provider_text[case.sha].body
                        if case.sha in provider_text
                        else case.subject
                    ),
                    files=case.files,
                )
                for case in cases
            ]
        split = max(0, min(len(cases), int(len(cases) * (1 - holdout_ratio))))
        train = cases[:split]
        holdout = cases[split:]
        train_metrics = self._score_cases(snapshot, train)
        holdout_metrics = self._score_cases(snapshot, holdout)
        metrics = {
            "mode": self.settings.eval.provider if self.settings.eval.provider != "git" else mode,
            "leakage_rule": "history-sensitive signals must be computed from parent_sha; current implementation stores parent_sha per case and avoids future commit files as task seeds",
            "train": train_metrics,
            "holdout": holdout_metrics,
            "go_no_go": {
                "holdout_recall_pack_ok": holdout_metrics["recall_at_pack"] >= 0.6,
                "critical_path_recall_ok": holdout_metrics["critical_path_recall"] >= 0.8,
            },
        }
        eval_run_id = stable_id(snapshot.repo_id, mode, limit, metrics)
        self.store.write_eval_run(
            eval_run_id=eval_run_id,
            repo_id=snapshot.repo_id,
            mode=mode,
            train_count=len(train),
            holdout_count=len(holdout),
            metrics=metrics,
        )
        return {"eval_run_id": eval_run_id, "cases": len(cases), "metrics": metrics}

    def tune(
        self,
        *,
        snapshot: SnapshotInfo,
        limit: int = 50,
        holdout_ratio: float = 0.3,
    ) -> dict[str, Any]:
        cases = self.harvest(limit)
        split = max(0, min(len(cases), int(len(cases) * (1 - holdout_ratio))))
        train = cases[:split]
        holdout = cases[split:]
        grid = [
            {"lexical": 1.0, "vector": 0.6, "graph": 0.8, "history": 0.1},
            {"lexical": 1.0, "vector": 0.9, "graph": 0.8, "history": 0.25},
            {"lexical": 1.2, "vector": 0.6, "graph": 1.0, "history": 0.4},
            {"lexical": 0.8, "vector": 1.1, "graph": 1.0, "history": 0.25},
        ]
        scored = []
        for weights in grid:
            metrics = self._score_cases(snapshot, train, weights=weights)
            scored.append((metrics["recall_at_pack"], metrics["mrr"], weights, metrics))
        scored.sort(key=lambda item: (-item[0], -item[1], str(item[2])))
        best = scored[0][2] if scored else {}
        holdout_metrics = self._score_cases(snapshot, holdout, weights=best)
        return {
            "train_count": len(train),
            "holdout_count": len(holdout),
            "best_weights": best,
            "train_metrics": scored[0][3] if scored else {},
            "holdout_metrics": holdout_metrics,
        }

    def ab_scope_baseline(self, *, snapshot: SnapshotInfo, limit: int = 10) -> dict[str, Any]:
        cases = self.harvest(limit)
        repo_files = [row["path"] for row in self.store.snapshot_files(snapshot.snapshot_id)]
        results = []
        for case in cases:
            pack = self.compiler.compile(snapshot=snapshot, task=case.subject, write=False)
            pack_items = pack.get("items", [])
            ctxlayer_context_paths = sorted(
                {item["path"] for item in pack_items if isinstance(item.get("path"), str)}
            )
            baseline_context_paths = _lexical_baseline_paths(
                case.subject,
                repo_files,
                limit=max(1, len(ctxlayer_context_paths)),
            )
            actual = sorted(set(case.files))
            edit_proxy_limit = _edit_proxy_limit(actual)
            baseline_edit_paths = _lexical_baseline_paths(
                case.subject,
                repo_files,
                limit=edit_proxy_limit,
            )
            ctxlayer_edit_paths = _ctxlayer_edit_proxy_paths(
                pack_items,
                limit=edit_proxy_limit,
            )
            results.append(
                {
                    "sha": case.sha,
                    "subject": case.subject,
                    "actual_files": actual,
                    "edit_proxy_limit": edit_proxy_limit,
                    "baseline": {
                        "context_scope": _context_scope_metrics(actual, baseline_context_paths),
                        "edit_scope": _edit_scope_metrics(actual, baseline_edit_paths),
                    },
                    "ctxlayer": {
                        "context_scope": _context_scope_metrics(actual, ctxlayer_context_paths),
                        "edit_scope": _edit_scope_metrics(actual, ctxlayer_edit_paths),
                    },
                }
            )
        baseline_context = _aggregate_scope_metrics(
            [item["baseline"]["context_scope"] for item in results]
        )
        ctxlayer_context = _aggregate_scope_metrics(
            [item["ctxlayer"]["context_scope"] for item in results]
        )
        baseline_edit = _aggregate_scope_metrics(
            [item["baseline"]["edit_scope"] for item in results]
        )
        ctxlayer_edit = _aggregate_scope_metrics(
            [item["ctxlayer"]["edit_scope"] for item in results]
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.ab_scope_baseline.v2",
            "mode": "offline_scope_proxy",
            "scope_proxy_definition": (
                "context_scope measures full context breadth: CTXLayer pack membership versus "
                "a lexical context set with the same breadth. edit_scope measures a predicted "
                "edit proxy: seed/high-score CTXLayer items versus the top lexical files, "
                f"capped at {EDIT_SCOPE_PROXY_MAX_FILES} files and the actual diff size. "
                "wrong_files_touched only appears in edit_scope; it is not full pack membership "
                "or impact closure."
            ),
            "delta_convention": (
                "positive delta means CTXLayer improved over baseline; lower-is-better "
                "edit_scope metrics are reported as reductions. context breadth deltas are "
                "descriptive and are not treated as failures by themselves."
            ),
            "metric_directions": {
                "context_scope": {
                    "recall": "higher_is_better",
                    "precision": "descriptive",
                    "context_breadth": "descriptive",
                    "extra_context_files": "descriptive",
                    "missing_files": "lower_is_better",
                },
                "edit_scope": {
                    "precision": "higher_is_better",
                    "recall": "higher_is_better",
                    "edit_scope_drift": "lower_is_better",
                    "wrong_files_touched": "lower_is_better",
                    "missing_files": "lower_is_better",
                },
            },
            "note": (
                "This compares lexical proxies with CTXLayer context/edit proxies over "
                "git-history tasks. It is a baseline scaffold, not measured agent lift."
            ),
            "cases": len(results),
            "metrics": {
                "context_scope": {
                    "baseline": baseline_context,
                    "ctxlayer": ctxlayer_context,
                    "comparison": _context_comparison(baseline_context, ctxlayer_context),
                    "raw_delta": _raw_delta_metrics(baseline_context, ctxlayer_context),
                },
                "edit_scope": {
                    "baseline": baseline_edit,
                    "ctxlayer": ctxlayer_edit,
                    "delta": _edit_scope_delta(baseline_edit, ctxlayer_edit),
                    "raw_delta": _raw_delta_metrics(baseline_edit, ctxlayer_edit),
                },
            },
            "case_results": results,
        }

    def harvest(self, limit: int) -> list[ReplayCase]:
        try:
            result = subprocess.run(
                [
                    "git",
                    "log",
                    f"--max-count={limit}",
                    "--reverse",
                    "--pretty=format:__CTX__%H%x1f%P%x1f%s",
                    "--name-only",
                ],
                cwd=self.repo_root,
                check=True,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                timeout=30,
            )
        except (subprocess.SubprocessError, FileNotFoundError):
            return []
        cases: list[ReplayCase] = []
        current: tuple[str, str, str] | None = None
        files: list[str] = []
        for raw in result.stdout.splitlines():
            line = raw.strip()
            if not line:
                continue
            if line.startswith("__CTX__"):
                if current:
                    case = self._case(current, files)
                    if case:
                        cases.append(case)
                sha, parents, subject = line.removeprefix("__CTX__").split("\x1f", 2)
                parent = parents.split()[0] if parents else ""
                current = (sha, parent, subject)
                files = []
            elif current:
                files.append(line.replace("\\", "/"))
        if current:
            case = self._case(current, files)
            if case:
                cases.append(case)
        return cases

    def _case(self, current: tuple[str, str, str], files: list[str]) -> ReplayCase | None:
        filtered = [
            path
            for path in sorted(set(files))
            if not any(fnmatch.fnmatch(path, glob) for glob in self.settings.eval.ignore_globs)
        ]
        if not filtered:
            return None
        sha, parent, subject = current
        return ReplayCase(sha=sha, parent_sha=parent, subject=subject, files=filtered)

    def _score_cases(
        self,
        snapshot: SnapshotInfo,
        cases: list[ReplayCase],
        weights: dict[str, float] | None = None,
    ) -> dict[str, Any]:
        if not cases:
            return {
                "count": 0,
                "recall_at_pack": 0.0,
                "precision_at_pack": 0.0,
                "mrr": 0.0,
                "critical_path_recall": 1.0,
            }
        recall_sum = 0.0
        precision_sum = 0.0
        mrr_sum = 0.0
        critical_hits = 0
        critical_total = 0
        for case in cases:
            original = None
            if weights:
                original = (
                    self.settings.retrieval.lexical_weight,
                    self.settings.retrieval.vector_weight,
                    self.settings.retrieval.graph_weight,
                    self.settings.retrieval.history_weight,
                )
                object.__setattr__(self.settings.retrieval, "lexical_weight", weights["lexical"])
                object.__setattr__(self.settings.retrieval, "vector_weight", weights["vector"])
                object.__setattr__(self.settings.retrieval, "graph_weight", weights["graph"])
                object.__setattr__(self.settings.retrieval, "history_weight", weights["history"])
            try:
                pack = self.compiler.compile(snapshot=snapshot, task=case.subject, write=False)
            finally:
                if original:
                    object.__setattr__(self.settings.retrieval, "lexical_weight", original[0])
                    object.__setattr__(self.settings.retrieval, "vector_weight", original[1])
                    object.__setattr__(self.settings.retrieval, "graph_weight", original[2])
                    object.__setattr__(self.settings.retrieval, "history_weight", original[3])
            ranked = [item["path"] for item in pack["items"]]
            ranked_unique = list(dict.fromkeys(ranked))
            targets = set(case.files)
            hits = targets & set(ranked_unique)
            recall_sum += len(hits) / len(targets)
            precision_sum += len(hits) / max(1, len(ranked_unique))
            for idx, path in enumerate(ranked_unique, start=1):
                if path in targets:
                    mrr_sum += 1 / idx
                    break
            critical = {
                path
                for path in targets
                if any(fnmatch.fnmatch(path, glob) for glob in self.settings.eval.critical_paths)
            }
            critical_total += len(critical)
            critical_hits += len(critical & set(ranked_unique))
        return {
            "count": len(cases),
            "recall_at_pack": round(recall_sum / len(cases), 4),
            "precision_at_pack": round(precision_sum / len(cases), 4),
            "mrr": round(mrr_sum / len(cases), 4),
            "critical_path_recall": round(
                (critical_hits / critical_total) if critical_total else 1.0, 4
            ),
        }


def _lexical_baseline_paths(task: str, paths: list[str], *, limit: int) -> list[str]:
    task_terms = _terms(task)
    scored = []
    for path in paths:
        path_terms = _terms(path.replace("/", " "))
        overlap = task_terms & path_terms
        if not overlap:
            continue
        scored.append((len(overlap), path.count("/"), path))
    scored.sort(key=lambda item: (-item[0], item[1], item[2]))
    return [path for _, _, path in scored[:limit]]


def _context_scope_metrics(actual_files: list[str], predicted_files: list[str]) -> dict[str, Any]:
    metrics = _prediction_metrics(actual_files, predicted_files)
    metrics["context_breadth"] = metrics["predicted_file_count"]
    metrics["extra_context_files"] = metrics["extra_files"]
    return metrics


def _edit_scope_metrics(actual_files: list[str], predicted_files: list[str]) -> dict[str, Any]:
    metrics = _prediction_metrics(actual_files, predicted_files)
    metrics["edit_scope_drift"] = metrics["drift_ratio"]
    metrics["wrong_files_touched"] = metrics["extra_files"]
    return metrics


def _prediction_metrics(actual_files: list[str], predicted_files: list[str]) -> dict[str, Any]:
    actual = set(actual_files)
    predicted = set(predicted_files)
    hits = actual & predicted
    wrong = predicted - actual
    missing = actual - predicted
    precision = len(hits) / len(predicted) if predicted else (1.0 if not actual else 0.0)
    recall = len(hits) / len(actual) if actual else 1.0
    return {
        "predicted_files": sorted(predicted),
        "hits": len(hits),
        "actual_files": len(actual),
        "predicted_file_count": len(predicted),
        "extra_files": len(wrong),
        "missing_files": len(missing),
        "drift_ratio": round(len(wrong) / len(predicted), 4) if predicted else 0.0,
        "scope_drift": round(len(wrong) / len(predicted), 4) if predicted else 0.0,
        "precision": round(precision, 4),
        "recall": round(recall, 4),
    }


def _aggregate_scope_metrics(items: list[dict[str, Any]]) -> dict[str, float]:
    if not items:
        return {"count": 0}
    numeric_keys = sorted(
        {
            key
            for item in items
            for key, value in item.items()
            if isinstance(value, (int, float)) and key != "count"
        }
    )
    return {"count": len(items), **{key: _avg(items, key) for key in numeric_keys}}


def _ctxlayer_edit_proxy_paths(pack_items: list[dict[str, Any]], *, limit: int) -> list[str]:
    ranked: list[tuple[bool, float, int, str]] = []
    for index, item in enumerate(pack_items):
        path = item.get("path")
        if not isinstance(path, str) or not path:
            continue
        provenance = item.get("provenance") or []
        is_seed = isinstance(provenance, list) and "seed" in provenance
        ranked.append((is_seed, float(item.get("score") or 0.0), index, path))
    ranked.sort(key=lambda item: (not item[0], -item[1], item[2], item[3]))
    paths: list[str] = []
    seen: set[str] = set()
    for _is_seed, _score, _index, path in ranked:
        if path in seen:
            continue
        paths.append(path)
        seen.add(path)
        if len(paths) >= limit:
            break
    return paths


def _edit_proxy_limit(actual_files: list[str]) -> int:
    return max(1, min(len(set(actual_files)), EDIT_SCOPE_PROXY_MAX_FILES))


def _context_comparison(baseline: dict[str, float], ctxlayer: dict[str, float]) -> dict[str, float]:
    return {
        "recall": round(ctxlayer.get("recall", 0.0) - baseline.get("recall", 0.0), 4),
        "precision": round(ctxlayer.get("precision", 0.0) - baseline.get("precision", 0.0), 4),
        "missing_files_reduction": round(
            baseline.get("missing_files", 0.0) - ctxlayer.get("missing_files", 0.0), 4
        ),
        "context_breadth_delta": round(
            ctxlayer.get("context_breadth", 0.0) - baseline.get("context_breadth", 0.0), 4
        ),
        "extra_context_files_delta": round(
            ctxlayer.get("extra_context_files", 0.0)
            - baseline.get("extra_context_files", 0.0),
            4,
        ),
    }


def _edit_scope_delta(baseline: dict[str, float], ctxlayer: dict[str, float]) -> dict[str, float]:
    return {
        "recall": round(ctxlayer.get("recall", 0.0) - baseline.get("recall", 0.0), 4),
        "precision": round(ctxlayer.get("precision", 0.0) - baseline.get("precision", 0.0), 4),
        "edit_scope_drift_reduction": round(
            baseline.get("edit_scope_drift", 0.0) - ctxlayer.get("edit_scope_drift", 0.0),
            4,
        ),
        "wrong_files_touched_reduction": round(
            baseline.get("wrong_files_touched", 0.0)
            - ctxlayer.get("wrong_files_touched", 0.0),
            4,
        ),
        "missing_files_reduction": round(
            baseline.get("missing_files", 0.0) - ctxlayer.get("missing_files", 0.0), 4
        ),
    }


def _raw_delta_metrics(baseline: dict[str, float], ctxlayer: dict[str, float]) -> dict[str, float]:
    keys = sorted(set(baseline) & set(ctxlayer) - {"count"})
    return {key: round(ctxlayer[key] - baseline[key], 4) for key in keys}


def _avg(items: list[dict[str, Any]], key: str) -> float:
    return round(sum(float(item[key]) for item in items) / len(items), 4)


def _terms(text: str) -> set[str]:
    normalized = "".join(ch.lower() if ch.isalnum() else " " for ch in text)
    return {term for term in normalized.split() if len(term) > 2}
