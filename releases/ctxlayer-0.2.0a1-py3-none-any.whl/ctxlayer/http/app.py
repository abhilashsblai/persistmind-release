from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from ctxlayer.http.auth import authorize
from ctxlayer.product import render_dashboard_html
from ctxlayer.service import CtxLayerService

# Serializes mutating requests in the live server so concurrent agents never
# collide on the single SQLite writer. Read (GET) requests are not gated.
_WRITE_LOCK = threading.Lock()


def handle_http_request(
    service: CtxLayerService,
    method: str,
    path: str,
    body: dict[str, Any] | None = None,
    *,
    authorized: bool = True,
) -> tuple[int, dict[str, Any]]:
    method = method.upper()
    payload = body or {}
    parsed = urlparse(path)
    route = parsed.path.rstrip("/") or "/"
    query = _query_params(parsed.query)
    parts = [part for part in route.split("/") if part]

    try:
        if method == "GET" and route == "/v1/health":
            return 200, {"ok": True}
        if method == "GET" and route == "/v1/dashboard":
            return 200, service.dashboard_data()
        if method == "GET" and route == "/v1/metrics":
            return 200, service.bench()
        if method == "GET" and len(parts) == 3 and parts[:2] == ["v1", "audit"]:
            if not authorized:
                return _unauthorized()
            return 200, service.get_audit_record(parts[2])
        if method == "GET" and route == "/v1/eval/scorecard":
            if not authorized:
                return _unauthorized()
            return 200, service.eval_scorecard(query.get("output"))
        if method == "GET" and route == "/v1/eval/scorecard/public":
            return 200, _public_scorecard(service.eval_scorecard())
        if method == "POST" and route == "/v1/eval/run":
            if not authorized:
                return _unauthorized()
            suite = str(payload.get("suite", "efficacy"))
            if suite != "efficacy":
                raise ValueError(f"unsupported eval suite: {suite}")
            return 200, service.eval_run_efficacy(
                str(payload["cases"]),
                str(payload["agent_command"]),
                baseline=str(payload.get("baseline", "no-pack")),
                candidate=str(payload.get("candidate", "ctx-pack")),
                limit=int(payload.get("limit", 10)),
                timeout=int(payload.get("timeout", 600)),
                keep_worktrees=bool(payload.get("keep_worktrees", False)),
            )
        if method == "POST" and route == "/v1/eval/loop-verify":
            if not authorized:
                return _unauthorized()
            paths = payload.get("paths")
            if paths is not None and not isinstance(paths, list):
                raise ValueError("paths must be a list when provided")
            return 200, service.eval_loop_verify(
                task=str(payload.get("task", "change greeting service")),
                paths=paths,
                result=str(payload.get("result", "pass")),
            )

        if method == "POST" and route == "/v1/context-pack":
            if not authorized:
                return _unauthorized()
            return 200, service.get_context_pack(
                payload.get("task"),
                payload.get("budget"),
                payload.get("seed_paths"),
                intent_id=payload.get("intent_id"),
                goal_id=payload.get("goal_id"),
                bind_snapshot=payload.get("bind_snapshot") or payload.get("bind_snapshot_id"),
            )
        if method == "GET" and route == "/v1/snapshot/current":
            return 200, service.snapshot_current()
        if method == "GET" and route == "/v1/snapshot/lineage":
            return 200, service.snapshot_lineage(
                query.get("snapshot_id"),
                limit=int(query.get("limit", "50")),
            )
        if method == "GET" and route == "/v1/intent":
            return 200, service.intent_list(
                status=query.get("status"),
                limit=int(query.get("limit", "50")),
            )
        if method == "POST" and route == "/v1/intent":
            if not authorized:
                return _unauthorized()
            return 200, service.intent_start(
                str(payload["problem"]),
                llm_propose=bool(payload.get("llm_propose", False)),
            )
        if method == "GET" and len(parts) == 3 and parts[:2] == ["v1", "intent"]:
            return 200, service.intent_show(parts[2])
        if method == "POST" and len(parts) == 4 and parts[:2] == ["v1", "intent"] and parts[3] == "refine":
            if not authorized:
                return _unauthorized()
            return 200, service.intent_refine(
                parts[2],
                evidence=payload.get("evidence"),
                select_goal=payload.get("select_goal") or payload.get("goal_id"),
            )
        if method == "GET" and route == "/v1/goals":
            return 200, service.goal_list(
                status=query.get("status"),
                limit=int(query.get("limit", "50")),
            )
        if method == "POST" and route == "/v1/goals/evaluate":
            if not authorized:
                return _unauthorized()
            return 200, service.goal_evaluate(
                str(payload["intent_id"]),
                candidate_goal_id=payload.get("candidate_goal_id") or payload.get("candidate"),
                mode=payload.get("mode"),
            )
        if method == "GET" and len(parts) == 3 and parts[:2] == ["v1", "goals"]:
            return 200, service.goal_show(parts[2])
        if method == "POST" and len(parts) == 4 and parts[:2] == ["v1", "goals"] and parts[3] == "challenge":
            if not authorized:
                return _unauthorized()
            return 200, service.goal_challenge(parts[2])
        if method == "POST" and len(parts) == 4 and parts[:2] == ["v1", "goals"] and parts[3] == "accept-alternative":
            if not authorized:
                return _unauthorized()
            return 200, service.goal_accept_alternative(
                parts[2],
                str(payload["alt_id"]),
                str(payload.get("rationale") or ""),
            )
        if method == "POST" and len(parts) == 4 and parts[:2] == ["v1", "goals"] and parts[3] == "reject-alternative":
            if not authorized:
                return _unauthorized()
            return 200, service.goal_reject_alternative(
                parts[2],
                str(payload["alt_id"]),
                str(payload.get("rationale") or ""),
            )
        if method == "POST" and route == "/v1/impact-report":
            if not authorized:
                return _unauthorized()
            return 200, service.get_impact_report(
                payload.get("paths"),
                payload.get("pack_id"),
                payload.get("diff"),
                business=bool(payload.get("business", False)),
            )
        if method == "GET" and route == "/v1/business/entities":
            return 200, service.business_entity_list(
                status=query.get("status"),
                node_type=query.get("type"),
                limit=int(query.get("limit", "100")),
            )
        if method == "POST" and route == "/v1/business/entities":
            if not authorized:
                return _unauthorized()
            return 200, service.business_entity_add(
                node_type=str(payload["type"]),
                name=str(payload["name"]),
                attrs=dict(payload.get("attrs") or payload.get("metadata") or {}),
                origin=str(payload.get("origin", "manual")),
                source_type=payload.get("source_type"),
                source_ref=payload.get("source_ref"),
                proposed_by=str(payload.get("proposed_by", "user")),
                confidence=float(payload.get("confidence", 0.9)),
            )
        if (
            method == "POST"
            and len(parts) == 5
            and parts[:3] == ["v1", "business", "entities"]
            and parts[4] in {"approve", "reject"}
        ):
            if not authorized:
                return _unauthorized()
            if parts[4] == "approve":
                return 200, service.business_entity_approve(
                    parts[3],
                    approver=str(payload.get("approver", "human:http")),
                    notes=str(payload.get("notes", "")),
                )
            return 200, service.business_entity_reject(
                parts[3],
                approver=str(payload.get("approver", "human:http")),
                reason=str(payload.get("reason", "")),
            )
        if method == "POST" and route == "/v1/business/links":
            if not authorized:
                return _unauthorized()
            return 200, service.business_link(
                src_node_id=str(payload["src_node_id"]),
                dst_node_id=str(payload["dst_node_id"]),
                kind=str(payload["kind"]),
                source_ref=str(payload.get("source_ref") or "manual"),
                source_type=str(payload.get("source_type") or "manual_entry"),
                proposed_by=str(payload.get("proposed_by", "user")),
                confidence=float(payload["confidence"]) if payload.get("confidence") is not None else None,
            )
        if method == "GET" and route == "/v1/org/connectors":
            return 200, service.org_connectors(kind=query.get("kind"))
        if method == "POST" and route == "/v1/org/connectors":
            if not authorized:
                return _unauthorized()
            return 200, service.org_connector_add(
                str(payload["kind"]),
                config=dict(payload.get("config") or {}),
                display_name=payload.get("display_name"),
                secret_ref=payload.get("secret_ref"),
                access_scope=str(payload.get("access_scope", "restricted")),
                remote_enabled=bool(payload.get("remote_enabled", False)),
            )
        if method == "POST" and route == "/v1/org/ingest":
            if not authorized:
                return _unauthorized()
            return 200, service.org_ingest(
                str(payload["connector"]),
                since=payload.get("since"),
                path=payload.get("path"),
                remote=bool(payload.get("remote", False)),
                actor=str(payload.get("actor", "system")),
            )
        if method == "GET" and route == "/v1/org/candidates":
            return 200, service.org_candidates(
                status=query.get("status", "quarantined"),
                source=query.get("source"),
                scope=query.get("scope"),
                actor=query.get("actor", "local-user"),
                limit=int(query.get("limit", "100")),
            )
        if (
            method == "POST"
            and len(parts) == 5
            and parts[:3] == ["v1", "org", "candidates"]
            and parts[4] in {"approve", "reject"}
        ):
            if not authorized:
                return _unauthorized()
            if parts[4] == "approve":
                return 200, service.org_approve(
                    parts[3],
                    actor=str(payload.get("actor", "codeowner:http")),
                    supersede=payload.get("supersede"),
                )
            return 200, service.org_reject(
                parts[3],
                actor=str(payload.get("actor", "codeowner:http")),
                reason=str(payload.get("reason", "rejected")),
            )
        if (
            method == "GET"
            and len(parts) == 5
            and parts[:3] == ["v1", "org", "candidates"]
            and parts[4] == "audit"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.org_audit(parts[3])
        if method == "POST" and route == "/v1/decision/start":
            if not authorized:
                return _unauthorized()
            return 200, service.decision_start(
                str(payload["question"]),
                options=payload.get("options") or [],
                seed_paths=payload.get("seed_paths") or [],
            )
        if method == "POST" and route == "/v1/decision/analyze":
            if not authorized:
                return _unauthorized()
            return 200, service.decision_analyze(str(payload["decision_id"]))
        if method == "POST" and route == "/v1/decision/record":
            if not authorized:
                return _unauthorized()
            return 200, service.decision_record(
                str(payload["decision_id"]),
                chosen_option_id=str(payload["chosen_option_id"]),
                rationale=str(payload["rationale"]),
                actor=str(payload.get("actor", "local-user")),
            )
        if method == "GET" and len(parts) == 3 and parts[:2] == ["v1", "decision"]:
            return 200, service.decision_show(parts[2])
        if method == "GET" and route == "/v1/decisions":
            return 200, service.decision_list(
                status=query.get("status"),
                limit=int(query.get("limit", "50")),
            )
        if method == "POST" and route == "/v1/check-diff":
            if not authorized:
                return _unauthorized()
            return 200, service.check_diff_against_pack(payload["pack_id"], payload.get("diff"))
        if method == "GET" and route == "/v1/sessions/conflicts":
            return 200, service.session_conflicts(status=query.get("status", "open"))
        if method == "GET" and route == "/v1/sessions/leases":
            return 200, service.session_leases(status=query.get("status", "active"))
        if method == "POST" and len(parts) == 4 and parts[:2] == ["v1", "sessions"] and parts[3] == "impact":
            if not authorized:
                return _unauthorized()
            return 200, service.session_declare_impact(parts[2], payload.get("paths") or [])
        if method == "POST" and len(parts) == 4 and parts[:2] == ["v1", "sessions"] and parts[3] in {"ack", "resolve"}:
            if not authorized:
                return _unauthorized()
            status = "acknowledged" if parts[3] == "ack" else "resolved"
            return 200, service.session_conflict_update(parts[2], status)
        if method == "POST" and route == "/v1/semantic/accuracy-eval":
            if not authorized:
                return _unauthorized()
            return 200, service.semantic_accuracy_eval(payload.get("fixtures"))
        if method == "POST" and route in {"/v1/learning/loop-verify", "/learning/loop-verify"}:
            if not authorized:
                return _unauthorized()
            result = service.learning_loop_verify(
                payload.get("task"),
                probe=payload.get("probe"),
                require_closure=bool(payload.get("require_closure", False)),
            )
            status = 409 if bool(payload.get("require_closure", False)) and not result.get("ok", False) else 200
            return status, result
        if method == "POST" and route in {"/v1/security/ingest-redteam", "/security/ingest-redteam"}:
            if not authorized:
                return _unauthorized()
            result = service.security_ingest_redteam(
                payload.get("fixtures"),
                output=payload.get("output"),
                strict=bool(payload.get("strict", False)),
            )
            status = 409 if bool(payload.get("strict", False)) and not result.get("ok", False) else 200
            return status, result
        if method == "GET" and route in {"/v1/security/defense-status", "/security/defense-status"}:
            return 200, service.security_status().get("ingest", {})
        if method == "GET" and route == "/v1/semantic/low-confidence":
            return 200, service.semantic_low_confidence(
                float(query.get("threshold", "0.5"))
            )
        if method == "GET" and route == "/v1/architecture/drift":
            result = service.architecture_drift(strict=_bool(query.get("strict")))
            return (409 if result.get("status") == "fail" else 200), result
        if method == "GET" and route == "/v1/semantic/repair":
            return 200, service.semantic_repair_list(
                status=query.get("status", "open"),
                limit=int(query.get("limit", "100")),
            )
        if (
            method == "POST"
            and len(parts) == 5
            and parts[:3] == ["v1", "semantic", "repair"]
            and parts[4] in {"confirm", "reject"}
        ):
            if not authorized:
                return _unauthorized()
            if parts[4] == "confirm":
                return 200, service.semantic_repair_confirm(
                    parts[3],
                    actor=str(payload.get("actor", "human:http")),
                    rationale=str(payload.get("rationale", "")),
                )
            return 200, service.semantic_repair_reject(
                parts[3],
                actor=str(payload.get("actor", "human:http")),
                rationale=str(payload.get("rationale", "")),
            )

        handled = _handle_codex(service, method, parts, payload, authorized=authorized)
        if handled:
            return handled
        handled = _handle_memory(service, method, parts, query, payload, authorized=authorized)
        if handled:
            return handled
        handled = _handle_continuations(service, method, parts, query, payload, authorized=authorized)
        if handled:
            return handled
        handled = _handle_skills(service, method, parts, query, payload, authorized=authorized)
        if handled:
            return handled
        handled = _handle_learning(service, method, parts, query, payload, authorized=authorized)
        if handled:
            return handled
        handled = _handle_cie(service, method, parts, query, payload, authorized=authorized)
        if handled:
            return handled
        handled = _handle_security(service, method, parts, query, payload, authorized=authorized)
        if handled:
            return handled
    except KeyError as exc:
        return 404, {"ok": False, "error": str(exc).strip("'")}
    except PermissionError as exc:
        return 403, {"ok": False, "error": str(exc)}
    except ValueError as exc:
        return 400, {"ok": False, "error": str(exc)}

    return 404, {"ok": False, "error": "not found"}


def _handle_codex(
    service: CtxLayerService,
    method: str,
    parts: list[str],
    payload: dict[str, Any],
    *,
    authorized: bool,
) -> tuple[int, dict[str, Any]] | None:
    if parts[:2] != ["v1", "codex"]:
        return None
    if method == "GET" and parts == ["v1", "codex", "enforcement-status"]:
        if not authorized:
            return _unauthorized()
        return 200, service.codex_enforcement_status()
    if method == "POST" and parts == ["v1", "codex", "hook-event"]:
        # Recording/finalize transport for the local hook daemon. The
        # security-critical write gate runs in-process in the hook itself, so
        # this localhost recording endpoint does not require auth.
        event = str(payload.get("event") or "")
        body = payload.get("payload")
        if not isinstance(body, dict):
            body = {key: value for key, value in payload.items() if key != "event"}
        return 200, service.codex_hook_event(event, body)
    if method != "POST":
        return None
    if not authorized:
        return _unauthorized()
    if parts == ["v1", "codex", "preflight"]:
        return 200, service.codex_preflight(
            str(payload["task"]),
            paths=payload.get("paths"),
            mode=str(payload.get("mode", "write")),
        )
    if parts == ["v1", "codex", "parallel-plan"]:
        return 200, service.codex_parallel_plan(
            str(payload["task_session_id"]),
            str(payload["pack_id"]),
            paths=payload.get("paths"),
        )
    if parts == ["v1", "codex", "subagents", "start"]:
        return 200, service.codex_child_start(
            str(payload["parent_task_session_id"]),
            str(payload["role"]),
            str(payload["objective"]),
            write_scope=payload.get("write_scope"),
            read_scope=payload.get("read_scope"),
            parent_pack_id=payload.get("parent_pack_id"),
        )
    if parts == ["v1", "codex", "subagents", "stop"]:
        return 200, service.codex_child_stop(
            str(payload["child_agent_session_id"]),
            str(payload.get("summary", "")),
            changed_files=payload.get("changed_files"),
            tests_run=payload.get("tests_run"),
            blockers=payload.get("blockers"),
        )
    if parts == ["v1", "codex", "subagents", "pack"]:
        return 200, service.codex_child_pack(
            str(payload["parent_pack_id"]),
            str(payload["role"]),
            scope=payload.get("scope"),
        )
    if parts == ["v1", "codex", "parallel-results", "merge"]:
        return 200, service.codex_merge_parallel_results(str(payload["parallel_run_id"]))
    return None


def _handle_memory(
    service: CtxLayerService,
    method: str,
    parts: list[str],
    query: dict[str, str],
    payload: dict[str, Any],
    *,
    authorized: bool,
) -> tuple[int, dict[str, Any]] | None:
    if parts[:2] != ["v1", "memory"]:
        return None
    if method == "GET" and len(parts) == 2:
        if query.get("query"):
            return 200, service.memory_search(
                query["query"],
                types=_csv(query.get("type") or query.get("types")),
                status=query.get("status"),
            )
        return 200, service.memory_records(
            status=query.get("status"),
            types=_csv(query.get("type") or query.get("types")),
        )
    if method == "POST" and len(parts) == 2:
        if not authorized:
            return _unauthorized()
        if "type" in payload and "assertion" in payload:
            return 200, service.memory_create_typed(payload)
        return 200, service.memory_propose(
            str(payload["record_type"]),
            str(payload["assertion"]),
            payload.get("evidence_refs"),
            str(payload.get("source_kind", "manual")),
            float(payload.get("confidence", 1.0)),
        )
    if method == "POST" and parts == ["v1", "memory", "recall"]:
        return 200, service.memory_recall(
            str(payload["query"]),
            paths=payload.get("paths"),
            types=payload.get("types") or payload.get("type"),
            limit=int(payload.get("limit", 8)),
            include_org=bool(payload.get("include_org", False)),
        )
    if method == "POST" and parts == ["v1", "memory", "extraction-eval"]:
        if not authorized:
            return _unauthorized()
        return 200, service.memory_extraction_eval(
            fixtures=payload.get("fixtures"),
            source_type=payload.get("source_type"),
        )
    if method == "POST" and parts == ["v1", "memory", "trust-calibrate"]:
        if not authorized:
            return _unauthorized()
        return 200, service.memory_trust_calibrate(apply=bool(payload.get("apply", False)))
    if method == "POST" and parts == ["v1", "memory", "maintain"]:
        if not authorized:
            return _unauthorized()
        return 200, service.memory_maintain(limit=int(payload.get("limit", 200)))
    if method == "GET" and parts == ["v1", "memory", "review"]:
        return 200, service.memory_review(status=query.get("status", "open"))
    if method == "GET" and len(parts) == 4 and parts[:3] == ["v1", "memory", "utilization"]:
        return 200, service.memory_utilization(parts[3])
    if len(parts) < 3:
        return None
    record_id = parts[2]
    if method == "GET" and len(parts) == 3:
        return _status_from_ok(service.memory_show(record_id))
    if method == "GET" and len(parts) == 4 and parts[3] == "diff":
        return _status_from_ok(service.memory_diff(record_id))
    if method == "PATCH" and len(parts) == 3:
        if not authorized:
            return _unauthorized()
        patch = payload.get("patch") if isinstance(payload.get("patch"), dict) else payload
        return 200, service.memory_update(
            record_id,
            patch,
            reason=str(payload.get("reason", "http update")),
            actor=str(payload.get("actor", "codeowner:http")),
        )
    if method == "POST" and len(parts) == 4 and parts[3] in {"approve", "validate"}:
        if not authorized:
            return _unauthorized()
        return 200, service.memory_validate(
            record_id,
            validator=str(payload.get("validator", "human:http")),
            evidence=payload.get("evidence"),
            actor=str(payload.get("actor", "codeowner:http")),
        )
    if method == "POST" and len(parts) == 4 and parts[3] == "quarantine":
        if not authorized:
            return _unauthorized()
        result = service.memory_quarantine(
            record_id,
            reason=str(payload.get("reason", "http quarantine")),
            severity=str(payload.get("severity", "high")),
            actor=str(payload.get("actor", "codeowner:http")),
        )
        if result.get("ok"):
            result["record"] = service.memory_show(record_id)["record"]
        return 200, result
    if method == "POST" and len(parts) == 4 and parts[3] == "promote":
        if not authorized:
            return _unauthorized()
        return 200, service.memory_promote(
            record_id,
            validator=str(payload["validator"]),
            actor=str(payload.get("actor", "codeowner:http")),
        )
    if method == "POST" and len(parts) == 4 and parts[3] == "expire":
        if not authorized:
            return _unauthorized()
        result = service.memory_expire(
            record_id,
            reason=str(payload.get("reason", "http expire")),
            actor=str(payload.get("actor", "codeowner:http")),
        )
        if result.get("ok"):
            result["record"] = service.memory_show(record_id)["record"]
        return 200, result
    return None


def _handle_continuations(
    service: CtxLayerService,
    method: str,
    parts: list[str],
    query: dict[str, str],
    payload: dict[str, Any],
    *,
    authorized: bool,
) -> tuple[int, dict[str, Any]] | None:
    if parts[:2] != ["v1", "continuations"]:
        return None
    if method == "GET" and len(parts) == 2:
        return 200, service.continuation_list(
            status=query.get("status"),
            limit=_int(query.get("limit"), 20),
        )
    if method == "POST" and len(parts) == 3 and parts[2] == "resume":
        if not authorized:
            return _unauthorized()
        return 200, service.continuation_resume(
            str(payload["task"]),
            limit=int(payload.get("limit", 3)),
        )
    if len(parts) < 3:
        return None
    continuation_id = parts[2]
    if method == "GET" and len(parts) == 3:
        return _status_from_ok(service.continuation_show(continuation_id))
    if method == "PATCH" and len(parts) == 3:
        if not authorized:
            return _unauthorized()
        return 200, service.continuation_update(
            continuation_id,
            state=payload.get("state"),
            next_action=payload.get("next_action"),
            blockers=payload.get("blockers"),
            reason=str(payload.get("reason", "http continuation update")),
        )
    if method == "POST" and len(parts) == 4 and parts[3] == "abandon":
        if not authorized:
            return _unauthorized()
        return 200, service.continuation_abandon(
            continuation_id,
            reason=str(payload.get("reason", "http abandon")),
        )
    return None


def _handle_skills(
    service: CtxLayerService,
    method: str,
    parts: list[str],
    query: dict[str, str],
    payload: dict[str, Any],
    *,
    authorized: bool,
) -> tuple[int, dict[str, Any]] | None:
    if parts[:2] != ["v1", "skills"]:
        return None
    if method == "GET" and len(parts) == 2:
        if query.get("query"):
            return 200, service.skill_search(
                query["query"],
                limit=_int(query.get("limit"), 5),
                include_untrusted=_bool(query.get("include_untrusted")),
            )
        return 200, service.skill_list(status=query.get("status"), trust=query.get("trust"))
    if method == "POST" and len(parts) == 2:
        if not authorized:
            return _unauthorized()
        return 200, service.skill_induce(str(payload["session_id"]))
    if len(parts) < 3:
        return None
    skill_id = parts[2]
    if method == "GET" and len(parts) == 3:
        return _status_from_ok(service.skill_show(skill_id))
    if method == "POST" and len(parts) == 4 and parts[3] == "replay":
        if not authorized:
            return _unauthorized()
        return 200, service.skill_replay(skill_id, timeout=int(payload.get("timeout", 120)))
    if method == "POST" and len(parts) == 4 and parts[3] == "approve":
        if not authorized:
            return _unauthorized()
        return 200, service.skill_approve(skill_id, approved_by=str(payload.get("approved_by", "http")))
    if method == "POST" and len(parts) == 4 and parts[3] == "reject":
        if not authorized:
            return _unauthorized()
        return 200, service.skill_reject(skill_id, reason=str(payload.get("reason", "http reject")))
    return None


def _handle_learning(
    service: CtxLayerService,
    method: str,
    parts: list[str],
    query: dict[str, str],
    payload: dict[str, Any] | None = None,
    *,
    authorized: bool = True,
) -> tuple[int, dict[str, Any]] | None:
    payload = payload or {}
    if parts == ["v1", "learning", "runs"]:
        if method != "GET":
            return None
        return 200, service.learning_archive(target=query.get("target"), limit=_int(query.get("limit"), 20))
    if parts == ["v1", "selfmod", "runs"]:
        if method != "GET":
            return None
        return 200, service.learning_selfmod_archive(target=query.get("target"), limit=_int(query.get("limit"), 20))
    if method == "GET" and len(parts) == 4 and parts[:3] == ["v1", "learning", "runs"]:
        return 200, service.learning_show(parts[3])
    if method == "POST" and len(parts) == 4 and parts[:3] == ["v1", "learning", "runs"]:
        if not authorized:
            return _unauthorized()
        run_id = parts[3]
        if payload.get("action") == "adopt":
            return 200, service.learning_adopt(run_id)
        if payload.get("action") == "promote":
            return 200, service.learning_adopt(run_id)
        if payload.get("action") == "revert":
            return 200, service.learning_revert(run_id)
        return None
    if method == "POST" and parts == ["v1", "learning", "rollback"]:
        if not authorized:
            return _unauthorized()
        return 200, service.learning_rollback(
            target=payload.get("target"),
            run_id=payload.get("run_id"),
        )
    if method == "POST" and len(parts) == 5 and parts[:3] == ["v1", "learning", "runs"]:
        if not authorized:
            return _unauthorized()
        run_id = parts[3]
        if parts[4] in {"adopt", "promote"}:
            return 200, service.learning_adopt(run_id)
        if parts[4] == "revert":
            return 200, service.learning_revert(run_id)
    if method == "POST" and parts == ["v1", "selfmod", "runs", "propose"]:
        if not authorized:
            return _unauthorized()
        return 200, service.learning_selfmod_propose(
            str(payload["target"]),
            weakness=str(payload.get("weakness", "")),
            ancestor_run_id=payload.get("ancestor_run_id"),
        )
    if method == "GET" and len(parts) == 4 and parts[:3] == ["v1", "selfmod", "runs"]:
        return 200, service.learning_selfmod_show(parts[3])
    if method == "POST" and len(parts) == 5 and parts[:3] == ["v1", "selfmod", "runs"]:
        if not authorized:
            return _unauthorized()
        run_id = parts[3]
        if parts[4] in {"adopt", "approve"}:
            return 200, service.learning_selfmod_adopt(
                run_id,
                approved_by=str(payload.get("approved_by", "http")),
            )
        if parts[4] == "reject":
            return 200, service.learning_selfmod_reject(
                run_id,
                reason=str(payload.get("reason", "http reject")),
                rejected_by=str(payload.get("rejected_by", "http")),
            )
        if parts[4] in {"revert", "rollback"}:
            return 200, service.learning_selfmod_revert(run_id)
    return None


def _handle_cie(
    service: CtxLayerService,
    method: str,
    parts: list[str],
    query: dict[str, str],
    payload: dict[str, Any] | None = None,
    *,
    authorized: bool = True,
) -> tuple[int, dict[str, Any]] | None:
    payload = payload or {}
    if parts[:2] != ["v1", "cie"]:
        return None
    if method == "GET" and parts == ["v1", "cie", "status"]:
        return 200, service.cie_status()
    if method == "POST" and parts == ["v1", "cie", "cycles"]:
        if not authorized:
            return _unauthorized()
        return 200, service.cie_cycle(
            limit=_int(payload.get("limit"), 20),
            target=str(payload.get("target", "cie")),
            task=str(payload.get("task", "")),
            paths=payload.get("paths") if isinstance(payload.get("paths"), list) else [],
        )
    if method == "GET" and parts == ["v1", "cie", "cycles"]:
        return 200, service.cie_archive(
            target=query.get("target"),
            limit=_int(query.get("limit"), 20),
        )
    if method == "GET" and len(parts) == 4 and parts[:3] == ["v1", "cie", "cycles"]:
        return 200, service.cie_show(parts[3])
    if method == "POST" and parts == ["v1", "cie", "predict"]:
        return 200, service.cie_predict(
            task=str(payload.get("task", "")),
            paths=payload.get("paths") if isinstance(payload.get("paths"), list) else [],
        )
    if method == "POST" and parts == ["v1", "cie", "checklist-preview"]:
        return 200, service.cie_checklist_preview(
            task=str(payload.get("task", "")),
            paths=payload.get("paths") if isinstance(payload.get("paths"), list) else [],
        )
    if method == "GET" and parts == ["v1", "cie", "score"]:
        return 200, service.cie_score(period=query.get("period", "current"))
    if method == "GET" and parts == ["v1", "cie", "timeline"]:
        return 200, service.cie_timeline(run_id=query.get("run_id"))
    if method == "GET" and len(parts) == 5 and parts[:3] == ["v1", "cie", "cycles"] and parts[4] == "timeline":
        return 200, service.cie_timeline(run_id=parts[3])
    if len(parts) == 7 and parts[:3] == ["v1", "cie", "cycles"] and parts[4] == "interventions":
        if method != "POST":
            return None
        if not authorized:
            return _unauthorized()
        run_id = parts[3]
        intervention_id = parts[5]
        action = parts[6]
        if action == "preview":
            return 200, service.cie_preview_adoption(run_id, intervention_id)
        if action == "adopt":
            return 200, service.cie_adopt(run_id, intervention_id, str(payload.get("approved_by", "http")))
        if action == "reject":
            return 200, service.cie_reject(
                run_id,
                intervention_id,
                str(payload.get("reason", "http reject")),
                str(payload.get("actor", "http")),
            )
        if action == "suspend":
            return 200, service.cie_suspend(
                run_id,
                intervention_id,
                str(payload.get("reason", "http suspend")),
                str(payload.get("actor", "http")),
            )
    return None


def _handle_security(
    service: CtxLayerService,
    method: str,
    parts: list[str],
    query: dict[str, str],
    payload: dict[str, Any],
    *,
    authorized: bool,
) -> tuple[int, dict[str, Any]] | None:
    if method == "GET" and parts == ["v1", "security", "reviews"]:
        return 200, service.memory_security_reviews(status=query.get("status", "open"))
    if method == "POST" and len(parts) == 5 and parts[:3] == ["v1", "security", "reviews"] and parts[4] == "resolve":
        if not authorized:
            return _unauthorized()
        return 200, service.memory_review_resolve(
            parts[3],
            resolution=str(payload["resolution"]),
            actor=str(payload.get("actor", "codeowner:http")),
            target_record_id=payload.get("target_record_id"),
            validator=str(payload.get("validator", "human:security-review")),
            reason=str(payload.get("reason", "http security review")),
        )
    return None


def _query_params(raw_query: str) -> dict[str, str]:
    return {key: values[-1] for key, values in parse_qs(raw_query).items() if values}


def _csv(value: str | None) -> list[str] | None:
    if not value:
        return None
    return [item.strip() for item in value.split(",") if item.strip()]


def _int(value: str | None, default: int) -> int:
    if value is None or value == "":
        return default
    return int(value)


def _bool(value: str | None) -> bool:
    return str(value).lower() in {"1", "true", "yes", "on"}


def _status_from_ok(payload: dict[str, Any]) -> tuple[int, dict[str, Any]]:
    return (200 if payload.get("ok") else 404), payload


def _unauthorized() -> tuple[int, dict[str, Any]]:
    return 401, {"ok": False, "error": "unauthorized"}


def _public_scorecard(scorecard: dict[str, Any]) -> dict[str, Any]:
    if not scorecard.get("ok", True):
        return scorecard
    public_keys = {
        "ok",
        "schema_version",
        "created_at",
        "mode",
        "arms",
        "delta",
        "pack_quality",
        "loop_closure",
        "gate",
        "reproduction",
        "scorecard_id",
        "eval_run_id",
        "audit_hash",
    }
    return {key: scorecard[key] for key in public_keys if key in scorecard}


def serve(workspace: str | Path, host: str = "127.0.0.1", port: int = 8765, token_env: str = "CTXLAYER_TOKEN") -> None:
    workspace_path = Path(workspace)

    class Handler(BaseHTTPRequestHandler):
        def _json(self, status: int, payload: dict[str, Any]) -> None:
            body = json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _html(self, status: int, body: str) -> None:
            encoded = body.encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(encoded)))
            self.end_headers()
            self.wfile.write(encoded)

        def _body(self) -> dict[str, Any]:
            length = int(self.headers.get("Content-Length", "0"))
            if not length:
                return {}
            return json.loads(self.rfile.read(length).decode("utf-8"))

        def _authorized(self) -> bool:
            return authorize(self.headers.get("Authorization"), token_env)

        def do_GET(self) -> None:  # noqa: N802
            if self.path in {"/", "/dashboard"}:
                with CtxLayerService(workspace_path) as service:
                    self._html(200, render_dashboard_html(service.dashboard_data()["dashboard"]))
                return
            with CtxLayerService(workspace_path) as service:
                status, payload = handle_http_request(
                    service,
                    "GET",
                    self.path,
                    authorized=self._authorized(),
                )
                self._json(status, payload)

        def do_PATCH(self) -> None:  # noqa: N802
            with _WRITE_LOCK, CtxLayerService(workspace_path) as service:
                status, payload = handle_http_request(
                    service,
                    "PATCH",
                    self.path,
                    self._body(),
                    authorized=self._authorized(),
                )
                self._json(status, payload)

        def do_POST(self) -> None:  # noqa: N802
            with _WRITE_LOCK, CtxLayerService(workspace_path) as service:
                status, payload = handle_http_request(
                    service,
                    "POST",
                    self.path,
                    self._body(),
                    authorized=self._authorized(),
                )
                self._json(status, payload)

        def do_DELETE(self) -> None:  # noqa: N802
            with _WRITE_LOCK, CtxLayerService(workspace_path) as service:
                status, payload = handle_http_request(
                    service,
                    "DELETE",
                    self.path,
                    self._body(),
                    authorized=self._authorized(),
                )
                self._json(status, payload)

    ThreadingHTTPServer((host, port), Handler).serve_forever()
