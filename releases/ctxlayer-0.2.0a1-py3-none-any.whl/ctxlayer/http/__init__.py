from __future__ import annotations

from typing import Any


def serve(*args: Any, **kwargs: Any) -> None:
    from .app import serve as _serve

    return _serve(*args, **kwargs)

__all__ = ["serve"]
