from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ctxlayer.utils import stable_id


WRITE_CAPABLE_TOOLS = {
    "apply_patch",
    "edit",
    "write",
    "bash",
    "shell",
    "mcp",
}

BROAD_TASK_TERMS = {
    "all",
    "complete",
    "entire",
    "extensive",
    "implement",
    "phase",
    "phases",
    "plan",
    "plans",
    "refactor",
    "system",
}


def enforcement_status(repo_root: Path, readiness: dict[str, Any]) -> dict[str, Any]:
    checks = readiness.get("checks", {}) if isinstance(readiness, dict) else {}
    hook_status = {
        "session_start": bool(checks.get("codex_hooks")),
        "user_prompt_submit": bool(checks.get("codex_hooks")),
        "pre_tool_use": bool(checks.get("codex_hooks")),
        "post_tool_use": bool(checks.get("codex_hooks")),
        "subagent_start": bool(checks.get("codex_hooks")),
        "subagent_stop": bool(checks.get("codex_hooks")),
        "stop": bool(checks.get("codex_hooks")),
    }
    blocking = []
    if not checks.get("agents_contract"):
        blocking.append("AGENTS.md CTX contract is missing")
    if not checks.get("codex_project_config"):
        blocking.append(".codex/config.toml is missing")
    if not checks.get("codex_hooks"):
        blocking.append("Codex hook surface is missing")
    if not checks.get("codex_agents"):
        blocking.append("CTX Codex custom agents are missing")
    if not checks.get("codex_mcp_snippet"):
        blocking.append("CTX MCP snippet is missing")

    return {
        "ok": not blocking,
        "schema_version": "ctxlayer.codex_enforcement.v1",
        "repo": str(repo_root),
        "preflight_required": True,
        "preflight_ready": False,
        "blocking_reasons": blocking,
        "hook_status": hook_status,
        "mcp_status": {
            "snippet_present": bool(checks.get("codex_mcp_snippet")),
            "project_config_present": bool(checks.get("codex_project_config")),
        },
        "agent_surfaces": {
            "custom_agents_present": bool(checks.get("codex_agents")),
            "max_depth": 1,
            "max_threads": 4,
        },
        "setup": readiness,
        "enforcement_scope": "repo-local trusted-project hooks plus AGENTS.md, Git hooks, CI, and audit",
        "tamper_model": "tamper-evident repo-local enforcement; use managed requirements for hard enterprise control",
    }


def memory_retrieval_manifest(
    *,
    task: str,
    pack: dict[str, Any],
    recall: dict[str, Any],
) -> dict[str, Any]:
    retrieval = pack.get("memory_retrieval", {}) if isinstance(pack.get("memory_retrieval"), dict) else {}
    served_counts = dict(retrieval.get("served_counts_by_type", {}) or {})
    for section, memory_type in [
        ("continuations", "continuation"),
        ("policy_references", "policy_reference"),
        ("project_memory", "project_memory"),
        ("skills", "skill_reference"),
    ]:
        items = pack.get(section, []) if isinstance(pack.get(section), list) else []
        if items:
            served_counts[memory_type] = max(int(served_counts.get(memory_type, 0)), len(items))

    recall_records = recall.get("records", []) if isinstance(recall.get("records"), list) else []
    for record in recall_records:
        record_type = str(record.get("type") or "memory")
        served_counts[record_type] = served_counts.get(record_type, 0) + 1

    return {
        "memory_retrieval_id": stable_id(pack.get("pack_id", ""), task, "codex-memory-retrieval"),
        "query": task,
        "weights": retrieval.get("weights", {}),
        "backend_status": retrieval.get("backend_status", {"lexical": "ok"}),
        "excluded_counts": retrieval.get("excluded_counts", {}),
        "served_counts_by_type": served_counts,
        "stale_count": int(retrieval.get("stale_count", 0) or 0),
        "quarantine_count": int(retrieval.get("quarantine_count", 0) or 0),
        "no_backend_diagnostics": retrieval.get("no_backend_diagnostics", []),
    }


def parallel_plan(
    *,
    task: str,
    task_session_id: str,
    pack_id: str,
    paths: list[str] | None = None,
    impact_report: dict[str, Any] | None = None,
    max_threads: int = 4,
    preflight_ready: bool = True,
    worktree_clean: bool = True,
) -> dict[str, Any]:
    paths = sorted({path for path in paths or [] if path})
    terms = {part.strip(".,:;()[]{}").lower() for part in task.split()}
    impacted = impact_report.get("impacted_paths", []) if impact_report else []
    risk = (impact_report.get("risk", {}) if impact_report else {}) or {}
    risk_score = float(risk.get("score", 0.0) or 0.0)
    broad = bool(terms & BROAD_TASK_TERMS) or len(paths) >= 3 or len(impacted) >= 8
    blockers = []
    if not preflight_ready:
        blockers.append("preflight is not ready")
    if not worktree_clean:
        blockers.append("worktree is not clean")
    if max_threads < 2:
        blockers.append("parallel agent thread budget is below 2")
    if paths and _has_overlapping_directories(paths):
        conflict_policy = "parent-only integration"
    else:
        conflict_policy = "disjoint writes"

    if blockers:
        recommendation = "blocked"
        reason = "; ".join(blockers)
        agent_tasks: list[dict[str, Any]] = []
    elif broad:
        recommendation = "required"
        reason = "broad task benefits from independent exploration, implementation, review, and verification"
        agent_tasks = _agent_tasks(task, paths, required=True)
    elif risk_score >= 5.0 or len(impacted) >= 4:
        recommendation = "optional"
        reason = "moderate impact or risk makes parallel review and verification useful"
        agent_tasks = _agent_tasks(task, paths, required=False)
    else:
        recommendation = "none"
        reason = "task appears narrow enough for a single parent agent"
        agent_tasks = []

    parallel_run_id = stable_id(task_session_id, pack_id, task, json.dumps(paths, sort_keys=True))
    return {
        "ok": True,
        "schema_version": "ctxlayer.codex_parallel_plan.v1",
        "parallel_run_id": parallel_run_id,
        "task_session_id": task_session_id,
        "pack_id": pack_id,
        "parallel_recommendation": recommendation,
        "recommendation": recommendation,
        "reason": reason,
        "agent_tasks": agent_tasks[:max(0, min(max_threads, 4))],
        "conflict_policy": conflict_policy,
        "waiver_reason": None,
        "merge_contract": {
            "parent_integrates": True,
            "child_agents_do_not_revert_peer_changes": True,
            "final_parent_checks": ["check-diff", "impact", "tests", "outcome"],
        },
    }


def pre_tool_gate(
    *,
    tool_name: str,
    preflight_ready: bool,
    active_plan_step: bool,
    read_only: bool = False,
) -> dict[str, Any]:
    normalized = tool_name.strip().lower()
    write_capable = any(term in normalized for term in WRITE_CAPABLE_TOOLS)
    if read_only or not write_capable:
        return {"ok": True, "decision": "allow", "reason": "read-only or non-writing tool"}
    if not preflight_ready:
        return {
            "ok": False,
            "decision": "block",
            "reason": "write-capable Codex tool use requires ready CTX preflight",
        }
    if not active_plan_step:
        return {
            "ok": False,
            "decision": "block",
            "reason": "write-capable Codex tool use requires an active CTX plan step",
        }
    return {"ok": True, "decision": "allow", "reason": "preflight and active plan step are ready"}


def _agent_tasks(task: str, paths: list[str], *, required: bool) -> list[dict[str, Any]]:
    write_scope = paths[:2] if paths else []
    read_scope = paths or ["repo"]
    return [
        {
            "role": "ctx-explorer",
            "objective": f"Map relevant context for: {task}",
            "read_scope": read_scope,
            "write_scope": [],
            "required_pack_sections": ["items", "project_memory", "continuations", "policy_references"],
            "expected_output": "findings, risks, and suggested file ownership",
            "timeout_seconds": 900,
        },
        {
            "role": "ctx-worker",
            "objective": f"Implement assigned slice for: {task}",
            "read_scope": read_scope,
            "write_scope": write_scope,
            "required_pack_sections": ["items", "skills", "project_memory", "policy_references"],
            "expected_output": "changed files, checkpoints, and verification notes",
            "timeout_seconds": 1800,
        },
        {
            "role": "ctx-reviewer",
            "objective": f"Review correctness, security, and test gaps for: {task}",
            "read_scope": read_scope,
            "write_scope": [],
            "required_pack_sections": ["items", "memory_retrieval", "policy_references"],
            "expected_output": "ordered findings with file references",
            "timeout_seconds": 900,
        },
        {
            "role": "ctx-verifier",
            "objective": f"Run or analyze verification for: {task}",
            "read_scope": read_scope,
            "write_scope": [] if required else write_scope[:1],
            "required_pack_sections": ["items", "parallel_agent_plan"],
            "expected_output": "commands, exits, failures, and likely owning files",
            "timeout_seconds": 1200,
        },
    ]


def _has_overlapping_directories(paths: list[str]) -> bool:
    parents = [str(Path(path).parent).replace("\\", "/") for path in paths]
    return len(set(parents)) < len(parents)
