from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any

from ctxlayer import __version__
from ctxlayer.config import load_settings
from ctxlayer.governance import TaskGovernance
from ctxlayer.memory import AgentSessionMemory
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import stable_id

if TYPE_CHECKING:
    from ctxlayer.service import CtxLayerService


def main(argv: list[str] | None = None) -> None:
    argv = _normalize_global_args(list(sys.argv[1:] if argv is None else argv))
    parser = argparse.ArgumentParser(prog="ctxlayer")
    parser.add_argument("--version", action="version", version=f"ctxlayer {__version__}")
    parser.add_argument("--repo", default=".", help="Repository root")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("version")
    sub.add_parser("init")
    sub.add_parser("index")
    sub.add_parser("resolve-snapshot")
    snapshot_cmd = sub.add_parser("snapshot")
    snapshot_cmd.add_argument("snapshot_command", choices=["current", "lineage"])
    snapshot_cmd.add_argument("--snapshot-id")
    snapshot_cmd.add_argument("--limit", type=int, default=50)

    bootstrap = sub.add_parser("bootstrap")
    bootstrap.add_argument("--agents", default="codex,claude")
    bootstrap.add_argument("--mcp-command", default="ctxlayer")
    bootstrap.add_argument("--absolute-mcp-repo", action="store_true")
    bootstrap.add_argument("--skip-index", action="store_true")

    setup = sub.add_parser("setup")
    setup.add_argument("setup_command", choices=["codex"])
    setup.add_argument("--mcp-command", default="ctxlayer")
    setup.add_argument("--install-hooks", action="store_true")
    setup.add_argument("--configure-mcp", action="store_true")
    setup.add_argument("--init-git", action="store_true")
    setup.add_argument("--absolute-mcp-repo", action="store_true")
    setup.add_argument("--codex-config")
    setup.add_argument("--skip-index", action="store_true")

    pack = sub.add_parser("pack")
    pack.add_argument("--task")
    pack.add_argument("--budget", type=int)
    pack.add_argument("--seed-path", action="append", default=[])
    pack.add_argument("--intent-id")
    pack.add_argument("--goal-id")
    pack.add_argument("--bind-snapshot")
    pack.add_argument("--no-rerank", action="store_true")
    pack.add_argument("--summary", action="store_true", help="Print only IDs and actionable status")

    intent = sub.add_parser("intent")
    intent.add_argument("intent_command", choices=["start", "show", "refine", "list"])
    intent.add_argument("intent_arg", nargs="?")
    intent.add_argument("--problem")
    intent.add_argument("--llm-propose", action="store_true")
    intent.add_argument("--evidence", action="append", default=[])
    intent.add_argument("--select-goal")
    intent.add_argument("--status")
    intent.add_argument("--limit", type=int, default=50)

    goal = sub.add_parser("goal")
    goal.add_argument(
        "goal_command",
        choices=[
            "evaluate",
            "show",
            "challenge",
            "accept-alternative",
            "reject-alternative",
            "reevaluate",
            "list",
        ],
    )
    goal.add_argument("goal_arg", nargs="?")
    goal.add_argument("--candidate", dest="candidate_goal_id")
    goal.add_argument("--mode", choices=["silent", "warn", "pause-and-challenge"])
    goal.add_argument("--alt", dest="alt_id")
    goal.add_argument("--rationale")
    goal.add_argument("--status")
    goal.add_argument("--limit", type=int, default=50)
    goal.add_argument("--trigger", default="manual")

    manifest = sub.add_parser("manifest")
    manifest.add_argument("--pack-id", required=True)

    reconstruct = sub.add_parser("reconstruct-pack")
    reconstruct.add_argument("--pack-id", required=True)
    reconstruct.add_argument("--task-text")

    impact = sub.add_parser("impact")
    impact.add_argument("--pack-id")
    impact.add_argument("--paths", nargs="*", default=[])
    impact.add_argument("--paths-from-stdin", action="store_true")
    impact.add_argument("--diff-from-stdin", action="store_true")
    impact.add_argument("--business", action="store_true")
    impact.add_argument("--summary", action="store_true", help="Print a concise impact summary")

    business = sub.add_parser("business")
    business.add_argument("business_command", choices=["entity", "link"])
    business.add_argument("business_action", choices=["add", "list", "approve", "reject"], nargs="?")
    business.add_argument("business_arg", nargs="?")
    business.add_argument("--type", dest="business_type")
    business.add_argument("--name")
    business.add_argument("--file")
    business.add_argument("--attrs", default="{}")
    business.add_argument("--origin", default="manual")
    business.add_argument("--source-type")
    business.add_argument("--source-ref")
    business.add_argument("--proposed-by", default="user")
    business.add_argument("--confidence", type=float, default=0.9)
    business.add_argument("--status")
    business.add_argument("--limit", type=int, default=100)
    business.add_argument("--approver", default="human")
    business.add_argument("--notes", default="")
    business.add_argument("--reason", default="")
    business.add_argument("--src")
    business.add_argument("--dst")
    business.add_argument("--kind")

    check = sub.add_parser("check-diff")
    check.add_argument("--pack-id", required=True)
    check.add_argument("--paths", nargs="*", default=[])
    check.add_argument("--paths-from-stdin", action="store_true")
    check.add_argument("--summary", action="store_true", help="Print a concise check summary")

    search = sub.add_parser("search")
    search.add_argument("query")
    search.add_argument("--limit", type=int, default=20)

    audit = sub.add_parser("audit")
    audit.add_argument("audit_command", choices=["verify", "record", "tip", "anchor"])
    audit.add_argument("--pack-id")
    audit.add_argument("--output")
    audit.add_argument("--target", default="signed-file")

    outcome = sub.add_parser("outcome")
    outcome.add_argument("--pack-id", required=True)
    outcome.add_argument("--result", required=True)
    outcome.add_argument("--files", nargs="*", default=None)
    outcome.add_argument("--session-id")
    outcome.add_argument("--summary", default=None)

    sub.add_parser("bench")
    sub.add_parser("doctor")
    sub.add_parser("gc")

    hook = sub.add_parser("hook")
    hook.add_argument("hook_command", choices=["install"])

    constitution = sub.add_parser("constitution")
    constitution.add_argument("constitution_command", choices=["build", "show", "check"])
    constitution.add_argument("--staged", action="store_true")
    constitution.add_argument("--path", dest="constitution_paths", action="append", default=[])
    constitution.add_argument("--task-session-id")
    constitution.add_argument("--ci", action="store_true")
    constitution.add_argument("--fail-on-violation", action="store_true")

    task = sub.add_parser("task")
    task.add_argument("task_command", choices=["start", "transition", "show"])
    task.add_argument("task_arg", nargs="?")
    task.add_argument("--task")
    task.add_argument("--state")
    task.add_argument("--actor", default="local-user")
    task.add_argument("--reason")
    task.add_argument("--pack-id")
    task.add_argument("--summary", action="store_true", help="Print only task/session IDs and state")

    plan = sub.add_parser("plan")
    plan.add_argument("plan_command", choices=["validate", "create", "show", "amend", "checkpoint"])
    plan.add_argument("plan_arg", nargs="?")
    plan.add_argument("--file", dest="plan_file")
    plan.add_argument("--json", dest="plan_json")
    plan.add_argument("--task-session-id")
    plan.add_argument("--pack-id")
    plan.add_argument("--author", default="local-user")
    plan.add_argument("--reason")
    plan.add_argument("--step-id")
    plan.add_argument("--path", dest="plan_paths", action="append", default=[])
    plan.add_argument("--staged", action="store_true")
    plan.add_argument("--fail-on-violation", action="store_true")
    plan.add_argument("--summary", action="store_true", help="Print only plan IDs and actionable status")

    release = sub.add_parser("release")
    release.add_argument(
        "release_command",
        choices=[
            "check",
            "report",
            "compare",
            "gap-register",
            "gap-validate",
            "gap-write",
            "inventory-write",
            "checklist-write",
            "benchmark-write",
        ],
    )
    release.add_argument("--baseline")
    release.add_argument("--version", default="1.0.0")
    release.add_argument("--output")

    ci = sub.add_parser("ci")
    ci.add_argument("ci_command", choices=["check", "emit-github", "emit-gitlab", "explain"])
    ci.add_argument("--base", default="origin/main")
    ci.add_argument("--head", default="HEAD")
    ci.add_argument("--pack-id")
    ci.add_argument("--report")

    workspace = sub.add_parser("workspace")
    workspace.add_argument(
        "workspace_command", choices=["init", "add-repo", "index", "impact", "status", "promotions"]
    )
    workspace.add_argument("workspace_arg", nargs="?")
    workspace.add_argument("--repo-id")
    workspace.add_argument("--repo", dest="workspace_repo_alias")

    eval_cmd = sub.add_parser("eval")
    eval_cmd.add_argument(
        "eval_command",
        choices=[
            "replay",
            "tune",
            "components",
            "ab",
            "agent",
            "run",
            "efficacy",
            "loop-verify",
            "scorecard",
            "gate",
            "harvest",
            "compare",
            "diagnose",
        ],
    )
    eval_cmd.add_argument("eval_provider", nargs="?")
    eval_cmd.add_argument("--limit", type=int, default=50)
    eval_cmd.add_argument("--holdout-ratio", type=float, default=0.3)
    eval_cmd.add_argument("--provider-repo")
    eval_cmd.add_argument("--repo", dest="provider_repo_alias")
    eval_cmd.add_argument("--project")
    eval_cmd.add_argument("--task-source", action="append", default=[])
    eval_cmd.add_argument("--report")
    eval_cmd.add_argument("--ground-truth")
    eval_cmd.add_argument("--cases")
    eval_cmd.add_argument("--agent-command")
    eval_cmd.add_argument("--suite", default="efficacy")
    eval_cmd.add_argument("--baseline", default="no-pack")
    eval_cmd.add_argument("--candidate", default="ctx-pack")
    eval_cmd.add_argument("--output")
    eval_cmd.add_argument("--probe-task", default="change greeting service")
    eval_cmd.add_argument("--probe-path", action="append", default=[])
    eval_cmd.add_argument("--result", default="pass")
    eval_cmd.add_argument("--timeout", type=int, default=600)
    eval_cmd.add_argument("--keep-worktrees", action="store_true")
    eval_cmd.add_argument("--gate", action="store_true")
    eval_cmd.add_argument("--fail-on-regression", action="store_true")
    eval_cmd.add_argument("--min-cases", type=int, default=1)
    eval_cmd.add_argument("--min-success-rate-delta", type=float, default=0.0)
    eval_cmd.add_argument("--min-tests-pass-rate-delta", type=float, default=0.0)
    eval_cmd.add_argument("--min-wrong-files-reduction", type=float, default=0.0)
    eval_cmd.add_argument("--min-missing-files-reduction", type=float, default=0.0)
    eval_cmd.add_argument("--min-ctxlayer-success-rate", type=float, default=0.0)

    learning = sub.add_parser("learning")
    learning.add_argument(
        "learning_command",
        choices=[
            "status",
            "optimize",
            "archive",
            "benchmark-trends",
            "adopt",
            "revert",
            "selfmod-propose",
            "selfmod-archive",
            "selfmod-adopt",
            "selfmod-revert",
            "loop-verify",
        ],
    )
    learning.add_argument("learning_arg", nargs="?")
    learning.add_argument("--target", default="pack_weights")
    learning.add_argument("--weakness", default="")
    learning.add_argument("--ancestor-run-id")
    learning.add_argument("--approved-by", default="local-user")
    learning.add_argument("--iterations", type=int, default=1)
    learning.add_argument("--limit", type=int, default=20)
    learning.add_argument("--holdout-ratio", type=float, default=0.3)
    learning.add_argument("--adopt", action="store_true")
    learning.add_argument("--probe", choices=["ranking", "rule_status"], default=None)
    learning.add_argument("--all", dest="learning_all", action="store_true")
    learning.add_argument("--require-closure", action="store_true")

    cie = sub.add_parser("cie")
    cie.add_argument(
        "cie_command",
        choices=[
            "status",
            "cycle",
            "archive",
            "show",
            "checklist-preview",
            "predict",
            "score",
            "timeline",
            "preview-adoption",
            "adopt",
            "reject",
            "suspend",
            "rollback",
            "export-state",
            "import-state",
            "rebuild-state",
        ],
    )
    cie.add_argument("cie_arg", nargs="?")
    cie.add_argument("--limit", type=int, default=20)
    cie.add_argument("--target", default="cie")
    cie.add_argument("--task", default="")
    cie.add_argument("--path", dest="cie_paths", action="append", default=[])
    cie.add_argument("--run-id")
    cie.add_argument("--intervention-id")
    cie.add_argument("--approved-by", default="local-user")
    cie.add_argument("--reason", default="")
    cie.add_argument("--actor", default="local-user")
    cie.add_argument("--period", default="current")
    cie.add_argument("--output")
    cie.add_argument("--input")
    cie.add_argument("--dry-run", action="store_true")
    cie.add_argument("--from-events", action="store_true")

    skill = sub.add_parser("skill")
    skill.add_argument(
        "skill_command",
        choices=["induce", "list", "show", "replay", "approve", "reject", "prune", "maintain", "search"],
    )
    skill.add_argument("skill_arg", nargs="?")
    skill.add_argument("--session", "--session-id", dest="skill_session_id")
    skill.add_argument("--status")
    skill.add_argument("--trust")
    skill.add_argument("--approved-by", default="local-user")
    skill.add_argument("--reason", default="manual reject")
    skill.add_argument("--limit", type=int, default=5)
    skill.add_argument("--include-untrusted", action="store_true")
    skill.add_argument("--timeout", type=int, default=120)
    skill.add_argument("--max-failures", type=int, default=3)
    skill.add_argument("--stale-after-days", type=int)

    security = sub.add_parser("security")
    security.add_argument(
        "security_command",
        choices=["scan", "status", "redact-audit", "quarantine-list", "ingest-redteam"],
    )
    security.add_argument("--status", default="open")
    security.add_argument("--fixtures")
    security.add_argument("--output")
    security.add_argument("--strict", action="store_true")

    memory = sub.add_parser("memory")
    memory.add_argument(
        "memory_command",
        choices=[
            "scan",
            "candidates",
            "explain",
            "list",
            "approve",
            "reject",
            "supersede",
            "conflicts",
            "stale",
            "verify",
            "explain-rule",
            "eval",
            "extraction-eval",
            "trust-calibrate",
            "search",
            "create",
            "update",
            "validate",
            "expire",
            "quarantine",
            "diff",
            "dream",
            "maintain",
            "promote",
            "review",
            "propose",
            "recall",
            "consolidate",
            "reflect",
            "utilization",
        ],
    )
    memory.add_argument("rule_id", nargs="?")
    memory.add_argument("memory_eval_command", nargs="?")
    memory.add_argument("--status")
    memory.add_argument("--fixtures", default="eval/rules")
    memory.add_argument("--source-type")
    memory.add_argument("--apply", action="store_true")
    memory.add_argument("--dry-run", action="store_true")
    memory.add_argument("--approved-by", default="local-user")
    memory.add_argument("--with", dest="with_candidate")
    memory.add_argument("--type", dest="memory_type", action="append", default=[])
    memory.add_argument("--source-kind", default="manual")
    memory.add_argument("--confidence", type=float, default=1.0)
    memory.add_argument("--title")
    memory.add_argument("--json", dest="memory_json")
    memory.add_argument("--reason", default="manual")
    memory.add_argument("--validator", default="human")
    memory.add_argument("--severity", default="high")
    memory.add_argument("--path", dest="memory_paths", action="append", default=[])
    memory.add_argument("--limit", type=int, default=20)
    memory.add_argument("--recent", type=int, default=10)
    memory.add_argument("--session", "--session-id", dest="session_id")
    memory.add_argument("--include-org", action="store_true")

    continuation = sub.add_parser("continuation")
    continuation.add_argument(
        "continuation_command",
        choices=["list", "show", "update", "resume", "abandon"],
    )
    continuation.add_argument("continuation_arg", nargs="?")
    continuation.add_argument("--task")
    continuation.add_argument("--state")
    continuation.add_argument("--next-action")
    continuation.add_argument("--blocker", dest="continuation_blockers", action="append", default=[])
    continuation.add_argument("--reason", default="manual")
    continuation.add_argument("--status")
    continuation.add_argument("--limit", type=int, default=20)

    session = sub.add_parser("session")
    session.add_argument(
        "session_command",
        choices=["start", "event", "finish", "explain", "leases", "declare-impact", "conflicts", "ack", "resolve"],
    )
    session.add_argument("session_arg", nargs="?")
    session.add_argument("--task")
    session.add_argument("--agent", default="codex")
    session.add_argument("--session-id")
    session.add_argument("--type", dest="event_type")
    session.add_argument("--payload", default="{}")
    session.add_argument("--result", default="pass")
    session.add_argument("--path", dest="session_paths", action="append", default=[])
    session.add_argument("--status", default="open")

    loop = sub.add_parser("loop")
    loop.add_argument("loop_command", choices=["runbook"])
    loop.add_argument("--task", required=True)
    loop.add_argument("--path", dest="loop_paths", action="append", default=[])
    loop.add_argument("--test", dest="loop_tests", action="append", default=[])
    loop.add_argument("--result", default="pass")

    runtime = sub.add_parser("runtime")
    runtime.add_argument("runtime_command", choices=["ingest", "link-errors", "candidates"])
    runtime.add_argument("runtime_source", nargs="?")
    runtime.add_argument("runtime_path", nargs="?")

    org = sub.add_parser("org")
    org.add_argument(
        "org_command",
        choices=["connector", "ingest", "candidates", "approve", "reject", "audit"],
    )
    org.add_argument("org_arg", nargs="?")
    org.add_argument("org_arg2", nargs="?")
    org.add_argument("--config")
    org.add_argument("--display-name")
    org.add_argument("--secret-ref")
    org.add_argument("--scope", default="restricted")
    org.add_argument("--remote", action="store_true")
    org.add_argument("--since")
    org.add_argument("--path")
    org.add_argument("--status", default="quarantined")
    org.add_argument("--source")
    org.add_argument("--actor", default="local-user")
    org.add_argument("--supersede")
    org.add_argument("--reason", default="rejected")
    org.add_argument("--limit", type=int, default=100)

    decision = sub.add_parser("decision")
    decision.add_argument(
        "decision_command",
        choices=["start", "analyze", "record", "show", "list"],
    )
    decision.add_argument("decision_id", nargs="?")
    decision.add_argument("--question")
    decision.add_argument("--option", dest="decision_options", action="append", default=[])
    decision.add_argument("--seed-paths", dest="decision_seed_paths", action="append", default=[])
    decision.add_argument("--chosen", dest="chosen_option_id")
    decision.add_argument("--rationale")
    decision.add_argument("--actor", default="local-user")
    decision.add_argument("--status")
    decision.add_argument("--limit", type=int, default=50)

    dashboard = sub.add_parser("dashboard")
    dashboard.add_argument("dashboard_command", choices=["data", "render"])
    dashboard.add_argument("--output", default=".ctxlayer/dashboard.html")

    rollup = sub.add_parser("rollup")
    rollup.add_argument("--label")
    rollup.add_argument("--limit", type=int, default=30)
    rollup.add_argument("--output")

    registry = sub.add_parser(
        "registry", help="Track projects where CTX Layer is installed/updated"
    )
    registry.add_argument(
        "registry_command", choices=["register", "list", "remove", "prune"]
    )
    registry.add_argument("--label", help="Friendly name (defaults to the repo folder name)")
    registry.add_argument(
        "--action", choices=["install", "update"], default="install"
    )
    registry.add_argument("--path", help="Project path for remove (defaults to --repo)")

    semantic = sub.add_parser("semantic")
    semantic.add_argument(
        "semantic_command",
        choices=[
            "index",
            "search",
            "repo-search",
            "explain",
            "graph",
            "list",
            "stats",
            "accuracy-eval",
            "low-confidence",
            "repair",
        ],
    )
    semantic.add_argument("semantic_arg", nargs="?")
    semantic.add_argument("--path")
    semantic.add_argument("--fixtures")
    semantic.add_argument("--threshold", type=float, default=0.5)
    semantic.add_argument("--status", default="open")
    semantic.add_argument("--finding-id")
    semantic.add_argument("--rationale", default="")
    semantic.add_argument("--limit", type=int, default=20)
    semantic.add_argument("--max-hops", type=int, default=2)

    architecture = sub.add_parser("architecture")
    architecture.add_argument(
        "architecture_command",
        choices=["infer", "map", "explain", "drift", "critical-paths"],
    )
    architecture.add_argument("architecture_arg", nargs="?")
    architecture.add_argument("--service")
    architecture.add_argument("--strict", action="store_true")

    behavior = sub.add_parser("behavior")
    behavior.add_argument("behavior_command", choices=["check"])
    behavior.add_argument("--path", dest="behavior_paths", action="append", default=[])
    behavior.add_argument("--diff-from-stdin", action="store_true")
    behavior.add_argument("--pack-id")

    verify = sub.add_parser("verify")
    verify.add_argument("verify_command", choices=["run"])
    verify.add_argument("--command", dest="verify_commands", action="append", default=[])
    verify.add_argument("--pack-id")
    verify.add_argument("--retry-budget", type=int, default=0)
    verify.add_argument("--timeout", type=int, default=120)

    agent = sub.add_parser("agent")
    agent.add_argument("agent_command", choices=["route"])
    agent.add_argument("--task", required=True)
    agent.add_argument("--risk-score", type=float, default=0.0)
    agent.add_argument("--capability", dest="agent_capabilities", action="append", default=[])
    agent.add_argument("--remote-review", action="store_true")

    codex = sub.add_parser("codex")
    codex.add_argument(
        "codex_command",
        choices=[
            "preflight",
            "enforcement-status",
            "parallel-plan",
            "child-start",
            "child-stop",
            "child-pack",
            "merge-parallel-results",
            "install-surfaces",
            "hook",
        ],
    )
    codex.add_argument("--task")
    codex.add_argument("--mode", default="write")
    codex.add_argument("--path", dest="codex_paths", action="append", default=[])
    codex.add_argument("--task-session-id")
    codex.add_argument("--pack-id")
    codex.add_argument("--parallel-run-id")
    codex.add_argument("--role", default="ctx-worker")
    codex.add_argument("--objective")
    codex.add_argument("--write-scope", action="append", default=[])
    codex.add_argument("--read-scope", action="append", default=[])
    codex.add_argument("--child-agent-session-id")
    codex.add_argument("--summary-text", default="")
    codex.add_argument("--changed-file", action="append", default=[])
    codex.add_argument("--test-run", action="append", default=[])
    codex.add_argument("--blocker", action="append", default=[])
    codex.add_argument("--event")
    codex.add_argument("--payload", default="{}")
    codex.add_argument("--mcp-command", default="ctxlayer")
    codex.add_argument("--install-hooks", action="store_true")
    codex.add_argument("--configure-mcp", action="store_true")
    codex.add_argument("--init-git", action="store_true")
    codex.add_argument("--absolute-mcp-repo", action="store_true")
    codex.add_argument("--codex-config")
    codex.add_argument("--skip-index", action="store_true")

    npx = sub.add_parser("npx")
    npx.add_argument("npx_command", choices=["doctor", "update"])
    npx.add_argument("--source")
    npx.add_argument("--project", action="store_true")

    serve = sub.add_parser("serve")
    serve.add_argument("--workspace", default=".")
    serve.add_argument("--host")
    serve.add_argument("--port", type=int)
    serve.add_argument("--auth", choices=["none", "token"], default=None)

    mcp = sub.add_parser("mcp")
    mcp.add_argument("--stdio", action="store_true", default=True)

    args = parser.parse_args(argv)
    try:
        if args.command == "npx":
            result = _dispatch_npx(args)
        elif args.command == "task" and args.task_command == "start":
            task_text = args.task or args.task_arg
            if not task_text:
                raise ValueError("task start requires --task")
            result = _fast_task_start(Path(args.repo), task_text)
        else:
            from ctxlayer.service import CtxLayerService

            with CtxLayerService(Path(args.repo)) as service:
                result = _dispatch(args, service)
    except Exception as exc:  # noqa: BLE001 - CLI should return a JSON error envelope.
        print(json.dumps({"ok": False, "error": str(exc)}, indent=2), file=sys.stderr)
        raise SystemExit(1) from exc
    if result is not None:
        if getattr(args, "summary", False):
            result = _summary_result(args, result)
        print(json.dumps(result, indent=2, sort_keys=True))


def _dispatch(args: argparse.Namespace, service: CtxLayerService) -> dict[str, Any] | None:
    if args.command == "version":
        return {"ok": True, "version": __version__}
    if args.command == "init":
        return service.init()
    if args.command == "bootstrap":
        return service.bootstrap(
            agents=args.agents,
            mcp_command=args.mcp_command,
            absolute_mcp_repo=args.absolute_mcp_repo,
            skip_index=args.skip_index,
        )
    if args.command == "setup":
        if args.setup_command == "codex":
            return service.setup_codex(
                mcp_command=args.mcp_command,
                install_hooks=args.install_hooks,
                configure_mcp=args.configure_mcp,
                init_git=args.init_git,
                absolute_mcp_repo=args.absolute_mcp_repo,
                codex_config=args.codex_config,
                skip_index=args.skip_index,
            )
    if args.command in {"index", "resolve-snapshot"}:
        return service.refresh_index() if args.command == "index" else service.resolve_snapshot()
    if args.command == "snapshot":
        if args.snapshot_command == "current":
            return service.snapshot_current()
        if args.snapshot_command == "lineage":
            return service.snapshot_lineage(args.snapshot_id, limit=args.limit)
    if args.command == "pack":
        return service.get_context_pack(
            args.task,
            args.budget,
            args.seed_path,
            rerank=not args.no_rerank,
            intent_id=args.intent_id,
            goal_id=args.goal_id,
            bind_snapshot=args.bind_snapshot,
        )
    if args.command == "intent":
        if args.intent_command == "start":
            problem = args.problem or args.intent_arg
            if not problem:
                raise ValueError("intent start requires --problem")
            return service.intent_start(problem, llm_propose=args.llm_propose)
        if args.intent_command == "show":
            if not args.intent_arg:
                raise ValueError("intent show requires an intent id")
            return service.intent_show(args.intent_arg)
        if args.intent_command == "refine":
            if not args.intent_arg:
                raise ValueError("intent refine requires an intent id")
            return service.intent_refine(
                args.intent_arg,
                evidence=args.evidence,
                select_goal=args.select_goal,
            )
        if args.intent_command == "list":
            return service.intent_list(status=args.status, limit=args.limit)
    if args.command == "goal":
        if args.goal_command == "evaluate":
            if not args.goal_arg:
                raise ValueError("goal evaluate requires an intent id")
            return service.goal_evaluate(
                args.goal_arg,
                candidate_goal_id=args.candidate_goal_id,
                mode=args.mode,
            )
        if args.goal_command == "show":
            if not args.goal_arg:
                raise ValueError("goal show requires a goal id")
            return service.goal_show(args.goal_arg)
        if args.goal_command == "challenge":
            if not args.goal_arg:
                raise ValueError("goal challenge requires a goal id")
            return service.goal_challenge(args.goal_arg)
        if args.goal_command == "accept-alternative":
            if not args.goal_arg or not args.alt_id or not args.rationale:
                raise ValueError("goal accept-alternative requires goal id, --alt, and --rationale")
            return service.goal_accept_alternative(args.goal_arg, args.alt_id, args.rationale)
        if args.goal_command == "reject-alternative":
            if not args.goal_arg or not args.alt_id or not args.rationale:
                raise ValueError("goal reject-alternative requires goal id, --alt, and --rationale")
            return service.goal_reject_alternative(args.goal_arg, args.alt_id, args.rationale)
        if args.goal_command == "reevaluate":
            if not args.goal_arg:
                raise ValueError("goal reevaluate requires a goal id")
            return service.goal_reevaluate(args.goal_arg, trigger=args.trigger)
        if args.goal_command == "list":
            return service.goal_list(status=args.status, limit=args.limit)
    if args.command == "manifest":
        return service.get_pack_manifest(args.pack_id)
    if args.command == "reconstruct-pack":
        return service.reconstruct_pack(args.pack_id, args.task_text)
    if args.command == "impact":
        paths = list(args.paths)
        diff = None
        if args.paths_from_stdin:
            paths.extend(line.strip() for line in sys.stdin if line.strip())
        if args.diff_from_stdin:
            diff = sys.stdin.read()
        return service.get_impact_report(
            paths=paths,
            pack_id=args.pack_id,
            diff=diff,
            business=args.business,
        )
    if args.command == "business":
        if args.business_command == "entity":
            if args.business_action == "add":
                if args.file and not args.name and not args.business_type:
                    return service.business_entity_bulk_add(
                        file=args.file,
                        origin=args.origin,
                        proposed_by=args.proposed_by,
                    )
                if not args.business_type or not args.name:
                    raise ValueError("business entity add requires --type and --name, or --file")
                attrs = json.loads(args.attrs or "{}")
                if args.file:
                    path = Path(args.file)
                    attrs = json.loads(path.read_text(encoding="utf-8"))
                return service.business_entity_add(
                    node_type=args.business_type,
                    name=args.name,
                    attrs=attrs,
                    origin=args.origin,
                    source_type=args.source_type,
                    source_ref=args.source_ref or args.file,
                    proposed_by=args.proposed_by,
                    confidence=args.confidence,
                )
            if args.business_action == "list":
                return service.business_entity_list(
                    status=args.status,
                    node_type=args.business_type,
                    limit=args.limit,
                )
            if args.business_action == "approve":
                if not args.business_arg:
                    raise ValueError("business entity approve requires a node id")
                return service.business_entity_approve(
                    args.business_arg,
                    approver=args.approver,
                    notes=args.notes,
                )
            if args.business_action == "reject":
                if not args.business_arg:
                    raise ValueError("business entity reject requires a node id")
                return service.business_entity_reject(
                    args.business_arg,
                    approver=args.approver,
                    reason=args.reason,
                )
        if args.business_command == "link":
            if not args.src or not args.dst or not args.kind:
                raise ValueError("business link requires --src, --dst, and --kind")
            return service.business_link(
                src_node_id=args.src,
                dst_node_id=args.dst,
                kind=args.kind,
                source_ref=args.source_ref or "manual",
                source_type=args.source_type or "manual_entry",
                proposed_by=args.proposed_by,
                confidence=args.confidence,
            )
    if args.command == "check-diff":
        paths = list(args.paths)
        diff = None
        if args.paths_from_stdin:
            paths.extend(line.strip() for line in sys.stdin if line.strip())
        else:
            diff = sys.stdin.read()
        return service.check_diff_against_pack(args.pack_id, diff=diff, paths=paths or None)
    if args.command == "search":
        return service.search_code(args.query, args.limit)
    if args.command == "audit":
        if args.audit_command == "verify":
            return service.verify_audit()
        if args.audit_command == "tip":
            return service.export_audit_tip(args.output)
        if args.audit_command == "anchor":
            return service.anchor_audit(args.target)
        if not args.pack_id:
            raise ValueError("--pack-id is required for audit record")
        return service.get_audit_record(args.pack_id)
    if args.command == "outcome":
        return service.record_outcome(
            args.pack_id,
            args.result,
            args.files,
            args.session_id,
            summary=args.summary,
        )
    if args.command == "bench":
        return service.bench()
    if args.command == "doctor":
        return service.doctor()
    if args.command == "gc":
        return service.gc()
    if args.command == "hook":
        if args.hook_command == "install":
            return service.install_post_commit_hook()
    if args.command == "constitution":
        if args.constitution_command == "build":
            return service.constitution_build()
        if args.constitution_command == "show":
            return service.constitution_show()
        if args.constitution_command == "check":
            result = service.constitution_check(
                args.constitution_paths,
                staged=args.staged,
                task_session_id=args.task_session_id,
                for_ci=args.ci,
            )
            if args.fail_on_violation and not result.get("ok"):
                raise ValueError("constitution capability check failed")
            return result
    if args.command == "task":
        if args.task_command == "start":
            task_text = args.task or args.task_arg
            if not task_text:
                raise ValueError("task start requires --task")
            return service.task_start(task_text)
        if args.task_command == "transition":
            task_session_id = args.task_arg
            if not task_session_id or not args.state:
                raise ValueError("task transition requires task_session_id and --state")
            return service.task_transition(
                task_session_id,
                args.state,
                actor=args.actor,
                reason=args.reason,
                pack_id=args.pack_id,
            )
        if args.task_command == "show":
            if not args.task_arg:
                raise ValueError("task show requires task_session_id")
            return service.task_show(args.task_arg)
    if args.command == "plan":
        if args.plan_command == "validate":
            plan = _load_plan_arg(args)
            result = service.plan_validate(
                plan,
                task_session_id=args.task_session_id,
                pack_id=args.pack_id,
            )
            if args.fail_on_violation and not result.get("ok"):
                raise ValueError("task plan validation failed")
            return result
        if args.plan_command == "create":
            if not args.task_session_id:
                raise ValueError("plan create requires --task-session-id")
            plan = _load_plan_arg(args)
            result = service.plan_create(
                args.task_session_id,
                plan,
                pack_id=args.pack_id,
                author=args.author,
            )
            if args.fail_on_violation and not result.get("ok"):
                raise ValueError("task plan validation failed")
            return result
        if args.plan_command == "show":
            if not args.plan_arg:
                raise ValueError("plan show requires plan_id")
            return service.plan_show(args.plan_arg)
        if args.plan_command == "amend":
            if not args.plan_arg:
                raise ValueError("plan amend requires plan_id")
            plan = _load_plan_arg(args, allow_positional_json=False)
            result = service.plan_amend(
                args.plan_arg,
                plan,
                author=args.author,
                reason=args.reason,
            )
            if args.fail_on_violation and not result.get("ok"):
                raise ValueError("task plan validation failed")
            return result
        if args.plan_command == "checkpoint":
            if not args.plan_arg or not args.step_id:
                raise ValueError("plan checkpoint requires plan_id and --step-id")
            result = service.plan_checkpoint(
                args.plan_arg,
                args.step_id,
                paths=args.plan_paths,
                staged=args.staged,
            )
            if args.fail_on_violation and not result.get("ok"):
                raise ValueError("task plan checkpoint failed")
            return result
    if args.command == "eval":
        if args.eval_command == "replay":
            return service.eval_replay(args.limit, args.holdout_ratio)
        if args.eval_command == "tune":
            return service.eval_tune(args.limit, args.holdout_ratio)
        if args.eval_command == "components":
            return service.eval_components(args.ground_truth)
        if args.eval_command == "ab":
            return service.eval_ab_baseline(args.limit)
        if args.eval_command == "agent":
            if not args.cases or not args.agent_command:
                raise ValueError("eval agent requires --cases and --agent-command")
            result = service.eval_agent_benchmark(
                args.cases,
                args.agent_command,
                limit=args.limit,
                timeout=args.timeout,
                keep_worktrees=args.keep_worktrees,
                gate=args.gate,
                gate_thresholds=_agent_gate_thresholds(args) if args.gate else None,
            )
            if args.fail_on_regression and result.get("gate", {}).get("status") == "fail":
                raise ValueError("agent benchmark regression gate failed")
            return result
        if args.eval_command in {"run", "efficacy"}:
            if args.eval_command == "run" and args.suite != "efficacy":
                raise ValueError(f"unsupported eval suite: {args.suite}")
            if not args.cases or not args.agent_command:
                raise ValueError(f"eval {args.eval_command} requires --cases and --agent-command")
            result = service.eval_run_efficacy(
                args.cases,
                args.agent_command,
                baseline=args.baseline,
                candidate=args.candidate,
                limit=args.limit,
                timeout=args.timeout,
                keep_worktrees=args.keep_worktrees,
            )
            if args.fail_on_regression and result.get("gate", {}).get("status") == "fail":
                raise ValueError("efficacy scorecard gate failed")
            return result
        if args.eval_command == "scorecard":
            return service.eval_scorecard(args.output)
        if args.eval_command == "loop-verify":
            return service.eval_loop_verify(
                task=args.probe_task,
                paths=args.probe_path or ["app/service.py"],
                result=args.result,
            )
        if args.eval_command == "gate":
            if not args.report:
                raise ValueError("eval gate requires --report")
            result = service.eval_agent_gate(args.report, thresholds=_agent_gate_thresholds(args))
            if args.fail_on_regression and result.get("status") == "fail":
                raise ValueError("agent benchmark regression gate failed")
            return result
        if args.eval_command == "harvest":
            provider = args.eval_provider
            project = args.provider_repo or args.provider_repo_alias or args.project
            if not provider or not project:
                raise ValueError("eval harvest requires provider and --provider-repo/--project")
            return service.eval_harvest(provider, project, args.limit)
        if args.eval_command == "compare":
            return service.eval_compare(args.task_source or ["git-only", "provider"], args.limit)
        if args.eval_command == "diagnose":
            if not args.report:
                raise ValueError("eval diagnose requires --report")
            return service.eval_diagnose(json.loads(Path(args.report).read_text(encoding="utf-8")))
    if args.command == "cie":
        if args.cie_command == "status":
            return service.cie_status()
        if args.cie_command == "cycle":
            return service.cie_cycle(
                limit=args.limit,
                target=args.target,
                task=args.task,
                paths=args.cie_paths,
            )
        if args.cie_command == "archive":
            return service.cie_archive(target=args.target if args.target else None, limit=args.limit)
        if args.cie_command == "show":
            run_id = args.run_id or args.cie_arg
            if not run_id:
                raise ValueError("cie show requires run_id")
            return service.cie_show(run_id)
        if args.cie_command == "checklist-preview":
            return service.cie_checklist_preview(task=args.task or args.cie_arg or "", paths=args.cie_paths)
        if args.cie_command == "predict":
            return service.cie_predict(task=args.task or args.cie_arg or "", paths=args.cie_paths)
        if args.cie_command == "score":
            return service.cie_score(period=args.period)
        if args.cie_command == "timeline":
            return service.cie_timeline(run_id=args.run_id or args.cie_arg)
        if args.cie_command in {"preview-adoption", "adopt", "reject", "suspend", "rollback"}:
            run_id = args.run_id
            intervention_id = args.intervention_id or args.cie_arg
            if not run_id or not intervention_id:
                raise ValueError(f"cie {args.cie_command} requires --run-id and intervention_id")
            if args.cie_command == "preview-adoption":
                return service.cie_preview_adoption(run_id, intervention_id)
            if args.cie_command == "adopt":
                return service.cie_adopt(run_id, intervention_id, args.approved_by)
            if args.cie_command == "reject":
                return service.cie_reject(run_id, intervention_id, args.reason, args.actor)
            if args.cie_command == "suspend":
                return service.cie_suspend(run_id, intervention_id, args.reason, args.actor)
            if args.cie_command == "rollback":
                return service.cie_rollback(run_id, intervention_id, args.approved_by)
        if args.cie_command == "export-state":
            return service.cie_export_state(output=args.output)
        if args.cie_command == "import-state":
            input_path = args.input or args.cie_arg
            if not input_path:
                raise ValueError("cie import-state requires --input")
            return service.cie_import_state(input_path, dry_run=args.dry_run or True)
        if args.cie_command == "rebuild-state":
            return service.cie_rebuild_state(from_events=args.from_events or True, dry_run=args.dry_run or True)
    if args.command == "learning":
        if args.learning_command == "status":
            return service.learning_status()
        if args.learning_command == "optimize":
            return service.learning_optimize(
                args.target,
                iterations=args.iterations,
                limit=args.limit,
                holdout_ratio=args.holdout_ratio,
                adopt=args.adopt,
            )
        if args.learning_command == "archive":
            return service.learning_archive(target=args.target if args.target else None, limit=args.limit)
        if args.learning_command == "benchmark-trends":
            return service.learning_benchmark_trends(limit=args.limit)
        if args.learning_command == "adopt":
            run_id = args.learning_arg
            if not run_id:
                raise ValueError("learning adopt requires run_id")
            return service.learning_adopt(run_id)
        if args.learning_command == "revert":
            run_id = args.learning_arg
            if not run_id:
                raise ValueError("learning revert requires run_id")
            return service.learning_revert(run_id)
        if args.learning_command == "selfmod-propose":
            return service.learning_selfmod_propose(
                args.target,
                weakness=args.weakness,
                ancestor_run_id=args.ancestor_run_id,
            )
        if args.learning_command == "selfmod-archive":
            return service.learning_selfmod_archive(
                target=args.target if args.target else None,
                limit=args.limit,
            )
        if args.learning_command == "selfmod-adopt":
            run_id = args.learning_arg
            if not run_id:
                raise ValueError("learning selfmod-adopt requires run_id")
            return service.learning_selfmod_adopt(run_id, approved_by=args.approved_by)
        if args.learning_command == "selfmod-revert":
            run_id = args.learning_arg
            if not run_id:
                raise ValueError("learning selfmod-revert requires run_id")
            return service.learning_selfmod_revert(run_id)
        if args.learning_command == "loop-verify":
            probe = "all" if args.learning_all else args.probe
            result = service.learning_loop_verify(
                args.learning_arg,
                probe=probe,
                require_closure=args.require_closure,
            )
            if args.require_closure and not result.get("ok", False):
                raise SystemExit(json.dumps(result, indent=2, sort_keys=True))
            return result
    if args.command == "skill":
        if args.skill_command == "induce":
            session_id = args.skill_session_id or args.skill_arg
            if not session_id:
                raise ValueError("skill induce requires --session")
            return service.skill_induce(session_id)
        if args.skill_command == "list":
            return service.skill_list(status=args.status, trust=args.trust)
        if args.skill_command == "show":
            if not args.skill_arg:
                raise ValueError("skill show requires skill_id")
            return service.skill_show(args.skill_arg)
        if args.skill_command == "replay":
            if not args.skill_arg:
                raise ValueError("skill replay requires skill_id")
            return service.skill_replay(args.skill_arg, timeout=args.timeout)
        if args.skill_command == "approve":
            if not args.skill_arg:
                raise ValueError("skill approve requires skill_id")
            return service.skill_approve(args.skill_arg, approved_by=args.approved_by)
        if args.skill_command == "reject":
            if not args.skill_arg:
                raise ValueError("skill reject requires skill_id")
            return service.skill_reject(args.skill_arg, reason=args.reason)
        if args.skill_command == "prune":
            return service.skill_prune(max_failures=args.max_failures)
        if args.skill_command == "maintain":
            return service.skill_maintain(
                max_failures=args.max_failures,
                stale_after_days=args.stale_after_days,
            )
        if args.skill_command == "search":
            if not args.skill_arg:
                raise ValueError("skill search requires query")
            return service.skill_search(
                args.skill_arg,
                limit=args.limit,
                include_untrusted=args.include_untrusted,
            )
    if args.command == "release":
        if args.release_command == "check":
            return service.release_check(args.version)
        if args.release_command == "report":
            return service.release_report()
        if args.release_command == "compare":
            if not args.baseline:
                raise ValueError("release compare requires --baseline")
            return service.release_compare(args.baseline)
        if args.release_command == "gap-register":
            return service.release_gap_register()
        if args.release_command == "gap-validate":
            return service.release_gap_validate()
        if args.release_command == "gap-write":
            return service.release_gap_write(args.output)
        if args.release_command == "inventory-write":
            return service.release_dead_code_inventory_write(args.output)
        if args.release_command == "checklist-write":
            return service.release_no_v0_checklist_write(args.output)
        if args.release_command == "benchmark-write":
            return service.release_benchmark_artifacts_write(args.output)
    if args.command == "ci":
        if args.ci_command == "check":
            return service.ci_check(args.base, args.head, args.pack_id)
        if args.ci_command == "emit-github":
            return service.ci_emit_github()
        if args.ci_command == "emit-gitlab":
            return service.ci_emit_gitlab()
        if args.ci_command == "explain":
            if not args.report:
                raise ValueError("ci explain requires --report")
            return service.ci_explain(args.report)
    if args.command == "workspace":
        if args.workspace_command == "init":
            return service.workspace_init()
        if args.workspace_command == "add-repo":
            if not args.workspace_arg:
                raise ValueError("workspace add-repo requires a path")
            return service.workspace_add_repo(args.workspace_arg)
        if args.workspace_command == "index":
            return service.workspace_index()
        if args.workspace_command == "impact":
            repo_id = args.repo_id or args.workspace_repo_alias or args.workspace_arg
            if not repo_id:
                raise ValueError("workspace impact requires --repo-id")
            return service.workspace_impact(repo_id)
        if args.workspace_command == "status":
            return service.workspace_status()
        if args.workspace_command == "promotions":
            return service.workspace_rule_promotions()
    if args.command == "security":
        if args.security_command == "scan":
            return service.security_scan()
        if args.security_command == "status":
            return service.security_status()
        if args.security_command == "redact-audit":
            return {"ok": True, "message": "audit text storage is hashed by default; no plaintext redaction needed"}
        if args.security_command == "quarantine-list":
            return service.memory_security_reviews(args.status)
        if args.security_command == "ingest-redteam":
            result = service.security_ingest_redteam(
                args.fixtures,
                output=args.output,
                strict=args.strict,
            )
            if args.strict and not result.get("ok", False):
                raise SystemExit(json.dumps(result, indent=2, sort_keys=True))
            return result
    if args.command == "memory":
        if args.memory_command == "scan":
            return service.memory_scan()
        if args.memory_command == "candidates":
            return service.memory_candidates(args.status)
        if args.memory_command == "explain":
            if not args.rule_id:
                raise ValueError("memory explain requires candidate_id")
            return service.memory_explain(args.rule_id)
        if args.memory_command == "list":
            return service.memory_list(args.status)
        if args.memory_command == "approve":
            if not args.rule_id:
                raise ValueError("memory approve requires candidate_id")
            return service.memory_approve(args.rule_id, args.approved_by)
        if args.memory_command == "reject":
            if not args.rule_id:
                raise ValueError("memory reject requires candidate_id")
            return service.memory_reject(args.rule_id)
        if args.memory_command == "supersede":
            if not args.rule_id or not args.with_candidate:
                raise ValueError("memory supersede requires old_rule_id --with new_candidate_id")
            return service.memory_supersede(args.rule_id, args.with_candidate, args.approved_by)
        if args.memory_command == "conflicts":
            return service.memory_conflicts()
        if args.memory_command == "stale":
            return service.memory_stale()
        if args.memory_command == "verify":
            return service.memory_verify()
        if args.memory_command == "explain-rule":
            if not args.rule_id:
                raise ValueError("memory explain-rule requires rule_id")
            return service.memory_explain(args.rule_id)
        if args.memory_command == "eval":
            if not args.rule_id:
                raise ValueError("memory eval requires harvest|replay|report")
            return service.memory_eval(args.rule_id)
        if args.memory_command == "extraction-eval":
            return service.memory_extraction_eval(args.fixtures, args.source_type)
        if args.memory_command == "trust-calibrate":
            return service.memory_trust_calibrate(apply=bool(args.apply and not args.dry_run))
        if args.memory_command == "search":
            if not args.rule_id:
                raise ValueError("memory search requires a query")
            return service.memory_search(args.rule_id, args.memory_type or None, args.status)
        if args.memory_command == "recall":
            if not args.rule_id:
                raise ValueError("memory recall requires a query")
            return service.memory_recall(
                args.rule_id,
                paths=args.memory_paths,
                types=args.memory_type or None,
                limit=args.limit,
                include_org=args.include_org,
            )
        if args.memory_command == "create":
            if args.memory_json:
                payload = json.loads(args.memory_json)
            else:
                if not args.rule_id or not args.memory_type:
                    raise ValueError("memory create requires --type and assertion")
                payload = {
                    "type": args.memory_type[0],
                    "assertion": args.rule_id,
                    "title": args.title,
                    "source_kind": args.source_kind,
                    "confidence": args.confidence,
                    "scope_refs": args.memory_paths,
                }
            return service.memory_create_typed(payload)
        if args.memory_command == "update":
            if not args.rule_id or not args.memory_json:
                raise ValueError("memory update requires record_id and --json patch")
            return service.memory_update(args.rule_id, json.loads(args.memory_json), args.reason)
        if args.memory_command == "validate":
            if not args.rule_id:
                raise ValueError("memory validate requires record_id")
            return service.memory_validate(args.rule_id, args.validator, actor=args.approved_by)
        if args.memory_command == "expire":
            if not args.rule_id:
                raise ValueError("memory expire requires record_id")
            return service.memory_expire(args.rule_id, args.reason, actor=args.approved_by)
        if args.memory_command == "quarantine":
            if not args.rule_id:
                raise ValueError("memory quarantine requires record_id")
            return service.memory_quarantine(
                args.rule_id,
                args.reason,
                severity=args.severity,
                actor=args.approved_by,
            )
        if args.memory_command == "diff":
            if not args.rule_id:
                raise ValueError("memory diff requires record_id")
            return service.memory_diff(args.rule_id)
        if args.memory_command == "dream":
            return service.memory_dream(args.session_id or args.rule_id, args.recent)
        if args.memory_command == "maintain":
            return service.memory_maintain(args.limit)
        if args.memory_command == "promote":
            if not args.rule_id or not args.validator:
                raise ValueError("memory promote requires record_id and --validator")
            return service.memory_promote(args.rule_id, args.validator, actor=args.approved_by)
        if args.memory_command == "review":
            return service.memory_review(args.status)
        if args.memory_command == "consolidate":
            return service.memory_consolidate(args.session_id or args.rule_id, args.recent)
        if args.memory_command == "reflect":
            return service.memory_reflect(args.session_id or args.rule_id, args.recent)
        if args.memory_command == "utilization":
            if not args.rule_id:
                raise ValueError("memory utilization requires pack_id")
            return service.memory_utilization(args.rule_id)
        if args.memory_command == "propose":
            if not args.rule_id or not args.memory_type:
                raise ValueError("memory propose requires --type and assertion")
            return service.memory_propose(
                args.memory_type[0],
                args.rule_id,
                source_kind=args.source_kind,
                confidence=args.confidence,
            )
    if args.command == "continuation":
        if args.continuation_command == "list":
            return service.continuation_list(args.status, args.limit)
        if args.continuation_command == "show":
            if not args.continuation_arg:
                raise ValueError("continuation show requires continuation_id")
            return service.continuation_show(args.continuation_arg)
        if args.continuation_command == "update":
            if not args.continuation_arg:
                raise ValueError("continuation update requires continuation_id")
            return service.continuation_update(
                args.continuation_arg,
                state=args.state,
                next_action=args.next_action,
                blockers=args.continuation_blockers or None,
                reason=args.reason,
            )
        if args.continuation_command == "resume":
            task = args.task or args.continuation_arg
            if not task:
                raise ValueError("continuation resume requires --task")
            return service.continuation_resume(task, args.limit)
        if args.continuation_command == "abandon":
            if not args.continuation_arg:
                raise ValueError("continuation abandon requires continuation_id")
            return service.continuation_abandon(args.continuation_arg, args.reason)
    if args.command == "session":
        if args.session_command == "start":
            task = args.task or args.session_arg
            if not task:
                raise ValueError("session start requires --task")
            return service.session_start(task, args.agent)
        if args.session_command == "event":
            session_id = args.session_id or args.session_arg
            if not session_id or not args.event_type:
                raise ValueError("session event requires session_id and --type")
            return service.session_event(session_id, args.event_type, json.loads(args.payload))
        if args.session_command == "finish":
            session_id = args.session_id or args.session_arg
            if not session_id:
                raise ValueError("session finish requires session_id")
            return service.session_finish(session_id, args.result)
        if args.session_command == "explain":
            session_id = args.session_id or args.session_arg
            if not session_id:
                raise ValueError("session explain requires session_id")
            return service.session_explain(session_id)
        if args.session_command == "leases":
            return service.session_leases(status=args.status or None)
        if args.session_command == "declare-impact":
            session_id = args.session_id or args.session_arg
            if not session_id:
                raise ValueError("session declare-impact requires session_id")
            return service.session_declare_impact(session_id, args.session_paths)
        if args.session_command == "conflicts":
            return service.session_conflicts(status=args.status or None)
        if args.session_command in {"ack", "resolve"}:
            if not args.session_arg:
                raise ValueError(f"session {args.session_command} requires conflict_id")
            status = "acknowledged" if args.session_command == "ack" else "resolved"
            return service.session_conflict_update(args.session_arg, status)
    if args.command == "loop":
        if args.loop_command == "runbook":
            return service.loop_runbook(
                args.task,
                args.loop_paths,
                tests=args.loop_tests,
                result=args.result,
            )
    if args.command == "runtime":
        if args.runtime_command == "ingest":
            if not args.runtime_source:
                raise ValueError("runtime ingest requires source")
            return service.runtime_ingest(args.runtime_source, args.runtime_path)
        if args.runtime_command == "link-errors":
            return service.runtime_link_errors()
        if args.runtime_command == "candidates":
            return service.runtime_candidates()
    if args.command == "org":
        if args.org_command == "connector":
            action = args.org_arg or "list"
            if action == "add":
                if not args.org_arg2:
                    raise ValueError("org connector add requires a connector kind")
                config = {}
                if args.config:
                    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
                return service.org_connector_add(
                    args.org_arg2,
                    config=config,
                    display_name=args.display_name,
                    secret_ref=args.secret_ref,
                    access_scope=args.scope,
                    remote_enabled=args.remote,
                )
            if action == "list":
                return service.org_connectors()
            raise ValueError(f"unknown org connector action: {action}")
        if args.org_command == "ingest":
            if not args.org_arg:
                raise ValueError("org ingest requires a connector kind or id")
            return service.org_ingest(
                args.org_arg,
                since=args.since,
                path=args.path,
                remote=args.remote,
                actor=args.actor,
            )
        if args.org_command == "candidates":
            return service.org_candidates(
                status=args.status,
                source=args.source,
                scope=None if args.scope == "restricted" else args.scope,
                actor=args.actor,
                limit=args.limit,
            )
        if args.org_command == "approve":
            if not args.org_arg:
                raise ValueError("org approve requires candidate_id")
            return service.org_approve(args.org_arg, actor=args.actor, supersede=args.supersede)
        if args.org_command == "reject":
            if not args.org_arg:
                raise ValueError("org reject requires candidate_id")
            return service.org_reject(args.org_arg, actor=args.actor, reason=args.reason)
        if args.org_command == "audit":
            if not args.org_arg:
                raise ValueError("org audit requires candidate_id")
            return service.org_audit(args.org_arg)
    if args.command == "decision":
        if args.decision_command == "start":
            if not args.question:
                raise ValueError("decision start requires --question")
            return service.decision_start(
                args.question,
                options=args.decision_options,
                seed_paths=args.decision_seed_paths,
            )
        if args.decision_command == "analyze":
            if not args.decision_id:
                raise ValueError("decision analyze requires decision_id")
            return service.decision_analyze(args.decision_id)
        if args.decision_command == "record":
            if not args.decision_id:
                raise ValueError("decision record requires decision_id")
            if not args.chosen_option_id:
                raise ValueError("decision record requires --chosen")
            if not args.rationale:
                raise ValueError("decision record requires --rationale")
            return service.decision_record(
                args.decision_id,
                chosen_option_id=args.chosen_option_id,
                rationale=args.rationale,
                actor=args.actor,
            )
        if args.decision_command == "show":
            if not args.decision_id:
                raise ValueError("decision show requires decision_id")
            return service.decision_show(args.decision_id)
        if args.decision_command == "list":
            return service.decision_list(status=args.status, limit=args.limit)
    if args.command == "dashboard":
        if args.dashboard_command == "data":
            return service.dashboard_data()
        if args.dashboard_command == "render":
            return service.dashboard_render(args.output)
    if args.command == "rollup":
        return service.metrics_rollup(
            label=args.label,
            limit=args.limit,
            output=args.output,
        )
    if args.command == "registry":
        if args.registry_command == "register":
            return service.registry_register(label=args.label, action=args.action)
        if args.registry_command == "list":
            return service.registry_list()
        if args.registry_command == "remove":
            return service.registry_remove(args.path)
        if args.registry_command == "prune":
            return service.registry_prune()
    if args.command == "semantic":
        if args.semantic_command == "index":
            return service.semantic_index()
        if args.semantic_command == "search":
            if not args.semantic_arg:
                raise ValueError("semantic search requires a query")
            return service.semantic_search(args.semantic_arg, args.limit)
        if args.semantic_command == "repo-search":
            if not args.semantic_arg:
                raise ValueError("semantic repo-search requires a query")
            return service.search_repo(args.semantic_arg, max_hops=args.max_hops, limit=args.limit)
        if args.semantic_command == "explain":
            if not args.semantic_arg:
                raise ValueError("semantic explain requires a node_id")
            return service.semantic_explain(args.semantic_arg)
        if args.semantic_command == "graph":
            path = args.path or args.semantic_arg
            if not path:
                raise ValueError("semantic graph requires --path or path argument")
            return service.semantic_graph_for_path(path)
        if args.semantic_command == "list":
            return service.semantic_list()
        if args.semantic_command == "stats":
            return service.graph_stats()
        if args.semantic_command == "accuracy-eval":
            return service.semantic_accuracy_eval(args.fixtures)
        if args.semantic_command == "low-confidence":
            return service.semantic_low_confidence(args.threshold)
        if args.semantic_command == "repair":
            action = args.semantic_arg or "list"
            if action == "list":
                return service.semantic_repair_list(status=args.status, limit=args.limit)
            finding_id = args.finding_id
            if not finding_id:
                raise ValueError("semantic repair confirm/reject requires --finding-id")
            if action == "confirm":
                return service.semantic_repair_confirm(finding_id, rationale=args.rationale)
            if action == "reject":
                return service.semantic_repair_reject(finding_id, rationale=args.rationale)
            raise ValueError("semantic repair action must be list, confirm, or reject")
    if args.command == "architecture":
        if args.architecture_command in {"infer", "map"}:
            return service.architecture_infer()
        if args.architecture_command == "explain":
            service_name = args.service or args.architecture_arg
            if not service_name:
                raise ValueError("architecture explain requires --service")
            return service.architecture_explain(service_name)
        if args.architecture_command == "drift":
            result = service.architecture_drift(strict=args.strict)
            if args.strict and result.get("status") == "fail":
                raise SystemExit(json.dumps(result, indent=2, sort_keys=True))
            return result
        if args.architecture_command == "critical-paths":
            return service.architecture_critical_paths()
    if args.command == "behavior":
        diff = sys.stdin.read() if args.diff_from_stdin else None
        return service.behavior_check(
            args.behavior_paths,
            diff=diff,
            pack_id=args.pack_id,
        )
    if args.command == "verify":
        if not args.verify_commands:
            raise ValueError("verify run requires at least one --command")
        return service.verify_run(
            args.verify_commands,
            pack_id=args.pack_id,
            retry_budget=args.retry_budget,
            timeout=args.timeout,
        )
    if args.command == "agent":
        return service.agent_route(
            args.task,
            risk_score=args.risk_score,
            capabilities=args.agent_capabilities,
            remote_review_enabled=args.remote_review,
        )
    if args.command == "codex":
        if args.codex_command == "preflight":
            if not args.task:
                raise ValueError("codex preflight requires --task")
            return service.codex_preflight(args.task, paths=args.codex_paths, mode=args.mode)
        if args.codex_command == "enforcement-status":
            return service.codex_enforcement_status()
        if args.codex_command == "parallel-plan":
            if not args.task_session_id or not args.pack_id:
                raise ValueError("codex parallel-plan requires --task-session-id and --pack-id")
            return service.codex_parallel_plan(
                args.task_session_id,
                args.pack_id,
                paths=args.codex_paths,
            )
        if args.codex_command == "child-start":
            if not args.task_session_id or not args.objective:
                raise ValueError("codex child-start requires --task-session-id and --objective")
            return service.codex_child_start(
                args.task_session_id,
                args.role,
                args.objective,
                write_scope=args.write_scope,
                read_scope=args.read_scope,
                parent_pack_id=args.pack_id,
            )
        if args.codex_command == "child-stop":
            if not args.child_agent_session_id:
                raise ValueError("codex child-stop requires --child-agent-session-id")
            return service.codex_child_stop(
                args.child_agent_session_id,
                args.summary_text,
                changed_files=args.changed_file,
                tests_run=args.test_run,
                blockers=args.blocker,
            )
        if args.codex_command == "child-pack":
            if not args.pack_id:
                raise ValueError("codex child-pack requires --pack-id")
            return service.codex_child_pack(args.pack_id, args.role, scope=args.codex_paths)
        if args.codex_command == "merge-parallel-results":
            if not args.parallel_run_id:
                raise ValueError("codex merge-parallel-results requires --parallel-run-id")
            return service.codex_merge_parallel_results(args.parallel_run_id)
        if args.codex_command == "install-surfaces":
            return service.codex_install_surfaces(
                mcp_command=args.mcp_command,
                install_hooks=args.install_hooks,
                configure_mcp=args.configure_mcp,
                init_git=args.init_git,
                absolute_mcp_repo=args.absolute_mcp_repo,
                codex_config=args.codex_config,
                skip_index=args.skip_index,
            )
        if args.codex_command == "hook":
            if not args.event:
                raise ValueError("codex hook requires --event")
            return service.codex_hook_event(args.event, json.loads(args.payload or "{}"))
    if args.command == "serve":
        from ctxlayer.http import serve

        serve(
            args.workspace,
            host=args.host or service.settings.server.host,
            port=args.port or service.settings.server.port,
            token_env=service.settings.server.token_env,
        )
        return None
    if args.command == "mcp":
        from ctxlayer.server.mcp_server import run_mcp

        run_mcp(service)
        return None
    raise ValueError(f"unknown command: {args.command}")


def _dispatch_npx(args: argparse.Namespace) -> dict[str, Any]:
    if args.npx_command == "doctor":
        return _npx_doctor()
    if args.npx_command == "update":
        return _npx_update(args.source, args.project)
    raise ValueError(f"unknown npx command: {args.npx_command}")


def _load_plan_arg(
    args: argparse.Namespace, *, allow_positional_json: bool = True
) -> dict[str, Any]:
    if args.plan_file:
        return json.loads(Path(args.plan_file).read_text(encoding="utf-8-sig"))
    if args.plan_json:
        return json.loads(args.plan_json)
    if allow_positional_json and args.plan_arg:
        return json.loads(args.plan_arg)
    raise ValueError("plan JSON is required via --file or --json")


def _summary_result(args: argparse.Namespace, result: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(result, dict):
        return result
    ok = result.get("ok")
    summary: dict[str, Any] = {"ok": bool(ok) if ok is not None else True}
    if args.command == "task" and getattr(args, "task_command", None) == "start":
        for key in ("task_session_id", "agent_session_id", "state"):
            if key in result:
                summary[key] = result[key]
        return summary
    if args.command == "pack":
        for key in ("pack_id", "agent_session_id", "snapshot_id", "base_commit_sha", "low_confidence"):
            if key in result:
                summary[key] = result[key]
        summary["item_count"] = len(result.get("items", []) or [])
        summary["seed_paths"] = result.get("seed_paths", [])
        if result.get("warnings"):
            summary["warnings"] = result["warnings"]
        return summary
    if args.command == "impact":
        risk = result.get("risk", {}) if isinstance(result.get("risk"), dict) else {}
        summary.update(
            {
                "risk_score": risk.get("score"),
                "input_path_count": len(result.get("input_paths", []) or []),
                "analyzed_path_count": len(result.get("analyzed_paths", result.get("input_paths", [])) or []),
                "impacted_path_count": len(result.get("impacted_paths", []) or []),
                "test_count": len(result.get("tests", []) or []),
            }
        )
        if result.get("excluded_paths"):
            summary["excluded_paths"] = result["excluded_paths"]
        if result.get("pack_awareness"):
            pack_awareness = result["pack_awareness"]
            summary["pack_id"] = pack_awareness.get("pack_id")
            summary["out_of_pack_paths"] = pack_awareness.get("out_of_pack_paths", [])
        if result.get("business_exposure"):
            exposure = result["business_exposure"]
            summary["business_exposure"] = {
                "lowest_trust_tier": exposure.get("lowest_trust_tier"),
                "exposure_summary": exposure.get("exposure_summary", {}),
                "authoritative": exposure.get("authoritative"),
                "requires_human_review": exposure.get("requires_human_review"),
            }
        return summary
    if args.command == "check-diff":
        report = result.get("impact_report", {}) if isinstance(result.get("impact_report"), dict) else {}
        risk = report.get("risk", {}) if isinstance(report.get("risk"), dict) else {}
        violations = result.get("violations", []) or []
        summary.update(
            {
                "pack_id": getattr(args, "pack_id", None),
                "violation_count": len(violations),
                "violations": violations[:10],
                "risk_score": risk.get("score"),
            }
        )
        if report.get("excluded_paths"):
            summary["excluded_paths"] = report["excluded_paths"]
        return summary
    if args.command == "plan":
        for key in (
            "plan_id",
            "task_session_id",
            "revision_id",
            "revision_number",
            "plan_hash",
            "previous_plan_hash",
            "checkpoint_id",
            "status",
            "step_id",
            "agent_session_id",
        ):
            if key in result:
                summary[key] = result[key]
        validation = result.get("validation", {}) if isinstance(result.get("validation"), dict) else {}
        if validation:
            summary["schema_error_count"] = len(validation.get("schema_errors", []) or [])
            summary["warning_count"] = len(validation.get("warnings", []) or [])
        if result.get("violations"):
            summary["violations"] = result["violations"][:10]
        return summary
    return result


def _fast_task_start(repo: Path, task: str) -> dict[str, Any]:
    repo_root = repo.resolve()
    settings = load_settings(repo_root)
    workspace_dir = repo_root / settings.toolchain.workspace_dir
    workspace_dir.mkdir(parents=True, exist_ok=True)
    store = SQLiteStore(workspace_dir / "workspace.db")
    try:
        store.migrate()
        repo_id = _latest_repo_id(store)
        workspace_id = stable_id(str(repo_root))[:16]
        result = TaskGovernance(
            repo_root,
            store,
            settings,
            workspace_id=workspace_id,
            repo_id=repo_id,
        ).start(task=task, constitution_hash=None, metadata={"source": "fast_task_start"})
        session = AgentSessionMemory(store, workspace_id=workspace_id, repo_id=repo_id).ensure(
            task=task,
            metadata={
                "task_session_id": result["task_session_id"],
                "constitution_hash": result["constitution_hash"],
                "source": "fast_task_start",
            },
        )
        AgentSessionMemory(store, workspace_id=workspace_id, repo_id=repo_id).event(
            session_id=session["session_id"],
            event_type="task_session",
            payload={
                "task_session_id": result["task_session_id"],
                "state": result["state"],
                "constitution_hash": result["constitution_hash"],
            },
        )
        result["agent_session_id"] = session["session_id"]
        result["mode"] = "fast"
        return result
    finally:
        store.close()


def _latest_repo_id(store: SQLiteStore) -> str | None:
    row = store.conn.execute(
        "SELECT repo_id FROM snapshots ORDER BY created_at DESC, snapshot_id DESC LIMIT 1"
    ).fetchone()
    return row["repo_id"] if row else None


def _agent_gate_thresholds(args: argparse.Namespace) -> dict[str, float | int]:
    return {
        "min_cases": args.min_cases,
        "min_success_rate_delta": args.min_success_rate_delta,
        "min_tests_pass_rate_delta": args.min_tests_pass_rate_delta,
        "min_wrong_files_touched_reduction": args.min_wrong_files_reduction,
        "min_missing_files_reduction": args.min_missing_files_reduction,
        "min_ctxlayer_success_rate": args.min_ctxlayer_success_rate,
    }


def _npx_doctor() -> dict[str, Any]:
    package_root = Path(__file__).resolve().parents[2]
    return {
        "ok": True,
        "python_cli": True,
        "package_root": str(package_root),
        "npm_update_command": 'ctxlayer npx update --source "<path-to-ctxlayer-repo>"',
    }


def _npx_update(source: str | None, project: bool) -> dict[str, Any]:
    package_root = Path(__file__).resolve().parents[2]
    source_path = source or str(package_root)
    npm = "npm.cmd" if sys.platform == "win32" else "npm"
    args = [npm, "install", "--save-dev" if project else "-g", source_path]
    result = subprocess.run(args, text=True)
    return {
        "ok": result.returncode == 0,
        "command": args,
        "source": source_path,
        "mode": "project" if project else "global",
        "returncode": result.returncode,
    }


def _normalize_global_args(argv: list[str]) -> list[str]:
    if "--repo" not in argv:
        return argv
    if len(argv) >= 3 and argv[0] == "eval" and argv[1] == "harvest":
        return argv
    if len(argv) >= 2 and argv[0] == "workspace" and argv[1] == "impact":
        return argv
    idx = argv.index("--repo")
    if idx == 0 or idx + 1 >= len(argv):
        return argv
    repo_pair = argv[idx : idx + 2]
    rest = argv[:idx] + argv[idx + 2 :]
    return [*repo_pair, *rest]
