from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from ctxlayer.config import Settings
from ctxlayer.learning.provider import AgentProvider
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import canonical_json, estimate_tokens


PARAM_PATCH_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["target", "parameters", "rationale"],
    "properties": {
        "target": {"type": "string"},
        "parameters": {"type": "object"},
        "rationale": {"type": "string"},
    },
    "additionalProperties": False,
}

TARGET_KEYS: dict[str, dict[str, tuple[float, float, str]]] = {
    "pack_weights": {
        "lexical_weight": (0.0, 3.0, "float"),
        "vector_weight": (0.0, 3.0, "float"),
        "graph_weight": (0.0, 3.0, "float"),
        "history_weight": (0.0, 3.0, "float"),
    },
    "pack_quotas": {
        "implementation_quota": (0.0, 1.0, "float"),
        "test_quota": (0.0, 1.0, "float"),
        "constraint_quota": (0.0, 1.0, "float"),
        "default_budget_tokens": (1000, 100000, "int"),
        "max_file_tokens": (500, 50000, "int"),
    },
    "skills": {
        "inject_top_k": (0, 10, "int"),
    },
    "impact_risk": {
        "changed_files_weight": (0.0, 10.0, "float"),
        "impacted_files_weight": (0.0, 10.0, "float"),
        "untested_files_weight": (0.0, 10.0, "float"),
        "low_confidence_edges_weight": (0.0, 10.0, "float"),
        "critical_paths_weight": (0.0, 10.0, "float"),
        "graph_centrality_weight": (0.0, 10.0, "float"),
        "changed_file_budget": (1, 25, "int"),
    },
    "rerank": {
        "outcome_boost": (0.0, 0.5, "float"),
        "memory_boost": (0.0, 0.5, "float"),
    },
}
TEXT_TARGET_KEYS: dict[str, dict[str, int]] = {
    "textual_artifacts": {
        "optimizer_prompt_instruction": 1200,
        "pack_template_instruction": 1200,
    }
}
PROTECTED_PREFIXES = (
    "audit.",
    "ci.",
    "security.",
    "eval.",
    "governance.",
    "constitution.",
)
PROTECTED_TEXT_PHRASES = (
    "bypass audit",
    "disable audit",
    "bypass gate",
    "disable gate",
    "skip tests",
    "ignore security",
    "disable security",
)

MetricEvaluator = Callable[[str, dict[str, Any], str], dict[str, Any]]


@dataclass(frozen=True)
class OptimizerCandidate:
    target: str
    parameters: dict[str, Any]
    rationale: str
    source: str


class ReflectiveOptimizer:
    def __init__(
        self,
        *,
        store: SQLiteStore,
        settings: Settings,
        provider: AgentProvider | None = None,
        evaluator: MetricEvaluator | None = None,
        model_family: str | None = None,
        budget_tokens: int | None = None,
        side_information: dict[str, Any] | None = None,
    ):
        self.store = store
        self.settings = settings
        self.provider = provider
        self.evaluator = evaluator or default_evaluator
        self.model_family = model_family
        self.budget_tokens = budget_tokens
        self.side_information = side_information or {}

    def optimize(
        self,
        *,
        target: str,
        iterations: int = 1,
        adopt: bool = False,
    ) -> dict[str, Any]:
        target = target.strip()
        before = current_parameters(self.settings, target)
        train_before = self.evaluator(target, before, "train")
        holdout_before = self.evaluator(target, before, "holdout")
        # Sealed oracle: the holdout split is the gate, so it must not be visible during the
        # search that proposes candidates — otherwise the optimizer can fit to its own gate
        # ("equilibrium under finite evaluation", arXiv:2603.28063). When sealed, candidate
        # generation only sees train metrics; holdout is consulted solely at gating time.
        sealed = bool(self.settings.learning.optimize.sealed_oracle)
        search_holdout = None if sealed else holdout_before
        candidates = self._candidates(
            target=target,
            before=before,
            train_before=train_before,
            holdout_before=search_holdout,
            iterations=iterations,
        )
        archive: list[dict[str, Any]] = []
        for candidate in candidates:
            train_after = self.evaluator(candidate.target, candidate.parameters, "train")
            holdout_after = self.evaluator(candidate.target, candidate.parameters, "holdout")
            gate = holdout_gate(
                before=holdout_before,
                after=holdout_after,
                holdout_required=self.settings.learning.optimize.holdout_required,
            )
            run_id = self.store.write_learning_run(
                target=target,
                kind="optimizer_variant",
                before=before,
                after={
                    "parameters": candidate.parameters,
                    "rationale": candidate.rationale,
                    "source": candidate.source,
                },
                train_metrics={
                    "before": train_before,
                    "after": train_after,
                    "delta": metric_delta(train_before, train_after),
                },
                holdout_metrics={
                    "before": holdout_before,
                    "after": holdout_after,
                    "delta": metric_delta(holdout_before, holdout_after),
                    "gate": gate,
                },
                gate_pass=gate["pass"],
                archived=True,
                promoted=False,
            )
            archive.append(
                {
                    "run_id": run_id,
                    "target": target,
                    "parameters": candidate.parameters,
                    "source": candidate.source,
                    "rationale": candidate.rationale,
                    "train_metrics": train_after,
                    "holdout_metrics": holdout_after,
                    "gate": gate,
                }
            )
            self._event(
                "optimizer_variant",
                run_id,
                {
                    "target": target,
                    "source": candidate.source,
                    "gate_pass": gate["pass"],
                    "holdout_delta": metric_delta(holdout_before, holdout_after),
                },
            )
        archive.sort(key=lambda item: _pareto_key(item["holdout_metrics"], item["train_metrics"]))
        best = archive[0] if archive else None
        adopted = None
        if adopt and best and best["gate"]["pass"]:
            adopted = self.adopt(best["run_id"])
        return {
            "ok": True,
            "target": target,
            "before": before,
            "train_before": train_before,
            "holdout_before": holdout_before,
            "archive": archive,
            "best": best,
            "adopted": adopted,
        }

    def adopt(self, run_id: str) -> dict[str, Any]:
        row = self.store.learning_run(run_id)
        if row is None:
            raise KeyError(f"learning run not found: {run_id}")
        if not bool(row["gate_pass"]):
            raise ValueError("cannot adopt optimizer run that failed holdout gate")
        target = row["target"]
        after = parse_run_json(row["after_json"])
        parameters = after.get("parameters", after)
        validate_parameters(target, parameters)
        self.store.promote_learning_run(run_id)
        apply_parameters(self.settings, target, parameters)
        self._event("optimizer_adopted", run_id, {"target": target, "parameters": parameters})
        return {"ok": True, "run_id": run_id, "target": target, "parameters": parameters}

    def revert(self, run_id: str) -> dict[str, Any]:
        row = self.store.learning_run(run_id)
        if row is None:
            raise KeyError(f"learning run not found: {run_id}")
        target = row["target"]
        before = parse_run_json(row["before_json"])
        validate_parameters(target, before)
        self.store.unpromote_learning_run(run_id)
        apply_parameters(self.settings, target, before)
        self._event("optimizer_reverted", run_id, {"target": target, "parameters": before})
        return {"ok": True, "run_id": run_id, "target": target, "parameters": before}

    def _candidates(
        self,
        *,
        target: str,
        before: dict[str, Any],
        train_before: dict[str, Any],
        holdout_before: dict[str, Any] | None,
        iterations: int,
    ) -> list[OptimizerCandidate]:
        candidates = deterministic_candidates(target, before)
        if self.provider is not None:
            prompt = optimizer_prompt(
                target=target,
                before=before,
                train_metrics=train_before,
                holdout_metrics=holdout_before,
                side_information=self.side_information,
                configured_instruction=(
                    self.settings.learning.optimize.optimizer_prompt_instruction
                ),
            )
            max_calls = max(0, iterations)
            used_tokens = 0
            for _ in range(max_calls):
                if self.budget_tokens is not None and used_tokens >= self.budget_tokens:
                    break
                used_tokens += estimate_tokens(prompt)
                raw = self.provider.complete(
                    prompt=prompt,
                    role="optimizer",
                    schema=PARAM_PATCH_SCHEMA,
                    model_family=self.model_family,
                    budget_tokens=self.budget_tokens,
                )
                if raw is None:
                    continue
                normalized = normalize_patch(raw)
                if not normalized["ok"]:
                    self._event("optimizer_patch_rejected", target, normalized)
                    continue
                if normalized["target"] != target:
                    self._event(
                        "optimizer_patch_rejected",
                        target,
                        {"ok": False, "reason": "target_mismatch", "patch_target": normalized["target"]},
                    )
                    continue
                candidates.append(
                    OptimizerCandidate(
                        target=target,
                        parameters=normalized["parameters"],
                        rationale=normalized["rationale"],
                        source="agent",
                    )
                )
        unique: dict[str, OptimizerCandidate] = {}
        for candidate in candidates:
            unique[canonical_json(candidate.parameters)] = candidate
        return list(unique.values())

    def _event(self, kind: str, ref: str | None, payload: dict[str, Any]) -> None:
        self.store.write_learning_event(phase="phase4", kind=kind, ref=ref, payload=payload)


def current_parameters(settings: Settings, target: str) -> dict[str, Any]:
    if target == "pack_weights":
        return {
            "lexical_weight": settings.retrieval.lexical_weight,
            "vector_weight": settings.retrieval.vector_weight,
            "graph_weight": settings.retrieval.graph_weight,
            "history_weight": settings.retrieval.history_weight,
        }
    if target == "pack_quotas":
        return {
            "implementation_quota": settings.pack.implementation_quota,
            "test_quota": settings.pack.test_quota,
            "constraint_quota": settings.pack.constraint_quota,
            "default_budget_tokens": settings.pack.default_budget_tokens,
            "max_file_tokens": settings.pack.max_file_tokens,
        }
    if target == "skills":
        return {"inject_top_k": settings.learning.skills.inject_top_k}
    if target == "impact_risk":
        optimize = settings.learning.optimize
        return {
            "changed_files_weight": optimize.impact_changed_files_weight,
            "impacted_files_weight": optimize.impact_impacted_files_weight,
            "untested_files_weight": optimize.impact_untested_files_weight,
            "low_confidence_edges_weight": optimize.impact_low_confidence_edges_weight,
            "critical_paths_weight": optimize.impact_critical_paths_weight,
            "graph_centrality_weight": optimize.impact_graph_centrality_weight,
            "changed_file_budget": optimize.impact_changed_file_budget,
        }
    if target == "rerank":
        return {
            "outcome_boost": settings.learning.rerank.outcome_boost,
            "memory_boost": settings.learning.rerank.memory_boost,
        }
    if target == "textual_artifacts":
        return {
            "optimizer_prompt_instruction": settings.learning.optimize.optimizer_prompt_instruction,
            "pack_template_instruction": settings.learning.optimize.pack_template_instruction,
        }
    raise ValueError(f"unsupported optimization target: {target}")


def deterministic_candidates(target: str, before: dict[str, Any]) -> list[OptimizerCandidate]:
    validate_parameters(target, before)
    candidates: list[OptimizerCandidate] = []
    if target == "pack_weights":
        for key, factor in [
            ("graph_weight", 1.15),
            ("history_weight", 1.2),
            ("vector_weight", 1.1),
            ("lexical_weight", 1.1),
        ]:
            params = dict(before)
            params[key] = round(float(params[key]) * factor, 4)
            candidates.append(
                OptimizerCandidate(
                    target=target,
                    parameters=validate_parameters(target, params),
                    rationale=f"Increase {key} based on optimization search.",
                    source="deterministic",
                )
            )
    elif target == "pack_quotas":
        for key, delta in [
            ("implementation_quota", 0.05),
            ("test_quota", 0.05),
            ("constraint_quota", 0.02),
        ]:
            params = dict(before)
            params[key] = round(min(1.0, float(params[key]) + delta), 4)
            _rebalance_quotas(params, preferred=key)
            candidates.append(
                OptimizerCandidate(
                    target=target,
                    parameters=validate_parameters(target, params),
                    rationale=f"Shift quota toward {key}.",
                    source="deterministic",
                )
            )
    elif target == "skills":
        params = dict(before)
        params["inject_top_k"] = min(10, int(params["inject_top_k"]) + 1)
        candidates.append(
            OptimizerCandidate(
                target=target,
                parameters=validate_parameters(target, params),
                rationale="Try one additional validated skill in the pack.",
                source="deterministic",
            )
        )
    elif target == "impact_risk":
        for key, factor in [
            ("untested_files_weight", 1.1),
            ("critical_paths_weight", 1.1),
            ("graph_centrality_weight", 1.1),
        ]:
            params = dict(before)
            params[key] = round(float(params[key]) * factor, 4)
            candidates.append(
                OptimizerCandidate(
                    target=target,
                    parameters=validate_parameters(target, params),
                    rationale=f"Increase {key} sensitivity for impact risk scoring.",
                    source="deterministic",
                )
            )
        params = dict(before)
        params["changed_file_budget"] = min(25, int(params["changed_file_budget"]) + 1)
        candidates.append(
            OptimizerCandidate(
                target=target,
                parameters=validate_parameters(target, params),
                rationale="Relax changed-file breadth sensitivity by one file.",
                source="deterministic",
            )
        )
    elif target == "rerank":
        for key in ["outcome_boost", "memory_boost"]:
            params = dict(before)
            params[key] = round(min(0.5, float(params[key]) + 0.01), 4)
            candidates.append(
                OptimizerCandidate(
                    target=target,
                    parameters=validate_parameters(target, params),
                    rationale=f"Increase bounded {key} within the existing candidate set.",
                    source="deterministic",
                )
            )
    elif target == "textual_artifacts":
        params = dict(before)
        params[
            "optimizer_prompt_instruction"
        ] = "Use benchmark failure traces, lift attribution, and roadmap pruning before proposing patches."
        if not params.get("pack_template_instruction"):
            params[
                "pack_template_instruction"
            ] = "Prefer context that explains why selected files address observed holdout failures."
        candidates.append(
            OptimizerCandidate(
                target=target,
                parameters=validate_parameters(target, params),
                rationale="Seed textual guidance from the measured benchmark loop.",
                source="deterministic",
            )
        )
    return candidates


def _rebalance_quotas(params: dict[str, Any], *, preferred: str) -> None:
    quota_keys = ["implementation_quota", "test_quota", "constraint_quota"]
    total = sum(float(params[key]) for key in quota_keys)
    if total <= 1.0:
        return
    excess = total - 1.0
    for key in quota_keys:
        if key == preferred:
            continue
        available = max(0.0, float(params[key]))
        reduction = min(available, excess)
        params[key] = round(available - reduction, 4)
        excess = round(excess - reduction, 4)
        if excess <= 0:
            break


def normalize_patch(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, dict):
        return {"ok": False, "reason": "non_object"}
    target = str(raw.get("target") or "").strip()
    params = raw.get("parameters")
    rationale = str(raw.get("rationale") or "").strip()
    if not target or not isinstance(params, dict) or not rationale:
        return {"ok": False, "reason": "missing_required_fields"}
    try:
        normalized = validate_parameters(target, params)
    except ValueError as exc:
        return {"ok": False, "target": target, "reason": str(exc)}
    return {"ok": True, "target": target, "parameters": normalized, "rationale": rationale}


def validate_parameters(target: str, params: dict[str, Any]) -> dict[str, Any]:
    if any(key.startswith(PROTECTED_PREFIXES) for key in params):
        raise ValueError("protected_key")
    allowed = TARGET_KEYS.get(target)
    text_allowed = TEXT_TARGET_KEYS.get(target)
    if allowed is None and text_allowed is None:
        raise ValueError("unsupported_target")
    allowed_keys = set(allowed or text_allowed or {})
    unknown = sorted(set(params) - allowed_keys)
    if unknown:
        raise ValueError(f"disallowed_keys: {', '.join(unknown)}")
    normalized: dict[str, Any] = {}
    if text_allowed is not None:
        for key, value in params.items():
            if not isinstance(value, str):
                raise ValueError(f"invalid_value: {key}")
            text = " ".join(value.strip().split())
            if len(text) > text_allowed[key]:
                raise ValueError(f"text_too_long: {key}")
            lowered = text.lower()
            if any(phrase in lowered for phrase in PROTECTED_TEXT_PHRASES):
                raise ValueError(f"protected_text: {key}")
            normalized[key] = text
        return normalized
    assert allowed is not None
    for key, value in params.items():
        minimum, maximum, kind = allowed[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f"invalid_value: {key}")
        numeric = float(value)
        if numeric < minimum or numeric > maximum:
            raise ValueError(f"out_of_range: {key}")
        normalized[key] = int(numeric) if kind == "int" else round(numeric, 6)
    if target == "pack_quotas":
        quota_sum = sum(
            float(normalized.get(key, 0.0))
            for key in ["implementation_quota", "test_quota", "constraint_quota"]
        )
        if quota_sum > 1.0:
            raise ValueError("quota_sum_exceeds_one")
    return normalized


def apply_parameters(settings: Settings, target: str, params: dict[str, Any]) -> None:
    normalized = validate_parameters(target, params)
    if target == "pack_weights":
        for key, value in normalized.items():
            object.__setattr__(settings.retrieval, key, value)
    elif target == "pack_quotas":
        for key, value in normalized.items():
            object.__setattr__(settings.pack, key, value)
    elif target == "skills":
        for key, value in normalized.items():
            object.__setattr__(settings.learning.skills, key, value)
    elif target == "impact_risk":
        mapping = {
            "changed_files_weight": "impact_changed_files_weight",
            "impacted_files_weight": "impact_impacted_files_weight",
            "untested_files_weight": "impact_untested_files_weight",
            "low_confidence_edges_weight": "impact_low_confidence_edges_weight",
            "critical_paths_weight": "impact_critical_paths_weight",
            "graph_centrality_weight": "impact_graph_centrality_weight",
            "changed_file_budget": "impact_changed_file_budget",
        }
        for key, value in normalized.items():
            object.__setattr__(settings.learning.optimize, mapping[key], value)
    elif target == "rerank":
        for key, value in normalized.items():
            object.__setattr__(settings.learning.rerank, key, value)
    elif target == "textual_artifacts":
        for key, value in normalized.items():
            object.__setattr__(settings.learning.optimize, key, value)


def holdout_gate(
    *,
    before: dict[str, Any],
    after: dict[str, Any],
    holdout_required: bool = True,
) -> dict[str, Any]:
    deltas = metric_delta(before, after)
    if not holdout_required:
        return {"pass": True, "reason": "holdout_not_required", "delta": deltas}
    success_ok = deltas.get("success_rate", 0.0) >= 0.0
    recall_ok = deltas.get("recall_at_pack", 0.0) >= 0.0
    missing_ok = deltas.get("missing_files", 0.0) <= 0.0
    drift_ok = deltas.get("scope_drift", 0.0) <= 0.0
    passed = success_ok and recall_ok and missing_ok and drift_ok
    return {
        "pass": passed,
        "reason": "holdout_improved_or_equal" if passed else "holdout_regression",
        "delta": deltas,
    }


def metric_delta(before: dict[str, Any], after: dict[str, Any]) -> dict[str, float]:
    keys = set(before) | set(after)
    result: dict[str, float] = {}
    for key in keys:
        left = before.get(key)
        right = after.get(key)
        if isinstance(left, (int, float)) and isinstance(right, (int, float)):
            result[key] = round(float(right) - float(left), 6)
    return dict(sorted(result.items()))


def default_evaluator(target: str, params: dict[str, Any], split: str) -> dict[str, Any]:
    _ = target, split
    magnitude = sum(float(value) for value in params.values() if isinstance(value, (int, float)))
    return {
        "count": 0,
        "success_rate": round(min(1.0, magnitude / 10.0), 4),
        "recall_at_pack": round(min(1.0, magnitude / 10.0), 4),
        "missing_files": 0.0,
        "scope_drift": 0.0,
    }


def optimizer_prompt(
    *,
    target: str,
    before: dict[str, Any],
    train_metrics: dict[str, Any],
    holdout_metrics: dict[str, Any] | None,
    side_information: dict[str, Any] | None = None,
    configured_instruction: str = "",
) -> str:
    allowed_keys = sorted({*TARGET_KEYS.get(target, {}), *TEXT_TARGET_KEYS.get(target, {})})
    lines = [
        "Propose one allow-listed CTX Layer optimization parameter patch.",
        "Use a reflective GEPA-style critique: inspect failure traces, lift attribution, and pruning advice before changing anything.",
        "For textual_artifacts, tune only the allowed guidance text; do not rewrite policy, audits, gates, or source files.",
        "Return strict JSON only. Do not modify audit, gates, security, CI, or evaluation logic.",
    ]
    if holdout_metrics is None:
        lines.append(
            "The holdout split is a sealed oracle: it is hidden during search and used only "
            "to gate promotion. Optimize for genuine improvement on train, not the gate."
        )
    if configured_instruction.strip():
        lines.append(f"Adopted optimizer guidance: {configured_instruction.strip()}")
    lines.append(
        canonical_json(
            {
                "target": target,
                "allowed_keys": allowed_keys,
                "before": before,
                "train_metrics": train_metrics,
                "holdout_metrics": "sealed" if holdout_metrics is None else holdout_metrics,
                "side_information": side_information or {},
            }
        )
    )
    return "\n".join(lines)


def parse_run_json(value: str) -> dict[str, Any]:
    import json

    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def archive_rows(rows: list[Any]) -> list[dict[str, Any]]:
    return [_run_dict(row) for row in rows]


def _run_dict(row: Any) -> dict[str, Any]:
    return {
        "run_id": row["run_id"],
        "target": row["target"],
        "kind": row["kind"],
        "before": parse_run_json(row["before_json"]),
        "after": parse_run_json(row["after_json"]),
        "train_metrics": parse_run_json(row["train_metrics_json"]),
        "holdout_metrics": parse_run_json(row["holdout_metrics_json"]),
        "gate_pass": bool(row["gate_pass"]),
        "archived": bool(row["archived"]),
        "promoted": bool(row["promoted"]),
        "created_at": row["created_at"],
    }


def _pareto_key(holdout: dict[str, Any], train: dict[str, Any]) -> tuple[float, float, float, float]:
    return (
        -float(holdout.get("success_rate", holdout.get("recall_at_pack", 0.0)) or 0.0),
        -float(holdout.get("recall_at_pack", 0.0) or 0.0),
        float(holdout.get("missing_files", 0.0) or 0.0),
        -float(train.get("recall_at_pack", 0.0) or 0.0),
    )
