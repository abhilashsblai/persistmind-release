from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any

from ctxlayer.memory.unified import UnifiedMemory
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import stable_id, utc_now

PASS_RESULTS = {"pass", "passed", "ok", "success"}


class EpisodicMemory:
    def __init__(
        self,
        store: SQLiteStore,
        *,
        workspace_id: str,
        repo_id: str | None,
        memory: UnifiedMemory | None = None,
        repo_root: Path | None = None,
    ):
        self.store = store
        self.workspace_id = workspace_id
        self.repo_id = repo_id
        self.repo_root = repo_root
        self.memory = memory or UnifiedMemory(store, workspace_id=workspace_id, repo_id=repo_id)

    def upsert_for_agent_session(
        self,
        session_id: str,
        *,
        trigger: str,
        result: str | None = None,
        outcome_id: str | None = None,
        pack_id: str | None = None,
        summary: str | None = None,
        require_useful_evidence: bool = False,
    ) -> dict[str, Any]:
        session = self.store.agent_session(session_id)
        if not session:
            return {"ok": False, "error": "session not found", "session_id": session_id}

        episode = self._build_episode(
            session,
            trigger=trigger,
            result=result,
            outcome_id=outcome_id,
            pack_id=pack_id,
            summary=summary,
        )
        if require_useful_evidence and not _has_useful_evidence(episode):
            return {
                "ok": False,
                "skipped": True,
                "reason": "insufficient_episode_evidence",
                "session_id": session_id,
            }
        record_id = episode_record_id(self.workspace_id, self.repo_id, session_id)
        payload = {
            "type": "episode",
            "record_id": record_id,
            "title": episode["title"],
            "assertion": _episode_assertion(episode),
            "scope": f"repo:{self.repo_id}" if self.repo_id else "workspace",
            "source_kind": f"episode:{trigger}",
            "confidence": 0.95 if episode.get("outcome_id") else 0.8,
            "importance": _importance(episode),
            "status": "active",
            "trust": "active",
            "metadata": episode,
            "provenance": {
                "generator": "ctxlayer:episodic",
                "validator": "agent_session_events",
                "session_id": session_id,
                "task_session_id": episode.get("task_session_id"),
                "outcome_id": episode.get("outcome_id"),
                "pack_id": episode.get("pack_id"),
                "updated_by_event": trigger,
            },
            "evidence": _evidence(episode),
        }
        existing = self.store.memory_record(record_id)
        if existing:
            updated = self.memory.update(
                record_id,
                {
                    "title": payload["title"],
                    "assertion": payload["assertion"],
                    "status": payload["status"],
                    "trust": payload["trust"],
                    "importance": payload["importance"],
                    "source_kind": payload["source_kind"],
                    "metadata": payload["metadata"],
                    "provenance": payload["provenance"],
                },
                actor="episodic",
                reason=trigger,
            )
            return {"ok": True, "episode": updated["record"], "updated": True}
        created = self.memory.create_typed(payload)
        return {"ok": True, "episode": created["record"], "updated": False}

    def _build_episode(
        self,
        session: Any,
        *,
        trigger: str,
        result: str | None,
        outcome_id: str | None,
        pack_id: str | None,
        summary: str | None,
    ) -> dict[str, Any]:
        session_id = str(session["session_id"])
        events = [_decode_event(row) for row in self.store.agent_session_events(session_id)]
        artifacts = [
            _decode_artifact(row) for row in self.store.agent_session_artifacts(session_id)
        ]
        outcome_payload = _latest_event_payload(events, "outcome", "outcome_id", outcome_id)
        summary_payload = _latest_event_payload(events, "summary", "outcome_id", outcome_id)

        task_session_id = _artifact_ref(artifacts, "task_session") or _event_value(
            events, "task_session_id"
        )
        task = self.store.task_session(task_session_id) if task_session_id else None
        task_metadata = _json(task["metadata_json"]) if task else {}
        session_metadata = _json(session["metadata_json"])
        objective = (
            task_metadata.get("objective")
            or task_metadata.get("task")
            or session_metadata.get("task")
            or f"Session {session_id}"
        )

        effective_pack_id = (
            pack_id or outcome_payload.get("pack_id") or _artifact_ref(artifacts, "pack_served")
        )
        manifest = _pack_manifest(self.store, effective_pack_id)
        plan = self.store.latest_task_plan_for_session(task_session_id) if task_session_id else None
        plan_id = str(plan["plan_id"]) if plan else _artifact_ref(artifacts, "plan_created")
        plan_payload = _latest_plan_payload(self.store, plan_id)
        checkpoints = _checkpoint_summaries(self.store, plan_id)
        verifications = _verification_summaries(
            self.store, task_session_id=task_session_id, plan_id=plan_id
        )
        outcome_result = (
            result
            or outcome_payload.get("result")
            or (session["status"] if session["status"] != "active" else None)
            or "unknown"
        )
        files_changed = _string_list(outcome_payload.get("files_changed"))
        if not files_changed:
            files_changed = sorted(
                {path for checkpoint in checkpoints for path in checkpoint.get("changed_paths", [])}
            )
        summary_text = summary or summary_payload.get("summary")
        files_read = _event_paths(events, "file_read") | _artifact_refs(artifacts, "file_read")
        files_edited = _event_paths(events, "file_edited") | _artifact_refs(
            artifacts, "file_edited"
        )
        affected_paths = sorted(
            set(files_changed)
            | files_read
            | files_edited
            | set(_step_values(plan_payload, "intended_files"))
        )
        created_at = utc_now()
        episode = {
            "episode_schema_version": "ctxlayer.episode.v1",
            "episode_id": episode_record_id(self.workspace_id, self.repo_id, session_id),
            "session_id": session_id,
            "agent_name": session["agent_name"],
            "workspace_id": self.workspace_id,
            "repo_id": self.repo_id,
            "task_session_id": task_session_id,
            "task_text_hash": session["task_text_hash"],
            "objective": str(objective),
            "title": _title(str(objective), outcome_result),
            "result": str(outcome_result),
            "trigger": trigger,
            "pack_id": effective_pack_id,
            "outcome_id": outcome_id or outcome_payload.get("outcome_id"),
            "plan_id": plan_id,
            "base_snapshot_id": manifest.get("snapshot_id"),
            "base_commit_sha": manifest.get("base_commit_sha"),
            "worktree_state": manifest.get("worktree_state"),
            "files_changed": files_changed,
            "files_read": sorted(files_read),
            "files_edited": sorted(files_edited),
            "affected_paths": affected_paths,
            "intended_files": sorted(set(_step_values(plan_payload, "intended_files"))),
            "tests_planned": sorted(set(_step_values(plan_payload, "intended_tests"))),
            "checkpoints": checkpoints,
            "verifications": verifications,
            "summary": _trim(summary_text, 1_200) if summary_text else None,
            "lesson": _lesson(summary_text, outcome_result, files_changed),
            "future_use": _future_use(str(objective), affected_paths, outcome_result),
            "event_counts": dict(Counter(event["event_type"] for event in events)),
            "artifact_refs": [
                {"type": item["artifact_type"], "ref": item["ref"]} for item in artifacts
            ],
            "quality_signals": {
                "has_outcome": bool(outcome_id or outcome_payload.get("outcome_id")),
                "has_pack": bool(effective_pack_id),
                "has_summary": bool(summary_text),
                "has_changed_paths": bool(files_changed),
                "has_verifications": bool(verifications),
            },
            "created_at": created_at,
            "updated_at": created_at,
        }
        return episode


def episode_record_id(workspace_id: str, repo_id: str | None, session_id: str) -> str:
    return stable_id("episode", workspace_id, repo_id or "", session_id)


def _episode_assertion(episode: dict[str, Any]) -> str:
    parts = [
        f"Episode for {episode['objective']}.",
        f"Result: {episode['result']}.",
    ]
    if episode.get("files_changed"):
        parts.append("Changed files: " + ", ".join(episode["files_changed"][:6]) + ".")
    if episode.get("summary"):
        parts.append("Summary: " + _trim(str(episode["summary"]), 500))
    else:
        parts.append(str(episode["lesson"]))
    return " ".join(parts)


def _importance(episode: dict[str, Any]) -> float:
    result = str(episode.get("result") or "").lower()
    if result in PASS_RESULTS:
        return 0.9
    if result and result != "unknown":
        return 0.8
    return 0.6


def _has_useful_evidence(episode: dict[str, Any]) -> bool:
    return any(
        [
            episode.get("task_session_id"),
            episode.get("pack_id"),
            episode.get("outcome_id"),
            episode.get("summary"),
            episode.get("files_changed"),
            episode.get("files_edited"),
            episode.get("checkpoints"),
            episode.get("verifications"),
        ]
    )


def _evidence(episode: dict[str, Any]) -> list[dict[str, Any]]:
    refs = [
        ("agent_session", episode.get("session_id")),
        ("task_session", episode.get("task_session_id")),
        ("pack", episode.get("pack_id")),
        ("plan", episode.get("plan_id")),
        ("outcome", episode.get("outcome_id")),
    ]
    evidence = [
        {
            "evidence_kind": kind,
            "evidence_hash": stable_id(kind, ref),
            "source_ref": str(ref),
            "metadata": {"episode_id": episode["episode_id"]},
        }
        for kind, ref in refs
        if ref
    ]
    for path in episode.get("files_changed", [])[:20]:
        evidence.append(
            {
                "path": path,
                "evidence_kind": "changed_path",
                "evidence_hash": stable_id("changed_path", episode["session_id"], path),
                "source_ref": episode["session_id"],
                "metadata": {"episode_id": episode["episode_id"]},
            }
        )
    return evidence


def _decode_event(row: Any) -> dict[str, Any]:
    return {**dict(row), "payload": _json(row["payload_json"])}


def _decode_artifact(row: Any) -> dict[str, Any]:
    return {**dict(row), "metadata": _json(row["metadata_json"])}


def _latest_event_payload(
    events: list[dict[str, Any]], event_type: str, key: str, value: str | None
) -> dict[str, Any]:
    candidates = [event for event in events if event["event_type"] == event_type]
    if value:
        for event in reversed(candidates):
            if str(event["payload"].get(key) or "") == str(value):
                return dict(event["payload"])
    if candidates:
        return dict(candidates[-1]["payload"])
    return {}


def _event_value(events: list[dict[str, Any]], key: str) -> str | None:
    for event in reversed(events):
        value = event.get("payload", {}).get(key)
        if value:
            return str(value)
    return None


def _artifact_ref(artifacts: list[dict[str, Any]], artifact_type: str) -> str | None:
    for artifact in reversed(artifacts):
        if artifact["artifact_type"] == artifact_type and artifact["ref"]:
            return str(artifact["ref"])
    return None


def _artifact_refs(artifacts: list[dict[str, Any]], artifact_type: str) -> set[str]:
    return {
        str(artifact["ref"])
        for artifact in artifacts
        if artifact["artifact_type"] == artifact_type and artifact["ref"]
    }


def _event_paths(events: list[dict[str, Any]], event_type: str) -> set[str]:
    return {
        str(event["payload"]["path"])
        for event in events
        if event["event_type"] == event_type and event.get("payload", {}).get("path")
    }


def _latest_plan_payload(store: SQLiteStore, plan_id: str | None) -> dict[str, Any]:
    if not plan_id:
        return {}
    revision = store.latest_task_plan_revision(plan_id)
    if not revision:
        return {}
    return _json(revision["plan_json"])


def _checkpoint_summaries(store: SQLiteStore, plan_id: str | None) -> list[dict[str, Any]]:
    if not plan_id:
        return []
    return [
        {
            "checkpoint_id": row["checkpoint_id"],
            "step_id": row["step_id"],
            "status": row["status"],
            "changed_paths": _json_list(row["changed_paths_json"]),
            "violations": _json_list(row["violations_json"]),
            "created_at": row["created_at"],
        }
        for row in store.task_plan_checkpoints(plan_id)
    ]


def _verification_summaries(
    store: SQLiteStore, *, task_session_id: str | None, plan_id: str | None
) -> list[dict[str, Any]]:
    if not task_session_id and not plan_id:
        return []
    rows = store.task_verifications(task_session_id=task_session_id, plan_id=plan_id)
    return [
        {
            "verification_id": row["verification_id"],
            "task_session_id": row["task_session_id"],
            "plan_id": row["plan_id"],
            "name": row["name"],
            "command": row["command"],
            "status": row["status"],
            "ok": bool(_json(row["report_json"]).get("ok")),
            "created_at": row["created_at"],
        }
        for row in reversed(rows)
    ]


def _pack_manifest(store: SQLiteStore, pack_id: str | None) -> dict[str, Any]:
    if not pack_id:
        return {}
    row = store.get_pack(pack_id)
    if not row:
        return {}
    return _json(row["manifest_json"])


def _step_values(plan: dict[str, Any], key: str) -> list[str]:
    steps = plan.get("steps", []) if isinstance(plan.get("steps"), list) else []
    values: list[str] = []
    for step in steps:
        raw = step.get(key, [])
        if isinstance(raw, list):
            values.extend(str(item) for item in raw)
    return values


def _title(objective: str, result: str | None) -> str:
    suffix = f" ({result})" if result and result != "unknown" else ""
    return _trim(f"Episode: {objective}{suffix}", 120)


def _lesson(summary: str | None, result: str | None, files_changed: list[str]) -> str:
    if summary and summary.strip():
        return _trim(summary.strip(), 500)
    result_label = str(result or "unknown")
    if files_changed:
        return (
            f"Session ended with result {result_label} after changing "
            + ", ".join(files_changed[:6])
            + "."
        )
    return f"Session ended with result {result_label}."


def _future_use(objective: str, paths: list[str], result: str | None) -> str:
    path_hint = ", ".join(paths[:6]) if paths else "this repository"
    return (
        f"Recall this episode for similar tasks involving {path_hint}; "
        f"the prior result was {result or 'unknown'} for: {objective}."
    )


def _trim(value: str, limit: int) -> str:
    text = " ".join(str(value).split())
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 1)].rstrip() + "..."


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item) for item in value if str(item).strip()]


def _json(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    try:
        parsed = json.loads(value or "{}")
    except (json.JSONDecodeError, TypeError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _json_list(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    try:
        parsed = json.loads(value or "[]")
    except (json.JSONDecodeError, TypeError):
        return []
    return parsed if isinstance(parsed, list) else []
