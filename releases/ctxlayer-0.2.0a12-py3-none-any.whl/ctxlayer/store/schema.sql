PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS schema_migrations (
  version    INTEGER PRIMARY KEY,
  name       TEXT NOT NULL,
  applied_at TEXT NOT NULL,
  checksum   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS repos (
  repo_id    TEXT PRIMARY KEY,
  root_path  TEXT NOT NULL,
  remote_url TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS snapshots (
  snapshot_id     TEXT PRIMARY KEY,
  repo_id         TEXT NOT NULL REFERENCES repos(repo_id),
  base_commit_sha TEXT NOT NULL,
  tree_digest     TEXT NOT NULL,
  dirty_digest    TEXT NOT NULL DEFAULT '',
  worktree_state  TEXT NOT NULL,
  branch_hint     TEXT,
  parent_snapshot TEXT,
  indexer_version TEXT NOT NULL,
  parser_bundle_version TEXT NOT NULL,
  chunker_version TEXT NOT NULL,
  embed_model     TEXT NOT NULL,
  created_at      TEXT NOT NULL,
  UNIQUE(repo_id, base_commit_sha, tree_digest, dirty_digest,
         indexer_version, parser_bundle_version, chunker_version, embed_model)
);

CREATE TABLE IF NOT EXISTS file_versions (
  file_version_id TEXT PRIMARY KEY,
  repo_id         TEXT NOT NULL,
  lang            TEXT,
  loc             INTEGER,
  skeleton        TEXT
);

CREATE TABLE IF NOT EXISTS snapshot_files (
  snapshot_id     TEXT NOT NULL REFERENCES snapshots(snapshot_id),
  path            TEXT NOT NULL,
  file_version_id TEXT NOT NULL REFERENCES file_versions(file_version_id),
  PRIMARY KEY (snapshot_id, path)
);

CREATE TABLE IF NOT EXISTS symbol_identities (
  symbol_identity_id TEXT PRIMARY KEY,
  repo_id   TEXT NOT NULL,
  path      TEXT NOT NULL,
  kind      TEXT NOT NULL,
  qualname  TEXT NOT NULL,
  is_test   INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS symbol_occurrences (
  symbol_occurrence_id TEXT PRIMARY KEY,
  symbol_identity_id   TEXT NOT NULL REFERENCES symbol_identities(symbol_identity_id),
  file_version_id      TEXT NOT NULL REFERENCES file_versions(file_version_id),
  start_line INTEGER,
  end_line   INTEGER,
  signature  TEXT,
  docstring  TEXT
);

CREATE TABLE IF NOT EXISTS edges (
  edge_id       TEXT PRIMARY KEY,
  scope_snapshot_id TEXT,
  src_repo_id   TEXT NOT NULL,
  src_node_type TEXT NOT NULL,
  src_node_id   TEXT NOT NULL,
  dst_repo_id   TEXT NOT NULL,
  dst_node_type TEXT NOT NULL,
  dst_node_id   TEXT NOT NULL,
  kind          TEXT NOT NULL,
  confidence    REAL NOT NULL DEFAULT 1.0,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_edges_src ON edges(src_repo_id, src_node_type, src_node_id, kind);
CREATE INDEX IF NOT EXISTS idx_edges_dst ON edges(dst_repo_id, dst_node_type, dst_node_id, kind);
CREATE INDEX IF NOT EXISTS idx_edges_scope ON edges(scope_snapshot_id);

CREATE TABLE IF NOT EXISTS edge_maintenance_state (
  id            INTEGER PRIMARY KEY CHECK (id = 1),
  last_dedup_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_snapshots_repo_created
  ON snapshots(repo_id, created_at DESC, snapshot_id);

CREATE TABLE IF NOT EXISTS chunks (
  chunk_id       TEXT PRIMARY KEY,
  snapshot_id    TEXT NOT NULL REFERENCES snapshots(snapshot_id),
  repo_id        TEXT NOT NULL,
  path           TEXT NOT NULL,
  symbol_identity_id TEXT,
  category       TEXT NOT NULL,
  start_line     INTEGER,
  end_line       INTEGER,
  text           TEXT NOT NULL,
  token_count    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_chunks_snapshot_path ON chunks(snapshot_id, path);
CREATE INDEX IF NOT EXISTS idx_chunks_symbol ON chunks(symbol_identity_id);

CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
  chunk_id UNINDEXED,
  text_normalized
);

CREATE TABLE IF NOT EXISTS test_commands (
  command_id TEXT PRIMARY KEY,
  repo_id    TEXT NOT NULL,
  path_glob  TEXT NOT NULL,
  command    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS chunk_vectors (
  chunk_id TEXT PRIMARY KEY REFERENCES chunks(chunk_id) ON DELETE CASCADE,
  dims INTEGER NOT NULL,
  vector_json TEXT NOT NULL,
  model TEXT NOT NULL,
  vector_blob BLOB,
  encoding TEXT NOT NULL DEFAULT 'json',
  scale REAL
);

CREATE TABLE IF NOT EXISTS retention_policies (
  target TEXT PRIMARY KEY,
  keep_full_days INTEGER,
  keep_summary_days INTEGER,
  max_rows INTEGER,
  scope TEXT NOT NULL DEFAULT 'global',
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS maintenance_state (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  last_maintenance_at TEXT,
  last_light_maintenance_at TEXT,
  last_degraded_auto_gc_at TEXT
);

CREATE TABLE IF NOT EXISTS maintenance_runs (
  maintenance_run_id TEXT PRIMARY KEY,
  trigger TEXT NOT NULL,
  mode TEXT NOT NULL,
  status TEXT NOT NULL,
  counts_json TEXT NOT NULL DEFAULT '{}',
  bytes_before INTEGER NOT NULL DEFAULT 0,
  bytes_after INTEGER NOT NULL DEFAULT 0,
  compact_json TEXT NOT NULL DEFAULT '{}',
  duration_ms REAL NOT NULL DEFAULT 0.0,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_maintenance_runs_created
  ON maintenance_runs(created_at);

CREATE TABLE IF NOT EXISTS chunk_vector_rows (
  vec_rowid INTEGER PRIMARY KEY AUTOINCREMENT,
  chunk_id TEXT NOT NULL UNIQUE REFERENCES chunks(chunk_id) ON DELETE CASCADE,
  dims INTEGER NOT NULL,
  model TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ownership (
  owner_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  path_glob TEXT NOT NULL,
  owner TEXT NOT NULL,
  source TEXT NOT NULL,
  confidence REAL NOT NULL DEFAULT 1.0
);

CREATE TABLE IF NOT EXISTS churn (
  churn_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  path TEXT NOT NULL,
  author TEXT,
  commits INTEGER NOT NULL,
  last_commit_sha TEXT,
  last_touched_at TEXT
);

CREATE TABLE IF NOT EXISTS cochange (
  cochange_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  path_a TEXT NOT NULL,
  path_b TEXT NOT NULL,
  commits_together INTEGER NOT NULL,
  commits_a INTEGER NOT NULL,
  commits_b INTEGER NOT NULL,
  jaccard REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_cochange_a ON cochange(repo_id, path_a, jaccard);
CREATE INDEX IF NOT EXISTS idx_cochange_b ON cochange(repo_id, path_b, jaccard);

CREATE TABLE IF NOT EXISTS eval_runs (
  eval_run_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  mode TEXT NOT NULL,
  train_count INTEGER NOT NULL,
  holdout_count INTEGER NOT NULL,
  metrics_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS efficacy_scorecards (
  scorecard_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  eval_run_id TEXT,
  schema_version TEXT NOT NULL,
  gate_status TEXT,
  report_json TEXT NOT NULL,
  audit_hash TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_efficacy_scorecards_repo_created
  ON efficacy_scorecards(repo_id, created_at);

CREATE TABLE IF NOT EXISTS release_reports (
  release_report_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  version TEXT NOT NULL,
  report_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ci_reports (
  ci_report_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  status TEXT NOT NULL,
  report_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS workspace_repos (
  workspace_repo_id TEXT PRIMARY KEY,
  workspace_root TEXT NOT NULL,
  repo_id TEXT NOT NULL,
  name TEXT NOT NULL,
  root_path TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS crossrepo_contracts (
  contract_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  path TEXT NOT NULL,
  kind TEXT NOT NULL,
  name TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS audit_anchors (
  anchor_id TEXT PRIMARY KEY,
  target TEXT NOT NULL,
  tip_hash TEXT NOT NULL,
  location TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS business_rules (
  rule_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  scope_glob TEXT,
  rule_text TEXT NOT NULL,
  source_type TEXT NOT NULL,
  source_ref TEXT NOT NULL,
  confidence REAL NOT NULL,
  status TEXT NOT NULL,
  approved_by TEXT,
  approved_at TEXT,
  supersedes_rule_id TEXT,
  updated_at TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS business_rule_evidence (
  rule_id TEXT NOT NULL REFERENCES business_rules(rule_id),
  repo_id TEXT,
  path TEXT,
  symbol_identity_id TEXT,
  quote_hash TEXT,
  evidence_type TEXT NOT NULL,
  evidence_kind TEXT,
  evidence_hash TEXT,
  line_start INTEGER,
  line_end INTEGER
);

CREATE TABLE IF NOT EXISTS business_rule_candidates (
  candidate_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  rule_text TEXT NOT NULL,
  source_type TEXT NOT NULL,
  confidence REAL NOT NULL,
  raw_score REAL,
  calibrated_confidence REAL,
  trust_tier TEXT,
  confidence_method TEXT,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS business_rule_candidate_evidence (
  candidate_id TEXT NOT NULL REFERENCES business_rule_candidates(candidate_id),
  repo_id TEXT,
  path TEXT,
  symbol_identity_id TEXT,
  evidence_kind TEXT NOT NULL,
  evidence_hash TEXT NOT NULL,
  line_start INTEGER,
  line_end INTEGER
);

CREATE TABLE IF NOT EXISTS business_rule_approvals (
  approval_id TEXT PRIMARY KEY,
  rule_id TEXT NOT NULL,
  approver TEXT NOT NULL,
  source TEXT NOT NULL,
  decision TEXT NOT NULL,
  notes TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS runtime_events (
  runtime_event_id TEXT PRIMARY KEY,
  source TEXT NOT NULL,
  repo_id TEXT,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  path TEXT,
  symbol_identity_id TEXT,
  severity TEXT NOT NULL,
  event_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS semantic_nodes (
  node_id TEXT PRIMARY KEY,
  repo_id TEXT,
  node_type TEXT NOT NULL,
  name TEXT NOT NULL,
  stable_key TEXT NOT NULL,
  confidence REAL NOT NULL,
  source TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  trust_tier TEXT,
  status TEXT,
  provenance_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_semantic_nodes_repo_type
  ON semantic_nodes(repo_id, node_type, name);

CREATE UNIQUE INDEX IF NOT EXISTS idx_semantic_nodes_stable_key
  ON semantic_nodes(stable_key);

CREATE TABLE IF NOT EXISTS semantic_edges (
  edge_id TEXT PRIMARY KEY,
  src_node_id TEXT NOT NULL REFERENCES semantic_nodes(node_id) ON DELETE CASCADE,
  dst_node_id TEXT NOT NULL REFERENCES semantic_nodes(node_id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  confidence REAL NOT NULL,
  evidence_json TEXT NOT NULL DEFAULT '[]',
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_semantic_edges_src
  ON semantic_edges(src_node_id, kind);

CREATE INDEX IF NOT EXISTS idx_semantic_edges_dst
  ON semantic_edges(dst_node_id, kind);

CREATE TABLE IF NOT EXISTS semantic_evidence (
  evidence_id TEXT PRIMARY KEY,
  node_id TEXT REFERENCES semantic_nodes(node_id) ON DELETE CASCADE,
  edge_id TEXT REFERENCES semantic_edges(edge_id) ON DELETE CASCADE,
  repo_id TEXT,
  path TEXT,
  symbol_identity_id TEXT,
  line_start INTEGER,
  line_end INTEGER,
  evidence_kind TEXT NOT NULL,
  evidence_hash TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_semantic_evidence_node
  ON semantic_evidence(node_id);

CREATE INDEX IF NOT EXISTS idx_semantic_evidence_edge
  ON semantic_evidence(edge_id);

CREATE TABLE IF NOT EXISTS business_node_approvals (
  approval_id TEXT PRIMARY KEY,
  node_id TEXT NOT NULL REFERENCES semantic_nodes(node_id) ON DELETE CASCADE,
  repo_id TEXT NOT NULL,
  decision TEXT NOT NULL,
  approver TEXT NOT NULL,
  notes TEXT,
  from_status TEXT,
  to_status TEXT NOT NULL,
  audit_row_hash TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_business_node_approvals_node
  ON business_node_approvals(node_id, created_at);

CREATE INDEX IF NOT EXISTS idx_business_node_approvals_repo_decision
  ON business_node_approvals(repo_id, decision, created_at);

CREATE TABLE IF NOT EXISTS org_knowledge_candidates (
  candidate_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  memory_record_id TEXT REFERENCES memory_records(record_id) ON DELETE SET NULL,
  source_connector TEXT NOT NULL,
  source_ref TEXT NOT NULL,
  content_extract TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  extracted_type TEXT NOT NULL,
  trust_tier TEXT NOT NULL DEFAULT 'low',
  confidence REAL NOT NULL DEFAULT 0.3,
  status TEXT NOT NULL DEFAULT 'quarantined',
  defense_result TEXT NOT NULL DEFAULT '{}',
  contradictions TEXT NOT NULL DEFAULT '[]',
  linked_entities TEXT NOT NULL DEFAULT '[]',
  captured_at TEXT,
  ingested_at TEXT NOT NULL,
  decay_at TEXT,
  provenance TEXT NOT NULL DEFAULT '{}',
  redaction_summary TEXT NOT NULL DEFAULT '{}',
  access_scope TEXT NOT NULL DEFAULT 'restricted',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_org_cand_status
  ON org_knowledge_candidates(workspace_id, repo_id, status);

CREATE INDEX IF NOT EXISTS idx_org_cand_source
  ON org_knowledge_candidates(source_connector, source_ref);

CREATE UNIQUE INDEX IF NOT EXISTS idx_org_cand_hash
  ON org_knowledge_candidates(workspace_id, content_hash);

CREATE TABLE IF NOT EXISTS org_connectors (
  connector_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  display_name TEXT NOT NULL,
  config_json TEXT NOT NULL DEFAULT '{}',
  secret_ref TEXT,
  access_scope TEXT NOT NULL DEFAULT 'restricted',
  remote_enabled INTEGER NOT NULL DEFAULT 0,
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_org_connectors_workspace_kind
  ON org_connectors(workspace_id, kind, enabled);

CREATE TABLE IF NOT EXISTS org_ingest_runs (
  run_id TEXT PRIMARY KEY,
  connector_id TEXT NOT NULL REFERENCES org_connectors(connector_id),
  workspace_id TEXT NOT NULL,
  since TEXT,
  items_seen INTEGER NOT NULL DEFAULT 0,
  items_quarantined INTEGER NOT NULL DEFAULT 0,
  items_rejected INTEGER NOT NULL DEFAULT 0,
  redactions INTEGER NOT NULL DEFAULT 0,
  remote_used INTEGER NOT NULL DEFAULT 0,
  audit_hash TEXT,
  started_at TEXT NOT NULL,
  finished_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_org_ingest_runs_connector_started
  ON org_ingest_runs(connector_id, started_at);

CREATE TABLE IF NOT EXISTS decisions (
  decision_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  question TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  snapshot_id TEXT,
  briefing_json TEXT NOT NULL DEFAULT '{}',
  human_decision_json TEXT,
  audit_hash TEXT,
  prev_audit_hash TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_decisions_repo
  ON decisions(repo_id, status);

CREATE INDEX IF NOT EXISTS idx_decisions_workspace_status
  ON decisions(workspace_id, status, updated_at);

CREATE TABLE IF NOT EXISTS semantic_file_index (
  repo_id TEXT NOT NULL,
  path TEXT NOT NULL,
  file_version_id TEXT NOT NULL,
  parser_backend TEXT NOT NULL,
  indexed_at TEXT NOT NULL,
  PRIMARY KEY (repo_id, path)
);

CREATE INDEX IF NOT EXISTS idx_semantic_file_index_repo
  ON semantic_file_index(repo_id, file_version_id);

CREATE TABLE IF NOT EXISTS semantic_drift_findings (
  finding_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  snapshot_id TEXT NOT NULL,
  finding_type TEXT NOT NULL,
  severity TEXT NOT NULL,
  node_id TEXT,
  edge_id TEXT,
  paths_json TEXT NOT NULL DEFAULT '[]',
  detail TEXT NOT NULL,
  confidence REAL,
  status TEXT NOT NULL DEFAULT 'open',
  detected_at TEXT NOT NULL,
  resolved_at TEXT,
  audit_hash TEXT,
  prev_audit_hash TEXT
);

CREATE INDEX IF NOT EXISTS idx_semantic_drift_repo_status
  ON semantic_drift_findings(repo_id, status, severity);

CREATE TABLE IF NOT EXISTS semantic_accuracy_runs (
  accuracy_run_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  fixture_set TEXT NOT NULL,
  metrics_json TEXT NOT NULL,
  passed INTEGER NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_semantic_accuracy_repo_created
  ON semantic_accuracy_runs(repo_id, created_at);

CREATE TABLE IF NOT EXISTS memory_eval_runs (
  memory_eval_run_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  metrics_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS dirty_blobs (
  blob_id TEXT PRIMARY KEY,
  snapshot_id TEXT NOT NULL REFERENCES snapshots(snapshot_id),
  path TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  content BLOB NOT NULL
);

CREATE TABLE IF NOT EXISTS context_packs (
  pack_id TEXT PRIMARY KEY,
  snapshot_id TEXT REFERENCES snapshots(snapshot_id),
  repo_id TEXT NOT NULL,
  task_text_hash TEXT NOT NULL,
  manifest_json TEXT NOT NULL,
  reconstructible INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  bound_snapshot_id TEXT,
  binding_mode TEXT NOT NULL DEFAULT 'auto',
  bound_at TEXT,
  base_commit_sha TEXT,
  worktree_state TEXT,
  staleness_state TEXT NOT NULL DEFAULT 'fresh'
);

CREATE INDEX IF NOT EXISTS idx_context_packs_snapshot_created
  ON context_packs(snapshot_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_context_packs_reconstructible_created
  ON context_packs(reconstructible, created_at DESC);

CREATE TABLE IF NOT EXISTS audit_log (
  audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
  pack_id TEXT NOT NULL,
  prev_hash TEXT NOT NULL,
  row_hash TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS session_leases (
  lease_id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  agent_name TEXT NOT NULL DEFAULT 'codex',
  bound_snapshot_id TEXT,
  impact_paths_json TEXT NOT NULL DEFAULT '[]',
  impact_hash TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active',
  acquired_at TEXT NOT NULL,
  renewed_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  released_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_session_leases_scope_status
  ON session_leases(workspace_id, repo_id, status, expires_at);

CREATE INDEX IF NOT EXISTS idx_session_leases_session_status
  ON session_leases(session_id, status, expires_at);

CREATE TABLE IF NOT EXISTS session_conflicts (
  conflict_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  left_session_id TEXT NOT NULL,
  right_session_id TEXT NOT NULL,
  conflict_type TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'warning',
  status TEXT NOT NULL DEFAULT 'open',
  paths_json TEXT NOT NULL DEFAULT '[]',
  detail_json TEXT NOT NULL DEFAULT '{}',
  detected_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  acknowledged_at TEXT,
  resolved_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_session_conflicts_scope_status
  ON session_conflicts(workspace_id, repo_id, status, detected_at);

CREATE TABLE IF NOT EXISTS audit_chain_state (
  chain_id TEXT PRIMARY KEY,
  tip_hash TEXT NOT NULL,
  height INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS outcomes (
  outcome_id TEXT PRIMARY KEY,
  pack_id TEXT NOT NULL,
  result TEXT NOT NULL,
  files_changed_json TEXT NOT NULL DEFAULT '[]',
  linked_prediction_id TEXT,
  prediction_link_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS memory_records (
  record_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  scope TEXT NOT NULL DEFAULT 'repo',
  type TEXT NOT NULL,
  subject_key TEXT NOT NULL,
  title TEXT,
  assertion TEXT NOT NULL,
  status TEXT NOT NULL,
  trust TEXT NOT NULL DEFAULT 'candidate',
  confidence REAL NOT NULL DEFAULT 1.0,
  importance REAL NOT NULL DEFAULT 0.5,
  source_kind TEXT NOT NULL,
  extraction_method TEXT NOT NULL,
  applies_when TEXT,
  avoid_when TEXT,
  owner TEXT,
  expires_at TEXT,
  invalidates_when TEXT,
  last_validated_at TEXT,
  superseded_by TEXT,
  provenance_json TEXT NOT NULL DEFAULT '{}',
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_memory_records_scope_type_status
  ON memory_records(workspace_id, repo_id, type, status);

CREATE INDEX IF NOT EXISTS idx_memory_records_subject
  ON memory_records(subject_key, type, status);

CREATE TABLE IF NOT EXISTS memory_evidence (
  evidence_id TEXT PRIMARY KEY,
  record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  repo_id TEXT,
  path TEXT,
  symbol_identity_id TEXT,
  line_start INTEGER,
  line_end INTEGER,
  evidence_kind TEXT NOT NULL,
  evidence_hash TEXT NOT NULL,
  source_ref TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_memory_evidence_record
  ON memory_evidence(record_id);

CREATE INDEX IF NOT EXISTS idx_memory_evidence_repo_path_record
  ON memory_evidence(repo_id, path, record_id);

CREATE TABLE IF NOT EXISTS memory_transitions (
  transition_id TEXT PRIMARY KEY,
  record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  from_status TEXT,
  to_status TEXT NOT NULL,
  actor TEXT NOT NULL,
  reason TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_memory_transitions_record
  ON memory_transitions(record_id);

CREATE TABLE IF NOT EXISTS memory_review_queue (
  review_id TEXT PRIMARY KEY,
  record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  reason TEXT NOT NULL,
  severity TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL,
  resolved_at TEXT,
  resolution TEXT
);

CREATE INDEX IF NOT EXISTS idx_memory_review_queue_status
  ON memory_review_queue(status, severity, created_at);

CREATE TABLE IF NOT EXISTS memory_revision (
  revision_id TEXT PRIMARY KEY,
  record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  previous_hash TEXT,
  record_json TEXT NOT NULL,
  actor TEXT NOT NULL,
  reason TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_memory_revision_record
  ON memory_revision(record_id, created_at);

CREATE TABLE IF NOT EXISTS memory_conflicts (
  conflict_id TEXT PRIMARY KEY,
  left_record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  right_record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  conflict_type TEXT NOT NULL,
  summary TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL,
  resolved_at TEXT,
  resolution TEXT
);

CREATE INDEX IF NOT EXISTS idx_memory_conflicts_status
  ON memory_conflicts(status);

CREATE TABLE IF NOT EXISTS memory_decay_policies (
  type TEXT PRIMARY KEY,
  default_ttl_days INTEGER,
  stale_after_days INTEGER,
  requires_manual_expiry INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS agent_sessions (
  session_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  task_text_hash TEXT NOT NULL,
  agent_name TEXT,
  started_at TEXT NOT NULL,
  ended_at TEXT,
  status TEXT NOT NULL,
  governed_class TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_agent_sessions_scope_status
  ON agent_sessions(workspace_id, repo_id, status);

CREATE TABLE IF NOT EXISTS agent_session_events (
  event_id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL REFERENCES agent_sessions(session_id) ON DELETE CASCADE,
  event_type TEXT NOT NULL,
  event_time TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  payload_hash TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_agent_session_events_session
  ON agent_session_events(session_id, event_time);

CREATE INDEX IF NOT EXISTS idx_agent_session_events_time
  ON agent_session_events(event_time DESC, event_id DESC);

CREATE TABLE IF NOT EXISTS agent_session_artifacts (
  artifact_id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL REFERENCES agent_sessions(session_id) ON DELETE CASCADE,
  artifact_type TEXT NOT NULL,
  ref TEXT NOT NULL,
  content_hash TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_agent_session_artifacts_session
  ON agent_session_artifacts(session_id, artifact_type);

CREATE TABLE IF NOT EXISTS memory_associations (
  association_id TEXT PRIMARY KEY,
  record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  target_type TEXT NOT NULL,
  target_ref TEXT NOT NULL,
  kind TEXT NOT NULL,
  weight REAL NOT NULL DEFAULT 1.0,
  evidence_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_memory_associations_record
  ON memory_associations(record_id, kind);

CREATE INDEX IF NOT EXISTS idx_memory_associations_target
  ON memory_associations(target_type, target_ref, kind);

CREATE TABLE IF NOT EXISTS memory_enforcement (
  directive_id TEXT PRIMARY KEY,
  record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  repo_id TEXT,
  enforcement_level TEXT NOT NULL,
  severity TEXT NOT NULL,
  path_globs_json TEXT NOT NULL,
  symbol_ids_json TEXT,
  anti_patterns_json TEXT,
  required_patterns_json TEXT,
  rationale TEXT,
  remediation TEXT,
  status TEXT NOT NULL,
  approved_by TEXT,
  source TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (enforcement_level IN ('advisory', 'warn', 'block')),
  CHECK (severity IN ('low', 'medium', 'high', 'critical')),
  CHECK (status IN ('active', 'suspended', 'superseded'))
);

CREATE INDEX IF NOT EXISTS idx_memory_enforcement_repo_status_level
  ON memory_enforcement(repo_id, status, enforcement_level);

CREATE INDEX IF NOT EXISTS idx_memory_enforcement_record
  ON memory_enforcement(record_id);

CREATE TABLE IF NOT EXISTS memory_vectors (
  record_id TEXT PRIMARY KEY REFERENCES memory_records(record_id) ON DELETE CASCADE,
  dims INTEGER NOT NULL,
  vector_json TEXT NOT NULL,
  model TEXT NOT NULL,
  vector_blob BLOB,
  encoding TEXT NOT NULL DEFAULT 'json',
  scale REAL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_memory_vectors_model
  ON memory_vectors(model, dims);

CREATE TABLE IF NOT EXISTS memory_vector_rows (
  vec_rowid INTEGER PRIMARY KEY AUTOINCREMENT,
  record_id TEXT NOT NULL UNIQUE REFERENCES memory_records(record_id) ON DELETE CASCADE,
  dims INTEGER NOT NULL,
  model TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS memory_access_log (
  access_id TEXT PRIMARY KEY,
  pack_id TEXT NOT NULL,
  memory_record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  served_at TEXT NOT NULL,
  score REAL NOT NULL,
  signals_json TEXT NOT NULL DEFAULT '[]'
);

CREATE INDEX IF NOT EXISTS idx_memory_access_log_pack
  ON memory_access_log(pack_id);

CREATE TABLE IF NOT EXISTS db_benchmark_runs (
  run_id TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  corpus_size INTEGER NOT NULL,
  backend TEXT NOT NULL,
  p50_ms REAL NOT NULL,
  p95_ms REAL NOT NULL,
  rows INTEGER NOT NULL,
  detail_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL,
  CHECK (kind IN ('vector', 'analytics', 'write'))
);

CREATE INDEX IF NOT EXISTS idx_db_benchmark_runs_kind_created
  ON db_benchmark_runs(kind, created_at);

CREATE TABLE IF NOT EXISTS memory_utilization (
  utilization_id TEXT PRIMARY KEY,
  pack_id TEXT NOT NULL,
  memory_record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  utilization_kind TEXT NOT NULL,
  score REAL NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_memory_utilization_pack
  ON memory_utilization(pack_id);

CREATE TABLE IF NOT EXISTS learning_candidate (
  candidate_id TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  provenance_json TEXT NOT NULL DEFAULT '{}',
  confidence REAL NOT NULL DEFAULT 0.0,
  status TEXT NOT NULL DEFAULT 'candidate',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_learning_candidate_status
  ON learning_candidate(kind, status, created_at);

CREATE TABLE IF NOT EXISTS skill (
  skill_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  nl_description TEXT NOT NULL,
  trigger_signature TEXT NOT NULL,
  steps_json TEXT NOT NULL DEFAULT '[]',
  evidence_json TEXT NOT NULL DEFAULT '[]',
  embedding_ref TEXT,
  provenance_json TEXT NOT NULL DEFAULT '{}',
  success_count INTEGER NOT NULL DEFAULT 0,
  fail_count INTEGER NOT NULL DEFAULT 0,
  last_validated_at TEXT,
  status TEXT NOT NULL DEFAULT 'candidate',
  trust TEXT NOT NULL DEFAULT 'untrusted',
  metrics_version INTEGER NOT NULL DEFAULT 0,
  last_measured_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_skill_status_trust
  ON skill(status, trust, updated_at);

CREATE TABLE IF NOT EXISTS artifact_outputs (
  output_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL,
  skill_id TEXT,
  session_id TEXT,
  task_session_id TEXT,
  artifact_kind TEXT NOT NULL,
  summary TEXT NOT NULL DEFAULT '',
  structure_json TEXT NOT NULL DEFAULT '{}',
  content_hash TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'produced',
  created_at TEXT NOT NULL,
  accepted_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_artifact_outputs_skill_created
  ON artifact_outputs(repo_id, skill_id, created_at);

CREATE TABLE IF NOT EXISTS revision_events (
  revision_id TEXT PRIMARY KEY,
  output_id TEXT,
  repo_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL,
  skill_id TEXT,
  session_id TEXT,
  task_session_id TEXT,
  event_type TEXT NOT NULL,
  signal_kind TEXT NOT NULL,
  request_summary TEXT NOT NULL DEFAULT '',
  theme TEXT NOT NULL DEFAULT 'unclassified',
  confidence REAL NOT NULL DEFAULT 0.0,
  status TEXT NOT NULL DEFAULT 'linked',
  actor TEXT NOT NULL DEFAULT 'user',
  created_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_revision_events_skill_created
  ON revision_events(repo_id, skill_id, created_at);
CREATE INDEX IF NOT EXISTS idx_revision_events_output
  ON revision_events(output_id, event_type);

CREATE TABLE IF NOT EXISTS skill_metrics (
  metric_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL,
  skill_id TEXT NOT NULL,
  usage_count INTEGER NOT NULL DEFAULT 0,
  accept_first_pass_count INTEGER NOT NULL DEFAULT 0,
  revised_output_count INTEGER NOT NULL DEFAULT 0,
  revision_count INTEGER NOT NULL DEFAULT 0,
  accept_first_pass_rate REAL NOT NULL DEFAULT 0.0,
  revision_rate REAL NOT NULL DEFAULT 0.0,
  avg_revisions_per_output REAL NOT NULL DEFAULT 0.0,
  trend TEXT NOT NULL DEFAULT 'flat',
  sample_tier TEXT NOT NULL DEFAULT 'low',
  themes_json TEXT NOT NULL DEFAULT '{}',
  measured_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_skill_metrics_skill_measured
  ON skill_metrics(skill_id, measured_at);

CREATE TABLE IF NOT EXISTS revision_classifications (
  classification_id TEXT PRIMARY KEY,
  revision_id TEXT NOT NULL,
  repo_id TEXT NOT NULL,
  skill_id TEXT,
  label TEXT NOT NULL,
  attribution TEXT NOT NULL,
  route TEXT NOT NULL,
  confidence REAL NOT NULL DEFAULT 0.0,
  rationale TEXT NOT NULL DEFAULT '',
  adjudicated INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_revision_classifications_revision
  ON revision_classifications(revision_id, created_at);
CREATE INDEX IF NOT EXISTS idx_revision_classifications_skill_label
  ON revision_classifications(skill_id, label, created_at);

CREATE TABLE IF NOT EXISTS skill_improvement_records (
  sir_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  skill_id TEXT NOT NULL,
  pattern TEXT NOT NULL,
  proposed_delta TEXT NOT NULL,
  evidence_refs_json TEXT NOT NULL DEFAULT '[]',
  evidence_count INTEGER NOT NULL DEFAULT 0,
  trust_tier TEXT NOT NULL DEFAULT 'low',
  status TEXT NOT NULL DEFAULT 'candidate',
  benchmark_ref TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_skill_improvement_records_skill_status
  ON skill_improvement_records(skill_id, status, updated_at);

CREATE TABLE IF NOT EXISTS skill_versions (
  version_id TEXT PRIMARY KEY,
  skill_id TEXT NOT NULL,
  repo_id TEXT NOT NULL,
  version INTEGER NOT NULL,
  guidance_hash TEXT NOT NULL,
  guidance_summary TEXT NOT NULL DEFAULT '',
  source_sir_id TEXT,
  active INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  activated_at TEXT,
  UNIQUE(skill_id, version)
);

CREATE INDEX IF NOT EXISTS idx_skill_versions_skill_active
  ON skill_versions(skill_id, active, version);

CREATE TABLE IF NOT EXISTS skill_refinement_approvals (
  approval_id TEXT PRIMARY KEY,
  sir_id TEXT NOT NULL,
  repo_id TEXT NOT NULL,
  skill_id TEXT NOT NULL,
  approved_by TEXT NOT NULL,
  status TEXT NOT NULL,
  reason TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS refinement_benchmarks (
  benchmark_id TEXT PRIMARY KEY,
  sir_id TEXT NOT NULL,
  repo_id TEXT NOT NULL,
  skill_id TEXT NOT NULL,
  baseline_version_id TEXT,
  candidate_version_id TEXT,
  result TEXT NOT NULL,
  revision_rate_delta REAL NOT NULL DEFAULT 0.0,
  regressions INTEGER NOT NULL DEFAULT 0,
  details_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_refinement_benchmarks_sir_created
  ON refinement_benchmarks(sir_id, created_at);

CREATE TABLE IF NOT EXISTS skill_closure_probes (
  probe_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  skill_id TEXT,
  sir_id TEXT,
  status TEXT NOT NULL,
  details_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_skill_closure_probes_created
  ON skill_closure_probes(repo_id, created_at);

CREATE TABLE IF NOT EXISTS skill_promotions (
  promotion_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  skill_id TEXT NOT NULL,
  global_skill_id TEXT,
  direction TEXT NOT NULL,
  status TEXT NOT NULL,
  privacy_status TEXT NOT NULL DEFAULT 'not_checked',
  approver TEXT,
  details_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_skill_promotions_skill_created
  ON skill_promotions(skill_id, created_at);

CREATE TABLE IF NOT EXISTS learning_run (
  run_id TEXT PRIMARY KEY,
  target TEXT NOT NULL,
  kind TEXT NOT NULL,
  before_json TEXT NOT NULL DEFAULT '{}',
  after_json TEXT NOT NULL DEFAULT '{}',
  train_metrics_json TEXT NOT NULL DEFAULT '{}',
  holdout_metrics_json TEXT NOT NULL DEFAULT '{}',
  gate_pass INTEGER NOT NULL DEFAULT 0,
  archived INTEGER NOT NULL DEFAULT 0,
  promoted INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_learning_run_kind_target
  ON learning_run(kind, target, created_at);

CREATE TABLE IF NOT EXISTS learning_event (
  event_id TEXT PRIMARY KEY,
  ts TEXT NOT NULL,
  phase TEXT NOT NULL,
  kind TEXT NOT NULL,
  ref TEXT,
  payload_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_learning_event_ts
  ON learning_event(ts, phase, kind);

CREATE INDEX IF NOT EXISTS idx_learning_event_ref_ts
  ON learning_event(ref, ts);

CREATE TABLE IF NOT EXISTS agent_benchmark_run (
  benchmark_run_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  cases INTEGER NOT NULL DEFAULT 0,
  success_rate_delta REAL NOT NULL DEFAULT 0.0,
  tests_pass_rate_delta REAL NOT NULL DEFAULT 0.0,
  wrong_files_touched_reduction REAL NOT NULL DEFAULT 0.0,
  missing_files_reduction REAL NOT NULL DEFAULT 0.0,
  agent_seconds_reduction REAL NOT NULL DEFAULT 0.0,
  memory_score REAL NOT NULL DEFAULT 0.0,
  context_retrieval_score REAL NOT NULL DEFAULT 0.0,
  gate_ok INTEGER,
  gate_status TEXT,
  delta_json TEXT NOT NULL DEFAULT '{}',
  lift_attribution_json TEXT NOT NULL DEFAULT '{}',
  roadmap_pruning_json TEXT NOT NULL DEFAULT '{}',
  report_json TEXT NOT NULL DEFAULT '{}',
  snapshot_id TEXT,
  benchmark_version TEXT,
  config_hash TEXT,
  git_rev TEXT,
  headline REAL,
  split TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_agent_benchmark_run_repo_created
  ON agent_benchmark_run(repo_id, created_at);

CREATE TABLE IF NOT EXISTS bench_reward_ledger (
  run_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  snapshot_id TEXT NOT NULL,
  benchmark_version TEXT NOT NULL,
  config_hash TEXT NOT NULL,
  git_rev TEXT,
  headline REAL NOT NULL,
  split TEXT NOT NULL,
  created_at TEXT NOT NULL,
  CHECK (split IN ('train', 'holdout'))
);

CREATE INDEX IF NOT EXISTS idx_bench_reward_ledger_repo_created
  ON bench_reward_ledger(repo_id, created_at);

CREATE TABLE IF NOT EXISTS bench_reward_metrics (
  run_id TEXT NOT NULL REFERENCES bench_reward_ledger(run_id),
  metric_key TEXT NOT NULL,
  value REAL NOT NULL,
  PRIMARY KEY (run_id, metric_key)
);

CREATE TRIGGER IF NOT EXISTS trg_bench_reward_ledger_no_update
BEFORE UPDATE ON bench_reward_ledger
BEGIN
  SELECT RAISE(ABORT, 'bench_reward_ledger is insert-only');
END;

CREATE TRIGGER IF NOT EXISTS trg_bench_reward_ledger_no_delete
BEFORE DELETE ON bench_reward_ledger
BEGIN
  SELECT RAISE(ABORT, 'bench_reward_ledger is insert-only');
END;

CREATE TRIGGER IF NOT EXISTS trg_bench_reward_metrics_no_update
BEFORE UPDATE ON bench_reward_metrics
BEGIN
  SELECT RAISE(ABORT, 'bench_reward_metrics is insert-only');
END;

CREATE TRIGGER IF NOT EXISTS trg_bench_reward_metrics_no_delete
BEFORE DELETE ON bench_reward_metrics
BEGIN
  SELECT RAISE(ABORT, 'bench_reward_metrics is insert-only');
END;

CREATE TABLE IF NOT EXISTS retention_baselines (
  baseline_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  task_set_hash TEXT NOT NULL,
  metric_key TEXT NOT NULL,
  floor_value REAL NOT NULL,
  created_at TEXT NOT NULL,
  created_by TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  supersedes TEXT
);

CREATE INDEX IF NOT EXISTS idx_retention_baselines_active
  ON retention_baselines(repo_id, task_set_hash, active, metric_key);

CREATE TABLE IF NOT EXISTS task_learning_summary (
  task_session_id TEXT PRIMARY KEY,
  idempotency_key TEXT NOT NULL,
  consolidated_at TEXT NOT NULL,
  trigger TEXT NOT NULL,
  session_ids_json TEXT NOT NULL DEFAULT '[]',
  counts_json TEXT NOT NULL DEFAULT '{}',
  record_refs_json TEXT NOT NULL DEFAULT '{}',
  narrative TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS constitutions (
  constitution_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT NOT NULL,
  constitution_hash TEXT NOT NULL,
  manifest_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_constitutions_repo_created
  ON constitutions(repo_id, created_at);

CREATE TABLE IF NOT EXISTS task_sessions (
  task_session_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  task_text_hash TEXT NOT NULL,
  current_state TEXT NOT NULL,
  pack_id TEXT,
  constitution_hash TEXT,
  governed_class TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_task_sessions_scope_state
  ON task_sessions(workspace_id, repo_id, current_state);

CREATE TABLE IF NOT EXISTS task_session_transitions (
  transition_id TEXT PRIMARY KEY,
  task_session_id TEXT NOT NULL REFERENCES task_sessions(task_session_id) ON DELETE CASCADE,
  from_state TEXT,
  to_state TEXT NOT NULL,
  actor TEXT NOT NULL,
  reason TEXT,
  prev_hash TEXT NOT NULL,
  transition_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_task_session_transitions_session
  ON task_session_transitions(task_session_id, created_at);

CREATE TABLE IF NOT EXISTS task_plans (
  plan_id TEXT PRIMARY KEY,
  task_session_id TEXT REFERENCES task_sessions(task_session_id) ON DELETE SET NULL,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  plan_hash TEXT NOT NULL,
  status TEXT NOT NULL,
  governed_class TEXT,
  required_verifications_json TEXT NOT NULL DEFAULT '[]',
  current_revision_id TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_task_plans_session_status
  ON task_plans(task_session_id, status);

CREATE TABLE IF NOT EXISTS task_plan_revisions (
  revision_id TEXT PRIMARY KEY,
  plan_id TEXT NOT NULL REFERENCES task_plans(plan_id) ON DELETE CASCADE,
  revision_number INTEGER NOT NULL,
  plan_hash TEXT NOT NULL,
  previous_plan_hash TEXT,
  author TEXT NOT NULL,
  reason TEXT,
  plan_json TEXT NOT NULL,
  validation_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_task_plan_revisions_plan
  ON task_plan_revisions(plan_id, revision_number);

CREATE TABLE IF NOT EXISTS task_plan_checkpoints (
  checkpoint_id TEXT PRIMARY KEY,
  plan_id TEXT NOT NULL REFERENCES task_plans(plan_id) ON DELETE CASCADE,
  step_id TEXT NOT NULL,
  status TEXT NOT NULL,
  changed_paths_json TEXT NOT NULL DEFAULT '[]',
  violations_json TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_task_plan_checkpoints_plan
  ON task_plan_checkpoints(plan_id, created_at);

CREATE TABLE IF NOT EXISTS ctx_health_probes (
  probe_id TEXT PRIMARY KEY,
  status TEXT NOT NULL,
  reasons_json TEXT NOT NULL DEFAULT '[]',
  db_bytes INTEGER NOT NULL DEFAULT 0,
  wal_bytes INTEGER NOT NULL DEFAULT 0,
  last_recall_ms REAL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_ctx_health_probes_created
  ON ctx_health_probes(created_at);

CREATE TABLE IF NOT EXISTS task_verifications (
  verification_id TEXT PRIMARY KEY,
  task_session_id TEXT,
  plan_id TEXT,
  name TEXT NOT NULL,
  command TEXT NOT NULL,
  status TEXT NOT NULL,
  report_json TEXT NOT NULL DEFAULT '{}',
  audit_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_task_verifications_plan_name
  ON task_verifications(plan_id, name, created_at);

CREATE INDEX IF NOT EXISTS idx_task_verifications_session_name
  ON task_verifications(task_session_id, name, created_at);

CREATE TABLE IF NOT EXISTS intents (
  intent_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  snapshot_id TEXT NOT NULL REFERENCES snapshots(snapshot_id),
  problem_statement TEXT NOT NULL,
  problem_text_hash TEXT NOT NULL,
  skeleton_hash TEXT NOT NULL,
  status TEXT NOT NULL,
  selected_goal_id TEXT,
  audit_hash TEXT NOT NULL,
  prev_audit_hash TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  bound_snapshot_id TEXT,
  binding_mode TEXT NOT NULL DEFAULT 'auto',
  bound_at TEXT,
  base_commit_sha TEXT,
  worktree_state TEXT,
  staleness_state TEXT NOT NULL DEFAULT 'fresh'
);

CREATE INDEX IF NOT EXISTS idx_intents_scope
  ON intents(workspace_id, repo_id, status);

CREATE UNIQUE INDEX IF NOT EXISTS idx_intents_reproduce
  ON intents(problem_text_hash, snapshot_id);

CREATE TABLE IF NOT EXISTS intent_evidence (
  evidence_id TEXT PRIMARY KEY,
  intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
  ref TEXT NOT NULL,
  source_type TEXT NOT NULL,
  repo_id TEXT,
  path TEXT,
  symbol_identity_id TEXT,
  line_start INTEGER,
  line_end INTEGER,
  evidence_hash TEXT NOT NULL,
  confidence REAL NOT NULL DEFAULT 1.0,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_intent_evidence_intent
  ON intent_evidence(intent_id, source_type);

CREATE TABLE IF NOT EXISTS intent_decomposition_nodes (
  node_id TEXT PRIMARY KEY,
  intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
  parent_id TEXT,
  label TEXT NOT NULL,
  node_kind TEXT NOT NULL,
  origin TEXT NOT NULL,
  status TEXT NOT NULL,
  confidence REAL NOT NULL DEFAULT 1.0,
  evidence_refs_json TEXT NOT NULL DEFAULT '[]',
  ordinal INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS trust_calibration (
  calibration_id TEXT PRIMARY KEY,
  repo_id TEXT,
  source_type TEXT NOT NULL,
  default_tier TEXT NOT NULL,
  approvals INTEGER NOT NULL,
  rejections INTEGER NOT NULL,
  approval_rate REAL NOT NULL,
  sample_size INTEGER NOT NULL,
  confidence_floor REAL NOT NULL,
  method TEXT NOT NULL,
  computed_at TEXT NOT NULL,
  UNIQUE(repo_id, source_type)
);

CREATE TABLE IF NOT EXISTS extraction_eval_results (
  result_id TEXT PRIMARY KEY,
  memory_eval_run_id TEXT NOT NULL REFERENCES memory_eval_runs(memory_eval_run_id),
  repo_id TEXT,
  source_type TEXT NOT NULL,
  corpus_version TEXT NOT NULL,
  true_positive INTEGER NOT NULL,
  false_positive INTEGER NOT NULL,
  false_negative INTEGER NOT NULL,
  precision REAL NOT NULL,
  recall REAL NOT NULL,
  f1 REAL NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_extraction_eval_results_run
  ON extraction_eval_results(memory_eval_run_id, source_type);

CREATE INDEX IF NOT EXISTS idx_trust_calibration_scope
  ON trust_calibration(repo_id, source_type);

CREATE INDEX IF NOT EXISTS idx_intent_nodes_intent
  ON intent_decomposition_nodes(intent_id, parent_id, ordinal);

CREATE TABLE IF NOT EXISTS intent_hypotheses (
  hypothesis_id TEXT PRIMARY KEY,
  intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
  statement TEXT NOT NULL,
  origin TEXT NOT NULL,
  confidence REAL NOT NULL,
  rank INTEGER NOT NULL,
  verified INTEGER NOT NULL DEFAULT 0,
  evidence_refs_json TEXT NOT NULL DEFAULT '[]',
  signals_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_intent_hypotheses_intent
  ON intent_hypotheses(intent_id, rank);

CREATE TABLE IF NOT EXISTS intent_stakeholders (
  stakeholder_id TEXT PRIMARY KEY,
  intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
  owner TEXT NOT NULL,
  files_json TEXT NOT NULL DEFAULT '[]',
  reason TEXT NOT NULL,
  source TEXT NOT NULL,
  confidence REAL NOT NULL DEFAULT 1.0
);

CREATE TABLE IF NOT EXISTS intent_contradictions (
  contradiction_id TEXT PRIMARY KEY,
  intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
  a_ref TEXT NOT NULL,
  b_ref TEXT NOT NULL,
  description TEXT NOT NULL,
  detector TEXT NOT NULL,
  severity TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS intent_candidate_goals (
  goal_id TEXT PRIMARY KEY,
  intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
  statement TEXT NOT NULL,
  success_metric TEXT,
  metric_source TEXT NOT NULL,
  confidence REAL NOT NULL,
  origin TEXT NOT NULL,
  evidence_refs_json TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS intent_open_questions (
  question_id TEXT PRIMARY KEY,
  intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  reason TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS goals (
  goal_id TEXT PRIMARY KEY,
  intent_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  snapshot_id TEXT,
  statement TEXT NOT NULL,
  success_metric TEXT NOT NULL,
  metric_kind TEXT NOT NULL DEFAULT 'technical',
  metric_target TEXT,
  hypothesis TEXT,
  confidence REAL NOT NULL DEFAULT 0.0,
  status TEXT NOT NULL DEFAULT 'proposed',
  challenge_state TEXT NOT NULL DEFAULT 'none',
  permission_mode TEXT NOT NULL DEFAULT 'warn',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  bound_snapshot_id TEXT,
  binding_mode TEXT NOT NULL DEFAULT 'auto',
  bound_at TEXT,
  base_commit_sha TEXT,
  worktree_state TEXT,
  staleness_state TEXT NOT NULL DEFAULT 'fresh'
);

CREATE INDEX IF NOT EXISTS idx_goals_scope_status
  ON goals(workspace_id, repo_id, status);

CREATE INDEX IF NOT EXISTS idx_goals_intent
  ON goals(intent_id);

CREATE TABLE IF NOT EXISTS goal_evidence (
  evidence_id TEXT PRIMARY KEY,
  goal_id TEXT NOT NULL REFERENCES goals(goal_id) ON DELETE CASCADE,
  ref TEXT NOT NULL,
  source_type TEXT NOT NULL,
  weight REAL NOT NULL DEFAULT 1.0,
  detail_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_goal_evidence_goal
  ON goal_evidence(goal_id);

CREATE TABLE IF NOT EXISTS goal_alternatives (
  alt_id TEXT PRIMARY KEY,
  goal_id TEXT NOT NULL REFERENCES goals(goal_id) ON DELETE CASCADE,
  statement TEXT NOT NULL,
  projected_metric_delta TEXT NOT NULL,
  rationale TEXT NOT NULL,
  confidence REAL NOT NULL DEFAULT 0.0,
  evidence_refs_json TEXT NOT NULL DEFAULT '[]',
  rank INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'proposed',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_goal_alternatives_goal
  ON goal_alternatives(goal_id, rank);

CREATE TABLE IF NOT EXISTS goal_decisions (
  decision_id TEXT PRIMARY KEY,
  goal_id TEXT NOT NULL REFERENCES goals(goal_id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  alt_id TEXT,
  actor TEXT NOT NULL,
  rationale TEXT,
  permission_mode TEXT NOT NULL,
  audit_row_hash TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_goal_decisions_goal
  ON goal_decisions(goal_id, created_at);

CREATE TABLE IF NOT EXISTS self_improve_runs (
  id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  run_day TEXT NOT NULL,
  mode TEXT NOT NULL,
  audit_json TEXT NOT NULL,
  brief_hash TEXT NOT NULL,
  status TEXT NOT NULL,
  lock_owner TEXT,
  lock_expires_at TEXT,
  completed_at TEXT,
  created_at TEXT NOT NULL,
  UNIQUE(repo_id, run_day)
);

CREATE TABLE IF NOT EXISTS self_improve_proposals (
  id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL REFERENCES self_improve_runs(id),
  parent_id TEXT,
  title TEXT NOT NULL,
  rationale TEXT NOT NULL,
  evidence_json TEXT NOT NULL,
  target_files TEXT NOT NULL,
  predicted_effect TEXT,
  capability_verdict TEXT NOT NULL,
  eval_json TEXT,
  overseer_json TEXT,
  reward_run_id TEXT,
  benchmark_version TEXT,
  config_hash TEXT,
  reward_before REAL,
  reward_after REAL,
  reward_delta REAL,
  retention_status TEXT,
  safety_verified INTEGER,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL,
  decided_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_self_improve_proposals_run
  ON self_improve_proposals(run_id, status, created_at);

CREATE TABLE IF NOT EXISTS self_improve_lineage (
  id TEXT PRIMARY KEY,
  proposal_id TEXT NOT NULL REFERENCES self_improve_proposals(id),
  parent_id TEXT,
  clade_root TEXT NOT NULL,
  before_metrics TEXT NOT NULL,
  after_metrics TEXT NOT NULL,
  clade_productivity REAL,
  effectiveness_json TEXT,
  superseded_by TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_self_improve_lineage_clade
  ON self_improve_lineage(clade_root, created_at);

CREATE TABLE IF NOT EXISTS self_improve_overseer_flags (
  id TEXT PRIMARY KEY,
  proposal_id TEXT REFERENCES self_improve_proposals(id),
  run_id TEXT REFERENCES self_improve_runs(id),
  kind TEXT NOT NULL,
  severity TEXT NOT NULL,
  detail TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_self_improve_flags_scope
  ON self_improve_overseer_flags(run_id, proposal_id, severity);

CREATE TABLE IF NOT EXISTS world_model_versions (
  version_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  model_kind TEXT NOT NULL,
  parent_version_id TEXT,
  training_pairs INTEGER NOT NULL DEFAULT 0,
  calibration_ece REAL,
  enforce_enabled INTEGER NOT NULL DEFAULT 0,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_world_model_versions_repo_created
  ON world_model_versions(repo_id, created_at);

CREATE TABLE IF NOT EXISTS world_model_eval_runs (
  eval_run_id TEXT PRIMARY KEY,
  version_id TEXT NOT NULL REFERENCES world_model_versions(version_id),
  repo_id TEXT NOT NULL,
  baseline_kind TEXT NOT NULL DEFAULT 'frequency_v0',
  holdout_pairs INTEGER NOT NULL DEFAULT 0,
  surprise_recall REAL NOT NULL DEFAULT 0.0,
  calibration_ece REAL,
  passed INTEGER NOT NULL DEFAULT 0,
  report_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_world_model_eval_runs_version_created
  ON world_model_eval_runs(version_id, created_at);

CREATE TABLE IF NOT EXISTS experience_strategies (
  strategy_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  task_shape_key TEXT NOT NULL,
  trigger TEXT NOT NULL,
  lesson TEXT NOT NULL,
  support INTEGER NOT NULL DEFAULT 0,
  lift REAL NOT NULL DEFAULT 0.0,
  importance REAL NOT NULL DEFAULT 0.5,
  evidence_json TEXT NOT NULL DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_experience_strategies_shape
  ON experience_strategies(repo_id, task_shape_key, status, importance);

CREATE TABLE IF NOT EXISTS provider_spend_ledger (
  spend_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  provider TEXT NOT NULL,
  spend_day TEXT NOT NULL,
  input_tokens INTEGER NOT NULL DEFAULT 0,
  output_tokens INTEGER NOT NULL DEFAULT 0,
  total_tokens INTEGER NOT NULL DEFAULT 0,
  cost_usd REAL NOT NULL DEFAULT 0.0,
  reason TEXT NOT NULL DEFAULT 'provider_call',
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_provider_spend_ledger_repo_day
  ON provider_spend_ledger(repo_id, spend_day, provider);

CREATE TABLE IF NOT EXISTS flywheel_health (
  health_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  period_start TEXT NOT NULL,
  period_end TEXT NOT NULL,
  headline REAL NOT NULL DEFAULT 0.0,
  components_json TEXT NOT NULL DEFAULT '{}',
  adoptions_count INTEGER NOT NULL DEFAULT 0,
  adoption_acceptance_rate REAL NOT NULL DEFAULT 0.0,
  retention_floor_margin REAL,
  provider_tokens INTEGER NOT NULL DEFAULT 0,
  provider_cost_usd REAL NOT NULL DEFAULT 0.0,
  compounding_slope REAL,
  status TEXT NOT NULL DEFAULT 'ok',
  warnings_json TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_flywheel_health_repo_period
  ON flywheel_health(repo_id, period_end);

CREATE TABLE IF NOT EXISTS reasoning_cycles (
  cycle_id TEXT PRIMARY KEY,
  task_session_id TEXT,
  repo_id TEXT NOT NULL,
  goal_id TEXT,
  intent_id TEXT,
  phase TEXT NOT NULL DEFAULT 'context',
  status TEXT NOT NULL DEFAULT 'open',
  opened_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  closed_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_reasoning_cycles_session
  ON reasoning_cycles(task_session_id, status, updated_at);

CREATE TABLE IF NOT EXISTS reasoning_syntheses (
  synthesis_id TEXT PRIMARY KEY,
  cycle_id TEXT NOT NULL REFERENCES reasoning_cycles(cycle_id),
  checkpoint TEXT NOT NULL,
  action TEXT NOT NULL,
  confidence REAL NOT NULL,
  rationale TEXT NOT NULL,
  drivers_json TEXT NOT NULL DEFAULT '[]',
  goal_fit REAL NOT NULL DEFAULT 0.0,
  provider_status_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_reasoning_syntheses_cycle_created
  ON reasoning_syntheses(cycle_id, created_at);

CREATE TABLE IF NOT EXISTS working_memory_notes (
  note_id TEXT PRIMARY KEY,
  task_session_id TEXT NOT NULL,
  cycle_id TEXT,
  kind TEXT NOT NULL,
  text TEXT NOT NULL,
  salience REAL NOT NULL DEFAULT 0.5,
  evidence_refs_json TEXT NOT NULL DEFAULT '[]',
  superseded_by TEXT,
  created_at TEXT NOT NULL,
  expires_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_working_memory_notes_session
  ON working_memory_notes(task_session_id, cycle_id, created_at);
