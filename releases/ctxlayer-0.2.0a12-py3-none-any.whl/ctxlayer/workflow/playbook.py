from __future__ import annotations

from typing import Any

PLAYBOOK_VERSION = "ctxlayer.workflow_playbook.v1"

GATE_KINDS: dict[str, str] = {
    "preflight_ready": "durable",
    "plan_active": "durable",
    "checkpoints_present": "durable",
    "check_diff_clean": "volatile",
    "dirty_set_in_scope": "volatile",
    "tests_pass": "durable",
    "outcome_recorded": "durable",
    "security_scan_pass": "durable",
    "release_validated": "durable",
    "bench_reward_recorded": "durable",
    "retention_guard_pass": "durable",
    "provider_live_or_honest_inactive": "durable",
    "metacognition_action_resolved": "durable",
    "workspace_critique_passed": "durable",
    "self_improve_reward_pass": "durable",
    "self_improve_safety_verified": "durable",
    "judgment_overlay_guard": "durable",
}

PLAYBOOK: dict[str, dict[str, Any]] = {
    "core_session": {
        "match": {"base": True},
        "required_features": ["pack"],
        "optional_features": [
            "memory_recall",
            "memory_prefetch",
            "continuation",
            "workflow_next",
        ],
        "gates": ["preflight_ready"],
        "stop_when": "context pack has been served and any requested read-only task is answered",
    },
    "standard_edit": {
        "match": {"default_write": True},
        "required_features": [
            "plan",
            "checkpoint",
            "impact",
            "check_diff",
            "tests",
            "outcome",
        ],
        "optional_features": ["anticipation_consult", "agent_route"],
        "gates": [
            "plan_active",
            "checkpoints_present",
            "check_diff_clean",
            "tests_pass",
            "outcome_recorded",
        ],
        "escalate_when": {
            "risk_score": ">=7",
            "touches": ["**/auth/**", "**/billing/**", "**/migrations/**"],
        },
        "stop_when": "plan, checkpoints, diff gates, tests, and outcome are recorded",
    },
    "investigation": {
        "match": {
            "keywords": [
                "investigate",
                "analyze",
                "read",
                "understand",
                "audit",
                "explain",
            ],
            "mode": "read",
        },
        "required_features": [],
        "optional_features": [
            "impact",
            "semantic_search",
            "architecture_infer",
            "graph_neighbors",
            "memory_graph_recall",
        ],
        "gates": [],
        "stop_when": "question is answered from the served context",
    },
    "architecture_change": {
        "match": {
            "keywords": ["architecture", "design", "refactor", "cross-cutting"],
            "mode": "write",
        },
        "required_features": ["decision", "architecture_infer", "agent_route"],
        "optional_features": ["semantic_search", "graph_neighbors"],
        "gates": [],
        "stop_when": "architecture decision and standard edit gates are complete",
    },
    "release": {
        "match": {
            "keywords": ["release", "publish", "version", "wheel"],
            "mode": "write",
        },
        "required_features": ["release_validate"],
        "optional_features": [],
        "gates": ["release_validated"],
        "stop_when": "release validation and standard edit gates are complete",
    },
    "memory_curation": {
        "match": {
            "keywords": ["memory", "remember", "recall", "curate"],
            "mode": "write",
        },
        "required_features": ["memory_recall"],
        "optional_features": ["memory_graph_recall", "memory_sleep", "memory_dream"],
        "gates": [],
        "stop_when": "memory work and standard edit gates are complete",
    },
    "decision": {
        "match": {"keywords": ["decide", "decision", "tradeoff"], "mode": "write"},
        "required_features": ["decision"],
        "optional_features": [],
        "gates": [],
        "stop_when": "decision evidence is recorded",
    },
    "data_migration": {
        "match": {"keywords": ["migration", "schema", "database"], "mode": "write"},
        "required_features": ["agent_route"],
        "optional_features": [],
        "gates": [],
        "stop_when": "migration-specific review and standard edit gates are complete",
    },
    "security_change": {
        "match": {
            "keywords": ["security", "auth", "secret", "permission"],
            "mode": "write",
        },
        "required_features": ["security_scan", "agent_route", "anticipation_consult"],
        "optional_features": ["semantic_search"],
        "gates": ["security_scan_pass"],
        "stop_when": "security scan and standard edit gates are complete",
    },
    "maintenance_ops": {
        "match": {
            "keywords": [
                "maintenance",
                "ops",
                "doctor",
                "health",
                "storage",
                "database",
                "retention",
                "gc",
            ],
            "mode": "write",
        },
        "required_features": ["impact", "storage_report"],
        "optional_features": [
            "gc",
            "retention",
            "maintenance_run",
            "agent_route",
            "memory_sleep",
            "selfimprove",
            "cie",
        ],
        "gates": [],
        "stop_when": "operations change and standard edit gates are complete",
    },
}

FEATURE_COVERAGE: dict[str, dict[str, str]] = {
    "pack": {"classification": "required", "reason": "universal context substrate"},
    "plan": {"classification": "required", "reason": "write tasks need scoped plans"},
    "checkpoint": {
        "classification": "required",
        "reason": "write files must be tied to plan steps",
    },
    "impact": {
        "classification": "required",
        "reason": "write completion needs impact evidence",
    },
    "check_diff": {
        "classification": "required",
        "reason": "write completion needs pack-scope validation",
    },
    "tests": {
        "classification": "required",
        "reason": "write completion needs verification evidence",
    },
    "outcome": {
        "classification": "required",
        "reason": "workflow memory needs explicit outcome",
    },
    "continuation": {
        "classification": "optional",
        "reason": "useful for resume and memory curation",
    },
    "memory_recall": {
        "classification": "optional",
        "reason": "fast-path recall should be available at session start",
    },
    "db_backend_status": {
        "classification": "optional",
        "reason": "agents inspect retrieval and analytics backend truth on demand",
    },
    "db_bench": {
        "classification": "maintenance",
        "reason": "database benchmark evidence is collected in the maintenance lane",
    },
    "storage_report": {
        "classification": "maintenance",
        "reason": "database size and pinning diagnostics belong in the maintenance lane",
    },
    "gc": {
        "classification": "maintenance",
        "reason": "garbage collection applies retention and compaction policy",
    },
    "retention": {
        "classification": "maintenance",
        "reason": "retention presets configure storage policy",
    },
    "maintenance_run": {
        "classification": "maintenance",
        "reason": "scheduled maintenance executes storage and memory hygiene",
    },
    "anticipation_consult": {
        "classification": "optional",
        "reason": "risky writes benefit from deterministic foresight",
    },
    "semantic_search": {
        "classification": "optional",
        "reason": "investigation tasks benefit from semantic lookup",
    },
    "architecture_infer": {
        "classification": "optional",
        "reason": "cross-cutting work benefits from inferred architecture",
    },
    "graph_neighbors": {
        "classification": "optional",
        "reason": "code graph lookup supports impact investigation",
    },
    "memory_graph_recall": {
        "classification": "optional",
        "reason": "memory graph recall exposes linked memories distinctly from code graph",
    },
    "memory_prefetch": {
        "classification": "optional",
        "reason": "anticipatory prefetch is useful at session start when enabled",
    },
    "memory_sleep": {
        "classification": "maintenance",
        "reason": "sleep consolidation is maintenance-lane, not per-task injection",
    },
    "memory_dream": {
        "classification": "maintenance",
        "reason": "dream reflection is maintenance-lane, not per-task injection",
    },
    "selfimprove": {
        "classification": "maintenance",
        "reason": "self-improvement is reviewed in maintenance workflows",
    },
    "cie": {
        "classification": "maintenance",
        "reason": "capability improvement engine is reviewed in maintenance workflows",
    },
    "agent_route": {
        "classification": "escalation_only",
        "reason": "only high-risk or specific task types need routing",
    },
    "decision": {
        "classification": "required",
        "reason": "architecture and trade-off work needs decision evidence",
    },
    "security_scan": {
        "classification": "required",
        "reason": "security-sensitive work needs scan evidence",
    },
    "release_validate": {
        "classification": "required",
        "reason": "release work needs packaging validation",
    },
    "workflow_next": {
        "classification": "optional",
        "reason": "advisory projection over existing workflow evidence",
    },
}


def task_type(task_type_id: str) -> dict[str, Any]:
    return PLAYBOOK[task_type_id]
