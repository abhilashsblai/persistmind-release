from __future__ import annotations

import json
from typing import Any, Callable

from ctxlayer.utils import canonical_json
from ctxlayer.workflow.playbook import GATE_KINDS

FingerprintProvider = Callable[[], dict[str, Any]]
SessionResolver = Callable[[str], str | None]

FLYWHEEL_GATE_NAMES = {
    "bench_reward_recorded": {"bench_reward_recorded", "bench_reward", "bench"},
    "retention_guard_pass": {"retention_guard_pass", "retention_check", "retention"},
    "provider_live_or_honest_inactive": {
        "provider_live_or_honest_inactive",
        "provider_status",
        "provider",
    },
    "metacognition_action_resolved": {
        "metacognition_action_resolved",
        "metacognition",
        "clarification",
    },
    "workspace_critique_passed": {
        "workspace_critique_passed",
        "workspace_critique",
        "critique",
    },
    "self_improve_reward_pass": {
        "self_improve_reward_pass",
        "self_improve_reward",
        "selfimprove_reward",
    },
    "self_improve_safety_verified": {
        "self_improve_safety_verified",
        "selfimprove_safety",
        "verify_safety",
    },
    "judgment_overlay_guard": {
        "judgment_overlay_guard",
        "judgment_overlay",
        "judgment",
    },
}


class GateEvaluator:
    def __init__(
        self,
        store: Any,
        *,
        fingerprint_provider: FingerprintProvider | None = None,
        session_resolver: SessionResolver | None = None,
    ) -> None:
        self.store = store
        self.fingerprint_provider = fingerprint_provider
        self.session_resolver = session_resolver

    def evaluate(
        self,
        task_session_id: str,
        gates: list[str],
        *,
        pack_id: str | None = None,
    ) -> dict[str, dict[str, Any]]:
        plan = self.store.latest_task_plan_for_session(task_session_id)
        results: dict[str, dict[str, Any]] = {}
        current_fingerprint = (
            self.fingerprint_provider() if self.fingerprint_provider else None
        )
        for gate in gates:
            if gate == "preflight_ready":
                results[gate] = self._status(
                    "pass", "task_session", detail="task session and pack were created"
                )
            elif gate == "plan_active":
                results[gate] = self._status(
                    "pass" if plan else "pending",
                    "task_plans",
                    plan_id=plan["plan_id"] if plan else None,
                )
            elif gate == "checkpoints_present":
                results[gate] = self._checkpoints(plan)
            elif gate in {"check_diff_clean", "dirty_set_in_scope"}:
                results[gate] = self._volatile_gate(
                    task_session_id,
                    plan["plan_id"] if plan else None,
                    gate,
                    current_fingerprint,
                )
            elif gate in {"tests_pass", "security_scan_pass", "release_validated"}:
                results[gate] = self._verification_gate(task_session_id, plan, gate)
            elif gate == "outcome_recorded":
                results[gate] = self._outcome_gate(task_session_id, pack_id)
            elif gate in FLYWHEEL_GATE_NAMES:
                results[gate] = self._named_verification_gate(
                    task_session_id, plan, gate
                )
            else:
                results[gate] = self._status("pending", "unknown_gate")
            results[gate]["kind"] = GATE_KINDS.get(gate, "durable")
        return results

    def record_volatile_gate(
        self,
        *,
        task_session_id: str,
        plan_id: str | None,
        gate_id: str,
        command: str,
        status: str,
        report: dict[str, Any],
        fingerprint: dict[str, Any],
    ) -> dict[str, Any]:
        payload = {
            **report,
            "schema_version": "ctxlayer.workflow_gate_observation.v1",
            "gate_id": gate_id,
            "fingerprint": fingerprint,
        }
        return self.store.write_task_verification(
            task_session_id=task_session_id,
            plan_id=plan_id,
            name=f"workflow:{gate_id}",
            command=command,
            status=status,
            report=payload,
        )

    def _checkpoints(self, plan: Any) -> dict[str, Any]:
        if not plan:
            return self._status("pending", "task_plan_checkpoints")
        checkpoints = self.store.task_plan_checkpoints(plan["plan_id"])
        passed = [row for row in checkpoints if str(row["status"]) == "pass"]
        return self._status(
            "pass" if passed else "pending",
            "task_plan_checkpoints",
            plan_id=plan["plan_id"],
            count=len(passed),
        )

    def _verification_gate(
        self, task_session_id: str, plan: Any, gate: str
    ) -> dict[str, Any]:
        plan_id = plan["plan_id"] if plan else None
        rows = self.store.task_verifications(
            task_session_id=task_session_id, plan_id=plan_id
        )
        names = _gate_verification_names(gate)
        candidates = [
            row
            for row in rows
            if not str(row["name"]).startswith("workflow:")
            and (not names or str(row["name"]) in names)
        ]
        if not candidates and gate == "tests_pass":
            candidates = [
                row for row in rows if not str(row["name"]).startswith("workflow:")
            ]
        if not candidates:
            return self._status("pending", "task_verifications", plan_id=plan_id)
        latest = candidates[0]
        status = "pass" if str(latest["status"]) == "pass" else "fail"
        return self._status(
            status,
            "task_verifications",
            plan_id=plan_id,
            verification_id=latest["verification_id"],
            name=latest["name"],
        )

    def _named_verification_gate(
        self, task_session_id: str, plan: Any, gate: str
    ) -> dict[str, Any]:
        plan_id = plan["plan_id"] if plan else None
        rows = self.store.task_verifications(
            task_session_id=task_session_id, plan_id=plan_id
        )
        names = FLYWHEEL_GATE_NAMES[gate]
        for row in rows:
            name = str(row["name"])
            if name == gate or name in names or name == f"workflow:{gate}":
                status = "pass" if str(row["status"]) == "pass" else "fail"
                return self._status(
                    status,
                    "task_verifications",
                    plan_id=plan_id,
                    verification_id=row["verification_id"],
                    name=name,
                    remediation=(
                        None if status == "pass" else _flywheel_remediation(gate)
                    ),
                )
        return self._status(
            "pending",
            "task_verifications",
            plan_id=plan_id,
            remediation=_flywheel_remediation(gate),
        )

    def _volatile_gate(
        self,
        task_session_id: str,
        plan_id: str | None,
        gate: str,
        current_fingerprint: dict[str, Any] | None,
    ) -> dict[str, Any]:
        rows = self.store.task_verifications(
            task_session_id=task_session_id, plan_id=plan_id
        )
        rows = [row for row in rows if str(row["name"]) == f"workflow:{gate}"]
        if not rows:
            return self._status("pending", "task_verifications", plan_id=plan_id)
        latest = rows[0]
        report = _json(latest["report_json"])
        fingerprint = report.get("fingerprint") if isinstance(report, dict) else None
        if current_fingerprint and fingerprint != current_fingerprint:
            return self._status(
                "stale",
                "task_verifications",
                plan_id=plan_id,
                verification_id=latest["verification_id"],
                fingerprint=fingerprint,
                current_fingerprint=current_fingerprint,
            )
        status = "pass" if str(latest["status"]) == "pass" else "fail"
        return self._status(
            status,
            "task_verifications",
            plan_id=plan_id,
            verification_id=latest["verification_id"],
            fingerprint=fingerprint,
        )

    def _outcome_gate(
        self, task_session_id: str, pack_id: str | None
    ) -> dict[str, Any]:
        if pack_id and hasattr(self.store, "conn"):
            row = self.store.conn.execute(
                """
                SELECT * FROM outcomes
                WHERE pack_id = ?
                ORDER BY created_at DESC, outcome_id
                LIMIT 1
                """,
                (pack_id,),
            ).fetchone()
            if row:
                status = (
                    "pass"
                    if str(row["result"]).lower() in {"pass", "passed", "ok", "success"}
                    else "fail"
                )
                return self._status(
                    status,
                    "outcomes",
                    outcome_id=row["outcome_id"],
                    pack_id=pack_id,
                )
        if self.session_resolver:
            session_id = self.session_resolver(task_session_id)
            if session_id:
                for artifact in self.store.agent_session_artifacts(session_id):
                    if artifact["artifact_type"] == "outcome":
                        return self._status(
                            "pass", "agent_session_artifacts", ref=artifact["ref"]
                        )
        return self._status("pending", "outcomes", pack_id=pack_id)

    @staticmethod
    def _status(status: str, source: str, **extra: Any) -> dict[str, Any]:
        return {
            "status": "pending" if status == "stale" else status,
            "raw_status": status,
            "source": source,
            "kind": GATE_KINDS.get(str(extra.get("gate_id") or ""), "durable"),
            **{key: value for key, value in extra.items() if value is not None},
        }


def _gate_verification_names(gate: str) -> set[str]:
    return {
        "tests_pass": {"pytest", "tests", "test", "verification"},
        "security_scan_pass": {"security_scan", "security scan", "security"},
        "release_validated": {"release_validate", "release validate", "release"},
    }.get(gate, set())


def _flywheel_remediation(gate: str) -> str:
    return {
        "bench_reward_recorded": "Run and persist the Track 0 reward ledger before completing this workflow.",
        "retention_guard_pass": "Run retention_check and persist passing evidence for the active benchmark/config hash.",
        "provider_live_or_honest_inactive": "Record provider_status evidence showing a usable provider or an honest inactive reason.",
        "metacognition_action_resolved": "Resolve the emitted metacognitive action or persist a governed skip reason.",
        "workspace_critique_passed": "Run the workspace critique loop for the risky write and persist the result.",
        "self_improve_reward_pass": "Evaluate the proposal in sandbox against reward and retention gates before adoption.",
        "self_improve_safety_verified": "Run selfimprove verify-safety with a logged human/operator action before modes 3-4.",
        "judgment_overlay_guard": "Verify judgment/narrative/world-model output only biases within the retrieved pool.",
    }[gate]


def _json(value: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def fingerprint_id(fingerprint: dict[str, Any]) -> str:
    return canonical_json(fingerprint)
