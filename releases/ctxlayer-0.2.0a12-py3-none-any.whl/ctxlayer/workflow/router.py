from __future__ import annotations

from fnmatch import fnmatch
from pathlib import Path
import re
import shlex
from typing import Any

from ctxlayer.workflow.classifier import classify, infer_mode
from ctxlayer.workflow.feature_catalog import (
    FEATURE_CATALOG,
    WORKFLOW_RECOMMEND_SCHEMA,
    template_params,
)
from ctxlayer.workflow.playbook import FEATURE_COVERAGE, GATE_KINDS, PLAYBOOK

RESOLVABLE_PARAMS = {
    "task",
    "task_session_id",
    "pack_id",
    "plan_id",
    "paths",
    "capabilities",
    "intent_id",
    "goal_id",
}

FREEFORM_COMMAND_TEMPLATES = {
    "<run impact-recommended tests>",
}

CTXLAYER_COMMAND_CONTRACT: dict[str, set[str] | None] = {
    "agent": {"route"},
    "anticipate": {"consult"},
    "architecture": {"infer"},
    "check-diff": None,
    "cie": {"status"},
    "db": {"backend-status", "bench"},
    "decision": {"start"},
    "gc": None,
    "graph": {"neighbors"},
    "impact": None,
    "maintenance": {"run"},
    "memory": {"dream", "graph", "prefetch", "recall", "sleep"},
    "outcome": None,
    "pack": None,
    "plan": {"checkpoint", "create"},
    "release": {"validate"},
    "retention": {"set"},
    "security": {"scan"},
    "selfimprove": {"status"},
    "semantic": {"search"},
    "storage-report": None,
    "workflow": {"next"},
}


class WorkflowRouter:
    def recommend(
        self,
        *,
        task: str,
        mode: str = "write",
        paths: list[str] | None = None,
        capabilities: list[str] | None = None,
        intent_id: str | None = None,
        goal_id: str | None = None,
        impact_report: dict[str, Any] | None = None,
        task_session_id: str | None = None,
        pack_id: str | None = None,
        plan_id: str | None = None,
        signals: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        paths = sorted({path.replace("\\", "/") for path in paths or [] if path})
        capabilities = sorted({item for item in capabilities or [] if item})
        risk_score = _risk_score(impact_report)
        normalized_mode = infer_mode(task, mode)
        task_types = classify(
            task,
            paths=paths,
            capabilities=capabilities,
            mode=normalized_mode,
            impact_risk=risk_score,
        )
        required_ids = _collect(task_types, "required_features")
        optional_ids = _collect(task_types, "optional_features")
        optional_ids = [item for item in optional_ids if item not in required_ids]
        overlay = _adopted_overlay(signals or {})
        required_ids, optional_ids, adapted_features = _apply_overlay(
            required_ids, optional_ids, overlay
        )
        gates = _gates(task_types)
        context = {
            "task": task,
            "paths": paths,
            "capabilities": capabilities,
            "intent_id": intent_id,
            "goal_id": goal_id,
            "task_session_id": task_session_id,
            "pack_id": pack_id,
            "plan_id": plan_id,
        }
        escalation = _escalation(task_types, paths, risk_score)
        required_features = [
            _feature(
                feature_id,
                context,
                task_types,
                classification="required",
                evidence=adapted_features.get(feature_id),
            )
            for feature_id in required_ids
        ]
        optional_features = [
            _feature(
                feature_id,
                context,
                task_types,
                classification="optional",
                evidence=adapted_features.get(feature_id),
            )
            for feature_id in optional_ids
        ]
        lifecycle = _lifecycle_groups(
            required_features + optional_features,
            {
                "mode": normalized_mode,
                "task_types": task_types,
                "paths": paths,
                "risk_score": risk_score,
                "signals": signals or {},
            },
        )
        return {
            "ok": True,
            "schema_version": WORKFLOW_RECOMMEND_SCHEMA,
            "task": task,
            "mode": normalized_mode,
            "paths": paths,
            "capabilities": capabilities,
            "intent_id": intent_id,
            "goal_id": goal_id,
            "task_types": task_types,
            "required_features": required_features,
            "optional_features": optional_features,
            **lifecycle,
            "gates": [
                {"gate_id": gate, "kind": GATE_KINDS.get(gate, "durable")}
                for gate in gates
            ],
            "escalation": escalation,
            "stop_when": _stop_when(task_types),
            "signals": signals or {},
            "adapted": bool(adapted_features),
        }

    def lint(self) -> dict[str, Any]:
        errors: list[str] = []
        for feature_id, feature in FEATURE_CATALOG.items():
            coverage = FEATURE_COVERAGE.get(feature_id)
            if not coverage:
                errors.append(f"feature {feature_id} lacks coverage classification")
            elif not coverage.get("reason"):
                errors.append(f"feature {feature_id} coverage lacks reason")
            params = template_params(feature["command_template"])
            required_params = set(feature.get("required_params", []))
            missing_contract = (
                params - set(feature.get("optional_params", [])) - required_params
            )
            if missing_contract:
                errors.append(
                    f"feature {feature_id} template params missing from param contract: "
                    f"{', '.join(sorted(missing_contract))}"
                )
            unresolved = required_params - RESOLVABLE_PARAMS
            if unresolved:
                errors.append(
                    f"feature {feature_id} required params are not router-resolvable: "
                    f"{', '.join(sorted(unresolved))}"
                )
            activation = feature.get("activation")
            if not isinstance(activation, dict):
                errors.append(f"feature {feature_id} lacks activation")
            else:
                trigger = activation.get("trigger")
                condition = activation.get("condition")
                if trigger not in {
                    "session_start",
                    "pre_write",
                    "pre_complete",
                    "on_demand",
                }:
                    errors.append(
                        f"feature {feature_id} has unknown activation trigger"
                    )
                if not isinstance(condition, str) or not condition:
                    errors.append(f"feature {feature_id} activation lacks condition")
            mcp_tool = str(feature.get("mcp_tool") or "")
            if mcp_tool and mcp_tool not in _registered_mcp_tools():
                errors.append(
                    f"feature {feature_id} references missing MCP tool {mcp_tool}"
                )
            errors.extend(
                f"feature {feature_id} {error}"
                for error in validate_command_template(feature["command_template"])
            )
        referenced = {
            feature_id
            for entry in PLAYBOOK.values()
            for key in ("required_features", "optional_features")
            for feature_id in entry.get(key, [])
        }
        unknown = referenced - set(FEATURE_CATALOG)
        if unknown:
            errors.append(
                f"playbook references unknown features: {', '.join(sorted(unknown))}"
            )
        return {
            "ok": not errors,
            "schema_version": "ctxlayer.workflow_lint.v1",
            "errors": errors,
            "feature_count": len(FEATURE_CATALOG),
            "task_type_count": len(PLAYBOOK),
            "memory_tier_complete": _memory_tier_complete(),
        }


def validate_command_template(command_template: str) -> list[str]:
    template = command_template.strip()
    if template in FREEFORM_COMMAND_TEMPLATES:
        return []
    if template.startswith("<") and template.endswith(">"):
        return [f"uses unallowlisted free-form command template {template!r}"]
    try:
        ctxlayer = _ctxlayer_tokens(template)
    except ValueError as exc:
        return [f"has unparsable command template: {exc}"]
    if not ctxlayer:
        return []
    command = _first_command_token(ctxlayer)
    if command is None:
        return ["ctxlayer command template has no command"]
    command_name, command_index = command
    allowed_subcommands = CTXLAYER_COMMAND_CONTRACT.get(command_name)
    if command_name not in CTXLAYER_COMMAND_CONTRACT:
        return [f"references unknown ctxlayer command {command_name!r}"]
    if allowed_subcommands is None:
        return []
    subcommand = _first_subcommand_token(ctxlayer[command_index + 1 :])
    if subcommand is None:
        return [f"ctxlayer command {command_name!r} is missing a subcommand"]
    if subcommand not in allowed_subcommands:
        return [f"references unknown ctxlayer subcommand {command_name} {subcommand!r}"]
    return []


def _ctxlayer_tokens(command_template: str) -> list[str]:
    tokens = shlex.split(command_template, posix=False)
    if "ctxlayer" not in tokens:
        return []
    return tokens[tokens.index("ctxlayer") :]


def _first_command_token(tokens: list[str]) -> tuple[str, int] | None:
    index = 1
    while index < len(tokens):
        token = tokens[index]
        if token == "|":
            return None
        if token == "--repo":
            index += 2
            continue
        if token.startswith("--"):
            index += 1
            continue
        return token, index
    return None


def _first_subcommand_token(tokens: list[str]) -> str | None:
    index = 0
    while index < len(tokens):
        token = tokens[index]
        if token == "|":
            return None
        if token.startswith("-"):
            if index + 1 < len(tokens) and not tokens[index + 1].startswith("-"):
                index += 2
            else:
                index += 1
            continue
        return token
    return None


def _collect(task_types: list[str], key: str) -> list[str]:
    values: list[str] = []
    for task_type_id in task_types:
        for feature_id in PLAYBOOK[task_type_id].get(key, []):
            if feature_id not in values:
                values.append(feature_id)
    return values


def _gates(task_types: list[str]) -> list[str]:
    values: list[str] = []
    for task_type_id in task_types:
        for gate_id in PLAYBOOK[task_type_id].get("gates", []):
            if gate_id not in values:
                values.append(gate_id)
    return values


def _feature(
    feature_id: str,
    context: dict[str, Any],
    task_types: list[str],
    *,
    classification: str,
    evidence: dict[str, Any] | None = None,
) -> dict[str, Any]:
    entry = FEATURE_CATALOG[feature_id]
    command, missing = _render_command(entry["command_template"], context)
    feature = {
        "feature_id": feature_id,
        "classification": classification,
        "command": command,
        "mcp_tool": entry["mcp_tool"],
        "why": entry["purpose"],
        "gate_kind": entry["gate_kind"],
        "activation": dict(entry.get("activation") or {}),
        "required_params": entry.get("required_params", []),
        "optional_params": entry.get("optional_params", []),
        "unresolved_params": missing,
        "remediation": _remediation(feature_id, missing) if missing else None,
        "task_types": [
            item
            for item in task_types
            if feature_id in PLAYBOOK[item].get("required_features", [])
            or feature_id in PLAYBOOK[item].get("optional_features", [])
        ],
    }
    if evidence:
        feature["evidence"] = evidence
    return feature


def _lifecycle_groups(
    features: list[dict[str, Any]], context: dict[str, Any]
) -> dict[str, list[dict[str, Any]]]:
    groups = {
        "now": [],
        "before_writing": [],
        "before_complete": [],
        "on_demand": [],
    }
    trigger_map = {
        "session_start": "now",
        "pre_write": "before_writing",
        "pre_complete": "before_complete",
        "on_demand": "on_demand",
    }
    for feature in features:
        activation = feature.get("activation") or {}
        if not _condition_matches(str(activation.get("condition") or ""), context):
            continue
        group = trigger_map.get(str(activation.get("trigger") or "on_demand"))
        if group:
            groups[group].append(feature)
    return groups


def _condition_matches(condition: str, context: dict[str, Any]) -> bool:
    if condition in {"", "always", "manual"}:
        return True
    mode = str(context.get("mode") or "")
    task_types = set(context.get("task_types") or [])
    paths = list(context.get("paths") or [])
    risk_score = float(context.get("risk_score") or 0.0)
    critical = any(
        fnmatch(path, pattern)
        for path in paths
        for pattern in (
            "**/auth/**",
            "**/billing/**",
            "**/migrations/**",
            "**/security/**",
        )
    )
    checks = {
        "write_mode": mode == "write",
        "investigation": "investigation" in task_types,
        "architecture_task": "architecture_change" in task_types,
        "architecture_or_decision": bool(
            task_types & {"architecture_change", "decision"}
        ),
        "security_change": "security_change" in task_types,
        "release_task": "release" in task_types,
        "memory_task": "memory_curation" in task_types,
        "maintenance_lane": "maintenance_ops" in task_types,
        "risk_high_or_critical_path": risk_score >= 7.0 or critical,
        "has_task_session": bool((context.get("signals") or {}).get("task_session_id")),
        "has_prior_context": True,
        "prefetch_enabled": True,
    }
    return bool(checks.get(condition, False))


def _adopted_overlay(signals: dict[str, Any]) -> list[dict[str, Any]]:
    overlay = signals.get("governance_overlay") if isinstance(signals, dict) else None
    return overlay if isinstance(overlay, list) else []


def _apply_overlay(
    required_ids: list[str], optional_ids: list[str], overlay: list[dict[str, Any]]
) -> tuple[list[str], list[str], dict[str, dict[str, Any]]]:
    required = list(required_ids)
    optional = list(optional_ids)
    evidence: dict[str, dict[str, Any]] = {}
    for item in overlay:
        if str(item.get("status") or "adopted") != "adopted":
            continue
        feature_id = str(item.get("feature_id") or "")
        if feature_id not in FEATURE_CATALOG:
            continue
        change = str(item.get("change") or "")
        if change == "promote_to_required":
            if feature_id in optional:
                optional.remove(feature_id)
            if feature_id not in required:
                required.append(feature_id)
        elif change in {"demote_to_optional", "add_optional"}:
            if feature_id in required:
                required.remove(feature_id)
            if feature_id not in optional:
                optional.append(feature_id)
        elif change == "remove":
            required = [item for item in required if item != feature_id]
            optional = [item for item in optional if item != feature_id]
        evidence[feature_id] = {
            "proposal_id": item.get("proposal_id"),
            "adoption_id": item.get("adoption_id"),
            "change": change,
            "support": item.get("support"),
            "lift": item.get("lift"),
        }
    return required, optional, evidence


def _render_command(template: str, context: dict[str, Any]) -> tuple[str, list[str]]:
    missing = [
        param
        for param in sorted(template_params(template))
        if context.get(param) in (None, "", [])
    ]
    values = {
        key: (_format_value(value) if value not in (None, "", []) else f"<{key}>")
        for key, value in context.items()
    }
    return template.format(**values), missing


def _format_value(value: Any) -> str:
    if isinstance(value, list):
        return ",".join(str(item) for item in value)
    return str(value)


def _remediation(feature_id: str, missing: list[str]) -> str:
    return (
        f"Resolve {', '.join(missing)} before running {feature_id}; "
        "use workflow start or the prior CTX command output to fill the placeholder."
    )


def _risk_score(impact_report: dict[str, Any] | None) -> float:
    if not impact_report:
        return 0.0
    risk = impact_report.get("risk", {}) if isinstance(impact_report, dict) else {}
    try:
        return float(risk.get("score", 0.0) or 0.0)
    except (TypeError, ValueError):
        return 0.0


def _escalation(
    task_types: list[str], paths: list[str], risk_score: float
) -> dict[str, Any]:
    reasons: list[str] = []
    if risk_score >= 7.0:
        reasons.append(f"impact risk score {risk_score:g} >= 7")
    patterns = PLAYBOOK["standard_edit"]["escalate_when"]["touches"]
    touched = [
        path for path in paths if any(fnmatch(path, pattern) for pattern in patterns)
    ]
    if touched:
        reasons.append(f"critical path touched: {', '.join(touched[:5])}")
    if any(item in task_types for item in {"security_change", "data_migration"}):
        reasons.append("task type requires explicit escalation review")
    return {
        "triggered": bool(reasons),
        "reasons": reasons,
        "actions": ["route to review with ctxlayer agent route"] if reasons else [],
    }


def _stop_when(task_types: list[str]) -> list[str]:
    return [
        PLAYBOOK[item]["stop_when"]
        for item in task_types
        if PLAYBOOK[item].get("stop_when")
    ]


def _registered_mcp_tools() -> set[str]:
    path = Path(__file__).resolve().parents[1] / "server" / "mcp_server.py"
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return set()
    return set(re.findall(r"@mcp\.tool\(\)\s+def\s+([A-Za-z_][A-Za-z0-9_]*)", text))


def _memory_tier_complete() -> bool:
    required = {
        "memory_recall",
        "memory_graph_recall",
        "memory_prefetch",
        "memory_sleep",
    }
    return required.issubset(FEATURE_CATALOG)
