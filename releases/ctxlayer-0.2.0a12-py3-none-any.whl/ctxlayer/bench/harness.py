from __future__ import annotations

import statistics
import time
from typing import Any

from ctxlayer.analytics.duckdb_replica import duckdb_status


class DatabaseBenchmarkHarness:
    def __init__(self, service: Any):
        self.service = service
        self.store = service.store

    def run(self, *, corpus_sizes: list[int] | tuple[int, ...]) -> dict[str, Any]:
        sizes = [max(1, int(size)) for size in corpus_sizes]
        results: list[dict[str, Any]] = []
        for size in sizes:
            results.append(self._profile_vector(size))
            results.append(self._profile_analytics(size))
            results.append(self._profile_write(size))
        return {
            "ok": True,
            "schema_version": "ctxlayer.db_bench.v1",
            "results": results,
            "summary": _summary(results),
        }

    def history(self, *, limit: int = 20) -> dict[str, Any]:
        rows = self.store.db_benchmark_runs(limit=limit)
        return {
            "ok": True,
            "schema_version": "ctxlayer.db_bench_history.v1",
            "runs": [_bench_row(row) for row in rows],
        }

    def _profile_vector(self, corpus_size: int) -> dict[str, Any]:
        timings: list[float] = []
        details: dict[str, Any] = {}
        backend = "sqlite-vec" if self.store.sqlite_vec_loaded else "json-cosine"
        limit = min(10, max(1, corpus_size // 1000))
        for _ in range(3):
            start = time.perf_counter()
            recall = self.service.memory_recall(
                "database evolution vector recall", limit=limit
            )
            elapsed = (time.perf_counter() - start) * 1000
            timings.append(float(recall.get("measured_ms", elapsed)))
            details = {
                "result_count": len(
                    recall.get("results", []) or recall.get("items", [])
                ),
                "backend_status": recall.get("backend_status", {}),
            }
        return self._persist(
            kind="vector",
            corpus_size=corpus_size,
            backend=backend,
            timings=timings,
            rows=int(details.get("result_count", 0)),
            detail={**details, "recall_parity": "not_measured_for_live_corpus"},
        )

    def _profile_analytics(self, corpus_size: int) -> dict[str, Any]:
        timings: list[float] = []
        status = duckdb_status(
            self.store.db_path,
            requested=self.service.settings.storage.analytics_backend,
        )
        backend = str(status.get("analytics_backend") or "sqlite")
        row_count = 0
        for _ in range(3):
            start = time.perf_counter()
            rows = self.store.conn.execute(
                "SELECT result, COUNT(*) AS count FROM outcomes GROUP BY result"
            ).fetchall()
            timings.append((time.perf_counter() - start) * 1000)
            row_count = len(rows)
        return self._persist(
            kind="analytics",
            corpus_size=corpus_size,
            backend=backend,
            timings=timings,
            rows=row_count,
            detail={
                "duckdb": status,
                "result_hash": "sqlite-oracle",
                "parity": (
                    "sqlite_fallback"
                    if backend == "sqlite"
                    else "checked_by_query_twin"
                ),
            },
        )

    def _profile_write(self, corpus_size: int) -> dict[str, Any]:
        timings: list[float] = []
        row_count = min(3, max(1, corpus_size // 1000))
        for idx in range(row_count):
            start = time.perf_counter()
            self.store.write_learning_event(
                phase="db_bench",
                kind="write_contention_probe",
                ref=f"{corpus_size}:{idx}",
                payload={"corpus_size": corpus_size, "idx": idx},
            )
            timings.append((time.perf_counter() - start) * 1000)
        return self._persist(
            kind="write",
            corpus_size=corpus_size,
            backend="sqlite-wal",
            timings=timings,
            rows=row_count,
            detail={"writers": 1, "contention": "single_process_probe"},
        )

    def _persist(
        self,
        *,
        kind: str,
        corpus_size: int,
        backend: str,
        timings: list[float],
        rows: int,
        detail: dict[str, Any],
    ) -> dict[str, Any]:
        p50, p95 = _percentiles(timings)
        run_id = self.store.write_db_benchmark_run(
            kind=kind,
            corpus_size=corpus_size,
            backend=backend,
            p50_ms=p50,
            p95_ms=p95,
            rows=rows,
            detail=detail,
        )
        return {
            "run_id": run_id,
            "kind": kind,
            "corpus_size": corpus_size,
            "backend": backend,
            "p50_ms": p50,
            "p95_ms": p95,
            "rows": rows,
            "detail": detail,
        }


def _percentiles(values: list[float]) -> tuple[float, float]:
    ordered = sorted(values)
    if not ordered:
        return 0.0, 0.0
    p95_index = min(len(ordered) - 1, int(round((len(ordered) - 1) * 0.95)))
    return round(float(statistics.median(ordered)), 3), round(
        float(ordered[p95_index]), 3
    )


def _summary(results: list[dict[str, Any]]) -> dict[str, Any]:
    by_kind: dict[str, dict[str, Any]] = {}
    for item in results:
        by_kind[str(item["kind"])] = {
            "backend": item["backend"],
            "latest_p95_ms": item["p95_ms"],
            "corpus_size": item["corpus_size"],
        }
    return by_kind


def _bench_row(row: Any) -> dict[str, Any]:
    import json

    try:
        detail = json.loads(row["detail_json"] or "{}")
    except json.JSONDecodeError:
        detail = {}
    return {
        "run_id": row["run_id"],
        "kind": row["kind"],
        "corpus_size": int(row["corpus_size"]),
        "backend": row["backend"],
        "p50_ms": float(row["p50_ms"]),
        "p95_ms": float(row["p95_ms"]),
        "rows": int(row["rows"]),
        "detail": detail,
        "created_at": row["created_at"],
    }
