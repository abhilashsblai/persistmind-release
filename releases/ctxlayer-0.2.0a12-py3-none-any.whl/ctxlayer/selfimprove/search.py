from __future__ import annotations

from typing import Any


def run_archive_search(
    engine: Any, *, max_iters: int, budget_tokens: int
) -> dict[str, Any]:
    prereq = engine.prerequisites_ready()
    if not prereq["ok"]:
        return {
            "ok": False,
            "status": "blocked",
            "reason": "self_improve_prerequisites_not_ready",
            "prerequisites": prereq,
            "max_iters": max_iters,
            "budget_tokens": budget_tokens,
        }

    brief_result = engine.brief(force=True)
    if not brief_result.get("ok"):
        return {
            "ok": False,
            "status": "blocked",
            "reason": "self_improve_brief_failed",
            "brief": brief_result,
            "prerequisites": prereq,
            "max_iters": max_iters,
            "budget_tokens": budget_tokens,
        }

    run = brief_result.get("run") or {}
    run_id = run.get("run_id")
    proposed = _propose_from_brief(engine, brief_result, max_iters=max_iters)
    evaluated = _evaluate_existing_candidates(engine, run_id=run_id, max_iters=max_iters)
    adopted = _adopt_validated_candidates(
        engine,
        evaluated=evaluated,
        run_id=run_id,
        max_iters=max_iters,
        allow_full_auto=bool(prereq.get("full_auto_allowed")),
    )

    status = "adopted" if adopted else "evaluated" if evaluated else "proposed"
    if not proposed and not evaluated and not adopted:
        status = "no_candidates"
    if run_id:
        engine.store.update_self_improve_run_status(run_id, status)
    return {
        "ok": True,
        "status": status,
        "schema_version": "ctxlayer.self_improve_archive_search.v1",
        "run": run,
        "brief": brief_result.get("brief"),
        "proposed": proposed,
        "evaluated": evaluated,
        "adopted": adopted,
        "prerequisites": prereq,
        "full_auto_allowed": bool(prereq.get("full_auto_allowed")),
        "max_iters": max_iters,
        "budget_tokens": budget_tokens,
    }


def _propose_from_brief(
    engine: Any, brief_result: dict[str, Any], *, max_iters: int
) -> list[dict[str, Any]]:
    run = brief_result.get("run") or {}
    run_id = run.get("run_id")
    if not run_id:
        return []
    existing = engine.store.self_improve_proposals(run_id=run_id, limit=1)
    if existing:
        return []
    proposals: list[dict[str, Any]] = []
    for item in (brief_result.get("brief") or {}).get("items", [])[:max_iters]:
        target_files = _target_files_from_item(item)
        captured = engine.capture(
            title=str(item.get("title") or item.get("kind") or "Self-improvement item"),
            rationale=str(item.get("detail") or "Generated from self-improvement brief."),
            target_files=target_files,
            evidence={
                "source": "archive_search",
                "brief_item": item,
            },
            predicted_effect={
                "kind": item.get("kind"),
                "expected": "human-authored patch required",
            },
        )
        proposals.append(captured["proposal"])
    return proposals


def _evaluate_existing_candidates(
    engine: Any, *, run_id: str | None, max_iters: int
) -> list[dict[str, Any]]:
    if not run_id:
        return []
    rows = engine.store.self_improve_proposals(run_id=run_id, limit=max_iters * 4)
    evaluated: list[dict[str, Any]] = []
    for row in rows:
        proposal = engine.show(row["id"])["proposal"]
        if proposal.get("status") not in {"captured", "validated"}:
            continue
        if proposal.get("status") == "captured":
            result = engine.evaluate(proposal["proposal_id"])
            evaluated.append(result)
        else:
            evaluated.append({"ok": True, "proposal": proposal, "eval": proposal.get("eval")})
        if len(evaluated) >= max_iters:
            break
    return evaluated


def _adopt_validated_candidates(
    engine: Any,
    *,
    evaluated: list[dict[str, Any]],
    run_id: str | None,
    max_iters: int,
    allow_full_auto: bool,
) -> list[dict[str, Any]]:
    if not allow_full_auto:
        return []
    candidates = [item["proposal"] for item in evaluated if item.get("ok")]
    if not candidates and run_id:
        candidates = [
            engine.show(row["id"])["proposal"]
            for row in engine.store.self_improve_proposals(
                run_id=run_id, status="validated", limit=max_iters
            )
        ]
    adopted: list[dict[str, Any]] = []
    for proposal in candidates[:max_iters]:
        result = engine.adopt(proposal["proposal_id"])
        if result.get("ok"):
            adopted.append(result)
    return adopted


def _target_files_from_item(item: dict[str, Any]) -> list[str]:
    evidence = item.get("evidence") if isinstance(item.get("evidence"), dict) else {}
    paths = evidence.get("changed_paths") or evidence.get("target_files") or []
    if isinstance(paths, str):
        paths = [paths]
    return sorted({str(path).replace("\\", "/") for path in paths if str(path).strip()})
