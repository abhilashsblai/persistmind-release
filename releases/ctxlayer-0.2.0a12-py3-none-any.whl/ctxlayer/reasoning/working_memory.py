from __future__ import annotations

from typing import Any

from ctxlayer.utils import stable_id, utc_now


def note_manifest(row: Any) -> dict[str, Any]:
    return {
        "note_id": row["note_id"],
        "task_session_id": row["task_session_id"],
        "cycle_id": row["cycle_id"],
        "kind": row["kind"],
        "text": row["text"],
        "salience": round(float(row["salience"]), 4),
        "evidence_refs": _json_list(row["evidence_refs_json"]),
        "created_at": row["created_at"],
        "expires_at": row["expires_at"],
        "superseded_by": row["superseded_by"],
    }


class WorkingMemory:
    def __init__(self, store: Any):
        self.store = store

    def capture(
        self,
        *,
        task_session_id: str,
        text: str,
        kind: str = "observation",
        cycle_id: str | None = None,
        salience: float = 0.5,
        evidence_refs: list[dict[str, Any]] | None = None,
        expires_at: str | None = None,
    ) -> dict[str, Any]:
        if not task_session_id.strip():
            raise ValueError("task_session_id is required")
        clean_text = text.strip()
        if not clean_text:
            raise ValueError("text is required")
        note_id = stable_id(
            "working_memory_note",
            task_session_id,
            cycle_id or "",
            kind,
            clean_text,
            utc_now(),
        )
        row = self.store.write_working_memory_note(
            note_id=note_id,
            task_session_id=task_session_id,
            cycle_id=cycle_id,
            kind=kind,
            text=clean_text,
            salience=max(0.0, min(1.0, float(salience))),
            evidence_refs=evidence_refs or [],
            expires_at=expires_at,
        )
        return note_manifest(row)

    def list(
        self,
        *,
        task_session_id: str,
        cycle_id: str | None = None,
        limit: int = 64,
    ) -> list[dict[str, Any]]:
        return [
            note_manifest(row)
            for row in self.store.working_memory_notes(
                task_session_id=task_session_id,
                cycle_id=cycle_id,
                limit=max(1, int(limit)),
            )
        ]


def _json_list(value: Any) -> list[dict[str, Any]]:
    import json

    try:
        parsed = json.loads(value or "[]")
    except (TypeError, json.JSONDecodeError):
        return []
    if not isinstance(parsed, list):
        return []
    return [item for item in parsed if isinstance(item, dict)]
