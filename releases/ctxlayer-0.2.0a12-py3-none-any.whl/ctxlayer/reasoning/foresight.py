from __future__ import annotations

import subprocess
from collections import Counter
from pathlib import Path
from typing import Any


def cochange_foresight(
    repo_root: Path,
    *,
    paths: list[str],
    limit: int = 8,
    max_commits: int = 300,
    min_support: int = 1,
) -> dict[str, Any]:
    seeds = sorted({_normalize_path(path) for path in paths if str(path).strip()})
    if not seeds:
        return _empty("no_seed_paths")
    commits = _git_commit_paths(repo_root, max_commits=max_commits)
    if not commits:
        return _empty("no_git_history", seeds=seeds)

    seed_commits = [commit for commit in commits if set(commit) & set(seeds)]
    if not seed_commits:
        return _empty("no_seed_history", seeds=seeds)

    total_commits = len(commits)
    candidate_counts: Counter[str] = Counter()
    overall_counts: Counter[str] = Counter()
    for commit in commits:
        overall_counts.update(commit)
    for commit in seed_commits:
        candidate_counts.update(path for path in commit if path not in seeds)

    predictions = []
    for path, support in candidate_counts.most_common():
        if support < min_support:
            continue
        seed_rate = support / max(1, len(seed_commits))
        background_rate = overall_counts[path] / max(1, total_commits)
        lift = seed_rate / max(background_rate, 0.0001)
        predictions.append(
            {
                "path": path,
                "support": int(support),
                "seed_commits": len(seed_commits),
                "total_commits": total_commits,
                "confidence": round(min(1.0, seed_rate), 4),
                "lift": round(lift, 4),
                "reason": "cochanged_with_seed_paths",
            }
        )
        if len(predictions) >= max(1, int(limit)):
            break

    return {
        "ok": True,
        "schema_version": "ctxlayer.foresight.v1",
        "mode": "deterministic_git_cochange",
        "seed_paths": seeds,
        "history_commits": total_commits,
        "seed_commits": len(seed_commits),
        "predictions": predictions,
    }


def _git_commit_paths(repo_root: Path, *, max_commits: int) -> list[list[str]]:
    proc = subprocess.run(
        [
            "git",
            "log",
            f"--max-count={max(1, int(max_commits))}",
            "--name-only",
            "--format=format:CTX_COMMIT_BOUNDARY",
        ],
        cwd=repo_root,
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        return []
    commits: list[list[str]] = []
    current: list[str] = []
    for raw in proc.stdout.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line == "CTX_COMMIT_BOUNDARY":
            if current:
                commits.append(sorted(set(current)))
                current = []
            continue
        current.append(_normalize_path(line))
    if current:
        commits.append(sorted(set(current)))
    return commits


def _normalize_path(path: str) -> str:
    return str(path).replace("\\", "/").removeprefix("./").strip("/")


def _empty(reason: str, *, seeds: list[str] | None = None) -> dict[str, Any]:
    return {
        "ok": True,
        "schema_version": "ctxlayer.foresight.v1",
        "mode": "deterministic_git_cochange",
        "seed_paths": seeds or [],
        "history_commits": 0,
        "seed_commits": 0,
        "predictions": [],
        "reason": reason,
    }
