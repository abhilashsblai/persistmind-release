from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, TypedDict

from ctxlayer.audit.chain import manifest_hash
from ctxlayer.impact import ImpactEngine
from ctxlayer.memory import UnifiedMemory
from ctxlayer.snapshot import SnapshotInfo
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import stable_id, utc_now

from .assembly import DecisionAssembler
from .recommend import build_recommendation
from .scoring import score_option


class Score(TypedDict):
    value: float | None
    basis_evidence_refs: list[str]
    inputs_trust: list[str]


class Recommendation(TypedDict):
    option_id: str | None
    confidence: float
    rationale: str
    low_trust_inputs: list[dict[str, Any]]
    gaps: list[str]
    presented_as: str


class HumanDecision(TypedDict):
    chosen_option_id: str
    rationale: str
    decided_by: str
    decided_at: str
    agreed_with_recommendation: bool


class DecisionBriefing(TypedDict):
    schema_version: str
    decision_id: str
    question: str
    snapshot_id: str
    stale: bool
    options: list[dict[str, Any]]
    recommendation: Recommendation
    input_trust_summary: dict[str, int]
    briefing_hash: str


@dataclass(frozen=True)
class DecisionEngine:
    repo_root: Path
    store: SQLiteStore
    impact: ImpactEngine
    memory: UnifiedMemory
    workspace_id: str
    repo_id: str | None = None

    def start(
        self,
        *,
        question: str,
        options_seed: list[str] | None,
        seed_paths: list[str] | None,
        snapshot: SnapshotInfo,
    ) -> dict[str, Any]:
        question = question.strip()
        if not question:
            raise ValueError("decision question is required")
        options = _option_seeds(
            question, options_seed or [], seed_paths or [], snapshot
        )
        decision_id = stable_id(
            self.workspace_id, snapshot.repo_id, question, snapshot.snapshot_id
        )
        audit = self.store.append_audit(
            pack_id=decision_id,
            payload={
                "kind": "decision_started",
                "decision_id": decision_id,
                "question": question,
                "snapshot_id": snapshot.snapshot_id,
            },
        )
        row = self.store.create_decision(
            decision_id=decision_id,
            workspace_id=self.workspace_id,
            repo_id=snapshot.repo_id,
            question=question,
            snapshot_id=snapshot.snapshot_id,
            briefing={
                "schema_version": "ctxlayer.decision_briefing.v1",
                "decision_id": decision_id,
                "question": question,
                "snapshot_id": snapshot.snapshot_id,
                "seed_paths": seed_paths or [],
                "options": options,
                "recommendation": None,
            },
            audit=audit,
        )
        return {"ok": True, "decision": self._decision_view(row)}

    def analyze(self, decision_id: str, *, snapshot: SnapshotInfo) -> dict[str, Any]:
        row = self.store.get_decision(decision_id)
        if not row:
            raise KeyError(f"decision not found: {decision_id}")
        current = self._decision_view(row)
        briefing_seed = current.get("briefing") or {}
        assembled = DecisionAssembler(
            repo_root=self.repo_root,
            store=self.store,
            impact=self.impact,
            memory=self.memory,
        ).assemble(
            question=current["question"],
            options=briefing_seed.get("options") or [],
            seed_paths=briefing_seed.get("seed_paths") or [],
            snapshot=snapshot,
        )
        scored = [score_option(option) for option in assembled["options"]]
        recommendation = build_recommendation(scored)
        briefing: dict[str, Any] = {
            "schema_version": "ctxlayer.decision_briefing.v1",
            "decision_id": decision_id,
            "question": current["question"],
            "snapshot_id": snapshot.snapshot_id,
            "stale": False,
            "seed_paths": briefing_seed.get("seed_paths") or [],
            "options": scored,
            "recommendation": recommendation,
            "input_trust_summary": assembled["input_trust_summary"],
        }
        briefing["briefing_hash"] = manifest_hash(briefing)
        audit = self.store.append_audit(
            pack_id=decision_id,
            payload={
                "kind": "decision_analyzed",
                "decision_id": decision_id,
                "briefing_hash": briefing["briefing_hash"],
                "input_trust_summary": briefing["input_trust_summary"],
            },
        )
        updated = self.store.update_decision_briefing(
            decision_id, briefing=briefing, audit=audit
        )
        return {
            "ok": True,
            "decision": self._decision_view(updated),
            "briefing": briefing,
        }

    def record(
        self,
        decision_id: str,
        *,
        chosen_option_id: str,
        rationale: str,
        actor: str,
        snapshot: SnapshotInfo,
    ) -> dict[str, Any]:
        rationale = rationale.strip()
        if not chosen_option_id:
            raise ValueError("chosen_option_id is required")
        if not rationale:
            raise ValueError("rationale is required")
        row = self.store.get_decision(decision_id)
        if not row:
            raise KeyError(f"decision not found: {decision_id}")
        decision = self._decision_view(row)
        if decision["status"] != "analyzed":
            raise ValueError(
                "decision must be analyzed before recording a human decision"
            )
        briefing = decision.get("briefing") or {}
        if briefing.get("snapshot_id") != snapshot.snapshot_id:
            raise ValueError("decision briefing is stale; re-analyze before recording")
        options = briefing.get("options") or []
        chosen = next(
            (option for option in options if option.get("id") == chosen_option_id), None
        )
        if chosen is None:
            raise ValueError(f"chosen option does not exist: {chosen_option_id}")
        recommendation = briefing.get("recommendation") or {}
        human_decision: dict[str, Any] = {
            "chosen_option_id": chosen_option_id,
            "chosen_statement": chosen.get("statement"),
            "rationale": rationale,
            "decided_by": actor,
            "decided_at": utc_now(),
            "agreed_with_recommendation": chosen_option_id
            == recommendation.get("option_id"),
            "briefing_hash": briefing.get("briefing_hash"),
        }
        memory = self._write_decision_memory(
            decision=decision,
            briefing=briefing,
            human_decision=human_decision,
            actor=actor,
        )
        human_decision["memory_record_id"] = (memory.get("record") or {}).get(
            "record_id"
        )
        audit = self.store.append_audit(
            pack_id=decision_id,
            payload={
                "kind": "decision_recorded",
                "decision_id": decision_id,
                "chosen_option_id": chosen_option_id,
                "decided_by": actor,
                "agreed_with_recommendation": human_decision[
                    "agreed_with_recommendation"
                ],
                "human_decision_hash": manifest_hash(human_decision),
            },
        )
        updated = self.store.set_decision_human_decision(
            decision_id,
            human_decision=human_decision,
            audit=audit,
        )
        self.store.write_learning_event(
            phase="B3",
            kind="decision_recorded",
            ref=decision_id,
            payload={
                "agreed_with_recommendation": human_decision[
                    "agreed_with_recommendation"
                ],
                "recommendation_confidence": recommendation.get("confidence"),
            },
        )
        return {
            "ok": True,
            "decision": self._decision_view(updated),
            "human_decision": human_decision,
            "audit": audit,
            "memory": memory,
        }

    def show(
        self, decision_id: str, *, snapshot: SnapshotInfo | None = None
    ) -> dict[str, Any]:
        row = self.store.get_decision(decision_id)
        if not row:
            raise KeyError(f"decision not found: {decision_id}")
        decision = self._decision_view(row)
        if snapshot is not None:
            decision["stale"] = bool(
                decision.get("snapshot_id")
                and decision["snapshot_id"] != snapshot.snapshot_id
            )
            if decision.get("briefing"):
                decision["briefing"]["stale"] = decision["stale"]
        return {"ok": True, "decision": decision}

    def list(self, *, status: str | None = None, limit: int = 50) -> dict[str, Any]:
        rows = self.store.list_decisions(
            workspace_id=self.workspace_id,
            repo_id=self.repo_id,
            status=status,
            limit=limit,
        )
        return {
            "ok": True,
            "decisions": [
                self._decision_view(row, include_briefing=False) for row in rows
            ],
        }

    def reconsider(
        self,
        *,
        question: str,
        snapshot: SnapshotInfo,
        seed_paths: list[str] | None = None,
        trigger: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        options = _option_seeds(
            question,
            ["continue with current plan", "pause and replan", "gather more context"],
            seed_paths or [],
            snapshot,
        )
        decision_id = stable_id(
            self.workspace_id,
            snapshot.repo_id,
            "reconsider",
            question,
            snapshot.snapshot_id,
            json.dumps(trigger or {}, sort_keys=True),
        )
        briefing: dict[str, Any] = {
            "schema_version": "ctxlayer.decision_reconsideration.v1",
            "decision_id": decision_id,
            "question": question,
            "snapshot_id": snapshot.snapshot_id,
            "seed_paths": seed_paths or [],
            "trigger": trigger or {},
            "options": options,
            "recommendation": {
                "option_id": options[1]["id"] if len(options) > 1 else None,
                "confidence": 0.75,
                "rationale": "High-surprise checkpoint requires a live replan consideration.",
                "low_trust_inputs": [],
                "gaps": [],
                "presented_as": "advisory",
            },
        }
        briefing["briefing_hash"] = manifest_hash(briefing)
        audit = self.store.append_audit(
            pack_id=decision_id,
            payload={
                "kind": "decision_reconsidered",
                "decision_id": decision_id,
                "briefing_hash": briefing["briefing_hash"],
                "trigger": trigger or {},
            },
        )
        existing = self.store.get_decision(decision_id)
        if existing is None:
            self.store.create_decision(
                decision_id=decision_id,
                workspace_id=self.workspace_id,
                repo_id=snapshot.repo_id,
                question=question,
                snapshot_id=snapshot.snapshot_id,
                briefing=briefing,
                audit=audit,
            )
        row = self.store.update_decision_briefing(
            decision_id,
            briefing=briefing,
            audit=audit,
        )
        self.store.write_learning_event(
            phase="C2",
            kind="checkpoint_reconsideration",
            ref=decision_id,
            payload={
                "question": question,
                "snapshot_id": snapshot.snapshot_id,
                "trigger": trigger or {},
                "briefing_hash": briefing["briefing_hash"],
            },
        )
        return {
            "ok": True,
            "decision_id": decision_id,
            "decision": self._decision_view(row),
            "briefing": briefing,
            "audit": audit,
        }

    def _write_decision_memory(
        self,
        *,
        decision: dict[str, Any],
        briefing: dict[str, Any],
        human_decision: dict[str, Any],
        actor: str,
    ) -> dict[str, Any]:
        alternatives = [
            option.get("statement")
            for option in briefing.get("options") or []
            if option.get("id") != human_decision["chosen_option_id"]
        ]
        assertion = (
            f"Decision: {decision['question']} -> "
            f"{human_decision.get('chosen_statement') or human_decision['chosen_option_id']}"
        )
        return self.memory.create_typed(
            {
                "type": "decision",
                "assertion": assertion,
                "title": decision["question"],
                "source_kind": "manual",
                "confidence": 1.0,
                "importance": 1.0,
                "status": "active",
                "trust": "human_verified",
                "metadata": {
                    "rationale": human_decision["rationale"],
                    "alternatives": [item for item in alternatives if item],
                    "decision_id": decision["decision_id"],
                    "briefing_hash": briefing.get("briefing_hash"),
                },
                "provenance": {
                    "generator": "human",
                    "validator": actor,
                    "input_source": "decision_support",
                    "validated_at": human_decision["decided_at"],
                },
                "evidence": [
                    {
                        "ref": decision["decision_id"],
                        "evidence_kind": "decision_briefing",
                        "source_type": "decision_briefing",
                        "evidence_hash": briefing.get("briefing_hash")
                        or manifest_hash(briefing),
                    }
                ],
            }
        )

    def _decision_view(
        self, row: Any, *, include_briefing: bool = True
    ) -> dict[str, Any]:
        briefing = _json_obj(row["briefing_json"])
        human_decision = (
            _json_obj(row["human_decision_json"])
            if row["human_decision_json"]
            else None
        )
        view = {
            "decision_id": row["decision_id"],
            "workspace_id": row["workspace_id"],
            "repo_id": row["repo_id"],
            "question": row["question"],
            "status": row["status"],
            "snapshot_id": row["snapshot_id"],
            "human_decision": human_decision,
            "audit_hash": row["audit_hash"],
            "prev_audit_hash": row["prev_audit_hash"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }
        if include_briefing:
            view["briefing"] = briefing
        else:
            recommendation = (
                briefing.get("recommendation") if isinstance(briefing, dict) else None
            )
            view["recommendation"] = recommendation
        return view


def _option_seeds(
    question: str,
    options_seed: list[str],
    seed_paths: list[str],
    snapshot: SnapshotInfo,
) -> list[dict[str, Any]]:
    statements = [item.strip() for item in options_seed if item and item.strip()]
    if not statements:
        statements = [question]
    options = []
    for index, statement in enumerate(statements, start=1):
        option_id = stable_id(snapshot.repo_id, question, index, statement)[:16]
        options.append(
            {
                "id": option_id,
                "statement": statement,
                "seed_paths": sorted({path.replace("\\", "/") for path in seed_paths}),
            }
        )
    return options


def _json_obj(value: str | None) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}
