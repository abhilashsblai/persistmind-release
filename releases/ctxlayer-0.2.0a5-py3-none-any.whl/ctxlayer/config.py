from __future__ import annotations

import fnmatch
import tomllib
from dataclasses import fields
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class ToolchainConfig:
    workspace_dir: str = ".ctxlayer"
    project_label: str | None = (
        None  # opaque-friendly human label for cross-project rollups
    )
    indexer_version: str = "ctxlayer-0.1"
    parser_bundle_version: str = "stdlib-parsers-0.1"
    chunker_version: str = "symbol-chunker-0.1"
    embed_model: str = "local-lexical-v1"
    parser_backend: str = "auto"  # auto|stdlib|tree-sitter
    embed_backend: str = "auto"  # auto|local|sentence-transformers
    vector_backend: str = "auto"  # auto|json|sqlite-vec
    vector_encoding: str = "f32"  # json|f32|i8


@dataclass(frozen=True)
class PackConfig:
    default_budget_tokens: int = 12_000
    max_file_tokens: int = 3_000
    implementation_quota: float = 0.7
    test_quota: float = 0.2
    constraint_quota: float = 0.1


@dataclass(frozen=True)
class RetrievalConfig:
    lexical_weight: float = 1.0
    vector_weight: float = 0.9
    graph_weight: float = 0.8
    history_weight: float = 0.25


@dataclass(frozen=True)
class AuditConfig:
    store_task_text: bool = False
    retain_dirty_blobs: bool = False
    retention_keep_days: int = 180
    retention_keep_abandoned_days: int = 30
    retention_keep_merged: bool = True


@dataclass(frozen=True)
class MaintenanceConfig:
    max_audit_age_days: int = 180
    max_sessions: int = 500
    keep_snapshots: int = 5
    keep_snapshots_per_repo: int = 3
    max_session_events: int = 2000
    db_warn_bytes: int = 1_000_000_000
    wal_warn_bytes: int = 256_000_000
    auto: bool = True
    auto_gc_on_degraded: bool = False
    maintenance_interval_hours: int = 24
    daemon_tick: bool = False
    opportunistic: bool = True
    compact_into_threshold_bytes: int = 1_000_000_000
    compact_min_free_ratio: float = 0.10
    max_auto_delete_fraction: float = 0.50
    pack_keep_full_days: int = 14


@dataclass(frozen=True)
class ReliabilityConfig:
    memory_recall_budget_ms: int = 300
    enforcement_status_budget_ms: int = 200
    doctor_budget_ms: int = 500


@dataclass(frozen=True)
class GuardrailsConfig:
    enabled: bool = True
    mode: str = "warn"
    block_requires_approval: bool = True
    block_min_severity: str = "high"
    min_block_confidence: float = 0.7
    content_match_required_for_block: bool = True
    critical_fail_closed: bool = False
    llm_judge: bool = False
    llm_judge_min_severity: str = "high"
    plan_time_check: bool = True
    override_audit_required: bool = True
    derive_on_consolidation: bool = True


@dataclass(frozen=True)
class GovernanceConfig:
    require_healthy_ctx: bool = False
    governed_classes: dict[str, list[str]] = field(
        default_factory=lambda: {
            "production_deploy": ["verify-production-assets"],
        }
    )


@dataclass(frozen=True)
class EvalConfig:
    ignore_globs: list[str] = field(
        default_factory=lambda: [
            "**/node_modules/**",
            "**/.git/**",
            "**/.ctxlayer/**",
            "**/__pycache__/**",
            "**/.pytest_cache/**",
        ]
    )
    critical_paths: list[str] = field(
        default_factory=lambda: [
            "**/auth/**",
            "**/billing/**",
            "**/payments/**",
            "**/migrations/**",
        ]
    )
    train_ratio: float = 0.7
    replay_limit: int = 50
    provider: str = "git"  # git|github|gitlab
    provider_project: str | None = None


@dataclass(frozen=True)
class ShardingConfig:
    lazy_embed_globs: list[str] = field(default_factory=list)
    cold_path_globs: list[str] = field(default_factory=list)
    max_file_bytes: int = 1_000_000


@dataclass(frozen=True)
class CIConfig:
    mode: str = "warn"  # warn|fail|strict
    require_pack: bool = True
    require_impact_report: bool = True
    require_selected_tests: bool = True
    allow_out_of_pack_with_label: str = "ctxlayer-approved"
    critical_paths_fail_closed: bool = True
    critical_paths: list[str] = field(
        default_factory=lambda: [
            "src/auth/**",
            "src/billing/**",
            "src/payments/**",
            "migrations/**",
        ]
    )
    business_rules_enabled: bool = True
    fail_on_high_risk_rule_changes: bool = True
    require_codeowner_for_rule_scope: bool = True
    warn_on_stale_rules: bool = True
    block_on_conflicting_rules: bool = False


@dataclass(frozen=True)
class ServerConfig:
    mode: str = "local"  # local|team
    auth: str = "none"  # none|token|oidc
    token_env: str = "CTXLAYER_TOKEN"
    host: str = "127.0.0.1"
    port: int = 8765


@dataclass(frozen=True)
class SecurityIngestConfig:
    default_deny: bool = True
    sanitize: bool = True
    anomaly_threshold: float = 0.92
    reviewer_min_role: str = "reviewer"
    redteam_fixture_dir: str = "eval/redteam"


@dataclass(frozen=True)
class SecurityConfig:
    encrypt_workspace_db: bool = False
    key_provider: str = "env"  # env|file|keychain
    key_env: str = "CTXLAYER_KEY"
    secret_globs: list[str] = field(default_factory=lambda: ["**/*"])
    ingest: SecurityIngestConfig = field(default_factory=SecurityIngestConfig)


@dataclass(frozen=True)
class MemoryApprovalConfig:
    required: bool = True
    default_status: str = "candidate"
    allow_codeowners_approval: bool = True
    allow_admin_approval: bool = True
    auto_approve_from_tests: bool = False
    auto_approve_from_docs: bool = False


@dataclass(frozen=True)
class MemoryConfig:
    approval: MemoryApprovalConfig = field(default_factory=MemoryApprovalConfig)
    stale_after_days: int = 180
    include_recent_incidents: bool = True
    sweep_on_maintenance: bool = True
    sweep_apply: bool = True
    stale_confidence_floor: float = 0.25
    stale_penalty: float = 0.5
    conflict_penalty: float = 0.6
    report_narrative_llm: bool = False


@dataclass(frozen=True)
class LearningMemoryConfig:
    reflect_on_finish: bool = True
    dream_on_finish: bool = True
    dream_on_outcome: bool = True
    consolidate_on_task_complete: bool = True
    deterministic_only_fallback: bool = True
    min_session_evidence: int = 1
    promote_candidates_on_outcome: bool = True
    capture_outcome_summary: bool = True
    maintenance_interval_hours: int = 24
    max_agent_items_per_session: int = 12
    max_candidate_age_days: int = 30
    require_real_outcome_to_promote: bool = True
    recall_recency_weight: float = 0.3
    recall_importance_weight: float = 0.4
    recall_relevance_weight: float = 0.3


@dataclass(frozen=True)
class LearningSkillsConfig:
    induce_on_success: bool = True
    require_replay_to_promote: bool = True
    inject_top_k: int = 3
    rank_relevance_weight: float = 0.7
    rank_reliability_weight: float = 0.2
    rank_freshness_weight: float = 0.1
    validation_half_life_days: int = 90
    cross_repo_requires_revalidation: bool = True


@dataclass(frozen=True)
class LearningRerankConfig:
    enabled: bool = False
    order_only: bool = True
    outcome_boost: float = 0.05
    memory_boost: float = 0.04
    neural_enabled: bool = False
    neural_model: str = ""
    neural_top_k: int = 50
    require_judge: bool = False
    judge_votes: int = 3
    judge_min_pass_rate: float = 0.67
    fail_closed_on_disagreement: bool = False
    max_disagreement: float = 0.5


@dataclass(frozen=True)
class LearningOptimizeConfig:
    enabled: bool = False
    sealed_oracle: bool = True
    targets: list[str] = field(
        default_factory=lambda: [
            "pack_weights",
            "pack_quotas",
            "skills",
            "impact_risk",
            "rerank",
            "textual_artifacts",
        ]
    )
    holdout_required: bool = True
    optimizer_prompt_instruction: str = ""
    pack_template_instruction: str = ""
    impact_changed_files_weight: float = 2.0
    impact_impacted_files_weight: float = 2.0
    impact_untested_files_weight: float = 3.0
    impact_low_confidence_edges_weight: float = 1.5
    impact_critical_paths_weight: float = 4.5
    impact_graph_centrality_weight: float = 1.0
    impact_changed_file_budget: int = 3


@dataclass(frozen=True)
class LearningSelfModConfig:
    enabled: bool = False
    allowlist: list[str] = field(
        default_factory=lambda: [
            "src/ctxlayer/architecture/**",
            "src/ctxlayer/behavior/**",
            "src/ctxlayer/agents/routing.py",
            "src/ctxlayer/impact/engine.py",
        ]
    )
    require_human_approval: bool = True
    max_worktrees: int = 1
    validation_commands: list[str] = field(
        default_factory=lambda: ["python -m pytest -q"]
    )
    validation_timeout_seconds: int = 600
    require_constitution_gate: bool = True
    benchmark_command: str = ""
    require_benchmark_gate: bool = False
    benchmark_timeout_seconds: int = 1200
    require_judge_gate: bool = False
    judge_votes: int = 3
    judge_min_pass_rate: float = 0.67
    fail_closed_on_disagreement: bool = True
    max_disagreement: float = 0.5


@dataclass(frozen=True)
class LearningLoopVerifyConfig:
    require_closure: bool = False
    default_probe: str = "ranking"
    probe_task: str = "ctxlayer loop closure probe"


@dataclass(frozen=True)
class LearningConfig:
    enabled: bool = True
    agent_command: str = ""
    actor_model_family: str = "primary"
    judge_model_family: str = "secondary"
    max_tokens_per_task: int = 20_000
    max_tokens_per_run: int = 400_000
    memory: LearningMemoryConfig = field(default_factory=LearningMemoryConfig)
    skills: LearningSkillsConfig = field(default_factory=LearningSkillsConfig)
    rerank: LearningRerankConfig = field(default_factory=LearningRerankConfig)
    optimize: LearningOptimizeConfig = field(default_factory=LearningOptimizeConfig)
    selfmod: LearningSelfModConfig = field(default_factory=LearningSelfModConfig)
    loop_verify: LearningLoopVerifyConfig = field(
        default_factory=LearningLoopVerifyConfig
    )


@dataclass(frozen=True)
class Settings:
    toolchain: ToolchainConfig = field(default_factory=ToolchainConfig)
    pack: PackConfig = field(default_factory=PackConfig)
    retrieval: RetrievalConfig = field(default_factory=RetrievalConfig)
    audit: AuditConfig = field(default_factory=AuditConfig)
    eval: EvalConfig = field(default_factory=EvalConfig)
    sharding: ShardingConfig = field(default_factory=ShardingConfig)
    ci: CIConfig = field(default_factory=CIConfig)
    server: ServerConfig = field(default_factory=ServerConfig)
    security: SecurityConfig = field(default_factory=SecurityConfig)
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    learning: LearningConfig = field(default_factory=LearningConfig)
    maintenance: MaintenanceConfig = field(default_factory=MaintenanceConfig)
    reliability: ReliabilityConfig = field(default_factory=ReliabilityConfig)
    guardrails: GuardrailsConfig = field(default_factory=GuardrailsConfig)
    governance: GovernanceConfig = field(default_factory=GovernanceConfig)

    @property
    def ignore_globs(self) -> list[str]:
        return self.eval.ignore_globs


def _section(data: dict[str, Any], name: str) -> dict[str, Any]:
    value: Any = data
    for part in name.split("."):
        if not isinstance(value, dict):
            return {}
        value = value.get(part, {})
    return value if isinstance(value, dict) else {}


def _dataclass_kwargs(cls: type[Any], data: dict[str, Any]) -> dict[str, Any]:
    allowed = {item.name for item in fields(cls)}
    return {key: value for key, value in data.items() if key in allowed}


def _learning_config(data: dict[str, Any]) -> LearningConfig:
    learning_data = dict(_section(data, "ctxlayer.learning"))
    memory_data = dict(_section(learning_data, "memory"))
    skills_data = dict(_section(learning_data, "skills"))
    rerank_data = dict(_section(learning_data, "rerank"))
    optimize_data = dict(_section(learning_data, "optimize"))
    selfmod_data = dict(_section(learning_data, "selfmod"))
    loop_verify_data = dict(_section(learning_data, "loop_verify"))
    for nested in ("memory", "skills", "rerank", "optimize", "selfmod", "loop_verify"):
        learning_data.pop(nested, None)
    return LearningConfig(
        **_dataclass_kwargs(LearningConfig, learning_data),
        memory=LearningMemoryConfig(
            **_dataclass_kwargs(LearningMemoryConfig, memory_data)
        ),
        skills=LearningSkillsConfig(
            **_dataclass_kwargs(LearningSkillsConfig, skills_data)
        ),
        rerank=LearningRerankConfig(
            **_dataclass_kwargs(LearningRerankConfig, rerank_data)
        ),
        optimize=LearningOptimizeConfig(
            **_dataclass_kwargs(LearningOptimizeConfig, optimize_data)
        ),
        selfmod=LearningSelfModConfig(
            **_dataclass_kwargs(LearningSelfModConfig, selfmod_data)
        ),
        loop_verify=LearningLoopVerifyConfig(
            **_dataclass_kwargs(LearningLoopVerifyConfig, loop_verify_data)
        ),
    )


def _security_config(data: dict[str, Any]) -> SecurityConfig:
    security_data = dict(_section(data, "security"))
    ingest_data = dict(_section(security_data, "ingest"))
    security_data.pop("ingest", None)
    return SecurityConfig(
        **_dataclass_kwargs(SecurityConfig, security_data),
        ingest=SecurityIngestConfig(
            **_dataclass_kwargs(SecurityIngestConfig, ingest_data)
        ),
    )


def load_settings(repo_root: Path) -> Settings:
    path = repo_root / "ctxlayer.toml"
    data: dict[str, Any] = {}
    if path.exists():
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    ctxlayer_data = dict(_section(data, "ctxlayer"))
    ctxlayer_data.pop("learning", None)
    ci_data = _section(data, "ci")
    ci_critical = _section(ci_data, "critical_paths")
    ci_business = _section(ci_data, "business_rules")
    if ci_critical and "globs" in ci_critical:
        ci_data = {**ci_data, "critical_paths": ci_critical["globs"]}
        ci_data.pop("critical_paths", None)
        ci_data["critical_paths"] = ci_critical["globs"]
    if ci_business:
        ci_data = {
            **ci_data,
            "business_rules_enabled": ci_business.get("enabled", True),
            "fail_on_high_risk_rule_changes": ci_business.get(
                "fail_on_high_risk_rule_changes", True
            ),
            "require_codeowner_for_rule_scope": ci_business.get(
                "require_codeowner_for_rule_scope", True
            ),
            "warn_on_stale_rules": ci_business.get("warn_on_stale_rules", True),
            "block_on_conflicting_rules": ci_business.get(
                "block_on_conflicting_rules", False
            ),
        }
        ci_data.pop("business_rules", None)
    memory_data = _section(data, "memory")
    approval_data = _section(memory_data, "approval")
    if approval_data:
        memory_data = {**memory_data, "approval": MemoryApprovalConfig(**approval_data)}
    return Settings(
        toolchain=ToolchainConfig(**_dataclass_kwargs(ToolchainConfig, ctxlayer_data)),
        pack=PackConfig(**_section(data, "pack")),
        retrieval=RetrievalConfig(**_section(data, "retrieval")),
        audit=AuditConfig(**_section(data, "audit")),
        eval=EvalConfig(**_section(data, "eval")),
        sharding=ShardingConfig(**_section(data, "sharding")),
        ci=CIConfig(**ci_data),
        server=ServerConfig(**_section(data, "server")),
        security=_security_config(data),
        memory=MemoryConfig(**memory_data),
        learning=_learning_config(data),
        maintenance=MaintenanceConfig(**_section(data, "maintenance")),
        reliability=ReliabilityConfig(**_section(data, "reliability")),
        guardrails=GuardrailsConfig(**_section(data, "guardrails")),
        governance=GovernanceConfig(**_section(data, "governance")),
    )


def is_ignored(path: str, settings: Settings) -> bool:
    normalized = path.replace("\\", "/")
    return any(fnmatch.fnmatch(normalized, glob) for glob in settings.ignore_globs)
