from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


CONTRACT_MARKER = "<!-- ctxlayer-agent-contract -->"
PLAN_CREATE_FILE_SNIPPET = """$planPath = Join-Path $env:TEMP "ctxlayer-plan.json"
$planJson = @'
{
  "objective": "<objective>",
  "steps": [
    {
      "id": "edit",
      "title": "<step title>",
      "intended_files": ["<path>"],
      "intended_tests": [],
      "capabilities": ["edit_source"],
      "risk": "medium"
    }
  ]
}
'@
[System.IO.File]::WriteAllText($planPath, $planJson, [System.Text.UTF8Encoding]::new($false))
ctxlayer --repo . plan create --task-session-id <task_session_id> --pack-id <pack_id> --file $planPath"""
POWERSHELL_PLAN_FILE_GUIDANCE = (
    "Do not pass plan JSON inline on PowerShell. Always write the plan payload to a\n"
    "UTF-8 JSON file and pass it with `ctxlayer plan create --file`."
)
CODEX_MEMORY_PARALLEL_GUIDANCE = """## Codex Memory and Parallel-Agent Enforcement

Before write-capable Codex work, run:

```powershell
ctxlayer --repo . codex preflight --task "<task>"
```

Treat the returned `memory_retrieval_id`, `continuation_matches`,
`served_memory_counts_by_type`, `policy_reference_count`, `skill_match_count`,
and `parallel_recommendation` as required context. Use the relevant memory area
for the task: active continuations for interrupted work, project memory for
facts/decisions/gotchas, policy references for governance pointers, and skills
for repeatable workflows.

For broad or disjoint work, follow the returned `parallel_agent_plan`. Spawn
CTX-scoped explorer, worker, reviewer, and verifier agents when recommended,
keep worker write scopes disjoint, and let the parent agent perform final
integration, CTX checks, tests, and outcome recording.
"""
SKILL_EVOLUTION_GUIDANCE = """## Skill Evolution Feedback Capture

When a user asks for a correction to accepted work, capture the event without
storing raw content:

```powershell
ctxlayer --repo . skill revision --skill-id <skill_id> --output-id <output_id> --text "<short correction>"
ctxlayer --repo . skill classify --skill-id <skill_id>
ctxlayer --repo . skill metrics --skill-id <skill_id>
```

Treat preference revisions as project memory candidates, repeated missing
patterns as skill-improvement candidates, and error corrections as corrective
learning evidence. Skill refinements require evidence, explicit approval,
benchmarking, and closure verification before activation.
"""


@dataclass(frozen=True)
class SubagentSpec:
    name: str
    description: str
    mode: str | None
    instructions: str


SUBAGENT_SPECS = [
    SubagentSpec(
        name="ctx-explorer",
        description=(
            "Read-heavy CTX-aware explorer for codebase questions, context discovery, "
            "and risk triage."
        ),
        mode="read-only",
        instructions=(
            "Use CTX Layer context before analysis. Stay read-only. Return concise "
            "findings with file references, uncertainty, and suggested follow-up "
            "checks. Do not edit files."
        ),
    ),
    SubagentSpec(
        name="ctx-worker",
        description="Scoped CTX-aware implementation worker for disjoint file ownership.",
        mode=None,
        instructions=(
            "Before edits, require parent task_session_id, pack_id, plan_id, active "
            "step, and assigned write scope. Do not revert other agents' work. Edit "
            "only assigned files, checkpoint changed paths, run assigned checks, and "
            "return changed files plus verification results."
        ),
    ),
    SubagentSpec(
        name="ctx-reviewer",
        description=(
            "CTX-aware reviewer focused on correctness, security, regressions, and "
            "missing tests."
        ),
        mode="read-only",
        instructions=(
            "Review using CTX Layer pack, impact, memory, and policy context. Stay "
            "read-only. Prioritize bugs, security risks, regressions, and missing "
            "tests with concrete file references."
        ),
    ),
    SubagentSpec(
        name="ctx-verifier",
        description=(
            "CTX-aware verification worker for tests, logs, impact reports, and "
            "failure localization."
        ),
        mode=None,
        instructions=(
            "Use CTX Layer impact and plan context to run bounded verification. "
            "Prefer read-only diagnostics unless explicitly assigned a repair scope. "
            "Report commands, exits, failures, and likely owning files."
        ),
    ),
]

HOOK_EVENTS = (
    "SessionStart",
    "UserPromptSubmit",
    "PreToolUse",
    "PostToolUse",
    "SubagentStart",
    "SubagentStop",
    "Stop",
)


def write_if_changed(path: Path, content: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists() or path.read_text(encoding="utf-8") != content:
        path.write_text(content, encoding="utf-8")
    return path


def ensure_instruction_contract(
    path: Path,
    agent_names: list[str],
    *,
    agent_label: str | None = None,
    self_bootstrap: bool = True,
) -> tuple[Path, bool]:
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    changed = False
    if CONTRACT_MARKER not in existing:
        addition = agent_contract(
            agent_names, agent_label=agent_label, self_bootstrap=self_bootstrap
        )
        if existing and not existing.endswith("\n"):
            existing += "\n"
        existing = f"{existing}\n{addition}" if existing else addition
        changed = True
    else:
        updated = ensure_agent_contract_guidance(
            existing, self_bootstrap=self_bootstrap
        )
        if updated != existing:
            existing = updated
            changed = True
    if changed:
        path.write_text(existing, encoding="utf-8")
    return path, changed


def ensure_agent_contract_guidance(
    existing: str, *, self_bootstrap: bool = True
) -> str:
    updated = replace_inline_json_plan_commands(existing)
    if "## Codex Memory and Parallel-Agent Enforcement" not in updated:
        updated = (
            updated.rstrip() + "\n\n" + CODEX_MEMORY_PARALLEL_GUIDANCE.rstrip() + "\n"
        )
    if "## Skill Evolution Feedback Capture" not in updated:
        updated = updated.rstrip() + "\n\n" + SKILL_EVOLUTION_GUIDANCE.rstrip() + "\n"
    if self_bootstrap and "setup auto" not in updated:
        updated = updated.rstrip() + "\n\n" + self_bootstrap_prompt().rstrip() + "\n"
    if "Do not pass plan JSON inline on PowerShell." in updated:
        return updated

    guidance = f"{POWERSHELL_PLAN_FILE_GUIDANCE}\n\n"
    before_plan_rules = "The plan must include an objective and a `steps` list."
    if before_plan_rules in updated:
        return updated.replace(before_plan_rules, guidance + before_plan_rules, 1)

    if updated.endswith("\n"):
        return updated + "\n" + guidance.rstrip() + "\n"
    return updated + "\n\n" + guidance.rstrip() + "\n"


def replace_inline_json_plan_commands(existing: str) -> str:
    lines: list[str] = []
    for line in existing.splitlines(keepends=True):
        stripped = line.strip()
        newline = "\n" if line.endswith("\n") else ""
        if (
            stripped.startswith("ctxlayer --repo . plan create ")
            and " --json " in stripped
        ):
            lines.append(PLAN_CREATE_FILE_SNIPPET + newline)
        elif (
            stripped.startswith("ctxlayer --repo . plan amend ")
            and " --json " in stripped
        ):
            lines.append(
                'ctxlayer --repo . plan amend <plan_id> --reason "<reason>" '
                "--file <updated_plan_json_file>" + newline
            )
        else:
            lines.append(line)
    return "".join(lines)


def agent_contract(
    agent_names: list[str],
    *,
    agent_label: str | None = None,
    self_bootstrap: bool = True,
) -> str:
    names = ", ".join(agent_names) if agent_names else (agent_label or "coding agents")
    bootstrap = f"\n{self_bootstrap_prompt()}" if self_bootstrap else ""
    return f"""# CTX Layer Agent Usage Contract
{CONTRACT_MARKER}

This project is guided by CTX Layer for AI coding agents: {names}.

Before editing this repository, request a CTX Layer context pack:

```powershell
ctxlayer --repo . task start --task "<task>"
ctxlayer --repo . pack --task "<task>"
```

Record the returned `task_session_id`, `pack_id`, and `agent_session_id`. Task
start, pack serving, plans, checkpoints, verification runs, and outcomes are
mirrored into agent session memory automatically. Create a structured task plan
before coding:

```powershell
{PLAN_CREATE_FILE_SNIPPET}
```

{POWERSHELL_PLAN_FILE_GUIDANCE}

{CODEX_MEMORY_PARALLEL_GUIDANCE}

{SKILL_EVOLUTION_GUIDANCE}

The plan must include an objective and a `steps` list. Each step must include
`id`, `title`, `intended_files`, `intended_tests`, `capabilities`, and `risk`
(`low`, `medium`, `high`, or `critical`).

During or after edits, checkpoint changed files against the active plan step:

```powershell
ctxlayer --repo . plan checkpoint <plan_id> --step-id <step_id> --path <changed_path>
```

If a checkpoint fails, amend the plan with a reason or remove the out-of-step
edit before continuing:

```powershell
ctxlayer --repo . plan amend <plan_id> --reason "<reason>" --file <updated_plan_json_file>
```

Before declaring work complete, run the local preflight and impact report:

```powershell
git diff HEAD | ctxlayer --repo . check-diff --pack-id <pack_id>
git diff --name-only HEAD | ctxlayer --repo . check-diff --pack-id <pack_id> --paths-from-stdin
git diff --name-only HEAD | ctxlayer --repo . impact --paths-from-stdin
```

Run the tests named by the impact report where practical, then record the outcome:

```powershell
ctxlayer --repo . outcome --pack-id <pack_id> --result pass
```

To inspect the remembered development episode, explain the returned session:

```powershell
ctxlayer --repo . session explain --session-id <agent_session_id>
```

If any CTX Layer check fails, do not declare the task complete. Fix the issue or
report the exact blocker.

The audit chain is tamper-evident for accidental edits and partial tampering. It is
not tamper-proof against an actor with full filesystem control who can rewrite the
database and recompute the chain.
{bootstrap}"""


def self_bootstrap_prompt() -> str:
    return """## Agent Self-Bootstrap

When this file is present but your native CTX Layer surfaces are missing, run:

```powershell
ctxlayer --repo . setup auto
```

That command detects the current agent and regenerates the native instruction
file, MCP registration snippets, hooks, subagents, and skills the agent supports.
"""


def codex_mcp_config(command: str = "ctxlayer", mcp_repo: str = ".") -> str:
    return f"""# Copy this block into your Codex config when you want this project to use CTX Layer.
[mcp_servers.ctxlayer]
command = {toml_string(command)}
args = ["mcp", "--repo", {toml_string(mcp_repo)}]
"""


def codex_project_config(command: str, mcp_repo: str) -> str:
    return f"""# Generated by CTX Layer. Project-local Codex config loads only when this repo is trusted.
[features]
hooks = true
multi_agent = true
memories = true

[agents]
max_threads = 4
max_depth = 1

[mcp_servers.ctxlayer]
command = {toml_string(command)}
args = ["mcp", "--repo", {toml_string(mcp_repo)}]
"""


def codex_hooks_json(repo_root: Path | None = None) -> str:
    hook = 'python "$(git rev-parse --show-toplevel)/.ctxlayer/codex/hooks/ctxlayer_hook.py"'
    initial_repo = powershell_string(str(repo_root)) if repo_root else "$null"
    hook_windows = (
        "powershell -NoProfile -ExecutionPolicy Bypass -Command "
        '"$payload = [Console]::In.ReadToEnd(); '
        f"$repo = {initial_repo}; "
        "if (-not $repo -or -not (Test-Path $repo)) { "
        "$repo = git rev-parse --show-toplevel; "
        "if ($LASTEXITCODE -ne 0 -or -not $repo) { $repo = $env:CODEX_PROJECT_DIR } "
        "}; "
        "$env:CTXLAYER_REPO = $repo; "
        "$payload | & python (Join-Path $repo '.ctxlayer/codex/hooks/ctxlayer_hook.py') "
    )
    payload = {
        "hooks": {
            "SessionStart": [
                {
                    "matcher": "startup|resume|clear|compact",
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} SessionStart",
                            "commandWindows": f'{hook_windows}SessionStart; exit $LASTEXITCODE"',
                            "timeout": 30,
                            "statusMessage": "Checking CTX Layer setup",
                        }
                    ],
                }
            ],
            "UserPromptSubmit": [
                {
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} UserPromptSubmit",
                            "commandWindows": f'{hook_windows}UserPromptSubmit; exit $LASTEXITCODE"',
                            "timeout": 30,
                            "statusMessage": "Preparing CTX Layer preflight",
                        }
                    ]
                }
            ],
            "PreToolUse": [
                {
                    "matcher": "Bash|apply_patch|Edit|Write|mcp__.*",
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} PreToolUse",
                            "commandWindows": f'{hook_windows}PreToolUse; exit $LASTEXITCODE"',
                            "timeout": 30,
                            "statusMessage": "Checking CTX Layer tool gate",
                        }
                    ],
                }
            ],
            "PostToolUse": [
                {
                    "matcher": "Bash|apply_patch|Edit|Write|mcp__.*",
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} PostToolUse",
                            "commandWindows": f'{hook_windows}PostToolUse; exit $LASTEXITCODE"',
                            "timeout": 30,
                            "statusMessage": "Recording CTX Layer tool evidence",
                        }
                    ],
                }
            ],
            "SubagentStart": [
                {
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} SubagentStart",
                            "commandWindows": f'{hook_windows}SubagentStart; exit $LASTEXITCODE"',
                            "timeout": 30,
                            "statusMessage": "Registering CTX Layer child session",
                        }
                    ]
                }
            ],
            "SubagentStop": [
                {
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} SubagentStop",
                            "commandWindows": f'{hook_windows}SubagentStop; exit $LASTEXITCODE"',
                            "timeout": 30,
                            "statusMessage": "Recording CTX Layer child summary",
                        }
                    ]
                }
            ],
            "Stop": [
                {
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} Stop",
                            "commandWindows": f'{hook_windows}Stop; exit $LASTEXITCODE"',
                            "timeout": 30,
                            "statusMessage": "Recording CTX Layer continuation state",
                        }
                    ]
                }
            ],
        }
    }
    return json.dumps(payload, indent=2, sort_keys=True) + "\n"


def codex_agent_toml(spec: SubagentSpec) -> str:
    mode = f'sandbox_mode = "{spec.mode}"\n' if spec.mode else ""
    return f"""name = "{spec.name}"
description = "{spec.description}"
{mode}developer_instructions = \"\"\"
{spec.instructions}
\"\"\"
"""


def claude_agent_markdown(spec: SubagentSpec) -> str:
    tools = (
        "Read, Grep, Glob"
        if spec.mode == "read-only"
        else "Read, Grep, Glob, Edit, Bash"
    )
    return f"""---
name: {spec.name}
description: {spec.description}
tools: {tools}
---

{spec.instructions}
"""


def hook_script() -> str:
    return """from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path


def main() -> int:
    event = sys.argv[1] if len(sys.argv) > 1 else "unknown"
    repo = _repo_root()
    payload = _read_stdin_json()
    result = _ctxlayer_event(repo, event, payload)
    if repo:
        log_dir = repo / ".ctxlayer" / "codex"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / "hook-events.jsonl"
        with log_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps({"event": event, "payload": payload, "result": result}, sort_keys=True) + "\\n")
    print(json.dumps(_codex_hook_output(result), sort_keys=True))
    return 1 if result.get("decision") == "block" else 0


def _codex_hook_output(result: dict) -> dict:
    event = str(result.get("event") or "")

    if event == "PreToolUse":
        if result.get("decision") == "block":
            return {
                "decision": "block",
                "reason": str(result.get("reason") or "CTX Layer hook blocked this tool call"),
            }
        return {"decision": "allow"}

    # Non-tool-gating Codex hook events do not accept PreToolUse decisions.
    # Keep stdout as valid, minimal JSON and rely on hook-events.jsonl for audit detail.
    if event in {
        "PostToolUse",
        "SessionStart",
        "UserPromptSubmit",
        "SubagentStart",
        "SubagentStop",
        "Stop",
    }:
        return {}

    if result.get("decision") == "block":
        return {
            "decision": "block",
            "reason": str(result.get("reason") or "CTX Layer hook blocked this tool call"),
        }
    return {}


def _daemon_result(event: str, body: dict) -> dict | None:
    base_url = os.environ.get("CTXLAYER_DAEMON")
    if not base_url:
        return None
    import urllib.request

    data = json.dumps({"event": event, "payload": body}).encode("utf-8")
    request = urllib.request.Request(
        base_url.rstrip("/") + "/v1/codex/hook-event",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    token = os.environ.get("CTXLAYER_TOKEN")
    if token:
        request.add_header("Authorization", "Bearer " + token)
    try:
        with urllib.request.urlopen(request, timeout=3) as response:
            parsed = json.loads(response.read().decode("utf-8"))
            return parsed if isinstance(parsed, dict) else None
    except Exception:  # noqa: BLE001 - fall back to the in-process service.
        return None


def _ctxlayer_event(repo: Path | None, event: str, payload: object) -> dict:
    base = {
        "ok": True,
        "event": event,
        "repo": str(repo) if repo else None,
        "ctxlayer_available": shutil.which("ctxlayer") is not None,
        "mode": "enforcing" if event == "PreToolUse" else "audit",
    }
    if not repo:
        return {**base, "ok": event != "PreToolUse", "decision": "block", "reason": "no git repo root"}
    body = payload if isinstance(payload, dict) else {"payload": payload}
    if event == "PreToolUse":
        # Hot path: the write gate is pure logic. Import only the lightweight
        # gate module so every tool call does not pay for the full service.
        try:
            from ctxlayer.codex import pre_tool_gate

            gate = pre_tool_gate(
                tool_name=str(body.get("tool_name") or body.get("tool") or ""),
                preflight_ready=bool(body.get("preflight_ready")),
                active_plan_step=bool(body.get("active_plan_step")),
                read_only=bool(body.get("read_only")),
            )
            return {**base, **gate}
        except Exception as exc:  # noqa: BLE001 - fail closed for the write gate.
            return {**base, "ok": False, "decision": "block", "reason": str(exc)}
    daemon = _daemon_result(event, body)
    if daemon is not None:
        return {**base, **daemon}
    try:
        from ctxlayer.service import CtxLayerService

        with CtxLayerService(repo) as service:
            return {**base, **service.codex_hook_event(event, body)}
    except Exception as exc:  # noqa: BLE001
        return {**base, "ok": False, "reason": str(exc)}


def _repo_root() -> Path | None:
    env_repo = _repo_from_env()
    if env_repo:
        return env_repo
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=5,
        )
    except (FileNotFoundError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    return Path(result.stdout.strip())


def _repo_from_env() -> Path | None:
    for name in ("CTXLAYER_REPO", "CODEX_PROJECT_DIR", "CODEX_WORKSPACE_ROOT"):
        value = os.environ.get(name)
        if not value:
            continue
        candidate = Path(value)
        if candidate.exists():
            return candidate
    return None


def _read_stdin_json() -> object:
    raw = sys.stdin.read()
    if not raw.strip():
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {"raw": raw[:4000]}


if __name__ == "__main__":
    raise SystemExit(main())
"""


def claude_settings_json(repo_root: Path | None = None) -> str:
    hook_path = ".ctxlayer/claude/hooks/ctxlayer_hook.py"
    command = f"python {hook_path}"
    payload = {
        "hooks": {
            event: [
                {
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{command} {event}",
                            "timeout": 30,
                        }
                    ]
                }
            ]
            for event in HOOK_EVENTS
        }
    }
    return json.dumps(payload, indent=2, sort_keys=True) + "\n"


def claude_skill(command: str, mcp_repo: str) -> str:
    return f"""---
name: ctx-loop
description: Use CTX Layer for pack, plan, checkpoint, impact, and outcome workflows.
---

# CTX Layer Loop

Before editing, run `{command} --repo . task start --task "<task>"` and
`{command} --repo . pack --task "<task>"`. Create a plan, checkpoint changed
files, run check-diff and impact, then record the outcome. The MCP server for
this project is `{command} mcp --repo "{mcp_repo}"`.
"""


def claude_mcp_json(command: str, mcp_repo: str) -> str:
    return (
        json.dumps(
            {
                "mcpServers": {
                    "ctxlayer": {
                        "command": command,
                        "args": ["mcp", "--repo", mcp_repo],
                    }
                }
            },
            indent=2,
            sort_keys=True,
        )
        + "\n"
    )


def cursor_mcp_json(command: str, mcp_repo: str) -> str:
    return claude_mcp_json(command, mcp_repo)


def cursor_rule(agent_names: list[str], command: str, mcp_repo: str) -> str:
    return (
        "---\n"
        "alwaysApply: true\n"
        "---\n\n"
        + agent_contract(agent_names, agent_label="Cursor", self_bootstrap=True)
        + "\n## Cursor Enforcement Note\n\n"
        "Cursor does not provide CTX Layer lifecycle hooks, subagents, or skills. "
        "Use the MCP server and this rule for the CTX workflow; PreToolUse "
        "write-gate enforcement is degraded to instruction-level enforcement.\n\n"
        "MCP command:\n\n"
        "```powershell\n"
        f'{command} mcp --repo "{mcp_repo}"\n'
        "```\n"
    )


def claude_command(command: str, mcp_repo: str) -> str:
    return f"""# Run from this project root to register CTX Layer with Claude Code.
claude mcp add ctxlayer -- {command} mcp --repo "{mcp_repo}"
"""


def mcp_readme(command: str, mcp_repo: str) -> str:
    return f"""# CTX Layer MCP Setup

This folder contains local setup snippets generated by `ctxlayer bootstrap`.

## Codex

Copy `.ctxlayer/mcp/codex.config.toml` into the relevant Codex config file.

## Claude Code

Run:

```powershell
claude mcp add ctxlayer -- {command} mcp --repo "{mcp_repo}"
```

## Cursor

Review `.cursor/mcp.json`, or configure an equivalent MCP server entry:

```json
{{
  "mcpServers": {{
    "ctxlayer": {{
      "command": "{command}",
      "args": ["mcp", "--repo", "{mcp_repo}"]
    }}
  }}
}}
```

## Direct MCP Smoke Test

```powershell
{command} mcp --repo "{mcp_repo}"
```
"""


def toml_string(value: str) -> str:
    return json.dumps(value)


def powershell_string(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def capabilities_yaml() -> str:
    return """schema_version: ctxlayer.capabilities.v1
require_task_session: false
missing_session_mode: warn
governance:
  governed_classes:
    production_deploy:
      required_verifications:
        - verify-production-assets
capabilities:
  edit_source:
    mode: free
  edit_tests:
    mode: free
  add_dependency:
    mode: warn
    paths: [package.json, package-lock.json, pnpm-lock.yaml, yarn.lock, pyproject.toml, requirements*.txt]
  modify_migration:
    mode: warn
    paths: [migrations/**, **/migrations/**]
  delete_file:
    mode: warn
  edit_critical_path:
    mode: warn
    paths: [src/auth/**, src/billing/**, src/payments/**, migrations/**]
  modify_ci_config:
    mode: warn
    paths: [.github/**, .gitlab-ci.yml, ctxlayer.toml, ctxlayer.capabilities.yaml]
  touch_env_secrets:
    mode: forbidden
    paths: [.env, .env.*, **/.env, **/.env.*, **/*.pem, **/*.key]
  run_destructive_command:
    mode: forbidden
"""


def production_asset_verifier() -> str:
    return """#!/usr/bin/env node
import { existsSync, readdirSync } from "node:fs";
import { join } from "node:path";

const roots = [
  ".next/standalone/.next/static",
  ".next/standalone/public",
  ".next/static",
  "public",
];

const present = roots.filter((root) => existsSync(root));
const hasFiles = present.some((root) => {
  try {
    return readdirSync(root, { recursive: true }).some((entry) => String(entry).trim());
  } catch {
    return false;
  }
});

if (!hasFiles) {
  console.error(
    "Production asset verification failed: static assets were not found in standalone/public output."
  );
  console.error(
    "Copy .next/static into .next/standalone/.next/static and public into .next/standalone/public before deploy."
  );
  process.exit(1);
}

console.log(`Production assets verified from ${present.map((root) => join(root)).join(", ")}`);
"""
