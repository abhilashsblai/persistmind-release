from __future__ import annotations

import fnmatch
import posixpath
import re
import subprocess
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from persistmind.config import Settings, is_ignored
from persistmind.linking import parse_codeowners
from persistmind.parsing import ExtractedFile, parse_file
from persistmind.retrieval import chunk_file
from persistmind.retrieval.embedder import make_embedder
from persistmind.runtime.operations import Deadline, OperationCoordinator, SignalCancellation
from persistmind.utils import canonical_json, relpath, sha256_bytes, stable_id

SUPPORTED_EXTS = {
    ".py",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".mjs",
    ".cjs",
    ".toml",
    ".md",
    ".json",
    ".yaml",
    ".yml",
    ".sql",
    ".go",
    ".java",
    ".php",
    ".rb",
    ".rs",
}

COVERS_RE = re.compile(r"^\s*(?:--|#|//)\s*Covers:\s*(?P<paths>.+?)\s*$", re.IGNORECASE)
HistoryMiner: Any | None = None


def _history_miner_class() -> Any:
    global HistoryMiner
    if HistoryMiner is None:
        from persistmind.mining.history import HistoryMiner as LoadedHistoryMiner

        HistoryMiner = LoadedHistoryMiner
    return HistoryMiner


class IndexRequiredError(RuntimeError):
    def __init__(self, snapshot_id: str):
        super().__init__("a ready source index is required; run `persistmind --repo . index`")
        self.snapshot_id = snapshot_id


@dataclass(frozen=True)
class SnapshotInfo:
    repo_id: str
    snapshot_id: str
    base_commit_sha: str
    tree_digest: str
    dirty_digest: str
    worktree_state: str
    branch_hint: str | None


class SnapshotResolver:
    """Legacy monolithic indexer retained only for historical store compatibility.

    Live source generation now flows through ``storage.source_service.SourceService``.
    New code should depend on ``SnapshotInfo`` plus SourceService operations instead
    of constructing this resolver.
    """

    __deprecated__ = "Use persistmind.storage.source_service.SourceService for live indexing."

    def __init__(
        self,
        repo_root: Path,
        store: Any,
        settings: Settings,
        *,
        read_only: bool = False,
    ):
        self.repo_root = repo_root.resolve()
        self.store = store
        self.settings = settings
        self.read_only = read_only
        self.repo_id = stable_id(str(self.repo_root))[:16]
        self.embedder = make_embedder(
            model_name=settings.toolchain.embed_model,
            backend=settings.toolchain.embed_backend,
        )
        self._active_generation_id: str | None = None

    def resolve(
        self,
        refresh: bool = False,
        *,
        ready_only: bool = False,
        deadline: Deadline | None = None,
    ) -> SnapshotInfo:
        operation_deadline = deadline or Deadline(
            self.settings.reliability.index_timeout_seconds, operation="index"
        )
        operation_deadline.check("index_discovery")
        files = self._discover_files(operation_deadline)
        info = self._identity(files, operation_deadline)
        if self.read_only:
            if refresh or not self.store.snapshot_ready(info.snapshot_id):
                raise IndexRequiredError(info.snapshot_id)
            return info
        self.store.upsert_repo(self.repo_id, self.repo_root, self._git_remote())
        if ready_only and not self.store.snapshot_ready(info.snapshot_id):
            raise IndexRequiredError(info.snapshot_id)
        if refresh or not self.store.snapshot_ready(info.snapshot_id):
            with (
                OperationCoordinator(
                    self.repo_root / self.settings.toolchain.workspace_dir / "operations",
                    "index",
                    deadline_seconds=operation_deadline.remaining(),
                ),
                SignalCancellation(operation_deadline),
            ):
                self._index_snapshot(info, files, operation_deadline)
        return info

    def current_identity(self) -> SnapshotInfo:
        if not self.read_only:
            self.store.upsert_repo(self.repo_id, self.repo_root, self._git_remote())
        deadline = Deadline(
            self.settings.reliability.pack_timeout_seconds,
            operation="snapshot_identity",
        )
        return self._identity(self._discover_files(deadline), deadline)

    def read_only_identity(self) -> SnapshotInfo:
        """Compute the current source identity without mutating repository storage."""

        deadline = Deadline(
            self.settings.reliability.pack_timeout_seconds,
            operation="snapshot_identity_read_only",
        )
        return self._identity(self._discover_files(deadline), deadline)

    def _identity(self, files: list[Path], deadline: Deadline) -> SnapshotInfo:
        deadline.check("identity_git")
        base_commit = self._git(["rev-parse", "HEAD"], fallback="NO_GIT")
        branch = self._git(["branch", "--show-current"], fallback=None)
        tree_digest = self._tree_digest(files, deadline)
        dirty_digest = self._dirty_digest(files, deadline)
        worktree_state = "dirty" if dirty_digest else "clean"
        snapshot_id = stable_id(
            self.repo_id,
            base_commit,
            tree_digest,
            dirty_digest,
            self.settings.toolchain.indexer_version,
            self.settings.toolchain.parser_bundle_version,
            self._chunker_version(),
            canonical_json(self._embedding_identity()),
        )
        return SnapshotInfo(
            repo_id=self.repo_id,
            snapshot_id=snapshot_id,
            base_commit_sha=base_commit or "",
            tree_digest=tree_digest,
            dirty_digest=dirty_digest,
            worktree_state=worktree_state,
            branch_hint=branch,
        )

    def _index_snapshot(self, info: SnapshotInfo, files: list[Path], deadline: Deadline) -> None:
        self.store.open_snapshot(
            snapshot_id=info.snapshot_id,
            repo_id=info.repo_id,
            base_commit_sha=info.base_commit_sha,
            tree_digest=info.tree_digest,
            dirty_digest=info.dirty_digest,
            worktree_state=info.worktree_state,
            branch_hint=info.branch_hint,
            parent_snapshot=None,
            indexer_version=self.settings.toolchain.indexer_version,
            parser_bundle_version=self.settings.toolchain.parser_bundle_version,
            chunker_version=self._chunker_version(),
            embed_model=self.settings.toolchain.embed_model,
        )
        generation_id = self.store.begin_snapshot_generation(
            info.snapshot_id,
            expected_file_count=len(files),
            deadline_at=(datetime.now(UTC) + timedelta(seconds=deadline.remaining())).isoformat(),
        )
        self._active_generation_id = generation_id
        extracted_by_path: dict[str, ExtractedFile] = {}
        module_to_path: dict[str, str] = {}
        file_version_by_path: dict[str, str] = {}
        symbol_ids_by_path: dict[str, dict[str, str]] = {}
        text_by_path: dict[str, str] = {}

        try:
            for path in files:
                deadline.check("index_parse")
                rel = relpath(path, self.repo_root)
                stat = self._safe_stat(path)
                if stat is None:
                    raise OSError(f"accepted source file became unreadable: {rel}")
                if stat.st_size > self.settings.sharding.max_file_bytes:
                    raise ValueError(f"accepted source file exceeds size limit: {rel}")
                raw = self._safe_read_bytes(path)
                if raw is None:
                    raise OSError(f"accepted source file became unreadable: {rel}")
                try:
                    text = raw.decode("utf-8")
                except UnicodeDecodeError as exc:
                    raise ValueError(f"accepted source file is not UTF-8: {rel}") from exc
                extracted = parse_file(rel, text, backend=self.settings.toolchain.parser_backend)
                file_version_id = sha256_bytes(raw)
                file_version_by_path[rel] = file_version_id
                extracted_by_path[rel] = extracted
                text_by_path[rel] = text
                self.store.put_file_version(
                    snapshot_id=info.snapshot_id,
                    repo_id=info.repo_id,
                    path=rel,
                    file_version_id=file_version_id,
                    lang=extracted.lang,
                    loc=len(text.splitlines()),
                    skeleton=extracted.skeleton,
                    generation_id=generation_id,
                )
                symbol_ids: dict[str, str] = {}
                for symbol in extracted.symbols:
                    deadline.check("index_symbols")
                    symbol_id = self.store.resolve_identity(
                        repo_id=info.repo_id,
                        path=rel,
                        kind=symbol.kind,
                        qualname=symbol.qualname,
                        is_test=symbol.is_test,
                    )
                    symbol_ids[symbol.qualname] = symbol_id
                    self.store.put_occurrence(
                        symbol_identity_id=symbol_id,
                        file_version_id=file_version_id,
                        start_line=symbol.start_line,
                        end_line=symbol.end_line,
                        signature=symbol.signature,
                        docstring=symbol.docstring,
                    )
                    self.store.put_edge(
                        scope_snapshot_id=info.snapshot_id,
                        src_repo_id=info.repo_id,
                        src_node_type="file",
                        src_node_id=rel,
                        dst_repo_id=info.repo_id,
                        dst_node_type="symbol",
                        dst_node_id=symbol_id,
                        kind="defines",
                        confidence=1.0,
                        metadata={"qualname": symbol.qualname},
                        generation_id=generation_id,
                    )
                symbol_ids_by_path[rel] = symbol_ids
                if rel.endswith(".py"):
                    for module in _python_module_aliases(rel):
                        module_to_path[module] = rel
                elif rel.endswith((".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs")):
                    module_to_path["./" + rel.rsplit(".", 1)[0]] = rel

            for rel, extracted in extracted_by_path.items():
                deadline.check("index_chunking")
                chunks = chunk_file(
                    snapshot_id=info.snapshot_id,
                    repo_id=info.repo_id,
                    path=rel,
                    text=text_by_path[rel],
                    extracted=extracted,
                    symbol_ids=symbol_ids_by_path[rel],
                    chunking=self.settings.chunking,
                )
                vectors = []
                embeddable_chunks = [
                    chunk for chunk in chunks if not self._is_lazy_embed_path(chunk.path)
                ]
                if embeddable_chunks:
                    deadline.check("index_embedding")
                    vectors = self.embedder.embed_many(
                        [chunk.text_normalized for chunk in embeddable_chunks]
                    )
                deadline.check("index_embedding")
                vector_by_chunk = {
                    chunk.chunk_id: vector
                    for chunk, vector in zip(embeddable_chunks, vectors, strict=True)
                }
                for chunk in chunks:
                    deadline.check("index_chunks")
                    self.store.put_chunk(
                        chunk_id=chunk.chunk_id,
                        snapshot_id=info.snapshot_id,
                        repo_id=info.repo_id,
                        path=chunk.path,
                        symbol_identity_id=chunk.symbol_identity_id,
                        category=chunk.category,
                        start_line=chunk.start_line,
                        end_line=chunk.end_line,
                        text=chunk.text,
                        text_normalized=chunk.text_normalized,
                        token_count=chunk.token_count,
                        generation_id=generation_id,
                    )
                    if chunk.chunk_id in vector_by_chunk:
                        self.store.put_chunk_vector(
                            chunk_id=chunk.chunk_id,
                            dims=self.embedder.dims,
                            vector=vector_by_chunk[chunk.chunk_id],
                            model=self.embedder.model_name,
                            encoding=self.settings.toolchain.vector_encoding,
                            generation_id=generation_id,
                        )
                self._link_imports(info, rel, extracted, module_to_path)
                self._link_tests(
                    info,
                    rel,
                    extracted,
                    extracted_by_path,
                    module_to_path,
                    text_by_path[rel],
                )
                self._link_calls(info, rel, extracted)

            deadline.check("index_history")
            self._store_test_commands(info.repo_id)
            self.store.replace_ownership(info.repo_id, parse_codeowners(self.repo_root))
            history = _history_miner_class()(self.repo_root).mine(
                info.base_commit_sha if info.base_commit_sha != "NO_GIT" else "HEAD"
            )
            deadline.check("index_history")
            self.store.replace_history_signals(
                repo_id=info.repo_id,
                churn_rows=history.churn_rows,
                cochange_rows=history.cochange_rows,
            )
            if self.settings.audit.retain_dirty_blobs and info.dirty_digest:
                self._retain_dirty_blobs(info, files)
            deadline.check("index_validation")
            counts = self.store.generation_counts(generation_id)
            fingerprint = self.store.generation_fingerprint(
                generation_id,
                {
                    "indexer_version": self.settings.toolchain.indexer_version,
                    "parser_bundle_version": self.settings.toolchain.parser_bundle_version,
                    "parser_backend": self.settings.toolchain.parser_backend,
                    "chunker": self._chunking_identity(),
                    "embedding": self._embedding_identity(),
                    "supported_extensions": sorted(SUPPORTED_EXTS),
                    "ignore_globs": sorted(self.settings.ignore_globs),
                    "cold_path_globs": sorted(self.settings.sharding.cold_path_globs),
                    "max_file_bytes": self.settings.sharding.max_file_bytes,
                },
            )
            self.store.finish_snapshot_generation(
                generation_id,
                indexed_file_count=counts["files"],
                indexed_chunk_count=counts["chunks"],
                indexed_edge_count=counts["edges"],
                validation_hash=stable_id(info.snapshot_id, fingerprint, canonical_json(counts)),
                source_index_fingerprint=fingerprint,
            )
        except BaseException as exc:
            self.store.fail_snapshot_generation(generation_id, str(exc))
            raise
        finally:
            self._active_generation_id = None

    def _link_imports(
        self,
        info: SnapshotInfo,
        rel: str,
        extracted: ExtractedFile,
        module_to_path: dict[str, str],
    ) -> None:
        for obs in extracted.imports:
            candidates = self._resolve_import(rel, obs.module, obs.name, module_to_path)
            for dst_path, confidence in candidates:
                self.store.put_edge(
                    scope_snapshot_id=info.snapshot_id,
                    src_repo_id=info.repo_id,
                    src_node_type="file",
                    src_node_id=rel,
                    dst_repo_id=info.repo_id,
                    dst_node_type="file",
                    dst_node_id=dst_path,
                    kind="imports",
                    confidence=confidence,
                    metadata={"module": obs.module, "name": obs.name},
                    generation_id=self._active_generation_id,
                )

    def _resolve_import(
        self, rel: str, module: str, name: str | None, module_to_path: dict[str, str]
    ) -> list[tuple[str, float]]:
        normalized = module.lstrip(".")
        candidates: list[tuple[str, float]] = []
        if module.startswith(".") and rel.endswith((".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs")):
            relative_key = "./" + posixpath.normpath(
                posixpath.join(posixpath.dirname(rel), module)
            ).removeprefix("./")
            if not relative_key.startswith("./../") and relative_key in module_to_path:
                candidates.append((module_to_path[relative_key], 1.0))
        for key in [normalized, f"{normalized}.{name}" if name else "", module]:
            if key and key in module_to_path:
                candidates.append((module_to_path[key], 1.0))
        if module.startswith("."):
            package = Path(rel).parent.as_posix().replace("/", ".")
            key = f"{package}.{normalized}".strip(".")
            if key in module_to_path:
                candidates.append((module_to_path[key], 0.9))
        if not candidates:
            tail = normalized.split(".")[-1]
            for key, path in module_to_path.items():
                if key.endswith("." + tail) or key == tail:
                    candidates.append((path, 0.55))
        seen: set[str] = set()
        unique: list[tuple[str, float]] = []
        for path, confidence in candidates:
            if path != rel and path not in seen:
                unique.append((path, confidence))
                seen.add(path)
        return unique

    def _link_tests(
        self,
        info: SnapshotInfo,
        rel: str,
        extracted: ExtractedFile,
        extracted_by_path: dict[str, ExtractedFile],
        module_to_path: dict[str, str],
        text: str,
    ) -> None:
        path = Path(rel)
        is_test = path.name.startswith("test_") or path.name.endswith(".test.ts") or "/test" in rel
        if not is_test:
            return
        for covered_path in _explicit_covers_paths(text):
            self.store.put_edge(
                scope_snapshot_id=info.snapshot_id,
                src_repo_id=info.repo_id,
                src_node_type="file",
                src_node_id=rel,
                dst_repo_id=info.repo_id,
                dst_node_type="file",
                dst_node_id=covered_path,
                kind="tests",
                confidence=0.95,
                metadata={"signal": "covers_annotation"},
                generation_id=self._active_generation_id,
            )
        for obs in extracted.imports:
            for dst_path, confidence in self._resolve_import(
                rel, obs.module, obs.name, module_to_path
            ):
                if confidence < 0.7:
                    continue
                self.store.put_edge(
                    scope_snapshot_id=info.snapshot_id,
                    src_repo_id=info.repo_id,
                    src_node_type="file",
                    src_node_id=rel,
                    dst_repo_id=info.repo_id,
                    dst_node_type="file",
                    dst_node_id=dst_path,
                    kind="tests",
                    confidence=min(0.9, confidence),
                    metadata={
                        "signal": "direct_import",
                        "module": obs.module,
                        "name": obs.name,
                    },
                    generation_id=self._active_generation_id,
                )
        stem = path.stem.replace("test_", "").replace(".test", "")
        for candidate in extracted_by_path:
            if candidate == rel:
                continue
            candidate_stem = Path(candidate).stem
            if candidate_stem == stem or candidate_stem in stem or stem in candidate_stem:
                self.store.put_edge(
                    scope_snapshot_id=info.snapshot_id,
                    src_repo_id=info.repo_id,
                    src_node_type="file",
                    src_node_id=rel,
                    dst_repo_id=info.repo_id,
                    dst_node_type="file",
                    dst_node_id=candidate,
                    kind="tests",
                    confidence=0.8,
                    metadata={"signal": "filename"},
                    generation_id=self._active_generation_id,
                )

    def _link_calls(self, info: SnapshotInfo, rel: str, extracted: ExtractedFile) -> None:
        names = {call.split(".")[-1] for call in extracted.calls}
        if self._active_generation_id is None:
            return
        for target in self.store.symbols_named_in_generation(
            info.repo_id, names, generation_id=self._active_generation_id
        ):
            if target["path"] == rel:
                confidence = 0.7
            else:
                confidence = 0.45
            self.store.put_edge(
                scope_snapshot_id=info.snapshot_id,
                src_repo_id=info.repo_id,
                src_node_type="file",
                src_node_id=rel,
                dst_repo_id=info.repo_id,
                dst_node_type="symbol",
                dst_node_id=target["symbol_identity_id"],
                kind="calls",
                confidence=confidence,
                metadata={"qualname": target["qualname"]},
                generation_id=self._active_generation_id,
            )

    def _store_test_commands(self, repo_id: str) -> None:
        if (self.repo_root / "pytest.ini").exists() or any(
            (self.repo_root / name).exists() for name in ["pyproject.toml", "setup.cfg"]
        ):
            self.store.put_test_command(
                repo_id=repo_id, path_glob="tests/**/*.py", command="pytest"
            )
            self.store.put_test_command(
                repo_id=repo_id, path_glob="**/test_*.py", command="pytest {path}"
            )
        if (self.repo_root / "package.json").exists():
            self.store.put_test_command(
                repo_id=repo_id, path_glob="**/*.test.ts", command="npm test -- {path}"
            )
            self.store.put_test_command(
                repo_id=repo_id, path_glob="**/*.test.tsx", command="npm test -- {path}"
            )

    def _retain_dirty_blobs(self, info: SnapshotInfo, files: list[Path]) -> None:
        status = self._git(["status", "--porcelain"], fallback="") or ""
        dirty_files = {line[3:].replace("\\", "/") for line in status.splitlines() if len(line) > 3}
        for path in files:
            rel = relpath(path, self.repo_root)
            if rel in dirty_files:
                content = self._safe_read_bytes(path)
                if content is None:
                    continue
                self.store.put_dirty_blob(
                    snapshot_id=info.snapshot_id,
                    path=rel,
                    content_hash=sha256_bytes(content),
                    content=content,
                )

    def _discover_files(self, deadline: Deadline) -> list[Path]:
        files: list[Path] = []
        git_candidates = self._git_source_candidates()
        candidates: Iterable[Path]
        if git_candidates is None:
            candidates = self.repo_root.rglob("*")
        else:
            candidates = git_candidates
        for path in candidates:
            deadline.check("index_discovery")
            rel = relpath(path, self.repo_root)
            if ".git/" in rel or rel.startswith(".git/") or is_ignored(rel, self.settings):
                continue
            if any(fnmatch.fnmatch(rel, glob) for glob in self.settings.sharding.cold_path_globs):
                continue
            if path.suffix.lower() not in SUPPORTED_EXTS:
                continue
            try:
                if path.is_file():
                    files.append(path)
            except OSError:
                continue
        return sorted(files)

    def _git_source_candidates(self) -> list[Path] | None:
        """Return tracked and unignored files, or ``None`` outside a Git worktree."""

        try:
            completed = subprocess.run(
                ["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard"],
                cwd=self.repo_root,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                check=False,
                timeout=30,
            )
        except (OSError, subprocess.TimeoutExpired):
            return None
        if completed.returncode != 0:
            return None
        return [
            self.repo_root / raw.decode("utf-8", errors="surrogateescape")
            for raw in completed.stdout.split(b"\0")
            if raw
        ]

    def _is_lazy_embed_path(self, rel: str) -> bool:
        return any(fnmatch.fnmatch(rel, glob) for glob in self.settings.sharding.lazy_embed_globs)

    def _chunker_version(self) -> str:
        return (
            f"{self.settings.toolchain.chunker_version}:{stable_id(self._chunking_identity())[:12]}"
        )

    def _chunking_identity(self) -> str:
        chunking = self.settings.chunking
        return canonical_json(
            {
                "adaptive_enabled": chunking.adaptive_enabled,
                "target_tokens": chunking.target_tokens,
                "max_tokens": chunking.max_tokens,
                "min_tokens": chunking.min_tokens,
                "overlap_lines": chunking.overlap_lines,
                "max_chunks_per_file": chunking.max_chunks_per_file,
                "split_oversized_symbols": chunking.split_oversized_symbols,
                "split_symbol_free_files": chunking.split_symbol_free_files,
                "markdown_heading_split": chunking.markdown_heading_split,
            }
        )

    def _embedding_identity(self) -> dict[str, object]:
        return {
            "requested_backend": self.settings.toolchain.embed_backend,
            "effective_backend": self.embedder.backend,
            "requested_model": self.settings.toolchain.embed_model,
            "effective_model": self.embedder.model_name,
            "dimensions": self.embedder.dims,
            "encoding": self.settings.toolchain.vector_encoding,
            "implementation_signature": self.embedder.implementation_signature,
            "degraded_reason": self.embedder.degraded_reason,
        }

    def _tree_digest(self, files: list[Path], deadline: Deadline) -> str:
        parts: list[str] = []
        for path in files:
            deadline.check("identity_hashing")
            rel = relpath(path, self.repo_root)
            stat = self._safe_stat(path)
            content = self._safe_read_bytes(path)
            if stat is None or content is None:
                continue
            parts.append(f"{rel}\0{stat.st_mode}\0{sha256_bytes(content)}")
        return stable_id(*parts)

    def _dirty_digest(self, files: list[Path], deadline: Deadline) -> str:
        deadline.check("identity_dirty_state")
        status = self._git(["status", "--porcelain"], fallback="")
        if not status:
            return ""
        dirty_files = {line[3:].replace("\\", "/") for line in status.splitlines() if len(line) > 3}
        parts: list[str] = []
        for path in files:
            deadline.check("identity_dirty_hashing")
            rel = relpath(path, self.repo_root)
            if rel in dirty_files:
                content = self._safe_read_bytes(path)
                if content is not None:
                    parts.append(f"{rel}\0{sha256_bytes(content)}")
        return stable_id(*parts, status)

    def _safe_stat(self, path: Path):
        try:
            return path.stat()
        except OSError:
            return None

    def _safe_read_bytes(self, path: Path) -> bytes | None:
        try:
            return path.read_bytes()
        except OSError:
            return None

    def _git(self, args: list[str], fallback: str | None) -> str | None:
        try:
            result = subprocess.run(
                ["git", *args],
                cwd=self.repo_root,
                check=True,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                timeout=10,
            )
        except (subprocess.SubprocessError, FileNotFoundError):
            return fallback
        return result.stdout.strip() or fallback

    def _git_remote(self) -> str | None:
        return self._git(["config", "--get", "remote.origin.url"], fallback=None)


def _python_module_aliases(rel: str) -> list[str]:
    module = rel[:-3].replace("/", ".")
    module = module.removesuffix(".__init__")
    aliases = [module]
    if module.startswith("src."):
        aliases.append(module[len("src.") :])
    return list(dict.fromkeys(aliases))


def _explicit_covers_paths(text: str) -> list[str]:
    paths: list[str] = []
    for line in text.splitlines():
        match = COVERS_RE.match(line)
        if not match:
            continue
        for raw_path in match.group("paths").split(","):
            path = _normalize_covers_path(raw_path)
            if path:
                paths.append(path)
    return list(dict.fromkeys(paths))


def _normalize_covers_path(raw_path: str) -> str:
    path = raw_path.strip().strip("`'\"<>").rstrip(".;")
    path = path.replace("\\", "/").removeprefix("./")
    if not path or path.startswith("/") or re.match(r"^[A-Za-z]:/", path):
        return ""
    if any(part == ".." for part in Path(path).parts):
        return ""
    return path
