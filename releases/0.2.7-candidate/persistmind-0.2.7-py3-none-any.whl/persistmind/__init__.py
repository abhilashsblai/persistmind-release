"""PersistMind's canonical local-first project-intelligence implementation."""

__all__ = ["__version__"]

__version__ = "0.2.7"
