from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from persistmind.memory.unified import UnifiedMemory
from persistmind.snapshot import SnapshotInfo
from persistmind.utils import canonical_json, stable_id, utc_now


@dataclass(frozen=True)
class LoopVerifyResult:
    record: dict[str, Any]


class LoopVerifier:
    def __init__(
        self,
        *,
        repo_root: Path,
        store: Any,
        workspace_id: str,
        repo_id: str | None,
    ) -> None:
        self.repo_root = repo_root
        self.store = store
        self.workspace_id = workspace_id
        self.repo_id = repo_id

    def run(
        self,
        *,
        snapshot: SnapshotInfo,
        task: str,
        probe: str = "ranking",
        require_closure: bool = False,
    ) -> dict[str, Any]:
        if probe == "all":
            records = [
                self.run(snapshot=snapshot, task=task, probe="ranking")["record"],
                self.run(snapshot=snapshot, task=task, probe="rule_status")["record"],
            ]
            closed = all(item["gate"]["closed"] for item in records)
            result = {
                "ok": closed or not require_closure,
                "records": records,
                "gate": {"closed": closed},
            }
            if require_closure and not closed:
                result["error"] = "loop closure gate failed"
            return result
        if probe not in {"ranking", "rule_status"}:
            raise ValueError("probe must be ranking, rule_status, or all")
        record = (
            self._ranking_probe(snapshot, task)
            if probe == "ranking"
            else self._rule_status_probe(snapshot, task)
        )
        if require_closure and not record["gate"]["closed"]:
            return {"ok": False, "record": record, "error": "loop closure gate failed"}
        return {"ok": True, "record": record}

    def _ranking_probe(self, snapshot: SnapshotInfo, task: str) -> dict[str, Any]:
        paths = [row["path"] for row in self.store.snapshot_files(snapshot.snapshot_id)[:5]]
        if len(paths) < 2:
            paths = ["persistmind-loop-control.py", "persistmind-loop-target.py"]
        memory = UnifiedMemory(self.store, workspace_id=self.workspace_id, repo_id=self.repo_id)
        before_order = _recall_order(memory.recall(task, paths=paths, active_only=False))
        target_path = paths[-1]
        target_ref = stable_id("candidate", target_path)
        outcome_id = self.store.record_outcome(
            pack_id=stable_id("loop_verify_pack", snapshot.snapshot_id, task, time.time_ns()),
            result="pass",
            files_changed=[target_path],
        )
        outcome_event = self.store.write_learning_event(
            phase="phase_h4",
            kind="loop_verify_outcome_injected",
            ref=outcome_id,
            payload={"probe": "ranking", "target_path": target_path},
        )
        after_order = _recall_order(memory.recall(task, paths=paths, active_only=False))
        event_id = self.store.write_learning_event(
            phase="phase_h4",
            kind="loop_verify_run",
            ref=target_ref,
            payload={
                "probe": "ranking",
                "changed": before_order != after_order,
                "attributable": True,
            },
        )
        return self._record(
            snapshot=snapshot,
            probe={
                "kind": "ranking",
                "task": task,
                "injected_outcome": {
                    "outcome_id": outcome_id,
                    "paths": [target_path],
                    "result": "pass",
                },
                "target_ref": target_ref,
            },
            before={
                "ordering": before_order,
                "rule_status": None,
                "rank_of_target": _rank(before_order, target_ref),
            },
            after={
                "ordering": after_order,
                "rule_status": None,
                "rank_of_target": _rank(after_order, target_ref),
            },
            effect={
                "changed": before_order != after_order,
                "rank_delta": _rank_delta(before_order, after_order, target_ref),
                "status_transition": None,
                "attributable": True,
                "attribution_path": [outcome_event, event_id],
            },
        )

    def _rule_status_probe(self, snapshot: SnapshotInfo, task: str) -> dict[str, Any]:
        memory = UnifiedMemory(self.store, workspace_id=self.workspace_id, repo_id=self.repo_id)
        record_id = stable_id("loop_verify_rule", snapshot.snapshot_id, task)
        assertion = f"Loop verification rule for {task}."
        memory.propose(
            record_type="fact",
            assertion=assertion,
            source_kind="loop_verify",
            confidence=0.5,
            record_id=record_id,
            status="candidate",
            trust="untrusted",
            provenance={"generator": "agent:loop_verify", "validator": "none"},
            metadata={"loop_verify": True},
        )
        before_status = self.store.memory_record(record_id)["status"]
        outcome_id = self.store.record_outcome(
            pack_id=stable_id("loop_verify_rule_pack", snapshot.snapshot_id, task, time.time_ns()),
            result="pass",
            files_changed=[],
        )
        outcome_event = self.store.write_learning_event(
            phase="phase_h4",
            kind="loop_verify_outcome_injected",
            ref=outcome_id,
            payload={"probe": "rule_status", "target_ref": record_id},
        )
        event_id = self.store.write_learning_event(
            phase="phase_h4",
            kind="loop_verify_run",
            ref=record_id,
            payload={"probe": "rule_status", "changed": False, "attributable": False},
        )
        after_status = self.store.memory_record(record_id)["status"]
        return self._record(
            snapshot=snapshot,
            probe={
                "kind": "rule_status",
                "task": task,
                "injected_outcome": {
                    "outcome_id": outcome_id,
                    "paths": [],
                    "result": "pass",
                },
                "target_ref": record_id,
            },
            before={
                "ordering": [],
                "rule_status": before_status,
                "rank_of_target": None,
            },
            after={"ordering": [], "rule_status": after_status, "rank_of_target": None},
            effect={
                "changed": before_status != after_status,
                "rank_delta": None,
                "status_transition": f"{before_status}->{after_status}",
                "attributable": False,
                "attribution_path": [outcome_event, event_id],
            },
        )

    def _record(
        self,
        *,
        snapshot: SnapshotInfo,
        probe: dict[str, Any],
        before: dict[str, Any],
        after: dict[str, Any],
        effect: dict[str, Any],
    ) -> dict[str, Any]:
        closed = bool(effect["changed"] and effect["attributable"])
        record = {
            "loop_verify_id": stable_id(
                snapshot.snapshot_id, canonical_json(probe), canonical_json(effect)
            ),
            "created_at": utc_now(),
            "snapshot_id": snapshot.snapshot_id,
            "repo_id": snapshot.repo_id,
            "workspace_id": self.workspace_id,
            "probe": probe,
            "before": before,
            "after": after,
            "effect": effect,
            "gate": {
                "closed": closed,
                "reason": "closed" if closed else "no_attributable_effect",
            },
        }
        run_id = self.store.write_learning_run(
            target="loop_verify",
            kind=f"phase_h4_{probe['kind']}",
            before=before,
            after=after,
            train_metrics={"effect": effect, "probe": probe},
            holdout_metrics={"gate": record["gate"]},
            gate_pass=closed,
            archived=True,
            promoted=False,
            run_id=record["loop_verify_id"],
        )
        audit = self.store.append_audit(
            pack_id=run_id,
            payload={
                "event": "loop_verify",
                "loop_verify_id": run_id,
                "gate": record["gate"],
            },
        )
        record["audit_hash"] = audit["row_hash"]
        record["prev_audit_hash"] = audit["prev_hash"]
        return record


def _recall_order(result: dict[str, Any]) -> list[str]:
    rows = result.get("results") or result.get("items") or []
    order: list[str] = []
    for row in rows:
        if isinstance(row, dict):
            record_id = str(row.get("record_id") or "")
            if record_id:
                order.append(record_id)
    return order


def _rank(order: list[str], target_ref: str) -> int | None:
    return order.index(target_ref) if target_ref in order else None


def _rank_delta(before: list[str], after: list[str], target_ref: str) -> int | None:
    before_rank = _rank(before, target_ref)
    after_rank = _rank(after, target_ref)
    if before_rank is None or after_rank is None:
        return None
    return after_rank - before_rank
