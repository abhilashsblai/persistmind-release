from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from persistmind.learning.taxonomy import Attribution, BlastRadius, Category, Severity


@dataclass(frozen=True)
class Lesson:
    category: Category
    attribution: Attribution
    mechanism: str
    severity: Severity
    blast_radius: BlastRadius
    recurrence_key: str
    symptom: str
    root_cause: str
    resolution: str
    prevent_recurrence: str
    detection_method: str
    evidence_refs: list[str] = field(default_factory=list)
    affected_paths: list[str] = field(default_factory=list)
    applies_when: str = ""
    avoid_when: str = ""
    verification_commands: list[str] = field(default_factory=list)
    cost_tokens: int = 0
    cost_seconds: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


LESSON_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": [
        "category",
        "attribution",
        "mechanism",
        "severity",
        "blast_radius",
        "recurrence_key",
        "symptom",
        "root_cause",
        "resolution",
        "prevent_recurrence",
        "detection_method",
        "evidence_refs",
    ],
    "properties": {
        "category": {"type": "string"},
        "attribution": {"type": "string"},
        "mechanism": {"type": "string"},
        "severity": {"type": "string"},
        "blast_radius": {"type": "string"},
        "recurrence_key": {"type": "string"},
        "symptom": {"type": "string"},
        "root_cause": {"type": "string"},
        "resolution": {"type": "string"},
        "prevent_recurrence": {"type": "string"},
        "detection_method": {"type": "string"},
        "evidence_refs": {"type": "array", "items": {"type": "string"}},
        "affected_paths": {"type": "array", "items": {"type": "string"}},
        "applies_when": {"type": "string"},
        "avoid_when": {"type": "string"},
        "verification_commands": {"type": "array", "items": {"type": "string"}},
        "cost_tokens": {"type": "integer", "minimum": 0},
        "cost_seconds": {"type": "number", "minimum": 0.0},
    },
    "additionalProperties": False,
}
