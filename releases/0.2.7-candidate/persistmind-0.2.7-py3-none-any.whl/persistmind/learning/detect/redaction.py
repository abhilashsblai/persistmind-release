from __future__ import annotations

from typing import Any

from persistmind.security.redaction import redact_with_summary
from persistmind.utils import sha256_text

DEFAULT_EXCERPT_LIMIT = 2000


def redact_excerpt(text: str, *, limit: int = DEFAULT_EXCERPT_LIMIT) -> dict[str, Any]:
    redacted, summary = redact_with_summary(str(text or ""))
    excerpt = redacted[: max(0, int(limit))]
    return {
        "excerpt": excerpt,
        "content_hash": "sha256:" + sha256_text(redacted),
        "redaction": summary,
        "truncated": len(redacted) > len(excerpt),
    }
