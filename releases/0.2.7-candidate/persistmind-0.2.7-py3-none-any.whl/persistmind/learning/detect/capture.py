from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from persistmind.learning.detect.redaction import redact_excerpt

DETECTOR_VERSION = "signal.capture.v1"
SIGNAL_KINDS = frozenset(
    {
        "edit_churn",
        "governance_gate_block",
        "plan_deviation",
        "self_revert",
        "test_run",
        "tool_failure",
        "user_correction",
    }
)


class SignalRecorder:
    """Best-effort writer for raw mistake-intelligence observations."""

    def __init__(
        self,
        store: Any,
        *,
        per_signal_limit: int = 2000,
        per_session_limit: int = 100,
    ) -> None:
        self.store = store
        self.per_signal_limit = max(0, int(per_signal_limit))
        self.per_session_limit = max(1, int(per_session_limit))

    def record(
        self,
        *,
        source: str,
        signal_kind: str,
        content: str = "",
        task_session_id: str | None = None,
        turn_id: str | None = None,
        evidence_ref: str | None = None,
        structural: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        try:
            if self._session_signal_count(task_session_id) >= self.per_session_limit:
                return {"ok": False, "skipped": True, "reason": "session_signal_budget_exceeded"}
            redacted = redact_excerpt(content, limit=self.per_signal_limit)
            payload = {
                **dict(structural or {}),
                "redaction": redacted["redaction"],
                "truncated": redacted["truncated"],
            }
            row = self.store.record_learning_signal(
                source=source,
                signal_kind=signal_kind,
                task_session_id=task_session_id,
                turn_id=turn_id,
                evidence_ref=evidence_ref,
                content_excerpt=redacted["excerpt"],
                content_hash=redacted["content_hash"],
                structural=payload,
                detector_version=DETECTOR_VERSION,
            )
            return {"ok": True, "signal": row}
        except Exception as exc:
            return {"ok": False, "skipped": True, "reason": type(exc).__name__}

    def _session_signal_count(self, task_session_id: str | None) -> int:
        if not task_session_id or not hasattr(self.store, "learning_signals"):
            return 0
        try:
            return len(self.store.learning_signals(task_session_id=task_session_id, limit=10000))
        except Exception:
            return 0
