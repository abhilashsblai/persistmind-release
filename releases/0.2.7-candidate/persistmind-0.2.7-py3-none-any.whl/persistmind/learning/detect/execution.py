from __future__ import annotations

import re
from collections import Counter
from collections.abc import Mapping, Sequence
from typing import Any


def extract_tool_failure(tool_name: str, response: Mapping[str, Any]) -> dict[str, Any] | None:
    exit_code = response.get("exit_code")
    stderr = str(response.get("stderr") or "")
    stdout = str(response.get("stdout") or "")
    text = "\n".join(part for part in (stdout, stderr) if part)
    failed = _failed_exit(exit_code) or _looks_like_failure(text)
    if not failed:
        return None
    return {
        "source": "PostToolUse",
        "signal_kind": "tool_failure",
        "evidence_ref": str(tool_name),
        "content": text[-2000:],
        "structural": {
            "tool_name": tool_name,
            "exit_code": exit_code,
            "failure_markers": _failure_markers(text),
        },
    }


#: Writes to one path within a session before churn is considered a signal.
EDIT_CHURN_THRESHOLD = 3


def edit_churn_signal(
    records: Sequence[Mapping[str, Any]], paths: Sequence[str]
) -> dict[str, Any] | None:
    """Flag a path rewritten repeatedly inside one session.

    Repeated rewrites of the same file usually mean the first attempts were
    wrong, which is a mistake the agent made without anyone telling it.
    """

    targets = {str(path) for path in paths if str(path).strip()}
    if not targets:
        return None
    counts: Counter[str] = Counter()
    for record in records:
        for path in record.get("paths") or []:
            if str(path) in targets:
                counts[str(path)] += 1
    churned = sorted(path for path, count in counts.items() if count >= EDIT_CHURN_THRESHOLD)
    if not churned:
        return None
    return {
        "source": "PostToolUse",
        "signal_kind": "edit_churn",
        "evidence_ref": churned[0],
        "content": f"{churned[0]} was written {counts[churned[0]]} times in one session",
        "structural": {
            "edited_paths": churned,
            "last_write_paths": churned,
            "write_counts": {path: counts[path] for path in churned},
        },
    }


def self_revert_signal(
    records: Sequence[Mapping[str, Any]], paths: Sequence[str], digest: str
) -> dict[str, Any] | None:
    """Flag a write that restores content the agent had already replaced.

    Requires an intervening different digest for the same path, so a no-op
    rewrite of unchanged content is not mistaken for a revert.
    """

    if not digest:
        return None
    targets = {str(path) for path in paths if str(path).strip()}
    if not targets:
        return None
    for path in sorted(targets):
        history = [
            str(record.get("content_digest") or "")
            for record in records
            if path in {str(item) for item in (record.get("paths") or [])}
            and str(record.get("content_digest") or "")
        ]
        if digest not in history[:-1]:
            continue
        earlier = history.index(digest)
        if any(item != digest for item in history[earlier + 1 :]):
            return {
                "source": "PostToolUse",
                "signal_kind": "self_revert",
                "evidence_ref": path,
                "content": f"{path} was restored to a previously replaced version",
                "structural": {
                    "edited_paths": [path],
                    "last_write_paths": [path],
                    "restored_digest": digest,
                },
            }
    return None


def plan_deviation_signal(
    plan_id: str, step_id: str, paths: Sequence[str], reason: str = ""
) -> dict[str, Any]:
    normalized = [str(path) for path in paths if str(path).strip()]
    return {
        "source": "plan_checkpoint",
        "signal_kind": "plan_deviation",
        "evidence_ref": plan_id,
        "content": reason or f"checkpoint outside step {step_id}",
        "structural": {
            "plan_id": plan_id,
            "step_id": step_id,
            "edited_paths": normalized,
            "last_write_paths": normalized,
        },
    }


def test_run_signal(command: str, result: str, output: str = "") -> dict[str, Any]:
    return {
        "source": "verify_run",
        "signal_kind": "test_run",
        "evidence_ref": command,
        "content": output[-2000:],
        "structural": {"command": command, "result": result},
    }


def _failed_exit(exit_code: Any) -> bool:
    try:
        return int(exit_code) != 0
    except (TypeError, ValueError):
        return False


def _looks_like_failure(text: str) -> bool:
    lowered = text.lower()
    return any(
        marker in lowered
        for marker in ("traceback", "assertionerror", "failed", "error:", "exception")
    )


def _failure_markers(text: str) -> list[str]:
    lowered = text.lower()
    markers = []
    for name, pattern in {
        "traceback": r"\btraceback\b",
        "assertion": r"\bassertionerror\b",
        "pytest_failed": r"\bfailed\b",
        "compiler_error": r"\berror:",
        "exception": r"\bexception\b",
    }.items():
        if re.search(pattern, lowered):
            markers.append(name)
    return markers
