from __future__ import annotations

import re
from collections import Counter
from collections.abc import Mapping, Sequence
from typing import Any

from persistmind.learning.taxonomy import TaxonomyClassification, classify_revision_text
from persistmind.utils import stable_id

DETECTOR_VERSION = "correction.detector.v1"


def classify_correction(
    text: str,
    *,
    edited_paths: Sequence[str] = (),
    last_write_paths: Sequence[str] = (),
) -> dict[str, Any]:
    classification = classify_revision_text(text)
    tokens = set(_tokens(text))
    path_overlap = _path_overlap(tokens, [*edited_paths, *last_write_paths])
    confidence = min(1.0, classification.confidence + (0.05 if path_overlap else 0.0))
    recurrence_key = stable_id(
        "recurrence",
        classification.category,
        _mechanism_for(classification, tokens),
        ",".join(path_overlap),
    )
    return {
        "detector_version": DETECTOR_VERSION,
        "category": classification.category,
        "attribution": classification.attribution,
        "mechanism": _mechanism_for(classification, tokens),
        "severity": classification.severity,
        "blast_radius": classification.blast_radius,
        "confidence": round(confidence, 4),
        "recurrence_key": recurrence_key,
        "affected_paths": path_overlap,
        "features": {
            "tokens": sorted(tokens),
            "path_overlap": path_overlap,
        },
        "summary": classification.rationale,
    }


def bundle_from_signals(signals: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Classify a whole signal bundle rather than only its first member.

    A single mistake often surfaces as several signals (a failing test, then a
    user correction). Classifying only ``signals[0]`` discards whichever arrived
    later, so the winning classification is chosen on specificity and the
    affected paths are unioned across every contributing signal.
    """

    classified = [(signal, bundle_from_signal(signal)) for signal in signals]
    if not classified:
        raise ValueError("cannot classify an empty signal bundle")
    affected = sorted(
        {
            str(path)
            for _, item in classified
            for path in item.get("affected_paths", [])
            if str(path).strip()
        }
    )
    primary_signal, winner = max(classified, key=lambda item: _specificity(item[1]))
    if affected == winner.get("affected_paths"):
        merged = dict(winner)
    else:
        # The recurrence key is derived from the scope, so it has to be
        # recomputed whenever the unioned paths differ from the winner's.
        merged = dict(winner)
        merged["affected_paths"] = affected
        merged["recurrence_key"] = stable_id(
            "recurrence",
            str(winner["category"]),
            str(winner["mechanism"]),
            ",".join(affected),
        )
    merged["contributing_signal_kinds"] = sorted(
        {str(signal.get("signal_kind") or "") for signal, _ in classified if signal.get("signal_kind")}
    )
    merged["bundle_size"] = len(classified)
    return {"primary_signal": primary_signal, **merged}


def _specificity(classification: Mapping[str, Any]) -> tuple[int, float]:
    """Rank a classification: a real category outranks the catch-all."""

    concrete = 0 if str(classification.get("category")) == "system_health" else 1
    return (concrete, float(classification.get("confidence") or 0.0))


def bundle_from_signal(signal: Mapping[str, Any]) -> dict[str, Any]:
    structural = signal.get("structural")
    if not isinstance(structural, Mapping):
        structural = {}
    text = str(signal.get("content_excerpt") or "")
    return classify_correction(
        text,
        edited_paths=[str(path) for path in structural.get("edited_paths", [])],
        last_write_paths=[str(path) for path in structural.get("last_write_paths", [])],
    )


def _tokens(text: str) -> list[str]:
    return re.findall(r"[a-zA-Z][a-zA-Z0-9_]{2,}", text.lower())


def _path_overlap(tokens: set[str], paths: Sequence[str]) -> list[str]:
    result: list[str] = []
    for path in paths:
        path_tokens = set(_tokens(path.replace("/", " ").replace("\\", " ")))
        if tokens & path_tokens:
            result.append(str(path).replace("\\", "/"))
    return sorted(set(result))


def _mechanism_for(classification: TaxonomyClassification, tokens: set[str]) -> str:
    if "wrong" in tokens or "incorrect" in tokens:
        return "incorrect_output"
    if "broken" in tokens or "error" in tokens:
        return "execution_error"
    if "revert" in tokens or "rollback" in tokens or "undo" in tokens:
        return "reverted_work"
    if classification.category == "verification_gap":
        return "missing_or_unclear_validation"
    if classification.category == "requirement_analysis":
        return "missed_requirement"
    if classification.category == "user_intent_mismatch":
        return "style_or_intent_mismatch"
    most_common = Counter(tokens).most_common(1)
    return most_common[0][0] if most_common else "unknown"
