from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from persistmind.learning.contracts import Lesson
from persistmind.learning.taxonomy import normalize_category
from persistmind.utils import stable_id

KNOWLEDGE_LESSON_CONSUMER = "knowledge.lesson.v1"


def project_mistake_to_lesson(
    mistake: Mapping[str, Any],
    *,
    knowledge_service: Any,
) -> dict[str, Any]:
    lesson = lesson_from_mistake(mistake)
    record_id = stable_id("failure_lesson", lesson.recurrence_key)
    existing = _existing_lesson(knowledge_service, record_id)
    existing_metadata = (
        dict(existing.get("metadata") or {}) if isinstance(existing, Mapping) else {}
    )
    evidence_refs = _merge_strings(existing_metadata.get("evidence_refs"), lesson.evidence_refs)
    affected_paths = _merge_strings(existing_metadata.get("affected_paths"), lesson.affected_paths)
    mistake_ids = _merge_strings(existing_metadata.get("mistake_ids"), [mistake.get("mistake_id")])
    support_count = max(
        len(mistake_ids),
        _non_negative_int(existing_metadata.get("support_count")) + 1
        if existing_metadata
        else 1,
    )
    signal_kinds = _merge_strings(existing_metadata.get("signal_kinds"), mistake.get("signal_kinds"))
    metadata = {
        **lesson.to_dict(),
        "evidence_refs": evidence_refs,
        "affected_paths": affected_paths,
        "mistake_ids": mistake_ids,
        "support_count": support_count,
        "signal_kinds": signal_kinds,
    }
    confidence = min(0.99, max(float(mistake.get("confidence") or 0.7), 0.7 + support_count * 0.05))
    payload = {
        "record_id": record_id,
        "type": "failure_lesson",
        "title": lesson.symptom[:120] or f"Failure lesson {lesson.recurrence_key[:12]}",
        "assertion": _lesson_assertion(lesson, signal_kinds),
        "confidence": confidence,
        "status": "active",
        "trust": "untrusted",
        "source_kind": "learning:mistake_event",
        "metadata": metadata,
        "evidence": [
            {
                "repo_id": getattr(knowledge_service, "repo_id", None),
                "path": path,
                "symbol_identity_id": None,
                "evidence_kind": "mistake_event",
                "evidence_hash": stable_id("mistake_evidence", mistake.get("mistake_id"), path),
                "source_ref": mistake.get("mistake_id"),
                "metadata": {"mistake_id": mistake.get("mistake_id")},
            }
            for path in affected_paths
        ],
    }
    result = knowledge_service.memory_create_typed(payload)
    return {
        "ok": bool(result.get("ok")),
        "consumer": KNOWLEDGE_LESSON_CONSUMER,
        "mistake_id": mistake.get("mistake_id"),
        "record": result.get("record"),
    }


def lesson_from_mistake(mistake: Mapping[str, Any]) -> Lesson:
    category = normalize_category(str(mistake.get("category") or "system_health"))
    affected_paths = [str(path) for path in mistake.get("affected_paths", []) if str(path)]
    signal_ids = [str(signal_id) for signal_id in mistake.get("signal_ids", []) if str(signal_id)]
    symptom = str(mistake.get("symptom") or category).strip()
    root_cause = str(mistake.get("root_cause") or mistake.get("mechanism") or "").strip()
    resolution = str(mistake.get("resolution") or "Apply the observed correction.").strip()
    prevention = str(mistake.get("prevent_recurrence") or resolution).strip()
    return Lesson(
        category=category,
        attribution=str(mistake.get("attribution") or "one_off"),  # type: ignore[arg-type]
        mechanism=str(mistake.get("mechanism") or "unknown"),
        severity=str(mistake.get("severity") or "medium"),  # type: ignore[arg-type]
        blast_radius=str(mistake.get("blast_radius") or "session"),  # type: ignore[arg-type]
        recurrence_key=str(mistake.get("recurrence_key") or ""),
        symptom=symptom,
        root_cause=root_cause,
        resolution=resolution,
        prevent_recurrence=prevention,
        detection_method=str(mistake.get("detection_method") or "mistake_event"),
        evidence_refs=signal_ids,
        affected_paths=affected_paths,
        cost_tokens=_non_negative_int(mistake.get("cost_tokens")),
        cost_seconds=_non_negative_float(mistake.get("cost_seconds")),
    )


def _clause(text: str) -> str:
    """Trim a sentence so it can be embedded mid-assertion without double stops."""

    return str(text or "").strip().rstrip(".;, ").strip()


def _lesson_assertion(lesson: Lesson, signal_kinds: list[str]) -> str:
    provenance = _bundle_provenance(signal_kinds)
    prefix = f"{provenance}, " if provenance else "When "
    condition = _clause(lesson.symptom)
    if provenance:
        condition = "when " + condition
    return (
        f"{prefix}{condition}, the root cause was "
        f"{_clause(lesson.root_cause)}; resolve it by {_clause(lesson.resolution)}."
    )


def _bundle_provenance(signal_kinds: list[str]) -> str:
    readable = [_readable_signal_kind(kind) for kind in signal_kinds]
    unique = list(dict.fromkeys(item for item in readable if item))
    if len(unique) <= 1:
        return ""
    return "Corroborated by " + " and ".join(unique[:3])


def _readable_signal_kind(kind: str) -> str:
    return {
        "test_run": "a failing test",
        "tool_failure": "a tool failure",
        "user_correction": "a user correction",
        "edit_churn": "edit churn",
        "self_revert": "a self-revert",
        "plan_deviation": "a plan deviation",
    }.get(str(kind), str(kind).replace("_", " "))


def _existing_lesson(knowledge_service: Any, record_id: str) -> Mapping[str, Any] | None:
    try:
        shown = knowledge_service.memory_show(record_id)
    except Exception:
        return None
    if not isinstance(shown, Mapping):
        return None
    record = shown.get("record")
    return record if isinstance(record, Mapping) else None


def _merge_strings(*values: Any) -> list[str]:
    merged: list[str] = []
    for value in values:
        if isinstance(value, str):
            candidates = [value]
        elif isinstance(value, list):
            candidates = value
        else:
            candidates = []
        for item in candidates:
            text = str(item or "").strip()
            if text and text not in merged:
                merged.append(text)
    return merged


def _non_negative_int(value: Any) -> int:
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return 0


def _non_negative_float(value: Any) -> float:
    try:
        return max(0.0, float(value))
    except (TypeError, ValueError):
        return 0.0
