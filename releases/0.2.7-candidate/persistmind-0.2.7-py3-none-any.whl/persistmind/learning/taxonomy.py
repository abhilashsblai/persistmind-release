from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

Category = Literal[
    "context_selection",
    "impact_prediction",
    "memory_quality",
    "skill_quality",
    "loop_closure",
    "eval_regression",
    "selfmod_safety",
    "security",
    "goal_alignment",
    "surface_parity",
    "system_health",
    "requirement_analysis",
    "verification_gap",
    "execution_discipline",
    "user_intent_mismatch",
    "regression",
    "premature_completion",
]
Attribution = Literal[
    "one_off",
    "agent_defect",
    "underspecified_prompt",
    "skill_defect",
    "system_defect",
    "environment",
    "user_preference",
    "external_dependency",
]
Severity = Literal["low", "medium", "high", "critical"]
BlastRadius = Literal["session", "repo", "workspace", "global"]

CATEGORIES: tuple[Category, ...] = (
    "context_selection",
    "impact_prediction",
    "memory_quality",
    "skill_quality",
    "loop_closure",
    "eval_regression",
    "selfmod_safety",
    "security",
    "goal_alignment",
    "surface_parity",
    "system_health",
    "requirement_analysis",
    "verification_gap",
    "execution_discipline",
    "user_intent_mismatch",
    "regression",
    "premature_completion",
)
ATTRIBUTIONS: tuple[Attribution, ...] = (
    "one_off",
    "agent_defect",
    "underspecified_prompt",
    "skill_defect",
    "system_defect",
    "environment",
    "user_preference",
    "external_dependency",
)
SEVERITIES: tuple[Severity, ...] = ("low", "medium", "high", "critical")
BLAST_RADII: tuple[BlastRadius, ...] = ("session", "repo", "workspace", "global")

DESCRIPTIONS: dict[Category, str] = {
    "context_selection": "Wrong, missing, stale, or excessive context selection.",
    "impact_prediction": "Changed-file impact, test selection, or blast-radius prediction weakness.",
    "memory_quality": "Stale, conflicting, untrusted, or poorly recalled memory.",
    "skill_quality": "Skill trigger, replay, applicability, or maintenance weakness.",
    "loop_closure": "A repeated issue did not affect later behavior.",
    "eval_regression": "Benchmark, holdout, canary, or scorecard regression.",
    "selfmod_safety": "Self-modification validation, allowlist, judge, or approval failure.",
    "security": "Secret, PII, prompt-injection, policy, or redaction risk.",
    "goal_alignment": "Wrong goal, unclear success metric, or unhandled challenge.",
    "surface_parity": "CLI, MCP, HTTP, dashboard, or rollup behavior drift.",
    "system_health": "Audit, snapshot, staleness, concurrency, or storage health issue.",
    "requirement_analysis": "Missed acceptance criteria, edge cases, or requirement details.",
    "verification_gap": "Testing, browser validation, screenshot, or local proof gap.",
    "execution_discipline": "Skipped plan, checkpoint, sequencing, or premature completion.",
    "user_intent_mismatch": "The produced artifact did not match the user's intended output.",
    "regression": "A previously working behavior or artifact quality regressed.",
    "premature_completion": "The agent stopped or reported completion before the work was done.",
}

ALIASES: dict[str, Category] = {
    "context": "context_selection",
    "scope": "context_selection",
    "impact": "impact_prediction",
    "test": "verification_gap",
    "tests": "verification_gap",
    "verification": "verification_gap",
    "security_scan": "security",
    "secret": "security",
    "policy": "security",
    "selfmod": "selfmod_safety",
    "benchmark": "eval_regression",
    "canary": "eval_regression",
    "dashboard": "surface_parity",
    "http": "surface_parity",
    "mcp": "surface_parity",
    "intent": "user_intent_mismatch",
    "mismatch": "user_intent_mismatch",
    "regress": "regression",
    "regression": "regression",
    "premature": "premature_completion",
    "incomplete": "premature_completion",
}

REVISION_CATEGORY_LABELS: dict[str, str] = {
    "preference": "preference_memory",
    "requirement_change": "requirements_log",
    "error": "corrective_learning",
    "skill_weakness": "skill_improvement",
    "unclassified": "review_queue",
}


@dataclass(frozen=True)
class TaxonomyClassification:
    category: Category
    attribution: Attribution
    severity: Severity
    blast_radius: BlastRadius
    confidence: float
    route: str
    rationale: str


def normalize_category(value: str) -> Category:
    token = "_".join(str(value or "").strip().lower().replace("-", "_").split())
    if token in CATEGORIES:
        return token  # type: ignore[return-value]
    if token in ALIASES:
        return ALIASES[token]
    for key, category in ALIASES.items():
        if key and key in token:
            return category
    return "system_health"


def is_known_category(value: str) -> bool:
    token = "_".join(str(value or "").strip().lower().replace("-", "_").split())
    return token in CATEGORIES


def category_descriptions() -> dict[str, str]:
    return dict(DESCRIPTIONS)


def classify_revision_text(text: str) -> TaxonomyClassification:
    theme = revision_theme(text)
    category = _category_for_theme(theme)
    return TaxonomyClassification(
        category=category,
        attribution=_attribution_for_theme(theme),
        severity=_severity_for_theme(theme),
        blast_radius=_blast_radius_for_theme(theme),
        confidence=0.85 if theme != "unclassified" else 0.35,
        route=_route_for_theme(theme),
        rationale=_summary_for_theme(theme),
    )


def revision_theme(text: str) -> str:
    scores = correction_scores(text)
    if scores["regression"] >= 1:
        return "error_correction"
    if scores["verification_gap"] >= 1:
        return "missing_validation_state"
    if scores["user_intent_mismatch"] >= 1:
        return "preference_style"
    if scores["requirement_analysis"] >= 1:
        if _has_any(text, ("executive", "summary", "brief")):
            return "missing_executive_summary"
        return "requirement_change"
    if scores["premature_completion"] >= 1:
        return "premature_completion"
    if _has_any(text, ("revert", "undo", "rollback")):
        return "reverted_output"
    return "unclassified"


def revision_summary(theme: str) -> str:
    return _summary_for_theme(theme)


def correction_scores(text: str) -> dict[Category, int]:
    tokens = set(_tokens(text))
    scores: dict[Category, int] = {category: 0 for category in CATEGORIES}
    _score(scores, "regression", tokens, {"wrong", "broken", "incorrect", "error", "calculation"})
    _score(scores, "verification_gap", tokens, {"validation", "verified", "test", "tests"})
    _score(scores, "user_intent_mismatch", tokens, {"tone", "formal", "style", "color", "blue"})
    _score(scores, "requirement_analysis", tokens, {"also", "add", "export", "include", "summary"})
    _score(scores, "premature_completion", tokens, {"done", "complete", "unfinished"})
    if scores["regression"] and _negates_regression(text):
        scores["regression"] = max(0, scores["regression"] - 1)
    if "rollback" in tokens or "revert" in tokens or "undo" in tokens:
        scores["regression"] += 2
    return scores


def _category_for_theme(theme: str) -> Category:
    if theme in {"error_correction", "reverted_output"}:
        return "regression"
    if theme == "missing_validation_state":
        return "verification_gap"
    if theme == "preference_style":
        return "user_intent_mismatch"
    if theme.startswith("missing_") or theme == "requirement_change":
        return "requirement_analysis"
    return "system_health"


def _attribution_for_theme(theme: str) -> Attribution:
    if theme == "requirement_change":
        return "underspecified_prompt"
    if theme in {"error_correction", "missing_validation_state", "missing_executive_summary"}:
        return "agent_defect"
    if theme == "preference_style":
        return "user_preference"
    return "one_off"


def _severity_for_theme(theme: str) -> Severity:
    if theme in {"error_correction", "reverted_output"}:
        return "high"
    if theme.startswith("missing_"):
        return "medium"
    return "low"


def _blast_radius_for_theme(theme: str) -> BlastRadius:
    if theme in {"error_correction", "missing_validation_state"}:
        return "repo"
    return "session"


#: Words that cancel a regression marker when they immediately precede it.
_NEGATORS = frozenset({"not", "isnt", "isn", "arent", "aren", "wasnt", "wasn", "never", "nothing"})
#: Regression markers that a negator can cancel.
_REGRESSION_MARKERS = frozenset({"wrong", "broken", "incorrect", "error", "calculation"})


def _negates_regression(text: str) -> bool:
    """True only when a negator directly qualifies a regression marker.

    Scanning for a bare "not" anywhere in the text cancelled real corrections:
    "this is incorrect, the totals do not add up" lost its regression score to
    a "not" that was reinforcing the complaint, not negating it. Negation is
    therefore adjacency-scoped.
    """

    tokens = _tokens(text)
    for index, token in enumerate(tokens[:-1]):
        if token in _NEGATORS and tokens[index + 1] in _REGRESSION_MARKERS:
            return True
    return False


def _tokens(text: str) -> list[str]:
    import re

    return re.findall(r"[a-zA-Z][a-zA-Z0-9_]{2,}", text.lower())


def _score(
    scores: dict[Category, int],
    category: Category,
    tokens: set[str],
    features: set[str],
) -> None:
    scores[category] += len(tokens & features)


def _has_any(text: str, words: tuple[str, ...]) -> bool:
    tokens = set(_tokens(text))
    return bool(tokens & set(words))


def _route_for_theme(theme: str) -> str:
    if theme.startswith("preference"):
        return REVISION_CATEGORY_LABELS["preference"]
    if theme.startswith("requirement"):
        return REVISION_CATEGORY_LABELS["requirement_change"]
    if theme.startswith("error") or theme == "reverted_output":
        return REVISION_CATEGORY_LABELS["error"]
    if theme.startswith("missing_"):
        return REVISION_CATEGORY_LABELS["skill_weakness"]
    return REVISION_CATEGORY_LABELS["unclassified"]


def _summary_for_theme(theme: str) -> str:
    return {
        "missing_executive_summary": "requested executive summary",
        "missing_validation_state": "requested validation state",
        "preference_style": "style preference revision",
        "requirement_change": "new requirement revision",
        "error_correction": "error correction revision",
        "reverted_output": "output reverted",
    }.get(theme, "unclassified revision")
