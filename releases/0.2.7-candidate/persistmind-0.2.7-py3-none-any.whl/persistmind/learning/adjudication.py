from __future__ import annotations

import os
from collections.abc import Mapping
from datetime import datetime
from pathlib import Path
from typing import Any

from persistmind.learning.detect.correction import bundle_from_signals
from persistmind.learning.provider import build_agent_provider, validate_json_schema
from persistmind.security.memory_defense import detect_query_injection
from persistmind.utils import canonical_json

MISTAKE_EVENT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": [
        "category",
        "attribution",
        "mechanism",
        "severity",
        "confidence",
        "blast_radius",
        "recurrence_key",
    ],
    "properties": {
        "category": {"type": "string"},
        "attribution": {"type": "string"},
        "mechanism": {"type": "string"},
        "severity": {"type": "string"},
        "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
        "blast_radius": {"type": "string"},
        "recurrence_key": {"type": "string"},
        "symptom": {"type": "string"},
        "root_cause": {"type": "string"},
        "resolution": {"type": "string"},
        "prevent_recurrence": {"type": "string"},
        "detection_method": {"type": "string"},
        "affected_paths": {"type": "array", "items": {"type": "string"}},
    },
    "additionalProperties": False,
}


class HostAgentAdjudicator:
    """Drain persisted signal queues into adjudicated mistake events."""

    def __init__(self, store: Any, *, repo_root: Path | None = None, settings: Any = None) -> None:
        self.store = store
        self.repo_root = repo_root
        self.settings = settings

    #: Signals in one task session within this window describe one mistake.
    BUNDLE_WINDOW_SECONDS = 300
    #: Upper bound so a noisy session cannot merge into one unreadable lesson.
    BUNDLE_MAX_SIGNALS = 5

    def drain(self, *, limit: int = 20) -> dict[str, Any]:
        processed: list[dict[str, Any]] = []
        skipped: list[dict[str, Any]] = []
        dismissed: list[dict[str, Any]] = []
        deferred: list[dict[str, Any]] = []
        pending = list(self.store.pending_adjudication(limit=limit))
        consumed: set[str] = set()
        for item in pending:
            signal_ids = _signal_ids(item.get("signal_bundle"))
            if any(signal_id in consumed for signal_id in signal_ids):
                # Already folded into an earlier bundle; its queue row was
                # closed alongside that mistake.
                continue
            signals = [self.store.learning_signal(signal_id) for signal_id in signal_ids]
            signals = [signal for signal in signals if signal is not None]
            if not signals:
                skipped.append({"queue_id": item["queue_id"], "reason": "signals_missing"})
                continue
            signals = self._expand_bundle(signals, pending=pending, consumed=consumed)
            consumed.update(str(signal["signal_id"]) for signal in signals)
            if _governance_only(signals):
                self.store.dismiss_learning_signals(
                    [str(signal["signal_id"]) for signal in signals],
                    reason="governance_gate_block_not_a_mistake",
                )
                dismissed.append(
                    {
                        "queue_id": item["queue_id"],
                        "reason": "governance_gate_block_not_a_mistake",
                    }
                )
                continue
            classification = dict(bundle_from_signals(signals))
            primary = classification.pop("primary_signal", None) or signals[0]
            adjudicated = self._provider_adjudication(primary, signals, classification)
            if adjudicated.get("_deferred_adjudication"):
                deferred.append(
                    {
                        "queue_id": item["queue_id"],
                        "reason": str(adjudicated.get("reason") or "provider_depth_guard"),
                    }
                )
                continue
            mistake = self.store.record_mistake_event(
                signal_ids=[str(signal["signal_id"]) for signal in signals],
                category=str(adjudicated["category"]),
                attribution=str(adjudicated["attribution"]),
                mechanism=str(adjudicated["mechanism"]),
                severity=str(adjudicated["severity"]),
                confidence=float(adjudicated["confidence"]),
                detector=str(adjudicated.get("detector") or classification["detector_version"]),
                blast_radius=str(adjudicated["blast_radius"]),
                recurrence_key=str(adjudicated["recurrence_key"]),
                symptom=str(adjudicated.get("symptom") or _symptom(primary)),
                root_cause=str(adjudicated.get("root_cause") or classification["summary"]),
                resolution=str(adjudicated.get("resolution") or _resolution_from_signal(primary)),
                prevent_recurrence=str(
                    adjudicated.get("prevent_recurrence") or _prevention_from_signal(primary)
                ),
                detection_method=str(primary.get("source") or "learning_signal"),
                affected_paths=[str(path) for path in adjudicated.get("affected_paths", []) if str(path)],
                provider_run_id=str(adjudicated.get("provider_run_id") or ""),
            )
            processed.append({"queue_id": item["queue_id"], "mistake_id": mistake["mistake_id"]})
        return {
            "ok": not skipped,
            "processed": processed,
            "skipped": skipped,
            "dismissed": dismissed,
            "deferred": deferred,
        }

    def _expand_bundle(
        self,
        signals: list[Mapping[str, Any]],
        *,
        pending: list[Mapping[str, Any]],
        consumed: set[str],
    ) -> list[Mapping[str, Any]]:
        """Fold sibling signals from the same task session into one bundle.

        A failing test followed by a user correction is one mistake described
        twice. Grouping is bounded by task session, a time window, and a maximum
        size so an unrelated later mistake in a long session stays separate.
        """

        anchor = signals[0]
        task_session_id = str(anchor.get("task_session_id") or "").strip()
        if not task_session_id:
            return signals
        anchor_at = _parse_instant(anchor.get("observed_at"))
        if anchor_at is None:
            return signals
        known = {str(signal["signal_id"]) for signal in signals}
        bundled = list(signals)
        governance = {"gate_block", "governance_gate_block"}
        for item in pending:
            if len(bundled) >= self.BUNDLE_MAX_SIGNALS:
                break
            for signal_id in _signal_ids(item.get("signal_bundle")):
                if signal_id in known or signal_id in consumed:
                    continue
                candidate = self.store.learning_signal(signal_id)
                if candidate is None:
                    continue
                if str(candidate.get("task_session_id") or "").strip() != task_session_id:
                    continue
                # Governance telemetry is dismissed on its own path; never let it
                # dilute a real mistake bundle.
                if str(candidate.get("signal_kind") or "") in governance:
                    continue
                candidate_at = _parse_instant(candidate.get("observed_at"))
                if candidate_at is None:
                    continue
                if abs((candidate_at - anchor_at).total_seconds()) > self.BUNDLE_WINDOW_SECONDS:
                    continue
                bundled.append(candidate)
                known.add(signal_id)
                break
        return bundled

    def _provider_adjudication(
        self,
        primary: Mapping[str, Any],
        signals: list[Mapping[str, Any]],
        classification: Mapping[str, Any],
    ) -> dict[str, Any]:
        fallback = _fallback_event(primary, classification)
        if self.repo_root is None or self.settings is None:
            return fallback
        depth = _provider_depth()
        max_depth = _provider_max_depth(self.settings)
        if depth >= max_depth:
            self.store.write_learning_event(
                phase="provider",
                kind="depth_guard",
                ref="learning.mistake_adjudication",
                payload={"depth": depth, "max_depth": max_depth, "action": "defer"},
            )
            return {"_deferred_adjudication": True, "reason": "provider_depth_guard"}
        prompt = _adjudication_prompt(signals, classification)
        old_allow = os.environ.get("PERSISTMIND_ALLOW_AMBIENT_AGENT_PROVIDER")
        os.environ["PERSISTMIND_ALLOW_AMBIENT_AGENT_PROVIDER"] = "1"
        try:
            try:
                provider = build_agent_provider(
                    self.settings,
                    repo_root=self.repo_root,
                    event_logger=self.store.write_learning_event,
                    agent_hint=_agent_hint(signals),
                )
                raw = provider.complete(
                    prompt=prompt,
                    role="learning.mistake_adjudication",
                    schema=MISTAKE_EVENT_SCHEMA,
                    model_family="reasoning",
                    budget_tokens=1200,
                )
                if _invalid_provider_payload(raw):
                    repair_prompt = _adjudication_prompt(
                        signals,
                        classification,
                        retry_reason="previous_response_failed_schema_validation",
                    )
                    raw = provider.complete(
                        prompt=repair_prompt,
                        role="learning.mistake_adjudication",
                        schema=MISTAKE_EVENT_SCHEMA,
                        model_family="reasoning",
                        budget_tokens=1200,
                    )
            except Exception:
                return fallback
        finally:
            if old_allow is None:
                os.environ.pop("PERSISTMIND_ALLOW_AMBIENT_AGENT_PROVIDER", None)
            else:
                os.environ["PERSISTMIND_ALLOW_AMBIENT_AGENT_PROVIDER"] = old_allow
        if not isinstance(raw, Mapping) or validate_json_schema(dict(raw), MISTAKE_EVENT_SCHEMA):
            return fallback
        adjudicated = {**fallback, **dict(raw)}
        if _has_injection(adjudicated):
            return fallback
        adjudicated["provider_run_id"] = getattr(provider, "provider_id", "agent")
        adjudicated["detector"] = "host-agent-adjudication.v1"
        return adjudicated


def _parse_instant(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None


def _signal_ids(bundle: Any) -> list[str]:
    if not isinstance(bundle, Mapping):
        return []
    value = bundle.get("signal_ids")
    return [str(item) for item in value] if isinstance(value, list) else []


def _agent_hint(signals: list[Mapping[str, Any]]) -> str | None:
    for signal in signals:
        structural = signal.get("structural")
        if not isinstance(structural, Mapping):
            continue
        for key in ("agent", "agent_name", "host_agent"):
            value = str(structural.get(key) or "").strip()
            if value:
                return value
    return None


def _provider_depth() -> int:
    try:
        return max(0, int(os.environ.get("PERSISTMIND_PROVIDER_DEPTH", "0") or "0"))
    except ValueError:
        return 0


def _provider_max_depth(settings: Any) -> int:
    learning = getattr(settings, "learning", None)
    try:
        return max(1, int(getattr(learning, "provider_max_depth", 1)))
    except (TypeError, ValueError):
        return 1


def _governance_only(signals: list[Mapping[str, Any]]) -> bool:
    governance_kinds = {"gate_block", "governance_gate_block"}
    return all(str(signal.get("signal_kind") or "") in governance_kinds for signal in signals)


def _signal_scope(signal: Mapping[str, Any]) -> str:
    structural = signal.get("structural")
    if not isinstance(structural, Mapping):
        return ""
    paths = [
        str(path)
        for key in ("edited_paths", "last_write_paths", "observed_paths")
        for path in (structural.get(key) or [])
        if str(path).strip()
    ]
    if not paths:
        return ""
    unique = sorted(dict.fromkeys(paths))[:3]
    return " on " + ", ".join(unique)


def _symptom(signal: Mapping[str, Any]) -> str:
    """Compose a condition-shaped clause.

    The lesson assertion reads ``When {symptom}, the root cause was ...``, so a
    verbatim prompt ("the calc is wrong, fix it") produces broken English. The
    raw text stays on the signal row; only the lesson prose is normalized.
    """

    kind = str(signal.get("signal_kind") or "").strip()
    evidence = str(signal.get("evidence_ref") or "").strip()
    structural = signal.get("structural") if isinstance(signal.get("structural"), Mapping) else {}
    scope = _signal_scope(signal)
    if kind == "user_correction":
        return f"the user corrected recent agent work{scope}"
    if kind == "tool_failure":
        markers = [str(marker) for marker in (structural.get("failure_markers") or [])]
        detail = f" with {markers[0].replace('_', ' ')}" if markers else ""
        return f"tool `{evidence or 'unknown'}` failed{detail}"
    if kind == "test_run":
        return f"test command `{evidence or 'unknown'}` failed"
    if kind == "edit_churn":
        return f"the same file was rewritten repeatedly{scope or ''}"
    if kind == "self_revert":
        return f"an edit was reverted by a later edit{scope or ''}"
    if kind == "plan_deviation":
        return f"an edit fell outside the active plan step{scope or ''}"
    readable = kind.replace("_", " ").strip() or "a learning signal"
    return f"{readable} was observed{scope}"


def _fallback_event(signal: Mapping[str, Any], classification: Mapping[str, Any]) -> dict[str, Any]:
    symptom = _symptom(signal)
    return {
        "category": str(classification["category"]),
        "attribution": str(classification["attribution"]),
        "mechanism": str(classification["mechanism"]),
        "severity": str(classification["severity"]),
        "confidence": float(classification["confidence"]),
        "blast_radius": str(classification["blast_radius"]),
        "recurrence_key": str(classification["recurrence_key"]),
        "symptom": symptom,
        "root_cause": _root_cause_from_signal(signal, classification),
        "resolution": _resolution_from_signal(signal),
        "prevent_recurrence": _prevention_from_signal(signal),
        "affected_paths": [str(path) for path in classification.get("affected_paths", []) if str(path)],
        "provider_run_id": "deterministic:fallback",
        "detector": str(classification["detector_version"]),
    }


def _root_cause_from_signal(
    signal: Mapping[str, Any], classification: Mapping[str, Any]
) -> str:
    mechanism = str(classification.get("mechanism") or "").replace("_", " ").strip()
    kind = str(signal.get("signal_kind") or "learning signal").replace("_", " ").strip()
    evidence = str(signal.get("evidence_ref") or "").strip()
    suffix = f" near {evidence}" if evidence else ""
    if mechanism and mechanism != "unknown":
        return f"The prior action showed {mechanism} during {kind}{suffix}."
    return f"The prior action did not satisfy the observed {kind}{suffix}."


def _resolution_from_signal(signal: Mapping[str, Any]) -> str:
    kind = str(signal.get("signal_kind") or "").strip()
    evidence = str(signal.get("evidence_ref") or "").strip()
    scope = _signal_scope(signal)
    if kind == "user_correction":
        return f"Apply the correction the user asked for{scope} and re-check the affected output."
    if kind in {"tool_failure", "test_run"}:
        target = f" `{evidence}`" if evidence else ""
        return f"Resolve the failure reported by{target} and re-run it before continuing."
    if kind in {"edit_churn", "self_revert"}:
        return f"Settle the intended change{scope} in one edit before moving on."
    if kind == "plan_deviation":
        return "Amend the active plan step to cover the edit, or revert the out-of-step change."
    return "Correct the observed issue and verify the changed behavior."


def _prevention_from_signal(signal: Mapping[str, Any]) -> str:
    kind = str(signal.get("signal_kind") or "mistake").replace("_", " ").strip()
    scope = _signal_scope(signal)
    evidence = str(signal.get("evidence_ref") or "").strip()
    where = scope or (f" near {evidence}" if evidence else "")
    return f"Before declaring the task complete, re-check for {kind}{where}."


def _adjudication_prompt(
    signals: list[Mapping[str, Any]],
    classification: Mapping[str, Any],
    *,
    retry_reason: str | None = None,
) -> str:
    baseline = _schema_projection(classification, MISTAKE_EVENT_SCHEMA)
    payload: dict[str, Any] = {
        "deterministic_baseline": baseline,
        "signals": [_signal_prompt_view(signal) for signal in signals],
    }
    if retry_reason:
        payload["retry_reason"] = retry_reason
    return (
        "Adjudicate these PersistMind learning signals into one mistake event. "
        "Return only strict JSON matching the supplied schema. Do not include markdown "
        "or any fields that are not present in the schema. "
        "Use specific observed symptom/root_cause/resolution/prevent_recurrence text; "
        "do not use generic templates.\n\n"
        + canonical_json(payload)
    )


def _schema_projection(value: Mapping[str, Any], schema: Mapping[str, Any]) -> dict[str, Any]:
    properties = schema.get("properties")
    if not isinstance(properties, Mapping):
        return dict(value)
    allowed = {str(key) for key in properties}
    return {str(key): item for key, item in value.items() if str(key) in allowed}


def _signal_prompt_view(signal: Mapping[str, Any]) -> dict[str, Any]:
    structural = signal.get("structural") if isinstance(signal.get("structural"), Mapping) else {}
    view: dict[str, Any] = {
        "signal_kind": str(signal.get("signal_kind") or ""),
        "content_excerpt": str(signal.get("content_excerpt") or ""),
    }
    evidence_ref = str(signal.get("evidence_ref") or "").strip()
    if evidence_ref:
        view["evidence_ref"] = evidence_ref
    paths: dict[str, list[str]] = {}
    for key in ("edited_paths", "last_write_paths", "observed_paths"):
        values = [
            str(path)
            for path in (structural.get(key) or [])
            if str(path).strip()
        ]
        if values:
            paths[key] = sorted(dict.fromkeys(values))[:10]
    if paths:
        view["paths"] = paths
    return view


def _invalid_provider_payload(raw: Any) -> bool:
    return not isinstance(raw, Mapping) or bool(validate_json_schema(dict(raw), MISTAKE_EVENT_SCHEMA))


def _has_injection(value: Mapping[str, Any]) -> bool:
    for key in ("symptom", "root_cause", "resolution", "prevent_recurrence"):
        defense = detect_query_injection(str(value.get(key) or ""))
        if not defense.get("ok", True):
            return True
    return False
