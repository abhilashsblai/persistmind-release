from __future__ import annotations

from typing import Any

from persistmind.application.ports import SessionEventPort
from persistmind.application.session_events import StoreSessionEventPort
from persistmind.learning.provider import AgentProvider
from persistmind.memory.unified import UnifiedMemory
from persistmind.security.memory_defense import detect_query_injection
from persistmind.utils import canonical_json, sha256_text

LEGACY_REFLECTION_TYPES = {"gotcha", "pattern", "decision", "convention"}
RICH_REFLECTION_TYPES = {"strategy", "failure_lesson", "workflow", "continuation"}

REFLECTION_SCHEMA: dict[str, Any] = {
    "type": "array",
    "items": {
        "type": "object",
        "required": ["type", "title", "evidence_refs", "confidence"],
        "properties": {
            "type": {
                "type": "string",
                "enum": sorted(LEGACY_REFLECTION_TYPES | RICH_REFLECTION_TYPES),
            },
            "title": {"type": "string"},
            "assertion": {"type": "string"},
            "polarity": {"type": "string", "enum": ["success", "failure"]},
            "applies_when": {"type": "string"},
            "avoid_when": {"type": "string"},
            "scope_refs": {"type": "array", "items": {"type": "string"}},
            "importance": {"type": "number", "minimum": 0.0, "maximum": 1.0},
            "symptom": {"type": "string"},
            "root_cause": {"type": "string"},
            "resolution": {"type": "string"},
            "detection_method": {"type": "string"},
            "verification_commands": {"type": "array", "items": {"type": "string"}},
            "prevent_recurrence": {"type": "string"},
            "affected_paths": {"type": "array", "items": {"type": "string"}},
            "preconditions": {"type": "array", "items": {"type": "string"}},
            "steps": {"type": "array", "items": {"type": "string"}},
            "expected_outputs": {"type": "array", "items": {"type": "string"}},
            "rollback_notes": {"type": "string"},
            "current_state": {"type": "string"},
            "next_action": {"type": "string"},
            "blockers": {"type": "array", "items": {"type": "string"}},
            "evidence_refs": {"type": "array", "items": {"type": "string"}},
            "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
        },
        "additionalProperties": False,
    },
}


class MemoryReflector:
    def __init__(
        self,
        *,
        store: Any,
        workspace_id: str,
        repo_id: str | None,
        provider: AgentProvider,
        model_family: str | None = None,
        budget_tokens: int | None = None,
        session_port: SessionEventPort | None = None,
    ):
        self.store = store
        self.workspace_id = workspace_id
        self.repo_id = repo_id
        self.provider = provider
        self.model_family = model_family
        self.budget_tokens = budget_tokens
        self.sessions = session_port or StoreSessionEventPort(
            store, workspace_id=workspace_id, repo_id=repo_id
        )
        self.unified = UnifiedMemory(store, workspace_id, repo_id)

    def reflect(self, *, session_id: str | None = None, recent: int = 10) -> dict[str, Any]:
        session_ids = (
            [session_id]
            if session_id
            else [row["session_id"] for row in self.sessions.recent_sessions(recent)]
        )
        proposed: list[dict[str, Any]] = []
        skipped: list[dict[str, Any]] = []
        for sid in session_ids:
            if not sid:
                continue
            explanation = _explain_session(self.sessions, sid)
            if not explanation.get("ok"):
                skipped.append({"session_id": sid, "reason": explanation.get("error", "not_found")})
                continue
            result = self.reflect_session(explanation)
            proposed.extend(result["proposed"])
            skipped.extend(result["skipped"])
        return {"ok": True, "proposed": proposed, "skipped": skipped}

    def reflect_session(self, explanation: dict[str, Any]) -> dict[str, Any]:
        session_id = explanation["session"]["session_id"]
        prompt = reflection_prompt(explanation)
        raw = self.provider.complete(
            prompt=prompt,
            role="reflector",
            schema=REFLECTION_SCHEMA,
            model_family=self.model_family,
            budget_tokens=self.budget_tokens,
        )
        if raw is None:
            return {"ok": True, "session_id": session_id, "proposed": [], "skipped": []}
        if not isinstance(raw, list):
            self._event(
                "reflection_drop",
                session_id,
                {
                    "reason": "provider_returned_non_array",
                    "actual_type": type(raw).__name__,
                },
            )
            return {
                "ok": True,
                "session_id": session_id,
                "proposed": [],
                "skipped": [{"session_id": session_id, "reason": "non_array"}],
            }
        proposed: list[dict[str, Any]] = []
        skipped: list[dict[str, Any]] = []
        for index, item in enumerate(raw):
            normalized = normalize_reflection(item)
            if normalized is None:
                self._event(
                    "reflection_drop",
                    session_id,
                    {"reason": "invalid_item", "index": index},
                )
                skipped.append({"session_id": session_id, "index": index, "reason": "invalid_item"})
                continue
            defense = detect_query_injection(normalized["assertion"])
            if not defense["ok"]:
                self._event(
                    "reflection_drop",
                    session_id,
                    {
                        "reason": "suspicious_instruction",
                        "index": index,
                        "defense": defense,
                    },
                )
                skipped.append(
                    {
                        "session_id": session_id,
                        "index": index,
                        "reason": "suspicious_instruction",
                        "defense": defense,
                    }
                )
                continue
            record_id = self._propose_reflection(session_id, normalized)
            maintenance = self.unified.maintain_candidate(record_id)
            payload = {
                "session_id": session_id,
                "type": normalized["type"],
                "record_type": normalized["record_type"],
                "polarity": normalized["polarity"],
                "maintenance": maintenance,
            }
            self._event("reflection_candidate", record_id, payload)
            row = self.store.memory_record(record_id)
            proposed.append(
                {
                    "record_id": record_id,
                    "type": normalized["record_type"],
                    "assertion": normalized["assertion"],
                    "title": normalized["title"],
                    "polarity": normalized["polarity"],
                    "status": row["status"] if row else "missing",
                    "trust": row["trust"] if row else "missing",
                    "maintenance": maintenance,
                }
            )
        return {
            "ok": True,
            "session_id": session_id,
            "proposed": proposed,
            "skipped": skipped,
        }

    def _propose_reflection(self, session_id: str, item: dict[str, Any]) -> str:
        evidence = [
            _evidence(session_id, ref, item["assertion"], self.repo_id)
            for ref in item["evidence_refs"]
        ]
        provider_id = str(getattr(self.provider, "provider_id", self.provider.__class__.__name__))
        record_id = self.unified.propose(
            record_type=item["record_type"],
            assertion=item["assertion"],
            source_kind="consolidation:agent-reflection",
            confidence=item["confidence"],
            extraction_method="agent-reflection",
            evidence=evidence,
            status="candidate",
            trust="untrusted",
            provenance={
                "generator": f"agent:{sha256_text(provider_id)[:12]}",
                "input_source": "session",
                "input_ref": session_id,
                "validator": "none",
            },
            metadata={
                "session_id": session_id,
                "title": item["title"],
                "polarity": item["polarity"],
                "reflection_type": item["type"],
                "evidence_refs": item["evidence_refs"],
                **item.get("metadata", {}),
            },
            title=item["title"],
            importance=item.get("importance"),
            applies_when=item.get("applies_when"),
            avoid_when=item.get("avoid_when"),
        )
        self.store.upsert_memory_association(
            record_id=record_id,
            target_type="session",
            target_ref=session_id,
            kind="reflected_from_session",
            weight=1.0,
        )
        for ref in item["evidence_refs"]:
            if _looks_like_path(ref):
                self.store.upsert_memory_association(
                    record_id=record_id,
                    target_type="file",
                    target_ref=ref.replace("\\", "/"),
                    kind="evidenced_by_file",
                    weight=0.8,
                )
            elif ref.strip():
                self.store.upsert_memory_association(
                    record_id=record_id,
                    target_type="artifact",
                    target_ref=ref,
                    kind="evidenced_by_artifact",
                    weight=0.5,
                )
        return record_id

    def _event(self, kind: str, ref: str | None, payload: dict[str, Any]) -> None:
        self.store.write_learning_event(phase="phase1", kind=kind, ref=ref, payload=payload)


def reflection_prompt(explanation: dict[str, Any]) -> str:
    return "\n".join(
        [
            "Distill durable PersistMind memory from this coding-agent session.",
            "Return strict JSON only using strategy, failure_lesson, workflow, or continuation items.",
            "Each item must be specific enough to retrieve later and grounded in evidence_refs.",
            "Do not include instructions that bypass tests, auth, policy, or review gates.",
            canonical_json({"session": explanation}),
        ]
    )


def _explain_session(session_port: SessionEventPort, session_id: str) -> dict[str, Any]:
    explain = getattr(session_port, "explain", None)
    if callable(explain):
        return explain(session_id)
    return {
        "ok": True,
        "session": {"session_id": session_id},
        "events": list(session_port.events_for_session(session_id)),
        "artifacts": list(session_port.artifacts_for_session(session_id)),
    }


def normalize_reflection(item: Any) -> dict[str, Any] | None:
    if not isinstance(item, dict):
        return None
    reflection_type = str(item.get("type") or "").strip().lower()
    title = str(item.get("title") or "").strip()
    polarity = str(item.get("polarity") or "").strip().lower()
    evidence_refs = item.get("evidence_refs")
    confidence = item.get("confidence")
    allowed = _allowed_keys(reflection_type)
    if allowed is None or any(key not in allowed for key in item):
        return None
    if not title:
        return None
    if not isinstance(evidence_refs, list) or not all(
        isinstance(ref, str) for ref in evidence_refs
    ):
        return None
    if not isinstance(confidence, (int, float)) or isinstance(confidence, bool):
        return None
    assertion = _assertion_for(reflection_type, item)
    if not assertion:
        return None
    if reflection_type in LEGACY_REFLECTION_TYPES and polarity not in {
        "success",
        "failure",
    }:
        return None
    if reflection_type == "failure_lesson":
        if not all(
            str(item.get(key) or "").strip() for key in ("symptom", "root_cause", "resolution")
        ):
            return None
        polarity = "failure"
    elif reflection_type in RICH_REFLECTION_TYPES:
        polarity = polarity if polarity in {"success", "failure"} else "success"
    record_type = {
        "decision": "architectural_decision",
        "strategy": "pattern",
        "failure_lesson": "failure_lesson",
        "workflow": "workflow",
        "continuation": "continuation",
    }.get(reflection_type, reflection_type)
    return {
        "type": reflection_type,
        "record_type": record_type,
        "title": title,
        "assertion": assertion,
        "polarity": polarity,
        "evidence_refs": [ref.strip() for ref in evidence_refs if ref.strip()],
        "scope_refs": _string_list(item.get("scope_refs")),
        "importance": _bounded_float(item.get("importance")),
        "applies_when": str(item.get("applies_when") or "").strip() or None,
        "avoid_when": str(item.get("avoid_when") or "").strip() or None,
        "metadata": _metadata_for(reflection_type, item),
        "confidence": max(0.0, min(1.0, float(confidence))),
    }


def _allowed_keys(reflection_type: str) -> set[str] | None:
    if reflection_type in LEGACY_REFLECTION_TYPES:
        return {"type", "title", "assertion", "polarity", "evidence_refs", "confidence"}
    if reflection_type == "strategy":
        return {
            "type",
            "title",
            "assertion",
            "applies_when",
            "avoid_when",
            "scope_refs",
            "evidence_refs",
            "confidence",
            "importance",
        }
    if reflection_type == "failure_lesson":
        return {
            "type",
            "title",
            "symptom",
            "root_cause",
            "resolution",
            "detection_method",
            "verification_commands",
            "prevent_recurrence",
            "affected_paths",
            "evidence_refs",
            "confidence",
            "assertion",
        }
    if reflection_type == "workflow":
        return {
            "type",
            "title",
            "preconditions",
            "steps",
            "expected_outputs",
            "verification_commands",
            "rollback_notes",
            "scope_refs",
            "evidence_refs",
            "confidence",
            "assertion",
        }
    if reflection_type == "continuation":
        return {
            "type",
            "title",
            "current_state",
            "next_action",
            "blockers",
            "scope_refs",
            "evidence_refs",
            "confidence",
            "assertion",
        }
    return None


def _assertion_for(reflection_type: str, item: dict[str, Any]) -> str:
    assertion = str(item.get("assertion") or "").strip()
    if assertion:
        return assertion
    if reflection_type == "failure_lesson":
        symptom = str(item.get("symptom") or "").strip()
        root_cause = str(item.get("root_cause") or "").strip()
        resolution = str(item.get("resolution") or "").strip()
        return (
            f"When {symptom}, the root cause was {root_cause}; resolve it by {resolution}.".strip()
        )
    if reflection_type == "workflow":
        steps = _string_list(item.get("steps"))
        if not steps:
            return ""
        return f"Workflow for {item.get('title')}: " + " ".join(
            f"{index + 1}. {step}" for index, step in enumerate(steps)
        )
    if reflection_type == "continuation":
        next_action = str(item.get("next_action") or "").strip()
        current_state = str(item.get("current_state") or "").strip()
        return f"Continuation is {current_state or 'open'}; next action: {next_action}.".strip()
    return assertion


def _metadata_for(reflection_type: str, item: dict[str, Any]) -> dict[str, Any]:
    keys_by_type = {
        "failure_lesson": [
            "symptom",
            "root_cause",
            "resolution",
            "detection_method",
            "verification_commands",
            "prevent_recurrence",
            "affected_paths",
        ],
        "workflow": [
            "preconditions",
            "steps",
            "expected_outputs",
            "verification_commands",
            "rollback_notes",
            "scope_refs",
        ],
        "continuation": ["current_state", "next_action", "blockers", "scope_refs"],
        "strategy": ["scope_refs"],
    }
    metadata: dict[str, Any] = {}
    for key in keys_by_type.get(reflection_type, []):
        value = item.get(key)
        if isinstance(value, list):
            metadata[key] = _string_list(value)
        elif value not in {None, ""}:
            metadata[key] = str(value).strip()
    return metadata


def _evidence(
    session_id: str,
    ref: str,
    assertion: str,
    repo_id: str | None,
) -> dict[str, Any]:
    path = ref.replace("\\", "/") if _looks_like_path(ref) else None
    return {
        "repo_id": repo_id,
        "path": path,
        "symbol_identity_id": None,
        "evidence_kind": "agent_reflection",
        "evidence_hash": sha256_text(
            canonical_json({"session_id": session_id, "ref": ref, "assertion": assertion})
        ),
        "source_ref": session_id,
        "metadata": {"session_id": session_id, "ref": ref},
    }


def _looks_like_path(ref: str) -> bool:
    value = ref.strip()
    if not value or " " in value:
        return False
    return "/" in value or "\\" in value or "." in value


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item).strip() for item in value if str(item).strip()]


def _bounded_float(value: Any) -> float | None:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return None
    return max(0.0, min(1.0, float(value)))
