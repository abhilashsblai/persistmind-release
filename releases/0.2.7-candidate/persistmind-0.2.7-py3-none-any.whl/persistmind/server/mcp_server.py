from __future__ import annotations

from functools import wraps
from pathlib import Path
from threading import Lock
from typing import TYPE_CHECKING, Any, Literal

from persistmind import __version__
from persistmind.agents.workflow_binding import build_mcp_bindable_result
from persistmind.application.registry import operation_catalog
from persistmind.composition.registry import OperationClient
from persistmind.interfaces import exception_result, finalize_result, publicize_value
from persistmind.security.context import principal_scope
from persistmind.security.principals import Principal
from persistmind.storage.activity_service import OUTCOME_RESULTS, ActivityService
from persistmind.storage.audit_service import AuditService
from persistmind.storage.control import StorageControlPlane, WorkspaceMigrationRequired
from persistmind.storage.knowledge_service import MEMORY_STATUSES, MEMORY_TYPES, KnowledgeService
from persistmind.storage.learning_service import LearningService
from persistmind.storage.pack_service import PackService
from persistmind.storage.runtime import inspect_storage
from persistmind.storage.source_service import SourceService
from persistmind.telemetry.token_accounting import TOKEN_LEGS, TOKEN_MEASUREMENTS
from persistmind.workflow.classifier import PREFLIGHT_MODES, WORKFLOW_MODES

if TYPE_CHECKING:
    from persistmind.composition.typing import OperationClientTypingMixin
else:
    OperationClientTypingMixin = object
from persistmind.storage.task_service import TASK_STATES, TaskService

OutcomeResult = Literal["pass", "fail", "partial", "cancelled"]
TaskCloseResult = Literal["fail", "partial", "cancelled", "blocked"]
TaskState = Literal["INTAKE", "PACK", "PLAN", "EXECUTE", "PREFLIGHT", "OUTCOME"]
TokenLeg = Literal["served", "agent"]
TokenMeasurement = Literal["measured", "estimated"]
PreflightMode = Literal["read", "write"]
WorkflowMode = Literal["auto", "read", "write"]
MemoryRecordType = Literal[
    "architectural_decision",
    "business_rule_candidate",
    "convention",
    "decision",
    "episode",
    "fact",
    "failure_lesson",
    "gotcha",
    "org_knowledge",
    "org_knowledge_candidate",
    "pattern",
    "policy_reference",
    "preference",
]
MemoryStatus = Literal[
    "active",
    "approved",
    "candidate",
    "expired",
    "needs_review",
    "quarantined",
    "rejected",
    "superseded",
]

MCP_LITERAL_CONTRACTS = {
    ("record_outcome", "result"): OUTCOME_RESULTS,
    ("task_close", "result"): ("fail", "partial", "cancelled", "blocked"),
    ("session_finish", "result"): OUTCOME_RESULTS,
    ("task_transition", "state"): TASK_STATES,
    ("token_usage_record", "leg"): TOKEN_LEGS,
    ("token_usage_record", "measurement"): TOKEN_MEASUREMENTS,
    ("memory_search", "types"): MEMORY_TYPES,
    ("memory_search", "status"): MEMORY_STATUSES,
    ("memory_recall", "types"): MEMORY_TYPES,
    ("memory_propose", "record_type"): MEMORY_TYPES,
    ("codex_preflight", "mode"): PREFLIGHT_MODES,
    ("workflow_brief", "mode"): WORKFLOW_MODES,
    ("workflow_recommend", "mode"): WORKFLOW_MODES,
    ("workflow_start", "mode"): WORKFLOW_MODES,
}

READ_ONLY_MCP_TOOLS = frozenset(
    {
        "mcp_capabilities",
        "codex_enforcement_status",
        "snapshot_current",
        "snapshot_lineage",
        "get_impact_report",
        "incident_list",
        "incident_show",
        "incident_validate",
        "search_code",
        "search_repo",
        "graph_neighbors",
        "graph_path",
        "graph_tests_for_path",
        "graph_contracts_for_path",
        "get_pack_manifest",
        "reconstruct_pack",
        "activity_events",
        "activity_event",
        "source_status", "architecture_infer", "architecture_explain", "architecture_drift",
        "semantic_search",
        "get_audit_record",
        "verify_audit",
        "audit_tip",
        "audit_gating_verify",
        "learning_active_manifest",
        "learning_versions",
        "learning_version_show",
        "storage_report",
        "storage_topology",
        "storage_status",
        "storage_resources_verify",
        "storage_memory_kinds",
        "storage_roles",
        "storage_models_status",
        "storage_keys_status",
        "storage_schema_status",
        "storage_partitions",
        "storage_verify",
        "storage_backup_verify",
        "db_backend_status",
        "task_show",
        "task_learning_report",
        "workflow_brief",
        "plan_validate",
        "plan_show",
        "memory_candidates",
        "memory_verify",
        "memory_stale",
        "memory_search",
        "memory_show",
        "memory_recall",
        "memory_graph_recall",
        "memory_enforcements",
        "memory_utilization",
        "policy_applicable",
        "continuation_search",
        "continuation_show",
        "learning_archive",
        "learning_runs",
        "learning_benchmark_trends",
        "learning_recent",
    }
)
CORE_MCP_TOOLS = frozenset(
    (
        "mcp_capabilities", "codex_enforcement_status", "search_code", "search_repo",
        "get_pack_manifest", "reconstruct_pack", "task_show", "memory_search",
        "memory_recall", "memory_show", "workflow_brief", "plan_show", "plan_validate",
        "get_impact_report", "source_status",
    )
)
MCP_TOOL_ACTIONS = {tool: "mcp.read" for tool in READ_ONLY_MCP_TOOLS}


class _ReadOnlyMCPRegistrar:
    """Register only explicitly reviewed read tools on unauthenticated stdio."""

    def __init__(self, server: Any, *, profile: str = "full") -> None:
        self.server = server
        self.profile = profile
        self.allowed_tools = CORE_MCP_TOOLS if profile == "core" else READ_ONLY_MCP_TOOLS
        self._call_lock = Lock()
        self._cleanup: Any = lambda: None
        self._principal: Principal | None = None

    def set_cleanup(self, cleanup: Any) -> None:
        self._cleanup = cleanup

    def set_principal(self, principal: Principal) -> None:
        self._principal = principal

    def tool(self, *args: Any, **kwargs: Any) -> Any:
        register = self.server.tool(*args, **kwargs)

        def decorate(function: Any) -> Any:
            if function.__name__ not in self.allowed_tools:
                return function

            @wraps(function)
            def isolated(*call_args: Any, **call_kwargs: Any) -> Any:
                # SQLite connections are opened and closed on the same worker
                # thread. Serializing the current stdio profile also provides a
                # deterministic concurrency bound until per-call read pools land.
                with self._call_lock:
                    try:
                        with principal_scope(self._principal):
                            try:
                                value = function(*call_args, **call_kwargs)
                                if isinstance(value, dict):
                                    value = finalize_result(value, operation=function.__name__)
                                return publicize_value(value)
                            except Exception as exc:  # noqa: BLE001 - stdio returns typed outcomes.
                                return exception_result(
                                    exc,
                                    operation=function.__name__,
                                    expose_error=False,
                                )
                    finally:
                        self._cleanup()

            return register(isolated)

        return decorate

    def run(self) -> None:
        self.server.run()


class _LazyService(OperationClientTypingMixin):
    """Delay catalog client construction until an MCP tool needs it."""

    def __init__(self, repo_root: Path) -> None:
        self.repo_root = repo_root
        self._service: OperationClient | None = None
        self._lock = Lock()

    def _get(self) -> OperationClient:
        with self._lock:
            if self._service is None:
                self._service = OperationClient(self.repo_root, read_only=True)
        return self._service

    def close(self) -> None:
        service, self._service = self._service, None
        if service is not None:
            service.close()


def _lazy_operation_method(operation_id: str) -> Any:
    def invoke(self: _LazyService, *args: Any, **kwargs: Any) -> dict[str, Any]:
        return self._get().registry.invoke(
            operation_id,
            {"operation_id": operation_id, "args": list(args), **kwargs},
        )

    invoke.__name__ = operation_id
    return invoke


for _operation_id in operation_catalog():
    if _operation_id.isidentifier() and not hasattr(_LazyService, _operation_id):
        setattr(_LazyService, _operation_id, _lazy_operation_method(_operation_id))

del _operation_id


class _LazyTaskService:
    """Use the Task authority whenever an active catalog is present."""

    def __init__(self, repo_root: Path) -> None:
        self.repo_root = repo_root
        self._service: TaskService | None = None
        self._checked = False
        self._lock = Lock()

    def get(self) -> TaskService | None:
        with self._lock:
            if not self._checked:
                from persistmind.config import load_settings

                settings = load_settings(self.repo_root)
                root = self.repo_root / settings.toolchain.workspace_dir
                if inspect_storage(root).initialized:
                    # A qualified PersistMind next-generation workspace must not fall back to
                    # OperationClient if the APSW runtime is unavailable.
                    self._service = TaskService(self.repo_root, read_only=True)
                self._checked = True
            return self._service

    def close(self) -> None:
        service, self._service = self._service, None
        self._checked = False
        if service is not None:
            service.close()


class _LazyKnowledgeService:
    """Use the Knowledge/Policy port whenever a catalog is active."""

    def __init__(self, repo_root: Path) -> None:
        self.repo_root = repo_root
        self._service: KnowledgeService | None = None
        self._checked = False
        self._lock = Lock()

    def get(self) -> KnowledgeService | None:
        with self._lock:
            if not self._checked:
                from persistmind.config import load_settings

                settings = load_settings(self.repo_root)
                root = self.repo_root / settings.toolchain.workspace_dir
                if inspect_storage(root).initialized:
                    self._service = KnowledgeService(self.repo_root, read_only=True)
                self._checked = True
            return self._service

    def close(self) -> None:
        service, self._service = self._service, None
        self._checked = False
        if service is not None:
            service.close()


class _LazyAuditService:
    """Use the Audit-chain port whenever a catalog is active."""

    def __init__(self, repo_root: Path) -> None:
        self.repo_root = repo_root
        self._service: AuditService | None = None
        self._checked = False
        self._lock = Lock()

    def get(self) -> AuditService | None:
        with self._lock:
            if not self._checked:
                from persistmind.config import load_settings

                settings = load_settings(self.repo_root)
                root = self.repo_root / settings.toolchain.workspace_dir
                if inspect_storage(root).initialized:
                    self._service = AuditService(self.repo_root, read_only=True)
                self._checked = True
            return self._service

    def close(self) -> None:
        service, self._service = self._service, None
        self._checked = False
        if service is not None:
            service.close()


class _LazyLearningService:
    """Use the Learning activation port whenever a catalog is active."""

    def __init__(self, repo_root: Path) -> None:
        self.repo_root = repo_root
        self._service: LearningService | None = None
        self._checked = False
        self._lock = Lock()

    def get(self) -> LearningService | None:
        with self._lock:
            if not self._checked:
                from persistmind.config import load_settings

                settings = load_settings(self.repo_root)
                root = self.repo_root / settings.toolchain.workspace_dir
                if inspect_storage(root).initialized:
                    self._service = LearningService(self.repo_root, read_only=True)
                self._checked = True
            return self._service

    def close(self) -> None:
        service, self._service = self._service, None
        self._checked = False
        if service is not None:
            service.close()


class _LazyRoleService:
    """Lazy role port shared by Activity, Source, and Pack service types."""

    def __init__(self, repo_root: Path, service_type: type[Any]) -> None:
        self.repo_root = repo_root
        self.service_type = service_type
        self._service: Any | None = None
        self._checked = False
        self._lock = Lock()

    def get(self) -> Any | None:
        with self._lock:
            if not self._checked:
                from persistmind.config import load_settings

                settings = load_settings(self.repo_root)
                if inspect_storage(self.repo_root / settings.toolchain.workspace_dir).initialized:
                    self._service = self.service_type(self.repo_root, read_only=True)
                self._checked = True
            return self._service

    def close(self) -> None:
        service, self._service = self._service, None
        self._checked = False
        if service is not None:
            service.close()


def run_mcp(service_or_path: OperationClient | str | Path) -> None:
    try:
        from mcp.server.fastmcp import FastMCP
    except Exception as exc:
        raise RuntimeError(
            "FastMCP is not installed. Install persistmind[mcp] to use MCP mode."
        ) from exc

    repo_root = (
        service_or_path.repo_root
        if isinstance(service_or_path, OperationClient)
        else Path(service_or_path).resolve()
    )
    from persistmind.config import load_settings

    settings = load_settings(repo_root)
    lazy_service = _LazyService(repo_root)
    service = lazy_service
    # FastMCP executes synchronous tools on worker threads. Resolve and cache
    # the Git/worktree identity on the main thread before stdio starts so
    # receipt issuance never needs to spawn Git from a worker thread on
    # Windows.
    from persistmind.repo_identity import canonical_repo_hash

    canonical_repo_hash(repo_root)
    storage = StorageControlPlane(repo_root)
    task_authority = _LazyTaskService(repo_root)
    knowledge_authority = _LazyKnowledgeService(repo_root)
    audit_authority = _LazyAuditService(repo_root)
    learning_authority = _LazyLearningService(repo_root)
    activity_port = _LazyRoleService(repo_root, ActivityService)
    source_port = _LazyRoleService(repo_root, SourceService)
    pack_port = _LazyRoleService(repo_root, PackService)
    mcp = _ReadOnlyMCPRegistrar(FastMCP("PersistMind"), profile=settings.mcp.profile)
    protocol_server = getattr(mcp.server, "_mcp_server", None)
    if protocol_server is not None:
        protocol_server.version = __version__
    scope = str(repo_root.resolve())

    def _unsupported_memory_operation(operation: str) -> dict[str, Any]:
        reason = "This memory operation is not safely wired in the next-generation Knowledge service."
        return {"ok": False, "status": "unsupported_operation", "operation": f"memory_{operation.replace('-', '_')}", "schema_version": "persistmind.unsupported_operation.v1", "reason": reason, "nextgen_v1": True}

    mcp.set_principal(
        Principal(
            subject="stdio-mcp-read-only",
            roles=frozenset({"reader"}),
            repo_scopes=frozenset({scope}),
            workspace_scopes=frozenset({scope}),
            auth_source="stdio-local-read-only",
            credential_id="stdio-mcp",
        )
    )

    def close_call_services() -> None:
        task_authority.close()
        knowledge_authority.close()
        audit_authority.close()
        learning_authority.close()
        activity_port.close()
        source_port.close()
        pack_port.close()
        if isinstance(lazy_service, _LazyService):
            lazy_service.close()

    mcp.set_cleanup(close_call_services)

    def authority_storage_unavailable(operation: str) -> dict[str, Any]:
        return {
            "ok": False,
            "status": "storage_not_initialized",
            "error": f"{operation} requires initialized persistmind-nextgen-v1 storage",
        }

    def authority_mutation_unavailable(operation: str) -> dict[str, Any]:
        return {
            "ok": False,
            "status": "forbidden",
            "error": (
                f"{operation} requires an authenticated, transport-bound principal; "
                "stdio MCP does not provide one"
            ),
        }

    @mcp.tool()
    def mcp_capabilities() -> dict[str, Any]:
        return {
            "ok": True,
            "schema_version": "persistmind.mcp_capabilities.v1",
            "engine_version": __version__,
            "mode": "read-only",
            "profile": settings.mcp.profile,
            "mutation_status": "transport_authority_required",
            "mutation_owner": "local-cli",
            "tools": sorted(mcp.allowed_tools),
        }

    def bindable_mcp_result(
        route: str,
        method: str,
        params: dict[str, Any],
        result: dict[str, Any],
    ) -> dict[str, Any]:
        return build_mcp_bindable_result(
            route,
            finalize_result(result, operation=method),
            repo_root=repo_root,
            method=method,
            params=params,
        )

    @mcp.tool()
    def resolve_snapshot(branch: str | None = None) -> dict[str, Any]:
        _ = branch
        return service.resolve_snapshot()

    @mcp.tool()
    def snapshot_current() -> dict[str, Any]:
        return service.snapshot_current()

    @mcp.tool()
    def snapshot_lineage(snapshot_id: str | None = None, limit: int = 50) -> dict[str, Any]:
        return service.snapshot_lineage(snapshot_id, limit)

    @mcp.tool()
    def get_context_pack(
        task: str | None = None,
        budget: int | None = None,
        seed_paths: list[str] | None = None,
        task_session_id: str | None = None,
        intent_id: str | None = None,
        goal_id: str | None = None,
        bind_snapshot: str | None = None,
        seed_from_diff: bool = False,
    ) -> dict[str, Any]:
        if pack_service := pack_port.get():
            result = pack_service.get_context_pack(
                task,
                budget,
                seed_paths,
                task_session_id=task_session_id,
                intent_id=intent_id,
                goal_id=goal_id,
                seed_from_diff=seed_from_diff,
            )
            if task_session_id:
                return bindable_mcp_result(
                    "pack",
                    "get_context_pack",
                    {
                        "task": task,
                        "budget": budget,
                        "seed_paths": seed_paths,
                        "task_session_id": task_session_id,
                        "intent_id": intent_id,
                        "goal_id": goal_id,
                        "bind_snapshot": bind_snapshot,
                        "seed_from_diff": seed_from_diff,
                    },
                    result,
                )
            return result
        return service.get_context_pack(
            task,
            budget,
            seed_paths,
            intent_id=intent_id,
            goal_id=goal_id,
            bind_snapshot=bind_snapshot,
            seed_from_diff=seed_from_diff,
        )

    @mcp.tool()
    def intent_start(problem: str, llm_propose: bool = False) -> dict[str, Any]:
        return service.intent_start(problem, llm_propose=llm_propose)

    @mcp.tool()
    def intent_show(intent_id: str) -> dict[str, Any]:
        return service.intent_show(intent_id)

    @mcp.tool()
    def intent_refine(
        intent_id: str,
        evidence: list[str] | None = None,
        select_goal: str | None = None,
    ) -> dict[str, Any]:
        return service.intent_refine(intent_id, evidence=evidence, select_goal=select_goal)

    @mcp.tool()
    def goal_evaluate(
        intent_id: str,
        candidate_goal_id: str | None = None,
        mode: str | None = None,
    ) -> dict[str, Any]:
        return service.goal_evaluate(intent_id, candidate_goal_id=candidate_goal_id, mode=mode)

    @mcp.tool()
    def goal_show(goal_id: str) -> dict[str, Any]:
        return service.goal_show(goal_id)

    @mcp.tool()
    def goal_challenge(goal_id: str) -> dict[str, Any]:
        return service.goal_challenge(goal_id)

    @mcp.tool()
    def get_impact_report(
        pack_id: str | None = None,
        paths: list[str] | None = None,
        diff: str | None = None,
        business: bool = False,
    ) -> dict[str, Any]:
        return service.get_impact_report(paths=paths, pack_id=pack_id, diff=diff, business=business)

    @mcp.tool()
    def impact_of(paths: list[str] | None = None, business: bool = False) -> dict[str, Any]:
        return service.get_impact_report(paths=paths or [], business=business)

    @mcp.tool()
    def business_entity_add(
        type: str,
        name: str,
        attrs: dict[str, Any] | None = None,
        origin: str = "manual",
        source_type: str | None = None,
        source_ref: str | None = None,
        confidence: float = 0.9,
    ) -> dict[str, Any]:
        return service.business_entity_add(
            node_type=type,
            name=name,
            attrs=attrs or {},
            origin=origin,
            source_type=source_type,
            source_ref=source_ref,
            confidence=confidence,
        )

    @mcp.tool()
    def business_entity_list(
        status: str | None = None,
        type: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        return service.business_entity_list(status=status, node_type=type, limit=limit)

    @mcp.tool()
    def business_entity_approve(
        node_id: str, approver: str = "human:mcp", notes: str = ""
    ) -> dict[str, Any]:
        return service.business_entity_approve(node_id, approver=approver, notes=notes)

    @mcp.tool()
    def business_entity_reject(
        node_id: str, approver: str = "human:mcp", reason: str = ""
    ) -> dict[str, Any]:
        return service.business_entity_reject(node_id, approver=approver, reason=reason)

    @mcp.tool()
    def business_link(
        src_node_id: str,
        dst_node_id: str,
        kind: str,
        source_ref: str = "manual",
        confidence: float | None = None,
    ) -> dict[str, Any]:
        return service.business_link(
            src_node_id=src_node_id,
            dst_node_id=dst_node_id,
            kind=kind,
            source_ref=source_ref,
            confidence=confidence,
        )

    @mcp.tool()
    def behavior_check(
        paths: list[str] | None = None,
        diff: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        return service.behavior_check(paths=paths, diff=diff, pack_id=pack_id)

    @mcp.tool()
    def check_diff_against_pack(pack_id: str, diff: str | None = None) -> dict[str, Any]:
        if pack_service := pack_port.get():
            from persistmind.git_utils import paths_from_diff

            result = pack_service.verify_paths(
                pack_id,
                paths_from_diff(diff),
                verification_name="check-diff",
                diff=diff,
            )
            return bindable_mcp_result(
                "check_diff",
                "check_diff_against_pack",
                {"pack_id": pack_id, "diff": diff},
                result,
            )
        return service.check_diff_against_pack(pack_id, diff)

    @mcp.tool()
    def search_code(query: str, mode: str = "hybrid") -> dict[str, Any]:
        _ = mode
        if source_service := source_port.get():
            return source_service.search(query)
        return service.search_code(query)

    @mcp.tool()
    def search_repo(term: str, max_hops: int = 2, limit: int = 20) -> dict[str, Any]:
        return service.search_repo(term=term, max_hops=max_hops, limit=limit)

    @mcp.tool()
    def graph_neighbors(path: str, max_hops: int = 1, limit: int = 20) -> dict[str, Any]:
        return service.graph_neighbors(path=path, max_hops=max_hops, limit=limit)

    @mcp.tool()
    def graph_path(source_path: str, target_path: str, max_hops: int = 4) -> dict[str, Any]:
        return service.graph_path(
            source_path=source_path, target_path=target_path, max_hops=max_hops
        )

    @mcp.tool()
    def graph_tests_for_path(path: str) -> dict[str, Any]:
        return service.graph_tests_for_path(path=path)

    @mcp.tool()
    def graph_contracts_for_path(path: str) -> dict[str, Any]:
        return service.graph_contracts_for_path(path=path)

    @mcp.tool()
    def refresh_index() -> dict[str, Any]:
        if source_port.get():
            return authority_mutation_unavailable("source build")
        return service.refresh_index()

    @mcp.tool()
    def record_outcome(
        pack_id: str,
        result: OutcomeResult,
        files_changed: list[str] | None = None,
        session_id: str | None = None,
        summary: str | None = None,
    ) -> dict[str, Any]:
        if activity_port.get():
            return authority_mutation_unavailable("outcome recording")
        if not session_id:
            raise ValueError("record_outcome requires session_id")
        return service.record_outcome(
            session_id,
            result,
            pack_id=pack_id,
            files_changed=files_changed or [],
            summary=summary,
        )

    @mcp.tool()
    def remediation_attempt_record(
        task_session_id: str,
        gate_id: str,
        approach: str,
        outcome: str,
        command_or_tool: str | None = None,
        error: str | None = None,
        waited_seconds: int | None = None,
        backoff_strategy: str | None = None,
        transient_recovery: str | None = None,
    ) -> dict[str, Any]:
        return service.remediation_attempt_record(
            task_session_id,
            gate_id=gate_id,
            approach=approach,
            outcome=outcome,
            command_or_tool=command_or_tool,
            error=error,
            waited_seconds=waited_seconds,
            backoff_strategy=backoff_strategy,
            transient_recovery=transient_recovery,
            actor="mcp",
        )

    @mcp.tool()
    def working_memory_promote(
        note_id: str,
        validator: str = "mcp:working-memory",
    ) -> dict[str, Any]:
        return service.working_memory_promote(note_id, actor="mcp", validator=validator)

    @mcp.tool()
    def working_memory_decline(note_id: str, reason: str) -> dict[str, Any]:
        return service.working_memory_decline(note_id, actor="mcp", reason=reason)

    @mcp.tool()
    def task_close(
        task_session_id: str,
        result: TaskCloseResult,
        reason: str,
        blocking_gate_id: str | None = None,
    ) -> dict[str, Any]:
        return service.task_close(
            task_session_id,
            result=result,
            reason=reason,
            blocking_gate_id=blocking_gate_id,
            actor="mcp",
        )

    @mcp.tool()
    def get_pack_manifest(pack_id: str) -> dict[str, Any]:
        if pack_service := pack_port.get():
            return pack_service.get_pack_manifest(pack_id)
        return service.get_pack_manifest(pack_id)

    @mcp.tool()
    def reconstruct_pack(pack_id: str, task_text: str | None = None) -> dict[str, Any]:
        if pack_service := pack_port.get():
            return pack_service.reconstruct_pack(pack_id, task_text)
        return service.reconstruct_pack(pack_id, task_text)

    @mcp.tool()
    def activity_events(
        event_type: str | None = None, since: str | None = None, limit: int = 100
    ) -> dict[str, Any]:
        if activity_service := activity_port.get():
            return activity_service.events(event_type=event_type, since=since, limit=limit)
        return authority_storage_unavailable("activity events")

    @mcp.tool()
    def activity_event(event_id: str, hydrate: bool = False) -> dict[str, Any]:
        if activity_service := activity_port.get():
            return activity_service.event(event_id, hydrate=hydrate)
        return authority_storage_unavailable("activity event")

    @mcp.tool()
    def token_usage_report(
        task_session_id: str | None = None, limit: int = 1000
    ) -> dict[str, Any]:
        if activity_service := activity_port.get():
            return activity_service.token_usage_report(task_session_id, limit=limit)
        return authority_storage_unavailable("token usage report")

    @mcp.tool()
    def token_usage_record(
        activity: str,
        leg: TokenLeg = "agent",
        input_tokens: int = 0,
        cache_read_tokens: int = 0,
        cache_write_tokens: int = 0,
        output_tokens: int = 0,
        task_session_id: str | None = None,
        measurement: TokenMeasurement = "measured",
        source: str = "reported",
        transcript_path: str | None = None,
    ) -> dict[str, Any]:
        if activity_service := activity_port.get():
            return activity_service.token_usage_record(
                activity=activity,
                leg=leg,
                tokens={
                    "input": input_tokens,
                    "cache_read": cache_read_tokens,
                    "cache_write": cache_write_tokens,
                    "output": output_tokens,
                },
                task_session_id=task_session_id,
                measurement=measurement,
                source=source,
                transcript_path=transcript_path,
            )
        return authority_storage_unavailable("token usage record")

    @mcp.tool()
    def source_status() -> dict[str, Any]:
        if source_service := source_port.get():
            return source_service.status()
        return authority_storage_unavailable("source status")

    @mcp.tool()
    def get_audit_record(pack_id: str) -> dict[str, Any]:
        if audit_service := audit_authority.get():
            return audit_service.get_audit_record(pack_id)
        return service.get_audit_record(pack_id)

    @mcp.tool()
    def verify_audit() -> dict[str, Any]:
        if audit_service := audit_authority.get():
            return audit_service.verify_audit()
        return service.verify_audit()

    @mcp.tool()
    def audit_tip() -> dict[str, Any]:
        if audit_service := audit_authority.get():
            return audit_service.audit_tip()
        return authority_storage_unavailable("audit tip")

    @mcp.tool()
    def audit_gating_verify() -> dict[str, Any]:
        if audit_service := audit_authority.get():
            return audit_service.verify_gating_integrity()
        return authority_storage_unavailable("audit gating verification")

    @mcp.tool()
    def learning_active_manifest() -> dict[str, Any]:
        if learning_service := learning_authority.get():
            return learning_service.active_manifest()
        return authority_storage_unavailable("learning active manifest")

    @mcp.tool()
    def learning_versions(skill_id: str | None = None, limit: int = 100) -> dict[str, Any]:
        if learning_service := learning_authority.get():
            return learning_service.versions(skill_id=skill_id, limit=limit)
        return authority_storage_unavailable("learning versions")

    @mcp.tool()
    def learning_version_show(version_id: str) -> dict[str, Any]:
        if learning_service := learning_authority.get():
            return learning_service.version_show(version_id)
        return authority_storage_unavailable("learning version")

    @mcp.tool()
    def learning_canary_evaluate(
        version_id: str,
        metrics: dict[str, float],
        minimum_pass_rate: float = 0.95,
        maximum_regression: float = 0.02,
    ) -> dict[str, Any]:
        if learning_service := learning_authority.get():
            return learning_service.canary_evaluate(
                version_id,
                metrics=metrics,
                minimum_pass_rate=minimum_pass_rate,
                maximum_regression=maximum_regression,
            )
        return authority_storage_unavailable("learning canary")

    @mcp.tool()
    def learning_propagate(
        version_id: str,
        targets: list[str],
        approver: str,
        signature: str,
    ) -> dict[str, Any]:
        if learning_service := learning_authority.get():
            return learning_service.propagate(
                version_id,
                targets=targets,
                approver=approver,
                signature=signature,
            )
        return authority_storage_unavailable("learning propagation")

    @mcp.tool()
    def eval_replay(limit: int = 50, holdout_ratio: float = 0.3) -> dict[str, Any]:
        return service.eval_replay(limit, holdout_ratio)

    @mcp.tool()
    def eval_tune(limit: int = 50, holdout_ratio: float = 0.3) -> dict[str, Any]:
        return service.eval_tune(limit, holdout_ratio)

    @mcp.tool()
    def eval_run_efficacy(
        cases_path: str,
        agent_command: str,
        baseline: str = "no-pack",
        candidate: str = "ctx-pack",
        limit: int = 10,
        timeout: int = 600,
        keep_worktrees: bool = False,
    ) -> dict[str, Any]:
        return service.eval_run_efficacy(
            cases_path,
            agent_command,
            baseline=baseline,
            candidate=candidate,
            limit=limit,
            timeout=timeout,
            keep_worktrees=keep_worktrees,
        )

    @mcp.tool()
    def eval_scorecard(output: str | None = None) -> dict[str, Any]:
        return service.eval_scorecard(output)

    @mcp.tool()
    def eval_loop_verify(
        task: str = "change greeting service",
        paths: list[str] | None = None,
        result: str = "pass",
    ) -> dict[str, Any]:
        return service.eval_loop_verify(task=task, paths=paths, result=result)

    @mcp.tool()
    def gc(
        deep: bool = False,
        dry_run: bool = False,
        prune_snapshots: bool = False,
        archive_pruned_snapshots: bool | None = None,
    ) -> dict[str, Any]:
        return service.gc(
            deep=deep,
            dry_run=dry_run,
            prune_snapshots=prune_snapshots,
            archive_pruned_snapshots=archive_pruned_snapshots,
        )

    @mcp.tool()
    def db_stats() -> dict[str, Any]:
        return service.db_stats()

    @mcp.tool()
    def storage_report(limit: int = 50) -> dict[str, Any]:
        report = storage.storage_status()
        report["limit"] = max(1, min(limit, 1000))
        return report

    @mcp.tool()
    def storage_topology() -> dict[str, Any]:
        return storage.storage_topology()

    @mcp.tool()
    def storage_status() -> dict[str, Any]:
        return storage.storage_status()

    @mcp.tool()
    def storage_bootstrap() -> dict[str, Any]:
        try:
            return storage.storage_bootstrap()
        except WorkspaceMigrationRequired as exc:
            return {"ok": False, "status": exc.status, "error": str(exc)}

    @mcp.tool()
    def storage_resources_verify() -> dict[str, Any]:
        return storage.storage_resources_verify()

    @mcp.tool()
    def storage_memory_kinds() -> dict[str, Any]:
        return storage.storage_memory_kinds()

    @mcp.tool()
    def storage_roles() -> dict[str, Any]:
        return storage.storage_roles()

    @mcp.tool()
    def storage_models_status() -> dict[str, Any]:
        return storage.storage_models_status()

    @mcp.tool()
    def storage_keys_status() -> dict[str, Any]:
        return storage.storage_keys_status()

    @mcp.tool()
    def storage_schema_status() -> dict[str, Any]:
        return storage.storage_schema_status()

    @mcp.tool()
    def storage_partitions() -> dict[str, Any]:
        return storage.storage_partitions()

    @mcp.tool()
    def storage_repair(dry_run: bool = True) -> dict[str, Any]:
        if not dry_run:
            return authority_mutation_unavailable("storage repair")
        return storage.storage_repair(dry_run=True)

    @mcp.tool()
    def storage_gc(dry_run: bool = True) -> dict[str, Any]:
        if not dry_run:
            return authority_mutation_unavailable("storage gc")
        return storage.storage_gc(dry_run=True)

    @mcp.tool()
    def storage_retention(keep_days: int = 30, dry_run: bool = True) -> dict[str, Any]:
        if not dry_run:
            return authority_mutation_unavailable("storage retention")
        return storage.storage_retention(dry_run=True, keep_days=keep_days)

    @mcp.tool()
    def storage_delete(scope: str, dry_run: bool = True) -> dict[str, Any]:
        if not dry_run:
            return authority_mutation_unavailable("storage delete")
        return storage.storage_delete(scope, dry_run=True)

    @mcp.tool()
    def storage_verify(full: bool = False) -> dict[str, Any]:
        return storage.storage_verify(full=full)

    @mcp.tool()
    def storage_reconcile(limit: int = 100) -> dict[str, Any]:
        _ = limit
        return authority_mutation_unavailable("storage reconcile")

    @mcp.tool()
    def storage_backup_create(verify: bool = False) -> dict[str, Any]:
        return storage.storage_backup_create(verify=verify)

    @mcp.tool()
    def storage_backup_verify(backup_id: str) -> dict[str, Any]:
        return storage.storage_backup_verify(backup_id)

    @mcp.tool()
    def storage_backup_restore_stage(
        backup_id: str, target: str, confirm: bool = False
    ) -> dict[str, Any]:
        if not confirm:
            return {
                "ok": False,
                "status": "confirmation_required",
                "error": "backup restore requires confirm=true",
            }
        return storage.storage_backup_restore_stage(backup_id, target=Path(target))

    @mcp.tool()
    def storage_catalog_recover() -> dict[str, Any]:
        return storage.storage_catalog_recover()

    @mcp.tool()
    def db_backend_status() -> dict[str, Any]:
        return service.db_backend_status()

    @mcp.tool()
    def db_bench(
        history: bool = False,
        limit: int = 20,
        corpus: list[int] | None = None,
    ) -> dict[str, Any]:
        return service.db_bench(history=history, limit=limit, corpus=corpus)

    @mcp.tool()
    def retention_show() -> dict[str, Any]:
        return service.retention_show()

    @mcp.tool()
    def retention_set(
        target: str | None = None,
        preset: str | None = None,
        keep_full_days: int | None = None,
        keep_summary_days: int | None = None,
        max_rows: int | None = None,
        scope: str = "global",
    ) -> dict[str, Any]:
        return service.retention_set(
            target=target,
            preset=preset,
            keep_full_days=keep_full_days,
            keep_summary_days=keep_summary_days,
            max_rows=max_rows,
            scope=scope,
        )

    @mcp.tool()
    def maintenance_run(full: bool = True, trigger: str = "mcp") -> dict[str, Any]:
        return service.maintenance_run(full=full, trigger=trigger)

    @mcp.tool()
    def maintenance_history(limit: int = 50) -> dict[str, Any]:
        return service.maintenance_history(limit=limit)

    @mcp.tool()
    def maintenance_tick(full: bool = True) -> dict[str, Any]:
        return service.maintenance_tick(full=full)

    @mcp.tool()
    def doctor() -> dict[str, Any]:
        return service.doctor()

    @mcp.tool()
    def release_check(version: str = "1.0.0") -> dict[str, Any]:
        return service.release_check(version)

    @mcp.tool()
    def release_validate(version: str = "1.0.0") -> dict[str, Any]:
        return service.release_check(version)

    @mcp.tool()
    def ci_check(
        base: str = "origin/main", head: str = "HEAD", pack_id: str | None = None
    ) -> dict[str, Any]:
        return service.ci_check(base, head, pack_id)

    @mcp.tool()
    def constitution_build(
        actor: str,
        signature: str,
        nonce: str,
        issued_at: str,
        expires_at: str,
    ) -> dict[str, Any]:
        return service.constitution_build(
            actor=actor,
            signature=signature,
            nonce=nonce,
            issued_at=issued_at,
            expires_at=expires_at,
        )

    @mcp.tool()
    def constitution_show() -> dict[str, Any]:
        return service.constitution_show()

    @mcp.tool()
    def constitution_check(
        paths: list[str] | None = None,
        task_session_id: str | None = None,
        for_ci: bool = False,
    ) -> dict[str, Any]:
        return service.constitution_check(
            paths or [],
            task_session_id=task_session_id,
            for_ci=for_ci,
        )

    @mcp.tool()
    def task_start(task: str) -> dict[str, Any]:
        if task_service := task_authority.get():
            return bindable_mcp_result(
                "task.start",
                "task_start",
                {"task": task},
                task_service.task_start(task),
            )
        return service.task_start(task)

    @mcp.tool()
    def task_transition(
        task_session_id: str,
        state: TaskState,
        actor: str = "mcp-agent",
        reason: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        if task_service := task_authority.get():
            return bindable_mcp_result(
                "task.transition",
                "task_transition",
                {
                    "task_session_id": task_session_id,
                    "state": state,
                    "actor": actor,
                    "reason": reason,
                    "pack_id": pack_id,
                },
                task_service.task_transition(
                    task_session_id,
                    state,
                    actor=actor,
                    reason=reason,
                    pack_id=pack_id,
                ),
            )
        return service.task_transition(
            task_session_id,
            state,
            actor=actor,
            reason=reason,
            pack_id=pack_id,
        )

    @mcp.tool()
    def task_show(task_session_id: str) -> dict[str, Any]:
        return service.task_show(task_session_id)

    @mcp.tool()
    def task_learning_report(task_session_id: str) -> dict[str, Any]:
        if task_service := task_authority.get():
            return task_service.task_learning_report(task_session_id)
        return service.task_learning_report(task_session_id)

    @mcp.tool()
    def codex_preflight(
        task: str,
        paths: list[str] | None = None,
        mode: PreflightMode = "write",
        probe: bool = False,
        fast: bool = False,
        task_session_id: str | None = None,
    ) -> dict[str, Any]:
        if task_service := task_authority.get():
            return task_service.codex_preflight(
                task,
                paths=paths,
                mode=mode,
                probe=probe or fast,
                task_session_id=task_session_id,
            )
        return service.codex_preflight(
            task,
            paths=paths,
            mode=mode,
            probe=probe or fast,
            task_session_id=task_session_id,
        )

    @mcp.tool()
    def codex_enforcement_status() -> dict[str, Any]:
        return service.codex_enforcement_status()

    @mcp.tool()
    def workflow_brief(
        task: str = "",
        paths: list[str] | None = None,
        mode: WorkflowMode = "auto",
        task_session_id: str | None = None,
    ) -> dict[str, Any]:
        return service.workflow_brief(task, paths=paths, mode=mode, task_session_id=task_session_id)

    @mcp.tool()
    def codex_parallel_plan(
        task_session_id: str,
        pack_id: str,
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        return service.codex_parallel_plan(task_session_id, pack_id, paths=paths)

    @mcp.tool()
    def codex_child_start(
        parent_task_session_id: str,
        role: str,
        objective: str,
        write_scope: list[str] | None = None,
    ) -> dict[str, Any]:
        return service.codex_child_start(
            parent_task_session_id,
            role,
            objective,
            write_scope=write_scope,
        )

    @mcp.tool()
    def codex_child_stop(
        child_agent_session_id: str,
        summary: str,
        changed_files: list[str] | None = None,
        tests_run: list[str] | None = None,
        blockers: list[str] | None = None,
    ) -> dict[str, Any]:
        return service.codex_child_stop(
            child_agent_session_id,
            summary,
            changed_files=changed_files,
            tests_run=tests_run,
            blockers=blockers,
        )

    @mcp.tool()
    def codex_child_pack(
        parent_pack_id: str, role: str, scope: list[str] | None = None
    ) -> dict[str, Any]:
        return service.codex_child_pack(parent_pack_id, role, scope=scope)

    @mcp.tool()
    def codex_merge_parallel_results(parallel_run_id: str) -> dict[str, Any]:
        return service.codex_merge_parallel_results(parallel_run_id)

    @mcp.tool()
    def plan_validate(
        plan: dict[str, Any],
        task_session_id: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        if task_service := task_authority.get():
            return task_service.plan_validate(
                plan, task_session_id=task_session_id, pack_id=pack_id
            )
        return service.plan_validate(plan, task_session_id=task_session_id, pack_id=pack_id)

    @mcp.tool()
    def plan_create(
        task_session_id: str,
        plan: dict[str, Any],
        pack_id: str | None = None,
        author: str = "mcp-agent",
    ) -> dict[str, Any]:
        if task_service := task_authority.get():
            return bindable_mcp_result(
                "plan.create",
                "plan_create",
                {
                    "task_session_id": task_session_id,
                    "plan": plan,
                    "pack_id": pack_id,
                    "author": author,
                },
                task_service.plan_create(task_session_id, plan, pack_id=pack_id, author=author),
            )
        return service.plan_create(
            task_session_id,
            plan,
            pack_id=pack_id,
            author=author,
        )

    @mcp.tool()
    def plan_amend(
        plan_id: str,
        plan: dict[str, Any],
        author: str = "mcp-agent",
        reason: str | None = None,
    ) -> dict[str, Any]:
        if task_service := task_authority.get():
            return bindable_mcp_result(
                "plan.amend",
                "plan_amend",
                {
                    "plan_id": plan_id,
                    "plan": plan,
                    "author": author,
                    "reason": reason,
                },
                task_service.plan_amend(plan_id, plan, author=author, reason=reason),
            )
        return service.plan_amend(plan_id, plan, author=author, reason=reason)

    @mcp.tool()
    def plan_show(plan_id: str) -> dict[str, Any]:
        return service.plan_show(plan_id)

    @mcp.tool()
    def plan_checkpoint(
        plan_id: str,
        step_id: str,
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        if task_service := task_authority.get():
            return bindable_mcp_result(
                "plan.checkpoint",
                "plan_checkpoint",
                {"plan_id": plan_id, "step_id": step_id, "paths": paths},
                task_service.plan_checkpoint(plan_id, step_id, paths=paths),
            )
        return service.plan_checkpoint(plan_id, step_id, paths=paths)

    @mcp.tool()
    def verify_run(
        commands: list[str],
        pack_id: str | None = None,
        retry_budget: int = 0,
        timeout: int = 120,
    ) -> dict[str, Any]:
        return service.verify_run(
            commands,
            pack_id=pack_id,
            retry_budget=retry_budget,
            timeout=timeout,
        )

    @mcp.tool()
    def workspace_index() -> dict[str, Any]:
        return service.workspace_index()

    @mcp.tool()
    def workspace_impact(repo_id: str) -> dict[str, Any]:
        return service.workspace_impact(repo_id)

    @mcp.tool()
    def workspace_status() -> dict[str, Any]:
        return service.workspace_status()

    @mcp.tool()
    def workspace_rule_promotions() -> dict[str, Any]:
        return service.workspace_rule_promotions()

    @mcp.tool()
    def security_scan() -> dict[str, Any]:
        return service.security_scan()

    @mcp.tool()
    def security_status() -> dict[str, Any]:
        return service.security_status()

    @mcp.tool()
    def security_ingest_redteam(
        fixtures: str | None = None,
        output: str | None = None,
        strict: bool = False,
    ) -> dict[str, Any]:
        return service.security_ingest_redteam(fixtures, output=output, strict=strict)

    @mcp.tool()
    def memory_candidates() -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_candidates()
        return service.memory_candidates()

    @mcp.tool()
    def memory_extraction_eval(
        fixtures: str | None = None, source_type: str | None = None
    ) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_extraction_eval(fixtures=fixtures, source_type=source_type)
        return service.memory_extraction_eval(fixtures=fixtures, source_type=source_type)

    @mcp.tool()
    def memory_trust_calibrate(apply: bool = False) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_trust_calibrate(apply=apply)
        return service.memory_trust_calibrate(apply=apply)

    @mcp.tool()
    def memory_approve(rule_id: str, approved_by: str = "local-user") -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_approve(rule_id, approved_by)
        return service.memory_approve(rule_id, approved_by)

    @mcp.tool()
    def memory_verify() -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_verify()
        return service.memory_verify()

    @mcp.tool()
    def memory_stale() -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_stale()
        return service.memory_stale()

    @mcp.tool()
    def memory_search(
        query: str,
        types: list[MemoryRecordType] | None = None,
        status: MemoryStatus | None = None,
    ) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_search(query, types, status)
        return service.memory_search(query, types, status)

    @mcp.tool()
    def memory_show(record_id: str) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_show(record_id)
        return service.memory_show(record_id)

    @mcp.tool()
    def memory_recall(
        query: str,
        paths: list[str] | None = None,
        types: list[MemoryRecordType] | None = None,
        limit: int = 20,
        include_org: bool = False,
    ) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_recall(
                query, paths, types, limit, include_org=include_org
            )
        return service.memory_recall(query, paths, types, limit, include_org=include_org)

    @mcp.tool()
    def memory_graph_recall(record_id: str, max_hops: int = 2) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_graph(record_id, limit=max(1, max_hops) * 50)
        return service.memory_graph(record_id, max_hops=max_hops)

    @mcp.tool()
    def memory_prefetch(
        task: str,
        session_id: str | None = None,
        current_paths: list[str] | None = None,
        top_k: int = 5,
    ) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_recall(task, paths=current_paths, limit=top_k)
        return service.nextgen_prefetch_memory(
            session_id, task, current_paths=current_paths, top_k=top_k
        )

    @mcp.tool()
    def memory_consolidate(record_ids: list[str] | None = None, session_id: str | None = None, recent: int = 10) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            if not record_ids:
                return {"ok": False, "status": "explicit_record_ids_required", "error": "memory_consolidate requires record_ids; use memory_sleep to discover candidates"}
            return knowledge_service.memory_consolidate(record_ids, recent)
        return service.memory_consolidate(session_id, recent)

    @mcp.tool()
    def memory_reflect(session_id: str | None = None, recent: int = 10) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_reflect(session_id, recent)
        return service.memory_reflect(session_id, recent)

    @mcp.tool()
    def memory_maintain(session_id: str | None = None, recent: int = 10) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_maintain(apply=True, limit=recent)
        return service.memory_maintain(session_id, recent)

    @mcp.tool()
    def memory_sweep(limit: int = 500, apply: bool = False) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_sweep(apply=apply, limit=limit)
        return service.memory_sweep(limit=limit, apply=apply)

    @mcp.tool()
    def memory_sleep(apply: bool = False, limit: int = 2000) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_sleep(apply=apply, limit=limit)
        return service.memory_sleep(apply=apply, limit=limit)

    @mcp.tool()
    def memory_dream(session_id: str | None = None) -> dict[str, Any]:
        if knowledge_authority.get():
            return _unsupported_memory_operation("dream")
        return service.memory_dream(session_id=session_id)

    @mcp.tool()
    def memory_enforce(
        record_id: str,
        level: str = "warn",
        severity: str = "medium",
        scope: list[str] | None = None,
        anti_patterns: list[str] | None = None,
        required_patterns: list[str] | None = None,
        remediation: str | None = None,
        rationale: str | None = None,
        approve: bool = False,
        approved_by: str = "mcp",
    ) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_enforce(
                record_id,
                level=level,
                severity=severity,
                scope=scope or [],
                anti_patterns=anti_patterns or [],
                required_patterns=required_patterns or [],
                remediation=remediation,
                rationale=rationale,
                approve=approve,
                approved_by=approved_by,
            )
        return service.memory_enforce(
            record_id,
            level=level,
            severity=severity,
            scope=scope or [],
            anti_patterns=anti_patterns or [],
            required_patterns=required_patterns or [],
            remediation=remediation,
            rationale=rationale,
            approve=approve,
            approved_by=approved_by,
        )

    @mcp.tool()
    def memory_enforcements(
        status: str | None = None, paths: list[str] | None = None
    ) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_enforcements(status=status, paths=paths or None)
        return service.memory_enforcements(status=status, paths=paths or None)

    @mcp.tool()
    def memory_unenforce(
        directive_id: str, reason: str = "manual suspend", actor: str = "mcp"
    ) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_unenforce(directive_id, reason=reason, actor=actor)
        return service.memory_unenforce(directive_id, reason=reason, actor=actor)

    @mcp.tool()
    def guardrail_override(
        directive_id: str,
        rationale: str,
        signature: str,
        nonce: str,
        issued_at: str,
        expires_at: str,
        task_session_id: str | None = None,
        session_id: str | None = None,
        target_paths: list[str] | None = None,
        actor: str = "mcp",
    ) -> dict[str, Any]:
        return service.guardrail_override(
            directive_id,
            rationale=rationale,
            task_session_id=task_session_id,
            session_id=session_id,
            target_paths=target_paths or [],
            actor=actor,
            signature=signature,
            nonce=nonce,
            issued_at=issued_at,
            expires_at=expires_at,
        )

    @mcp.tool()
    def memory_utilization(pack_id: str) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            result = knowledge_service.memory_metrics()
            result["pack_id"] = pack_id
            return result
        return service.memory_utilization(pack_id)

    @mcp.tool()
    def memory_propose(
        record_type: MemoryRecordType,
        assertion: str,
        evidence_refs: list[dict[str, Any]] | None = None,
        source_kind: str = "manual",
        confidence: float = 1.0,
    ) -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.memory_propose(
                record_type, assertion, evidence_refs, source_kind, confidence
            )
        return service.memory_propose(
            record_type, assertion, evidence_refs, source_kind, confidence
        )

    @mcp.tool()
    def policy_applicable(scope: str = "global") -> dict[str, Any]:
        if knowledge_service := knowledge_authority.get():
            return knowledge_service.policy_applicable(scope)
        return authority_storage_unavailable("policy_applicable")

    @mcp.tool()
    def continuation_search(status: str | None = None, limit: int = 20) -> dict[str, Any]:
        if task_service := task_authority.get():
            return task_service.continuation_list(status=status, limit=limit)
        return service.continuation_list(status=status, limit=limit)

    @mcp.tool()
    def continuation_show(continuation_id: str) -> dict[str, Any]:
        if task_service := task_authority.get():
            return task_service.continuation_show(continuation_id)
        return service.continuation_show(continuation_id)

    @mcp.tool()
    def continuation_resume(task: str, limit: int = 3) -> dict[str, Any]:
        if task_service := task_authority.get():
            return task_service.continuation_resume(task, limit=limit)
        return service.continuation_resume(task, limit=limit)

    @mcp.tool()
    def skill_search(
        query: str,
        limit: int = 5,
        include_untrusted: bool = False,
    ) -> dict[str, Any]:
        return service.skill_search(query, limit=limit, include_untrusted=include_untrusted)

    @mcp.tool()
    def skill_induce(session_id: str) -> dict[str, Any]:
        return service.skill_induce(session_id)

    @mcp.tool()
    def skill_show(skill_id: str) -> dict[str, Any]:
        return service.skill_show(skill_id)

    @mcp.tool()
    def skill_replay(skill_id: str, timeout: int = 120) -> dict[str, Any]:
        return service.skill_replay(skill_id, timeout=timeout)

    @mcp.tool()
    def skill_artifact_register(
        skill_id: str | None = None,
        summary: str = "",
        content: str | None = None,
        output_id: str | None = None,
    ) -> dict[str, Any]:
        return service.skill_artifact_register(
            skill_id=skill_id,
            summary=summary,
            content=content,
            output_id=output_id,
        )

    @mcp.tool()
    def skill_revision_capture(
        text: str,
        output_id: str | None = None,
        skill_id: str | None = None,
    ) -> dict[str, Any]:
        return service.skill_revision_capture(
            revision_text=text, output_id=output_id, skill_id=skill_id
        )

    @mcp.tool()
    def skill_metrics(skill_id: str | None = None) -> dict[str, Any]:
        return service.skill_metrics(skill_id)

    @mcp.tool()
    def skill_revision_classify(
        revision_id: str | None = None,
        skill_id: str | None = None,
    ) -> dict[str, Any]:
        return service.skill_revision_classify(revision_id, skill_id=skill_id)

    @mcp.tool()
    def skill_improvements(
        skill_id: str | None = None,
        status: str | None = None,
    ) -> dict[str, Any]:
        return service.skill_improvements(skill_id=skill_id, status=status)

    @mcp.tool()
    def skill_refinement_approve(sir_id: str, approved_by: str = "mcp") -> dict[str, Any]:
        return service.skill_refinement_approve(sir_id, approved_by=approved_by)

    @mcp.tool()
    def skill_refinement_benchmark(sir_id: str) -> dict[str, Any]:
        return service.skill_refinement_benchmark(sir_id)

    @mcp.tool()
    def skill_closure_verify(skill_id: str | None = None) -> dict[str, Any]:
        return service.skill_closure_verify(skill_id)

    @mcp.tool()
    def skill_global_promote(skill_id: str, approved_by: str = "mcp") -> dict[str, Any]:
        return service.skill_global_promote(skill_id, approver=approved_by)

    @mcp.tool()
    def skill_global_adopt(global_skill_id: str, approved_by: str = "mcp") -> dict[str, Any]:
        return service.skill_global_adopt(global_skill_id, approver=approved_by)

    @mcp.tool()
    def learning_optimize(
        target: str = "pack_weights",
        iterations: int = 1,
        limit: int = 20,
        holdout_ratio: float = 0.3,
        adopt: bool = False,
    ) -> dict[str, Any]:
        return service.learning_optimize(
            target,
            iterations=iterations,
            limit=limit,
            holdout_ratio=holdout_ratio,
            adopt=adopt,
        )

    @mcp.tool()
    def learning_status() -> dict[str, Any]:
        return service.learning_status()

    @mcp.tool()
    def learning_recurrence(
        min_occurrences: int = 3,
        min_exposures: int = 2,
    ) -> dict[str, Any]:
        return service.learning_recurrence(
            min_occurrences=min_occurrences,
            min_exposures=min_exposures,
        )

    @mcp.tool()
    def learning_adjudicate(drain: bool = True, limit: int = 20) -> dict[str, Any]:
        return service.learning_adjudicate(drain=drain, limit=limit)

    @mcp.tool()
    def learning_loop_verify(
        task: str | None = None,
        probe: str | None = None,
        require_closure: bool = False,
    ) -> dict[str, Any]:
        return service.learning_loop_verify(
            task,
            probe=probe,
            require_closure=require_closure,
        )

    @mcp.tool()
    def learning_archive(target: str | None = None, limit: int = 20) -> dict[str, Any]:
        return service.learning_archive(target=target, limit=limit)

    @mcp.tool()
    def learning_runs(target: str | None = None, limit: int = 20) -> dict[str, Any]:
        return service.learning_archive(target=target, limit=limit)

    @mcp.tool()
    def learning_benchmark_trends(limit: int = 20) -> dict[str, Any]:
        return service.learning_benchmark_trends(limit=limit)

    @mcp.tool()
    def learning_recent(limit: int = 20) -> dict[str, Any]:
        return service.learning_recent(limit=limit)

    @mcp.tool()
    def learning_adopt(run_id: str) -> dict[str, Any]:
        return service.learning_adopt(run_id)

    @mcp.tool()
    def learning_revert(run_id: str) -> dict[str, Any]:
        return service.learning_revert(run_id)

    @mcp.tool()
    def learning_selfmod_propose(
        target: str,
        weakness: str = "",
        ancestor_run_id: str | None = None,
    ) -> dict[str, Any]:
        return service.learning_selfmod_propose(
            target,
            weakness=weakness,
            ancestor_run_id=ancestor_run_id,
        )

    @mcp.tool()
    def learning_selfmod_archive(target: str | None = None, limit: int = 20) -> dict[str, Any]:
        return service.learning_selfmod_archive(target=target, limit=limit)

    @mcp.tool()
    def selfmod_show(target: str | None = None, limit: int = 20) -> dict[str, Any]:
        return service.learning_selfmod_archive(target=target, limit=limit)

    @mcp.tool()
    def learning_selfmod_adopt(
        run_id: str,
        approved_by: str = "local-user",
    ) -> dict[str, Any]:
        return service.learning_selfmod_adopt(run_id, approved_by=approved_by)

    @mcp.tool()
    def learning_selfmod_revert(run_id: str) -> dict[str, Any]:
        return service.learning_selfmod_revert(run_id)

    @mcp.tool()
    def cie_status() -> dict[str, Any]:
        return service.cie_status()

    @mcp.tool()
    def self_improve_status() -> dict[str, Any]:
        return service.self_improve_status()

    @mcp.tool()
    def cie_cycle(
        limit: int = 20,
        target: str = "cie",
        task: str = "",
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        return service.cie_cycle(limit=limit, target=target, task=task, paths=paths or [])

    @mcp.tool()
    def cie_archive(target: str | None = None, limit: int = 20) -> dict[str, Any]:
        return service.cie_archive(target=target, limit=limit)

    @mcp.tool()
    def cie_show(run_id: str) -> dict[str, Any]:
        return service.cie_show(run_id)

    @mcp.tool()
    def cie_predict(task: str = "", paths: list[str] | None = None) -> dict[str, Any]:
        return service.cie_predict(task=task, paths=paths or [])

    @mcp.tool()
    def cie_checklist_preview(task: str = "", paths: list[str] | None = None) -> dict[str, Any]:
        return service.cie_checklist_preview(task=task, paths=paths or [])

    @mcp.tool()
    def cie_score(period: str = "current") -> dict[str, Any]:
        return service.cie_score(period=period)

    @mcp.tool()
    def cie_timeline(run_id: str | None = None) -> dict[str, Any]:
        return service.cie_timeline(run_id=run_id)

    @mcp.tool()
    def cie_preview_adoption(run_id: str, intervention_id: str) -> dict[str, Any]:
        return service.cie_preview_adoption(run_id, intervention_id)

    @mcp.tool()
    def cie_adopt(run_id: str, intervention_id: str, approved_by: str) -> dict[str, Any]:
        return service.cie_adopt(run_id, intervention_id, approved_by)

    @mcp.tool()
    def cie_reject(
        run_id: str, intervention_id: str, reason: str, actor: str = "mcp"
    ) -> dict[str, Any]:
        return service.cie_reject(run_id, intervention_id, reason, actor)

    @mcp.tool()
    def cie_suspend(
        run_id: str, intervention_id: str, reason: str, actor: str = "mcp"
    ) -> dict[str, Any]:
        return service.cie_suspend(run_id, intervention_id, reason, actor)

    @mcp.tool()
    def session_start(task: str, agent_name: str = "codex") -> dict[str, Any]:
        return service.session_start(task, agent_name)

    @mcp.tool()
    def session_event(session_id: str, event_type: str, payload: dict[str, Any]) -> dict[str, Any]:
        return service.session_event(session_id, event_type, payload)

    @mcp.tool()
    def session_finish(session_id: str, result: OutcomeResult = "pass") -> dict[str, Any]:
        return service.session_finish(session_id, result)

    @mcp.tool()
    def session_explain(session_id: str) -> dict[str, Any]:
        return service.session_explain(session_id)

    @mcp.tool()
    def session_leases(status: str | None = "active") -> dict[str, Any]:
        return service.session_leases(status=status)

    @mcp.tool()
    def session_declare_impact(session_id: str, paths: list[str]) -> dict[str, Any]:
        return service.session_declare_impact(session_id, paths)

    @mcp.tool()
    def session_conflicts(status: str | None = "open") -> dict[str, Any]:
        return service.session_conflicts(status=status)

    @mcp.tool()
    def session_conflict_ack(conflict_id: str) -> dict[str, Any]:
        return service.session_conflict_update(conflict_id, "acknowledged")

    @mcp.tool()
    def session_conflict_resolve(conflict_id: str) -> dict[str, Any]:
        return service.session_conflict_update(conflict_id, "resolved")

    @mcp.tool()
    def runtime_candidates() -> dict[str, Any]:
        return service.runtime_candidates()

    @mcp.tool()
    def org_connector_add(
        kind: str,
        config: dict[str, Any] | None = None,
        display_name: str | None = None,
        access_scope: str = "restricted",
        remote_enabled: bool = False,
    ) -> dict[str, Any]:
        return service.org_connector_add(
            kind,
            config=config or {},
            display_name=display_name,
            access_scope=access_scope,
            remote_enabled=remote_enabled,
        )

    @mcp.tool()
    def org_ingest(
        connector: str,
        since: str | None = None,
        path: str | None = None,
        remote: bool = False,
        actor: str = "system",
    ) -> dict[str, Any]:
        return service.org_ingest(connector, since=since, path=path, remote=remote, actor=actor)

    @mcp.tool()
    def org_candidates(
        status: str | None = "quarantined",
        source: str | None = None,
        scope: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        return service.org_candidates(status=status, source=source, scope=scope, limit=limit)

    @mcp.tool()
    def org_approve(candidate_id: str, actor: str = "codeowner:mcp") -> dict[str, Any]:
        return service.org_approve(candidate_id, actor=actor)

    @mcp.tool()
    def org_reject(
        candidate_id: str, actor: str = "codeowner:mcp", reason: str = "rejected"
    ) -> dict[str, Any]:
        return service.org_reject(candidate_id, actor=actor, reason=reason)

    @mcp.tool()
    def decision_start(
        question: str,
        options: list[str] | None = None,
        seed_paths: list[str] | None = None,
    ) -> dict[str, Any]:
        return service.decision_start(question, options=options or [], seed_paths=seed_paths or [])

    @mcp.tool()
    def decision_analyze(decision_id: str) -> dict[str, Any]:
        return service.decision_analyze(decision_id)

    @mcp.tool()
    def decision_record(
        decision_id: str,
        chosen_option_id: str,
        rationale: str,
        actor: str | None = None,
    ) -> dict[str, Any]:
        if not chosen_option_id or not rationale:
            raise ValueError("decision_record requires chosen_option_id and rationale")
        return service.decision_record(
            decision_id,
            chosen_option_id=chosen_option_id,
            rationale=rationale,
            actor=actor or "local-user:mcp",
        )

    @mcp.tool()
    def dashboard_data() -> dict[str, Any]:
        return service.dashboard_data()

    @mcp.tool()
    def architecture_infer() -> dict[str, Any]:
        return service.architecture_infer()

    @mcp.tool()
    def architecture_explain(service_name: str) -> dict[str, Any]:
        return service.architecture_explain(service_name)

    @mcp.tool()
    def architecture_drift(strict: bool = False) -> dict[str, Any]:
        return service.architecture_drift(strict=strict, persist=False)

    @mcp.tool()
    def anticipation_consult(
        task: str,
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        return service.anticipation_consult(task, paths=paths or [])

    @mcp.tool()
    def semantic_search(query: str, limit: int = 20) -> dict[str, Any]:
        return service.semantic_search(query, limit)

    @mcp.tool()
    def semantic_accuracy_eval(fixtures: str | None = None) -> dict[str, Any]:
        return service.semantic_accuracy_eval(fixtures)

    @mcp.tool()
    def semantic_low_confidence(threshold: float = 0.5) -> dict[str, Any]:
        return service.semantic_low_confidence(threshold)

    @mcp.tool()
    def semantic_repair_list(status: str = "open", limit: int = 100) -> dict[str, Any]:
        return service.semantic_repair_list(status=status, limit=limit)

    @mcp.tool()
    def semantic_repair_confirm(
        finding_id: str,
        rationale: str = "",
        actor: str = "human:mcp",
    ) -> dict[str, Any]:
        return service.semantic_repair_confirm(finding_id, actor=actor, rationale=rationale)

    @mcp.tool()
    def semantic_repair_reject(
        finding_id: str,
        rationale: str = "",
        actor: str = "human:mcp",
    ) -> dict[str, Any]:
        return service.semantic_repair_reject(finding_id, actor=actor, rationale=rationale)

    @mcp.tool()
    def agent_route(
        task: str,
        risk_score: float = 0.0,
        capabilities: list[str] | None = None,
        remote_review_enabled: bool = False,
    ) -> dict[str, Any]:
        return service.agent_route(
            task,
            risk_score=risk_score,
            capabilities=capabilities,
            remote_review_enabled=remote_review_enabled,
        )

    @mcp.tool()
    def workflow_recommend(
        task: str,
        mode: WorkflowMode = "write",
        paths: list[str] | None = None,
        capabilities: list[str] | None = None,
        intent_id: str | None = None,
        goal_id: str | None = None,
    ) -> dict[str, Any]:
        return service.workflow_recommend(
            task,
            mode=mode,
            paths=paths or [],
            capabilities=capabilities or [],
            intent_id=intent_id,
            goal_id=goal_id,
        )

    @mcp.tool()
    def workflow_start(
        task: str,
        mode: WorkflowMode = "write",
        paths: list[str] | None = None,
        capabilities: list[str] | None = None,
        intent_id: str | None = None,
        goal_id: str | None = None,
    ) -> dict[str, Any]:
        return service.workflow_start(
            task,
            mode=mode,
            paths=paths or [],
            capabilities=capabilities or [],
            intent_id=intent_id,
            goal_id=goal_id,
        )

    @mcp.tool()
    def workflow_next(task_session_id: str) -> dict[str, Any]:
        return service.workflow_next(task_session_id=task_session_id)

    @mcp.tool()
    def workflow_lint() -> dict[str, Any]:
        return service.workflow_lint()

    @mcp.tool()
    def governance_status() -> dict[str, Any]:
        return service.governance_status()

    @mcp.tool()
    def governance_propose(min_samples: int | None = None) -> dict[str, Any]:
        return service.governance_propose(min_samples=min_samples)

    @mcp.tool()
    def governance_list(status: str | None = None) -> dict[str, Any]:
        return service.governance_list(status=status)

    @mcp.tool()
    def governance_show(proposal_id: str) -> dict[str, Any]:
        return service.governance_show(proposal_id)

    @mcp.tool()
    def governance_preview_adoption(proposal_id: str) -> dict[str, Any]:
        return service.governance_preview_adoption(proposal_id)

    @mcp.tool()
    def governance_adopt(
        proposal_id: str,
        actor: str = "local-user",
        reason: str | None = None,
    ) -> dict[str, Any]:
        return service.governance_adopt(proposal_id, actor=actor, reason=reason)

    @mcp.tool()
    def governance_reject(proposal_id: str, reason: str | None = None) -> dict[str, Any]:
        return service.governance_reject(proposal_id, reason=reason)

    @mcp.tool()
    def governance_rollback(adoption_id: str, reason: str | None = None) -> dict[str, Any]:
        return service.governance_rollback(adoption_id, reason=reason)

    @mcp.tool()
    def provider_status() -> dict[str, Any]:
        return service.provider_status()

    @mcp.tool()
    def metacog_state(
        task: str,
        paths: list[str] | None = None,
        task_session_id: str | None = None,
    ) -> dict[str, Any]:
        return service.metacog_state(task, paths=paths or [], task_session_id=task_session_id)

    @mcp.tool()
    def clarify_open(
        question: str,
        task_session_id: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        return service.clarify_open(question, task_session_id=task_session_id, pack_id=pack_id)

    @mcp.tool()
    def clarify_answer(request_id: str, answer: str) -> dict[str, Any]:
        return service.clarify_answer(request_id, answer)

    @mcp.tool()
    def clarify_list(
        task_session_id: str | None = None,
        status: str | None = "open",
        limit: int = 50,
    ) -> dict[str, Any]:
        return service.clarify_list(task_session_id=task_session_id, status=status, limit=limit)

    @mcp.tool()
    def clarify_withdraw(request_id: str, reason: str | None = None) -> dict[str, Any]:
        return service.clarify_withdraw(request_id, reason=reason)

    @mcp.tool()
    def workspace_explain(task: str, paths: list[str] | None = None) -> dict[str, Any]:
        return service.workspace_explain(task, paths=paths or [])

    @mcp.tool()
    def judgment_status() -> dict[str, Any]:
        return service.judgment_status()

    @mcp.tool()
    def judgment_propose() -> dict[str, Any]:
        return service.judgment_propose()

    @mcp.tool()
    def judgment_adopt(
        heuristic_id: str,
        actor: str = "local-user",
        reason: str | None = None,
    ) -> dict[str, Any]:
        return service.judgment_adopt(heuristic_id, actor=actor, reason=reason)

    @mcp.tool()
    def judgment_reject(heuristic_id: str, reason: str | None = None) -> dict[str, Any]:
        return service.judgment_reject(heuristic_id, reason=reason)

    @mcp.tool()
    def narrative_show() -> dict[str, Any]:
        return service.narrative_show()

    @mcp.tool()
    def capability_matrix(output_format: str = "json") -> dict[str, Any]:
        return service.capability_matrix(output_format)

    @mcp.tool()
    def capability_claims_check(claim: str | None = None) -> dict[str, Any]:
        return service.capability_claims_check(claim)

    @mcp.tool()
    def teacher_runtime_start(
        task_session_id: str,
        task: str,
        pack_id: str | None = None,
        agent_session_id: str | None = None,
    ) -> dict[str, Any]:
        return service.teacher_runtime_start(
            task_session_id,
            task,
            pack_id=pack_id,
            agent_session_id=agent_session_id,
        )

    @mcp.tool()
    def teacher_runtime_status(
        run_id: str | None = None, task_session_id: str | None = None
    ) -> dict[str, Any]:
        return service.teacher_runtime_status(run_id=run_id, task_session_id=task_session_id)

    @mcp.tool()
    def teacher_runtime_obligations(run_id: str, status: str | None = None) -> dict[str, Any]:
        return service.teacher_runtime_obligations(run_id, status)

    @mcp.tool()
    def teacher_runtime_resolve(
        obligation_id: str, evidence_ref: str, actor: str = "codex"
    ) -> dict[str, Any]:
        return service.teacher_runtime_resolve(obligation_id, evidence_ref, actor)

    @mcp.tool()
    def teacher_runtime_events(run_id: str) -> dict[str, Any]:
        return service.teacher_runtime_events(run_id)

    @mcp.tool()
    def teach_event(
        event_type: str,
        source: str,
        summary: str,
        task_session_id: str | None = None,
        privacy_class: str = "summary_only",
    ) -> dict[str, Any]:
        return service.teach_event(
            event_type,
            source,
            summary,
            task_session_id=task_session_id,
            privacy_class=privacy_class,
        )

    @mcp.tool()
    def teach_brief(task_session_id: str) -> dict[str, Any]:
        return service.teach_brief(task_session_id)

    @mcp.tool()
    def teach_exam(task_session_id: str, exam: dict[str, Any]) -> dict[str, Any]:
        return service.teach_exam(task_session_id, exam)

    @mcp.tool()
    def teach_reflection(task_session_id: str, reflection: dict[str, Any]) -> dict[str, Any]:
        return service.teach_reflection(task_session_id, reflection)

    @mcp.tool()
    def lesson_list(status: str | None = None) -> dict[str, Any]:
        return service.lesson_list(status)

    @mcp.tool()
    def lesson_decide(
        lesson_id: str,
        decision: str,
        actor: str = "professional-teacher:mcp",
        rationale: str = "",
    ) -> dict[str, Any]:
        return service.lesson_decide(lesson_id, decision, actor, rationale)

    @mcp.tool()
    def student_profile(agent_kind: str = "codex") -> dict[str, Any]:
        return service.student_profile(agent_kind)

    @mcp.tool()
    def curriculum_recommend(task_session_id: str, objective: str) -> dict[str, Any]:
        return service.curriculum_recommend(task_session_id, objective)

    @mcp.tool()
    def living_graph_status(branch: str | None = None) -> dict[str, Any]:
        return service.graph_status(branch)

    @mcp.tool()
    def living_graph_update(
        paths: list[str],
        branch: str | None = None,
        deleted_paths: list[str] | None = None,
        source_ref: str | None = None,
    ) -> dict[str, Any]:
        return service.graph_update(
            paths,
            branch=branch,
            deleted_paths=deleted_paths,
            source_ref=source_ref,
        )

    @mcp.tool()
    def living_graph_query(
        query: str = "",
        graph_version_id: str | None = None,
        node_type: str | None = None,
        limit: int = 50,
        budget_ms: int = 100,
    ) -> dict[str, Any]:
        return service.graph_query(
            query,
            graph_version_id=graph_version_id,
            node_type=node_type,
            limit=limit,
            budget_ms=budget_ms,
        )

    @mcp.tool()
    def living_graph_neighbors(
        node_id: str,
        graph_version_id: str | None = None,
        limit: int = 50,
    ) -> dict[str, Any]:
        return service.living_graph_neighbors(
            node_id, graph_version_id=graph_version_id, limit=limit
        )

    @mcp.tool()
    def living_graph_fork(source_graph_version_id: str, branch: str) -> dict[str, Any]:
        return service.graph_fork(source_graph_version_id, branch)

    @mcp.tool()
    def living_graph_merge_review(
        source_graph_version_id: str, target_graph_version_id: str
    ) -> dict[str, Any]:
        return service.graph_merge_review(source_graph_version_id, target_graph_version_id)

    @mcp.tool()
    def teacher_review_request(
        item_type: str,
        item_id: str,
        requested_by: str = "mcp-agent",
        risk: str = "medium",
    ) -> dict[str, Any]:
        return service.teacher_review_request(item_type, item_id, requested_by, risk=risk)

    @mcp.tool()
    def teacher_review_list(status: str | None = "pending") -> dict[str, Any]:
        return service.teacher_review_list(status)

    @mcp.tool()
    def teacher_review_decide(
        review_id: str,
        decision: str,
        actor: str,
        role: str = "professional_teacher",
        rationale: str = "",
    ) -> dict[str, Any]:
        return service.teacher_review_decide(review_id, decision, actor, role, rationale)

    @mcp.tool()
    def team_lesson_import_decide(
        import_id: str,
        decision: str,
        actor: str,
        role: str = "professional_teacher",
    ) -> dict[str, Any]:
        return service.team_lesson_import_decide(import_id, decision, actor, role)

    @mcp.tool()
    def orchestration_create(
        parent_task_session_id: str,
        objective: str,
        tasks: list[dict[str, Any]],
        dependencies: list[dict[str, str]] | None = None,
    ) -> dict[str, Any]:
        return service.orchestration_create(
            parent_task_session_id,
            objective,
            tasks,
            dependencies=dependencies or [],
        )

    @mcp.tool()
    def orchestration_status(orchestration_id: str) -> dict[str, Any]:
        return service.orchestration_status(orchestration_id)

    @mcp.tool()
    def orchestration_checkpoint(
        orchestration_id: str,
        role_id: str | None = None,
        changed_files: list[str] | None = None,
        tests: list[str] | None = None,
        blockers: list[str] | None = None,
    ) -> dict[str, Any]:
        return service.orchestration_checkpoint(
            orchestration_id,
            role_id=role_id,
            changed_files=changed_files,
            tests=tests,
            blockers=blockers,
        )

    @mcp.tool()
    def orchestration_child_start(
        orchestration_task_id: str,
    ) -> dict[str, Any]:
        return service.orchestration_child_start(orchestration_task_id)

    @mcp.tool()
    def orchestration_child_stop(
        child_agent_session_id: str,
        summary: str,
        changed_files: list[str] | None = None,
        tests_run: list[str] | None = None,
        blockers: list[str] | None = None,
    ) -> dict[str, Any]:
        return service.orchestration_child_stop(
            child_agent_session_id,
            summary,
            changed_files=changed_files,
            tests_run=tests_run,
            blockers=blockers,
        )

    @mcp.tool()
    def orchestration_integrate(
        orchestration_id: str,
        output_id: str,
        decision: str,
        actor: str,
        verifier_status: str | None = None,
        rationale: str = "",
    ) -> dict[str, Any]:
        return service.orchestration_integrate(
            orchestration_id,
            output_id,
            decision,
            actor,
            verifier_status=verifier_status,
            rationale=rationale,
        )

    @mcp.tool()
    def teacher_benchmark_suite_create(
        name: str,
        version: str,
        purpose: str,
        tasks: list[dict[str, Any]],
    ) -> dict[str, Any]:
        return service.teacher_benchmark_suite_create(name, version, purpose, tasks)

    @mcp.tool()
    def teacher_benchmark_run_start(
        suite_id: str, baseline_run_id: str | None = None
    ) -> dict[str, Any]:
        return service.teacher_benchmark_run_start(suite_id, baseline_run_id=baseline_run_id)

    @mcp.tool()
    def teacher_benchmark_compare(
        baseline_run_id: str,
        candidate_run_id: str,
        thresholds: dict[str, float],
    ) -> dict[str, Any]:
        return service.teacher_benchmark_compare(baseline_run_id, candidate_run_id, thresholds)

    @mcp.tool()
    def teacher_benchmark_resume(benchmark_run_id: str) -> dict[str, Any]:
        return service.teacher_benchmark_resume(benchmark_run_id)

    @mcp.tool()
    def teacher_benchmark_waive(
        regression_id: str,
        actor: str,
        reason: str,
        expires_at: str,
    ) -> dict[str, Any]:
        return service.teacher_benchmark_waive(regression_id, actor, reason, expires_at)

    @mcp.tool()
    def teacher_release_gate(suite_id: str) -> dict[str, Any]:
        return service.teacher_release_gate(suite_id)

    @mcp.tool()
    def teacher_claim_evaluate(
        claim: str,
        candidate_run_id: str,
        baseline_run_id: str | None = None,
    ) -> dict[str, Any]:
        return service.teacher_claim_evaluate(
            claim, candidate_run_id, baseline_run_id=baseline_run_id
        )

    @mcp.tool()
    def incident_list(
        kind: str | None = None,
        status: str | None = None,
        severity: str | None = None,
        category: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        return service.incident_list(
            kind=kind, status=status, severity=severity, category=category, limit=limit
        )

    @mcp.tool()
    def incident_show(occurrence_id: str = "") -> dict[str, Any]:
        return service.incident_show(occurrence_id=occurrence_id)

    @mcp.tool()
    def incident_validate(occurrence_id: str = "") -> dict[str, Any]:
        return service.incident_validate(occurrence_id=occurrence_id)

    try:
        mcp.run()
    finally:
        close_call_services()
