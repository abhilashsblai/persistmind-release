from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from persistmind.analytics.queries import query_rows
from persistmind.utils import stable_id


def propose_judgment_heuristics_from_store(
    store: Any,
    *,
    workspace_id: str,
    repo_id: str | None,
    analytics_backend: str = "auto",
    db_path: Path | None = None,
) -> dict[str, Any]:
    grouped = query_rows(
        sqlite_conn=store.conn,
        db_path=db_path or store.db_path,
        sqlite_sql="""
            SELECT record_id, metadata_json
            FROM memory_records
            WHERE type = ? AND workspace_id = ? AND repo_id = ?
            ORDER BY updated_at DESC, record_id
        """,
        duckdb_sql="""
            SELECT record_id, metadata_json
            FROM sqlite_db.memory_records
            WHERE type = ? AND workspace_id = ? AND repo_id = ?
            ORDER BY updated_at DESC, record_id
        """,
        params=("failure_lesson", workspace_id, repo_id or ""),
        requested_backend=analytics_backend,
    )
    proposals = propose_judgment_heuristics(
        _failure_lesson_events(grouped["rows"]), repo_id=repo_id
    )
    return {
        "proposals": proposals,
        "analytics_backend": grouped["backend"],
        "analytics_parity_ok": bool(grouped["parity_ok"]),
        "analytics_fallback_reason": grouped.get("fallback_reason"),
    }


def propose_judgment_heuristics(events: list[Any], *, repo_id: str | None) -> list[dict[str, Any]]:
    failures_by_path: dict[str, list[str]] = {}
    for event in events:
        payload = _payload(event)
        result = str(payload.get("result") or payload.get("outcome_result") or "").lower()
        if result not in {"fail", "failed", "error", "blocked"}:
            continue
        for path in payload.get("changed_files") or payload.get("paths") or []:
            normalized = str(path).replace("\\", "/")
            failures_by_path.setdefault(normalized, []).append(str(_event_ref(event)))
    proposals = []
    for path, refs in sorted(failures_by_path.items()):
        if len(refs) < 2:
            continue
        assertion = f"When touching {path}, prefer running its targeted tests before broad checks."
        proposals.append(
            {
                "heuristic_id": stable_id("judgment", repo_id or "", path, assertion),
                "scope": path,
                "assertion": assertion,
                "basis": {"event_refs": refs, "repo_id": repo_id},
                "support": len(refs),
                "lift": min(1.0, len(refs) / 10.0),
                "status": "candidate",
            }
        )
    return proposals


def _payload(event: Any) -> dict[str, Any]:
    if isinstance(event, dict):
        return event
    try:
        return json.loads(event["payload_json"] or "{}")
    except Exception:
        return {}


def _event_ref(event: Any) -> str:
    if isinstance(event, dict):
        return str(event.get("event_id") or event.get("ref") or event.get("id") or "")
    try:
        return str(event["event_id"])
    except Exception:
        return ""


def _failure_lesson_events(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    events = []
    for row in rows:
        metadata = _json_dict(row.get("metadata_json"))
        paths = metadata.get("affected_paths") or metadata.get("paths") or []
        if not paths:
            paths = ["global"]
        refs = _string_list(metadata.get("evidence_refs") or metadata.get("occurrence_refs"))
        if not refs:
            refs = [str(row.get("record_id") or "")]
        for ref in sorted(set(refs)):
            events.append({"result": "fail", "paths": paths, "ref": ref})
    return events


def _json_dict(raw: Any) -> dict[str, Any]:
    if not raw:
        return {}
    try:
        parsed = json.loads(str(raw))
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item) for item in value if str(item).strip()]
