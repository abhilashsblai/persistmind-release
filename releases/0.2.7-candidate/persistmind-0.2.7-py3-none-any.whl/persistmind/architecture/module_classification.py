from __future__ import annotations

import ast
import json
from importlib import resources
from pathlib import Path
from typing import Any

MANIFEST_NAME = "module-classification.v1.json"


def load_module_classification() -> dict[str, Any]:
    with resources.files("persistmind.architecture").joinpath(MANIFEST_NAME).open(
        "r", encoding="utf-8"
    ) as handle:
        value = json.load(handle)
    if not isinstance(value, dict) or value.get("schema_version") != (
        "persistmind.module_classification.v1"
    ):
        raise ValueError("unsupported module classification manifest")
    return value


def architecture_lint(repo_root: Path) -> dict[str, Any]:
    root = Path(repo_root).resolve()
    manifest = load_module_classification()
    extended = {str(item) for item in manifest.get("extended_packages", [])}
    core_roots = {str(item) for item in manifest.get("core_packages", [])}
    allowlist = {
        (str(item.get("importer")), str(item.get("target_package")))
        for item in manifest.get("allowlist", [])
        if isinstance(item, dict)
    }
    findings: list[dict[str, Any]] = []
    for path in sorted((root / "src" / "persistmind").rglob("*.py")):
        module = _module_name(root, path)
        parts = module.split(".")
        if len(parts) < 2 or parts[1] not in core_roots:
            continue
        for imported, lineno in _persistmind_imports(path):
            target = _top_package(imported)
            if target not in extended:
                continue
            allowed = (module, target) in allowlist
            findings.append(
                {
                    "importer": module,
                    "target": imported,
                    "target_package": target,
                    "path": path.relative_to(root).as_posix(),
                    "line": lineno,
                    "allowed": allowed,
                }
            )
    violations = [item for item in findings if not item["allowed"]]
    return {
        "ok": not violations,
        "status": "pass" if not violations else "fail",
        "schema_version": "persistmind.architecture_lint.v1",
        "manifest": MANIFEST_NAME,
        "violations": violations,
        "allowlisted": [item for item in findings if item["allowed"]],
        "violation_count": len(violations),
        "allowlisted_count": len(findings) - len(violations),
    }


def _module_name(root: Path, path: Path) -> str:
    relative = path.relative_to(root / "src").with_suffix("")
    return ".".join(relative.parts)


def _persistmind_imports(path: Path) -> list[tuple[str, int]]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except (OSError, SyntaxError, UnicodeDecodeError):
        return []
    imports: list[tuple[str, int]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                name = alias.name
                if name == "persistmind" or name.startswith("persistmind."):
                    imports.append((name, node.lineno))
        elif isinstance(node, ast.ImportFrom) and node.module:
            if node.module == "persistmind" or node.module.startswith("persistmind."):
                imports.append((node.module, node.lineno))
    return imports


def _top_package(module: str) -> str:
    parts = module.split(".")
    return parts[1] if len(parts) > 1 and parts[0] == "persistmind" else ""


__all__ = ["MANIFEST_NAME", "architecture_lint", "load_module_classification"]
