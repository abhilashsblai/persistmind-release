from __future__ import annotations

import hashlib
import json
import re
import shlex
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from .shell_intent import analyze_shell_command

ToolKind = Literal["read", "write", "scan", "network", "control", "unknown"]
ToolScope = Literal["narrow", "broad", "unknown"]

_MCP_READ_VERBS = {
    "fetch",
    "find",
    "get",
    "health",
    "inspect",
    "list",
    "lookup",
    "query",
    "read",
    "search",
    "show",
    "status",
    "view",
}
_MCP_WRITE_VERBS = {
    "add",
    "archive",
    "cancel",
    "copy",
    "create",
    "delete",
    "execute",
    "forward",
    "label",
    "move",
    "patch",
    "post",
    "put",
    "remove",
    "rename",
    "reply",
    "run",
    "send",
    "set",
    "share",
    "update",
    "upload",
    "write",
}
_MCP_SCAN_VERBS = {
    "all",
    "directory",
    "enumerate",
    "find",
    "glob",
    "grep",
    "index",
    "list",
    "search",
    "tree",
    "walk",
}
_PERSISTMIND_CONTEXT_MCP_TOOLS = {
    "codex_enforcement_status",
    "get_impact_report",
    "get_pack_manifest",
    "impact_of",
    "mcp_capabilities",
    "memory_recall",
    "plan_show",
    "search_code",
    "search_repo",
    "session_explain",
    "storage_roles",
    "storage_status",
    "storage_verify",
    "task_show",
    "workflow_brief",
}
_PERSISTMIND_BOOTSTRAP_MCP_TOOLS = {
    "codex_preflight",
    "get_context_pack",
    "task_start",
}
_NON_REPOSITORY_CONTROL_MCP_SERVERS = {
    "browser",
    "chrome",
    "chrome_devtools",
}
_NON_REPOSITORY_MCP_SERVERS = {
    "supabase",
    "tool_search",
}
_TOOL_DISCOVERY_TOOLS = {
    "toolsearch",
    "toolsearchtool",
}
_WRITE_TOOLS = {
    "applypatch",
    "edit",
    "multiedit",
    "notebookedit",
    "strreplaceeditor",
    "write",
}
_READ_TOOLS = {"read", "view", "glob", "grep", "search", "find", "list", "ls"}
_NETWORK_TOOLS = {"websearch", "webfetch"}
_CONTROL_TOOLS = {"task", "agent", "slashcommand"}
_PATH_TARGET_KEYS = {
    "path",
    "file_path",
    "relative_path",
    "root_path",
    "directory",
    "root",
    "cwd",
    "search_path",
    "dir",
    "folder",
    "file",
    "filename",
}


@dataclass(frozen=True)
class ToolCapability:
    kind: ToolKind
    targets: tuple[str, ...] = ()
    scope: ToolScope = "unknown"
    read_only: bool = False
    repository_context_read: bool = False
    governance_bootstrap: bool = False
    non_repository_read: bool = False
    reason: str = ""
    scan_allow_keys: tuple[str, ...] = ()


def classify_tool(
    tool: str,
    command: str,
    tool_input: Mapping[str, Any],
    *,
    repo: Path | None = None,
) -> ToolCapability:
    normalized = _normalized_tool(tool)
    if _is_shell_tool(normalized):
        return _classify_shell(command, tool_input, repo=repo)
    if normalized in _TOOL_DISCOVERY_TOOLS:
        return ToolCapability(
            kind="control",
            read_only=True,
            repository_context_read=False,
            non_repository_read=True,
        )
    if normalized.startswith("mcp"):
        return _classify_mcp(tool, tool_input, repo=repo)
    targets = tuple(_tool_targets(tool_input))
    broad = _tool_scope_broad(targets, repo=repo)
    if normalized in _READ_TOOLS:
        kind: ToolKind = (
            "scan" if normalized in {"glob", "grep", "search", "find", "list", "ls"} else "read"
        )
        return ToolCapability(
            kind=kind,
            targets=targets,
            scope="broad" if broad or (kind == "scan" and not targets) else "narrow",
            read_only=True,
            repository_context_read=True,
        )
    if normalized in _NETWORK_TOOLS:
        return ToolCapability(kind="network", read_only=True, repository_context_read=False)
    if normalized in _CONTROL_TOOLS:
        return ToolCapability(kind="control", read_only=True, repository_context_read=False)
    if normalized in _WRITE_TOOLS:
        return ToolCapability(kind="write", targets=targets, scope="narrow", read_only=False)
    return ToolCapability(kind="unknown", targets=targets, repository_context_read=True)


def persistmind_mcp_bootstrap_name(tool: str) -> bool:
    normalized = tool.casefold()
    prefix = "mcp__persistmind__"
    return (
        normalized.startswith(prefix)
        and normalized[len(prefix) :] in _PERSISTMIND_BOOTSTRAP_MCP_TOOLS
    )


def persistmind_mcp_context_name(tool: str) -> bool:
    normalized = tool.casefold()
    prefix = "mcp__persistmind__"
    return (
        normalized.startswith(prefix)
        and normalized[len(prefix) :] in _PERSISTMIND_CONTEXT_MCP_TOOLS
    )


def _classify_shell(
    command: str, tool_input: Mapping[str, Any], *, repo: Path | None
) -> ToolCapability:
    if _looks_like_persistmind_invocation(command):
        from persistmind.codex import (
            _ctx_governance_operation,
            _safe_ctx_governance_command,
            _safe_ctx_read_only_command,
        )

        if _safe_persistmind_diagnostic_command(_ctx_governance_operation(command)):
            return ToolCapability(kind="control", read_only=True, repository_context_read=False)
        if _safe_ctx_governance_command(command):
            return ToolCapability(kind="control", read_only=False, governance_bootstrap=True)
        if _safe_ctx_read_only_command(command):
            return ToolCapability(kind="control", read_only=True, repository_context_read=False)
    if _safe_codex_consultation(command, tool_input, repo=repo):
        return ToolCapability(
            kind="control",
            scope="narrow",
            read_only=True,
            repository_context_read=False,
            non_repository_read=True,
        )

    analysis = analyze_shell_command(command, repo=repo)
    if analysis.non_repository_read:
        return ToolCapability(
            kind="read",
            targets=tuple(analysis.read_targets),
            scope="narrow",
            read_only=True,
            repository_context_read=False,
            non_repository_read=True,
        )
    if analysis.broad_scan:
        return ToolCapability(
            kind="scan",
            targets=tuple(analysis.read_targets),
            scope="broad",
            read_only=True,
            repository_context_read=True,
            reason=analysis.broad_scan_reason,
        )
    if analysis.repository_read:
        return ToolCapability(
            kind="read",
            targets=tuple(analysis.read_targets),
            scope="narrow" if analysis.read_targets else "unknown",
            read_only=True,
            repository_context_read=True,
        )
    from persistmind.codex import _SHELL_WRITE_SIGNAL

    if _SHELL_WRITE_SIGNAL.search(command):
        return ToolCapability(kind="write", read_only=False)
    return ToolCapability(kind="unknown", repository_context_read=True)


def _looks_like_persistmind_invocation(command: str) -> bool:
    prefix = command.lstrip()[:512].casefold()
    if not prefix:
        return False
    if (
        prefix.startswith("persistmind")
        or prefix.startswith("'persistmind'")
        or prefix.startswith('"persistmind"')
    ):
        return True
    if prefix.startswith("&") and "persistmind" in prefix:
        return True
    return (
        " -m persistmind" in prefix
        or " '-m' 'persistmind'" in prefix
        or ' "-m" "persistmind"' in prefix
    )


def _safe_persistmind_diagnostic_command(operation: tuple[str, str | None] | None) -> bool:
    if operation is None:
        return False
    command_name, subcommand = operation
    if command_name == "doctor":
        return True
    if command_name == "storage" and subcommand in {"status", "verify", "resources"}:
        return True
    return command_name == "codex" and subcommand == "enforcement-status"


def _safe_codex_consultation(
    command: str, tool_input: Mapping[str, Any], *, repo: Path | None
) -> bool:
    try:
        argv = [_strip_shell_token(token) for token in shlex.split(command, posix=False)]
    except ValueError:
        return False
    if len(argv) < 2:
        return False
    executable = argv[0].replace("\\", "/").rsplit("/", 1)[-1].casefold()
    if executable not in {"codex", "codex.exe"} or argv[1].casefold() != "exec":
        return False
    if any(token in command for token in (";", "&&", "||", "|", "<", ">", "`", "$(")):
        return False
    lowered = [token.casefold() for token in argv]
    if "--json" not in lowered:
        return False
    sandbox = _option_value(argv, "--sandbox")
    if sandbox and sandbox.casefold() in {
        "workspace-write",
        "danger-full-access",
        "dangerously-bypass-approvals-and-sandbox",
    }:
        return False
    if sandbox and sandbox.casefold() in {"read-only", "readonly"}:
        return True
    workdir = (
        _option_value(argv, "-C") or _option_value(argv, "--cwd") or _option_value(argv, "--cd")
    )
    if workdir is None:
        for key in ("cwd", "workdir", "working_directory"):
            value = tool_input.get(key)
            if value:
                workdir = str(value)
                break
    return bool(workdir and _outside_repo(workdir, repo))


def _strip_shell_token(token: str) -> str:
    if len(token) >= 2 and token[0] == token[-1] and token[0] in {"'", '"'}:
        return token[1:-1]
    return token


def _option_value(argv: list[str], name: str) -> str | None:
    key = name.casefold()
    prefix = key + "="
    for token in argv:
        lowered_token = token.casefold()
        if lowered_token.startswith(prefix):
            return token[len(name) + 1 :]
    lowered = [token.casefold() for token in argv]
    if key not in lowered:
        return None
    index = lowered.index(key)
    if index + 1 >= len(argv):
        return ""
    return argv[index + 1]


def _outside_repo(value: str, repo: Path | None) -> bool:
    if repo is None:
        return False
    try:
        path = Path(value).expanduser()
        if not path.is_absolute():
            path = repo / path
        path = path.resolve()
        root = repo.resolve()
        try:
            path.relative_to(root)
            return False
        except ValueError:
            return True
    except OSError:
        return False


def _classify_mcp(
    tool: str,
    tool_input: Mapping[str, Any],
    *,
    repo: Path | None,
) -> ToolCapability:
    if persistmind_mcp_bootstrap_name(tool):
        return ToolCapability(kind="control", read_only=False, governance_bootstrap=True)
    if persistmind_mcp_context_name(tool):
        return ToolCapability(kind="read", read_only=True, repository_context_read=False)
    if _non_repository_control_mcp_name(tool):
        return ToolCapability(
            kind="control",
            read_only=True,
            repository_context_read=False,
            non_repository_read=True,
        )
    tokens = set(_mcp_tokens(tool))
    targets = tuple(_tool_targets(tool_input))
    if _non_repository_mcp_name(tool):
        if tokens & _MCP_WRITE_VERBS:
            return ToolCapability(kind="write", targets=targets, read_only=False)
        return ToolCapability(
            kind="network",
            targets=targets,
            scope="narrow",
            read_only=True,
            repository_context_read=False,
            non_repository_read=True,
        )
    broad = _tool_scope_broad(targets, repo=repo)
    if tokens & _MCP_WRITE_VERBS:
        return ToolCapability(kind="write", targets=targets, read_only=False)
    if tokens & _MCP_SCAN_VERBS:
        return ToolCapability(
            kind="scan",
            targets=targets,
            scope="broad" if broad or not targets else "narrow",
            read_only=True,
            repository_context_read=True,
            scan_allow_keys=tuple(_mcp_scan_allow_keys(tool)),
        )
    if tokens & _MCP_READ_VERBS:
        return ToolCapability(
            kind="read",
            targets=targets,
            scope="narrow" if targets else "unknown",
            read_only=True,
            repository_context_read=True,
        )
    return ToolCapability(kind="unknown", targets=targets, repository_context_read=True)


def _tool_targets(tool_input: Mapping[str, Any]) -> list[str]:
    raw: list[object] = []
    for name, value in _iter_tool_input_items(tool_input):
        if value is None or value == "":
            continue
        normalized = name.casefold()
        is_path_key = normalized in _PATH_TARGET_KEYS or normalized.endswith("_file")
        if not is_path_key:
            continue
        raw.extend(value if isinstance(value, list) else [value])
    return [str(value).strip().strip("'\"") for value in raw if str(value).strip()]


def _iter_tool_input_items(value: Mapping[str, Any], prefix: str = "") -> list[tuple[str, Any]]:
    items: list[tuple[str, Any]] = []
    for key, item in value.items():
        name = f"{prefix}_{key}" if prefix else str(key)
        if isinstance(item, Mapping):
            items.extend(_iter_tool_input_items(item, name))
        else:
            items.append((name, item))
    return items


def _tool_scope_broad(targets: tuple[str, ...] | list[str], *, repo: Path | None) -> bool:
    if not targets:
        return False
    return any(_is_repository_root_or_ancestor(value, repo) for value in targets)


def _is_repository_root_or_ancestor(value: object, repo: Path | None) -> bool:
    text = str(value or "").strip()
    if text in {"", ".", "./", ".\\"}:
        return True
    if repo is None:
        return False
    try:
        candidate = Path(text).expanduser()
        if not candidate.is_absolute():
            candidate = repo / candidate
        resolved = candidate.resolve()
        root = repo.resolve()
        return resolved == root or root.is_relative_to(resolved)
    except (OSError, ValueError):
        return False


def _mcp_tokens(tool: str) -> list[str]:
    return [token for token in re.split(r"[^a-z0-9]+", tool.casefold()) if token and token != "mcp"]


def _non_repository_control_mcp_name(tool: str) -> bool:
    parts = [part for part in tool.casefold().split("__") if part and part != "mcp"]
    return bool(parts and parts[0] in _NON_REPOSITORY_CONTROL_MCP_SERVERS)


def _non_repository_mcp_name(tool: str) -> bool:
    parts = [part for part in tool.casefold().split("__") if part and part != "mcp"]
    return bool(parts and parts[0] in _NON_REPOSITORY_MCP_SERVERS)


def _mcp_scan_allow_keys(tool: str) -> list[str]:
    normalized = tool.casefold()
    parts = [part for part in normalized.split("__") if part and part != "mcp"]
    keys = {normalized}
    if parts:
        keys.add(parts[-1])
    if len(parts) >= 2:
        keys.add("__".join(parts[-2:]))
        keys.add(".".join(parts[-2:]))
    return sorted(keys)


def mcp_input_digest(tool: str, tool_input: Mapping[str, Any]) -> str:
    material = {
        "tool": tool,
        "tool_input": tool_input,
    }
    encoded = json.dumps(material, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8", errors="replace")).hexdigest()[:12]


def _normalized_tool(tool: str) -> str:
    return "".join(character for character in tool.casefold() if character.isalnum())


def _is_shell_tool(normalized: str) -> bool:
    return any(name in normalized for name in ("bash", "shell", "terminal"))


__all__ = [
    "ToolCapability",
    "classify_tool",
    "mcp_input_digest",
    "persistmind_mcp_bootstrap_name",
    "persistmind_mcp_context_name",
]
