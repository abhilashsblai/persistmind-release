from __future__ import annotations

import hashlib
import re
import shlex
from dataclasses import dataclass, field
from pathlib import Path

_WALK_HEURISTIC = re.compile(
    r"""(?ix)
    os\.walk|\.rglob\s*\(|glob\s*\(\s*['"]\*\*|dir\.glob|readdirsync|get-childitem|opendir|file::find
    """
)
_PS_ALIASES = {
    "cat": "get-content",
    "gc": "get-content",
    "type": "get-content",
    "gci": "get-childitem",
    "ls": "ls",
    "dir": "dir",
    "deno": "deno",
    "bun": "bun",
    "py": "python",
    "ruby": "ruby",
    "sls": "select-string",
}
MAX_SHELL_COMMAND_BYTES = 16 * 1024
MAX_SUBSTITUTION_DEPTH = 8


@dataclass(frozen=True)
class ShellIntent:
    executable: str
    argv: tuple[str, ...] = ()
    recursive: bool = False
    targets: tuple[str, ...] = ()
    enumerates_repo: bool = False
    reads_repo: bool = False
    non_repository_read: bool = False
    digest: str = ""
    reason: str = ""


@dataclass(frozen=True)
class ShellAnalysis:
    intents: tuple[ShellIntent, ...] = field(default_factory=tuple)

    @property
    def broad_scan(self) -> bool:
        return any(intent.enumerates_repo for intent in self.intents)

    @property
    def repository_read(self) -> bool:
        return any(intent.reads_repo for intent in self.intents)

    @property
    def non_repository_read(self) -> bool:
        return bool(self.intents) and all(intent.non_repository_read for intent in self.intents)

    @property
    def read_targets(self) -> list[str]:
        targets: list[str] = []
        for intent in self.intents:
            targets.extend(intent.targets)
            if intent.reads_repo and not intent.targets:
                targets.append(f"<shell-read:{intent.digest}>")
        return sorted(set(targets))

    @property
    def broad_scan_reason(self) -> str:
        for intent in self.intents:
            if intent.enumerates_repo and intent.reason:
                return intent.reason
        return ""


def analyze_shell_command(command: str, *, repo: Path | None = None) -> ShellAnalysis:
    return _analyze_shell_command(command, repo=repo, substitution_depth=0)


def _analyze_shell_command(
    command: str, *, repo: Path | None, substitution_depth: int
) -> ShellAnalysis:
    if len(command.encode("utf-8", errors="replace")) > MAX_SHELL_COMMAND_BYTES:
        return _bounded_substitution_scan(
            command,
            "shell command exceeds classifier length bound",
        )
    nested_broad = False
    nested_reason = ""
    for body in [*_substitution_bodies(command), *_powershell_array_bodies(command)]:
        if substitution_depth >= MAX_SUBSTITUTION_DEPTH:
            nested_reason = "shell substitution nesting exceeds classifier depth bound"
            break
        nested = _analyze_shell_command(
            body,
            repo=repo,
            substitution_depth=substitution_depth + 1,
        )
        if nested.broad_scan:
            nested_broad = True
            nested_reason = nested.broad_scan_reason
            break
    if nested_broad or nested_reason:
        digest = hashlib.sha256(command.encode("utf-8", errors="replace")).hexdigest()[:12]
        return ShellAnalysis(
            (
                ShellIntent(
                    executable="<substitution>",
                    argv=(command,),
                    targets=(".",),
                    enumerates_repo=True,
                    reads_repo=True,
                    digest=digest,
                    reason=nested_reason,
                ),
            )
        )
    if _interpreter_walks(command):
        digest = hashlib.sha256(command.encode("utf-8", errors="replace")).hexdigest()[:12]
        executable = _canonical_executable(command.strip().split(maxsplit=1)[0])
        return ShellAnalysis(
            (
                ShellIntent(
                    executable=executable,
                    argv=(command,),
                    targets=(".",),
                    enumerates_repo=True,
                    reads_repo=True,
                    digest=digest,
                ),
            )
        )
    digest = hashlib.sha256(command.encode("utf-8", errors="replace")).hexdigest()[:12]
    literal_assignment = _powershell_literal_assignment_intent(command, digest=digest)
    if literal_assignment is not None:
        return ShellAnalysis((literal_assignment,))
    segments = [segment.strip() for segment in _control_segments(command) if segment.strip()]
    return ShellAnalysis(
        tuple(_classify_segment(segment, repo=repo) for segment in segments)
    )


def _bounded_substitution_scan(command: str, reason: str) -> ShellAnalysis:
    digest = hashlib.sha256(command.encode("utf-8", errors="replace")).hexdigest()[:12]
    return ShellAnalysis(
        (
            ShellIntent(
                executable="<substitution>",
                argv=(command[:256],),
                targets=(".",),
                enumerates_repo=True,
                reads_repo=True,
                digest=digest,
                reason=reason,
            ),
        )
    )


def _interpreter_walks(command: str) -> bool:
    try:
        argv = _split_segment(command)
    except ValueError:
        argv = tuple(command.strip().split(maxsplit=1))
    executable = _canonical_executable(argv[0]) if argv else ""
    return executable in {
        "python",
        "python3",
        "node",
        "pwsh",
        "powershell",
        "perl",
        "ruby",
        "deno",
        "bun",
    } and bool(_WALK_HEURISTIC.search(command))


def _classify_segment(segment: str, *, repo: Path | None) -> ShellIntent:
    digest = hashlib.sha256(segment.encode("utf-8", errors="replace")).hexdigest()[:12]
    assignment_intent = _powershell_literal_assignment_intent(segment, digest=digest)
    if assignment_intent is not None:
        return assignment_intent
    temp_intent = _powershell_temp_command_file_intent(segment, digest=digest)
    if temp_intent is not None:
        return temp_intent
    try:
        argv = _split_segment(segment)
    except ValueError:
        return ShellIntent(
            executable="<unparsed>",
            argv=(segment,),
            reads_repo=True,
            digest=digest,
        )
    if not argv:
        return ShellIntent(executable="", digest=digest, non_repository_read=True)
    executable = _canonical_executable(argv[0])
    argv = _normalize_git_c(argv)
    executable = _canonical_executable(argv[0]) if argv else executable
    cmd_intent = _cmd_shell_intent(executable, argv, repo=repo, digest=digest)
    if cmd_intent is not None:
        return cmd_intent
    archive_intent = _compress_archive_intent(executable, argv, repo=repo, digest=digest)
    if archive_intent is not None:
        return archive_intent
    flags = _canonical_flags(argv[1:])
    lowered = " ".join(argv).casefold()
    targets = tuple(_positional_targets(executable, argv, flags))

    non_repo = _is_non_repository_read(executable, argv)
    reads = non_repo or _is_repository_read_executable(executable, argv)
    enumerates = False if non_repo else _enumerates_repo(
        executable, argv, flags, targets, lowered, repo=repo
    )
    if enumerates:
        reads = True
    return ShellIntent(
        executable=executable,
        argv=argv,
        recursive=_has_recursive_flag(flags),
        targets=targets,
        enumerates_repo=enumerates,
        reads_repo=reads and not non_repo,
        non_repository_read=non_repo,
        digest=digest,
    )


def _canonical_executable(value: str) -> str:
    name = value.replace("\\", "/").rsplit("/", 1)[-1].casefold()
    for suffix in (".exe", ".com", ".cmd", ".bat", ".ps1"):
        name = name.removesuffix(suffix)
    return _PS_ALIASES.get(name, name)


def _cmd_shell_intent(
    executable: str,
    argv: tuple[str, ...],
    *,
    repo: Path | None,
    digest: str,
) -> ShellIntent | None:
    if executable != "cmd":
        return None
    for index, token in enumerate(argv[1:], start=1):
        if token.casefold() not in {"/c", "/k"}:
            continue
        body = " ".join(argv[index + 1 :]).strip()
        if not body:
            return ShellIntent(
                executable="cmd",
                argv=argv,
                digest=digest,
                non_repository_read=True,
            )
        nested = _analyze_shell_command(body, repo=repo, substitution_depth=1)
        if not nested.intents:
            return ShellIntent(
                executable="cmd",
                argv=argv,
                digest=digest,
                non_repository_read=True,
            )
        if nested.broad_scan:
            return ShellIntent(
                executable="cmd",
                argv=argv,
                targets=tuple(nested.read_targets) or (".",),
                enumerates_repo=True,
                reads_repo=True,
                digest=digest,
                reason=nested.broad_scan_reason,
            )
        if nested.repository_read:
            return ShellIntent(
                executable="cmd",
                argv=argv,
                targets=tuple(nested.read_targets),
                reads_repo=True,
                digest=digest,
            )
        return ShellIntent(
            executable="cmd",
            argv=argv,
            digest=digest,
            non_repository_read=True,
        )
    return None


def _powershell_literal_assignment_intent(segment: str, *, digest: str) -> ShellIntent | None:
    stripped = segment.strip()
    if not re.match(r"(?is)^\$[a-z_][\w:.-]*\s*=", stripped):
        return None
    _, value = stripped.split("=", 1)
    value = value.lstrip()
    if value.startswith("@("):
        bodies = _balanced_operator_bodies(value, "@(")
        if not bodies or not _powershell_array_body_is_literal(bodies[0]):
            return None
        return ShellIntent(
            executable="<powershell-assignment>",
            argv=(segment,),
            digest=digest,
            non_repository_read=True,
        )
    if not value.startswith(("@{", "@'", '@"', "'", '"', "{", "[")):
        return None
    return ShellIntent(
        executable="<powershell-assignment>",
        argv=(segment,),
        digest=digest,
        non_repository_read=True,
    )


def _powershell_temp_command_file_intent(segment: str, *, digest: str) -> ShellIntent | None:
    stripped = segment.strip()
    if re.match(
        r"(?is)^\$[a-z_][\w:.-]*\s*=\s*join-path\s+\$env:(?:temp|tmp)\b",
        stripped,
    ):
        return ShellIntent(
            executable="<powershell-temp-assignment>",
            argv=(segment,),
            digest=digest,
            non_repository_read=True,
        )
    if re.match(
        r"(?is)^\[system\.io\.file\]::writeall(?:lines|text)\s*\(\s*\$[a-z_][\w:.-]*\s*,",
        stripped,
    ):
        return ShellIntent(
            executable="<powershell-temp-write>",
            argv=(segment,),
            digest=digest,
            non_repository_read=True,
        )
    return None


def _compress_archive_intent(
    executable: str,
    argv: tuple[str, ...],
    *,
    repo: Path | None,
    digest: str,
) -> ShellIntent | None:
    if executable not in {"powershell", "pwsh", "compress-archive"}:
        return None
    if executable in {"powershell", "pwsh"}:
        lowered = [token.casefold() for token in argv]
        if not any("compress-archive" in token for token in lowered):
            return None
    targets = tuple(_compress_archive_sources(argv))
    if not targets:
        return None
    broad = any(_archive_source_is_broad(target, repo) for target in targets)
    return ShellIntent(
        executable=executable,
        argv=argv,
        targets=targets,
        enumerates_repo=broad,
        reads_repo=True,
        digest=digest,
        reason="archive source expands beyond explicit files" if broad else "",
    )


def _compress_archive_sources(argv: tuple[str, ...]) -> list[str]:
    sources: list[str] = []
    source_option = False
    destination_option = False
    for token in argv[1:]:
        lowered = token.casefold()
        if destination_option:
            destination_option = False
            continue
        if source_option:
            source_option = False
            sources.extend(_split_archive_source_token(token))
            continue
        if lowered in {"-path", "-literalpath"}:
            source_option = True
            continue
        if lowered.startswith("-path:") or lowered.startswith("-literalpath:"):
            sources.extend(_split_archive_source_token(token.split(":", 1)[1]))
            continue
        if lowered in {"-destinationpath", "-compressionlevel", "-update"}:
            destination_option = lowered != "-update"
            continue
    return [source for source in sources if source]


def _split_archive_source_token(token: str) -> list[str]:
    stripped = token.strip().strip("'\"")
    if not stripped:
        return []
    return [part.strip().strip("'\"") for part in stripped.split(",") if part.strip()]


def _archive_source_is_broad(value: str, repo: Path | None) -> bool:
    if any(pattern in value for pattern in ("*", "?")):
        return True
    text = value.strip()
    if text in {"", ".", "./", ".\\"}:
        return True
    try:
        path = Path(text).expanduser()
        if repo is not None and not path.is_absolute():
            path = repo / path
        if path.exists() and path.is_dir():
            return True
    except OSError:
        return False
    return _is_repo_or_ancestor(text, repo)


def _split_segment(segment: str) -> tuple[str, ...]:
    tokens = [_strip_token_quotes(token) for token in shlex.split(segment, posix=False)]
    if tokens:
        match = re.match(r"(?i)^(dir|ls)(/.+)$", tokens[0])
        if match:
            tokens = [match.group(1), match.group(2), *tokens[1:]]
    return tuple(tokens)


def _strip_token_quotes(token: str) -> str:
    if len(token) >= 2 and token[0] == token[-1] and token[0] in {"'", '"'}:
        return token[1:-1]
    return token


def _normalize_git_c(argv: tuple[str, ...]) -> tuple[str, ...]:
    if not argv or _canonical_executable(argv[0]) != "git":
        return argv
    result = [argv[0]]
    index = 1
    while index < len(argv):
        token = argv[index]
        if token == "-C" and index + 1 < len(argv):
            index += 2
            continue
        result.extend(argv[index:])
        break
    return tuple(result)


def _canonical_flags(argv: tuple[str, ...]) -> tuple[str, ...]:
    flags: list[str] = []
    for token in argv:
        if token.startswith("--"):
            flags.append("-R" if token == "--recursive" else token.casefold())
            continue
        if token.startswith("/"):
            lowered = token.casefold()
            if "s" in lowered.replace("/", ""):
                flags.append("/s")
            continue
        if token.startswith("-") and not token.startswith("--"):
            lowered = token.casefold()
            if lowered in {"-rec", "-recurse"}:
                flags.append("-recurse")
            elif lowered in {"-r", "-R".casefold()}:
                flags.append("-R")
            elif len(token) > 2 and not token[1].isdigit():
                flags.extend(f"-{character}" for character in token[1:])
            else:
                flags.append(token)
    return tuple(flags)


def _has_recursive_flag(flags: tuple[str, ...]) -> bool:
    lowered = {flag.casefold() for flag in flags}
    return bool(lowered & {"-r", "-R".casefold(), "-recurse", "/s"})


def _positional_targets(
    executable: str, argv: tuple[str, ...], flags: tuple[str, ...]
) -> list[str]:
    del flags
    if executable == "git":
        return []
    targets: list[str] = []
    skip_next = False
    fd_pattern_seen = False
    search_pattern_seen = False
    for token in argv[1:]:
        if skip_next:
            skip_next = False
            continue
        if token.casefold() in {"-c", "-pattern", "-path", "--glob", "-name", "-t", "--type"}:
            skip_next = True
            continue
        if token.startswith("-") or token.startswith("/"):
            continue
        if executable in {"rg", "grep", "select-string"}:
            if not search_pattern_seen:
                search_pattern_seen = True
                continue
            targets.append(token)
            continue
        if executable == "fd" and not fd_pattern_seen:
            fd_pattern_seen = True
            continue
        if executable in {
            "python",
            "python3",
            "node",
            "pwsh",
            "powershell",
            "perl",
            "ruby",
            "deno",
            "bun",
        }:
            continue
        targets.append(token)
    return targets


def _looks_like_path(token: str) -> bool:
    return (
        token in {".", "./", ".\\"}
        or "/" in token
        or "\\" in token
        or "*" in token
        or token.endswith((".py", ".js", ".ts", ".md", ".json", ".toml", ".yaml", ".yml"))
    )


def _is_repository_read_executable(executable: str, argv: tuple[str, ...]) -> bool:
    if executable in {
        "get-content",
        "read",
        "view",
        "rg",
        "grep",
        "find",
        "fd",
        "tree",
        "get-childitem",
        "select-string",
        "ls",
        "dir",
    }:
        return True
    return executable == "git" and len(argv) >= 2 and argv[1].casefold() in {
        "grep",
        "ls-files",
        "show",
        "diff",
    }


def _is_non_repository_read(executable: str, argv: tuple[str, ...]) -> bool:
    if executable in {
        "echo",
        "printf",
        "date",
        "whoami",
        "hostname",
        "pwd",
        "cd",
        "get-command",
        "get-location",
        "get-process",
        "get-variable",
        "get-nettcpconnection",
        "get-netudpendpoint",
        "test-netconnection",
        "netstat",
        "tasklist",
    }:
        return True
    if executable in {"python", "python3", "node", "npm", "pnpm", "yarn"} and any(
        token in {"--version", "-v", "version"} for token in argv[1:]
    ):
        return True
    return executable == "git" and len(argv) >= 2 and argv[1].casefold() in {
        "status",
        "log",
        "rev-parse",
        "branch",
        "remote",
    }


def _enumerates_repo(
    executable: str,
    argv: tuple[str, ...],
    flags: tuple[str, ...],
    targets: tuple[str, ...],
    lowered: str,
    *,
    repo: Path | None,
) -> bool:
    if executable == "git" and len(argv) >= 2 and argv[1].casefold() in {"ls-files", "grep"}:
        return True
    if executable in {"rg", "fd", "tree"}:
        return _targets_are_unscoped_or_root_like(targets, repo)
    if executable in {"get-childitem", "select-string"} and _has_recursive_flag(flags):
        return _targets_are_unscoped_or_root_like(targets, repo)
    if executable in {"ls", "dir", "grep"} and _has_recursive_flag(flags):
        return _targets_are_unscoped_or_root_like(targets, repo)
    if executable == "find":
        return any(_is_repo_or_ancestor(target, repo) for target in (targets or (".",)))
    if executable in {
        "python",
        "python3",
        "node",
        "pwsh",
        "powershell",
        "perl",
        "ruby",
        "deno",
        "bun",
    }:
        return bool(_WALK_HEURISTIC.search(lowered))
    if executable == "<substitution>":
        return True
    if any("**" in target or "{" in target for target in targets):
        return True
    if executable == "tar" and any(token == "-tf" or token.startswith("-") and "t" in token for token in argv[1:]):
        return True
    return False


def _targets_are_unscoped_or_root_like(targets: tuple[str, ...], repo: Path | None) -> bool:
    return not targets or any(_is_repo_or_ancestor(target, repo) for target in targets)


def _substitution_bodies(command: str) -> list[str]:
    bodies: list[str] = []
    index = 0
    while index < len(command):
        if command.startswith("$(", index):
            start = index + 2
            depth = 1
            cursor = start
            quote: str | None = None
            while cursor < len(command):
                character = command[cursor]
                if quote:
                    if character == quote:
                        quote = None
                elif character in {"'", '"'}:
                    quote = character
                elif command.startswith("$(", cursor):
                    depth += 1
                    cursor += 1
                elif character == ")":
                    depth -= 1
                    if depth == 0:
                        bodies.append(command[start:cursor])
                        index = cursor + 1
                        break
                cursor += 1
            else:
                index += 2
            continue
        if command[index] == "`":
            cursor = command.find("`", index + 1)
            if cursor >= 0:
                bodies.append(command[index + 1 : cursor])
                index = cursor + 1
                continue
        index += 1
    return bodies


def _powershell_array_bodies(command: str) -> list[str]:
    return [
        body
        for body in _balanced_operator_bodies(command, "@(")
        if not _powershell_array_body_is_literal(body)
    ]


def _balanced_operator_bodies(command: str, opener: str) -> list[str]:
    bodies: list[str] = []
    index = 0
    while index < len(command):
        if command.startswith(opener, index):
            start = index + len(opener)
            depth = 1
            cursor = start
            quote: str | None = None
            while cursor < len(command):
                character = command[cursor]
                if quote:
                    if character == quote:
                        quote = None
                elif character in {"'", '"'}:
                    quote = character
                elif command.startswith(opener, cursor):
                    depth += 1
                    cursor += len(opener) - 1
                elif character == ")":
                    depth -= 1
                    if depth == 0:
                        bodies.append(command[start:cursor])
                        index = cursor + 1
                        break
                cursor += 1
            else:
                index += len(opener)
            continue
        index += 1
    return bodies


def _control_segments(command: str) -> list[str]:
    segments: list[str] = []
    start = 0
    index = 0
    quote: str | None = None
    paren_depth = 0
    while index < len(command):
        character = command[index]
        if quote:
            if character == quote:
                quote = None
            index += 1
            continue
        if character in {"'", '"'}:
            quote = character
            index += 1
            continue
        if command.startswith("@(", index):
            paren_depth += 1
            index += 2
            continue
        if paren_depth and character == "(":
            paren_depth += 1
            index += 1
            continue
        if paren_depth and character == ")":
            paren_depth -= 1
            index += 1
            continue
        if paren_depth:
            index += 1
            continue
        if command.startswith("&&", index) or command.startswith("||", index):
            segments.append(command[start:index])
            index += 2
            start = index
            continue
        if character in {";", "&", "|", "\r", "\n"}:
            if character == "&" and not command[:index].strip():
                index += 1
                start = index
                continue
            segments.append(command[start:index])
            index += 1
            start = index
            continue
        index += 1
    segments.append(command[start:])
    return segments


def _powershell_array_body_is_literal(body: str) -> bool:
    stripped = body.strip()
    if not stripped:
        return True
    index = 0
    saw_value = False
    while index < len(stripped):
        while index < len(stripped) and stripped[index].isspace():
            index += 1
        if index >= len(stripped):
            break
        if stripped[index] == ",":
            index += 1
            continue
        if stripped[index] not in {"'", '"'}:
            return False
        quote = stripped[index]
        index += 1
        while index < len(stripped):
            if stripped[index] == quote:
                index += 1
                saw_value = True
                break
            index += 1
        else:
            return False
        while index < len(stripped) and stripped[index].isspace():
            index += 1
        if index < len(stripped) and stripped[index] not in {","}:
            return False
    return saw_value


def _is_repo_or_ancestor(value: str, repo: Path | None) -> bool:
    text = str(value or "").strip("'\"")
    if text in {"", ".", "./", ".\\"}:
        return True
    if repo is None:
        return text in {"/", "\\"}
    try:
        candidate = Path(text).expanduser()
        if not candidate.is_absolute():
            candidate = repo / candidate
        resolved = candidate.resolve()
        root = repo.resolve()
        return resolved == root or root.is_relative_to(resolved)
    except (OSError, ValueError):
        return False


__all__ = ["ShellAnalysis", "ShellIntent", "analyze_shell_command"]
