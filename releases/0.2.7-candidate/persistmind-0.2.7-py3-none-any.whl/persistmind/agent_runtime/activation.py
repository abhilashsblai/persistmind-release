from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from persistmind import __version__
from persistmind.branding import INSTALLATION_SCHEMA, resolve_project_state
from persistmind.updater.atomic import read_json, write_json

ACTIVATION_SCHEMA = "persistmind.host_activation.v1"
_MAX_BYTES = 32 * 1024


def record_host_attachment(repo: Path, payload: Mapping[str, Any]) -> dict[str, Any]:
    """Record that the installed hook actually ran inside a host session."""

    session_id = str(payload.get("session_id") or "").strip()
    document = {
        "schema_version": ACTIVATION_SCHEMA,
        "engine_version": __version__,
        "host": "codex",
        "session_id_sha256": (
            hashlib.sha256(session_id.encode("utf-8")).hexdigest() if session_id else None
        ),
        "observed_at": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
        "hook_event": "SessionStart",
    }
    path = _activation_path(repo)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(document, sort_keys=True, separators=(",", ":")), encoding="utf-8"
    )
    os.replace(temporary, path)
    status = activation_status(repo, expected_version=__version__)
    status["installation_manifest_reconciliation"] = _reconcile_installation_manifest(repo, status)
    return status


def activation_status(repo: Path, *, expected_version: str) -> dict[str, Any]:
    document = _read_activation(repo)
    version_matches = bool(document) and str(document.get("engine_version")) == expected_version
    session_identified = bool(document.get("session_id_sha256")) if document else False
    attached = version_matches and session_identified
    return {
        "schema_version": ACTIVATION_SCHEMA,
        "status": "attached_session_observed" if attached else "configured_restart_required",
        "direct_probe_status": "host_hook_observed" if attached else "callable_not_host_attached",
        "current_session_attached": attached,
        "restart_required": not attached,
        "diagnostic": (
            "A matching SessionStart hook has been observed for this installed runtime."
            if attached
            else "No matching SessionStart hook has been observed yet for this runtime; "
            "this is expected until a trusted host agent session starts after setup."
        ),
        "verification_scope": "host-session-observation",
        "attached_engine_version": document.get("engine_version") if document else None,
        "expected_engine_version": expected_version,
        "observed_at": document.get("observed_at") if document else None,
        "session_identity_recorded": session_identified,
        "project_trust": "user_review_required_if_prompted",
        "command_hook_review": "user_review_required_if_changed",
        "trust_store_mutated": False,
    }


def _read_activation(repo: Path) -> dict[str, Any]:
    path = _activation_path(repo)
    try:
        raw = path.read_bytes()
    except OSError:
        return {}
    if len(raw) > _MAX_BYTES:
        return {}
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {}
    if not isinstance(value, dict) or value.get("schema_version") != ACTIVATION_SCHEMA:
        return {}
    return value


def _activation_path(repo: Path) -> Path:
    return resolve_project_state(Path(repo).resolve()) / "runtime" / "host-activation.json"


def _reconcile_installation_manifest(repo: Path, status: Mapping[str, Any]) -> dict[str, Any]:
    path = resolve_project_state(Path(repo).resolve()) / "installation.json"
    try:
        manifest = read_json(path)
    except Exception as exc:
        return {
            "ok": False,
            "status": "read_failed",
            "path": str(path),
            "error_type": type(exc).__name__,
            "error": str(exc),
        }
    if not manifest:
        return {"ok": False, "status": "missing", "path": str(path)}
    if manifest.get("schema_version") != INSTALLATION_SCHEMA:
        return {
            "ok": False,
            "status": "unsupported_schema",
            "path": str(path),
            "schema_version": manifest.get("schema_version"),
        }

    attached = bool(status.get("current_session_attached"))
    activation = dict(manifest.get("agent_activation") or {})
    activation.update(
        {
            "schema_version": "persistmind.agent_activation.v1",
            "configured": True,
            "current_session_attached": attached,
            "restart_required": not attached,
            "direct_probe_status": status.get("direct_probe_status"),
            "diagnostic": status.get("diagnostic"),
            "verification_scope": status.get("verification_scope"),
            "attached_engine_version": status.get("attached_engine_version"),
            "expected_engine_version": status.get("expected_engine_version"),
            "observed_at": status.get("observed_at"),
            "session_identity_recorded": status.get("session_identity_recorded"),
            "project_trust": status.get("project_trust"),
            "command_hook_review": status.get("command_hook_review"),
            "trust_store_mutated": status.get("trust_store_mutated"),
            "status": ("attached_session_observed" if attached else "configured_restart_required"),
            "message": (
                "A matching host SessionStart hook has been observed for this runtime."
                if attached
                else "Host hook surfaces are configured, but no matching current session "
                "attachment has been observed yet."
            ),
        }
    )

    before_engine = manifest.get("engine_version")
    manifest["engine_version"] = __version__
    manifest["agent_activation"] = activation
    manifest["manifest_updated_at"] = datetime.now(UTC).isoformat().replace("+00:00", "Z")
    manifest["manifest_update_reason"] = "host_activation_observed"
    try:
        write_json(path, manifest)
    except Exception as exc:
        return {
            "ok": False,
            "status": "write_failed",
            "path": str(path),
            "error_type": type(exc).__name__,
            "error": str(exc),
        }
    return {
        "ok": True,
        "status": "updated",
        "path": str(path),
        "engine_version_before": before_engine,
        "engine_version_after": __version__,
        "agent_activation_status": activation["status"],
    }


__all__ = ["ACTIVATION_SCHEMA", "activation_status", "record_host_attachment"]
