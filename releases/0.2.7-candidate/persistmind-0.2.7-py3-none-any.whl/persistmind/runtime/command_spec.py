from __future__ import annotations

import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path

_BASE_ENVIRONMENT = frozenset(
    {
        "APPDATA",
        "COMSPEC",
        "HOME",
        "LANG",
        "LC_ALL",
        "LOCALAPPDATA",
        "PATH",
        "PATHEXT",
        "SYSTEMDRIVE",
        "SYSTEMROOT",
        "TEMP",
        "TMP",
        "USERNAME",
        "USERPROFILE",
        "WINDIR",
    }
)
_BENCH_ENVIRONMENT = frozenset(
    {
        "PERSISTMIND_BENCH_ARM",
        "PERSISTMIND_BENCH_CASE_ID",
        "PERSISTMIND_BENCH_CONTEXT_PATH",
        "PERSISTMIND_BENCH_PACK_ID",
        "PERSISTMIND_BENCH_PROMPT_PATH",
        "PERSISTMIND_BENCH_REPO",
        "PERSISTMIND_BENCH_TASK",
        "PERSISTMIND_LEARNING_BUDGET_TOKENS",
        "PERSISTMIND_LEARNING_CHILD",
        "PERSISTMIND_LEARNING_MODEL_FAMILY",
        "PERSISTMIND_LEARNING_PROMPT_PATH",
        "PERSISTMIND_LEARNING_ROLE",
        "PERSISTMIND_PROVIDER_DEPTH",
        "PERSISTMIND_REASONING_READ_ONLY",
    }
)
_POWERSHELL_BUILTINS = frozenset(
    {
        "cd",
        "foreach-object",
        "get-childitem",
        "get-content",
        "join-path",
        "pop-location",
        "push-location",
        "select-object",
        "select-string",
        "set-location",
        "where-object",
        "write-output",
    }
)


@dataclass(frozen=True, slots=True)
class CommandSpec:
    executable: Path
    arguments: tuple[str, ...]
    working_directory: Path
    environment: Mapping[str, str]
    timeout_seconds: int
    output_limit: int
    executable_sha256: str
    stdin_path: Path | None = None
    shell: bool = False

    @classmethod
    def from_local_command(
        cls,
        command: str,
        *,
        cwd: Path,
        timeout: int,
        environment: Mapping[str, str] | None = None,
        output_limit: int = 4000,
        stdin_path: Path | None = None,
    ) -> CommandSpec:
        if not command or any(character in command for character in ("\x00", "\r", "\n")):
            raise ValueError("local command must be one non-empty line")
        arguments: tuple[str, ...]
        if os.name == "nt" and _requires_powershell(command):
            executable = _resolve_powershell(cwd)
            arguments = ("-NoLogo", "-NoProfile", "-NonInteractive", "-Command", command)
        else:
            argv = _command_argv(command)
            executable = _resolve_executable(argv[0], cwd)
            arguments = tuple(argv[1:])
        return cls(
            executable=executable,
            arguments=arguments,
            working_directory=cwd.resolve(),
            environment=minimal_environment(environment),
            timeout_seconds=max(1, min(int(timeout), 3600)),
            output_limit=max(256, min(int(output_limit), 1_000_000)),
            executable_sha256=_sha256(executable),
            stdin_path=stdin_path.resolve() if stdin_path is not None else None,
        )

    @property
    def argv(self) -> tuple[str, ...]:
        return (str(self.executable), *self.arguments)

    def run(self) -> dict[str, object]:
        creationflags = (
            int(getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)) if os.name == "nt" else 0
        )
        stdin_handle = None
        try:
            if self.stdin_path is not None:
                stdin_handle = self.stdin_path.open("r", encoding="utf-8")
            completed = subprocess.run(
                list(self.argv),
                cwd=self.working_directory,
                env=dict(self.environment),
                shell=False,
                stdin=stdin_handle if stdin_handle is not None else subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=self.timeout_seconds,
                check=False,
                creationflags=creationflags,
                start_new_session=os.name != "nt",
            )
            return {
                "argv": list(self.argv),
                "exit_code": completed.returncode,
                "timed_out": False,
                "stdout": _trim(completed.stdout, self.output_limit),
                "stderr": _trim(completed.stderr, self.output_limit),
                "shell": False,
                "execution_mode": (
                    "powershell" if _is_powershell_executable(self.executable) else "direct"
                ),
                "executable_sha256": self.executable_sha256,
            }
        except subprocess.TimeoutExpired as exc:
            return {
                "argv": list(self.argv),
                "exit_code": 124,
                "timed_out": True,
                "stdout": _trim(exc.stdout or "", self.output_limit),
                "stderr": _trim(exc.stderr or "", self.output_limit),
                "shell": False,
                "execution_mode": (
                    "powershell" if _is_powershell_executable(self.executable) else "direct"
                ),
                "executable_sha256": self.executable_sha256,
            }
        finally:
            if stdin_handle is not None:
                stdin_handle.close()


def minimal_environment(overrides: Mapping[str, str] | None = None) -> dict[str, str]:
    result = {name: value for name, value in os.environ.items() if name in _BASE_ENVIRONMENT}
    for name, value in (overrides or {}).items():
        if name in _BENCH_ENVIRONMENT:
            result[name] = str(value)
    return result


def _command_argv(command: str) -> list[str]:
    stripped = command.strip()
    if stripped.startswith("["):
        try:
            value = json.loads(stripped)
        except json.JSONDecodeError as exc:
            raise ValueError("structured local command JSON is invalid") from exc
        if (
            not isinstance(value, list)
            or not value
            or not all(isinstance(item, str) and item for item in value)
        ):
            raise ValueError("structured local command must be a non-empty JSON string array")
        return list(value)
    powershell_call = stripped.startswith("&") and len(stripped) > 1 and stripped[1].isspace()
    if powershell_call:
        stripped = stripped[1:].lstrip()
    try:
        # PowerShell's call operator convention uses single-quoted arguments,
        # which CommandLineToArgvW intentionally does not interpret as quotes.
        # Parse that explicit form with the shell-neutral quoted-token parser;
        # execution still uses shell=False below.
        value = (
            shlex.split(stripped, posix=True)
            if powershell_call or os.name != "nt"
            else _windows_argv(stripped)
        )
    except ValueError as exc:
        raise ValueError("local command quoting is invalid") from exc
    if not value:
        raise ValueError("local command has no executable")
    return value


def _windows_argv(command: str) -> list[str]:
    import ctypes
    from ctypes import wintypes

    count = ctypes.c_int()
    command_line_to_argv = ctypes.windll.shell32.CommandLineToArgvW
    command_line_to_argv.argtypes = (wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_int))
    command_line_to_argv.restype = ctypes.POINTER(wintypes.LPWSTR)
    pointer = command_line_to_argv(command, ctypes.byref(count))
    if not pointer:
        raise ValueError("Windows command line parsing failed")
    try:
        return [pointer[index] for index in range(count.value)]
    finally:
        ctypes.windll.kernel32.LocalFree(pointer)


def _resolve_executable(value: str, cwd: Path) -> Path:
    candidate = Path(value).expanduser()
    if candidate.is_absolute():
        resolved = candidate.resolve()
    elif candidate.parent != Path("."):
        resolved = (cwd / candidate).resolve()
    else:
        found = shutil.which(value)
        if not found:
            raise FileNotFoundError(f"local command executable is unavailable: {value}")
        resolved = Path(found).resolve()
        if _is_bare_python(value) and not _python_launcher_is_usable(resolved):
            resolved = Path(sys.executable).resolve()
    if not resolved.is_file():
        raise FileNotFoundError(f"local command executable is not a file: {resolved}")
    return resolved


def _is_bare_python(value: str) -> bool:
    return Path(value).name.casefold() in {"python", "python.exe", "python3", "python3.exe"}


def _python_launcher_is_usable(path: Path) -> bool:
    try:
        completed = subprocess.run(
            [str(path), "-c", "import sys; raise SystemExit(0)"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return completed.returncode == 0


def _requires_powershell(command: str) -> bool:
    stripped = command.strip()
    if stripped.startswith("[") or (stripped.startswith("&") and stripped[1:2].isspace()):
        return False
    first = stripped.split(None, 1)[0].casefold() if stripped else ""
    return first in _POWERSHELL_BUILTINS or _contains_unquoted_pipeline(stripped)


def _contains_unquoted_pipeline(command: str) -> bool:
    quote: str | None = None
    escaped = False
    for character in command:
        if escaped:
            escaped = False
            continue
        if character == "`" and quote != "'":
            escaped = True
            continue
        if character in {"'", '"'}:
            if quote == character:
                quote = None
            elif quote is None:
                quote = character
            continue
        if character == "|" and quote is None:
            return True
    return False


def _resolve_powershell(cwd: Path) -> Path:
    for name in ("pwsh.exe", "pwsh", "powershell.exe", "powershell"):
        found = shutil.which(name)
        if found:
            return Path(found).resolve()
    raise FileNotFoundError(
        "PowerShell verification command requires pwsh or powershell.exe on PATH"
    )


def _is_powershell_executable(path: Path) -> bool:
    return path.stem.casefold() in {"pwsh", "powershell"}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _trim(value: str | bytes, limit: int) -> str:
    if isinstance(value, bytes):
        value = value.decode("utf-8", errors="replace")
    return value if len(value) <= limit else value[:limit] + "\n...[truncated]"
