from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any

from persistmind.agents.adapters.base import BootstrapContext
from persistmind.agents.contract import cursor_mcp_json, cursor_rule, write_if_changed


class CursorAdapter:
    name = "cursor"
    aliases = ()
    supports_hooks = False
    supports_subagents = False
    supports_skills = False
    instruction_file = ".cursor/rules/persistmind.mdc"

    def detect(self, env: Mapping[str, str]) -> bool:
        return bool(env.get("CURSOR_TRACE_ID")) or any(key.startswith("CURSOR_") for key in env)

    def render(self, ctx: BootstrapContext) -> list[Path]:
        return [
            write_if_changed(
                ctx.repo_root / ".cursor" / "rules" / "persistmind.mdc",
                cursor_rule(ctx.agent_names, ctx.runtime_invocation, ctx.mcp_repo),
            ),
            write_if_changed(
                ctx.repo_root / ".cursor" / "mcp.json",
                cursor_mcp_json(ctx.runtime_invocation, ctx.mcp_repo),
            ),
        ]

    def configure_mcp(
        self, ctx: BootstrapContext, *, config_path: Path | None = None
    ) -> dict[str, Any]:
        return {
            "ok": True,
            "agent": self.name,
            "changed": False,
            "hint": self.mcp_setup_hint(ctx),
            "project_config": str(ctx.repo_root / ".cursor" / "mcp.json"),
        }

    def readiness(self, repo_root: Path) -> dict[str, Any]:
        checks = {
            "cursor_rule": (repo_root / ".cursor" / "rules" / "persistmind.mdc").exists(),
            "cursor_mcp": (repo_root / ".cursor" / "mcp.json").exists(),
        }
        missing = [name for name, ok in checks.items() if not ok]
        return {
            "agent": self.name,
            "ok": not missing,
            "checks": checks,
            "missing": missing,
            "enforcement_level": "mcp-only",
            "degraded": True,
            "degradation_note": (
                "Cursor does not support PersistMind lifecycle hooks, subagents, or "
                "skills; enforcement is MCP plus always-applied rule guidance."
            ),
        }

    def mcp_setup_hint(self, ctx: BootstrapContext) -> str:
        return "Review `.cursor/mcp.json` in the project root."

    def reasoning_command(self, repo_root: Path) -> list[str] | None:
        return None
