from __future__ import annotations

import os
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from persistmind.agents.adapters.base import BootstrapContext
from persistmind.agents.contract import (
    SUBAGENT_SPECS,
    codex_agent_toml,
    codex_hook_wrapper_ps1,
    codex_hooks_json,
    codex_mcp_config,
    codex_project_config,
    ensure_instruction_contract,
    hook_script,
    write_if_changed,
)
from persistmind.branding import resolve_project_state


class CodexAdapter:
    name = "codex"
    aliases = ("openai-codex",)
    supports_hooks = True
    supports_subagents = True
    supports_skills = False
    instruction_file = "AGENTS.md"

    def detect(self, env: Mapping[str, str]) -> bool:
        return any(key.startswith("CODEX_") for key in env) or bool(
            env.get("CODEX_PROJECT_DIR") or env.get("CODEX_WORKSPACE_ROOT")
        )

    def render(self, ctx: BootstrapContext) -> list[Path]:
        written: list[Path] = []
        path, _changed = ensure_instruction_contract(
            ctx.repo_root / self.instruction_file,
            ctx.agent_names,
            agent_label="Codex",
            invocation=ctx.runtime_invocation,
        )
        written.append(path)
        codex_dir = ctx.repo_root / ".codex"
        agents_dir = codex_dir / "agents"
        hook_dir = ctx.workspace_root / "codex" / "hooks"
        written.extend(
            [
                write_if_changed(
                    ctx.workspace_root / "mcp" / "codex.config.toml",
                    codex_mcp_config(ctx.runtime_invocation, ctx.mcp_repo),
                ),
                write_if_changed(
                    codex_dir / "config.toml",
                    codex_project_config(ctx.runtime_invocation, ctx.mcp_repo),
                ),
                write_if_changed(
                    codex_dir / "hooks.json",
                    codex_hooks_json(ctx.repo_root, ctx.runtime_invocation),
                ),
                write_if_changed(
                    hook_dir / "persistmind-hook.ps1",
                    codex_hook_wrapper_ps1(ctx.runtime_invocation),
                ),
                write_if_changed(hook_dir / "persistmind_hook.py", hook_script()),
            ]
        )
        for spec in SUBAGENT_SPECS:
            written.append(
                write_if_changed(agents_dir / f"{spec.name}.toml", codex_agent_toml(spec))
            )
        return written

    def configure_mcp(
        self, ctx: BootstrapContext, *, config_path: Path | None = None
    ) -> dict[str, Any]:
        target = config_path or default_codex_config_path()
        block = codex_mcp_config(ctx.runtime_invocation, ctx.mcp_repo).strip() + "\n"
        existing = target.read_text(encoding="utf-8") if target.exists() else ""
        updated = _replace_toml_table(existing, "mcp_servers.persistmind", block)
        changed = updated != existing
        if changed:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(updated, encoding="utf-8")
        return {
            "ok": True,
            "agent": self.name,
            "config_path": str(target),
            "changed": changed,
            "block": block,
        }

    def readiness(self, repo_root: Path) -> dict[str, Any]:
        workspace = resolve_project_state(repo_root)
        agents_path = repo_root / self.instruction_file
        agents_text = agents_path.read_text(encoding="utf-8") if agents_path.exists() else ""
        checks = {
            "codex_agents_file": agents_path.exists(),
            "codex_agents_contract": "<!-- persistmind-agent-contract -->" in agents_text,
            "codex_mcp_snippet": (workspace / "mcp" / "codex.config.toml").exists(),
            "codex_project_config": (repo_root / ".codex" / "config.toml").exists(),
            "codex_hooks": (repo_root / ".codex" / "hooks.json").exists()
            and (workspace / "codex" / "hooks" / "persistmind_hook.py").exists(),
            "codex_agents": all(
                (repo_root / ".codex" / "agents" / f"{name}.toml").exists()
                for name in [
                    "persistmind-explorer",
                    "persistmind-worker",
                    "persistmind-reviewer",
                    "persistmind-verifier",
                ]
            ),
        }
        missing = [name for name, ok in checks.items() if not ok]
        return {
            "agent": self.name,
            "ok": not missing,
            "checks": checks,
            "missing": missing,
            "enforcement_level": "hooks",
        }

    def mcp_setup_hint(self, ctx: BootstrapContext) -> str:
        return "Copy `.persistmind/mcp/codex.config.toml` into Codex config or run setup with --configure-mcp."

    def reasoning_command(self, repo_root: Path) -> list[str] | None:
        return [
            "codex",
            "exec",
            "--ephemeral",
            "--skip-git-repo-check",
            "--sandbox",
            "read-only",
            "-C",
            str(repo_root),
            "-",
        ]


def default_codex_config_path() -> Path:
    """Return the active Codex config, including isolated CODEX_HOME sessions."""

    home = os.environ.get("CODEX_HOME")
    root = Path(home).expanduser() if home else Path.home() / ".codex"
    return root / "config.toml"


def _replace_toml_table(existing: str, table_name: str, block: str) -> str:
    lines = existing.splitlines()
    block_lines = block.strip().splitlines()
    generated_preamble = block_lines[0].strip() if block_lines else ""
    header = f"[{table_name}]"
    output: list[str] = []
    idx = 0
    replaced = False
    while idx < len(lines):
        if lines[idx].strip() == header:
            if generated_preamble.startswith("#"):
                while True:
                    while output and not output[-1].strip():
                        output.pop()
                    if output and output[-1].strip() == generated_preamble:
                        output.pop()
                        continue
                    break
            if output and output[-1].strip():
                output.append("")
            output.extend(block_lines)
            replaced = True
            idx += 1
            while idx < len(lines):
                stripped = lines[idx].strip()
                if stripped.startswith("[") and stripped.endswith("]"):
                    break
                idx += 1
            continue
        output.append(lines[idx])
        idx += 1

    if not replaced:
        if output and output[-1].strip():
            output.append("")
        output.extend(block_lines)

    return "\n".join(output).rstrip() + "\n"


def _remove_toml_table(existing: str, table_name: str) -> str:
    lines = existing.splitlines()
    header = f"[{table_name}]"
    output: list[str] = []
    skipping = False
    for line in lines:
        stripped = line.strip()
        if stripped == header:
            skipping = True
            continue
        if skipping and stripped.startswith("[") and stripped.endswith("]"):
            skipping = False
        if not skipping:
            output.append(line)
    return "\n".join(output).strip() + "\n" if output else ""
