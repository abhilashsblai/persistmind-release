from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from shlex import quote as shlex_quote

from persistmind.runtime_invocation import RuntimeInvocation, runtime_invocation

CONTRACT_MARKER = "<!-- persistmind-agent-contract -->"
CODEX_MCP_STARTUP_TIMEOUT_SEC = 120.0
# Hook handlers normally finish well below this budget, but failure reporting can
# require a cold Python import plus a SQLite transaction.  A two-second budget
# caused the host to terminate valid policy responses on Windows before the
# incident recorder completed.
HOOK_COMMAND_TIMEOUT_SECONDS = 30
PLAN_CREATE_FILE_SNIPPET = """$planPath = Join-Path $env:TEMP "persistmind-plan.json"
$planJson = @'
{
  "objective": "<objective>",
  "steps": [
    {
      "id": "edit",
      "title": "<step title>",
      "intended_files": ["<path>"],
      "intended_tests": [],
      "capabilities": ["edit_source"],
      "risk": "medium"
    }
  ]
}
'@
[System.IO.File]::WriteAllText($planPath, $planJson, [System.Text.UTF8Encoding]::new($false))
persistmind --repo . plan create --task-session-id <task_session_id> --pack-id <pack_id> --file $planPath"""
POWERSHELL_PLAN_FILE_GUIDANCE = (
    "Do not pass plan JSON inline on PowerShell. Always write the plan payload to a\n"
    "UTF-8 JSON file and pass it with `persistmind plan create --file`."
)
CODEX_MEMORY_PARALLEL_GUIDANCE = """## Codex Memory and Parallel-Agent Enforcement

Before write-capable Codex work, run:

```powershell
persistmind --repo . codex preflight --task "<task>" --mode write --task-session-id <task_session_id>
```

Treat the returned `memory_retrieval_id`, `continuation_matches`,
`served_memory_counts_by_type`, `policy_reference_count`, `skill_match_count`,
`parallel_recommendation`, `workflow` governance block, and `metacognition`
block as required context.
Use the relevant memory area for the task: active continuations for interrupted
work, project memory for facts/decisions/gotchas, policy references for
governance pointers, and skills for repeatable workflows.

Every pack can include a `metacognition` block. If it recommends `ask_human`
with an open clarification, ask the user that question before writing; if it
recommends `gather_more`, retrieve or search first; if it recommends `replan`,
revise the active plan. Treat this as a first-class instruction, not advice.

The write gate derives preflight and active-plan state from the PersistMind store when
available. Respect the configured governance enforcement mode (`off`, `audit`,
`warn`, or `block`) and use `persistmind --repo . workflow brief --task "<task>"`
or the MCP `workflow_brief` tool when you need a refreshed capability plan.

For broad or disjoint work, follow the returned `parallel_agent_plan`. Spawn
PersistMind-scoped explorer, worker, reviewer, and verifier agents when recommended,
keep worker write scopes disjoint, and let the parent agent perform final
integration, PersistMind checks, tests, and outcome recording.
"""
SKILL_EVOLUTION_GUIDANCE = """## Skill Evolution Feedback Capture

When a user asks for a correction to accepted work, capture the event without
storing raw content:

```powershell
persistmind --repo . skill revision --skill-id <skill_id> --output-id <output_id> --text "<short correction>"
persistmind --repo . skill classify --skill-id <skill_id>
persistmind --repo . skill metrics --skill-id <skill_id>
```

Treat preference revisions as project memory candidates, repeated missing
patterns as skill-improvement candidates, and error corrections as corrective
learning evidence. Skill refinements require evidence, explicit approval,
benchmarking, and closure verification before activation.
"""
STORAGE_ROUTING_GUIDANCE = """## PersistMind Storage Routing Contract

PersistMind initializes and owns eight writable authority roles under
`.persistmind/stores/`. Coding agents must save information through PersistMind CLI
or MCP operations; never open, edit, copy, replace, or run SQL against the database
files directly. PersistMind selects the role, applies validation, and records the
required lifecycle and audit evidence.

| Information to save | PersistMind role | Physical location | Write through |
| --- | --- | --- | --- |
| Repository snapshots, indexed files, symbols, dependencies, and generated code-search data | Source | `stores/source/default/manifest.db` plus immutable `stores/source/default/segments/` | `index`, `search`, snapshot, and pack operations; do not put task notes here |
| Current task sessions, goals, plans, checkpoints, clarifications, verifications, outcomes, and working notes | Task | `stores/task/task-state.db` | `task`, `goal`, `plan`, `working-memory`, `clarify`, `verify`, and `outcome` operations |
| Time-ordered execution history, context-pack activity, hook/runtime events, and operational receipts | Activity | `stores/activity/active.db` with managed sealed partitions | Normal PersistMind commands and hooks; activity is recorded automatically |
| Security-sensitive and tamper-evident action history, policy decisions, and administrative evidence | Audit | `stores/activity/audit/active.db` with managed sealed partitions | Governed PersistMind commands and hooks; never synthesize or rewrite audit rows |
| Durable project facts, decisions, conventions, relationships, and reusable experience | Knowledge | `stores/knowledge/knowledge.db` | `memory`, `decision`, `experience`, and successful `outcome` operations; exclude transient logs |
| Constitutions, rules, guardrails, approvals, and governance configuration | Policy | `stores/knowledge/policy.db` | `constitution`, `policy`, `guardrail`, and governance operations only |
| Lessons, skill feedback, evaluations, calibration, and evidence-backed behavioral improvements | Learning | `stores/learning/learning.db` | `learning`, `skill`, `lesson`, `teach`, evaluation, and reflection operations |

Paths are relative to `.persistmind/` and are implementation details: activity,
audit, and source stores can partition or seal. Discover the live layout with
`persistmind --repo . storage roles` and health with
`persistmind --repo . storage verify`; never infer routing from filenames.

Incident reporting is local and enabled by default. PersistMind automatically
captures controlled failures into authoritative JSON under
`.persistmind/incidents/`; feedback is stored under `.persistmind/feedback/`.
Database rows for reporting are rebuildable indexes, not the source of truth.
Network submission remains disabled unless a user explicitly configures and runs
it. If a failure is not captured automatically, record it with `incident create`.
"""
PERSISTMIND_FIRST_CONTEXT_GUIDANCE = """## Mandatory PersistMind-First Context

On every new agent session and every new user task, use PersistMind as the first
source of repository context. Before repository discovery, run:

```powershell
persistmind --repo . codex preflight --task "<current user task>" --mode read
```

For write-capable work, use `--mode write`, retain the returned
`task_session_id`, `pack_id`, and `memory_retrieval_id`, and create the required
plan before editing. Base investigation on the returned pack, project memory,
policy references, impact report, and PersistMind search results.

Do not scan or enumerate the whole repository to reconstruct context. Prohibited
shortcuts include root-wide recursive glob/grep, `rg --files`, `git ls-files`,
`Get-ChildItem -Recurse` from the repository root, `find .`, `tree`, bulk-opening
files, or equivalent MCP/tool calls. Preflight does not lift this scan gate. If
the pack is insufficient, query PersistMind again with `search`, `memory recall`,
`impact`, or a more specific pack request. Scoped reads and scoped recursive
search on a path identified by the user or PersistMind are permitted. Keep reads
scoped to the smallest relevant path.

Installed hooks invalidate prior context authorization at session start and on
each submitted prompt. They deny broad repository scans and write-capable tools
until the required PersistMind workflow state is current. Do not bypass, disable,
or work around those hooks.
"""
COMPLETION_GUIDANCE = """## PersistMind Completion Contract

Before declaring work complete, run the local preflight and impact checks:

Stage intended new files first so `git diff HEAD` and `git diff --name-only
HEAD` include them. Review the staged set before continuing.

Prefer the scoped check-diff form when the active plan lists intended files; it
records the durable `check_diff_clean` evidence without pulling unrelated dirty
worktree paths into the task:

```powershell
persistmind --repo . check-diff --pack-id <pack_id> --paths <changed_path> [<changed_path>...]
git diff --name-only HEAD | persistmind --repo . check-diff --pack-id <pack_id> --paths-from-stdin
git diff --name-only HEAD | persistmind --repo . impact --paths-from-stdin
```

Run the tests named by the impact report through `persistmind verify run`. After
check-diff, checkpoints, and tests pass, explicitly transition the task to
`OUTCOME`, then record the outcome with the same task/session and pack IDs:

```powershell
persistmind --repo . verify run --pack-id <pack_id> --plan-id <plan_id> --command "<test command>"
persistmind --repo . verify run --pack-id <pack_id> --plan-id <plan_id> --command-file <commands.txt>
persistmind --repo . task transition <task_session_id> --state OUTCOME --pack-id <pack_id>
persistmind --repo . outcome --task-session-id <task_session_id> --pack-id <pack_id> --result pass --episode-eligible
```

If outcome recording refuses closure because the task is still in `PREFLIGHT`,
run `persistmind --repo . workflow next --task-session-id <task_session_id>` and
resolve the pending gate it reports. Do not treat a passed test command as an
implicit OUTCOME transition.
"""


@dataclass(frozen=True)
class SubagentSpec:
    name: str
    description: str
    mode: str | None
    instructions: str


SUBAGENT_SPECS = [
    SubagentSpec(
        name="persistmind-explorer",
        description=(
            "Read-heavy PersistMind-aware explorer for codebase questions, context discovery, "
            "and risk triage."
        ),
        mode="read-only",
        instructions=(
            "Use PersistMind context before analysis. Stay read-only. Return concise "
            "findings with file references, uncertainty, and suggested follow-up "
            "checks. Do not edit files."
        ),
    ),
    SubagentSpec(
        name="persistmind-worker",
        description="Scoped PersistMind-aware implementation worker for disjoint file ownership.",
        mode=None,
        instructions=(
            "Before edits, require parent task_session_id, pack_id, plan_id, active "
            "step, and assigned write scope. Do not revert other agents' work. Edit "
            "only assigned files, checkpoint changed paths, run assigned checks, and "
            "return changed files plus verification results."
        ),
    ),
    SubagentSpec(
        name="persistmind-reviewer",
        description=(
            "PersistMind-aware reviewer focused on correctness, security, regressions, and missing tests."
        ),
        mode="read-only",
        instructions=(
            "Review using PersistMind pack, impact, memory, and policy context. Stay "
            "read-only. Prioritize bugs, security risks, regressions, and missing "
            "tests with concrete file references."
        ),
    ),
    SubagentSpec(
        name="persistmind-verifier",
        description=(
            "PersistMind-aware verification worker for tests, logs, impact reports, and "
            "failure localization."
        ),
        mode=None,
        instructions=(
            "Use PersistMind impact and plan context to run bounded verification. "
            "Prefer read-only diagnostics unless explicitly assigned a repair scope. "
            "Report commands, exits, failures, and likely owning files."
        ),
    ),
]

HOOK_EVENTS = (
    "SessionStart",
    "UserPromptSubmit",
    "PreToolUse",
    "PostToolUse",
    "SubagentStart",
    "SubagentStop",
    "Stop",
)


def write_if_changed(path: Path, content: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists() or path.read_text(encoding="utf-8") != content:
        path.write_text(content, encoding="utf-8")
    return path


def ensure_instruction_contract(
    path: Path,
    agent_names: list[str],
    *,
    agent_label: str | None = None,
    self_bootstrap: bool = True,
    invocation: RuntimeInvocation | str | None = None,
) -> tuple[Path, bool]:
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    changed = False
    if CONTRACT_MARKER not in existing:
        addition = agent_contract(
            agent_names,
            agent_label=agent_label,
            self_bootstrap=self_bootstrap,
            invocation=invocation,
        )
        if existing and not existing.endswith("\n"):
            existing += "\n"
        existing = f"{existing}\n{addition}" if existing else addition
        changed = True
    else:
        updated = ensure_agent_contract_guidance(
            existing,
            self_bootstrap=self_bootstrap,
            invocation=invocation,
        )
        if updated != existing:
            existing = updated
            changed = True
    if changed:
        path.write_text(existing, encoding="utf-8")
    return path, changed


def ensure_agent_contract_guidance(
    existing: str,
    *,
    self_bootstrap: bool = True,
    invocation: RuntimeInvocation | str | None = None,
) -> str:
    updated = replace_inline_json_plan_commands(existing)
    updated = _replace_legacy_completion_guidance(updated)
    updated = _upsert_managed_guidance(
        updated,
        key="codex-memory",
        content=CODEX_MEMORY_PARALLEL_GUIDANCE,
        legacy_end_heading="## Skill Evolution Feedback Capture",
    )
    updated = _upsert_managed_guidance(
        updated,
        key="skill-evolution",
        content=SKILL_EVOLUTION_GUIDANCE,
        legacy_end_text=(
            "Skill refinements require evidence, explicit approval,\n"
            "benchmarking, and closure verification before activation."
        ),
    )
    if self_bootstrap:
        updated = _upsert_managed_guidance(
            updated,
            key="self-bootstrap",
            content=self_bootstrap_prompt(),
            legacy_end_heading="## PersistMind Storage Routing Contract",
            legacy_end_text=(
                "file, MCP registration snippets, hooks, subagents, and skills the agent supports."
            ),
        )
    updated = _upsert_managed_guidance(
        updated,
        key="storage-routing",
        content=STORAGE_ROUTING_GUIDANCE,
        legacy_end_heading="## Mandatory PersistMind-First Context",
        legacy_end_text=(
            "If a failure is not captured automatically, record it with `incident create`."
        ),
    )
    updated = _upsert_managed_guidance(
        updated,
        key="persistmind-first-context",
        content=PERSISTMIND_FIRST_CONTEXT_GUIDANCE,
        legacy_end_text="or work around those hooks.",
    )
    updated = _upsert_managed_guidance(
        updated,
        key="completion-contract",
        content=COMPLETION_GUIDANCE,
        legacy_end_heading="To inspect the remembered development episode",
        legacy_end_text="persistmind --repo . outcome --pack-id <pack_id> --result pass",
    )
    if "Do not pass plan JSON inline on PowerShell." in updated:
        return _bind_runtime_contract(updated, invocation)

    guidance = f"{POWERSHELL_PLAN_FILE_GUIDANCE}\n\n"
    before_plan_rules = "The plan must include an objective and a `steps` list."
    if before_plan_rules in updated:
        updated = updated.replace(before_plan_rules, guidance + before_plan_rules, 1)
        return _bind_runtime_contract(updated, invocation)

    if updated.endswith("\n"):
        updated = updated + "\n" + guidance.rstrip() + "\n"
    else:
        updated = updated + "\n\n" + guidance.rstrip() + "\n"
    return _bind_runtime_contract(updated, invocation)


def _replace_legacy_completion_guidance(document: str) -> str:
    start = document.find("Before declaring work complete, run the local preflight")
    if start < 0:
        return document
    end = document.find("To inspect the remembered development episode", start)
    if end < 0:
        return document
    start_marker = "<!-- persistmind-managed:completion-contract:start -->"
    end_marker = "<!-- persistmind-managed:completion-contract:end -->"
    block = f"{start_marker}\n{COMPLETION_GUIDANCE.strip()}\n{end_marker}\n\n"
    return document[:start] + block + document[end:]


def _upsert_managed_guidance(
    document: str,
    *,
    key: str,
    content: str,
    legacy_end_heading: str | None = None,
    legacy_end_text: str | None = None,
) -> str:
    """Refresh one PersistMind-owned section without replacing project prose."""

    start_marker = f"<!-- persistmind-managed:{key}:start -->"
    end_marker = f"<!-- persistmind-managed:{key}:end -->"
    block = f"{start_marker}\n{content.strip()}\n{end_marker}"
    marked_start = document.find(start_marker)
    if marked_start >= 0:
        marked_end = document.find(end_marker, marked_start + len(start_marker))
        if marked_end >= 0:
            marked_end += len(end_marker)
            return document[:marked_start] + block + document[marked_end:]

    heading = content.lstrip().splitlines()[0]
    section_start = document.find(heading)
    if section_start >= 0:
        section_end = -1
        if legacy_end_heading:
            section_end = document.find(
                legacy_end_heading,
                section_start + len(heading),
            )
        if section_end < 0 and legacy_end_text:
            anchor = document.find(legacy_end_text, section_start + len(heading))
            if anchor >= 0:
                section_end = anchor + len(legacy_end_text)
        if section_end >= 0:
            while section_end < len(document) and document[section_end] in "\r\n":
                section_end += 1
            suffix = document[section_end:]
            separator = "\n\n" if suffix else "\n"
            return document[:section_start] + block + separator + suffix

    prefix = document.rstrip()
    return (prefix + "\n\n" if prefix else "") + block + "\n"


def replace_inline_json_plan_commands(existing: str) -> str:
    lines: list[str] = []
    for line in existing.splitlines(keepends=True):
        stripped = line.strip()
        newline = "\n" if line.endswith("\n") else ""
        if (
            stripped.startswith(
                ("persistmind --repo . plan create ", "persistmind --repo . plan create ")
            )
            and " --json " in stripped
        ):
            lines.append(PLAN_CREATE_FILE_SNIPPET + newline)
        elif (
            stripped.startswith(
                ("persistmind --repo . plan amend ", "persistmind --repo . plan amend ")
            )
            and " --json " in stripped
        ):
            lines.append(
                'persistmind --repo . plan amend <plan_id> --reason "<reason>" '
                "--file <updated_plan_json_file>" + newline
            )
        else:
            lines.append(line)
    return "".join(lines)


def agent_contract(
    agent_names: list[str],
    *,
    agent_label: str | None = None,
    self_bootstrap: bool = True,
    invocation: RuntimeInvocation | str | None = None,
) -> str:
    names = ", ".join(agent_names) if agent_names else (agent_label or "coding agents")
    bootstrap = f"\n{self_bootstrap_prompt()}" if self_bootstrap else ""
    contract = f"""# PersistMind Agent Usage Contract
{CONTRACT_MARKER}

This project is guided by PersistMind for AI coding agents: {names}.

Before editing this repository, request a PersistMind context pack:

```powershell
persistmind --repo . task start --task "<task>"
persistmind --repo . pack --task "<task>" --task-session-id <task_session_id>
```

Record the returned `task_session_id`, `pack_id`, and `agent_session_id`. Task
start, pack serving, plans, checkpoints, verification runs, and outcomes are
mirrored into agent session memory automatically. Create a structured task plan
before coding:

```powershell
{PLAN_CREATE_FILE_SNIPPET}
```

{POWERSHELL_PLAN_FILE_GUIDANCE}

{CODEX_MEMORY_PARALLEL_GUIDANCE}

{SKILL_EVOLUTION_GUIDANCE}

{STORAGE_ROUTING_GUIDANCE}

{PERSISTMIND_FIRST_CONTEXT_GUIDANCE}

The plan must include an objective and a `steps` list. Each step must include
`id`, `title`, `intended_files`, `intended_tests`, `capabilities`, and `risk`
(`low`, `medium`, `high`, or `critical`).

During or after edits, checkpoint changed files against the active plan step:

```powershell
persistmind --repo . plan checkpoint <plan_id> --step-id <step_id> --path <changed_path>
```

If a checkpoint fails, amend the plan with a reason or remove the out-of-step
edit before continuing:

```powershell
persistmind --repo . plan amend <plan_id> --reason "<reason>" --file <updated_plan_json_file>
```

{COMPLETION_GUIDANCE}

To inspect the remembered development episode, explain the returned session:

```powershell
persistmind --repo . session explain --session-id <agent_session_id>
```

If any PersistMind check fails, do not declare the task complete. Fix the issue or
report the exact blocker.

For storage or performance blockers, run `persistmind --repo . storage-report`
before guessing at the cause. The Control report identifies the catalog,
physical authorities, migration state, and SQLite runtime qualification.
Do not infer readiness from file size alone; use catalog status and
authority-aware verification evidence.

The audit chain is tamper-evident for accidental edits and partial tampering. It is
not tamper-proof against an actor with full filesystem control who can rewrite the
database and recompute the chain.
{bootstrap}"""
    return ensure_agent_contract_guidance(
        contract,
        self_bootstrap=self_bootstrap,
        invocation=invocation,
    )


def _bind_runtime_contract(
    contract: str,
    invocation: RuntimeInvocation | str | None,
) -> str:
    if invocation is None:
        return contract
    rendered = _as_runtime_invocation(invocation).render_powershell()
    updated = contract.replace("persistmind --repo .", f"{rendered} --repo .")
    managed_prefix = re.compile(
        r"& (?:'(?:''|[^'])+'|\"[^\"\r\n]+\"|\S+) "
        r"'-I' '-m' 'persistmind' --repo \."
    )
    return managed_prefix.sub(lambda _match: f"{rendered} --repo .", updated)


def self_bootstrap_prompt() -> str:
    return """## Agent Self-Bootstrap

When this file is present but your native PersistMind surfaces are missing, run:

```powershell
persistmind --repo . setup auto
```

That command detects the current agent and regenerates the native instruction
file, MCP registration snippets, hooks, subagents, and skills the agent supports.
"""


def codex_mcp_config(command: RuntimeInvocation | str | None = None, mcp_repo: str = ".") -> str:
    invocation = _as_runtime_invocation(command)
    args = [*invocation.prefix_args, "--repo", mcp_repo, "mcp", "--stdio"]
    return f"""# Copy this block into your Codex config when you want this project to use PersistMind.
[mcp_servers.persistmind]
command = {toml_string(invocation.executable)}
args = [{", ".join(toml_string(arg) for arg in args)}]
startup_timeout_sec = {CODEX_MCP_STARTUP_TIMEOUT_SEC:.1f}
"""


def codex_project_config(command: RuntimeInvocation | str | None, mcp_repo: str) -> str:
    invocation = _as_runtime_invocation(command)
    args = [*invocation.prefix_args, "--repo", mcp_repo, "mcp", "--stdio"]
    return f"""# Generated by PersistMind. Project-local Codex config loads only when this repo is trusted.
[features]
hooks = true
multi_agent = true
memories = true

[agents]
max_threads = 4
max_depth = 1

[mcp_servers.persistmind]
command = {toml_string(invocation.executable)}
args = [{", ".join(toml_string(arg) for arg in args)}]
startup_timeout_sec = {CODEX_MCP_STARTUP_TIMEOUT_SEC:.1f}
"""


def codex_hooks_json(
    repo_root: Path | None = None,
    invocation: RuntimeInvocation | str | None = None,
) -> str:
    runtime = _as_runtime_invocation(invocation)
    hook_script_path = (
        repo_root.resolve() / ".persistmind" / "codex" / "hooks" / "persistmind_hook.py"
        if repo_root
        else Path(".persistmind") / "codex" / "hooks" / "persistmind_hook.py"
    )
    hook = " ".join(
        [
            shlex_quote(runtime.executable),
            shlex_quote("-I"),
            shlex_quote("-X"),
            shlex_quote("utf8"),
            shlex_quote(str(hook_script_path)),
        ]
    )
    wrapper_path = (
        repo_root / ".persistmind" / "codex" / "hooks" / "persistmind-hook.ps1"
        if repo_root
        else Path(".persistmind") / "codex" / "hooks" / "persistmind-hook.ps1"
    )
    hook_windows = (
        "powershell -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned "
        f"-File {powershell_string(str(wrapper_path))} "
    )
    payload = {
        "hooks": {
            "SessionStart": [
                {
                    "matcher": "startup|resume|clear|compact",
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} SessionStart",
                            "commandWindows": f"{hook_windows}SessionStart",
                            "timeout": HOOK_COMMAND_TIMEOUT_SECONDS,
                            "statusMessage": "Checking PersistMind setup",
                        }
                    ],
                }
            ],
            "UserPromptSubmit": [
                {
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} UserPromptSubmit",
                            "commandWindows": f"{hook_windows}UserPromptSubmit",
                            "timeout": HOOK_COMMAND_TIMEOUT_SECONDS,
                            "statusMessage": "Preparing PersistMind preflight",
                        }
                    ]
                }
            ],
            "PreToolUse": [
                {
                    "matcher": (
                        "Bash|Shell|shell_command|Read|Glob|Grep|Search|Find|List|LS|"
                        "Task|Agent|NotebookEdit|WebFetch|SlashCommand|apply_patch|Edit|Write|mcp__.*"
                    ),
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} PreToolUse",
                            "commandWindows": f"{hook_windows}PreToolUse",
                            "timeout": HOOK_COMMAND_TIMEOUT_SECONDS,
                            "statusMessage": "Checking PersistMind tool gate",
                        }
                    ],
                }
            ],
            "PostToolUse": [
                {
                    "matcher": (
                        "Bash|Shell|shell_command|Read|Glob|Grep|Search|Find|List|LS|"
                        "Task|Agent|NotebookEdit|WebFetch|SlashCommand|apply_patch|Edit|Write|mcp__.*"
                    ),
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} PostToolUse",
                            "commandWindows": f"{hook_windows}PostToolUse",
                            "timeout": HOOK_COMMAND_TIMEOUT_SECONDS,
                            "statusMessage": "Recording PersistMind tool evidence",
                        }
                    ],
                }
            ],
            "SubagentStart": [
                {
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} SubagentStart",
                            "commandWindows": f"{hook_windows}SubagentStart",
                            "timeout": HOOK_COMMAND_TIMEOUT_SECONDS,
                            "statusMessage": "Registering PersistMind child session",
                        }
                    ]
                }
            ],
            "SubagentStop": [
                {
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} SubagentStop",
                            "commandWindows": f"{hook_windows}SubagentStop",
                            "timeout": HOOK_COMMAND_TIMEOUT_SECONDS,
                            "statusMessage": "Recording PersistMind child summary",
                        }
                    ]
                }
            ],
            "Stop": [
                {
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} Stop",
                            "commandWindows": f"{hook_windows}Stop",
                            "timeout": HOOK_COMMAND_TIMEOUT_SECONDS,
                            "statusMessage": "Recording PersistMind continuation state",
                        }
                    ]
                }
            ],
        }
    }
    return json.dumps(payload, indent=2, sort_keys=True) + "\n"


def codex_hook_wrapper_ps1(
    invocation: RuntimeInvocation | str | None = None,
) -> str:
    runtime = _as_runtime_invocation(invocation)
    command = powershell_string(runtime.executable)
    return f"""param(
    [Parameter(Mandatory = $true)]
    [string]$Event
)

$ErrorActionPreference = "Stop"

$utf8 = [System.Text.UTF8Encoding]::new($false)
[Console]::InputEncoding = $utf8
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8
$env:PYTHONIOENCODING = "utf-8"
$env:PYTHONUTF8 = "1"

$payload = [Console]::In.ReadToEnd()
$repo = [string](Resolve-Path -LiteralPath (Join-Path $PSScriptRoot "..\\..\\.."))
$env:PERSISTMIND_REPO = $repo
$hook = Join-Path $repo '.persistmind\\codex\\hooks\\persistmind_hook.py'
if (-not (Test-Path -LiteralPath $hook -PathType Leaf)) {{
    throw "PersistMind hook script is missing: $hook"
}}

$payload | & {command} '-I' '-X' 'utf8' $hook $Event
exit $LASTEXITCODE
"""


def codex_agent_toml(spec: SubagentSpec) -> str:
    mode = f'sandbox_mode = "{spec.mode}"\n' if spec.mode else ""
    return f"""name = "{spec.name}"
description = "{spec.description}"
{mode}developer_instructions = \"\"\"
{spec.instructions}
\"\"\"
"""


def claude_agent_markdown(spec: SubagentSpec) -> str:
    tools = "Read, Grep, Glob" if spec.mode == "read-only" else "Read, Grep, Glob, Edit, Bash"
    return f"""---
name: {spec.name}
description: {spec.description}
tools: {tools}
---

{spec.instructions}
"""


def hook_script() -> str:
    return """from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


def main() -> int:
    event = sys.argv[1] if len(sys.argv) > 1 else "unknown"
    repo = _repo_root()
    agent = _hook_agent()
    payload = _read_stdin_json()
    result = _persistmind_event(repo, event, payload)
    payload_object = payload if isinstance(payload, dict) else {}
    is_self_test = isinstance(payload, dict) and bool(
        payload.get("_persistmind_hook_self_test")
    )
    if repo and not is_self_test:
        try:
            _append_hook_event(repo, agent, event, payload, result)
        except Exception as exc:
            # Audit persistence is best effort. It must not invalidate a policy
            # decision that Codex can still enforce from stdout.
            print(
                "persistmind-hook: audit write failed: " + type(exc).__name__,
                file=sys.stderr,
            )
        try:
            from persistmind.reporting.automatic import maybe_capture_hook_failure

            maybe_capture_hook_failure(
                repo,
                result,
                event=event,
                host_event_id=str(payload_object.get("hook_event_id") or "") or None,
            )
        except Exception:
            # Reporting is best effort and never changes the hook decision.
            pass
    output = (
        _codex_hook_output(result)
        if agent == "codex"
        else _gemini_hook_output(result)
        if agent == "gemini"
        else _claude_hook_output(result)
    )
    print(json.dumps(output, ensure_ascii=False, sort_keys=True))
    # Codex treats an exit-0 structured deny as an enforced block. Exit 1 is a
    # failed hook and fails open; exit 2 requires the reason on stderr instead.
    return 0


def _codex_hook_output(result: dict) -> dict:
    event = str(result.get("event") or "")
    if event == "PreToolUse":
        if result.get("decision") == "block":
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "deny",
                    "permissionDecisionReason": _bounded_text(
                        result.get("reason")
                        or "PersistMind hook blocked this tool call",
                        2000,
                    ),
                }
            }
        if result.get("decision") == "warn":
            context = _additional_context(result)
            if context:
                return {
                    "hookSpecificOutput": {
                        "hookEventName": "PreToolUse",
                        "additionalContext": context,
                    }
                }
        return {}

    if event in {"SessionStart", "UserPromptSubmit", "SubagentStart"}:
        context = _additional_context(result)
        if context:
            return {
                "hookSpecificOutput": {
                    "hookEventName": event,
                    "additionalContext": context,
                }
            }
        return {}

    if event == "PostToolUse" and result.get("decision") in {"block", "warn"}:
        return {
            "hookSpecificOutput": {
                "hookEventName": "PostToolUse",
                "additionalContext": _additional_context(result),
            }
        }
    return {}


def _claude_hook_output(result: dict) -> dict:
    event = str(result.get("event") or "")
    if event == "PreToolUse" and result.get("decision") == "block":
        return {
            "decision": "block",
            "reason": _bounded_text(
                result.get("reason") or "PersistMind hook blocked this tool call",
                2000,
            ),
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": _bounded_text(
                    result.get("reason") or "PersistMind hook blocked this tool call",
                    2000,
                ),
            },
        }
    if event in {"SessionStart", "UserPromptSubmit", "SubagentStart", "PostToolUse"}:
        context = _additional_context(result)
        if context:
            return {
                "hookSpecificOutput": {
                    "hookEventName": event,
                    "additionalContext": context,
                }
            }
    return {}


def _gemini_hook_output(result: dict) -> dict:
    event = str(result.get("event") or "")
    if event == "BeforeTool":
        if result.get("decision") == "block":
            return {
                "decision": "deny",
                "reason": _bounded_text(
                    result.get("reason") or "PersistMind hook blocked this tool call",
                    2000,
                ),
            }
        return {"decision": "allow"}
    if event in {"SessionStart", "BeforeAgent"}:
        context = _additional_context(result)
        if context:
            return {
                "hookSpecificOutput": {
                    "hookEventName": event,
                    "additionalContext": context,
                }
            }
    return {}


def _bounded_text(value: object, limit: int) -> str:
    text = str(value or "").strip()
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 20)] + " ... [truncated]"


def _additional_context(result: dict) -> str:
    lines: list[str] = []
    explicit = result.get("additional_context")
    if explicit:
        lines.append(_bounded_text(explicit, 2000))
    if result.get("banner"):
        lines.append(_bounded_text(result["banner"], 1000))
    if result.get("reason") and result.get("decision") in {"warn", "block"}:
        lines.append("PersistMind hook: " + _bounded_text(result["reason"], 1000))
    workflow = result.get("workflow_next_action")
    if isinstance(workflow, dict):
        if workflow.get("command"):
            lines.append("PersistMind next: " + _bounded_text(workflow["command"], 1200))
        if workflow.get("why"):
            lines.append("Why: " + _bounded_text(workflow["why"], 600))
    plan = result.get("parallel_agent_plan")
    if isinstance(plan, dict) and plan.get("recommendation"):
        suffix = (
            " - " + _bounded_text(plan.get("reason"), 600)
            if plan.get("reason")
            else ""
        )
        lines.append(
            "PersistMind parallel recommendation: "
            + _bounded_text(plan.get("recommendation"), 80)
            + suffix
        )
    intuition = result.get("intuition")
    if isinstance(intuition, dict) and intuition.get("message"):
        lines.append(_bounded_text(intuition["message"], 1000))
    runtime_error = result.get("runtime_error")
    if isinstance(runtime_error, dict) and runtime_error.get("status"):
        message = "PersistMind runtime degraded: " + _bounded_text(
            runtime_error.get("status"), 120
        )
        if runtime_error.get("error_type"):
            message += " (" + _bounded_text(runtime_error.get("error_type"), 120) + ")"
        lines.append(message)
    learning_signal = result.get("learning_signal")
    if isinstance(learning_signal, dict) and learning_signal.get("ok") is False:
        message = "PersistMind learning capture failed: " + _bounded_text(
            learning_signal.get("status"), 120
        )
        if learning_signal.get("error_type"):
            message += " (" + _bounded_text(learning_signal.get("error_type"), 120) + ")"
        lines.append(message)
    return _bounded_text("\\n".join(line for line in lines if line), 4000)


def _json_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    ).encode("utf-8")


def _digest(value: object) -> dict:
    raw = _json_bytes(value)
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def _audit_payload(payload: object) -> dict:
    if not isinstance(payload, dict):
        return {"type": type(payload).__name__, **_digest(payload)}
    audit: dict = {
        key: payload[key]
        for key in (
            "session_id",
            "turn_id",
            "hook_event_name",
            "cwd",
            "model",
            "permission_mode",
            "tool_name",
            "tool_use_id",
            "agent_id",
            "agent_type",
            "source",
            "trigger",
            "stop_hook_active",
        )
        if key in payload
        and isinstance(payload[key], (str, int, float, bool, type(None)))
    }
    audit["payload"] = _digest(payload)
    for key in ("prompt", "last_assistant_message", "tool_response"):
        if key in payload:
            audit[key] = _digest(payload[key])
    tool_input = payload.get("tool_input")
    if tool_input is not None:
        summary = _digest(tool_input)
        summary["type"] = type(tool_input).__name__
        if isinstance(tool_input, dict):
            summary["keys"] = sorted(str(key) for key in tool_input)[:40]
            safe_paths = {}
            for key in (
                "path",
                "file_path",
                "filepath",
                "target_path",
                "target_paths",
            ):
                if key in tool_input:
                    safe_paths[key] = tool_input[key]
            if safe_paths:
                summary["paths"] = safe_paths
        audit["tool_input"] = summary
    return audit


def _audit_result(result: object) -> dict:
    if not isinstance(result, dict):
        return {"type": type(result).__name__, **_digest(result)}
    audit = {
        key: result[key]
        for key in (
            "ok",
            "event",
            "decision",
            "reason",
            "mode",
            "record_only",
            "enforcement_mode",
            "would_have_blocked",
            "status",
        )
        if key in result
        and isinstance(result[key], (str, int, float, bool, type(None)))
    }
    for key in ("preflight_state", "binding", "role_scope", "context_health"):
        value = result.get(key)
        if isinstance(value, dict):
            audit[key] = {
                inner: value[inner]
                for inner in (
                    "source",
                    "session_id",
                    "task_session_id",
                    "pack_id",
                    "plan_id",
                    "preflight_ready",
                    "active_plan_step",
                    "status",
                    "reason",
                )
                if inner in value
                and isinstance(value[inner], (str, int, float, bool, type(None)))
            }
    audit["result"] = _digest(result)
    return audit


def _hook_task_session_id(payload: dict, result: dict) -> str | None:
    for source in (payload, result):
        value = source.get("task_session_id")
        if value:
            return str(value)
    for key in ("preflight_state", "binding", "role_scope", "context_health"):
        value = result.get(key)
        if isinstance(value, dict) and value.get("task_session_id"):
            return str(value["task_session_id"])
    return None


def _append_hook_event(
    repo: Path, agent: str, event: str, payload: object, result: dict
) -> None:
    log_dir = repo / ".persistmind" / agent
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / "hook-events.jsonl"
    record = {
        "event": event,
        "fired_at": datetime.now(timezone.utc).isoformat(),
        "payload": _audit_payload(payload),
        "result": _audit_result(result),
        "schema_version": "persistmind.codex_hook_audit.v2",
    }
    try:
        from persistmind.storage.audit_service import AuditService
        from persistmind.utils import stable_id

        body = payload if isinstance(payload, dict) else {}
        task_session_id = _hook_task_session_id(body, result)
        record_id = "engine_evidence_" + stable_id(
            "hook-event",
            agent,
            event,
            str(body.get("hook_event_id") or ""),
            record["fired_at"],
        )[:32]
        with AuditService(repo) as audit:
            audit.record_engine_evidence(
                record_id=record_id,
                kind="hook_event",
                task_session_id=task_session_id,
                payload=record,
                idempotency_key=(
                    f"hook-event:{agent}:{body.get('hook_event_id')}"
                    if body.get("hook_event_id")
                    else None
                ),
            )
    except Exception:
        # JSONL remains the compatibility/debug path; hook execution must not fail
        # solely because the tamper-evident evidence sink is unavailable.
        pass
    encoded = _json_bytes(record) + b"\\n"
    descriptor = os.open(
        log_path,
        os.O_APPEND | os.O_CREAT | os.O_WRONLY | getattr(os, "O_BINARY", 0),
        0o600,
    )
    try:
        os.write(descriptor, encoded)
    finally:
        os.close(descriptor)


def _daemon_result(event: str, body: dict) -> dict | None:
    base_url = os.environ.get("PERSISTMIND_DAEMON")
    if not base_url:
        return None
    import urllib.parse
    import urllib.request

    parsed_url = urllib.parse.urlparse(base_url)
    loopback = (parsed_url.hostname or "").lower() in {
        "127.0.0.1",
        "::1",
        "localhost",
    }
    token = os.environ.get("PERSISTMIND_TOKEN")
    if parsed_url.scheme not in {"http", "https"}:
        return None
    if parsed_url.scheme != "https" and not loopback:
        return None
    if not loopback and not token:
        return None
    data = json.dumps({"event": event, "payload": body}).encode("utf-8")
    if len(data) > 1024 * 1024:
        return None
    request = urllib.request.Request(
        base_url.rstrip("/") + "/v1/codex/hook-event",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    if token:
        request.add_header("Authorization", "Bearer " + token)
    try:
        with urllib.request.urlopen(request, timeout=3) as response:
            final_url = urllib.parse.urlparse(response.geturl())
            final_loopback = (final_url.hostname or "").lower() in {
                "127.0.0.1",
                "::1",
                "localhost",
            }
            if final_url.scheme != "https" and not final_loopback:
                return None
            raw = response.read(64 * 1024 + 1)
            if len(raw) > 64 * 1024:
                return None
            parsed = json.loads(raw.decode("utf-8"))
            if not isinstance(parsed, dict):
                return None
            allowed = {
                "ok",
                "decision",
                "reason",
                "additional_context",
                "record_only",
                "enforcement_mode",
                "would_have_blocked",
                "preflight_state",
                "workflow_next_action",
                "context_health",
            }
            return {key: value for key, value in parsed.items() if key in allowed}
    except Exception:  # noqa: BLE001 - fall back to the in-process service.
        return None


def _persistmind_event(repo: Path | None, event: str, payload: object) -> dict:
    runtime_error = None
    if repo:
        try:
            from persistmind.agent_runtime.events import handle_host_hook_event

            return handle_host_hook_event(repo, event, payload)
        except Exception as exc:
            # Preserve the self-contained compatibility path for an older or
            # partially upgraded runtime. PreToolUse still fails closed below.
            runtime_error = {
                "status": "persistmind_runtime_unavailable",
                "error_type": type(exc).__name__,
                "error": _bounded_text(str(exc), 500),
            }
    base = {
        "ok": True,
        "event": event,
        "repo": str(repo) if repo else None,
        "persistmind_available": shutil.which("persistmind") is not None,
        "mode": "enforcing" if event in {"PreToolUse", "BeforeTool"} else "audit",
    }
    if runtime_error is not None:
        base["runtime_error"] = runtime_error
    if not repo:
        return {
            **base,
            "ok": event not in {"PreToolUse", "BeforeTool"},
            "decision": "block",
            "reason": "no git repo root",
        }
    body = payload if isinstance(payload, dict) else {"payload": payload}
    if event == "SessionStart":
        try:
            from persistmind.agent_runtime.activation import record_host_attachment
            from persistmind.agent_runtime.hooks import record_hook_heartbeat

            base["host_activation"] = record_host_attachment(repo, body)
            base["hook_coverage"] = record_hook_heartbeat(
                repo,
                agent=agent,
                session_id=str(body.get("session_id") or body.get("transcript_path") or ""),
                host_pid=os.getppid(),
            )
        except Exception as exc:  # activation evidence is diagnostic, never a hook blocker.
            base["host_activation"] = {
                "status": "attachment_record_failed",
                "error": _bounded_text(str(exc), 1000),
            }
    if body.get("_persistmind_hook_self_test"):
        return {
            **base,
            "ok": False,
            "decision": "block",
            "reason": "PersistMind hook self-test block",
        }
    if body.get("_persistmind_invalid_json") and event in {"PreToolUse", "BeforeTool"}:
        return {
            **base,
            "ok": False,
            "decision": "block",
            "reason": "Codex hook input was not valid JSON",
        }
    try:
        from persistmind.agent_runtime.hooks import evaluate_fast_hook

        fast = evaluate_fast_hook(repo, event, body)
        if event in {"PreToolUse", "BeforeTool"}:
            return {**base, **fast}
        # Non-gating events use the durable fast journal but retain the
        # established host-specific response envelope below.
    except Exception:
        # Older engines and pre-v2 workspaces retain the established hook path.
        pass
    if event in {"SessionStart", "UserPromptSubmit", "BeforeAgent"}:
        _invalidate_context_authorization(repo, event, body)
    daemon = _daemon_result(event, body)
    if daemon is not None:
        return {**base, **daemon}
    if event in {"SessionStart", "UserPromptSubmit", "BeforeAgent"}:
        return {
            **base,
            "record_only": True,
            "additional_context": (
                "PersistMind-first context is mandatory. Context authorization was "
                "refreshed for this session or prompt. Before repository discovery, "
                "run persistmind --repo . codex preflight --task <current-user-task> "
                "--mode read (or --mode write for edits), then use PersistMind search, "
                "impact, or pack results. Unscoped repo discovery is hook-blocked, and "
                "preflight does not lift that scan gate. Scoped recursive search on a "
                "relevant path is allowed."
            ),
        }
    if event in {"PreToolUse", "BeforeTool"}:
        service_error = None
        try:
            from persistmind.composition.registry import OperationClient

            with OperationClient(repo) as service:
                return {**base, **service.codex_hook_event(event, body)}
        except Exception as exc:
            service_error = str(exc)
        try:
            from persistmind.codex import infer_hook_read_only, pre_tool_gate
            from persistmind.config import load_settings

            settings = load_settings(repo)
            gate = pre_tool_gate(
                tool_name=str(body.get("tool_name") or body.get("tool") or ""),
                preflight_ready=bool(body.get("preflight_ready")),
                active_plan_step=bool(body.get("active_plan_step")),
                read_only=infer_hook_read_only(body),
                enforcement_mode=settings.governance.enforcement_mode,
            )
            return {
                **base,
                **gate,
                "hook_runtime_degraded": {
                    "reason": "service_error",
                    "error": _bounded_text(service_error, 1000),
                },
            }
        except Exception as exc:  # noqa: BLE001 - fail closed for the write gate.
            return {**base, "ok": False, "decision": "block", "reason": str(exc)}
    try:
        from persistmind.composition.registry import OperationClient

        with OperationClient(repo) as service:
            return {**base, **service.codex_hook_event(event, body)}
    except Exception as exc:  # noqa: BLE001
        return {**base, "ok": False, "reason": str(exc)}


def _invalidate_context_authorization(repo: Path, event: str, body: dict) -> None:
    try:
        from persistmind.agent_runtime.hooks import write_policy_snapshot

        material = "\\0".join(
            (
                event,
                str(body.get("session_id") or ""),
                str(body.get("hook_event_id") or ""),
                datetime.now(timezone.utc).isoformat(),
            )
        )
        write_policy_snapshot(
            repo,
            revision=hashlib.sha256(material.encode("utf-8")).hexdigest(),
            preflight_ready=False,
            authorization_mode="none",
        )
    except Exception:
        # Broad scans remain denied independently. A stale ready snapshot must
        # never weaken that repository-enumeration boundary.
        return


def _hook_agent() -> str:
    if len(sys.argv) > 2 and sys.argv[2].casefold() in {
        "codex",
        "claude",
        "gemini",
        "grok",
    }:
        return sys.argv[2].casefold()
    try:
        agent = Path(__file__).resolve().parents[1].name.lower()
    except (IndexError, OSError):
        agent = "codex"
    return agent if agent in {"codex", "claude", "gemini", "grok"} else "codex"


def _repo_root() -> Path | None:
    try:
        script_repo = Path(__file__).resolve().parents[3]
        if script_repo.exists():
            return script_repo
    except (IndexError, OSError):
        pass
    env_repo = _repo_from_env()
    if env_repo:
        return env_repo
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=5,
        )
    except (FileNotFoundError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    return Path(result.stdout.strip())


def _repo_from_env() -> Path | None:
    for name in (
        "PERSISTMIND_REPO",
        "CODEX_PROJECT_DIR",
        "CODEX_WORKSPACE_ROOT",
        "GEMINI_PROJECT_DIR",
    ):
        value = os.environ.get(name)
        if not value:
            continue
        candidate = Path(value)
        if candidate.exists():
            return candidate
    return None


def _read_stdin_json() -> object:
    raw = sys.stdin.read()
    # Windows PowerShell and a few command runners may prefix redirected UTF-8
    # stdin with a BOM. json.loads rejects that marker when it is already a
    # decoded string, so remove exactly one transport marker before parsing.
    if raw.startswith("\ufeff"):
        raw = raw[1:]
    if not raw.strip():
        return {}
    try:
        return _repair_powershell_surrogates(json.loads(raw))
    except json.JSONDecodeError:
        encoded = raw.encode("utf-8", errors="replace")
        return {
            "_persistmind_invalid_json": True,
            "raw_bytes": len(encoded),
            "raw_sha256": hashlib.sha256(encoded).hexdigest(),
        }


def _repair_powershell_surrogates(value: object) -> object:
    # Windows PowerShell 5 can transcode astral UTF-8 characters into a pair
    # of surrogate code units before Python sees stdin. Recombine valid pairs
    # so hashes and audit bytes remain equivalent across the native wrappers.
    if isinstance(value, str):
        try:
            return value.encode("utf-16", "surrogatepass").decode("utf-16")
        except UnicodeDecodeError:
            return value.encode("utf-16", "surrogatepass").decode(
                "utf-16", "replace"
            )
    if isinstance(value, list):
        return [_repair_powershell_surrogates(item) for item in value]
    if isinstance(value, dict):
        return {
            _repair_powershell_surrogates(key): _repair_powershell_surrogates(item)
            for key, item in value.items()
        }
    return value


if __name__ == "__main__":
    raise SystemExit(main())
"""


def claude_settings_json(
    repo_root: Path | None = None,
    invocation: RuntimeInvocation | str | None = None,
) -> str:
    runtime = _as_runtime_invocation(invocation)
    hook_path = (
        repo_root.resolve() / ".persistmind" / "claude" / "hooks" / "persistmind_hook.py"
        if repo_root
        else Path(".persistmind") / "claude" / "hooks" / "persistmind_hook.py"
    )
    command = " ".join(
        [
            shlex_quote(runtime.executable),
            shlex_quote("-I"),
            shlex_quote("-X"),
            shlex_quote("utf8"),
            shlex_quote(str(hook_path)),
        ]
    )
    tool_matcher = (
        "Bash|Shell|shell_command|Read|Glob|Grep|Search|Find|List|LS|Task|Agent|"
        "NotebookEdit|WebFetch|SlashCommand|apply_patch|Edit|Write|mcp__.*"
    )
    payload = {
        "hooks": {
            event: [
                {
                    **({"matcher": tool_matcher} if event in {"PreToolUse", "PostToolUse"} else {}),
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{command} {event}",
                            "timeout": HOOK_COMMAND_TIMEOUT_SECONDS,
                        }
                    ],
                }
            ]
            for event in HOOK_EVENTS
        }
    }
    return json.dumps(payload, indent=2, sort_keys=True) + "\n"


def claude_skill(command: RuntimeInvocation | str | None, mcp_repo: str) -> str:
    invocation = _as_runtime_invocation(command)
    rendered = invocation.render_powershell()
    return f"""---
name: ctx-loop
description: Use PersistMind for pack, plan, checkpoint, impact, and outcome workflows.
---

# PersistMind Loop

Before editing, run `{rendered} --repo . task start --task "<task>"` and
`{rendered} --repo . pack --task "<task>" --task-session-id <task_session_id>`.
Create a plan, checkpoint changed files, run check-diff, impact, and tests,
transition the task to OUTCOME, then record the outcome. The MCP server for this
project is `{rendered} --repo "{mcp_repo}" mcp --stdio`.
"""


def claude_mcp_json(command: RuntimeInvocation | str | None, mcp_repo: str) -> str:
    invocation = _as_runtime_invocation(command)
    return (
        json.dumps(
            {
                "mcpServers": {
                    "persistmind": {
                        "command": invocation.executable,
                        "args": [
                            *invocation.prefix_args,
                            "--repo",
                            mcp_repo,
                            "mcp",
                            "--stdio",
                        ],
                    }
                }
            },
            indent=2,
            sort_keys=True,
        )
        + "\n"
    )


def cursor_mcp_json(command: RuntimeInvocation | str | None, mcp_repo: str) -> str:
    return claude_mcp_json(command, mcp_repo)


def cursor_rule(
    agent_names: list[str],
    command: RuntimeInvocation | str | None,
    mcp_repo: str,
) -> str:
    invocation = _as_runtime_invocation(command)
    rendered = invocation.render_powershell()
    return (
        "---\n"
        "alwaysApply: true\n"
        "---\n\n"
        + agent_contract(
            agent_names,
            agent_label="Cursor",
            self_bootstrap=True,
            invocation=invocation,
        )
        + "\n## Cursor Enforcement Note\n\n"
        "Cursor does not provide PersistMind lifecycle hooks, subagents, or skills. "
        "Use the MCP server and this rule for the PersistMind workflow; PreToolUse "
        "write-gate enforcement is degraded to instruction-level enforcement.\n\n"
        "MCP command:\n\n"
        "```powershell\n"
        f'{rendered} --repo "{mcp_repo}" mcp --stdio\n'
        "```\n"
    )


def claude_command(command: RuntimeInvocation | str | None, mcp_repo: str) -> str:
    invocation = _as_runtime_invocation(command)
    rendered = invocation.render_powershell("--repo", mcp_repo, "mcp", "--stdio")
    return f"""# Run from this project root to register PersistMind with Claude Code.
claude mcp add persistmind -- {rendered}
"""


def mcp_readme(command: RuntimeInvocation | str | None, mcp_repo: str) -> str:
    invocation = _as_runtime_invocation(command)
    rendered = invocation.render_powershell("--repo", mcp_repo, "mcp", "--stdio")
    return f"""# PersistMind MCP Setup

This folder contains local setup snippets generated by `persistmind bootstrap`.

## Codex

Copy `.persistmind/mcp/codex.config.toml` into the relevant Codex config file.

## Claude Code

Run:

```powershell
claude mcp add persistmind -- {rendered}
```

## Gemini CLI

Review `.gemini/settings.json`, which contains the project MCP server and hooks,
or configure an equivalent MCP server entry:

```json
{{
  "mcpServers": {{
    "persistmind": {{
      "command": {json.dumps(invocation.executable)},
      "args": {json.dumps([*invocation.prefix_args, "--repo", mcp_repo, "mcp", "--stdio"])}
    }}
  }}
}}
```

## Grok Build

Review `.grok/config.toml` and the owned `.grok/plugins/persistmind` plugin.

## Direct MCP Smoke Test

```powershell
{rendered}
```
"""


def _as_runtime_invocation(
    value: RuntimeInvocation | str | None,
) -> RuntimeInvocation:
    if isinstance(value, RuntimeInvocation):
        return value.require_managed()
    if value is None or value.strip() in {"persistmind"}:
        return runtime_invocation()
    command = value.strip()
    if command != value or any(char.isspace() for char in command):
        raise ValueError("legacy MCP command strings cannot combine an executable and arguments")
    path = Path(command).expanduser()
    if not path.is_absolute():
        raise ValueError(
            "managed MCP command must be a structured invocation with an absolute executable"
        )
    return runtime_invocation(executable=str(path), prefix_args=("-I", "-m", "persistmind"))


def toml_string(value: str) -> str:
    return json.dumps(value)


def powershell_string(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def capabilities_yaml() -> str:
    return """schema_version: persistmind.capabilities.v1
require_task_session: false
missing_session_mode: warn
governance:
  governed_classes:
    production_deploy:
      required_verifications:
        - verify-production-assets
capabilities:
  edit_source:
    mode: free
  edit_tests:
    mode: free
  add_dependency:
    mode: warn
    paths: [package.json, package-lock.json, pnpm-lock.yaml, yarn.lock, pyproject.toml, requirements*.txt]
  modify_migration:
    mode: warn
    paths: [migrations/**, **/migrations/**]
  delete_file:
    mode: warn
  edit_critical_path:
    mode: warn
    paths: [src/auth/**, src/billing/**, src/payments/**, migrations/**]
  modify_ci_config:
    mode: warn
    paths: [.github/**, .gitlab-ci.yml, persistmind.toml, persistmind.capabilities.yaml]
  touch_env_secrets:
    mode: forbidden
    paths: [.env, .env.*, **/.env, **/.env.*, **/*.pem, **/*.key]
  run_destructive_command:
    mode: forbidden
"""


def production_asset_verifier() -> str:
    return """#!/usr/bin/env node
import { existsSync, readdirSync } from "node:fs";
import { join } from "node:path";

const roots = [
  ".next/standalone/.next/static",
  ".next/standalone/public",
  ".next/static",
  "public",
];

const present = roots.filter((root) => existsSync(root));
const hasFiles = present.some((root) => {
  try {
    return readdirSync(root, { recursive: true }).some((entry) => String(entry).trim());
  } catch {
    return false;
  }
});

if (!hasFiles) {
  console.error(
    "Production asset verification failed: static assets were not found in standalone/public output."
  );
  console.error(
    "Copy .next/static into .next/standalone/.next/static and public into .next/standalone/public before deploy."
  );
  process.exit(1);
}

console.log(`Production assets verified from ${present.map((root) => join(root)).join(", ")}`);
"""
