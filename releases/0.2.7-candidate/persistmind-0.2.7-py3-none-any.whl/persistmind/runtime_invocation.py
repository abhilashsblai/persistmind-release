from __future__ import annotations

import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

RUNTIME_INVOCATION_SCHEMA = "persistmind.runtime_invocation.v1"
RUNTIME_PROBE_SCHEMA = "persistmind.runtime_probe.v1"
CANONICAL_PREFIX_ARGS = ("-I", "-m", "persistmind")
_SOURCE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")


@dataclass(frozen=True)
class RuntimeProbe:
    ok: bool
    executable: str
    argv_sha256: str
    returncode: int | None = None
    version_output: str | None = None
    error: str | None = None
    schema_version: str = RUNTIME_PROBE_SCHEMA

    def to_dict(self) -> dict[str, Any]:
        value: dict[str, Any] = {
            "schema_version": self.schema_version,
            "ok": self.ok,
            "executable": self.executable,
            "argv_sha256": self.argv_sha256,
            "returncode": self.returncode,
        }
        if self.version_output is not None:
            value["version_output"] = self.version_output
        if self.error is not None:
            value["error"] = self.error
        return value


@dataclass(frozen=True)
class RuntimeInvocation:
    """A shell-independent description of the PersistMind runtime.

    Managed surfaces intentionally store the executable and its fixed prefix as
    separate values.  This prevents a path containing spaces from being treated
    as a shell command and lets MCP clients consume the invocation as argv.
    """

    executable: str
    prefix_args: tuple[str, ...]
    source: str
    version: int = 1

    def __post_init__(self) -> None:
        executable = _validated_text(self.executable, field="executable")
        path = Path(executable).expanduser()
        if not path.is_absolute():
            raise ValueError("runtime executable must be an absolute path")
        prefix_args = tuple(
            _validated_text(str(value), field="prefix_args") for value in self.prefix_args
        )
        source = _validated_text(self.source, field="source")
        if not _SOURCE_RE.fullmatch(source):
            raise ValueError("runtime invocation source is invalid")
        if self.version != 1:
            raise ValueError(f"unsupported runtime invocation version: {self.version}")
        object.__setattr__(self, "executable", str(path.resolve(strict=False)))
        object.__setattr__(self, "prefix_args", prefix_args)
        object.__setattr__(self, "source", source)

    @classmethod
    def managed(
        cls,
        executable: str | os.PathLike[str] | None = None,
        *,
        source: str | None = None,
    ) -> RuntimeInvocation:
        selected, selected_source = _managed_python(executable)
        return cls(
            executable=str(selected),
            prefix_args=CANONICAL_PREFIX_ARGS,
            source=source or selected_source,
        )

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> RuntimeInvocation:
        if value.get("schema_version") != RUNTIME_INVOCATION_SCHEMA:
            raise ValueError("unsupported runtime invocation schema")
        allowed = {"schema_version", "executable", "prefix_args", "source"}
        extra = set(value) - allowed
        if extra:
            raise ValueError("unknown runtime invocation fields: " + ", ".join(sorted(extra)))
        prefix = value.get("prefix_args")
        if not isinstance(prefix, list) or not all(isinstance(item, str) for item in prefix):
            raise ValueError("runtime prefix_args must be a string array")
        executable = value.get("executable")
        source = value.get("source")
        if not isinstance(executable, str) or not isinstance(source, str):
            raise ValueError("runtime executable and source must be strings")
        return cls(executable, tuple(prefix), source)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": RUNTIME_INVOCATION_SCHEMA,
            "executable": self.executable,
            "prefix_args": list(self.prefix_args),
            "source": self.source,
        }

    @property
    def invocation_sha256(self) -> str:
        encoded = json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()

    @property
    def is_managed(self) -> bool:
        return self.prefix_args == CANONICAL_PREFIX_ARGS

    def require_managed(self) -> RuntimeInvocation:
        if not self.is_managed:
            raise ValueError("managed PersistMind invocation must use -I -m persistmind")
        return self

    def argv(self, *args: str) -> list[str]:
        suffix = [_validated_text(str(arg), field="argv") for arg in args]
        return [self.executable, *self.prefix_args, *suffix]

    def match_argv(self, argv: Sequence[str]) -> tuple[str, ...]:
        """Return command-specific argv after an exact invocation match."""

        values = tuple(str(value) for value in argv)
        prefix_length = 1 + len(self.prefix_args)
        if len(values) < prefix_length:
            raise ValueError("runtime_argv_too_short")
        candidate = Path(values[0]).expanduser()
        if not candidate.is_absolute():
            raise ValueError("runtime_executable_not_absolute")
        expected_path = str(Path(self.executable).resolve(strict=False))
        candidate_path = str(candidate.resolve(strict=False))
        if os.name == "nt":
            matches = os.path.normcase(candidate_path) == os.path.normcase(expected_path)
        else:
            matches = candidate_path == expected_path
        if not matches:
            raise ValueError("runtime_executable_mismatch")
        if values[1:prefix_length] != self.prefix_args:
            raise ValueError("runtime_prefix_mismatch")
        return values[prefix_length:]

    def mcp_config(self, *, repo: Path) -> tuple[str, list[str]]:
        return self.executable, [
            *self.prefix_args,
            "--repo",
            str(repo),
            "mcp",
            "--stdio",
        ]

    def render_posix(self, *args: str) -> str:
        return " ".join(shlex.quote(item) for item in self.argv(*args))

    def render_powershell(self, *args: str) -> str:
        return "& " + " ".join(_powershell_quote(item) for item in self.argv(*args))

    def validate(self, *, repo: Path, timeout: float = 15.0) -> RuntimeProbe:
        argv = self.argv("--version")
        argv_hash = _argv_sha256(argv)
        executable = Path(self.executable)
        if not executable.is_file():
            return RuntimeProbe(
                ok=False,
                executable=self.executable,
                argv_sha256=argv_hash,
                error="runtime_executable_missing",
            )
        if not self.is_managed:
            return RuntimeProbe(
                ok=False,
                executable=self.executable,
                argv_sha256=argv_hash,
                error="runtime_prefix_not_managed",
            )
        try:
            completed = subprocess.run(
                argv,
                cwd=repo,
                env={
                    **os.environ,
                    "PYTHONIOENCODING": "utf-8",
                    "PYTHONUTF8": "1",
                },
                text=True,
                encoding="utf-8",
                errors="replace",
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=timeout,
                check=False,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            return RuntimeProbe(
                ok=False,
                executable=self.executable,
                argv_sha256=argv_hash,
                error=f"runtime_probe_error:{type(exc).__name__}",
            )
        version_output = (completed.stdout or completed.stderr).strip()[:512]
        return RuntimeProbe(
            ok=completed.returncode == 0 and version_output.casefold().startswith("persistmind "),
            executable=self.executable,
            argv_sha256=argv_hash,
            returncode=completed.returncode,
            version_output=version_output,
            error=(
                None
                if completed.returncode == 0
                and version_output.casefold().startswith("persistmind ")
                else "runtime_identity_probe_failed"
            ),
        )


def runtime_invocation(
    value: RuntimeInvocation | Mapping[str, Any] | None = None,
    *,
    executable: str | None = None,
    prefix_args: Sequence[str] | None = None,
    source: str | None = None,
) -> RuntimeInvocation:
    """Normalize structured CLI/API inputs into a managed invocation."""

    if isinstance(value, RuntimeInvocation):
        if executable is not None or prefix_args is not None or source is not None:
            raise ValueError("runtime invocation inputs are ambiguous")
        return value.require_managed()
    if value is not None:
        if executable is not None or prefix_args is not None or source is not None:
            raise ValueError("runtime invocation inputs are ambiguous")
        return RuntimeInvocation.from_dict(value).require_managed()
    if prefix_args is not None and executable is None:
        raise ValueError("runtime prefix args require a runtime executable")
    if executable is None:
        return RuntimeInvocation.managed(source=source)
    invocation = RuntimeInvocation(
        executable=executable,
        prefix_args=tuple(prefix_args or ()),
        source=source or "explicit",
    )
    return invocation.require_managed()


def load_project_runtime_invocation(repo: Path) -> RuntimeInvocation | None:
    """Load the invocation applied to a project, with setup-only fallback.

    ``installation.json`` describes the currently applied surfaces and therefore
    wins over the desired regeneration profile. A malformed present record is a
    hard error; callers must not silently accept a different executable.
    """

    root = repo.expanduser().resolve()
    for state_name in (".persistmind",):
        state = root / state_name
        for name in ("installation.json", "setup-profile.json"):
            path = state / name
            if not path.is_file():
                continue
            try:
                value = json.loads(
                    path.read_text(encoding="utf-8"),
                    object_pairs_hook=_reject_duplicate_pairs,
                )
            except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise ValueError("runtime_invocation_record_invalid") from exc
            if not isinstance(value, Mapping):
                raise ValueError("runtime_invocation_record_invalid")
            invocation = value.get("runtime_invocation")
            if invocation is None:
                continue
            if not isinstance(invocation, Mapping):
                raise ValueError("runtime_invocation_record_invalid")
            return RuntimeInvocation.from_dict(invocation).require_managed()
    return None


def _managed_python(
    executable: str | os.PathLike[str] | None,
) -> tuple[Path, str]:
    if executable is not None:
        return Path(executable).expanduser().resolve(strict=False), "explicit"
    override = os.environ.get("PERSISTMIND_BOOTSTRAP_HOME")
    if override:
        candidate = _python_in_environment(Path(override).expanduser())
        if candidate.is_file():
            return candidate.resolve(), "managed-bootstrap"
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        candidate = _python_in_environment(base / "PersistMind" / "bootstrap")
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
        candidate = _python_in_environment(base / "persistmind" / "bootstrap")
    if candidate.is_file():
        return candidate.resolve(), "managed-bootstrap"
    return Path(sys.executable).resolve(), "current-python"


def _python_in_environment(root: Path) -> Path:
    return root / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def _validated_text(value: str, *, field: str) -> str:
    if not value:
        raise ValueError(f"runtime {field} cannot be empty")
    if any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise ValueError(f"runtime {field} contains control characters")
    return value


def _powershell_quote(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _argv_sha256(argv: Sequence[str]) -> str:
    encoded = json.dumps(list(argv), ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _reject_duplicate_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("runtime_invocation_record_duplicate_key")
        value[key] = item
    return value
