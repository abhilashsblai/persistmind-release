CREATE TABLE IF NOT EXISTS teaching_students(
    student_id TEXT PRIMARY KEY CHECK(length(student_id) > 0),
    agent_identity TEXT NOT NULL CHECK(length(agent_identity) > 0),
    display_name TEXT NOT NULL DEFAULT '',
    metadata_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_teaching_students_identity
    ON teaching_students(agent_identity);

CREATE TABLE IF NOT EXISTS teaching_events(
    event_id TEXT PRIMARY KEY CHECK(length(event_id) > 0),
    student_id TEXT NOT NULL REFERENCES teaching_students(student_id),
    event_type TEXT NOT NULL CHECK(length(event_type) > 0),
    skill_key TEXT NOT NULL DEFAULT '',
    mistake_id TEXT,
    evidence_json TEXT NOT NULL DEFAULT '{}',
    observed_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_teaching_events_student
    ON teaching_events(student_id,observed_at,event_id);
CREATE INDEX IF NOT EXISTS idx_teaching_events_mistake
    ON teaching_events(mistake_id,event_id);

CREATE TABLE IF NOT EXISTS student_mastery(
    student_id TEXT NOT NULL REFERENCES teaching_students(student_id),
    skill_key TEXT NOT NULL CHECK(length(skill_key) > 0),
    mastery_level REAL NOT NULL DEFAULT 0.0 CHECK(mastery_level >= 0 AND mastery_level <= 1),
    success_count INTEGER NOT NULL DEFAULT 0 CHECK(success_count >= 0),
    failure_count INTEGER NOT NULL DEFAULT 0 CHECK(failure_count >= 0),
    last_event_id TEXT,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(student_id,skill_key)
);

CREATE TABLE IF NOT EXISTS revision_events(
    revision_id TEXT PRIMARY KEY CHECK(length(revision_id) > 0),
    skill_key TEXT NOT NULL CHECK(length(skill_key) > 0),
    mistake_id TEXT,
    summary TEXT NOT NULL DEFAULT '',
    evidence_json TEXT NOT NULL DEFAULT '{}',
    captured_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_revision_events_skill
    ON revision_events(skill_key,captured_at,revision_id);
CREATE INDEX IF NOT EXISTS idx_revision_events_mistake
    ON revision_events(mistake_id,revision_id);

CREATE TABLE IF NOT EXISTS revision_classifications(
    classification_id TEXT PRIMARY KEY CHECK(length(classification_id) > 0),
    revision_id TEXT NOT NULL REFERENCES revision_events(revision_id),
    label TEXT NOT NULL CHECK(length(label) > 0),
    attribution TEXT NOT NULL DEFAULT '',
    route TEXT NOT NULL DEFAULT '',
    confidence REAL NOT NULL DEFAULT 0.0 CHECK(confidence >= 0 AND confidence <= 1),
    classified_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_revision_classifications_revision
    ON revision_classifications(revision_id,classified_at,classification_id);

CREATE TABLE IF NOT EXISTS skill_improvements(
    improvement_id TEXT PRIMARY KEY CHECK(length(improvement_id) > 0),
    skill_key TEXT NOT NULL CHECK(length(skill_key) > 0),
    label TEXT NOT NULL CHECK(length(label) > 0),
    evidence_count INTEGER NOT NULL DEFAULT 0 CHECK(evidence_count >= 0),
    latest_revision_id TEXT,
    status TEXT NOT NULL DEFAULT 'candidate'
        CHECK(status IN ('candidate','promoted','rejected','closed')),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_skill_improvements_skill_label
    ON skill_improvements(skill_key,label);
