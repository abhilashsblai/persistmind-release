CREATE TABLE IF NOT EXISTS learning_signals(
    signal_id TEXT PRIMARY KEY CHECK(length(signal_id) > 0),
    task_session_id TEXT,
    turn_id TEXT,
    source TEXT NOT NULL CHECK(length(source) > 0),
    signal_kind TEXT NOT NULL CHECK(length(signal_kind) > 0),
    evidence_ref TEXT,
    content_excerpt TEXT NOT NULL DEFAULT '',
    content_hash TEXT NOT NULL CHECK(length(content_hash) > 0),
    structural_json TEXT NOT NULL DEFAULT '{}',
    detector_version TEXT NOT NULL CHECK(length(detector_version) > 0),
    adjudication_state TEXT NOT NULL CHECK(adjudication_state IN ('pending','adjudicated','dismissed')),
    observed_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_learning_signals_state
    ON learning_signals(adjudication_state,observed_at,signal_id);
CREATE INDEX IF NOT EXISTS idx_learning_signals_session
    ON learning_signals(task_session_id,observed_at,signal_id);

CREATE TABLE IF NOT EXISTS adjudication_queue(
    queue_id TEXT PRIMARY KEY CHECK(length(queue_id) > 0),
    signal_bundle_json TEXT NOT NULL,
    state TEXT NOT NULL CHECK(state IN ('pending','leased','done','dismissed','failed')),
    attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts >= 0),
    lease_expires_at TEXT,
    last_error TEXT,
    due_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_learning_adjudication_queue_state
    ON adjudication_queue(state,due_at,queue_id);

CREATE TABLE IF NOT EXISTS mistake_events(
    mistake_id TEXT PRIMARY KEY CHECK(length(mistake_id) > 0),
    signal_ids_json TEXT NOT NULL,
    category TEXT NOT NULL CHECK(length(category) > 0),
    attribution TEXT NOT NULL CHECK(length(attribution) > 0),
    mechanism TEXT NOT NULL DEFAULT '',
    severity TEXT NOT NULL CHECK(length(severity) > 0),
    confidence REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
    detector TEXT NOT NULL CHECK(length(detector) > 0),
    symptom TEXT NOT NULL DEFAULT '',
    root_cause TEXT NOT NULL DEFAULT '',
    resolution TEXT NOT NULL DEFAULT '',
    prevent_recurrence TEXT NOT NULL DEFAULT '',
    detection_method TEXT NOT NULL DEFAULT '',
    affected_paths_json TEXT NOT NULL DEFAULT '[]',
    blast_radius TEXT NOT NULL CHECK(length(blast_radius) > 0),
    recurrence_key TEXT NOT NULL CHECK(length(recurrence_key) > 0),
    provider_run_id TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_mistake_events_recurrence
    ON mistake_events(recurrence_key,created_at,mistake_id);

CREATE TABLE IF NOT EXISTS lesson_links(
    mistake_id TEXT NOT NULL REFERENCES mistake_events(mistake_id),
    target_kind TEXT NOT NULL,
    target_ref TEXT NOT NULL,
    link_kind TEXT NOT NULL,
    weight REAL NOT NULL CHECK(weight >= 0 AND weight <= 1),
    created_at TEXT NOT NULL,
    PRIMARY KEY(mistake_id,target_kind,target_ref,link_kind)
);

CREATE TABLE IF NOT EXISTS behavior_deltas(
    delta_id TEXT PRIMARY KEY CHECK(length(delta_id) > 0),
    mistake_id TEXT NOT NULL REFERENCES mistake_events(mistake_id),
    lesson_record_id TEXT,
    retrieval_event_id TEXT,
    decision_point TEXT NOT NULL,
    expected_action_signature TEXT NOT NULL,
    observed_action_signature TEXT NOT NULL,
    changed INTEGER NOT NULL CHECK(changed IN (0,1)),
    attributable INTEGER NOT NULL CHECK(attributable IN (0,1)),
    observed_at TEXT NOT NULL
);
