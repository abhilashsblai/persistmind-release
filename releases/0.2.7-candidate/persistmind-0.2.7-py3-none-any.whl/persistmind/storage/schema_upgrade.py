from __future__ import annotations

import hashlib
import json
import re
import time
from collections.abc import Mapping
from dataclasses import replace
from pathlib import Path, PurePosixPath
from typing import Any, cast

from .adapters.apsw_driver import copy_nextgen_database, open_nextgen_connection
from .adapters.sqlite_base import schema_resource_hash, schema_upgrade_resources
from .adapters.sqlite_control import SQLiteControlStore
from .bootstrap import validate_nextgen_manifest
from .catalog import FileCatalog
from .descriptors import StoreRole, TopologyManifest
from .resources import read_bytes, sha256
from .runtime import StorageNotInitialized, inspect_storage
from .workspace_lock import WorkspaceRuntimeLock

TARGET_HEADS = {
    StoreRole.CONTROL: 1,
    StoreRole.SOURCE_MANIFEST: 4,
    StoreRole.SOURCE_SEGMENT: 1,
    StoreRole.TASK_STATE: 8,
    StoreRole.ACTIVITY_ACTIVE: 4,
    StoreRole.ACTIVITY_SEALED: 4,
    StoreRole.AUDIT_ACTIVE: 3,
    StoreRole.AUDIT_SEALED: 3,
    StoreRole.KNOWLEDGE: 4,
    StoreRole.POLICY: 4,
    StoreRole.LEARNING: 6,
}


class SchemaUpgradeRejected(RuntimeError):
    status = "schema_upgrade_rejected"


class NextgenSchemaService:
    """Prepare, verify, and atomically publish additive authority schema heads."""

    def __init__(self, workspace_root: Path) -> None:
        self.root = workspace_root.resolve()
        self.catalog = FileCatalog(self.root / "catalog")

    def plan(self) -> dict[str, Any]:
        topology = self._topology()
        steps = []
        for descriptor in topology.stores:
            target = TARGET_HEADS[descriptor.store_role]
            observed_head, observed_resource_hash = self._store_schema_identity(descriptor)
            target_resource_hash = schema_resource_hash(descriptor.store_role, target)
            if descriptor.schema_head != target:
                if descriptor.schema_head > target:
                    raise SchemaUpgradeRejected(
                        f"schema downgrade is forbidden for {descriptor.store_role.value}: "
                        f"{descriptor.schema_head} -> {target}"
                    )
                resources = [
                    {
                        "version": version,
                        "resource": resource,
                        "sha256": sha256(resource),
                    }
                    for version, resource in schema_upgrade_resources(
                        descriptor.store_role, descriptor.schema_head, target
                    )
                ]
                steps.append(
                    {
                        "store_id": descriptor.store_id,
                        "role": descriptor.store_role.value,
                        "from_head": descriptor.schema_head,
                        "to_head": target,
                        "source_location": descriptor.location,
                        "target_location": _shadow_location(
                            descriptor.location,
                            generation=topology.generation + 1,
                            schema_head=target,
                        ),
                        "target_resource_hash": target_resource_hash,
                        "resources": resources,
                        "mode": "prepare_copy_verify_atomic_pointer_switch",
                    }
                )
            elif observed_head == target and (
                observed_resource_hash != target_resource_hash
                or not self._store_schema_objects_current(
                    descriptor,
                    target,
                    allow_development_driver=False,
                )
            ):
                resources = _schema_resources_for_head(descriptor.store_role, target)
                steps.append(
                    {
                        "store_id": descriptor.store_id,
                        "role": descriptor.store_role.value,
                        "from_head": target,
                        "to_head": target,
                        "source_location": descriptor.location,
                        "target_location": _shadow_location(
                            descriptor.location,
                            generation=topology.generation + 1,
                            schema_head=target,
                        ),
                        "target_resource_hash": target_resource_hash,
                        "observed_resource_hash": observed_resource_hash,
                        "resources": resources,
                        "mode": "refresh_schema_resource_identity",
                    }
                )
        plan_identity = {
            "from_generation": topology.generation,
            "to_generation": topology.generation + (1 if steps else 0),
            "steps": steps,
        }
        payload = json.dumps(plan_identity, sort_keys=True, separators=(",", ":"))
        return {
            "ok": not steps,
            "status": "current" if not steps else "schema_upgrade_ready",
            "schema_version": "persistmind.schema_plan.v2",
            "topology_generation": topology.generation,
            "target_topology_generation": topology.generation + (1 if steps else 0),
            "steps": steps,
            "plan_hash": hashlib.sha256(payload.encode()).hexdigest(),
        }

    def apply(
        self,
        plan: Mapping[str, Any],
        *,
        allow_development_driver: bool = False,
    ) -> dict[str, Any]:
        supplied_identity = {
            "from_generation": int(plan.get("topology_generation", -1)),
            "to_generation": int(plan.get("target_topology_generation", -1)),
            "steps": list(plan.get("steps") or ()),
        }
        supplied_hash = hashlib.sha256(
            json.dumps(supplied_identity, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        if str(plan.get("plan_hash")) != supplied_hash:
            raise SchemaUpgradeRejected("schema plan hash mismatch")
        current = self.plan()
        if str(plan.get("plan_hash")) != current["plan_hash"]:
            raise SchemaUpgradeRejected("schema plan changed before application")
        topology = self._topology()
        if not current["steps"]:
            return {
                **current,
                "ok": True,
                "status": "already_current",
                "from_generation": topology.generation,
                "generation": topology.generation,
                "upgraded": [],
            }

        prepared: list[Path] = []
        published = False
        with WorkspaceRuntimeLock(self.root, exclusive=True):
            # Re-read after acquiring the maintenance fence. A runtime may have
            # published a generation between plan validation and lock acquisition.
            locked = self.plan()
            if locked["plan_hash"] != current["plan_hash"]:
                raise SchemaUpgradeRejected("schema plan changed while acquiring maintenance")
            topology = self._topology()
            descriptors = {item.store_id: item for item in topology.stores}
            replacements = {}
            try:
                for step in locked["steps"]:
                    descriptor = descriptors[str(step["store_id"])]
                    target = self.catalog.resolve_location(str(step["target_location"]))
                    if target.exists() or _sqlite_companions(target):
                        raise SchemaUpgradeRejected(
                            f"prepared schema target already exists: {target}"
                        )
                    target.parent.mkdir(parents=True, exist_ok=True)
                    self._prepare_shadow(
                        descriptor=descriptor,
                        step=step,
                        target=target,
                        generation=topology.generation + 1,
                        allow_development_driver=allow_development_driver,
                    )
                    prepared.append(target)
                    replacements[descriptor.store_id] = replace(
                        descriptor,
                        location=str(step["target_location"]),
                        schema_head=int(step["to_head"]),
                        generation=topology.generation + 1,
                        resource_hash=str(step["target_resource_hash"]),
                    )

                target_topology = TopologyManifest(
                    topology_id=topology.topology_id,
                    generation=topology.generation + 1,
                    profile=topology.profile,
                    stores=tuple(replacements.get(item.store_id, item) for item in topology.stores),
                    workspace_id=topology.workspace_id,
                    contract_hash=topology.contract_hash,
                    created_at=_now(),
                    schema_version=topology.schema_version,
                )
                validate_nextgen_manifest(target_topology)
                self._publish(
                    topology,
                    target_topology,
                    allow_development_driver=allow_development_driver,
                )
                published = True
            finally:
                if not published:
                    for target in prepared:
                        _remove_prepared_image(target)

        return {
            **locked,
            "ok": True,
            "status": "upgraded",
            "from_generation": topology.generation,
            "generation": topology.generation + 1,
            "upgraded": [str(step["role"]) for step in locked["steps"]],
        }

    def verify(self) -> dict[str, Any]:
        plan = self.plan()
        if plan["steps"]:
            raise SchemaUpgradeRejected("authority schema heads are not current")
        return {**plan, "ok": True, "status": "verified"}

    def _topology(self):
        inspection = inspect_storage(self.root)
        if not inspection.initialized or inspection.topology is None:
            raise StorageNotInitialized("PersistMind storage is not initialized")
        validate_nextgen_manifest(inspection.topology)
        return inspection.topology

    def _prepare_shadow(
        self,
        *,
        descriptor: Any,
        step: Mapping[str, Any],
        target: Path,
        generation: int,
        allow_development_driver: bool,
    ) -> None:
        source = self.catalog.resolve_location(str(step["source_location"]))
        source_connection = open_nextgen_connection(
            source,
            read_only=True,
            allow_development_driver=allow_development_driver,
        )
        try:
            copy_nextgen_database(
                source_connection,
                target,
                allow_development_driver=allow_development_driver,
            )
        finally:
            source_connection.close()

        connection = open_nextgen_connection(
            target,
            allow_development_driver=allow_development_driver,
        )
        try:
            statements = ["BEGIN IMMEDIATE;"]
            for resource in step["resources"]:
                resource_name = str(resource["resource"])
                expected = str(resource["sha256"])
                observed = (
                    _base_schema_checksum(descriptor.store_role)
                    if int(resource["version"]) == 1
                    else sha256(resource_name)
                )
                if observed != expected:
                    raise SchemaUpgradeRejected(
                        f"schema resource changed after planning: {resource_name}"
                    )
                if int(step["to_head"]) > int(step["from_head"]):
                    statements.append(read_bytes(resource_name).decode("utf-8"))
                    statements.append(
                        "INSERT INTO domain_schema_migrations("
                        "version,resource,checksum,applied_at) "
                        f"VALUES({int(resource['version'])},{_sql(resource_name)},"
                        f"{_sql(expected)},{_sql(_now())});"
                    )
                else:
                    statements.extend(
                        read_bytes(item).decode("utf-8")
                        for item in _resource_apply_names(resource_name)
                    )
                    statements.append(
                        "INSERT INTO domain_schema_migrations("
                        "version,resource,checksum,applied_at) "
                        f"VALUES({int(resource['version'])},{_sql(resource_name)},"
                        f"{_sql(expected)},{_sql(_now())}) "
                        "ON CONFLICT(version) DO UPDATE SET "
                        "resource=excluded.resource,"
                        "checksum=excluded.checksum,"
                        "applied_at=excluded.applied_at;"
                    )
            statements.extend(
                [
                    "UPDATE domain_metadata SET "
                    f"schema_head={int(step['to_head'])},generation={generation},"
                    f"resource_hash={_sql(str(step['target_resource_hash']))} "
                    "WHERE singleton=1;",
                    f"PRAGMA user_version={int(step['to_head'])};",
                    "COMMIT;",
                ]
            )
            connection.executescript("\n".join(statements))
            integrity = [str(row[0]) for row in connection.execute("PRAGMA quick_check").fetchall()]
            foreign_keys = connection.execute("PRAGMA foreign_key_check").fetchall()
            metadata = connection.execute(
                "SELECT store_id,schema_head,generation,resource_hash "
                "FROM domain_metadata WHERE singleton=1"
            ).fetchone()
            if integrity != ["ok"] or foreign_keys:
                raise SchemaUpgradeRejected(
                    f"prepared schema image failed integrity verification: {descriptor.store_id}"
                )
            expected_metadata = (
                descriptor.store_id,
                int(step["to_head"]),
                generation,
                str(step["target_resource_hash"]),
            )
            if metadata is None or tuple(metadata) != expected_metadata:
                raise SchemaUpgradeRejected(
                    f"prepared schema image identity mismatch: {descriptor.store_id}"
                )
            for resource in step["resources"]:
                row = connection.execute(
                    "SELECT resource,checksum FROM domain_schema_migrations WHERE version=?",
                    (int(resource["version"]),),
                ).fetchone()
                if row is None or tuple(row) != (
                    str(resource["resource"]),
                    str(resource["sha256"]),
                ):
                    raise SchemaUpgradeRejected(
                        f"prepared schema migration receipt mismatch: {descriptor.store_id}"
                    )
        finally:
            connection.close()

    def _publish(
        self,
        current: TopologyManifest,
        target: TopologyManifest,
        *,
        allow_development_driver: bool,
    ) -> None:
        control_descriptor = next(
            item for item in current.stores if item.store_role is StoreRole.CONTROL
        )
        with SQLiteControlStore(
            self.catalog.resolve_location(control_descriptor.location),
            descriptor=control_descriptor,
            allow_development_driver=allow_development_driver,
        ) as control:
            control_store = cast(SQLiteControlStore, control)
            control_store.stage_topology(target.to_dict())
            self.catalog.activate(target, expected_generation=current.generation)
            published = self.catalog.current()
            control_store.activate_topology(published.generation)

    def _store_schema_identity(self, descriptor: Any) -> tuple[int | None, str | None]:
        path = self.catalog.resolve_location(descriptor.location)
        connection = open_nextgen_connection(
            path,
            read_only=True,
            allow_development_driver=False,
        )
        try:
            row = connection.execute(
                "SELECT schema_head,resource_hash FROM domain_metadata WHERE singleton=1"
            ).fetchone()
        finally:
            connection.close()
        if row is None:
            return None, None
        return int(row[0]), str(row[1])

    def _store_schema_objects_current(
        self,
        descriptor: Any,
        schema_head: int,
        *,
        allow_development_driver: bool,
    ) -> bool:
        required = _schema_objects_for_head(descriptor.store_role, schema_head)
        if not required:
            return True
        path = self.catalog.resolve_location(descriptor.location)
        connection = open_nextgen_connection(
            path,
            read_only=True,
            allow_development_driver=allow_development_driver,
        )
        try:
            for object_type, name in required:
                row = connection.execute(
                    "SELECT 1 FROM sqlite_master WHERE type=? AND name=?",
                    (object_type, name),
                ).fetchone()
                if row is None:
                    return False
        finally:
            connection.close()
        return True


def _schema_resources_for_head(role: StoreRole, schema_head: int) -> list[dict[str, Any]]:
    resources = [
        {
            "version": 1,
            "resource": ",".join(_base_schema_resources(role)),
            "sha256": _base_schema_checksum(role),
        }
    ]
    resources.extend(
        {
            "version": version,
            "resource": resource,
            "sha256": sha256(resource),
        }
        for version, resource in schema_upgrade_resources(role, 1, schema_head)
    )
    return resources


def _base_schema_resources(role: StoreRole) -> tuple[str, ...]:
    if role is StoreRole.CONTROL:
        return ("schemas/control/v1.sql",)
    if role is StoreRole.SOURCE_MANIFEST:
        return ("schemas/source/v1.sql",)
    if role is StoreRole.SOURCE_SEGMENT:
        return ("schemas/source_segment/v1.sql",)
    if role is StoreRole.TASK_STATE:
        return ("schemas/task/v1.sql",)
    if role in {StoreRole.ACTIVITY_ACTIVE, StoreRole.ACTIVITY_SEALED}:
        return ("schemas/activity/v1.sql", "schemas/reporting/activity.v1.sql")
    if role in {StoreRole.AUDIT_ACTIVE, StoreRole.AUDIT_SEALED}:
        return ("schemas/audit/v1.sql",)
    if role is StoreRole.KNOWLEDGE:
        return ("schemas/knowledge/v1.sql",)
    if role is StoreRole.POLICY:
        return ("schemas/policy/v1.sql",)
    if role is StoreRole.LEARNING:
        return ("schemas/learning/v1.sql", "schemas/reporting/learning.v1.sql")
    raise SchemaUpgradeRejected(f"unsupported schema role: {role.value}")


def _base_schema_checksum(role: StoreRole) -> str:
    return hashlib.sha256(
        "\n".join(sha256(resource) for resource in _base_schema_resources(role)).encode("ascii")
    ).hexdigest()


def _schema_objects_for_head(role: StoreRole, schema_head: int) -> tuple[tuple[str, str], ...]:
    resources = list(_base_schema_resources(role))
    resources.extend(resource for _, resource in schema_upgrade_resources(role, 1, schema_head))
    objects: list[tuple[str, str]] = []
    for resource in resources:
        sql = read_bytes(resource).decode("utf-8")
        objects.extend(_schema_objects(sql))
    return tuple(dict.fromkeys(objects))


def _schema_objects(sql: str) -> tuple[tuple[str, str], ...]:
    objects: list[tuple[str, str]] = []
    patterns = (
        ("table", r"\bCREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+([A-Za-z_][A-Za-z0-9_]*)"),
        (
            "table",
            r"\bCREATE\s+VIRTUAL\s+TABLE\s+IF\s+NOT\s+EXISTS\s+([A-Za-z_][A-Za-z0-9_]*)",
        ),
        ("index", r"\bCREATE\s+INDEX\s+IF\s+NOT\s+EXISTS\s+([A-Za-z_][A-Za-z0-9_]*)"),
        ("trigger", r"\bCREATE\s+TRIGGER\s+IF\s+NOT\s+EXISTS\s+([A-Za-z_][A-Za-z0-9_]*)"),
    )
    for object_type, pattern in patterns:
        objects.extend((object_type, match) for match in re.findall(pattern, sql, re.IGNORECASE))
    return tuple(objects)


def _resource_apply_names(resource_name: str) -> tuple[str, ...]:
    return tuple(item for item in resource_name.split(",") if item)


def _shadow_location(location: str, *, generation: int, schema_head: int) -> str:
    path = PurePosixPath(location)
    filename = f"{path.stem}.catalog-g{generation}.h{schema_head}{path.suffix}"
    return str(path.with_name(filename))


def _sql(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _sqlite_companions(path: Path) -> tuple[Path, ...]:
    return tuple(
        item for item in (Path(str(path) + "-wal"), Path(str(path) + "-shm")) if item.exists()
    )


def _remove_prepared_image(path: Path) -> None:
    for item in (Path(str(path) + "-wal"), Path(str(path) + "-shm"), path):
        item.unlink(missing_ok=True)
