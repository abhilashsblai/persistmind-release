from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any, cast

from ..descriptors import StorageDomain, StoreDescriptor, StoreRole
from ..events import EventLedger, StorageEvent
from .sqlite_base import SQLiteDomainStore, _now


class LearningConflict(RuntimeError):
    """A version or evaluation id was reused with incompatible immutable data."""

    status = "conflict"


class SQLiteLearningStore(SQLiteDomainStore):
    def __init__(
        self,
        path: Path,
        *,
        descriptor: StoreDescriptor | None = None,
        allow_development_driver: bool = False,
    ) -> None:
        super().__init__(
            path,
            StorageDomain.LEARNING,
            StoreRole.LEARNING,
            resource="schemas/learning/v1.sql",
            extra_resources=("schemas/reporting/learning.v1.sql",),
            store_id="learning-current",
            descriptor=descriptor,
            allow_development_driver=allow_development_driver,
        )

    def active_manifest(self) -> Mapping[str, Any]:
        with self._write_lock:
            rows = self.connection.execute(
                "SELECT skill_id,version_id FROM active_skills ORDER BY skill_id"
            ).fetchall()
        return {row["skill_id"]: row["version_id"] for row in rows}

    def register_version(
        self,
        version: Mapping[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        version_id = str(version.get("version_id") or "").strip()
        skill_id = str(version.get("skill_id") or "").strip()
        artifact_ref = str(version.get("artifact_ref") or "").strip()
        benchmark_id = str(version.get("benchmark_id") or "").strip()
        if not version_id or not skill_id or not artifact_ref or not benchmark_id:
            raise ValueError(
                "skill version requires version_id, skill_id, artifact_ref, and benchmark_id"
            )
        status = str(version.get("status") or "candidate")
        if status != "candidate":
            raise ValueError("new skill versions must start as candidate")
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT * FROM skill_versions WHERE version_id=?", (version_id,)
            ).fetchone()
            if existing is not None:
                immutable = ("skill_id", "artifact_ref", "benchmark_id")
                expected = {
                    "skill_id": skill_id,
                    "artifact_ref": artifact_ref,
                    "benchmark_id": benchmark_id,
                }
                if any(str(existing[key]) != expected[key] for key in immutable):
                    raise LearningConflict(
                        f"skill version id conflicts with immutable content: {version_id}"
                    )
                return dict(existing)
            self.connection.execute(
                "INSERT INTO skill_versions VALUES(?,?,?,?,?,?)",
                (version_id, skill_id, artifact_ref, benchmark_id, status, _now()),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            row = self.connection.execute(
                "SELECT * FROM skill_versions WHERE version_id=?", (version_id,)
            ).fetchone()
        if row is None:  # pragma: no cover - committed insert is immediately read.
            raise RuntimeError(f"skill version write did not persist: {version_id}")
        return dict(row)

    def version(self, version_id: str) -> Mapping[str, Any] | None:
        with self._write_lock:
            row = self.connection.execute(
                "SELECT * FROM skill_versions WHERE version_id=?", (version_id,)
            ).fetchone()
        return dict(row) if row is not None else None

    def versions(
        self, *, skill_id: str | None = None, limit: int = 1000
    ) -> Sequence[Mapping[str, Any]]:
        with self._write_lock:
            if skill_id:
                rows = self.connection.execute(
                    "SELECT * FROM skill_versions WHERE skill_id=? "
                    "ORDER BY created_at DESC,version_id LIMIT ?",
                    (skill_id, max(1, min(int(limit), 10_000))),
                ).fetchall()
            else:
                rows = self.connection.execute(
                    "SELECT * FROM skill_versions ORDER BY created_at DESC,version_id LIMIT ?",
                    (max(1, min(int(limit), 10_000)),),
                ).fetchall()
        return [dict(row) for row in rows]

    def record_evaluation(self, evaluation: Mapping[str, Any]) -> Mapping[str, Any]:
        evaluation_id = str(evaluation.get("evaluation_id") or "").strip()
        version_id = str(evaluation.get("version_id") or "").strip()
        split = str(evaluation.get("split") or "").strip()
        metrics = evaluation.get("metrics")
        if not evaluation_id or not version_id or not split or not isinstance(metrics, Mapping):
            raise ValueError(
                "learning evaluation requires evaluation_id, version_id, split, and metrics"
            )
        passed = bool(evaluation.get("passed"))
        metrics_json = json.dumps(dict(metrics), sort_keys=True, separators=(",", ":"))
        with self._write_lock, self.connection:
            if (
                self.connection.execute(
                    "SELECT 1 FROM skill_versions WHERE version_id=?", (version_id,)
                ).fetchone()
                is None
            ):
                raise KeyError(version_id)
            existing = self.connection.execute(
                "SELECT * FROM learning_evaluations WHERE evaluation_id=?", (evaluation_id,)
            ).fetchone()
            if existing is not None:
                if (
                    str(existing["version_id"]) != version_id
                    or str(existing["split"]) != split
                    or str(existing["metrics_json"]) != metrics_json
                    or bool(existing["passed"]) != passed
                ):
                    raise LearningConflict(
                        f"learning evaluation id conflicts with immutable data: {evaluation_id}"
                    )
                return _evaluation_row(cast(Mapping[str, Any], existing))
            self.connection.execute(
                "INSERT INTO learning_evaluations VALUES(?,?,?,?,?,?)",
                (evaluation_id, version_id, split, metrics_json, int(passed), _now()),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            row = self.connection.execute(
                "SELECT * FROM learning_evaluations WHERE evaluation_id=?", (evaluation_id,)
            ).fetchone()
        if row is None:  # pragma: no cover - committed insert is immediately read.
            raise RuntimeError(f"learning evaluation write did not persist: {evaluation_id}")
        return _evaluation_row(cast(Mapping[str, Any], row))

    def evaluations(self, version_id: str) -> Sequence[Mapping[str, Any]]:
        with self._write_lock:
            rows = self.connection.execute(
                "SELECT * FROM learning_evaluations WHERE version_id=? "
                "ORDER BY created_at,evaluation_id",
                (version_id,),
            ).fetchall()
        return [_evaluation_row(cast(Mapping[str, Any], row)) for row in rows]

    def transition_version(
        self,
        version_id: str,
        *,
        to_state: str,
        actor: str,
        reason: str,
    ) -> Mapping[str, Any]:
        if to_state not in {"candidate", "active", "inactive", "rejected", "suspended"}:
            raise ValueError(f"invalid Learning version state: {to_state}")
        with self._write_lock, self.connection:
            row = self.connection.execute(
                "SELECT * FROM skill_versions WHERE version_id=?", (version_id,)
            ).fetchone()
            if row is None:
                raise KeyError(version_id)
            from_state = str(row["status"])
            transition = {
                "record_id": "learning-version-transition-"
                + hashlib.sha256(
                    f"{version_id}\x1f{from_state}\x1f{to_state}\x1f{actor}\x1f{reason}".encode()
                ).hexdigest()[:32],
                "kind": "learning_version_transition",
                "scope": str(row["skill_id"]),
                "version_id": version_id,
                "from_state": from_state,
                "to_state": to_state,
                "actor": actor,
                "reason": reason,
                "created_at": _now(),
            }
            payload = json.dumps(transition, sort_keys=True, separators=(",", ":"))
            digest = hashlib.sha256(payload.encode()).hexdigest()
            self.connection.execute(
                "INSERT OR IGNORE INTO domain_records VALUES(?,?,?,?,?,1,?,?,?)",
                (
                    transition["record_id"],
                    transition["kind"],
                    transition["scope"],
                    payload,
                    digest,
                    transition["created_at"],
                    transition["created_at"],
                    "learning-version-transition:" + str(transition["record_id"]),
                ),
            )
            self.connection.execute(
                "UPDATE skill_versions SET status=? WHERE version_id=?", (to_state, version_id)
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            updated = self.connection.execute(
                "SELECT * FROM skill_versions WHERE version_id=?", (version_id,)
            ).fetchone()
        return dict(updated) if updated is not None else {}

    def promote(self, version_id: str, *, approval: Mapping[str, Any]) -> Mapping[str, Any]:
        if (
            not approval.get("approved_by")
            or not approval.get("benchmark_id")
            or not approval.get("rollback_version")
        ):
            raise PermissionError(
                "skill promotion requires approval, benchmark, and rollback metadata"
            )
        with self._write_lock, self.connection:
            row = self.connection.execute(
                "SELECT skill_id FROM skill_versions WHERE version_id=? AND status='candidate'",
                (version_id,),
            ).fetchone()
            if not row:
                raise KeyError(version_id)
            prior = self.connection.execute(
                "SELECT version_id FROM active_skills WHERE skill_id=?", (row[0],)
            ).fetchone()
            if prior is not None and str(prior[0]) != version_id:
                self.connection.execute(
                    "UPDATE skill_versions SET status='inactive' WHERE version_id=?",
                    (prior[0],),
                )
            self.connection.execute(
                "INSERT OR REPLACE INTO active_skills VALUES(?,?,?,?)",
                (row[0], version_id, json.dumps(dict(approval), sort_keys=True), _now()),
            )
            self.connection.execute(
                "UPDATE skill_versions SET status='active' WHERE version_id=?",
                (version_id,),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return {"ok": True, "version_id": version_id, "active": True}

    def rollback(self, version_id: str, *, approval: Mapping[str, Any]) -> Mapping[str, Any]:
        if not approval.get("approved_by"):
            raise PermissionError("rollback requires approval")
        with self._write_lock, self.connection:
            row = self.connection.execute(
                "SELECT skill_id FROM skill_versions WHERE version_id=?", (version_id,)
            ).fetchone()
            if not row:
                raise KeyError(version_id)
            current = self.connection.execute(
                "SELECT version_id FROM active_skills WHERE skill_id=?", (row[0],)
            ).fetchone()
            self.connection.execute(
                "UPDATE active_skills SET version_id=?,approval_json=?,activated_at=? "
                "WHERE skill_id=?",
                (version_id, json.dumps(dict(approval), sort_keys=True), _now(), row[0]),
            )
            if current is not None and str(current[0]) != version_id:
                self.connection.execute(
                    "UPDATE skill_versions SET status='inactive' WHERE version_id=?",
                    (current[0],),
                )
            self.connection.execute(
                "UPDATE skill_versions SET status='active' WHERE version_id=?",
                (version_id,),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return {"ok": True, "version_id": version_id, "rolled_back": True}

    def write_learning_event(
        self,
        *,
        phase: str,
        kind: str,
        ref: str | None = None,
        payload: Mapping[str, Any] | None = None,
    ) -> str:
        created_at = _now()
        payload_json = _stable_json(dict(payload or {}))
        event_id = "learning-event-" + hashlib.sha256(
            f"{phase}\x1f{kind}\x1f{ref or ''}\x1f{payload_json}\x1f{created_at}".encode()
        ).hexdigest()[:32]
        row = {
            "event_id": event_id,
            "phase": str(phase),
            "kind": str(kind),
            "ref": ref,
            "payload_json": payload_json,
            "created_at": created_at,
        }
        self._upsert_domain_record("learning_event", event_id, str(phase), row)
        return event_id

    def learning_events(self, *, ref: str | None = None, limit: int = 100) -> Sequence[Mapping[str, Any]]:
        rows = self._domain_rows("learning_event", limit=limit)
        if ref is not None:
            rows = [row for row in rows if row.get("ref") == ref]
        return rows[: max(1, min(int(limit), 10_000))]

    def record_learning_signal(
        self,
        *,
        source: str,
        signal_kind: str,
        task_session_id: str | None = None,
        turn_id: str | None = None,
        evidence_ref: str | None = None,
        content_excerpt: str = "",
        content_hash: str | None = None,
        structural: Mapping[str, Any] | None = None,
        detector_version: str = "deterministic.v1",
        signal_id: str | None = None,
        observed_at: str | None = None,
    ) -> Mapping[str, Any]:
        observed = observed_at or _now()
        structural_json = _stable_json(dict(structural or {}))
        content_digest = content_hash or hashlib.sha256(
            str(content_excerpt or "").encode()
        ).hexdigest()
        signal_id = signal_id or "learning-signal-" + hashlib.sha256(
            (
                f"{task_session_id or ''}\x1f{turn_id or ''}\x1f{source}\x1f"
                f"{signal_kind}\x1f{evidence_ref or ''}\x1f{content_digest}"
            ).encode()
        ).hexdigest()[:32]
        queue_id = "adjudication-" + hashlib.sha256(signal_id.encode()).hexdigest()[:32]
        bundle_json = _stable_json({"signal_ids": [signal_id]})
        with self._write_lock, self.connection:
            self.connection.execute(
                """
                INSERT INTO learning_signals(
                  signal_id,task_session_id,turn_id,source,signal_kind,evidence_ref,
                  content_excerpt,content_hash,structural_json,detector_version,
                  adjudication_state,observed_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(signal_id) DO NOTHING
                """,
                (
                    signal_id,
                    task_session_id,
                    turn_id,
                    source,
                    signal_kind,
                    evidence_ref,
                    str(content_excerpt or "")[:2000],
                    content_digest,
                    structural_json,
                    detector_version,
                    "pending",
                    observed,
                ),
            )
            self.connection.execute(
                """
                INSERT INTO adjudication_queue(
                  queue_id,signal_bundle_json,state,attempts,lease_expires_at,last_error,
                  due_at,created_at,updated_at
                ) VALUES(?,?,?,?,?,?,?,?,?)
                ON CONFLICT(queue_id) DO NOTHING
                """,
                (queue_id, bundle_json, "pending", 0, None, None, observed, observed, observed),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            event_id = "mistake-observed-" + hashlib.sha256(signal_id.encode()).hexdigest()[:32]
            event = StorageEvent(
                event_id=event_id,
                event_type="MistakeObserved.v1",
                aggregate_id=signal_id,
                sequence=None,
                payload={
                    "signal_id": signal_id,
                    "task_session_id": task_session_id,
                    "signal_kind": signal_kind,
                    "source": source,
                    "observed_at": observed,
                },
                required_consumers=("activity.ledger.v1", "learning.adjudication.v1"),
            )
            ledger = EventLedger(self.connection)
            ledger.append(event)
            encoded = json.dumps(event.payload, sort_keys=True, separators=(",", ":"))
            payload_hash = hashlib.sha256(encoded.encode()).hexdigest()
            ledger.receipt(
                event_id,
                "learning.adjudication.v1",
                "learning-signal-queue.v1",
                payload_hash,
            )
            ledger.receipt(
                event_id,
                "activity.ledger.v1",
                "learning-signal-activity-ledger.v1",
                payload_hash,
            )
            ledger.publish_if_complete(event_id)
        row = self.learning_signal(signal_id)
        if row is None:  # pragma: no cover - committed insert is immediately read.
            raise RuntimeError(f"learning signal write did not persist: {signal_id}")
        return row

    def learning_signal(self, signal_id: str) -> Mapping[str, Any] | None:
        with self._write_lock:
            row = self.connection.execute(
                "SELECT * FROM learning_signals WHERE signal_id=?", (signal_id,)
            ).fetchone()
        return _signal_row(cast(Mapping[str, Any], row)) if row is not None else None

    def learning_signals(
        self,
        *,
        adjudication_state: str | None = None,
        task_session_id: str | None = None,
        limit: int = 100,
    ) -> Sequence[Mapping[str, Any]]:
        clauses = []
        params: list[Any] = []
        if adjudication_state:
            clauses.append("adjudication_state=?")
            params.append(adjudication_state)
        if task_session_id:
            clauses.append("task_session_id=?")
            params.append(task_session_id)
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        params.append(max(1, min(int(limit), 10_000)))
        with self._write_lock:
            rows = self.connection.execute(
                f"SELECT * FROM learning_signals {where} ORDER BY observed_at DESC,signal_id LIMIT ?",
                params,
            ).fetchall()
        return [_signal_row(cast(Mapping[str, Any], row)) for row in rows]

    def dismiss_learning_signals(
        self,
        signal_ids: Sequence[str],
        *,
        reason: str = "",
    ) -> None:
        now = _now()
        with self._write_lock, self.connection:
            for signal_id in signal_ids:
                self.connection.execute(
                    """
                    UPDATE learning_signals
                    SET adjudication_state='dismissed'
                    WHERE signal_id=?
                    """,
                    (signal_id,),
                )
                queue_id = "adjudication-" + hashlib.sha256(str(signal_id).encode()).hexdigest()[:32]
                self.connection.execute(
                    """
                    UPDATE adjudication_queue
                    SET state='dismissed',last_error=?,updated_at=?
                    WHERE queue_id=?
                    """,
                    (reason, now, queue_id),
                )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )

    def pending_adjudication(self, *, limit: int = 100) -> Sequence[Mapping[str, Any]]:
        with self._write_lock:
            rows = self.connection.execute(
                """
                SELECT * FROM adjudication_queue
                WHERE state='pending'
                ORDER BY due_at,queue_id
                LIMIT ?
                """,
                (max(1, min(int(limit), 10_000)),),
            ).fetchall()
        return [_queue_row(cast(Mapping[str, Any], row)) for row in rows]

    def record_mistake_event(
        self,
        *,
        signal_ids: Sequence[str],
        category: str,
        attribution: str,
        severity: str,
        confidence: float,
        detector: str,
        blast_radius: str,
        recurrence_key: str,
        mechanism: str = "",
        symptom: str = "",
        root_cause: str = "",
        resolution: str = "",
        prevent_recurrence: str = "",
        detection_method: str = "",
        affected_paths: Sequence[str] = (),
        provider_run_id: str | None = None,
        mistake_id: str | None = None,
    ) -> Mapping[str, Any]:
        created_at = _now()
        signal_ids_json = json.dumps(list(signal_ids), sort_keys=True)
        affected_paths_json = json.dumps(list(affected_paths), sort_keys=True)
        mistake_id = mistake_id or "mistake-" + hashlib.sha256(
            f"{signal_ids_json}\x1f{category}\x1f{recurrence_key}".encode()
        ).hexdigest()[:32]
        with self._write_lock, self.connection:
            self.connection.execute(
                """
                INSERT INTO mistake_events(
                  mistake_id,signal_ids_json,category,attribution,mechanism,severity,
                  confidence,detector,symptom,root_cause,resolution,prevent_recurrence,
                  detection_method,affected_paths_json,blast_radius,recurrence_key,
                  provider_run_id,created_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(mistake_id) DO NOTHING
                """,
                (
                    mistake_id,
                    signal_ids_json,
                    category,
                    attribution,
                    mechanism,
                    severity,
                    max(0.0, min(1.0, float(confidence))),
                    detector,
                    symptom,
                    root_cause,
                    resolution,
                    prevent_recurrence,
                    detection_method,
                    affected_paths_json,
                    blast_radius,
                    recurrence_key,
                    provider_run_id,
                    created_at,
                ),
            )
            for signal_id in signal_ids:
                self.connection.execute(
                    """
                    UPDATE learning_signals
                    SET adjudication_state='adjudicated'
                    WHERE signal_id=?
                    """,
                    (signal_id,),
                )
                queue_id = "adjudication-" + hashlib.sha256(signal_id.encode()).hexdigest()[:32]
                self.connection.execute(
                    "UPDATE adjudication_queue SET state='done',updated_at=? WHERE queue_id=?",
                    (created_at, queue_id),
                )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        row = self.mistake_event(mistake_id)
        if row is None:  # pragma: no cover - committed insert is immediately read.
            raise RuntimeError(f"mistake event write did not persist: {mistake_id}")
        return row

    def mistake_event(self, mistake_id: str) -> Mapping[str, Any] | None:
        with self._write_lock:
            row = self.connection.execute(
                "SELECT * FROM mistake_events WHERE mistake_id=?", (mistake_id,)
            ).fetchone()
        return _mistake_row(cast(Mapping[str, Any], row)) if row is not None else None

    def mistake_events(
        self, *, recurrence_key: str | None = None, limit: int = 100
    ) -> Sequence[Mapping[str, Any]]:
        bounded = max(1, min(int(limit), 10_000))
        with self._write_lock:
            if recurrence_key:
                rows = self.connection.execute(
                    """
                    SELECT * FROM mistake_events
                    WHERE recurrence_key=?
                    ORDER BY created_at DESC,mistake_id
                    LIMIT ?
                    """,
                    (recurrence_key, bounded),
                ).fetchall()
            else:
                rows = self.connection.execute(
                    "SELECT * FROM mistake_events ORDER BY created_at DESC,mistake_id LIMIT ?",
                    (bounded,),
                ).fetchall()
        return [_mistake_row(cast(Mapping[str, Any], row)) for row in rows]

    def record_lesson_link(
        self,
        *,
        mistake_id: str,
        target_kind: str,
        target_ref: str,
        link_kind: str,
        weight: float = 1.0,
    ) -> Mapping[str, Any]:
        created_at = _now()
        with self._write_lock, self.connection:
            self.connection.execute(
                """
                INSERT INTO lesson_links(
                  mistake_id,target_kind,target_ref,link_kind,weight,created_at
                ) VALUES(?,?,?,?,?,?)
                ON CONFLICT(mistake_id,target_kind,target_ref,link_kind) DO UPDATE SET
                  weight=excluded.weight
                """,
                (
                    mistake_id,
                    target_kind,
                    target_ref,
                    link_kind,
                    max(0.0, min(1.0, float(weight))),
                    created_at,
                ),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return {
            "mistake_id": mistake_id,
            "target_kind": target_kind,
            "target_ref": target_ref,
            "link_kind": link_kind,
            "weight": max(0.0, min(1.0, float(weight))),
            "created_at": created_at,
        }

    def record_behavior_delta(
        self,
        *,
        mistake_id: str,
        decision_point: str,
        expected_action_signature: str,
        observed_action_signature: str,
        changed: bool,
        attributable: bool,
        lesson_record_id: str | None = None,
        retrieval_event_id: str | None = None,
        delta_id: str | None = None,
        observed_at: str | None = None,
    ) -> Mapping[str, Any]:
        observed = observed_at or _now()
        delta_id = delta_id or "behavior-delta-" + hashlib.sha256(
            (
                f"{mistake_id}\x1f{lesson_record_id or ''}\x1f{retrieval_event_id or ''}\x1f"
                f"{decision_point}\x1f{expected_action_signature}\x1f"
                f"{observed_action_signature}\x1f{observed}"
            ).encode()
        ).hexdigest()[:32]
        with self._write_lock, self.connection:
            self.connection.execute(
                """
                INSERT INTO behavior_deltas(
                  delta_id,mistake_id,lesson_record_id,retrieval_event_id,decision_point,
                  expected_action_signature,observed_action_signature,changed,attributable,
                  observed_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(delta_id) DO NOTHING
                """,
                (
                    delta_id,
                    mistake_id,
                    lesson_record_id,
                    retrieval_event_id,
                    decision_point,
                    expected_action_signature,
                    observed_action_signature,
                    int(bool(changed)),
                    int(bool(attributable)),
                    observed,
                ),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        row = self.behavior_delta(delta_id)
        if row is None:  # pragma: no cover - committed insert is immediately read.
            raise RuntimeError(f"behavior delta write did not persist: {delta_id}")
        return row

    def behavior_delta(self, delta_id: str) -> Mapping[str, Any] | None:
        with self._write_lock:
            row = self.connection.execute(
                "SELECT * FROM behavior_deltas WHERE delta_id=?", (delta_id,)
            ).fetchone()
        return _behavior_delta_row(cast(Mapping[str, Any], row)) if row is not None else None

    def behavior_deltas(
        self,
        *,
        mistake_id: str | None = None,
        retrieval_event_id: str | None = None,
        limit: int = 100,
    ) -> Sequence[Mapping[str, Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        if mistake_id:
            clauses.append("mistake_id=?")
            params.append(mistake_id)
        if retrieval_event_id:
            clauses.append("retrieval_event_id=?")
            params.append(retrieval_event_id)
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        params.append(max(1, min(int(limit), 10_000)))
        with self._write_lock:
            rows = self.connection.execute(
                f"""
                SELECT * FROM behavior_deltas
                {where}
                ORDER BY observed_at DESC,delta_id
                LIMIT ?
                """,
                params,
            ).fetchall()
        return [_behavior_delta_row(cast(Mapping[str, Any], row)) for row in rows]

    def ensure_teaching_student(
        self,
        *,
        agent_identity: str = "local-agent",
        display_name: str = "",
        metadata: Mapping[str, Any] | None = None,
    ) -> Mapping[str, Any]:
        now = _now()
        student_id = "teaching-student-" + hashlib.sha256(agent_identity.encode()).hexdigest()[:32]
        with self._write_lock, self.connection:
            self.connection.execute(
                """
                INSERT INTO teaching_students(
                  student_id,agent_identity,display_name,metadata_json,created_at,updated_at
                ) VALUES(?,?,?,?,?,?)
                ON CONFLICT(agent_identity) DO UPDATE SET
                  display_name=excluded.display_name,
                  metadata_json=excluded.metadata_json,
                  updated_at=excluded.updated_at
                """,
                (student_id, agent_identity, display_name, _stable_json(metadata or {}), now, now),
            )
            row = self.connection.execute(
                "SELECT * FROM teaching_students WHERE agent_identity=?", (agent_identity,)
            ).fetchone()
        return dict(row)

    def record_teaching_event(
        self,
        *,
        event_type: str,
        skill_key: str,
        mistake_id: str,
        evidence: Mapping[str, Any] | None = None,
        agent_identity: str = "local-agent",
    ) -> Mapping[str, Any]:
        student = self.ensure_teaching_student(agent_identity=agent_identity)
        observed_at = _now()
        event_id = "teaching-event-" + hashlib.sha256(
            f"{student['student_id']}\x1f{event_type}\x1f{skill_key}\x1f{mistake_id}".encode()
        ).hexdigest()[:32]
        with self._write_lock, self.connection:
            self.connection.execute(
                """
                INSERT OR IGNORE INTO teaching_events(
                  event_id,student_id,event_type,skill_key,mistake_id,evidence_json,observed_at
                ) VALUES(?,?,?,?,?,?,?)
                """,
                (
                    event_id,
                    student["student_id"],
                    event_type,
                    skill_key,
                    mistake_id,
                    _stable_json(evidence or {}),
                    observed_at,
                ),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            row = self.connection.execute(
                "SELECT * FROM teaching_events WHERE event_id=?", (event_id,)
            ).fetchone()
        return dict(row)

    def mastery_update(
        self,
        *,
        skill_key: str,
        success: bool,
        last_event_id: str | None = None,
        agent_identity: str = "local-agent",
    ) -> Mapping[str, Any]:
        student = self.ensure_teaching_student(agent_identity=agent_identity)
        now = _now()
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT * FROM student_mastery WHERE student_id=? AND skill_key=?",
                (student["student_id"], skill_key),
            ).fetchone()
            success_count = int(existing["success_count"] if existing else 0) + int(success)
            failure_count = int(existing["failure_count"] if existing else 0) + int(not success)
            total = success_count + failure_count
            mastery_level = round(success_count / total, 6) if total else 0.0
            self.connection.execute(
                """
                INSERT INTO student_mastery(
                  student_id,skill_key,mastery_level,success_count,failure_count,
                  last_event_id,updated_at
                ) VALUES(?,?,?,?,?,?,?)
                ON CONFLICT(student_id,skill_key) DO UPDATE SET
                  mastery_level=excluded.mastery_level,
                  success_count=excluded.success_count,
                  failure_count=excluded.failure_count,
                  last_event_id=excluded.last_event_id,
                  updated_at=excluded.updated_at
                """,
                (
                    student["student_id"],
                    skill_key,
                    mastery_level,
                    success_count,
                    failure_count,
                    last_event_id,
                    now,
                ),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            row = self.connection.execute(
                "SELECT * FROM student_mastery WHERE student_id=? AND skill_key=?",
                (student["student_id"], skill_key),
            ).fetchone()
        return dict(row)

    def capture_revision_event(
        self,
        *,
        skill_key: str,
        mistake_id: str,
        summary: str,
        evidence: Mapping[str, Any] | None = None,
    ) -> Mapping[str, Any]:
        revision_id = "revision-event-" + hashlib.sha256(
            f"{skill_key}\x1f{mistake_id}\x1f{summary}".encode()
        ).hexdigest()[:32]
        with self._write_lock, self.connection:
            self.connection.execute(
                """
                INSERT OR IGNORE INTO revision_events(
                  revision_id,skill_key,mistake_id,summary,evidence_json,captured_at
                ) VALUES(?,?,?,?,?,?)
                """,
                (revision_id, skill_key, mistake_id, summary, _stable_json(evidence or {}), _now()),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            row = self.connection.execute(
                "SELECT * FROM revision_events WHERE revision_id=?", (revision_id,)
            ).fetchone()
        return dict(row)

    def classify_revision_event(
        self,
        *,
        revision_id: str,
        label: str,
        attribution: str,
        route: str,
        confidence: float,
    ) -> Mapping[str, Any]:
        classification_id = "revision-classification-" + hashlib.sha256(
            f"{revision_id}\x1f{label}\x1f{attribution}\x1f{route}".encode()
        ).hexdigest()[:32]
        with self._write_lock, self.connection:
            self.connection.execute(
                """
                INSERT OR IGNORE INTO revision_classifications(
                  classification_id,revision_id,label,attribution,route,confidence,classified_at
                ) VALUES(?,?,?,?,?,?,?)
                """,
                (
                    classification_id,
                    revision_id,
                    label,
                    attribution,
                    route,
                    max(0.0, min(1.0, float(confidence))),
                    _now(),
                ),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            row = self.connection.execute(
                "SELECT * FROM revision_classifications WHERE classification_id=?",
                (classification_id,),
            ).fetchone()
        return dict(row)

    def upsert_skill_improvement(
        self,
        *,
        skill_key: str,
        label: str,
        latest_revision_id: str,
    ) -> Mapping[str, Any]:
        now = _now()
        improvement_id = "skill-improvement-" + hashlib.sha256(
            f"{skill_key}\x1f{label}".encode()
        ).hexdigest()[:32]
        with self._write_lock, self.connection:
            self.connection.execute(
                """
                INSERT INTO skill_improvements(
                  improvement_id,skill_key,label,evidence_count,latest_revision_id,
                  status,created_at,updated_at
                ) VALUES(?,?,?,?,?,?,?,?)
                ON CONFLICT(skill_key,label) DO UPDATE SET
                  evidence_count=skill_improvements.evidence_count+1,
                  latest_revision_id=excluded.latest_revision_id,
                  updated_at=excluded.updated_at
                """,
                (
                    improvement_id,
                    skill_key,
                    label,
                    1,
                    latest_revision_id,
                    "candidate",
                    now,
                    now,
                ),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            row = self.connection.execute(
                "SELECT * FROM skill_improvements WHERE skill_key=? AND label=?",
                (skill_key, label),
            ).fetchone()
        return dict(row)

    def write_learning_run(
        self,
        *,
        target: str,
        kind: str,
        before: Mapping[str, Any],
        after: Mapping[str, Any],
        train_metrics: Mapping[str, Any],
        holdout_metrics: Mapping[str, Any],
        gate_pass: bool,
        archived: bool,
        promoted: bool,
        run_id: str | None = None,
    ) -> str:
        created_at = _now()
        before_json = _stable_json(dict(before))
        after_json = _stable_json(dict(after))
        train_json = _stable_json(dict(train_metrics))
        holdout_json = _stable_json(dict(holdout_metrics))
        run_id = run_id or "learning-run-" + hashlib.sha256(
            f"{target}\x1f{kind}\x1f{before_json}\x1f{after_json}\x1f{created_at}".encode()
        ).hexdigest()[:32]
        row = {
            "run_id": run_id,
            "target": str(target),
            "kind": str(kind),
            "before_json": before_json,
            "after_json": after_json,
            "train_metrics_json": train_json,
            "holdout_metrics_json": holdout_json,
            "gate_pass": int(bool(gate_pass)),
            "archived": int(bool(archived)),
            "promoted": int(bool(promoted)),
            "created_at": created_at,
            "updated_at": created_at,
        }
        self._upsert_domain_record("learning_run", run_id, str(target), row)
        return run_id

    def learning_run(self, run_id: str) -> Mapping[str, Any] | None:
        rows = self._domain_rows("learning_run", limit=10_000)
        return next((row for row in rows if row.get("run_id") == run_id), None)

    def learning_runs(
        self,
        *,
        target: str | None = None,
        kind: str | None = None,
        limit: int = 100,
    ) -> Sequence[Mapping[str, Any]]:
        rows = self._domain_rows("learning_run", limit=limit)
        if target is not None:
            rows = [row for row in rows if row.get("target") == target]
        if kind is not None:
            rows = [row for row in rows if row.get("kind") == kind]
        return rows[: max(1, min(int(limit), 10_000))]

    def promoted_learning_runs(self, *, limit: int = 100) -> Sequence[Mapping[str, Any]]:
        return [
            row
            for row in self._domain_rows("learning_run", limit=limit)
            if bool(row.get("promoted"))
        ][: max(1, min(int(limit), 10_000))]

    def promote_learning_run(self, run_id: str) -> None:
        self._set_learning_run_flag(run_id, "promoted", True)

    def unpromote_learning_run(self, run_id: str) -> None:
        self._set_learning_run_flag(run_id, "promoted", False)

    def _set_learning_run_flag(self, run_id: str, field: str, value: bool) -> None:
        row = self.learning_run(run_id)
        if row is None:
            raise KeyError(run_id)
        updated = dict(row)
        updated[field] = int(value)
        updated["updated_at"] = _now()
        self._upsert_domain_record("learning_run", run_id, str(updated["target"]), updated)

    def _upsert_domain_record(
        self, kind: str, record_id: str, scope: str, payload: Mapping[str, Any]
    ) -> None:
        payload_json = _stable_json(dict(payload))
        digest = hashlib.sha256(payload_json.encode()).hexdigest()
        now = _now()
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT revision,created_at FROM domain_records WHERE record_id=?", (record_id,)
            ).fetchone()
            revision = int(existing["revision"]) + 1 if existing is not None else 1
            created_at = str(existing["created_at"]) if existing is not None else now
            self.connection.execute(
                """
                INSERT INTO domain_records(
                  record_id,kind,scope,payload_json,content_hash,revision,created_at,updated_at,idempotency_key
                ) VALUES(?,?,?,?,?,?,?,?,?)
                ON CONFLICT(record_id) DO UPDATE SET
                  kind=excluded.kind,
                  scope=excluded.scope,
                  payload_json=excluded.payload_json,
                  content_hash=excluded.content_hash,
                  revision=excluded.revision,
                  updated_at=excluded.updated_at
                """,
                (
                    record_id,
                    kind,
                    scope,
                    payload_json,
                    digest,
                    revision,
                    created_at,
                    now,
                    f"{kind}:{record_id}",
                ),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )

    def _domain_rows(self, kind: str, *, limit: int = 100) -> list[dict[str, Any]]:
        bounded = max(1, min(int(limit), 10_000))
        with self._write_lock:
            rows = self.connection.execute(
                """
                SELECT payload_json
                FROM domain_records
                WHERE kind=?
                ORDER BY updated_at DESC,record_id
                LIMIT ?
                """,
                (kind, bounded),
            ).fetchall()
        parsed: list[dict[str, Any]] = []
        for row in rows:
            try:
                value = json.loads(str(row["payload_json"]))
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                parsed.append(value)
        return parsed


def _evaluation_row(row: Mapping[str, Any]) -> dict[str, Any]:
    try:
        metrics = json.loads(str(row["metrics_json"]))
    except (KeyError, TypeError, json.JSONDecodeError):
        metrics = {}
    return {
        "evaluation_id": str(row["evaluation_id"]),
        "version_id": str(row["version_id"]),
        "split": str(row["split"]),
        "metrics": metrics if isinstance(metrics, dict) else {},
        "passed": bool(row["passed"]),
        "created_at": str(row["created_at"]),
    }


def _signal_row(row: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "signal_id": str(row["signal_id"]),
        "task_session_id": row["task_session_id"],
        "turn_id": row["turn_id"],
        "source": str(row["source"]),
        "signal_kind": str(row["signal_kind"]),
        "evidence_ref": row["evidence_ref"],
        "content_excerpt": str(row["content_excerpt"] or ""),
        "content_hash": str(row["content_hash"]),
        "structural": _json_dict(row["structural_json"]),
        "detector_version": str(row["detector_version"]),
        "adjudication_state": str(row["adjudication_state"]),
        "observed_at": str(row["observed_at"]),
    }


def _queue_row(row: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "queue_id": str(row["queue_id"]),
        "signal_bundle": _json_dict(row["signal_bundle_json"]),
        "state": str(row["state"]),
        "attempts": int(row["attempts"]),
        "lease_expires_at": row["lease_expires_at"],
        "last_error": row["last_error"],
        "due_at": str(row["due_at"]),
        "created_at": str(row["created_at"]),
        "updated_at": str(row["updated_at"]),
    }


def _mistake_row(row: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "mistake_id": str(row["mistake_id"]),
        "signal_ids": _json_list(row["signal_ids_json"]),
        "category": str(row["category"]),
        "attribution": str(row["attribution"]),
        "mechanism": str(row["mechanism"] or ""),
        "severity": str(row["severity"]),
        "confidence": float(row["confidence"]),
        "detector": str(row["detector"]),
        "symptom": str(row["symptom"] or ""),
        "root_cause": str(row["root_cause"] or ""),
        "resolution": str(row["resolution"] or ""),
        "prevent_recurrence": str(row["prevent_recurrence"] or ""),
        "detection_method": str(row["detection_method"] or ""),
        "affected_paths": _json_list(row["affected_paths_json"]),
        "blast_radius": str(row["blast_radius"]),
        "recurrence_key": str(row["recurrence_key"]),
        "provider_run_id": row["provider_run_id"],
        "created_at": str(row["created_at"]),
    }


def _behavior_delta_row(row: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "delta_id": str(row["delta_id"]),
        "mistake_id": str(row["mistake_id"]),
        "lesson_record_id": row["lesson_record_id"],
        "retrieval_event_id": row["retrieval_event_id"],
        "decision_point": str(row["decision_point"]),
        "expected_action_signature": str(row["expected_action_signature"]),
        "observed_action_signature": str(row["observed_action_signature"]),
        "changed": bool(row["changed"]),
        "attributable": bool(row["attributable"]),
        "observed_at": str(row["observed_at"]),
    }


def _stable_json(value: Mapping[str, Any]) -> str:
    return json.dumps(dict(value), sort_keys=True, separators=(",", ":"))


def _json_dict(value: Any) -> dict[str, Any]:
    try:
        parsed = json.loads(str(value or "{}"))
    except json.JSONDecodeError:
        return {}
    return dict(parsed) if isinstance(parsed, Mapping) else {}


def _json_list(value: Any) -> list[str]:
    try:
        parsed = json.loads(str(value or "[]"))
    except json.JSONDecodeError:
        return []
    return [str(item) for item in parsed] if isinstance(parsed, list) else []
