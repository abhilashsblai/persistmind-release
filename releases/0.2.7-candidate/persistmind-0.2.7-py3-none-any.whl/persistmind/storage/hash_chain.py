from __future__ import annotations

import hashlib
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any

ZERO_HASH = "0" * 64


@dataclass(frozen=True, slots=True)
class ChainRow:
    record_id: str
    sequence: int
    prev_hash: str
    event_hash: str
    payload: str


def compute_chain_link(previous_hash: str, payload: str) -> str:
    """Return PersistMind's canonical hash-chain link for a JSON payload."""

    return hashlib.sha256(f"{previous_hash}\0{payload}".encode()).hexdigest()


def verify_chain_rows(
    rows: Iterable[ChainRow | Mapping[str, Any]],
    *,
    schema_version: str,
    record_id_field: str = "record_id",
    reason_prefix: str = "chain",
    partition_id: str = "active",
) -> dict[str, Any]:
    """Verify sequence, predecessor, event hash, and chain tip for ordered rows."""

    expected_sequence = 1
    previous_hash = ZERO_HASH
    count = 0
    for raw in rows:
        row = _coerce_row(raw, record_id_field=record_id_field)
        expected_hash = compute_chain_link(previous_hash, row.payload)
        if row.sequence != expected_sequence:
            return {
                "ok": False,
                "status": "verification_failed",
                "reason": f"{reason_prefix}_sequence_gap",
                record_id_field: row.record_id,
                "expected_sequence": expected_sequence,
                "actual_sequence": row.sequence,
            }
        if row.prev_hash != previous_hash:
            return {
                "ok": False,
                "status": "verification_failed",
                "reason": f"{reason_prefix}_predecessor_mismatch",
                record_id_field: row.record_id,
                "expected": previous_hash,
                "actual": row.prev_hash,
            }
        if row.event_hash != expected_hash:
            return {
                "ok": False,
                "status": "verification_failed",
                "reason": f"{reason_prefix}_event_hash_mismatch",
                record_id_field: row.record_id,
                "expected": expected_hash,
                "actual": row.event_hash,
            }
        expected_sequence += 1
        previous_hash = expected_hash
        count += 1
    return {
        "ok": True,
        "schema_version": schema_version,
        "records": count,
        "tip": previous_hash,
        "partition_id": partition_id,
    }


def _coerce_row(value: ChainRow | Mapping[str, Any], *, record_id_field: str) -> ChainRow:
    if isinstance(value, ChainRow):
        return value
    try:
        payload = value["payload_json"]
    except (KeyError, IndexError):
        payload = value["payload"]
    return ChainRow(
        record_id=str(value[record_id_field]),
        sequence=int(value["sequence"]),
        prev_hash=str(value["prev_hash"]),
        event_hash=str(value["event_hash"]),
        payload=str(payload),
    )
