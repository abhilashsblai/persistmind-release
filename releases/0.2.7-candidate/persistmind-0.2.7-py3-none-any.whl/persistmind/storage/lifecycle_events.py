from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any, cast

from persistmind.utils import stable_id, utc_now

from .adapters.sqlite_activity import SQLiteActivityStore, SQLiteAuditStore
from .descriptors import StoreRole
from .events import EventLedger, StorageEvent
from .resources import required_event_consumers
from .runtime import StorageOpenIntent, StorageRuntime


class LifecycleEventService:
    """Converge required lifecycle consumers before an operation is complete."""

    def __init__(self, workspace_root: Path, *, allow_development_driver: bool = False) -> None:
        self.runtime = StorageRuntime.open(
            workspace_root.resolve(),
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=allow_development_driver,
            required_roles=frozenset({StoreRole.ACTIVITY_ACTIVE, StoreRole.AUDIT_ACTIVE}),
        )
        activity = self.runtime.router.resolve_write_store(StoreRole.ACTIVITY_ACTIVE)
        audit = self.runtime.router.resolve_write_store(StoreRole.AUDIT_ACTIVE)
        if not isinstance(activity, SQLiteActivityStore) or not isinstance(audit, SQLiteAuditStore):
            raise RuntimeError("lifecycle event roles are unavailable")
        self.activity = activity
        self.audit = audit
        self.ledger = EventLedger(cast(Any, activity.connection))

    def close(self) -> None:
        self.runtime.close()

    def __enter__(self) -> LifecycleEventService:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def emit(
        self,
        event_type: str,
        aggregate_id: str,
        payload: Mapping[str, Any],
    ) -> dict[str, Any]:
        document = {**dict(payload), "occurred_at": payload.get("occurred_at") or utc_now()}
        consumers = required_event_consumers(event_type, document)
        if consumers is None:
            raise ValueError(f"unregistered storage event: {event_type}")
        event = StorageEvent(
            event_id="evt_" + stable_id(event_type, aggregate_id, str(document))[:32],
            event_type=event_type,
            aggregate_id=aggregate_id,
            sequence=None,
            payload=document,
            required_consumers=consumers,
        )
        self.ledger.append(event)
        applied = []
        for consumer in consumers:
            try:
                self._apply(event, consumer)
                with self.activity.connection:
                    self.ledger.receipt(
                        event.event_id,
                        consumer,
                        "v1",
                        _payload_hash(self.ledger, event.event_id),
                    )
                applied.append(consumer)
            except Exception as exc:
                with self.activity.connection:
                    self.ledger.dead_letter(event.event_id, consumer, str(exc))
                raise
        with self.activity.connection:
            complete = self.ledger.publish_if_complete(event.event_id)
        return {
            "ok": complete,
            "status": "converged" if complete else "pending",
            "schema_version": "persistmind.lifecycle_event_result.v1",
            "event_id": event.event_id,
            "event_type": event_type,
            "consumers": applied,
            "completion": self.ledger.completion(event.event_id),
        }

    def _apply(self, event: StorageEvent, consumer: str) -> None:
        if consumer == "audit.append.v1":
            self.audit.append_audit(
                {
                    "audit_id": event.event_id,
                    "correlation_id": event.aggregate_id,
                    "kind": event.event_type,
                    "principal": event.payload.get("principal", "storage-control"),
                    "payload": dict(event.payload),
                },
                idempotency_key=f"lifecycle-audit:{event.event_id}",
            )
            return
        self.activity.put(
            {
                "record_id": "lifecycle-receipt-" + stable_id(event.event_id, consumer)[:32],
                "kind": "lifecycle_consumer_receipt",
                "event_id": event.event_id,
                "event_type": event.event_type,
                "consumer": consumer,
                "payload": dict(event.payload),
            },
            idempotency_key=f"lifecycle-consumer:{event.event_id}:{consumer}",
        )


def _payload_hash(ledger: EventLedger, event_id: str) -> str:
    row = ledger.connection.execute(
        "SELECT payload_hash FROM storage_outbox WHERE event_id=?", (event_id,)
    ).fetchone()
    if row is None:
        raise KeyError(event_id)
    return str(row[0])
