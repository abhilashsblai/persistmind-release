from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import re
import shutil
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, cast

from persistmind.security.approvals import require_approval_quorum
from persistmind.setup import ensure_project_state_ignored
from persistmind.utils import canonical_json

from .adapters.sqlite_base import SQLiteDomainStore
from .adapters.sqlite_control import SQLiteControlStore
from .artifacts import ContentAddressedArtifacts
from .backup import BACKUP_DIRECTORY_GLOB, BackupService
from .bootstrap import bootstrap_nextgen
from .catalog import CatalogRecoveryAmbiguous, FileCatalog
from .descriptors import StoreRole
from .lifecycle import OperationFence
from .operations import memory_kinds_status, resources_status
from .runtime import StorageOpenIntent, StorageRuntime, inspect_storage
from .runtime_policy import qualify_nextgen_runtime, require_qualified_nextgen_runtime


class WorkspaceMigrationRequired(RuntimeError):
    status = "workspace_migration_required"


class StorageControlPlane:
    """Split-v1 storage operations selectable before product-service construction."""

    def __init__(self, repo_root: Path) -> None:
        from persistmind.config import load_settings

        self.repo_root = repo_root.resolve()
        self.workspace_root = self.repo_root / load_settings(self.repo_root).toolchain.workspace_dir

    def topology(self) -> dict[str, Any]:
        inspection = inspect_storage(self.workspace_root)
        qualification = qualify_nextgen_runtime()
        if not inspection.initialized:
            return {
                "ok": True,
                "status": "uninitialized",
                "schema_version": "persistmind.storage_topology_status.v1",
                "profile": "persistmind-nextgen-v1",
                "topology_id": "persistmind-nextgen-v1",
                "generation": None,
                "stores": [],
                "runtime": qualification.to_dict(),
            }
        topology = inspection.topology
        assert topology is not None
        return {
            "ok": True,
            "status": "ready" if qualification.ok else "runtime_unqualified",
            "schema_version": topology.schema_version,
            "topology_id": topology.topology_id,
            "generation": topology.generation,
            "profile": topology.profile,
            "stores": [item.to_dict() for item in topology.stores],
            "runtime": qualification.to_dict(),
        }

    def status(self) -> dict[str, Any]:
        result = self.topology()
        result["workspace_root"] = str(self.workspace_root)
        return result

    def kill_switch_status(self) -> dict[str, Any]:
        inspection = inspect_storage(self.workspace_root)
        if not inspection.initialized:
            return {"ok": True, "active": False, "status": "uninitialized"}
        with StorageRuntime.open(
            self.workspace_root,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            read_only=True,
            required_roles=frozenset({StoreRole.CONTROL}),
        ) as runtime:
            store = runtime.router.resolve_read_set(StoreRole.CONTROL)[0]
            if not isinstance(store, SQLiteControlStore):
                raise RuntimeError("Control read route is unavailable")
            state = dict(store.kill_switch_status())
        return {
            "ok": True,
            "status": "halted" if state.get("active") else "ready",
            **state,
        }

    def kill_switch_set(
        self,
        *,
        active: bool,
        actor: str,
        reason: str,
        approvals: list[Mapping[str, str]],
        scope: str = "workspace",
    ) -> dict[str, Any]:
        if not reason.strip():
            raise ValueError("kill-switch transition requires a reason")
        document = {
            "schema_version": "persistmind.control_kill_switch.v1",
            "action": "activate" if active else "reset",
            "active": bool(active),
            "scope": scope,
            "actor": actor,
            "reason": reason,
        }
        signers = cast(
            list[Mapping[str, str]],
            require_approval_quorum(
                self.workspace_root,
                approvals,
                document,
                quorum=1 if active else 2,
                allow_test_provider=False,
            ),
        )
        decision_hash = (
            "sha256:" + hashlib.sha256(canonical_json(document).encode("utf-8")).hexdigest()
        )
        with StorageRuntime.open(
            self.workspace_root,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            required_roles=frozenset({StoreRole.CONTROL}),
        ) as runtime:
            store = runtime.router.resolve_write_store(StoreRole.CONTROL)
            if not isinstance(store, SQLiteControlStore):
                raise RuntimeError("Control write route is unavailable")
            state = dict(
                store.record_kill_switch_transition(
                    active=active,
                    scope=scope,
                    reason=reason,
                    actor=actor,
                    signer_identities=signers,
                    decision_document_hash=decision_hash,
                )
            )
        return {
            "ok": True,
            "status": "halted" if active else "ready",
            "schema_version": "persistmind.control_kill_switch.v1",
            "state": state,
        }

    def reconcile(self, *, limit: int = 100) -> dict[str, Any]:
        from .consistency_service import ConsistencyService

        with ConsistencyService(self.repo_root) as service:
            return service.reconcile(limit=limit)

    def bootstrap(self) -> dict[str, Any]:
        # The production contract validates the APSW/VFS runtime before any
        # authority file exists.  Source-tree tests may use bootstrap_nextgen's
        # explicit development-driver switch, but no public control-plane path
        # can silently create stdlib-owned authority files.
        require_qualified_nextgen_runtime()
        if (self.workspace_root / "workspace.db").exists():
            raise WorkspaceMigrationRequired(
                "an older workspace format is present; run the offline "
                "`persistmind-migrate` utility before bootstrap"
            )
        manifest = bootstrap_nextgen(
            self.workspace_root,
            activate=True,
            allow_development_driver=False,
            project_state_protocol=2,
        )
        ignore = ensure_project_state_ignored(self.repo_root)
        return {
            "ok": True,
            "status": "initialized",
            "schema_version": "persistmind.storage_bootstrap.v1",
            "profile": manifest.profile,
            "manifest": manifest.to_dict(),
            "gitignore": ignore,
            "workspace_db_created": False,
        }

    def verify(self, *, full: bool = False) -> dict[str, Any]:
        inspection = inspect_storage(self.workspace_root)
        qualification = qualify_nextgen_runtime()
        if not inspection.initialized:
            return {
                "ok": False,
                "status": "storage_not_initialized",
                "schema_version": "persistmind.storage_verify.v1",
                "checks": [],
            }
        if not qualification.ok:
            return {
                "ok": False,
                "status": "sqlite_runtime_unsupported",
                "schema_version": "persistmind.storage_verify.v1",
                "runtime": qualification.to_dict(),
                "checks": [],
            }
        # The production APSW factory is the only allowed verification opener.
        # Keeping this branch explicit prevents a stdlib read-only shortcut from
        # silently qualifying a authority store.
        with StorageRuntime.open(
            self.workspace_root,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            read_only=True,
            required_roles=frozenset(StoreRole),
        ) as runtime:
            stores, open_failures = runtime.router.inspect_declared()
            checks = [
                {
                    **dict(failure),
                    "path": str(runtime.catalog.resolve_location(str(failure["location"]))),
                    "ok": False,
                    "health": {
                        "ok": False,
                        "integrity_mode": "full" if full else "quick",
                        "error_type": failure["error_type"],
                        "error": failure["error"],
                        **(
                            {"identity": failure["diagnostics"]}
                            if failure.get("diagnostics")
                            else {}
                        ),
                    },
                    "recovery": {
                        "safe_entry_point": "persistmind storage recover plan",
                        "in_place_repair_supported": False,
                    },
                }
                for failure in open_failures
            ]
            for store_id, store in stores.items():
                try:
                    health = dict(store.verify_integrity(full=full))
                except Exception as exc:  # keep checking independent stores
                    health = {
                        "ok": False,
                        "integrity_mode": "full" if full else "quick",
                        "error_type": type(exc).__name__,
                        "error": str(exc),
                    }
                descriptor = store.descriptor
                from .schema_upgrade import TARGET_HEADS

                required_head = TARGET_HEADS[descriptor.store_role]
                actual_head = int(health.get("schema_head", descriptor.schema_head))
                schema_current = (
                    descriptor.schema_head == required_head and actual_head == required_head
                )
                checks.append(
                    {
                        "store_id": store_id,
                        "role": descriptor.store_role.value,
                        "path": str(runtime.catalog.resolve_location(descriptor.location)),
                        "ok": bool(health.get("ok")) and schema_current,
                        "health": {
                            **health,
                            "declared_schema_head": descriptor.schema_head,
                            "required_schema_head": required_head,
                            "schema_current": schema_current,
                        },
                        "recovery": (
                            None
                            if health.get("ok") and schema_current
                            else {
                                "safe_entry_point": "persistmind storage recover plan",
                                "in_place_repair_supported": False,
                            }
                        ),
                    }
                )
            route_checks = []
            for role in sorted(
                {item.store_role for item in runtime.topology.stores}, key=lambda item: item.value
            ):
                try:
                    routed = runtime.router.resolve_read_set(role)
                    route_checks.append(
                        {
                            "role": role.value,
                            "ok": bool(routed),
                            "stores": [item.descriptor.store_id for item in routed],
                            "mode": "read_only",
                        }
                    )
                except Exception as exc:
                    route_checks.append(
                        {
                            "role": role.value,
                            "ok": False,
                            "error_type": type(exc).__name__,
                            "error": str(exc),
                            "mode": "read_only",
                        }
                    )
            from persistmind.application.registry import operation_catalog

            operation_checks: list[dict[str, Any]] = []
            catalog = operation_catalog()
            for operation_id, operation_descriptor in catalog.items():
                if operation_descriptor.availability.value != "active":
                    continue
                plans: list[dict[str, Any]] = []
                for required_role in operation_descriptor.required_roles:
                    try:
                        plans.append(
                            dict(
                                runtime.router.explain_route(
                                    required_role,
                                    mode="declared",
                                    # This verifies declared authority availability,
                                    # not a request's authorization scope. Each role
                                    # must therefore use its own topology default.
                                    scope=None,
                                )
                            )
                        )
                    except Exception as exc:
                        plans.append(
                            {
                                "ok": False,
                                "role": role,
                                "mode": operation_descriptor.mode.value,
                                "error_type": type(exc).__name__,
                                "error": str(exc),
                            }
                        )
                operation_checks.append(
                    {
                        "operation_id": operation_id,
                        "mode": operation_descriptor.mode.value,
                        "route_validation": "declared-role-availability",
                        "ok": all(bool(plan["ok"]) for plan in plans),
                        "plans": plans,
                    }
                )
            for check in checks:
                if check["ok"] or not check.get("role"):
                    continue
                check["affected_operations"] = sorted(
                    operation_id
                    for operation_id, descriptor in catalog.items()
                    if descriptor.availability.value == "active"
                    and check["role"] in descriptor.required_roles
                )
        all_ok = (
            all(item["ok"] for item in checks)
            and all(item["ok"] for item in route_checks)
            and all(item["ok"] for item in operation_checks)
        )
        return {
            "ok": all_ok,
            "status": "ok" if all_ok else "degraded",
            "schema_version": "persistmind.storage_verify.v1",
            "full": full,
            "checks": checks,
            "route_checks": route_checks,
            "operation_route_checks": operation_checks,
        }

    def recover_catalog(self) -> dict[str, Any]:
        catalog = FileCatalog(self.workspace_root / "catalog")
        try:
            manifest = catalog.recover()
        except CatalogRecoveryAmbiguous as exc:
            return {
                "ok": False,
                "status": "catalog_recovery_ambiguous",
                "error": str(exc),
            }
        return {"ok": True, "status": "recovered", "manifest": manifest.to_dict()}

    def recovery_plan(self, authority: str, *, output: Path) -> dict[str, Any]:
        from .recovery import AuthorityRecoveryService

        return AuthorityRecoveryService(self.repo_root, self.workspace_root).plan(
            authority, output=output
        )

    def recovery_stage(
        self,
        plan_path: Path,
        *,
        backup_destination: Path,
        backup_id: str | None = None,
    ) -> dict[str, Any]:
        from .recovery import AuthorityRecoveryService

        return AuthorityRecoveryService(self.repo_root, self.workspace_root).stage(
            plan_path,
            backup_destination=backup_destination,
            backup_id=backup_id,
        )

    def recovery_status(self, stage_path: Path) -> dict[str, Any]:
        from .recovery import AuthorityRecoveryService

        return AuthorityRecoveryService(self.repo_root, self.workspace_root).status(stage_path)

    def recovery_apply(
        self, stage_path: Path, *, loss_acceptance: Path | None = None
    ) -> dict[str, Any]:
        from .recovery import AuthorityRecoveryService

        return AuthorityRecoveryService(self.repo_root, self.workspace_root).apply(
            stage_path, loss_acceptance=loss_acceptance
        )

    def recovery_rollback(self, stage_path: Path) -> dict[str, Any]:
        from .recovery import AuthorityRecoveryService

        return AuthorityRecoveryService(self.repo_root, self.workspace_root).rollback(stage_path)

    def recovery_finalize(self, stage_path: Path) -> dict[str, Any]:
        from .recovery import AuthorityRecoveryService

        reconciliation = self.reconcile(limit=10_000)
        verification = self.verify(full=True)
        return AuthorityRecoveryService(self.repo_root, self.workspace_root).record_closure(
            stage_path,
            reconciliation=reconciliation,
            verification=verification,
        )

    def resources_verify(self) -> dict[str, Any]:
        return resources_status()

    def memory_kinds(self) -> dict[str, Any]:
        return memory_kinds_status()

    def roles(self) -> dict[str, Any]:
        topology = self.topology()
        return {
            "ok": topology["ok"],
            "schema_version": "persistmind.storage_roles.v1",
            "generation": topology.get("generation"),
            "roles": topology.get("stores", []),
        }

    def models_status(self) -> dict[str, Any]:
        from .model_bundle import model_status

        model = model_status(self.workspace_root)
        sqlite_vec = importlib.util.find_spec("sqlite_vec") is not None
        return {
            "ok": True,
            "status": "ready" if model["verified"] and sqlite_vec else "deterministic_fallback",
            "schema_version": "persistmind.storage_models_status.v1",
            "required_model": "sentence-transformers/all-MiniLM-L6-v2",
            "model": model,
            "sqlite_vec": sqlite_vec,
            "fallback": "local-hash-embedder-v1" if not model["verified"] else None,
        }

    def models_install(self, source: Path) -> dict[str, Any]:
        from .model_bundle import install_model_bundle, model_status

        install_model_bundle(self.workspace_root, source)
        return {
            "ok": True,
            "status": "installed",
            "schema_version": "persistmind.storage_model_install.v1",
            "model": model_status(self.workspace_root),
        }

    def keys_status(self) -> dict[str, Any]:
        from persistmind.security.encryption import volume_encryption_status
        from persistmind.security.envelope import WorkspaceKeyProvider

        volume = volume_encryption_status(self.workspace_root)
        try:
            import keyring

            backend = (
                type(keyring.get_keyring()).__module__ + "." + type(keyring.get_keyring()).__name__
            )
            approved = not any(
                token in backend.casefold() for token in ("fail", "null", "plaintext")
            )
        except Exception:  # noqa: BLE001 - status must not fail because a backend is absent.
            backend, approved = "unavailable", False
        return {
            "ok": True,
            "status": "ready" if volume["verified"] and approved else "restricted",
            "schema_version": "persistmind.storage_keys_status.v1",
            "volume_encryption": volume,
            "keyring_backend": backend,
            "keyring_approved": approved,
            "confidential_persistence_allowed": bool(volume["verified"] and approved),
            "current_key_id": WorkspaceKeyProvider(self.workspace_root).current_key_id(),
        }

    def keys_rotate(self) -> dict[str, Any]:
        from .key_management import StorageKeyRotationService

        return StorageKeyRotationService(self.workspace_root).rotate()

    def recovery_kit_create(self, output: Path) -> tuple[dict[str, Any], str]:
        from persistmind.security.envelope import create_recovery_kit

        return create_recovery_kit(self.workspace_root, output)

    def recovery_kit_verify(self, path: Path, passphrase: str) -> dict[str, Any]:
        from persistmind.security.envelope import verify_recovery_kit

        return verify_recovery_kit(path, passphrase)

    def approval_sign(self, document_path: Path, *, principal: str | None = None) -> dict[str, Any]:
        from persistmind.security.approvals import WorkspaceApprovalSigner

        try:
            document = json.loads(document_path.resolve().read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ValueError("approval document is unreadable") from exc
        if not isinstance(document, dict):
            raise ValueError("approval document must be a JSON object")
        signer_principal = str(
            principal
            or document.get("approver")
            or document.get("actor")
            or document.get("approved_by")
            or ""
        ).strip()
        if not signer_principal:
            raise ValueError("approval signing requires a principal bound in the document")
        signer = WorkspaceApprovalSigner(
            self.workspace_root,
            principal=signer_principal,
        )
        return {
            "ok": True,
            "status": "signed",
            "schema_version": "persistmind.approval_signature.v1",
            "document_hash": hashlib.sha256(
                json.dumps(document, sort_keys=True, separators=(",", ":")).encode()
            ).hexdigest(),
            "signer": signer.identity(),
            "signature": signer.sign(document),
        }

    def schema_status(self) -> dict[str, Any]:
        from .schema_upgrade import TARGET_HEADS

        inspection = inspect_storage(self.workspace_root)
        if not inspection.initialized or inspection.topology is None:
            return {
                "ok": False,
                "status": "storage_not_initialized",
                "schema_version": "persistmind.storage_schema_status.v1",
                "roles": [],
            }
        with StorageRuntime.open(
            self.workspace_root,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            read_only=True,
            required_roles=frozenset(StoreRole),
        ) as runtime:
            stores = runtime.router.open_declared()
            roles = []
            for descriptor in inspection.topology.stores:
                health = dict(stores[descriptor.store_id].health())
                actual = int(health.get("schema_head", descriptor.schema_head))
                required = TARGET_HEADS[descriptor.store_role]
                roles.append(
                    {
                        "store_id": descriptor.store_id,
                        "role": descriptor.store_role.value,
                        "declared": descriptor.schema_head,
                        "expected": required,
                        "actual": actual,
                        "current": actual == required and descriptor.schema_head == required,
                        "resource_hash": descriptor.resource_hash,
                    }
                )
        return {
            "ok": all(item["current"] for item in roles),
            "status": "current" if all(item["current"] for item in roles) else "upgrade_required",
            "schema_version": "persistmind.storage_schema_status.v1",
            "generation": inspection.topology.generation,
            "roles": roles,
        }

    def schema_plan(self, *, output: Path | None = None) -> dict[str, Any]:
        from .schema_upgrade import NextgenSchemaService

        plan = NextgenSchemaService(self.workspace_root).plan()
        if output is not None:
            target = output.resolve()
            if target.exists():
                raise FileExistsError(target)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(json.dumps(plan, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            plan["output"] = str(target)
        return plan

    def schema_upgrade(self, *, plan_path: Path) -> dict[str, Any]:
        try:
            plan = json.loads(plan_path.resolve().read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ValueError("schema upgrade plan is unreadable") from exc
        if not isinstance(plan, dict):
            raise ValueError("schema upgrade plan must be a JSON object")
        return self.schema_upgrade_document(plan)

    def schema_upgrade_document(self, plan: Mapping[str, Any]) -> dict[str, Any]:
        from .schema_upgrade import NextgenSchemaService

        result = NextgenSchemaService(self.workspace_root).apply(plan)
        if not result["upgraded"]:
            return {**result, "lifecycle_event": None}
        result["lifecycle_event"] = self._emit_lifecycle(
            "SchemaHeadChanged.v1",
            "topology:" + str(result["generation"]),
            {
                "from_generation": result["from_generation"],
                "generation": result["generation"],
                "upgraded": result["upgraded"],
                "plan_hash": result["plan_hash"],
            },
        )
        return result

    def partitions(self) -> dict[str, Any]:
        inspection = inspect_storage(self.workspace_root)
        if not inspection.initialized or inspection.topology is None:
            return {
                "ok": False,
                "status": "storage_not_initialized",
                "schema_version": "persistmind.storage_partitions.v1",
                "partitions": [],
            }
        partitions = [
            item.to_dict()
            for item in inspection.topology.stores
            if item.store_role.value
            in {
                "activity_active",
                "activity_sealed",
                "audit_active",
                "audit_sealed",
                "source_segment",
            }
        ]
        return {
            "ok": True,
            "schema_version": "persistmind.storage_partitions.v1",
            "generation": inspection.topology.generation,
            "partitions": partitions,
        }

    def rotate_partition(
        self,
        role: str,
        *,
        actor: str | None = None,
        signature: str | None = None,
    ) -> dict[str, Any]:
        normalized = role.strip().lower()
        if normalized not in {"activity", "audit"}:
            raise ValueError("partition role must be activity or audit")
        with OperationFence(
            self.workspace_root,
            "partition-rotate",
            {"role": normalized},
            scope=f"partition-{normalized}",
        ) as fence:
            if normalized == "activity":
                from .activity_service import ActivityService

                with ActivityService(self.repo_root) as service:
                    result = service.rotate_partition()
            else:
                from .audit_service import AuditService

                with AuditService(self.repo_root) as service:
                    result = service.rotate_partition(
                        actor=actor or "",
                        signature=signature or "",
                    )
            event_type = (
                "ActivityPartitionSealed.v1"
                if normalized == "activity"
                else "AuditPartitionSealed.v1"
            )
            result["lifecycle_event"] = self._emit_lifecycle(
                event_type,
                str(result.get("sealed_store_id") or result.get("partition_id") or normalized),
                {
                    **result,
                    "local_anchor": normalized == "audit",
                },
            )
            fence.succeed(result)
            return result

    def repair(self, *, dry_run: bool = True) -> dict[str, Any]:
        inspection = inspect_storage(self.workspace_root)
        actions: list[dict[str, Any]] = []
        if not inspection.initialized:
            actions.append({"action": "recover_catalog", "reason": "catalog is not committed"})
        else:
            topology = inspection.topology
            assert topology is not None
            actions.extend(_source_segment_repair_actions(self.workspace_root, topology))
            if not any(item["action"] == "restore_store_from_verified_backup" for item in actions):
                verification = self.verify(full=True)
                for check in verification.get("checks", []):
                    if not check.get("ok"):
                        actions.append(
                            {
                                "action": "restore_store_from_verified_backup",
                                "store_id": check.get("store_id"),
                            }
                        )
        if not dry_run and actions:
            if actions == [{"action": "recover_catalog", "reason": "catalog is not committed"}]:
                recovered = self.recover_catalog()
                return {
                    "ok": recovered.get("ok", False),
                    "status": "applied",
                    "schema_version": "persistmind.storage_repair.v1",
                    "actions": actions,
                    "result": recovered,
                }
            if all(item["action"] == "remove_orphan_source_segment" for item in actions):
                for item in actions:
                    path = Path(str(item["path"])).resolve()
                    path.unlink(missing_ok=True)
                    Path(f"{path}-wal").unlink(missing_ok=True)
                    Path(f"{path}-shm").unlink(missing_ok=True)
                return {
                    "ok": True,
                    "status": "applied",
                    "schema_version": "persistmind.storage_repair.v1",
                    "actions": actions,
                }
            raise RuntimeError(
                "repair requires an explicit verified-backup restore for damaged stores"
            )
        return {
            "ok": not actions,
            "status": "clean" if not actions else "plan_ready",
            "schema_version": "persistmind.storage_repair.v1",
            "dry_run": dry_run,
            "actions": actions,
        }

    def doctor(self) -> dict[str, Any]:
        from persistmind.architecture.contracts import validate_architecture_contracts
        from persistmind.interfaces.manifest import validate_interface_artifacts
        from persistmind.storage.learning_service import LearningService

        topology = self.topology()
        resources = self.resources_verify()
        architecture = validate_architecture_contracts(self.repo_root)
        interfaces = validate_interface_artifacts(self.repo_root)
        schema = self.schema_status()
        verification = (
            self.verify(full=True)
            if topology.get("generation")
            else {"ok": False, "status": "storage_not_initialized", "checks": []}
        )
        reconciliation: dict[str, Any] = {
            "ok": False,
            "status": "storage_not_initialized",
            "stores": [],
        }
        warnings: list[dict[str, Any]] = []
        if topology.get("generation"):
            with StorageRuntime.open(
                self.workspace_root,
                intent=StorageOpenIntent.REQUIRE_INITIALIZED,
                read_only=True,
                required_roles=frozenset(StoreRole),
            ) as runtime:
                states = [
                    dict(store.reconciliation_health())
                    for store in runtime.router.open_declared().values()
                ]
            reconciliation = {
                "ok": all(item["ok"] for item in states),
                "status": "healthy"
                if all(item["ok"] for item in states)
                else "dead_letters_present",
                "pending_publications": sum(int(item["pending_publications"]) for item in states),
                "dead_letters": sum(int(item["dead_letters"]) for item in states),
                "stores": states,
            }
            with LearningService(self.repo_root, read_only=True) as learning:
                warnings.extend(_learning_provider_warnings(learning.status()))
        diagnostics = _doctor_diagnostics(
            {
                "topology": topology,
                "resources": resources,
                "architecture": architecture,
                "interfaces": interfaces,
                "schema": schema,
                "verification": verification,
                "reconciliation": reconciliation,
            },
            warnings,
        )
        healthy = all(
            bool(item.get("ok"))
            for item in (
                topology,
                resources,
                architecture,
                interfaces,
                schema,
                verification,
                reconciliation,
            )
        )
        return {
            "ok": healthy,
            "status": "healthy" if healthy else "degraded",
            "schema_version": "persistmind.storage_doctor.v2",
            "topology": topology,
            "resources": resources,
            "architecture": architecture,
            "interfaces": interfaces,
            "schema": schema,
            "verification": verification,
            "reconciliation": reconciliation,
            "warnings": warnings,
            "diagnostics": diagnostics,
            "diagnostic_count": len(diagnostics),
            "remediation": []
            if verification.get("ok") and schema.get("ok")
            else (
                [
                    "run storage schema plan, then apply the reviewed plan with storage schema upgrade"
                ]
                if not schema.get("ok")
                else [
                    "run storage verify --full and restore any failed role from a verified backup"
                ]
            ),
        }

    def export(self, scope: str, *, output: Path) -> dict[str, Any]:
        if not scope.strip():
            raise ValueError("export scope must be non-empty")
        target = output.resolve()
        if target.is_relative_to(self.workspace_root):
            raise ValueError("export output must be outside the live workspace root")
        if target.exists():
            raise FileExistsError(target)
        staging = target.with_name(f".{target.name}.staging-{os.getpid()}")
        entries: list[dict[str, Any]] = []
        try:
            staging.mkdir(parents=True)
            with StorageRuntime.open(
                self.workspace_root,
                intent=StorageOpenIntent.REQUIRE_INITIALIZED,
                required_roles=frozenset(StoreRole),
            ) as runtime:
                for store_id, store in sorted(runtime.router.open_declared().items()):
                    if not isinstance(store, SQLiteDomainStore):
                        raise RuntimeError(f"unsupported export store: {store_id}")
                    rows = _logical_rows(store.connection, scope)
                    if not rows:
                        continue
                    relative = Path("records") / f"{store_id}.jsonl"
                    destination = staging / relative
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    encoded = b"".join(
                        (
                            json.dumps(
                                row, sort_keys=True, separators=(",", ":"), ensure_ascii=False
                            )
                            + "\n"
                        ).encode("utf-8")
                        for row in rows
                    )
                    destination.write_bytes(encoded)
                    entries.append(
                        {
                            "path": relative.as_posix(),
                            "rows": len(rows),
                            "bytes": len(encoded),
                            "sha256": hashlib.sha256(encoded).hexdigest(),
                        }
                    )
                manifest = {
                    "schema_version": "persistmind-export-v1",
                    "scope": scope,
                    "topology_generation": runtime.topology.generation,
                    "entries": entries,
                    "created_at": datetime.now(UTC).isoformat(),
                }
                payload = json.dumps(
                    manifest, sort_keys=True, separators=(",", ":"), ensure_ascii=False
                ).encode("utf-8")
                (staging / "manifest.json").write_bytes(payload)
            os.replace(staging, target)
        finally:
            if staging.exists():
                shutil.rmtree(staging, ignore_errors=True)
        return {
            "ok": True,
            "status": "exported",
            "schema_version": "persistmind.storage_export.v1",
            "scope": scope,
            "output": str(target),
            "entries": entries,
        }

    def delete(self, scope: str, *, dry_run: bool = True) -> dict[str, Any]:
        from .privacy import PrivacyDeletionService

        service = PrivacyDeletionService(self.workspace_root)
        plan = service.plan(scope)
        if dry_run:
            return {
                "ok": True,
                "status": "plan_ready",
                "schema_version": "persistmind.privacy_delete_plan.v1",
                **plan,
            }
        return service.apply(scope, plan)

    def legal_hold_create(self, scope: str, reason: str) -> dict[str, Any]:
        from .privacy import PrivacyDeletionService

        return PrivacyDeletionService(self.workspace_root).hold_create(scope, reason)

    def legal_hold_release(self, hold_id: str) -> dict[str, Any]:
        from .privacy import PrivacyDeletionService

        return PrivacyDeletionService(self.workspace_root).hold_release(hold_id)

    def gc(self, *, dry_run: bool = True, grace_seconds: float = 3600.0) -> dict[str, Any]:
        live = _live_object_references(self.workspace_root)
        artifacts = ContentAddressedArtifacts(self.workspace_root / "objects")
        existing = sorted(
            f"sha256:{path.name}"
            for path in (self.workspace_root / "objects" / "sha256").glob("*")
            if path.is_dir() and re.fullmatch(r"[0-9a-f]{64}", path.name)
        )
        candidates = sorted(set(existing) - live)
        if dry_run:
            deleted: list[str] = []
            return {
                "ok": True,
                "status": "plan_ready",
                "schema_version": "persistmind.storage_gc.v1",
                "live": len(live),
                "candidates": candidates,
                "deleted": deleted,
            }
        with OperationFence(
            self.workspace_root,
            "object-gc",
            {"candidates": candidates, "grace_seconds": grace_seconds},
        ) as fence:
            deleted = artifacts.sweep(
                live,
                grace_seconds=grace_seconds,
                revalidate=lambda ref: ref in _live_object_references(self.workspace_root),
            )
            result = {
                "ok": True,
                "status": "applied",
                "schema_version": "persistmind.storage_gc.v1",
                "live": len(live),
                "candidates": candidates,
                "deleted": deleted,
            }
            result["lifecycle_event"] = self._emit_lifecycle(
                "ObjectDeleted.v1",
                "object-gc:" + hashlib.sha256("\n".join(deleted).encode()).hexdigest()[:24],
                {"object_count": len(deleted), "object_refs": deleted},
            )
            fence.succeed(result)
            return result

    def retention(self, *, dry_run: bool = True, keep_days: int = 30) -> dict[str, Any]:
        if keep_days < 0:
            raise ValueError("retention keep_days must be non-negative")
        cutoff = datetime.now(UTC) - timedelta(days=keep_days)
        expired: list[str] = []
        for directory in (self.workspace_root / "backups").glob(BACKUP_DIRECTORY_GLOB):
            if (
                directory.is_dir()
                and datetime.fromtimestamp(directory.stat().st_mtime, UTC) < cutoff
            ):
                expired.append(str(directory))
        if dry_run:
            return {
                "ok": True,
                "status": "plan_ready",
                "schema_version": "persistmind.storage_retention.v1",
                "keep_days": keep_days,
                "expired_backups": expired,
                "deleted": [],
            }
        with OperationFence(
            self.workspace_root,
            "retention",
            {"keep_days": keep_days, "expired_backups": expired},
        ) as fence:
            for raw in expired:
                shutil.rmtree(Path(raw))
            result = {
                "ok": True,
                "status": "applied",
                "schema_version": "persistmind.storage_retention.v1",
                "keep_days": keep_days,
                "expired_backups": expired,
                "deleted": expired,
            }
            result["lifecycle_event"] = self._emit_lifecycle(
                "RetentionApplied.v1",
                "retention:" + hashlib.sha256("\n".join(expired).encode()).hexdigest()[:24],
                {"keep_days": keep_days, "deleted": len(expired)},
            )
            fence.succeed(result)
            return result

    def backup_create(self, *, verify: bool = False) -> dict[str, Any]:
        with OperationFence(
            self.workspace_root, "backup-create", {"verify": verify}, scope="backup"
        ) as fence:
            result = BackupService(self.workspace_root).create()
            if verify:
                backup_id = str(result["backup"]["backup_id"])
                result["verification"] = BackupService(self.workspace_root).verify(backup_id)
            backup_id = str(result["backup"]["backup_id"])
            result["lifecycle_event"] = self._emit_lifecycle(
                "BackupVerified.v1",
                backup_id,
                {
                    "backup_id": backup_id,
                    "manifest_fingerprint": hashlib.sha256(
                        (self.workspace_root / "backups" / backup_id / "manifest.json").read_bytes()
                    ).hexdigest(),
                },
            )
            fence.succeed(result)
            return result

    def backup_verify(self, backup_id: str) -> dict[str, Any]:
        result = BackupService(self.workspace_root).verify(backup_id)
        result["lifecycle_event"] = self._emit_lifecycle(
            "BackupVerified.v1", backup_id, {"backup_id": backup_id}
        )
        return result

    def backup_restore_stage(self, backup_id: str, *, target: Path) -> dict[str, Any]:
        return BackupService(self.workspace_root).restore_stage(backup_id, target=target)

    # The HTTP adapter intentionally shares the narrow storage method names
    # with feature services, keeping storage administration inside Control.
    # construction until product ports are complete.
    def storage_topology(self) -> dict[str, Any]:
        _require_storage_read("storage.topology.read")
        return self.topology()

    def storage_status(self) -> dict[str, Any]:
        _require_storage_read("storage.status.read")
        return self.status()

    def storage_bootstrap(
        self,
        *,
        activate: bool | None = None,
    ) -> dict[str, Any]:
        _require_storage_admin("storage.bootstrap")
        del activate
        return self.bootstrap()

    def storage_resources_verify(self) -> dict[str, Any]:
        _require_storage_read("storage.resources.read")
        return self.resources_verify()

    def storage_memory_kinds(self) -> dict[str, Any]:
        _require_storage_read("storage.memory_kinds.read")
        return self.memory_kinds()

    def storage_roles(self) -> dict[str, Any]:
        _require_storage_read("storage.roles.read")
        return self.roles()

    def storage_models_status(self) -> dict[str, Any]:
        _require_storage_read("storage.models.read")
        return self.models_status()

    def storage_keys_status(self) -> dict[str, Any]:
        _require_storage_read("storage.keys.read")
        return self.keys_status()

    def storage_schema_status(self) -> dict[str, Any]:
        _require_storage_read("storage.schema.read")
        return self.schema_status()

    def storage_schema_plan(self) -> dict[str, Any]:
        _require_storage_admin("storage.schema.plan")
        return self.schema_plan()

    def storage_partitions(self) -> dict[str, Any]:
        _require_storage_read("storage.partitions.read")
        return self.partitions()

    def storage_partition_rotate(
        self,
        role: str,
        *,
        actor: str | None = None,
        signature: str | None = None,
    ) -> dict[str, Any]:
        _require_storage_admin("storage.partition.rotate")
        return self.rotate_partition(role, actor=actor, signature=signature)

    def storage_repair(self, *, dry_run: bool = True) -> dict[str, Any]:
        _require_storage_admin("storage.repair")
        return self.repair(dry_run=dry_run)

    def storage_export(self, scope: str, *, output: Path) -> dict[str, Any]:
        _require_storage_admin("storage.export")
        return self.export(scope, output=output)

    def storage_delete(self, scope: str, *, dry_run: bool = True) -> dict[str, Any]:
        _require_storage_admin("storage.delete")
        return self.delete(scope, dry_run=dry_run)

    def storage_gc(self, *, dry_run: bool = True) -> dict[str, Any]:
        _require_storage_admin("storage.gc")
        return self.gc(dry_run=dry_run)

    def storage_retention(self, *, dry_run: bool = True, keep_days: int = 30) -> dict[str, Any]:
        _require_storage_admin("storage.retention")
        return self.retention(dry_run=dry_run, keep_days=keep_days)

    def storage_verify(self, *, full: bool = False) -> dict[str, Any]:
        _require_storage_read("storage.verify")
        return self.verify(full=full)

    def storage_reconcile(self, *, limit: int = 100) -> dict[str, Any]:
        _require_storage_admin("storage.reconcile")
        return self.reconcile(limit=limit)

    def storage_catalog_recover(self) -> dict[str, Any]:
        _require_storage_admin("storage.catalog.recover")
        return self.recover_catalog()

    def storage_backup_create(self, *, verify: bool = False) -> dict[str, Any]:
        _require_storage_admin("storage.backup.create")
        return self.backup_create(verify=verify)

    def storage_backup_verify(self, backup_id: str) -> dict[str, Any]:
        _require_storage_read("storage.backup.read")
        return self.backup_verify(backup_id)

    def storage_backup_restore_stage(self, backup_id: str, *, target: Path) -> dict[str, Any]:
        _require_storage_admin("storage.backup.restore")
        return self.backup_restore_stage(backup_id, target=target)

    def _emit_lifecycle(
        self, event_type: str, aggregate_id: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        from .lifecycle_events import LifecycleEventService

        with LifecycleEventService(self.workspace_root) as events:
            return events.emit(event_type, aggregate_id, payload)


def _require_storage_read(action: str) -> None:
    from persistmind.security.context import require_current_principal

    require_current_principal(roles=frozenset({"reader", "operator", "admin"}), action=action)


def _require_storage_admin(action: str) -> None:
    from persistmind.security.context import require_current_principal

    require_current_principal(roles=frozenset({"admin"}), action=action)


def _source_segment_repair_actions(workspace_root: Path, topology: Any) -> list[dict[str, Any]]:
    segment_root = (workspace_root / "stores" / "source" / "default" / "segments").resolve()
    referenced: dict[Path, str] = {}
    for descriptor in topology.stores:
        if descriptor.store_role.value != "source_segment":
            continue
        path = (workspace_root / Path(descriptor.location)).resolve()
        referenced[path] = descriptor.store_id

    actions: list[dict[str, Any]] = []
    for path, store_id in sorted(referenced.items(), key=lambda item: str(item[0])):
        if not path.is_file():
            actions.append(
                {
                    "action": "restore_store_from_verified_backup",
                    "store_id": store_id,
                    "reason": "sealed source segment is missing",
                    "path": str(path),
                }
            )
    if segment_root.is_dir():
        for path in sorted(segment_root.glob("source-*.db")):
            resolved = path.resolve()
            if resolved not in referenced:
                actions.append(
                    {
                        "action": "remove_orphan_source_segment",
                        "reason": "source segment is not catalog-published",
                        "path": str(resolved),
                    }
                )
    return actions


_INTERNAL_TABLE_PREFIXES = ("sqlite_", "domain_schema_", "storage_outbox", "storage_consumer_")
_SECRET_KEYS = {"token", "secret", "password", "credential", "signature", "wrapped_dek"}


def _logical_rows(connection: Any, scope: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for table in _product_tables(connection):
        quoted = '"' + table.replace('"', '""') + '"'
        columns = [str(item[1]) for item in connection.execute(f"PRAGMA table_info({quoted})")]
        for raw in connection.execute(f"SELECT * FROM {quoted}"):
            document = {columns[index]: raw[index] for index in range(len(columns))}
            serialized = json.dumps(document, sort_keys=True, default=str)
            if scope != "*" and scope not in serialized:
                continue
            rows.append({"table": table, "record": _redact(document)})
    rows.sort(
        key=lambda item: (
            str(item["table"]),
            json.dumps(item["record"], sort_keys=True, default=str),
        )
    )
    return rows


def _matching_mutable_rows(connection: Any, scope: str) -> list[tuple[str, int]]:
    matched: list[tuple[str, int]] = []
    for table in _product_tables(connection):
        quoted = '"' + table.replace('"', '""') + '"'
        for row in connection.execute(f"SELECT rowid,* FROM {quoted}"):
            if scope in json.dumps(list(row[1:]), default=str, sort_keys=True):
                matched.append((table, int(row[0])))
    # Child/history rows precede canonical parents. SQLite will still fail
    # closed if a relationship is not fully in scope.
    matched.sort(
        key=lambda item: (
            0
            if any(
                token in item[0]
                for token in ("evidence", "revision", "transition", "checkpoint", "verification")
            )
            else 1,
            item[0],
            item[1],
        )
    )
    return matched


def _product_tables(connection: Any) -> list[str]:
    return [
        str(row[0])
        for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        )
        if not str(row[0]).startswith(_INTERNAL_TABLE_PREFIXES)
        and str(row[0]) not in {"domain_metadata"}
    ]


def _redact(value: Any, key: str = "") -> Any:
    if any(token in key.casefold() for token in _SECRET_KEYS):
        return "[REDACTED]"
    if isinstance(value, dict):
        return {str(k): _redact(v, str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact(item) for item in value]
    if isinstance(value, str) and key.endswith("_json"):
        try:
            return _redact(json.loads(value))
        except json.JSONDecodeError:
            return value
    return value


def _live_object_references(root: Path) -> set[str]:
    pattern = re.compile(rb"sha256:[0-9a-f]{64}")
    live: set[str] = set()
    for directory in (root / "stores", root / "catalog", root / "backups"):
        if not directory.exists():
            continue
        for path in directory.rglob("*"):
            if not path.is_file() or path.stat().st_size > 512 * 1024 * 1024:
                continue
            try:
                with path.open("rb") as handle:
                    for block in iter(lambda: handle.read(1024 * 1024), b""):
                        live.update(item.decode("ascii") for item in pattern.findall(block))
            except OSError:
                continue
    return live


def _learning_provider_warnings(learning_status: Mapping[str, Any]) -> list[dict[str, Any]]:
    adjudication = (
        learning_status.get("mistake_intelligence", {}).get("adjudication", {})
        if isinstance(learning_status, Mapping)
        else {}
    )
    if not isinstance(adjudication, Mapping):
        return []
    provider = int(adjudication.get("provider") or 0)
    deterministic = int(adjudication.get("deterministic") or 0)
    sample = provider + deterministic
    if sample < 3 or provider > 0:
        return []
    last_error = str(adjudication.get("last_provider_error") or "")
    detail = f"provider_share is 0.0 across {sample} adjudications"
    if last_error:
        detail = f"{detail}; last provider error: {last_error}"
    return [
        {
            "kind": "learning_provider_fallback_only",
            "severity": "warn",
            "detail": detail,
            "remediation": "verify host-agent CLI stdin support and run learning adjudicate --drain",
        }
    ]


def _doctor_diagnostics(
    checks: Mapping[str, Mapping[str, Any]],
    warnings: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    diagnostics: list[dict[str, Any]] = []
    for name, check in checks.items():
        if bool(check.get("ok")):
            continue
        diagnostic: dict[str, Any] = {
            "component": name,
            "status": str(check.get("status") or "failed"),
            "severity": "error",
        }
        if check.get("error"):
            diagnostic["error"] = str(check.get("error"))
        nested_failures: list[dict[str, Any]] = []
        for key in ("checks", "route_checks", "operation_route_checks", "stores"):
            value = check.get(key)
            if not isinstance(value, list):
                continue
            for item in value:
                if isinstance(item, Mapping) and not bool(item.get("ok", True)):
                    nested_failures.append(
                        {
                            "name": str(
                                item.get("name")
                                or item.get("id")
                                or item.get("check")
                                or item.get("component")
                                or item.get("resource")
                                or item.get("store")
                                or item.get("operation_id")
                                or item.get("role")
                                or f"{name}.{key}"
                            ),
                            "status": str(item.get("status") or "failed"),
                            **(
                                {"problems": list(item.get("problems") or [])[:5]}
                                if isinstance(item.get("problems"), list)
                                else {}
                            ),
                            **({"detail": str(item.get("detail"))} if item.get("detail") else {}),
                            **({"error": str(item.get("error"))} if item.get("error") else {}),
                            **(
                                {"message": str(item.get("message"))} if item.get("message") else {}
                            ),
                        }
                    )
        if nested_failures:
            diagnostic["failures"] = nested_failures[:5]
            diagnostic["failure_count"] = len(nested_failures)
        diagnostics.append(diagnostic)
    for warning in warnings:
        diagnostics.append(
            {
                "component": str(warning.get("kind") or "warning"),
                "status": str(warning.get("severity") or "warn"),
                "severity": "warn",
                "detail": str(warning.get("detail") or ""),
                "remediation": warning.get("remediation"),
            }
        )
    return diagnostics


def ensure_setup_storage_ready(repo_root: Path, *, install_hooks: bool) -> dict[str, Any] | None:
    if not install_hooks:
        return None
    control = StorageControlPlane(repo_root)
    if inspect_storage(control.workspace_root).initialized:
        return {
            "ok": True,
            "status": "already_initialized",
            "schema_version": "persistmind.storage_bootstrap.v1",
        }
    return control.bootstrap()
