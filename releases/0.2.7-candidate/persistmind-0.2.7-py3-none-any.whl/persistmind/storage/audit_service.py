from __future__ import annotations

import json
import os
from collections.abc import Mapping
from dataclasses import replace
from pathlib import Path
from typing import Any

from persistmind.application.execution_scope import current_operation_scope
from persistmind.audit.fingerprint import gating_fingerprint
from persistmind.config import load_settings
from persistmind.security.approvals import require_approval_signature
from persistmind.security.memory_defense import require_actor_role
from persistmind.utils import canonical_json, stable_id, utc_now

from .adapters.sqlite_activity import SQLiteAuditStore
from .descriptors import StoreCapabilities, StoreDescriptor, StoreRole
from .runtime import StorageOpenIntent, StorageRuntime, resolve_runtime_store
from .topology_service import publish_topology


class AuditService:
    """Narrow, independently verifiable Audit-chain port for PersistMind next-generation workspaces.

    It intentionally owns only typed audit-chain reads plus the self-mod gating
    baseline tripwire. Pack/outcome/session producers remain Activity/Source
    work because they require a cross-store outbox rather than a hidden
    retired-workspace fallback.
    """

    def __init__(
        self,
        repo_root: Path,
        *,
        allow_development_driver: bool = False,
        read_only: bool = False,
    ) -> None:
        self.repo_root = repo_root.resolve()
        self.settings = load_settings(self.repo_root)
        operation_scope = current_operation_scope()
        required_roles = (
            frozenset(StoreRole(role) for role in operation_scope.roles)
            if operation_scope is not None
            else frozenset(
                {
                    StoreRole.AUDIT_ACTIVE,
                    StoreRole.AUDIT_SEALED,
                    *(() if read_only else (StoreRole.CONTROL,)),
                }
            )
        ) | {StoreRole.AUDIT_ACTIVE}
        self.runtime = StorageRuntime.open(
            self.repo_root / self.settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=allow_development_driver,
            read_only=read_only,
            required_roles=required_roles,
        )
        store = resolve_runtime_store(self.runtime, StoreRole.AUDIT_ACTIVE, read_only=read_only)
        if not isinstance(store, SQLiteAuditStore):
            raise RuntimeError("Audit route did not resolve to SQLiteAuditStore")
        self.store = store

    def close(self) -> None:
        self.runtime.close()

    def __enter__(self) -> AuditService:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def verify_audit(self) -> dict[str, Any]:
        partitions = []
        ok = True
        for store in self._read_stores():
            verified = dict(store.verify_chain())
            descriptor = store.descriptor
            if descriptor.read_only and descriptor.logical_content_hash:
                verified["descriptor_root_matches"] = (
                    verified.get("tip") == descriptor.logical_content_hash
                )
                verified["ok"] = bool(verified.get("ok")) and bool(
                    verified["descriptor_root_matches"]
                )
            ok = ok and bool(verified.get("ok"))
            partitions.append(
                {
                    "store_id": descriptor.store_id,
                    "state": descriptor.state,
                    "verification": verified,
                }
            )
        active = dict(self.store.verify_chain())
        return {
            **active,
            "ok": ok,
            "partitions": partitions,
            "nextgen_v1": True,
        }

    def audit_tip(self, output: str | None = None) -> dict[str, Any]:
        result = dict(self.store.tip())
        result["nextgen_v1"] = True
        if not result.get("ok"):
            return result
        tip = str(result.get("tip") or "")
        if output:
            target = Path(output)
            if not target.is_absolute():
                target = self.repo_root / target
            target = target.resolve()
            try:
                target.relative_to(self.repo_root)
            except ValueError as exc:
                raise ValueError("audit tip output must stay within the repository") from exc
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(tip + "\n", encoding="utf-8")
            result["exported_to"] = str(target)
        return result

    def get_audit_record(self, correlation_id: str) -> dict[str, Any]:
        candidates = [
            record
            for store in self._read_stores()
            if (record := store.latest(correlation_id)) is not None
        ]
        record = max(
            candidates,
            key=lambda item: (
                str(item.get("created_at") or item.get("committed_at") or ""),
                str(item.get("audit_id") or ""),
            ),
            default=None,
        )
        if record is None:
            raise KeyError(f"audit record not found for correlation: {correlation_id}")
        return {
            "ok": True,
            "schema_version": "persistmind.audit_record.v1",
            "record": dict(record),
            "chain": self.verify_audit(),
            "nextgen_v1": True,
        }

    def record_gating_baseline(self, *, actor: str = "local-user") -> dict[str, Any]:
        _require_codeowner(actor, "audit_gating_baseline")
        fingerprint = gating_fingerprint(self.repo_root)
        audit_id = "audit_" + stable_id("gating-baseline", fingerprint["digest"])[:32]
        record = {
            "audit_id": audit_id,
            "correlation_id": "gating-baseline",
            "kind": "gating_baseline",
            "principal": actor,
            "fingerprint": fingerprint["digest"],
            "files": fingerprint["files"],
        }
        stored_id = self.store.append_audit(
            record,
            idempotency_key=f"gating-baseline:{fingerprint['digest']}",
        )
        return {
            "ok": True,
            "schema_version": "persistmind.audit_gating_baseline.v1",
            "audit_id": stored_id,
            "fingerprint": fingerprint["digest"],
            "files": fingerprint["files"],
            "nextgen_v1": True,
        }

    def anchor_audit(
        self,
        *,
        actor: str,
        signature: str,
        nonce: str,
        issued_at: str,
    ) -> dict[str, Any]:
        tip = dict(self.store.tip())
        if not tip.get("ok"):
            raise RuntimeError("Audit chain has no verifiable tip to anchor")
        document = {
            "schema_version": "persistmind.audit_anchor_document.v1",
            "action": "anchor_audit",
            "store_id": self.store.descriptor.store_id,
            "tip": str(tip["tip"]),
            "records": int(tip.get("records") or 0),
            "actor": actor,
            "nonce": nonce,
            "issued_at": issued_at,
        }
        signer = require_approval_signature(
            self.runtime.root,
            signature,
            document,
            expected_principal=actor,
            allow_test_provider=self.store._allow_development_driver,
        )
        anchor_id = "audit_" + stable_id("external-anchor", canonical_json(document))[:32]
        stored = self.store.append_audit(
            {
                "audit_id": anchor_id,
                "correlation_id": "audit-anchor",
                "kind": "external_anchor",
                "principal": actor,
                "anchored_tip": tip["tip"],
                "anchored_records": tip.get("records"),
                "decision_document": document,
                "signature": signature,
                "signer": signer,
            },
            idempotency_key="audit-anchor:" + stable_id(canonical_json(document)),
        )
        return {
            "ok": True,
            "status": "anchored",
            "schema_version": "persistmind.audit_anchor.v1",
            "audit_id": stored,
            "anchored_tip": tip["tip"],
            "signer": signer,
        }

    def verify_gating_integrity(self) -> dict[str, Any]:
        current = gating_fingerprint(self.repo_root)
        baseline = max(
            (
                record
                for store in self._read_stores()
                if (record := store.latest("gating-baseline")) is not None
            ),
            key=lambda item: (
                str(item.get("created_at") or item.get("committed_at") or ""),
                str(item.get("audit_id") or ""),
            ),
            default=None,
        )
        if baseline is None:
            return {
                "ok": False,
                "status": "validation_failed",
                "reason": "no_gating_baseline",
                "current": current["digest"],
                "nextgen_v1": True,
            }
        payload = _as_dict(baseline.get("payload"))
        recorded = str(payload.get("fingerprint") or "")
        ok = recorded == current["digest"]
        return {
            "ok": ok,
            "status": "ok" if ok else "verification_failed",
            "reason": "gating_intact" if ok else "gating_fingerprint_mismatch",
            "current": current["digest"],
            "baseline": recorded,
            "audit_id": baseline["audit_id"],
            "nextgen_v1": True,
        }

    def record_engine_evidence(
        self,
        *,
        record_id: str,
        kind: str,
        task_session_id: str | None,
        payload: Mapping[str, Any],
        idempotency_key: str | None = None,
    ) -> dict[str, Any] | str:
        stored = self.store.append_engine_evidence(
            record_id=record_id,
            kind=kind,
            task_session_id=task_session_id,
            payload=payload,
            idempotency_key=idempotency_key,
        )
        return stored

    def engine_evidence(
        self,
        *,
        kind: str | None = None,
        task_session_id: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        records = [
            dict(record)
            for record in self.store.engine_evidence_records(
                kind=kind,
                task_session_id=task_session_id,
                limit=limit,
            )
        ]
        return {
            "ok": True,
            "schema_version": "persistmind.engine_evidence_query.v1",
            "kind": kind,
            "task_session_id": task_session_id,
            "records": records,
            "count": len(records),
            "chain": dict(self.store.verify_engine_evidence_chain()),
            "nextgen_v1": True,
        }

    def pack_manifest_evidence(
        self,
        *,
        task_session_id: str,
        limit: int = 20,
    ) -> dict[str, Any]:
        return self.engine_evidence(
            kind="pack_manifest",
            task_session_id=task_session_id,
            limit=limit,
        )

    def verify_hook_log(self) -> dict[str, Any]:
        records = self.store.engine_evidence_records(kind="hook_event", limit=1)
        return {
            **dict(self.store.verify_engine_evidence_chain()),
            "schema_version": "persistmind.hook_event_chain_verify.v1",
            "kind": "hook_event",
            "hook_event_records_sampled": len(records),
            "nextgen_v1": True,
        }

    def rotate_partition(self, *, actor: str, signature: str) -> dict[str, Any]:
        _require_codeowner(actor, "audit_partition_rotation")
        if not signature.strip():
            raise ValueError("audit rotation requires an external anchor signature")
        current = self.runtime.topology
        next_generation = current.generation + 1
        proof = dict(self.store.seal_partition())
        partition_id = str(proof["partition_id"])
        sealed_relative = f"stores/activity/audit/sealed/{partition_id}.db"
        sealed_path = self.runtime.catalog.resolve_location(sealed_relative)
        sealed = dict(self.store.seal_partition(sealed_path, sealed_store_id=partition_id))
        active_store_id = f"audit-active-g{next_generation}"
        active_relative = f"stores/activity/audit/active-g{next_generation}.db"
        old = next(
            item
            for item in current.stores
            if item.store_role is StoreRole.AUDIT_ACTIVE and item.state == "active"
        )
        active_descriptor = StoreDescriptor(
            store_id=active_store_id,
            domain=old.domain,
            store_role=StoreRole.AUDIT_ACTIVE,
            backend="sqlite",
            location=active_relative,
            schema_head=old.schema_head,
            authorization_scope=old.authorization_scope,
            generation=next_generation,
            state="active",
            shard_key=old.shard_key,
            partition_key="current",
            created_at=utc_now(),
            capabilities=StoreCapabilities(partitioning=True, online_backup=True),
        )
        replacement = SQLiteAuditStore(
            self.runtime.catalog.resolve_location(active_relative),
            descriptor=active_descriptor,
            allow_development_driver=self.store._allow_development_driver,
        )
        link_id = (
            "audit_"
            + stable_id("audit-partition-link", partition_id, str(sealed["root_hash"]))[:32]
        )
        replacement.append_audit(
            {
                "audit_id": link_id,
                "correlation_id": partition_id,
                "kind": "audit_partition_link",
                "principal": actor,
                "previous_partition_id": partition_id,
                "previous_partition_root": sealed["root_hash"],
                "anchor_signature_hash": stable_id(signature),
            },
            idempotency_key=f"audit-partition-link:{partition_id}",
        )
        replacement.close()
        sealed_descriptor = replace(
            old,
            store_id=partition_id,
            store_role=StoreRole.AUDIT_SEALED,
            location=sealed_relative,
            generation=next_generation,
            state="sealed",
            read_only=True,
            partition_key=partition_id,
            sealed_at=utc_now(),
            logical_content_hash=str(sealed["root_hash"]),
            physical_image_hash=str(sealed["physical_image_hash"]),
            capabilities=StoreCapabilities(partitioning=True, online_backup=True),
        )
        stores = tuple(item for item in current.stores if item.store_id != old.store_id) + (
            active_descriptor,
            sealed_descriptor,
        )
        publish_topology(
            self.runtime,
            replace(current, generation=next_generation, stores=stores, created_at=utc_now()),
            expected_generation=current.generation,
        )
        anchor = {
            "schema_version": "persistmind.audit_anchor.v1",
            "partition_id": partition_id,
            "root_hash": sealed["root_hash"],
            "signature": signature,
            "principal": actor,
            "catalog_generation": next_generation,
            "created_at": utc_now(),
        }
        anchor["anchor_hash"] = stable_id(canonical_json(anchor))
        self._write_anchor(partition_id, anchor)
        return {
            "ok": True,
            "schema_version": "persistmind.audit_rotation.v1",
            "catalog_generation": next_generation,
            "sealed": sealed,
            "anchor": anchor,
            "active_store_id": active_store_id,
            "requires_reopen": True,
            "nextgen_v1": True,
        }

    def _read_stores(self) -> list[SQLiteAuditStore]:
        stores: list[SQLiteAuditStore] = []
        for role in (StoreRole.AUDIT_ACTIVE, StoreRole.AUDIT_SEALED):
            try:
                resolved = self.runtime.router.resolve_read_set(role)
            except KeyError:
                continue
            stores.extend(store for store in resolved if isinstance(store, SQLiteAuditStore))
        return stores

    def _write_anchor(self, partition_id: str, anchor: Mapping[str, Any]) -> None:
        root = self.runtime.root / "anchors" / "audit"
        root.mkdir(parents=True, exist_ok=True)
        target = root / f"{partition_id}.json"
        temporary = target.with_name(f".{target.name}.{os.getpid()}.tmp")
        try:
            with temporary.open("x", encoding="utf-8") as handle:
                handle.write(json.dumps(dict(anchor), sort_keys=True, separators=(",", ":")))
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, target)
        finally:
            temporary.unlink(missing_ok=True)


def _as_dict(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, Mapping) else {}


def _require_codeowner(actor: str, action: str) -> None:
    authorization = require_actor_role(actor, "codeowner", action)
    if not authorization["ok"]:
        raise PermissionError(
            f"{action} requires {authorization['required_role']} role; "
            f"{authorization['actor']} is {authorization['actor_role']}"
        )
