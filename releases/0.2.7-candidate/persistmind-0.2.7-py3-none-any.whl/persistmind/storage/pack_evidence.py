from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from persistmind.utils import stable_id

from .audit_service import AuditService


def pack_manifest_payload(
    *,
    task_session_id: str,
    pack_id: str,
    manifest: Mapping[str, Any],
) -> dict[str, Any]:
    items = [item for item in manifest.get("items", []) if isinstance(item, Mapping)]
    pack_paths = sorted({str(item.get("path") or "") for item in items if item.get("path")})
    relevance_scores = {
        str(item.get("path") or item.get("record_id") or index): item.get("relevance_score")
        for index, item in enumerate(items)
        if item.get("relevance_score") is not None
    }
    symbol_ids = sorted(
        {
            str(item.get("symbol_id") or item.get("record_id") or "")
            for item in items
            if item.get("symbol_id") or item.get("record_id")
        }
    )
    return {
        "schema_version": "persistmind.pack_manifest_evidence.v1",
        "task_session_id": task_session_id,
        "pack_id": pack_id,
        "pack_paths": pack_paths,
        "seed_paths": sorted(str(path) for path in manifest.get("seed_paths", []) if path),
        "symbol_ids": symbol_ids,
        "relevance_scores": relevance_scores,
        "snapshot_id": manifest.get("snapshot_id"),
        "source_generation_id": manifest.get("source_generation_id"),
        "source_index_fingerprint": manifest.get("source_index_fingerprint"),
        "recorded_at": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
    }


def record_pack_manifest_evidence(
    repo_root: Path,
    *,
    task_session_id: str,
    pack_id: str,
    manifest: Mapping[str, Any],
    allow_development_driver: bool = False,
) -> str:
    payload = pack_manifest_payload(
        task_session_id=task_session_id,
        pack_id=pack_id,
        manifest=manifest,
    )
    record_id = "engine_evidence_" + stable_id("pack-manifest", task_session_id, pack_id)[:32]
    with AuditService(
        repo_root,
        allow_development_driver=allow_development_driver,
        read_only=False,
    ) as audit:
        return audit.record_engine_evidence(
            record_id=record_id,
            kind="pack_manifest",
            task_session_id=task_session_id,
            payload=payload,
            idempotency_key=f"pack-manifest:{task_session_id}:{pack_id}",
        )
