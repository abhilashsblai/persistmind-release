from __future__ import annotations

import json
import re
import shlex
from pathlib import Path
from typing import Any

from persistmind.utils import stable_id

WRITE_CAPABLE_TOOLS = {
    "apply_patch",
    "edit",
    "write",
    "bash",
    "shell",
    "mcp",
}

BROAD_TASK_TERMS = {
    "all",
    "complete",
    "entire",
    "extensive",
    "implement",
    "phase",
    "phases",
    "plan",
    "plans",
    "refactor",
    "system",
}

_READ_ONLY_SHELL_PREFIX = re.compile(
    r"""(?ix)
    ^\s*(?:
        rg|grep|findstr|where(?:\.exe)?|
        get-(?:content|childitem|item|location|command|process|variable|nettcpconnection|netudpendpoint)|
        test-netconnection|netstat(?:\.exe)?|tasklist(?:\.exe)?|
        test-path|resolve-path|select-string|compare-object|measure-object|
        git\s+(?:status|diff|log|show|rev-parse|rev-list|merge-base|ls-files|
                 check-ignore|remote|branch)
    )\b
    """
)
_SHELL_WRITE_SIGNAL = re.compile(
    r"""(?ix)
    (?:
        \b(?:remove-item|set-content|add-content|out-file|new-item|move-item|
             copy-item|rename-item|clear-content|remove-variable)\b|
        \b(?:rm|del|erase|rmdir|mv|cp|touch|mkdir|tee)\b|
        \bsed\s+-i\b|
        \bgit\s+(?:add|commit|push|reset|checkout|switch|restore|clean|merge|
                  rebase|cherry-pick|revert|tag)\b|
        \b(?:npm|pnpm|yarn)\s+(?:install|add|remove|publish)\b|
        \b(?:pip|pip3|python\s+-m\s+pip)\s+install\b|
        (?:^|[\s;&|])(?:cmd(?:\.exe)?\s+/c\s+)?(?:echo|printf)\b[^\r\n]*>{1,2}
    )
    """
)
_MCP_READ_VERBS = {
    "fetch",
    "find",
    "get",
    "health",
    "inspect",
    "list",
    "lookup",
    "query",
    "read",
    "search",
    "show",
    "status",
    "view",
}
_MCP_WRITE_VERBS = {
    "add",
    "archive",
    "cancel",
    "copy",
    "create",
    "delete",
    "execute",
    "forward",
    "label",
    "move",
    "patch",
    "post",
    "put",
    "remove",
    "rename",
    "reply",
    "run",
    "send",
    "set",
    "share",
    "update",
    "upload",
    "write",
}
_PERSISTMIND_CONTEXT_MCP_TOOLS = {
    "codex_enforcement_status",
    "get_impact_report",
    "get_pack_manifest",
    "impact_of",
    "mcp_capabilities",
    "memory_recall",
    "plan_show",
    "search_code",
    "search_repo",
    "session_explain",
    "storage_roles",
    "storage_status",
    "storage_verify",
    "task_show",
    "workflow_brief",
}
_PERSISTMIND_BOOTSTRAP_MCP_TOOLS = {
    "codex_preflight",
    "get_context_pack",
    "task_start",
}
_READ_ONLY_GOVERNANCE_SUBCOMMANDS = {
    "codex": {"enforcement-status"},
    "plan": {"show"},
    "session": {"explain"},
    "storage": {
        "keys",
        "memory-kinds",
        "models",
        "partitions",
        "recover.catalog",
        "recover.plan",
        "recover.status",
        "resources",
        "roles",
        "schema.plan",
        "schema.status",
        "schema",
        "status",
        "topology",
        "verify",
    },
    "task": {"show"},
    "workflow": {"brief", "lint"},
}
_READ_ONLY_GOVERNANCE_COMMANDS = {
    "db-stats",
    "doctor",
    "impact",
    "manifest",
    "operations",
    "reconstruct-pack",
    "search",
    "status",
    "storage-report",
}
_SAFE_GOVERNANCE_SUBCOMMANDS = {
    "codex": {"preflight"},
    "workflow": {"start", "next", "rebind"},
    "task": {"start"},
    "plan": {"create", "amend", "checkpoint"},
    "memory": {"create"},
    "verify": {"run"},
    "setup": {"auto", "codex"},
    "storage": {
        "recover.apply",
        "recover.finalize",
        "recover.rollback",
        "recover.stage",
        "schema.upgrade",
    },
}
_SAFE_GOVERNANCE_COMMANDS = {
    "index",
    "pack",
    "check-diff",
    "impact",
    "outcome",
    "doctor",
}


def enforcement_status(repo_root: Path, readiness: dict[str, Any]) -> dict[str, Any]:
    checks = readiness.get("checks", {}) if isinstance(readiness, dict) else {}
    from persistmind.agent_runtime.hooks import authoritative_policy_snapshot
    from persistmind.config import load_settings

    policy_snapshot = authoritative_policy_snapshot(repo_root)
    settings = load_settings(repo_root)
    preflight_ready = bool(
        policy_snapshot.get("current") and policy_snapshot.get("preflight_ready")
    )
    hook_status = {
        "session_start": bool(checks.get("codex_hooks")),
        "user_prompt_submit": bool(checks.get("codex_hooks")),
        "pre_tool_use": bool(checks.get("codex_hooks")),
        "post_tool_use": bool(checks.get("codex_hooks")),
        "subagent_start": bool(checks.get("codex_hooks")),
        "subagent_stop": bool(checks.get("codex_hooks")),
        "stop": bool(checks.get("codex_hooks")),
    }
    blocking = []
    if not checks.get("agents_contract"):
        blocking.append("AGENTS.md PersistMind contract is missing")
    if not checks.get("codex_project_config"):
        blocking.append(".codex/config.toml is missing")
    if not checks.get("codex_hooks"):
        blocking.append("Codex hook surface is missing")
    if not checks.get("codex_agents"):
        blocking.append("PersistMind Codex custom agents are missing")
    if not checks.get("codex_mcp_snippet"):
        blocking.append("PersistMind MCP snippet is missing")

    return {
        "ok": not blocking,
        "schema_version": "persistmind.codex_enforcement.v1",
        "repo": str(repo_root),
        "preflight_required": True,
        "effective_enforcement_mode": settings.governance.enforcement_mode,
        "preflight_ready": preflight_ready,
        "preflight": {
            "authorization_mode": policy_snapshot.get("authorization_mode", "none"),
            "current": bool(policy_snapshot.get("current")),
            "pack_id": policy_snapshot.get("pack_id"),
            "revision": policy_snapshot.get("revision"),
            "task_session_id": policy_snapshot.get("task_session_id"),
        },
        "blocking_reasons": blocking,
        "hook_status": hook_status,
        "mcp_status": {
            "snippet_present": bool(checks.get("codex_mcp_snippet")),
            "project_config_present": bool(checks.get("codex_project_config")),
        },
        "agent_surfaces": {
            "custom_agents_present": bool(checks.get("codex_agents")),
            "max_depth": 1,
            "max_threads": 4,
        },
        "setup": readiness,
        "enforcement_scope": (
            "session-scoped registered host hooks for first-party and MCP tool surfaces, "
            "plus AGENTS.md, Git hooks, CI, and audit"
        ),
        "tamper_model": (
            "tamper-evident repo-local hook/config fingerprinting; not an OS sandbox "
            "or process boundary"
        ),
    }


def infer_hook_read_only(payload: dict[str, Any]) -> bool:
    """Infer read-only intent from the actual Codex hook wire shape.

    Codex does not send PersistMind's historical synthetic read_only field. Shell and
    MCP calls therefore need a conservative classifier so block mode does not
    deadlock repository inspection or the CTX bootstrap workflow.
    """

    explicit = payload.get("read_only")
    if isinstance(explicit, bool):
        return explicit

    tool_name = str(payload.get("tool_name") or payload.get("tool") or "").strip()
    command = _hook_command(payload)
    tool_input = payload.get("tool_input")
    if not isinstance(tool_input, dict):
        tool_input = {}
    try:
        from persistmind.agent_runtime.tool_capability import classify_tool

        return classify_tool(
            tool_name,
            command,
            {**tool_input, "command": command},
        ).read_only
    except Exception:
        pass
    normalized = tool_name.lower()
    if "bash" in normalized or "shell" in normalized:
        command = _hook_command(payload)
        if not command:
            return False
        if _SHELL_WRITE_SIGNAL.search(command):
            return False
        if _safe_ctx_read_only_command(command):
            return True
        if _safe_ctx_governance_command(command):
            return False
        return bool(_READ_ONLY_SHELL_PREFIX.search(command))

    if normalized.startswith("mcp__") or normalized == "mcp":
        prefix = "mcp__persistmind__"
        if normalized.startswith(prefix):
            operation = normalized[len(prefix) :]
            if operation in _PERSISTMIND_CONTEXT_MCP_TOOLS:
                return True
        tokens = {token for token in re.split(r"[^a-z0-9]+", normalized) if token}
        if tokens & _MCP_WRITE_VERBS:
            return False
        return bool(tokens & _MCP_READ_VERBS)

    return False


def infer_hook_governance_bootstrap(payload: dict[str, Any]) -> bool:
    """Recognize narrowly bounded commands that must be able to create preflight state."""

    tool_name = str(payload.get("tool_name") or payload.get("tool") or "").strip()
    command = _hook_command(payload)
    tool_input = payload.get("tool_input")
    if not isinstance(tool_input, dict):
        tool_input = {}
    try:
        from persistmind.agent_runtime.tool_capability import classify_tool

        return classify_tool(
            tool_name,
            command,
            {**tool_input, "command": command},
        ).governance_bootstrap
    except Exception:
        pass
    normalized = tool_name.lower()
    if "bash" in normalized or "shell" in normalized:
        command = _hook_command(payload)
        return bool(command and _safe_ctx_governance_command(command))
    prefix = "mcp__persistmind__"
    return normalized.startswith(prefix) and normalized[len(prefix) :] in (
        _PERSISTMIND_BOOTSTRAP_MCP_TOOLS
    )


def _safe_ctx_governance_command(command: str) -> bool:
    """Recognize a single PersistMind control-plane command.

    These commands must remain runnable while the preflight snapshot is being
    created or repaired.  Shell composition is rejected so the exception
    cannot be used to append an unrelated process or repository write.
    """

    operation = _ctx_governance_operation(command)
    if operation is None:
        return False
    command_name, subcommand = operation
    if command_name in _SAFE_GOVERNANCE_COMMANDS:
        return True
    allowed_subcommands = _SAFE_GOVERNANCE_SUBCOMMANDS.get(command_name)
    return bool(allowed_subcommands and subcommand in allowed_subcommands)


def _safe_ctx_read_only_command(command: str) -> bool:
    operation = _ctx_governance_operation(command)
    if operation is None:
        return False
    command_name, subcommand = operation
    if command_name in _READ_ONLY_GOVERNANCE_COMMANDS:
        return True
    allowed_subcommands = _READ_ONLY_GOVERNANCE_SUBCOMMANDS.get(command_name)
    return bool(allowed_subcommands and subcommand in allowed_subcommands)


def _ctx_governance_operation(command: str) -> tuple[str, str | None] | None:
    """Parse one non-composed managed PersistMind invocation."""

    stripped = command.strip()
    control_tail = stripped[1:].lstrip() if stripped.startswith("&") else stripped
    if _has_unquoted_shell_control_operator(control_tail):
        return None
    try:
        tokens = shlex.split(stripped, posix=True)
    except ValueError:
        return None
    if tokens and tokens[0] == "&":
        tokens = tokens[1:]
    if not tokens:
        return None
    executable_name = tokens[0].replace("\\", "/").rsplit("/", 1)[-1].casefold()
    direct = executable_name in {"persistmind", "persistmind.exe"}
    managed_module = (
        executable_name in {"python", "python.exe", "python3", "python3.exe"}
        and len(tokens) >= 4
        and tokens[1:4] == ["-I", "-m", "persistmind"]
    )
    if not direct and not managed_module:
        return None
    argv = tokens[4:] if managed_module else tokens[1:]
    while argv and argv[0] == "--repo":
        if len(argv) < 2:
            return None
        argv = argv[2:]
    if not argv:
        return None
    command_name = argv[0].casefold()
    subcommand = argv[1].casefold() if len(argv) >= 2 else None
    if command_name == "storage" and subcommand in {"recover", "schema"} and len(argv) >= 3:
        subcommand = f"{subcommand}.{argv[2].casefold()}"
    return command_name, subcommand


def _has_unquoted_shell_control_operator(command: str) -> bool:
    quote: str | None = None
    for index, character in enumerate(command):
        if quote:
            if character == quote:
                quote = None
            continue
        if character in {"'", '"'}:
            quote = character
            continue
        if character in {";", "&", "|", "<", ">", "`", "\r", "\n"}:
            return True
        if command.startswith("$(", index):
            return True
    return False


def _hook_command(payload: dict[str, Any]) -> str:
    tool_input = payload.get("tool_input")
    if isinstance(tool_input, dict) and isinstance(tool_input.get("command"), str):
        return str(tool_input["command"])
    command = payload.get("command")
    return str(command) if isinstance(command, str) else ""


def memory_retrieval_manifest(
    *,
    task: str,
    pack: dict[str, Any],
    recall: dict[str, Any],
) -> dict[str, Any]:
    retrieval = (
        pack.get("memory_retrieval", {}) if isinstance(pack.get("memory_retrieval"), dict) else {}
    )
    served_counts = dict(retrieval.get("served_counts_by_type", {}) or {})
    for section, memory_type in [
        ("continuations", "continuation"),
        ("policy_references", "policy_reference"),
        ("project_memory", "project_memory"),
        ("skills", "skill_reference"),
    ]:
        items = pack.get(section, []) if isinstance(pack.get(section), list) else []
        if items:
            served_counts[memory_type] = max(int(served_counts.get(memory_type, 0)), len(items))

    recall_records = recall.get("records", []) if isinstance(recall.get("records"), list) else []
    for record in recall_records:
        record_type = str(record.get("type") or "memory")
        served_counts[record_type] = served_counts.get(record_type, 0) + 1

    return {
        "memory_retrieval_id": stable_id(pack.get("pack_id", ""), task, "codex-memory-retrieval"),
        "query": task,
        "weights": retrieval.get("weights", {}),
        "backend_status": retrieval.get("backend_status", {"lexical": "ok"}),
        "excluded_counts": retrieval.get("excluded_counts", {}),
        "served_counts_by_type": served_counts,
        "stale_count": int(retrieval.get("stale_count", 0) or 0),
        "quarantine_count": int(retrieval.get("quarantine_count", 0) or 0),
        "no_backend_diagnostics": retrieval.get("no_backend_diagnostics", []),
    }


def parallel_plan(
    *,
    task: str,
    task_session_id: str,
    pack_id: str,
    paths: list[str] | None = None,
    impact_report: dict[str, Any] | None = None,
    max_threads: int = 4,
    preflight_ready: bool = True,
    worktree_clean: bool = True,
) -> dict[str, Any]:
    paths = sorted({path for path in paths or [] if path})
    terms = {part.strip(".,:;()[]{}").lower() for part in task.split()}
    impacted = impact_report.get("impacted_paths", []) if impact_report else []
    risk = (impact_report.get("risk", {}) if impact_report else {}) or {}
    risk_score = float(risk.get("score", 0.0) or 0.0)
    broad = bool(terms & BROAD_TASK_TERMS) or len(paths) >= 3 or len(impacted) >= 8
    blockers = []
    if not preflight_ready:
        blockers.append("preflight is not ready")
    if not worktree_clean:
        blockers.append("worktree is not clean")
    if max_threads < 2:
        blockers.append("parallel agent thread budget is below 2")
    if paths and _has_overlapping_directories(paths):
        conflict_policy = "parent-only integration"
    else:
        conflict_policy = "disjoint writes"

    if blockers:
        recommendation = "blocked"
        reason = "; ".join(blockers)
        agent_tasks: list[dict[str, Any]] = []
    elif broad:
        recommendation = "required"
        reason = "broad task benefits from independent exploration, implementation, review, and verification"
        agent_tasks = _agent_tasks(task, paths, required=True)
    elif risk_score >= 5.0 or len(impacted) >= 4:
        recommendation = "optional"
        reason = "moderate impact or risk makes parallel review and verification useful"
        agent_tasks = _agent_tasks(task, paths, required=False)
    else:
        recommendation = "none"
        reason = "task appears narrow enough for a single parent agent"
        agent_tasks = []

    parallel_run_id = stable_id(task_session_id, pack_id, task, json.dumps(paths, sort_keys=True))
    return {
        "ok": True,
        "schema_version": "persistmind.codex_parallel_plan.v1",
        "parallel_run_id": parallel_run_id,
        "task_session_id": task_session_id,
        "pack_id": pack_id,
        "parallel_recommendation": recommendation,
        "recommendation": recommendation,
        "reason": reason,
        "agent_tasks": agent_tasks[: max(0, min(max_threads, 4))],
        "conflict_policy": conflict_policy,
        "waiver_reason": None,
        "merge_contract": {
            "parent_integrates": True,
            "child_agents_do_not_revert_peer_changes": True,
            "final_parent_checks": ["check-diff", "impact", "tests", "outcome"],
        },
    }


def pre_tool_gate(
    *,
    tool_name: str,
    preflight_ready: bool,
    active_plan_step: bool,
    read_only: bool = False,
    target_paths: list[str] | None = None,
    proposed_content: str | None = None,
    diff: str | None = None,
    directives: list[dict[str, Any]] | None = None,
    guardrails_mode: str = "warn",
    block_min_severity: str = "high",
    min_block_confidence: float = 0.7,
    content_match_required_for_block: bool = True,
    block_requires_approval: bool = False,
    approval_token: str = "",
    surprise: dict[str, Any] | None = None,
    interoception: dict[str, Any] | None = None,
    surprise_nudge_threshold: float = 0.5,
    surprise_block_threshold: float = 0.85,
    surprise_requires_corroboration: bool = True,
    anticipation_mode: str = "warn",
    surprise_nudge_count: int = 0,
    max_nudges_per_session: int = 8,
    workflow_next_action: dict[str, Any] | None = None,
    enforcement_mode: str = "block",
    block_grace_remaining: int = 0,
) -> dict[str, Any]:
    normalized = tool_name.strip().lower()
    write_capable = any(term in normalized for term in WRITE_CAPABLE_TOOLS)
    if read_only or not write_capable:
        return _with_workflow_next(
            {
                "ok": True,
                "decision": "allow",
                "reason": "read-only or non-writing tool",
            },
            workflow_next_action,
        )
    semantic = _semantic_guardrail_decision(
        directives or [],
        text=diff if diff is not None else proposed_content,
        mode=guardrails_mode,
        block_min_severity=block_min_severity,
        min_block_confidence=min_block_confidence,
        content_match_required_for_block=content_match_required_for_block,
    )
    if semantic["decision"] == "block":
        result = {
            "ok": False,
            "decision": "block",
            "reason": semantic["reason"],
            "matched": semantic["matched"],
            "target_paths": target_paths or [],
            "override": _guardrail_override_help(semantic["matched"]),
        }
        return _with_workflow_next(
            _with_surprise(
                result,
                surprise=surprise,
                interoception=interoception,
                target_paths=target_paths or [],
                matched=semantic["matched"],
                nudge_threshold=surprise_nudge_threshold,
                block_threshold=surprise_block_threshold,
                requires_corroboration=surprise_requires_corroboration,
                anticipation_mode=anticipation_mode,
                nudge_count=surprise_nudge_count,
                max_nudges=max_nudges_per_session,
            ),
            workflow_next_action,
        )
    semantic_warning: dict[str, Any] | None = None
    if semantic["decision"] == "warn":
        semantic_warning = {
            "ok": True,
            "decision": "warn",
            "reason": semantic["reason"],
            "matched": semantic["matched"],
            "target_paths": target_paths or [],
            "override": _guardrail_override_help(semantic["matched"]),
        }
    if enforcement_mode.strip().lower() == "off":
        return _with_workflow_next(
            {
                "ok": True,
                "decision": "allow",
                "reason": "governance enforcement is off",
                "enforcement_mode": "off",
                "record_only": True,
            },
            workflow_next_action,
        )
    if not preflight_ready:
        return _apply_enforcement_mode(
            _with_workflow_next(
                _with_surprise(
                    {
                        "ok": False,
                        "decision": "block",
                        "reason": ("write-capable Codex tool use requires ready CTX preflight"),
                    },
                    surprise=surprise,
                    interoception=interoception,
                    target_paths=target_paths or [],
                    matched=[],
                    nudge_threshold=surprise_nudge_threshold,
                    block_threshold=surprise_block_threshold,
                    requires_corroboration=surprise_requires_corroboration,
                    anticipation_mode=anticipation_mode,
                    nudge_count=surprise_nudge_count,
                    max_nudges=max_nudges_per_session,
                ),
                workflow_next_action,
            ),
            enforcement_mode,
            block_grace_remaining,
        )
    if not active_plan_step:
        return _apply_enforcement_mode(
            _with_workflow_next(
                _with_surprise(
                    {
                        "ok": False,
                        "decision": "block",
                        "reason": ("write-capable Codex tool use requires an active CTX plan step"),
                    },
                    surprise=surprise,
                    interoception=interoception,
                    target_paths=target_paths or [],
                    matched=[],
                    nudge_threshold=surprise_nudge_threshold,
                    block_threshold=surprise_block_threshold,
                    requires_corroboration=surprise_requires_corroboration,
                    anticipation_mode=anticipation_mode,
                    nudge_count=surprise_nudge_count,
                    max_nudges=max_nudges_per_session,
                ),
                workflow_next_action,
            ),
            enforcement_mode,
            block_grace_remaining,
        )
    if semantic_warning is not None:
        return _with_workflow_next(
            _with_surprise(
                semantic_warning,
                surprise=surprise,
                interoception=interoception,
                target_paths=target_paths or [],
                matched=semantic["matched"],
                nudge_threshold=surprise_nudge_threshold,
                block_threshold=surprise_block_threshold,
                requires_corroboration=surprise_requires_corroboration,
                anticipation_mode=anticipation_mode,
                nudge_count=surprise_nudge_count,
                max_nudges=max_nudges_per_session,
            ),
            workflow_next_action,
        )
    result = {
        "ok": True,
        "decision": "allow",
        "reason": "preflight and active plan step are ready",
    }
    return _apply_enforcement_mode(
        _with_workflow_next(
            _with_surprise(
                result,
                surprise=surprise,
                interoception=interoception,
                target_paths=target_paths or [],
                matched=[],
                nudge_threshold=surprise_nudge_threshold,
                block_threshold=surprise_block_threshold,
                requires_corroboration=surprise_requires_corroboration,
                anticipation_mode=anticipation_mode,
                nudge_count=surprise_nudge_count,
                max_nudges=max_nudges_per_session,
            ),
            workflow_next_action,
        ),
        enforcement_mode,
        block_grace_remaining,
    )


def _apply_enforcement_mode(
    result: dict[str, Any], enforcement_mode: str, block_grace_remaining: int
) -> dict[str, Any]:
    mode = enforcement_mode.strip().lower()
    if mode not in {"off", "audit", "warn", "block"}:
        mode = "warn"
    original = dict(result)
    result = dict(result)
    result["enforcement_mode"] = mode
    if mode == "block":
        if result.get("decision") == "block" and block_grace_remaining > 0:
            result.update(
                {
                    "ok": True,
                    "decision": "warn",
                    "would_have_blocked": True,
                    "grace_remaining": block_grace_remaining - 1,
                }
            )
        return result
    if mode == "warn" and result.get("decision") == "block":
        result.update({"ok": True, "decision": "warn", "would_have_blocked": True})
    elif mode == "audit" and result.get("decision") in {"block", "warn"}:
        result.update(
            {
                "ok": True,
                "decision": "allow",
                "record_only": True,
                "audited_decision": original.get("decision"),
                "would_have_blocked": original.get("decision") == "block",
            }
        )
    return result


def _with_workflow_next(
    result: dict[str, Any], workflow_next_action: dict[str, Any] | None
) -> dict[str, Any]:
    if not workflow_next_action:
        return result
    enriched = dict(result)
    enriched["workflow_next_action"] = workflow_next_action
    return enriched


def _with_surprise(
    result: dict[str, Any],
    *,
    surprise: dict[str, Any] | None,
    interoception: dict[str, Any] | None,
    target_paths: list[str],
    matched: list[dict[str, Any]],
    nudge_threshold: float,
    block_threshold: float,
    requires_corroboration: bool,
    anticipation_mode: str,
    nudge_count: int,
    max_nudges: int,
) -> dict[str, Any]:
    if surprise is None:
        return result
    from persistmind.anticipation.interoception import (
        InteroceptiveState,
        build_nudge_message,
    )

    mode = anticipation_mode.strip().lower()
    score = surprise.get("surprise")
    if mode == "off" or score is None:
        enriched = dict(result)
        enriched["surprise"] = _surprise_section(
            surprise, level="silent", message="", corroborated_by=[]
        )
        return enriched
    gut = float((interoception or {}).get("gut", 0.0) or 0.0)
    signal = InteroceptiveState.blend(surprise=float(score), gut=gut)["signal"]
    corroborated_by = _surprise_corroboration(
        target_paths=target_paths, matched=matched, surprise=surprise
    )
    level = "silent"
    if signal >= float(nudge_threshold):
        level = "nudge"
    if nudge_count >= max(0, int(max_nudges)) and level == "nudge":
        level = "silent"
    if signal >= float(block_threshold) and mode in {"block", "enforce"}:
        if not requires_corroboration or corroborated_by:
            level = "block"
        else:
            level = "nudge"
    message = (
        build_nudge_message(
            target_paths=target_paths,
            surprise={**surprise, "surprise": signal},
            level=level,
            interoception=interoception,
        )
        if level != "silent"
        else ""
    )
    enriched = dict(result)
    enriched["surprise"] = _surprise_section(
        surprise,
        level=level,
        message=message,
        corroborated_by=corroborated_by,
        score=signal,
    )
    if level == "block" and result.get("decision") != "block":
        enriched.update(
            {
                "ok": False,
                "decision": "block",
                "reason": "anticipation surprise corroborated by independent risk signal",
            }
        )
    elif level == "nudge" and result.get("decision") == "allow":
        enriched.update(
            {
                "ok": True,
                "decision": "warn",
                "reason": "anticipation surprise nudge",
            }
        )
    return enriched


def _surprise_section(
    surprise: dict[str, Any],
    *,
    level: str,
    message: str,
    corroborated_by: list[str],
    score: float | None = None,
) -> dict[str, Any]:
    return {
        "score": score if score is not None else surprise.get("surprise"),
        "level": level,
        "message": message,
        "components": surprise.get("components", {}),
        "corroborated_by": corroborated_by,
        "model_id": surprise.get("model_id"),
        "prediction_id": surprise.get("prediction_id"),
    }


def _surprise_corroboration(
    *,
    target_paths: list[str],
    matched: list[dict[str, Any]],
    surprise: dict[str, Any],
) -> list[str]:
    reasons: list[str] = []
    for item in matched:
        if item.get("directive_id"):
            reasons.append(f"guardrail:{item['directive_id']}")
    if any(_critical_path(path) for path in target_paths):
        reasons.append("critical_path")
    components = surprise.get("components", {}) if isinstance(surprise, dict) else {}
    if float(components.get("failure_prior", 0.0) or 0.0) >= 0.5:
        reasons.append("failure_lesson")
    return sorted(set(reasons))


def _critical_path(path: str) -> bool:
    lowered = path.replace("\\", "/").lower()
    return any(token in lowered for token in ("/auth/", "/billing/", "/payments/", "migration"))


def _semantic_guardrail_decision(
    directives: list[dict[str, Any]],
    *,
    text: str | None,
    mode: str,
    block_min_severity: str,
    min_block_confidence: float,
    content_match_required_for_block: bool,
) -> dict[str, Any]:
    normalized_mode = mode.strip().lower()
    if normalized_mode == "off" or not directives:
        return {
            "decision": "allow",
            "reason": "no semantic guardrails matched",
            "matched": [],
        }
    content = text or ""
    matched: list[dict[str, Any]] = []
    strongest = "allow"
    for directive in directives:
        violation = _directive_violation(directive, content)
        if not violation:
            continue
        level = str(directive.get("effective_level") or directive.get("enforcement_level"))
        desired = "block" if level == "block" else "warn"
        if not bool(violation.get("content_matcher")):
            desired = "warn"
        item = {
            "directive_id": directive.get("directive_id"),
            "record_id": directive.get("record_id"),
            "level": directive.get("enforcement_level"),
            "effective_level": directive.get("effective_level", directive.get("enforcement_level")),
            "severity": directive.get("severity"),
            "confidence": float(directive.get("confidence") or 0.0),
            "assertion": directive.get("assertion"),
            "matched_path": directive.get("matched_path"),
            "matched_pattern": violation.get("matched_pattern"),
            "violation_kind": violation.get("kind"),
            "remediation": directive.get("remediation"),
            "rationale": directive.get("rationale"),
            "content_matcher": bool(violation.get("content_matcher")),
            "decision": desired,
        }
        matched.append(item)
        strongest = _stronger_decision(strongest, desired)
    if strongest == "allow":
        return {
            "decision": "allow",
            "reason": "no semantic guardrails matched",
            "matched": [],
        }
    if strongest == "block":
        blockable = normalized_mode == "block" and any(
            item["decision"] == "block"
            and (item["content_matcher"] or not content_match_required_for_block)
            and item["confidence"] >= float(min_block_confidence)
            and _severity_rank(str(item.get("severity") or "low"))
            >= _severity_rank(block_min_severity)
            for item in matched
        )
        strongest = "block" if blockable else "warn"
    elif normalized_mode == "off":
        strongest = "allow"
    reason = (
        "edit matches enforceable memory guardrail"
        if strongest == "block"
        else "edit matches memory guardrail warning"
    )
    return {"decision": strongest, "reason": reason, "matched": matched}


def _directive_violation(directive: dict[str, Any], content: str) -> dict[str, Any] | None:
    anti_patterns = [str(item) for item in directive.get("anti_patterns") or []]
    required_patterns = [str(item) for item in directive.get("required_patterns") or []]
    for pattern in anti_patterns:
        if _regex_search(pattern, content):
            return {
                "kind": "anti_pattern",
                "matched_pattern": pattern,
                "content_matcher": True,
            }
    for pattern in required_patterns:
        if not _regex_search(pattern, content):
            return {
                "kind": "required_pattern_absent",
                "matched_pattern": pattern,
                "content_matcher": True,
            }
    if not anti_patterns and not required_patterns:
        return {
            "kind": "path_scope",
            "matched_pattern": None,
            "content_matcher": False,
        }
    return None


def _regex_search(pattern: str, content: str) -> bool:
    try:
        return re.search(pattern, content, flags=re.MULTILINE) is not None
    except re.error:
        return False


def _stronger_decision(left: str, right: str) -> str:
    rank = {"allow": 0, "warn": 1, "block": 2}
    return left if rank.get(left, 0) >= rank.get(right, 0) else right


def _severity_rank(value: str) -> int:
    return {"low": 0, "medium": 1, "high": 2, "critical": 3}.get(value.strip().lower(), 0)


def _guardrail_override_help(matched: list[dict[str, Any]]) -> dict[str, Any]:
    directive_id = next(
        (str(item.get("directive_id")) for item in matched if item.get("directive_id")),
        "<directive_id>",
    )
    return {
        "allowed": True,
        "how": f'persistmind guardrail override {directive_id} --rationale "<reason>"',
        "or_mark_stale": (f'persistmind memory unenforce {directive_id} --reason "rule outdated"'),
    }


def _agent_tasks(task: str, paths: list[str], *, required: bool) -> list[dict[str, Any]]:
    write_scope = paths[:2] if paths else []
    read_scope = paths or ["repo"]
    return [
        {
            "role": "ctx-explorer",
            "objective": f"Map relevant context for: {task}",
            "read_scope": read_scope,
            "write_scope": [],
            "required_pack_sections": [
                "items",
                "project_memory",
                "continuations",
                "policy_references",
            ],
            "expected_output": "findings, risks, and suggested file ownership",
            "timeout_seconds": 900,
        },
        {
            "role": "ctx-worker",
            "objective": f"Implement assigned slice for: {task}",
            "read_scope": read_scope,
            "write_scope": write_scope,
            "required_pack_sections": [
                "items",
                "skills",
                "project_memory",
                "policy_references",
            ],
            "expected_output": "changed files, checkpoints, and verification notes",
            "timeout_seconds": 1800,
        },
        {
            "role": "ctx-reviewer",
            "objective": f"Review correctness, security, and test gaps for: {task}",
            "read_scope": read_scope,
            "write_scope": [],
            "required_pack_sections": [
                "items",
                "memory_retrieval",
                "policy_references",
            ],
            "expected_output": "ordered findings with file references",
            "timeout_seconds": 900,
        },
        {
            "role": "ctx-verifier",
            "objective": f"Run or analyze verification for: {task}",
            "read_scope": read_scope,
            "write_scope": [] if required else write_scope[:1],
            "required_pack_sections": ["items", "parallel_agent_plan"],
            "expected_output": "commands, exits, failures, and likely owning files",
            "timeout_seconds": 1200,
        },
    ]


def _has_overlapping_directories(paths: list[str]) -> bool:
    parents = [str(Path(path).parent).replace("\\", "/") for path in paths]
    return len(set(parents)) < len(parents)
