from __future__ import annotations

import fnmatch
import json
import time
from collections import deque
from pathlib import Path
from typing import Any

from persistmind.application.public_surface import derive_public_surface_files
from persistmind.codex import pre_tool_gate
from persistmind.config import Settings
from persistmind.snapshot import SnapshotInfo
from persistmind.utils import canonical_repo_path
from persistmind.verification.scope_assessment import assess_write_scope

from .coverage_gaps import (
    detect_cli_facade_paths,
    detect_generated_client_paths,
    detect_migration_paths,
)

RISK_WEIGHTS = {
    "changed_files": 2.0,
    "impacted_files": 2.0,
    "untested_files": 3.0,
    "low_confidence_edges": 1.5,
    "critical_paths": 4.5,
    "graph_centrality": 1.0,
}
RISK_CHANGED_FILE_BUDGET = 3
TESTABLE_EXTENSIONS = {
    ".py",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".mjs",
    ".cjs",
    ".go",
    ".java",
    ".php",
    ".rb",
    ".rs",
    ".sql",
}
SOURCE_EXTENSIONS = TESTABLE_EXTENSIONS | {
    ".css",
    ".html",
    ".htm",
    ".json",
    ".md",
    ".toml",
    ".yaml",
    ".yml",
}


class ImpactEngine:
    def __init__(self, repo_root: Path, store: Any, settings: Settings):
        self.repo_root = repo_root
        self.store = store
        self.settings = settings

    def report(
        self,
        *,
        snapshot: SnapshotInfo,
        paths: list[str],
        pack_id: str | None = None,
        business: bool = False,
    ) -> dict[str, Any]:
        normalized_input_paths = sorted(
            {canonical_repo_path(path, self.repo_root) for path in paths if path}
        )
        excluded_paths = [
            {"path": path, "reason": "matches configured impact ignore_globs"}
            for path in normalized_input_paths
            if self._is_ignored_path(path)
        ]
        excluded_path_set = {item["path"] for item in excluded_paths}
        normalized_paths = [
            path for path in normalized_input_paths if path not in excluded_path_set
        ]
        impacted, paths_detail, closure_performance = self._reverse_closure(
            snapshot, normalized_paths
        )
        public_surface_paths = sorted(
            {
                str(item["from"])
                for item in paths_detail
                if str(item.get("kind") or "") == "public_surface"
            }
        )
        tests = self._select_tests(snapshot, impacted)
        performance = _merge_performance(closure_performance, tests.get("performance", {}))
        untested = sorted(path for path in impacted if path not in tests["covered_paths"])
        migration_paths = detect_migration_paths(
            normalized_paths,
            patterns=self.settings.eval.migration_path_patterns,
        )
        cli_facade_paths = detect_cli_facade_paths(normalized_paths, self.repo_root)
        generated_client_paths = detect_generated_client_paths(
            normalized_paths,
            self.repo_root,
            prefixes=self.settings.eval.generated_client_prefixes,
            markers=self.settings.eval.generated_client_markers,
        )
        high_risk_paths = sorted(
            set(migration_paths) | set(cli_facade_paths) | set(generated_client_paths)
        )
        critical = [
            path
            for path in impacted
            if any(fnmatch.fnmatch(path, glob) for glob in self.settings.eval.critical_paths)
        ]
        critical = sorted(set(critical) | set(high_risk_paths))
        centrality = {
            row["path"]: row
            for row in self.store.graph_file_centrality(
                snapshot.repo_id, snapshot_id=snapshot.snapshot_id
            )
        }
        graph_central_paths = sorted(
            path
            for path in impacted
            if float(centrality.get(path, {}).get("score") or 0.0) >= 0.5
            and int(centrality.get(path, {}).get("degree") or 0) >= 2
        )
        components, metrics = _risk_components(
            changed=normalized_paths,
            impacted=impacted,
            paths_detail=paths_detail,
            untested=untested,
            critical=critical,
            graph_central_paths=graph_central_paths,
            weights=impact_risk_weights(self.settings),
            changed_file_budget=int(self.settings.learning.optimize.impact_changed_file_budget),
        )
        risk_score = min(10.0, round(sum(components.values()), 2))
        report: dict[str, Any] = {
            "schema_version": "persistmind.impact_report.v1",
            "repo_id": snapshot.repo_id,
            "snapshot_id": snapshot.snapshot_id,
            "scope": f"single-repo: {snapshot.repo_id}; cross-repo consumers not indexed",
            "input_paths": normalized_input_paths,
            "analyzed_paths": normalized_paths,
            "public_surface_paths": public_surface_paths,
            "migration_paths": migration_paths,
            "cli_facade_paths": cli_facade_paths,
            "generated_client_paths": generated_client_paths,
            "not_analyzed": ["api_contracts_schemas", "cross_repo_consumers"],
            "excluded_paths": excluded_paths,
            "impacted_paths": sorted(impacted),
            "dependency_paths": paths_detail,
            "tests": tests["tests"],
            "risk": {
                "score": risk_score,
                "components": components,
                "metrics": metrics,
                "untested_paths": untested,
                "critical_paths": critical,
                "graph_central_paths": graph_central_paths,
            },
            "performance": {
                "contract_coverage": performance,
            },
        }
        if pack_id:
            pack = self.store.get_pack(pack_id)
            if pack:
                manifest = json.loads(pack["manifest_json"])
                pack_paths = {
                    canonical_repo_path(item["path"], self.repo_root)
                    for item in manifest.get("items", [])
                }
                seed_paths = {
                    canonical_repo_path(path, self.repo_root)
                    for path in manifest.get("seed_paths", [])
                }
                context_paths = pack_paths | seed_paths
                report["pack_awareness"] = {
                    "pack_id": pack_id,
                    "pack_paths": sorted(pack_paths),
                    "seed_paths": sorted(seed_paths),
                    "out_of_pack_paths": sorted(set(normalized_paths) - context_paths),
                    "out_of_impact_paths": sorted(set(normalized_paths) - impacted),
                }
        if business:
            exposure = self.store.business_exposure_walk(
                snapshot.repo_id,
                sorted(impacted),
                active_only=True,
            )
            report["business_exposure"] = exposure
            self.store.append_audit(
                pack_id=pack_id or f"business-exposure:{snapshot.snapshot_id}",
                payload={
                    "event": "business_exposure_served",
                    "repo_id": snapshot.repo_id,
                    "snapshot_id": snapshot.snapshot_id,
                    "input_paths": normalized_input_paths,
                    "analyzed_paths": normalized_paths,
                    "impacted_count": len(impacted),
                    "lowest_trust_tier": exposure.get("lowest_trust_tier"),
                    "exposure_summary": exposure.get("exposure_summary", {}),
                    "authoritative": False,
                    "requires_human_review": True,
                },
            )
        return report

    def check_diff_against_pack(
        self,
        *,
        snapshot: SnapshotInfo,
        pack_id: str,
        paths: list[str],
        diff: str | None = None,
    ) -> dict[str, Any]:
        started = time.perf_counter()
        normalized_input_paths = sorted(
            {canonical_repo_path(path, self.repo_root) for path in paths if path}
        )
        excluded_paths = [
            {"path": path, "reason": "matches configured impact ignore_globs"}
            for path in normalized_input_paths
            if self._is_ignored_path(path)
        ]
        excluded_path_set = {item["path"] for item in excluded_paths}
        normalized_paths = [
            path for path in normalized_input_paths if path not in excluded_path_set
        ]
        report: dict[str, Any] = {
            "schema_version": "persistmind.impact_report.v1",
            "repo_id": snapshot.repo_id,
            "snapshot_id": snapshot.snapshot_id,
            "scope": f"single-repo: {snapshot.repo_id}; scoped check-diff preflight",
            "input_paths": normalized_input_paths,
            "analyzed_paths": normalized_paths,
            "excluded_paths": excluded_paths,
            "impacted_paths": normalized_paths,
            "dependency_paths": [],
            "tests": [],
            "risk": {
                "score": 0.0,
                "components": {},
                "metrics": {"changed_files": len(normalized_paths)},
                "untested_paths": [],
                "critical_paths": [],
                "graph_central_paths": [],
            },
            "performance": {
                "mode": "scoped_check_diff",
                "closure_traversal": False,
            },
        }
        pack = self.store.get_pack(pack_id)
        if pack:
            manifest = json.loads(pack["manifest_json"])
            pack_paths = {
                canonical_repo_path(item["path"], self.repo_root)
                for item in manifest.get("items", [])
            }
            seed_paths = {
                canonical_repo_path(path, self.repo_root) for path in manifest.get("seed_paths", [])
            }
            coverable_seed_paths = {
                path for path in seed_paths if self._seed_path_can_cover(snapshot.snapshot_id, path)
            }
            context_paths = pack_paths | coverable_seed_paths
            uncovered = sorted(set(normalized_paths) - context_paths)
            out_of_pack_paths, uncovered_noncode = self._classify_uncovered_paths(
                snapshot.snapshot_id, uncovered
            )
            report["pack_awareness"] = {
                "pack_id": pack_id,
                "pack_paths": sorted(pack_paths),
                "seed_paths": sorted(seed_paths),
                "coverable_seed_paths": sorted(coverable_seed_paths),
                "out_of_pack_paths": out_of_pack_paths,
                "uncovered_noncode": uncovered_noncode,
                "out_of_impact_paths": [],
            }
            report["scope_assessment"] = assess_write_scope(
                store=self.store,
                repo_root=self.repo_root,
                pack=pack,
                manifest=manifest,
                actual_paths=normalized_paths,
                diff=diff,
            )
            unapproved = set(report["scope_assessment"].get("actual_minus_approved", []))
            planned_new_paths = [path for path in out_of_pack_paths if path not in unapproved]
            report["pack_awareness"]["planned_new_paths"] = planned_new_paths
            report["pack_awareness"]["out_of_pack_paths"] = [
                path for path in out_of_pack_paths if path in unapproved
            ]
        pack_awareness: dict[str, Any] = report.get("pack_awareness", {})
        scope_assessment: dict[str, Any] = report.get("scope_assessment", {})
        violations = list(scope_assessment.get("violations", []))
        for reason in scope_assessment.get("incomplete_reasons", []):
            violations.append({"kind": "verification_incomplete", "reason": reason})
        for path in pack_awareness.get("out_of_pack_paths", []):
            if path in scope_assessment.get("actual_minus_approved", []):
                violations.append({"kind": "out_of_pack", "path": path})
        if self.settings.check_diff.block_noncode_paths:
            for path in pack_awareness.get("uncovered_noncode", []):
                violations.append({"kind": "uncovered_noncode", "path": path})
        for path in pack_awareness.get("out_of_impact_paths", []):
            violations.append({"kind": "out_of_impact", "path": path})
        if pack_awareness.get("out_of_pack_paths"):
            report["remediation"] = {
                "uncovered_paths": pack_awareness["out_of_pack_paths"],
                "command": 'persistmind --repo . pack --task "<task>" --seed-from-diff',
                "rebind_hint": (
                    "persistmind --repo . workflow rebind "
                    "--task-session-id <task_session_id> --pack-id <new_pack_id>"
                ),
            }
        guardrail_check = self._guardrail_diff_check(
            snapshot=snapshot, paths=normalized_paths, diff=diff
        )
        report["guardrails"] = guardrail_check
        if guardrail_check.get("decision") == "block":
            guardrail_violations = []
            for item in guardrail_check.get("matched", []):
                guardrail_violations.append(
                    {
                        "kind": "guardrail_directive",
                        "path": item.get("matched_path"),
                        "directive_id": item.get("directive_id"),
                        "record_id": item.get("record_id"),
                        "reason": guardrail_check.get("reason"),
                        "remediation": item.get("remediation"),
                    }
                )
            violations = guardrail_violations + violations
        report["performance"]["elapsed_ms"] = round((time.perf_counter() - started) * 1000, 2)
        return {
            "ok": not violations,
            "status": scope_assessment.get("status", "verification_incomplete"),
            "violations": violations,
            "impact_report": report,
        }

    def _guardrail_diff_check(
        self, *, snapshot: SnapshotInfo, paths: list[str], diff: str | None
    ) -> dict[str, Any]:
        if not self.settings.guardrails.enabled or not paths:
            return {"enabled": False, "decision": "allow", "matched": []}
        directives = self.store.directives_for_paths(paths, snapshot.repo_id)
        mode = "block" if self.settings.ci.mode in {"fail", "strict"} else "warn"
        decision = pre_tool_gate(
            tool_name="apply_patch",
            preflight_ready=True,
            active_plan_step=True,
            target_paths=paths,
            diff=diff or "",
            directives=directives,
            guardrails_mode=mode,
            block_min_severity=self.settings.guardrails.block_min_severity,
            min_block_confidence=self.settings.guardrails.min_block_confidence,
            content_match_required_for_block=(
                self.settings.guardrails.content_match_required_for_block
            ),
        )
        return {
            "enabled": True,
            "decision": decision.get("decision"),
            "ok": bool(decision.get("ok")),
            "reason": decision.get("reason"),
            "matched": decision.get("matched", []),
        }

    def select_minimal_tests(
        self,
        *,
        snapshot: SnapshotInfo,
        paths: list[str],
        contract_symbols: list[str] | None = None,
    ) -> dict[str, Any]:
        """Change-driven regression test selection (RTS).

        Computes the minimal affected test set via a firewall closure over the existing
        test->symbol graph: the reverse-closure of the changed files, then the tests linked to
        anything in that closure (Ekstazi/STARTS class-firewall idea). Includes an explicit
        unsafe-fallback note because regex/structural resolution can miss dynamic dispatch and
        reflection, so callers should treat the selection as a fast path, not a guarantee.
        """
        normalized = sorted({_normalize_path(path) for path in paths if path})
        analyzed = [path for path in normalized if not self._is_ignored_path(path)]
        impacted, _detail, closure_performance = self._reverse_closure(snapshot, analyzed)
        public_surface_paths = sorted(
            {
                str(item["from"])
                for item in _detail
                if str(item.get("kind") or "") == "public_surface"
            }
        )
        selection = self._select_tests(
            snapshot,
            impacted,
            public_surface_paths=public_surface_paths,
            contract_symbols=contract_symbols or [],
        )
        performance = _merge_performance(closure_performance, selection.get("performance", {}))
        selected_tests = sorted({item["path"] for item in selection["tests"]})
        # Changed/impacted testable files with no linked test are an RTS blind spot.
        uncovered = sorted(
            path
            for path in impacted
            if _is_testable_path(path) and path not in selection["covered_paths"]
        )
        return {
            "schema_version": "persistmind.rts_selection.v1",
            "repo_id": snapshot.repo_id,
            "changed_paths": analyzed,
            "public_surface_paths": public_surface_paths,
            "contract_symbols": sorted({str(item) for item in contract_symbols or [] if item}),
            "impacted_paths": sorted(impacted),
            "selected_tests": selected_tests,
            "test_details": selection["tests"],
            "uncovered_impacted_paths": uncovered,
            "performance": {"contract_coverage": performance},
            "safety": (
                "fast-path selection over structural test links; may miss tests reachable only "
                "via dynamic dispatch/reflection — run the full suite when correctness is critical"
            ),
        }

    def anticipate(
        self,
        *,
        snapshot: SnapshotInfo,
        task: str,
        current_paths: list[str],
        candidates: list[dict[str, Any]] | None = None,
        world_model: Any | None = None,
        top_k: int = 5,
        pack: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        from persistmind.anticipation.efe import EFEScorer
        from persistmind.anticipation.world_model import WorldModel

        model = world_model or WorldModel(self.store, snapshot.repo_id)
        scorer = EFEScorer(self.store, model, self)
        return scorer.score(
            snapshot=snapshot,
            task=task,
            current_paths=current_paths,
            candidates=candidates,
            pack=pack,
            top_k=top_k,
        )

    def _reverse_closure(
        self, snapshot: SnapshotInfo, paths: list[str], max_depth: int = 4
    ) -> tuple[set[str], list[dict[str, Any]], dict[str, Any]]:
        started = time.perf_counter()
        surface_started = time.perf_counter()
        public_surface_paths = derive_public_surface_files(paths, repo_root=self.repo_root)
        performance = {
            "derive_public_surface_elapsed_ms": round(
                (time.perf_counter() - surface_started) * 1000, 2
            ),
            "rglob_elapsed_ms": 0.0,
            "rglob_count": 0,
        }
        impacted = set(paths) | public_surface_paths
        detail: dict[tuple[str, str, str, tuple[str, ...]], dict[str, Any]] = {}
        queue: deque[tuple[str, int, float, list[str]]] = deque(
            (path, 0, 1.0, [path]) for path in sorted(impacted)
        )
        for surface in sorted(public_surface_paths):
            for path in paths:
                if surface == path:
                    continue
                detail[(surface, path, "public_surface", (surface, path))] = {
                    "from": surface,
                    "to": path,
                    "kind": "public_surface",
                    "confidence": 1.0,
                    "route": [surface, path],
                }
        while queue:
            path, depth, confidence, route = queue.popleft()
            if depth >= max_depth:
                continue
            for neighbor in self.store.neighbors(
                snapshot_id=snapshot.snapshot_id,
                repo_id=snapshot.repo_id,
                node_type="file",
                node_id=path,
                kinds=["imports", "tests"],
                direction="in",
            ):
                if neighbor.node_type != "file":
                    continue
                if self._is_ignored_path(neighbor.node_id):
                    continue
                edge_confidence = confidence * neighbor.confidence
                if edge_confidence < 0.2:
                    continue
                new_route = [neighbor.node_id, *route]
                detail_key = (neighbor.node_id, path, neighbor.kind, tuple(new_route))
                existing = detail.get(detail_key)
                rounded_confidence = round(edge_confidence, 4)
                if existing is None:
                    detail[detail_key] = {
                        "from": neighbor.node_id,
                        "to": path,
                        "kind": neighbor.kind,
                        "confidence": rounded_confidence,
                        "route": new_route,
                    }
                else:
                    existing["confidence"] = max(float(existing["confidence"]), rounded_confidence)
                if neighbor.node_id not in impacted:
                    impacted.add(neighbor.node_id)
                    queue.append((neighbor.node_id, depth + 1, edge_confidence, new_route))
        performance["elapsed_ms"] = round((time.perf_counter() - started) * 1000, 2)
        return (
            impacted,
            sorted(
                detail.values(),
                key=lambda item: (item["from"], item["to"], item["kind"], item["route"]),
            ),
            performance,
        )

    def _select_tests(
        self,
        snapshot: SnapshotInfo,
        impacted: set[str],
        *,
        public_surface_paths: list[str] | None = None,
        contract_symbols: list[str] | None = None,
    ) -> dict[str, Any]:
        tests: list[dict[str, Any]] = []
        covered: set[str] = set()
        for path in sorted(impacted):
            for neighbor in self.store.neighbors(
                snapshot_id=snapshot.snapshot_id,
                repo_id=snapshot.repo_id,
                node_type="file",
                node_id=path,
                kinds=["tests"],
                direction="in",
            ):
                if self._is_ignored_path(neighbor.node_id):
                    continue
                covered.add(path)
                tests.append(
                    {
                        "path": neighbor.node_id,
                        "covers": path,
                        "confidence": neighbor.confidence,
                        "command": self._default_test_command(snapshot.repo_id, neighbor.node_id),
                    }
                )
        for surface in sorted(set(public_surface_paths or [])):
            package_node = surface.removesuffix("/__init__.py")
            if not package_node or package_node == surface:
                continue
            for neighbor in self.store.neighbors(
                snapshot_id=snapshot.snapshot_id,
                repo_id=snapshot.repo_id,
                node_type="file",
                node_id=package_node,
                kinds=["tests"],
                direction="in",
            ):
                if self._is_ignored_path(neighbor.node_id):
                    continue
                covered.add(surface)
                tests.append(
                    {
                        "path": neighbor.node_id,
                        "covers": surface,
                        "confidence": neighbor.confidence,
                        "command": self._default_test_command(snapshot.repo_id, neighbor.node_id),
                    }
                )
        performance = {"rglob_elapsed_ms": 0.0, "rglob_count": 0}
        for symbol in sorted({str(item) for item in contract_symbols or [] if str(item).strip()}):
            for test_path in self._tests_referencing_symbol(symbol, performance=performance):
                tests.append(
                    {
                        "path": test_path,
                        "covers": symbol,
                        "confidence": 0.7,
                        "command": self._default_test_command(snapshot.repo_id, test_path),
                    }
                )
        unique = {
            f"{item['path']}:{item['covers']}": item
            for item in sorted(tests, key=lambda item: (item["path"], item["covers"]))
        }
        performance["rglob_elapsed_ms"] = round(float(performance["rglob_elapsed_ms"]), 2)
        return {"tests": list(unique.values()), "covered_paths": covered, "performance": performance}

    def _tests_referencing_symbol(
        self, symbol: str, *, performance: dict[str, Any] | None = None
    ) -> list[str]:
        needle = symbol.strip()
        if not needle:
            return []
        short = needle.rsplit(".", 1)[-1]
        matches: list[str] = []
        started = time.perf_counter()
        for root_name in ("tests", "test"):
            root = self.repo_root / root_name
            if not root.exists():
                continue
            for path in root.rglob("*.py"):
                if performance is not None:
                    performance["rglob_count"] = int(performance.get("rglob_count", 0)) + 1
                relative = path.relative_to(self.repo_root).as_posix()
                if self._is_ignored_path(relative):
                    continue
                try:
                    text = path.read_text(encoding="utf-8")
                except (OSError, UnicodeDecodeError):
                    continue
                if needle in text or short in text:
                    matches.append(relative)
        if performance is not None:
            performance["rglob_elapsed_ms"] = float(
                performance.get("rglob_elapsed_ms", 0.0)
            ) + ((time.perf_counter() - started) * 1000)
        return sorted(set(matches))

    def _default_test_command(self, repo_id: str, path: str) -> str:
        for row in self.store.test_commands(repo_id):
            if fnmatch.fnmatch(path, row["path_glob"]):
                return row["command"].replace("{path}", path)
        if path.endswith(".py"):
            return f"pytest {path}"
        if path.endswith((".ts", ".tsx", ".js", ".jsx")):
            return "npm test -- " + path
        return "run relevant tests"

    def _is_ignored_path(self, path: str) -> bool:
        normalized = _normalize_path(path)
        for glob in self.settings.eval.ignore_globs:
            if fnmatch.fnmatch(normalized, glob) or fnmatch.fnmatch(f"./{normalized}", glob):
                return True
            if glob.startswith("**/") and fnmatch.fnmatch(normalized, glob[3:]):
                return True
        return False

    def _classify_uncovered_paths(
        self, snapshot_id: str, paths: list[str]
    ) -> tuple[list[str], list[str]]:
        out_of_pack: list[str] = []
        uncovered_noncode: list[str] = []
        for path in sorted(paths):
            if self._is_indexable_changed_path(snapshot_id, path):
                out_of_pack.append(path)
            else:
                uncovered_noncode.append(path)
        return out_of_pack, uncovered_noncode

    def _is_indexable_changed_path(self, snapshot_id: str, path: str) -> bool:
        if self.store.chunks_by_paths(snapshot_id, [path], limit_per_path=1):
            return True
        if path.startswith(".codex/") or path.startswith(".pytest_cache/"):
            return False
        return Path(path).suffix.lower() in SOURCE_EXTENSIONS

    def _seed_path_can_cover(self, snapshot_id: str, path: str) -> bool:
        if self.store.chunks_by_paths(snapshot_id, [path], limit_per_path=1):
            return True
        suffix = Path(path).suffix.lower()
        if not suffix:
            return True
        return self._is_indexable_changed_path(snapshot_id, path)


def _normalize_path(path: str) -> str:
    return path.replace("\\", "/").removeprefix("./")


def _merge_performance(*blocks: dict[str, Any]) -> dict[str, Any]:
    merged: dict[str, Any] = {}
    for block in blocks:
        for key, value in block.items():
            if isinstance(value, (int, float)) and key in merged:
                merged[key] = round(float(merged[key]) + float(value), 2)
            else:
                merged[key] = value
    return merged


def _risk_components(
    *,
    changed: list[str],
    impacted: set[str],
    paths_detail: list[dict[str, Any]],
    untested: list[str],
    critical: list[str],
    graph_central_paths: list[str] | None = None,
    weights: dict[str, float] | None = None,
    changed_file_budget: int = RISK_CHANGED_FILE_BUDGET,
) -> tuple[dict[str, float], dict[str, Any]]:
    changed_count = len(changed)
    impacted_count = len(impacted)
    transitive_count = max(0, impacted_count - changed_count)
    edge_count = len(paths_detail)
    low_confidence_count = sum(1 for item in paths_detail if item["confidence"] < 0.7)
    critical_count = len(critical)
    graph_central_count = len(graph_central_paths or [])
    testable_impacted = sorted(path for path in impacted if _is_testable_path(path))
    testable_untested = sorted(path for path in untested if path in testable_impacted)

    ratios = {
        "changed_files": _ratio(changed_count, max(1, changed_file_budget)),
        "impacted_files": _ratio(transitive_count, impacted_count),
        "untested_files": _ratio(len(testable_untested), len(testable_impacted)),
        "low_confidence_edges": _ratio(low_confidence_count, edge_count),
        "critical_paths": 1.0 if critical_count else 0.0,
        "graph_centrality": _ratio(graph_central_count, impacted_count),
    }
    risk_weights = weights or RISK_WEIGHTS
    components = {key: round(ratios[key] * weight, 2) for key, weight in risk_weights.items()}
    metrics = {
        "changed_files": changed_count,
        "changed_file_budget": max(1, changed_file_budget),
        "impacted_files": impacted_count,
        "transitive_files": transitive_count,
        "untested_files": len(untested),
        "testable_impacted_files": len(testable_impacted),
        "testable_untested_files": len(testable_untested),
        "dependency_edges": edge_count,
        "low_confidence_edges": low_confidence_count,
        "critical_paths": critical_count,
        "graph_central_files": graph_central_count,
        "changed_breadth_ratio": round(ratios["changed_files"], 4),
        "impacted_ratio": round(ratios["impacted_files"], 4),
        "untested_ratio": round(ratios["untested_files"], 4),
        "low_confidence_ratio": round(ratios["low_confidence_edges"], 4),
        "critical_presence": round(ratios["critical_paths"], 4),
        "graph_centrality_ratio": round(ratios["graph_centrality"], 4),
    }
    return components, metrics


def impact_risk_weights(settings: Settings) -> dict[str, float]:
    optimize = settings.learning.optimize
    return {
        "changed_files": float(optimize.impact_changed_files_weight),
        "impacted_files": float(optimize.impact_impacted_files_weight),
        "untested_files": float(optimize.impact_untested_files_weight),
        "low_confidence_edges": float(optimize.impact_low_confidence_edges_weight),
        "critical_paths": float(optimize.impact_critical_paths_weight),
        "graph_centrality": float(optimize.impact_graph_centrality_weight),
    }


def _ratio(numerator: int, denominator: int) -> float:
    if denominator <= 0:
        return 0.0
    return min(1.0, numerator / denominator)


def _is_testable_path(path: str) -> bool:
    suffix = Path(path).suffix.lower()
    return suffix in TESTABLE_EXTENSIONS
