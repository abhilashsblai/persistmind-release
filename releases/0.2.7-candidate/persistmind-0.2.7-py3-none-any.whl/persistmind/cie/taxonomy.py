from __future__ import annotations

from persistmind.learning.taxonomy import (
    ALIASES as _ALIASES,
    CATEGORIES as FAILURE_CATEGORIES,
    DESCRIPTIONS as _DESCRIPTIONS,
    category_descriptions as failure_category_descriptions,
    is_known_category as is_known_failure_category,
    normalize_category as normalize_failure_category,
)

__all__ = [
    "FAILURE_CATEGORIES",
    "_ALIASES",
    "_DESCRIPTIONS",
    "failure_category_descriptions",
    "is_known_failure_category",
    "normalize_failure_category",
]
