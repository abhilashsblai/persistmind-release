from __future__ import annotations

from collections import Counter

from persistmind.cie.complexity import estimate_complexity
from persistmind.cie.contracts import MistakeRecurrencePrediction, deterministic_id


def predict_mistakes(
    task: str = "", paths: list[str] | None = None, history: list[dict] | None = None
) -> MistakeRecurrencePrediction:
    complexity = estimate_complexity(task, paths or [], history or [])
    history = history or []
    historical_modes = _historical_modes(task, paths or [], history)
    modes = ["verification_gap"] if complexity["task_complexity_score"] >= 25 else []
    modes.extend(historical_modes)
    if complexity["task_type"] in {"security_sensitive", "database", "migration"}:
        modes.append("risk_calibration_failure")
    if complexity["surface_count"]:
        modes.append("surface_parity")
    behavior = "normal"
    if complexity["complexity_band"] in {"critical", "high"}:
        behavior = "ask_for_review"
    elif modes:
        behavior = "expand_tests"
    content_confidence = 0.35 + min(0.45, len(historical_modes) * 0.12 + len(history) * 0.02)
    volume_confidence = 0.35 + min(0.25, len(history) * 0.05)
    confidence = max(content_confidence, volume_confidence)
    return MistakeRecurrencePrediction(
        prediction_id=deterministic_id(
            "prediction", task, paths or [], modes, complexity["complexity_band"]
        ),
        task_signature=deterministic_id("task_signature", task, paths or []),
        task_type=complexity["task_type"],
        likely_failure_modes=sorted(set(modes)),
        recommended_behavior=behavior,
        task_complexity_score=complexity["task_complexity_score"],
        complexity_band=complexity["complexity_band"],
        confidence=round(confidence, 3),
        provisional=len(history or []) < 5,
        evidence_refs=sorted(set([*complexity["evidence_refs"], *_history_refs(history)])),
    )


def _historical_modes(task: str, paths: list[str], history: list[dict]) -> list[str]:
    task_text = task.lower()
    path_terms = {part for path in paths for part in path.replace("\\", "/").lower().split("/")}
    weighted: Counter[str] = Counter()
    for row in history:
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else row
        category = str(payload.get("category") or payload.get("cie_domain") or "").strip()
        if not category:
            continue
        haystack = " ".join(
            str(payload.get(key) or "")
            for key in ("recurrence_key", "reason", "symptom", "root_cause", "affected_paths")
        ).lower()
        if category in task_text or any(term and term in haystack for term in path_terms):
            weighted[category] += 2
        else:
            weighted[category] += 1
    return [name for name, _count in weighted.most_common(3)]


def _history_refs(history: list[dict]) -> list[str]:
    refs: list[str] = []
    for row in history:
        ref = row.get("event_id") or row.get("mistake_id") or row.get("run_id") or row.get("ref")
        if ref:
            refs.append(str(ref))
    return refs
