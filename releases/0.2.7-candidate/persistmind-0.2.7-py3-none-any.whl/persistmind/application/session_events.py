from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from typing import Any

from persistmind.application.ports import Document, SessionEventPort


class StoreSessionEventPort(SessionEventPort):
    """Session event reader over the current task/activity state stores."""

    def __init__(
        self,
        store: Any,
        *,
        workspace_id: str | None = None,
        repo_id: str | None = None,
    ) -> None:
        self.store = store
        self.workspace_id = workspace_id
        self.repo_id = repo_id

    def events_for_session(self, session_id: str) -> Sequence[Document]:
        if hasattr(self.store, "agent_session_events"):
            return list(self.store.agent_session_events(session_id))
        rows = self._state_rows("session_event", limit=10000)
        return [
            self._event(row)
            for row in rows
            if str(_field(row, "session_id") or _payload(row).get("session_id") or "")
            == session_id
        ]

    def artifacts_for_session(self, session_id: str) -> Sequence[Document]:
        if hasattr(self.store, "agent_session_artifacts"):
            return list(self.store.agent_session_artifacts(session_id))
        artifacts: list[Document] = []
        for event in self.events_for_session(session_id):
            event_type = str(event.get("event_type") or "")
            payload = _mapping(event.get("payload"))
            for path in _payload_paths(payload):
                artifact_type = "file_edited" if event_type in {"file_edited", "edit"} else "file_read"
                artifacts.append(
                    {
                        "session_id": session_id,
                        "event_id": event.get("event_id"),
                        "artifact_type": artifact_type,
                        "ref": path,
                        "payload": payload,
                    }
                )
            command = str(payload.get("command") or "").strip()
            if command and event_type == "test_run":
                artifacts.append(
                    {
                        "session_id": session_id,
                        "event_id": event.get("event_id"),
                        "artifact_type": "test_command",
                        "ref": command,
                        "payload": payload,
                    }
                )
        return artifacts

    def recent_sessions(self, limit: int = 20) -> Sequence[Document]:
        if hasattr(self.store, "agent_sessions"):
            return list(self.store.agent_sessions(limit=limit))
        rows = self._state_rows("agent_session", limit=limit)
        if not rows:
            rows = self._state_rows("task_session", limit=limit)
        sessions = [self._session(row) for row in rows]
        return sessions[: max(0, int(limit))]

    def explain(self, session_id: str) -> dict[str, Any]:
        session = self._find_session(session_id)
        if session is None:
            return {"ok": False, "error": "session_not_found", "session_id": session_id}
        return {
            "ok": True,
            "session": session,
            "events": list(self.events_for_session(session_id)),
            "artifacts": list(self.artifacts_for_session(session_id)),
        }

    def _find_session(self, session_id: str) -> Document | None:
        if hasattr(self.store, "agent_sessions"):
            for row in self.store.agent_sessions(limit=10000):
                if str(row["session_id"]) == session_id:
                    return row
        for kind in ("agent_session", "task_session"):
            for row in self._state_rows(kind, limit=10000):
                session = self._session(row)
                if str(session.get("session_id") or "") == session_id:
                    return session
        return None

    def _state_rows(self, kind: str, *, limit: int) -> list[Any]:
        if not hasattr(self.store, "state_list"):
            return []
        try:
            rows = self.store.state_list(kind, limit=limit)
        except TypeError:
            rows = self.store.state_list(kind)
        if isinstance(rows, Mapping):
            records = rows.get("records")
            return list(records) if isinstance(records, list) else []
        return list(rows or [])

    def _event(self, row: Any) -> Document:
        payload = _payload(row)
        event_id = str(
            _field(row, "event_id") or _field(row, "state_id") or _field(row, "record_id") or ""
        )
        return {
            "event_id": event_id,
            "session_id": str(_field(row, "session_id") or payload.get("session_id") or ""),
            "event_type": str(_field(row, "event_type") or payload.get("event_type") or ""),
            "event_time": str(_field(row, "event_time") or _field(row, "created_at") or ""),
            "payload": payload,
            "payload_json": json.dumps(payload, sort_keys=True),
        }

    def _session(self, row: Any) -> Document:
        payload = _payload(row)
        session_id = str(
            _field(row, "session_id")
            or payload.get("session_id")
            or _field(row, "state_id")
            or _field(row, "record_id")
            or ""
        )
        return {
            "session_id": session_id,
            "workspace_id": str(_field(row, "workspace_id") or payload.get("workspace_id") or ""),
            "repo_id": str(_field(row, "repo_id") or payload.get("repo_id") or ""),
            "task": str(_field(row, "task") or payload.get("task") or payload.get("task_text") or ""),
            "status": str(_field(row, "status") or payload.get("status") or ""),
            "created_at": str(_field(row, "created_at") or ""),
            "updated_at": str(_field(row, "updated_at") or ""),
            "payload": payload,
        }


def _field(row: Any, key: str) -> Any:
    try:
        return row[key]
    except (KeyError, IndexError, TypeError):
        if isinstance(row, Mapping):
            return row.get(key)
        return getattr(row, key, None)


def _payload(row: Any) -> dict[str, Any]:
    raw = _field(row, "payload")
    if isinstance(raw, Mapping):
        return dict(raw)
    raw = _field(row, "payload_json")
    if raw is None:
        raw = _field(row, "state_json")
    if raw is None and isinstance(row, Mapping):
        return {str(key): value for key, value in row.items() if not str(key).startswith("_")}
    if isinstance(raw, Mapping):
        return dict(raw)
    try:
        parsed = json.loads(str(raw or "{}"))
    except json.JSONDecodeError:
        return {}
    return dict(parsed) if isinstance(parsed, Mapping) else {}


def _mapping(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, Mapping) else {}


def _payload_paths(payload: Mapping[str, Any]) -> list[str]:
    paths: list[str] = []
    for key in ("path", "file_path", "filepath", "target_path", "ref"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            paths.append(value)
    value = payload.get("target_paths") or payload.get("paths") or payload.get("files")
    if isinstance(value, list):
        paths.extend(str(item) for item in value if str(item).strip())
    return sorted({path.replace("\\", "/").removeprefix("./") for path in paths})
