from __future__ import annotations

from .consolidate import build_project_narrative

__all__ = ["build_project_narrative"]
