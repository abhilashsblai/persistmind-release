from __future__ import annotations

from typing import Any


ASK_SIGNALS = {"ambiguous_intent", "goal_confidence", "missing_seed_paths"}
SEARCH_SIGNALS = {"memory_sparse", "seed_coverage_gap", "pack_low_confidence"}
REPLAN_SIGNALS = {
    "anticipation_surprise",
    "efe_instability",
    "verification_failures",
    "workspace_not_converged",
}


def decide_resolution(
    *,
    task: str,
    uncertainty: dict[str, Any],
    self_state: str,
    gather_threshold: float,
    ask_threshold: float,
    clarification_budget_remaining: int,
) -> dict[str, Any]:
    score = float(uncertainty.get("score") or 0.0)
    signals = {
        str(item.get("signal") or "")
        for item in uncertainty.get("drivers") or []
        if isinstance(item, dict)
    }
    if self_state == "off_track" or signals & REPLAN_SIGNALS:
        resolvable_by = "replan"
    elif signals & ASK_SIGNALS:
        resolvable_by = "ask"
    elif signals & SEARCH_SIGNALS:
        resolvable_by = "search"
    else:
        resolvable_by = "search" if score >= gather_threshold else "none"

    budget_exhausted = clarification_budget_remaining <= 0
    if resolvable_by == "ask" and score >= ask_threshold and not budget_exhausted:
        action = "ask_human"
    elif resolvable_by == "replan" and score >= gather_threshold:
        action = "replan"
    elif resolvable_by == "search" and score >= gather_threshold:
        action = "gather_more"
    else:
        action = "proceed"
    if resolvable_by == "ask" and budget_exhausted:
        action = "proceed"

    return {
        "action": action,
        "resolvable_by": resolvable_by,
        "budget_exhausted": budget_exhausted,
        "question": (
            build_question(task, uncertainty) if action == "ask_human" else None
        ),
    }


def build_question(task: str, uncertainty: dict[str, Any]) -> str:
    drivers = [
        str(item.get("signal") or "")
        for item in uncertainty.get("drivers") or []
        if isinstance(item, dict)
    ]
    if "missing_seed_paths" in drivers:
        return (
            "Which files or subsystem should I treat as the intended edit surface for "
            f"this task: {task}?"
        )
    if "goal_confidence" in drivers:
        return f"What outcome should I optimize for before proceeding with: {task}?"
    return f"Can you clarify the intended scope and success criteria for: {task}?"
