from __future__ import annotations

from typing import Any

READ_INTENT_TERMS = {
    "what",
    "why",
    "how",
    "investigate",
    "review",
    "explain",
    "audit",
}
WRITE_INTENT_TERMS = {
    "add",
    "build",
    "change",
    "fix",
    "implement",
    "wire",
    "update",
}
VAGUE_TERMS = {"this", "that", "it", "thing", "stuff", "issue", "problem"}


def compute_uncertainty(signals: dict[str, Any]) -> dict[str, Any]:
    drivers: list[dict[str, Any]] = []
    task = str(signals.get("task") or "")
    terms = {part.strip(".,:;()[]{}").lower() for part in task.split()}
    paths = [str(path) for path in signals.get("paths") or [] if path]
    pack = signals.get("pack") if isinstance(signals.get("pack"), dict) else {}

    if pack.get("low_confidence"):
        _add(
            drivers,
            "pack_low_confidence",
            0.25,
            "compiler marked the pack low confidence",
        )
    warnings = pack.get("warnings") if isinstance(pack.get("warnings"), list) else []
    warning_kinds = {
        str(item.get("kind") or "")
        for item in warnings
        if isinstance(item, dict) and item.get("kind")
    }
    if warning_kinds:
        contribution = min(0.25, 0.08 * len(warning_kinds))
        _add(
            drivers,
            "pack_warnings",
            contribution,
            f"pack warnings present: {', '.join(sorted(warning_kinds))}",
        )

    seed_coverage = (
        pack.get("seed_coverage") if isinstance(pack.get("seed_coverage"), dict) else {}
    )
    unselected = seed_coverage.get("unselected_seed_paths") or []
    if unselected:
        _add(
            drivers,
            "seed_coverage_gap",
            min(0.30, 0.10 * len(unselected)),
            "seeded paths were not selected into the pack",
        )
    if not paths and terms & WRITE_INTENT_TERMS:
        _add(
            drivers,
            "missing_seed_paths",
            0.20,
            "write-like task has no seed paths",
        )
    if terms & VAGUE_TERMS and not paths:
        _add(
            drivers,
            "ambiguous_intent",
            0.45,
            "task wording is vague and has no grounding paths",
        )

    goal_confidence = _float_or_none(signals.get("goal_confidence"))
    if goal_confidence is not None:
        contribution = max(0.0, min(0.30, (1.0 - goal_confidence) * 0.30))
        if contribution:
            _add(drivers, "goal_confidence", contribution, "goal confidence is low")

    surprise = _nested_float(signals, ("surprise", "surprise"))
    if surprise is not None and surprise >= 0.50:
        _add(
            drivers,
            "anticipation_surprise",
            min(0.35, surprise * 0.35),
            "anticipation surprise is elevated",
        )
    efe = _nested_float(signals, ("surprise", "expected_free_energy"))
    if efe is not None and efe >= 0.50:
        _add(
            drivers,
            "efe_instability",
            min(0.25, efe * 0.25),
            "expected free energy indicates instability",
        )

    unresolved_gates = int(signals.get("unresolved_gates") or 0)
    if unresolved_gates:
        _add(
            drivers,
            "unresolved_gates",
            min(0.30, unresolved_gates * 0.10),
            "workflow gates are unresolved",
        )
    verification_failures = int(signals.get("verification_failures") or 0)
    if verification_failures:
        _add(
            drivers,
            "verification_failures",
            min(0.35, verification_failures * 0.15),
            "latest verification evidence has failures",
        )

    retrieval = (
        pack.get("memory_retrieval")
        if isinstance(pack.get("memory_retrieval"), dict)
        else {}
    )
    served_counts = retrieval.get("served_counts_by_type") or {}
    if isinstance(served_counts, dict) and not any(
        int(v or 0) for v in served_counts.values()
    ):
        _add(drivers, "memory_sparse", 0.10, "no memory records were served")
    storage = signals.get("storage") if isinstance(signals.get("storage"), dict) else {}
    if storage:
        vector_store = str(storage.get("vector_store") or "")
        if vector_store and vector_store != "sqlite-vec":
            _add(
                drivers,
                "retrieval_degraded",
                0.12,
                f"memory recall is using {vector_store} fallback",
            )

    workspace = pack.get("workspace") if isinstance(pack.get("workspace"), dict) else {}
    if workspace.get("active") and not workspace.get("converged"):
        _add(
            drivers,
            "workspace_not_converged",
            0.25,
            "cognitive workspace did not converge within bounds",
        )

    score = min(1.0, round(sum(float(item["contribution"]) for item in drivers), 4))
    return {"score": score, "drivers": drivers}


def _add(
    drivers: list[dict[str, Any]], signal: str, contribution: float, reason: str
) -> None:
    contribution = round(max(0.0, min(1.0, float(contribution))), 4)
    if contribution:
        drivers.append(
            {"signal": signal, "contribution": contribution, "reason": reason}
        )


def _float_or_none(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int | float):
        return max(0.0, min(1.0, float(value)))
    return None


def _nested_float(payload: dict[str, Any], path: tuple[str, ...]) -> float | None:
    value: Any = payload
    for key in path:
        if not isinstance(value, dict):
            return None
        value = value.get(key)
    return _float_or_none(value)
