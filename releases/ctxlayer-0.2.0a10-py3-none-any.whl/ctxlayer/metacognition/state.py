from __future__ import annotations

from typing import Any


def classify_state(uncertainty: dict[str, Any], signals: dict[str, Any]) -> str:
    score = float(uncertainty.get("score") or 0.0)
    drivers = {
        str(item.get("signal") or ""): float(item.get("contribution") or 0.0)
        for item in uncertainty.get("drivers") or []
        if isinstance(item, dict)
    }
    unresolved = int(signals.get("unresolved_gates") or 0)
    if drivers.get("anticipation_surprise", 0.0) >= 0.25 and unresolved == 0:
        return "off_track"
    if drivers.get("verification_failures", 0.0) and (
        drivers.get("pack_low_confidence", 0.0) or drivers.get("ambiguous_intent", 0.0)
    ):
        return "confused"
    if score >= 0.70:
        return "uncertain"
    if score >= 0.45:
        return "uncertain"
    return "confident"
