from __future__ import annotations

import time
from pathlib import Path
from typing import Any

from ctxlayer.analytics.queries import query_rows
from ctxlayer.eval.agent import AgentBenchmarkHarness, PackProvider, PreflightProvider
from ctxlayer.utils import stable_id, utc_now

ARM_LABELS = {
    "no-pack": "baseline",
    "ctx-pack": "ctxlayer",
    "baseline": "baseline",
    "ctxlayer": "ctxlayer",
}


def run_efficacy(
    repo_root: Path,
    *,
    cases_path: Path,
    agent_command: str,
    pack_provider: PackProvider,
    preflight_provider: PreflightProvider,
    baseline: str = "no-pack",
    candidate: str = "ctx-pack",
    limit: int = 10,
    timeout: int = 600,
    keep_worktrees: bool = False,
    determinism_runs: int = 3,
) -> dict[str, Any]:
    baseline_arm = _arm_name(baseline)
    candidate_arm = _arm_name(candidate)
    if baseline_arm != "baseline" or candidate_arm != "ctxlayer":
        raise ValueError(
            "efficacy currently compares --baseline no-pack to --candidate ctx-pack"
        )

    benchmark = AgentBenchmarkHarness(
        repo_root,
        pack_provider=pack_provider,
        preflight_provider=preflight_provider,
    ).run_cases_file(
        path=cases_path,
        agent_command=agent_command,
        limit=limit,
        timeout=timeout,
        keep_worktrees=keep_worktrees,
    )
    benchmark["pack_quality_probes"] = _determinism_probes(
        repo_root=repo_root,
        benchmark=benchmark,
        pack_provider=pack_provider,
        runs=determinism_runs,
    )
    return assemble_scorecard(
        benchmark,
        baseline_label=baseline,
        candidate_label=candidate,
        cases_path=cases_path,
        agent_command=agent_command,
    )


def assemble_scorecard(
    benchmark: dict[str, Any],
    *,
    baseline_label: str = "no-pack",
    candidate_label: str = "ctx-pack",
    cases_path: Path | str | None = None,
    agent_command: str | None = None,
) -> dict[str, Any]:
    delta = _dict(benchmark.get("delta"))
    ctx_metrics = _dict(_dict(benchmark.get("arms")).get("ctxlayer")).get("metrics", {})
    baseline_metrics = _dict(_dict(benchmark.get("arms")).get("baseline")).get(
        "metrics", {}
    )
    pack_quality = _pack_quality(benchmark)
    gate_checks = [
        {
            "name": "ctx_pack_reduces_or_matches_out_of_scope_edits",
            "ok": float(delta.get("out_of_scope_edit_rate_delta", 0.0)) <= 0.0,
            "actual": delta.get("out_of_scope_edit_rate_delta", 0.0),
            "expected": "<= 0",
        },
        {
            "name": "ctx_pack_reduces_or_matches_hallucination_incidents",
            "ok": float(delta.get("hallucination_incident_delta", 0.0)) <= 0.0,
            "actual": delta.get("hallucination_incident_delta", 0.0),
            "expected": "<= 0",
        },
        {
            "name": "pack_manifest_is_deterministic",
            "ok": pack_quality["determinism"]["identical_manifest_hash"] is True,
            "actual": pack_quality["determinism"]["identical_manifest_hash"],
            "expected": True,
        },
    ]
    return {
        "ok": bool(benchmark.get("ok", True)),
        "schema_version": "ctxlayer.efficacy_scorecard.v1",
        "created_at": str(benchmark.get("created_at") or utc_now()),
        "mode": "efficacy",
        "arms": {
            baseline_label: {"internal_arm": "baseline", "metrics": baseline_metrics},
            candidate_label: {"internal_arm": "ctxlayer", "metrics": ctx_metrics},
        },
        "delta": delta,
        "pack_quality": pack_quality,
        "loop_closure": {
            "verified": False,
            "reason": "not_run",
            "note": "Phase 0 records verification status; enforced loop closure lands in H4.",
        },
        "gate": {
            "status": "pass" if all(check["ok"] for check in gate_checks) else "fail",
            "checks": gate_checks,
        },
        "reproduction": {
            "cases_path": str(cases_path) if cases_path is not None else None,
            "agent_command": agent_command or benchmark.get("agent_command"),
            "baseline": baseline_label,
            "candidate": candidate_label,
        },
        "benchmark": benchmark,
    }


def latest_efficacy_scorecard(
    store: Any,
    *,
    repo_id: str,
    analytics_backend: str = "auto",
    db_path: Path | None = None,
) -> dict[str, Any]:
    grouped = query_rows(
        sqlite_conn=store.conn,
        db_path=db_path or store.db_path,
        sqlite_sql="""
            SELECT *
            FROM efficacy_scorecards
            WHERE repo_id = ?
            ORDER BY created_at DESC, scorecard_id DESC
            LIMIT ?
        """,
        duckdb_sql="""
            SELECT *
            FROM sqlite_db.efficacy_scorecards
            WHERE repo_id = ?
            ORDER BY created_at DESC, scorecard_id DESC
            LIMIT ?
        """,
        params=(repo_id, 1),
        requested_backend=analytics_backend,
    )
    return {
        "row": grouped["rows"][0] if grouped["rows"] else None,
        "analytics_backend": grouped["backend"],
        "analytics_parity_ok": bool(grouped["parity_ok"]),
        "analytics_fallback_reason": grouped.get("fallback_reason"),
    }


def _pack_quality(benchmark: dict[str, Any]) -> dict[str, Any]:
    cases = [
        case for case in benchmark.get("case_results", []) if isinstance(case, dict)
    ]
    ctx_results = [
        _dict(_dict(case.get("arms")).get("ctxlayer"))
        for case in cases
        if isinstance(case.get("arms"), dict)
    ]
    context = [
        _dict(_dict(result.get("ctxlayer_signals")).get("context_retrieval"))
        for result in ctx_results
    ]
    impact_scores = [_impact_accuracy(result) for result in ctx_results]
    pack_signals = [
        _dict(_dict(result.get("ctxlayer_signals")).get("pack"))
        for result in ctx_results
    ]
    probes = [
        probe
        for probe in benchmark.get("pack_quality_probes", [])
        if isinstance(probe, dict)
    ]
    selected_tests = [
        _dict(_dict(result.get("ctxlayer_signals")).get("test_selection"))
        for result in ctx_results
    ]
    latencies_ms = [
        float(signal.get("pack_seconds", 0.0)) * 1000.0
        for signal in pack_signals
        if signal.get("pack_seconds") is not None
    ]
    latencies_ms.extend(
        float(run.get("seconds", 0.0)) * 1000.0
        for probe in probes
        for run in probe.get("runs", [])
        if isinstance(run, dict) and run.get("seconds") is not None
    )
    determinism = _determinism_summary(probes)
    return {
        "context_recall": _avg(item.get("context_recall", 0.0) for item in context),
        "expected_context_missing": sorted(
            {
                path
                for item in context
                for path in item.get("expected_context_missing", [])
                if isinstance(path, str)
            }
        ),
        "impact_prediction": {
            "precision": _avg(item["precision"] for item in impact_scores),
            "recall": _avg(item["recall"] for item in impact_scores),
            "f1": _avg(item["f1"] for item in impact_scores),
        },
        "test_selection_precision": _avg(
            (
                1.0
                if item.get("expected_test_selected") is True
                else 0.0 if item.get("expected_test_selected") is False else 1.0
            )
            for item in selected_tests
        ),
        "determinism": determinism,
        "latency": {
            "p50_ms": _percentile(latencies_ms, 50),
            "p95_ms": _percentile(latencies_ms, 95),
            "max_ms": round(max(latencies_ms), 4) if latencies_ms else 0.0,
        },
    }


def _determinism_probes(
    *,
    repo_root: Path,
    benchmark: dict[str, Any],
    pack_provider: PackProvider,
    runs: int,
) -> list[dict[str, Any]]:
    count = max(1, int(runs))
    probes: list[dict[str, Any]] = []
    cases = [
        case for case in benchmark.get("case_results", []) if isinstance(case, dict)
    ]
    for case in cases:
        task = str(case.get("task") or "")
        if not task:
            continue
        probe_runs = []
        for index in range(count):
            started = time.perf_counter()
            pack = pack_provider(repo_root, task)
            seconds = round(time.perf_counter() - started, 4)
            probe_runs.append(
                {
                    "run": index + 1,
                    "pack_id": pack.get("pack_id"),
                    "pack_manifest_hash": _pack_manifest_hash(pack),
                    "seconds": seconds,
                }
            )
        hashes = [str(item["pack_manifest_hash"]) for item in probe_runs]
        probes.append(
            {
                "case_id": case.get("case_id"),
                "task": task,
                "runs": probe_runs,
                "identical_manifest_hash": len(set(hashes)) == 1,
            }
        )
    return probes


def _determinism_summary(probes: list[dict[str, Any]]) -> dict[str, Any]:
    hashes = [
        str(run.get("pack_manifest_hash"))
        for probe in probes
        for run in probe.get("runs", [])
        if isinstance(run, dict) and run.get("pack_manifest_hash")
    ]
    per_case = [
        {
            "case_id": probe.get("case_id"),
            "runs": len(
                [run for run in probe.get("runs", []) if isinstance(run, dict)]
            ),
            "identical_manifest_hash": bool(probe.get("identical_manifest_hash")),
        }
        for probe in probes
    ]
    if not probes:
        return {
            "verified": False,
            "runs": 0,
            "identical_manifest_hash": None,
            "pack_hashes": [],
            "cases": [],
            "reason": "not_run",
        }
    identical = all(item["identical_manifest_hash"] for item in per_case)
    return {
        "verified": identical,
        "runs": min((item["runs"] for item in per_case), default=0),
        "identical_manifest_hash": identical,
        "pack_hashes": sorted(set(hashes)),
        "cases": per_case,
        "reason": "verified" if identical else "hash_mismatch",
    }


def _pack_manifest_hash(pack: dict[str, Any]) -> str:
    return stable_id(
        "pack_manifest",
        str(pack.get("pack_id") or ""),
        str(pack.get("snapshot_id") or ""),
        str(pack.get("task_text_hash") or ""),
        str(pack.get("constitution_hash") or ""),
    )


def _impact_accuracy(result: dict[str, Any]) -> dict[str, float]:
    predicted = _impact_paths(_dict(result.get("preflight")).get("impact"))
    actual = {path for path in result.get("changed_files", []) if isinstance(path, str)}
    hits = predicted & actual
    precision = (
        len(hits) / len(predicted) if predicted else (1.0 if not actual else 0.0)
    )
    recall = len(hits) / len(actual) if actual else 1.0
    f1 = (2 * precision * recall / (precision + recall)) if precision + recall else 0.0
    return {
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
    }


def _impact_paths(value: Any) -> set[str]:
    report = _dict(value)
    paths: set[str] = set()
    for key in ("analyzed_paths", "impacted_paths", "dependency_paths"):
        for item in report.get(key, []) or []:
            if isinstance(item, str):
                paths.add(item.replace("\\", "/"))
            elif isinstance(item, dict):
                for nested_key in ("path", "from", "to"):
                    nested = item.get(nested_key)
                    if isinstance(nested, str):
                        paths.add(nested.replace("\\", "/"))
    return paths


def _arm_name(value: str) -> str:
    try:
        return ARM_LABELS[value]
    except KeyError as exc:
        raise ValueError(f"unknown efficacy arm label: {value}") from exc


def _dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _avg(values: Any) -> float:
    items = [float(value) for value in values]
    if not items:
        return 0.0
    return round(sum(items) / len(items), 4)


def _percentile(values: list[float], percentile: int) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(
        len(ordered) - 1, max(0, round((percentile / 100) * (len(ordered) - 1)))
    )
    return round(ordered[index], 4)
