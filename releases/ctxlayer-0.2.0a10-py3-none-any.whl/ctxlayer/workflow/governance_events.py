from __future__ import annotations

import json
from typing import Any

from ctxlayer.utils import stable_id


def record_session_feature_events(
    store: Any,
    *,
    workspace_id: str,
    repo_id: str | None,
    task_session_id: str | None,
    agent_session_id: str,
    outcome_result: str,
) -> dict[str, Any]:
    events = store.agent_session_events(agent_session_id)
    snapshot = _latest_workflow_snapshot(events, task_session_id)
    if not snapshot:
        return {
            "ok": True,
            "recorded_count": 0,
            "reason": "no_workflow_recommendation_snapshot",
        }
    used_tools = _used_tool_names(events)
    difficulty = _difficulty_proxy(snapshot)
    recorded: list[str] = []
    for feature in _recommended_features(snapshot):
        task_types = (
            feature.get("task_types") or snapshot.get("task_types") or ["unknown"]
        )
        for task_type in task_types:
            event_id = stable_id(
                agent_session_id,
                task_session_id or "",
                task_type,
                feature.get("feature_id"),
                feature.get("classification"),
            )
            recorded.append(
                store.upsert_governance_feature_event(
                    workspace_id=workspace_id,
                    repo_id=repo_id,
                    task_session_id=task_session_id,
                    agent_session_id=agent_session_id,
                    pack_id=snapshot.get("pack_id"),
                    task_type=str(task_type),
                    feature_id=str(feature.get("feature_id")),
                    classification=str(feature.get("classification") or "optional"),
                    recommended=True,
                    used=_feature_used(feature, used_tools),
                    outcome_result=outcome_result,
                    difficulty_proxy=difficulty,
                    metadata={
                        "mcp_tool": feature.get("mcp_tool"),
                        "gate_kind": feature.get("gate_kind"),
                    },
                    event_id=event_id,
                )
            )
    return {
        "ok": True,
        "recorded_count": len(recorded),
        "event_ids": recorded,
        "task_session_id": task_session_id,
        "agent_session_id": agent_session_id,
    }


def _latest_workflow_snapshot(
    events: list[Any], task_session_id: str | None
) -> dict[str, Any] | None:
    snapshots: list[dict[str, Any]] = []
    for row in events:
        if row["event_type"] != "workflow_recommendation_snapshot":
            continue
        payload = _json_dict(row["payload_json"])
        if task_session_id and payload.get("task_session_id") != task_session_id:
            continue
        snapshots.append(payload)
    return snapshots[-1] if snapshots else None


def _recommended_features(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    features: list[dict[str, Any]] = []
    for classification, key in (
        ("required", "required_features"),
        ("optional", "optional_features"),
    ):
        for item in snapshot.get(key, []) or []:
            if isinstance(item, dict):
                features.append({"classification": classification, **item})
    return features


def _used_tool_names(events: list[Any]) -> set[str]:
    used: set[str] = set()
    for row in events:
        payload = _json_dict(row["payload_json"])
        event_type = str(row["event_type"] or "")
        for key in ("tool_name", "tool", "mcp_tool", "feature_id"):
            value = payload.get(key)
            if isinstance(value, str) and value:
                used.add(value)
        if event_type.startswith("tool_"):
            value = payload.get("tool_name") or payload.get("tool")
            if isinstance(value, str) and value:
                used.add(value)
        if event_type.startswith("workflow_feature_used:"):
            used.add(event_type.split(":", 1)[1])
    return used


def _feature_used(feature: dict[str, Any], used_tools: set[str]) -> bool:
    feature_id = str(feature.get("feature_id") or "")
    mcp_tool = str(feature.get("mcp_tool") or "")
    command = str(feature.get("command") or "")
    return bool(
        feature_id in used_tools
        or (mcp_tool and mcp_tool in used_tools)
        or any(tool and tool in command for tool in used_tools)
    )


def _difficulty_proxy(snapshot: dict[str, Any]) -> dict[str, Any]:
    gates = snapshot.get("gates") or []
    unresolved = sum(
        len(feature.get("unresolved_params") or [])
        for feature in (snapshot.get("required_features") or [])
        + (snapshot.get("optional_features") or [])
        if isinstance(feature, dict)
    )
    return {
        "mode": snapshot.get("mode"),
        "task_type_count": len(snapshot.get("task_types") or []),
        "gate_count": len(gates),
        "unresolved_param_count": unresolved,
        "bucket": "high" if len(gates) + unresolved >= 4 else "low",
    }


def _json_dict(raw: str | bytes | None) -> dict[str, Any]:
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}
