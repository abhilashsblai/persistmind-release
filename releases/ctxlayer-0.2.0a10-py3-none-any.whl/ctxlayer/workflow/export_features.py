from __future__ import annotations

import argparse
import html
import json
import sys
import zipfile
from pathlib import Path
from typing import Any

from ctxlayer.workflow.feature_catalog import FEATURE_CATALOG
from ctxlayer.workflow.playbook import FEATURE_COVERAGE, PLAYBOOK, PLAYBOOK_VERSION

DEFAULT_OUTPUT = Path("features/features.xlsx")


def feature_rows() -> list[list[Any]]:
    rows: list[list[Any]] = [
        [
            "feature_id",
            "purpose",
            "mcp_tool",
            "gate_kind",
            "required_params",
            "optional_params",
            "coverage",
            "coverage_reason",
            "task_types",
            "command_template",
        ]
    ]
    for feature_id, feature in sorted(FEATURE_CATALOG.items()):
        coverage = FEATURE_COVERAGE.get(feature_id, {})
        task_types = [
            task_type
            for task_type, entry in sorted(PLAYBOOK.items())
            if feature_id in entry.get("required_features", [])
            or feature_id in entry.get("optional_features", [])
        ]
        rows.append(
            [
                feature_id,
                feature["purpose"],
                feature["mcp_tool"],
                feature["gate_kind"],
                ", ".join(feature.get("required_params", [])),
                ", ".join(feature.get("optional_params", [])),
                coverage.get("classification", ""),
                coverage.get("reason", ""),
                ", ".join(task_types),
                feature["command_template"],
            ]
        )
    return rows


def playbook_rows() -> list[list[Any]]:
    rows: list[list[Any]] = [
        [
            "playbook_version",
            "task_type",
            "match",
            "required_features",
            "optional_features",
            "gates",
            "stop_when",
        ]
    ]
    for task_type, entry in sorted(PLAYBOOK.items()):
        rows.append(
            [
                PLAYBOOK_VERSION,
                task_type,
                json.dumps(entry.get("match", {}), sort_keys=True),
                ", ".join(entry.get("required_features", [])),
                ", ".join(entry.get("optional_features", [])),
                ", ".join(entry.get("gates", [])),
                entry.get("stop_when", ""),
            ]
        )
    return rows


def write_xlsx(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        _writestr(zf, "[Content_Types].xml", CONTENT_TYPES)
        _writestr(zf, "_rels/.rels", ROOT_RELS)
        _writestr(zf, "xl/workbook.xml", WORKBOOK)
        _writestr(zf, "xl/_rels/workbook.xml.rels", WORKBOOK_RELS)
        _writestr(zf, "xl/styles.xml", STYLES)
        _writestr(zf, "xl/worksheets/sheet1.xml", _sheet_xml(feature_rows()))
        _writestr(zf, "xl/worksheets/sheet2.xml", _sheet_xml(playbook_rows()))


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args(argv)
    output = Path(args.output)
    if args.check:
        expected = _xlsx_bytes()
        actual = output.read_bytes() if output.exists() else b""
        if actual != expected:
            print(
                json.dumps(
                    {
                        "ok": False,
                        "output": str(output),
                        "reason": "features xlsx differs from generated catalog/playbook",
                    },
                    indent=2,
                )
            )
            raise SystemExit(1)
        print(json.dumps({"ok": True, "output": str(output)}, indent=2))
        return
    write_xlsx(output)
    print(json.dumps({"ok": True, "output": str(output)}, indent=2))


def _xlsx_bytes() -> bytes:
    import io

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        _writestr(zf, "[Content_Types].xml", CONTENT_TYPES)
        _writestr(zf, "_rels/.rels", ROOT_RELS)
        _writestr(zf, "xl/workbook.xml", WORKBOOK)
        _writestr(zf, "xl/_rels/workbook.xml.rels", WORKBOOK_RELS)
        _writestr(zf, "xl/styles.xml", STYLES)
        _writestr(zf, "xl/worksheets/sheet1.xml", _sheet_xml(feature_rows()))
        _writestr(zf, "xl/worksheets/sheet2.xml", _sheet_xml(playbook_rows()))
    return buf.getvalue()


def _writestr(zf: zipfile.ZipFile, name: str, data: str) -> None:
    info = zipfile.ZipInfo(name)
    info.date_time = (2026, 1, 1, 0, 0, 0)
    info.compress_type = zipfile.ZIP_DEFLATED
    zf.writestr(info, data)


def _sheet_xml(rows: list[list[Any]]) -> str:
    body = []
    for row_idx, row in enumerate(rows, start=1):
        cells = []
        for col_idx, value in enumerate(row, start=1):
            ref = f"{_col(col_idx)}{row_idx}"
            cells.append(
                f'<c r="{ref}" t="inlineStr"><is><t>{html.escape(str(value))}</t></is></c>'
            )
        body.append(f'<row r="{row_idx}">{"".join(cells)}</row>')
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        f"<sheetData>{''.join(body)}</sheetData></worksheet>"
    )


def _col(index: int) -> str:
    chars = []
    while index:
        index, rem = divmod(index - 1, 26)
        chars.append(chr(65 + rem))
    return "".join(reversed(chars))


CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>"""

ROOT_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

WORKBOOK = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="features" sheetId="1" r:id="rId1"/>
    <sheet name="playbook" sheetId="2" r:id="rId2"/>
  </sheets>
</workbook>"""

WORKBOOK_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>
  <fills count="1"><fill><patternFill patternType="none"/></fill></fills>
  <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs>
</styleSheet>"""


if __name__ == "__main__":
    main(sys.argv[1:])
