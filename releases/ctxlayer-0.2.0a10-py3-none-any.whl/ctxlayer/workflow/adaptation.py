from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any

from ctxlayer.analytics.queries import query_rows


PASS_RESULTS = {"pass", "passed", "ok", "success"}


def propose_playbook_changes(
    store: Any,
    *,
    min_samples: int = 12,
    analytics_backend: str = "auto",
    db_path: Path | None = None,
) -> dict[str, Any]:
    grouped = _analytics_feature_rows(
        store,
        requested_backend=analytics_backend,
        db_path=db_path,
    )
    groups: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in grouped["rows"]:
        groups[(str(row["task_type"]), str(row["feature_id"]))].append(row)

    proposals: list[dict[str, Any]] = []
    for (task_type, feature_id), items in sorted(groups.items()):
        support = sum(int(row["count"] or 0) for row in items)
        if support < min_samples:
            continue
        stats = _feature_stats(items)
        if stats["used_count"] == 0 or stats["unused_count"] == 0:
            continue
        lift = stats["used_success_rate"] - stats["unused_success_rate"]
        if lift <= 0:
            continue
        if stats["bucket_count"] > 1 and stats["positive_strata"] < 2:
            continue
        change = (
            "promote_to_required"
            if stats["classification"] == "optional"
            else "add_optional"
        )
        proposal_id = store.upsert_governance_playbook_proposal(
            task_type=task_type,
            feature_id=feature_id,
            change=change,
            support=support,
            lift=lift,
            confidence=min(1.0, max(0.0, lift) * (support / max(min_samples, 1))),
            evidence=stats,
        )
        proposals.append(
            {
                "proposal_id": proposal_id,
                "task_type": task_type,
                "feature_id": feature_id,
                "change": change,
                "support": support,
                "lift": lift,
                "confidence": min(
                    1.0, max(0.0, lift) * (support / max(min_samples, 1))
                ),
            }
        )
    return {
        "ok": True,
        "schema_version": "ctxlayer.governance_adaptation.v1",
        "proposal_count": len(proposals),
        "proposals": proposals,
        "analytics_backend": grouped["backend"],
        "analytics_parity_ok": bool(grouped["parity_ok"]),
        "analytics_fallback_reason": grouped.get("fallback_reason"),
    }


def adopted_overlay(store: Any) -> list[dict[str, Any]]:
    proposals = {
        row["proposal_id"]: row
        for row in store.governance_playbook_proposals(limit=1000)
    }
    overlay: list[dict[str, Any]] = []
    for row in store.governance_playbook_adoptions(active_only=True):
        proposal = proposals.get(row["proposal_id"])
        evidence = _json_dict(proposal["evidence_json"]) if proposal else {}
        overlay.append(
            {
                "adoption_id": row["adoption_id"],
                "proposal_id": row["proposal_id"],
                "task_type": row["task_type"],
                "feature_id": row["feature_id"],
                "change": row["change"],
                "status": row["status"],
                "support": proposal["support"] if proposal else None,
                "lift": proposal["lift"] if proposal else None,
                "evidence": evidence,
            }
        )
    return overlay


def preview_adoption(proposal: dict[str, Any]) -> dict[str, Any]:
    return {
        "ok": True,
        "schema_version": "ctxlayer.governance_adoption_preview.v1",
        "proposal_id": proposal.get("proposal_id"),
        "overlay": [
            {
                "proposal_id": proposal.get("proposal_id"),
                "task_type": proposal.get("task_type"),
                "feature_id": proposal.get("feature_id"),
                "change": proposal.get("change"),
                "status": "preview",
                "support": proposal.get("support"),
                "lift": proposal.get("lift"),
            }
        ],
    }


def _analytics_feature_rows(
    store: Any,
    *,
    requested_backend: str,
    db_path: Path | None,
) -> dict[str, Any]:
    sqlite_sql = """
        SELECT task_type, feature_id, classification, used, outcome_result,
               difficulty_proxy_json, COUNT(*) AS count
        FROM (
          SELECT * FROM governance_feature_events
          ORDER BY created_at DESC, event_id
          LIMIT ?
        ) recent
        GROUP BY task_type, feature_id, classification, used, outcome_result,
                 difficulty_proxy_json
        ORDER BY task_type, feature_id, classification, used, outcome_result,
                 difficulty_proxy_json
    """
    duckdb_sql = sqlite_sql.replace(
        "FROM governance_feature_events", "FROM sqlite_db.governance_feature_events"
    )
    return query_rows(
        sqlite_conn=store.conn,
        db_path=db_path or store.db_path,
        sqlite_sql=sqlite_sql,
        duckdb_sql=duckdb_sql,
        params=(5000,),
        requested_backend=requested_backend,
    )


def _feature_stats(items: list[dict[str, Any]]) -> dict[str, Any]:
    used = [row for row in items if int(row["used"] or 0) == 1]
    unused = [row for row in items if int(row["used"] or 0) == 0]
    strata: dict[str, dict[str, Any]] = {}
    positive = 0
    for bucket, rows in _by_bucket(items).items():
        bucket_used = [row for row in rows if int(row["used"] or 0) == 1]
        bucket_unused = [row for row in rows if int(row["used"] or 0) == 0]
        if not bucket_used or not bucket_unused:
            continue
        used_rate = _success_rate(bucket_used)
        unused_rate = _success_rate(bucket_unused)
        strata[bucket] = {
            "used_count": len(bucket_used),
            "unused_count": len(bucket_unused),
            "used_success_rate": used_rate,
            "unused_success_rate": unused_rate,
            "lift": used_rate - unused_rate,
        }
        if used_rate > unused_rate:
            positive += 1
    return {
        "classification": str(items[0]["classification"] or "optional"),
        "sample_count": _count(items),
        "used_count": _count(used),
        "unused_count": _count(unused),
        "used_success_rate": _success_rate(used),
        "unused_success_rate": _success_rate(unused),
        "positive_strata": positive,
        "bucket_count": len(_by_bucket(items)),
        "strata": strata,
    }


def _success_rate(rows: list[Any]) -> float:
    if not rows:
        return 0.0
    passed = sum(
        int(row["count"] or 0)
        for row in rows
        if str(row["outcome_result"]).lower() in PASS_RESULTS
    )
    return passed / _count(rows)


def _by_bucket(items: list[Any]) -> dict[str, list[Any]]:
    buckets: dict[str, list[Any]] = defaultdict(list)
    for row in items:
        proxy = _json_dict(row["difficulty_proxy_json"])
        buckets[str(proxy.get("bucket") or "unknown")].append(row)
    return buckets


def _count(rows: list[Any]) -> int:
    return sum(int(row["count"] or 0) for row in rows)


def _json_dict(raw: str | bytes | None) -> dict[str, Any]:
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}
