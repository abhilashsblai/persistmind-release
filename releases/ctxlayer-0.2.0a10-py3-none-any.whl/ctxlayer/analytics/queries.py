from __future__ import annotations

from pathlib import Path
from typing import Any

from ctxlayer.analytics.duckdb_replica import DuckDBReplica, duckdb_status


def query_rows(
    *,
    sqlite_conn: Any,
    db_path: Path,
    sqlite_sql: str,
    duckdb_sql: str,
    params: list[Any] | tuple[Any, ...] | None = None,
    requested_backend: str = "auto",
) -> dict[str, Any]:
    sqlite_rows = _row_dicts(sqlite_conn.execute(sqlite_sql, params or []).fetchall())
    status = duckdb_status(db_path, requested=requested_backend)
    if not status.get("active"):
        return {
            "backend": "sqlite",
            "rows": sqlite_rows,
            "parity_ok": True,
            "fallback_reason": status.get("reason"),
        }
    try:
        with DuckDBReplica(db_path) as replica:
            duck_rows = replica.query(duckdb_sql, params)
    except Exception as exc:  # noqa: BLE001 - analytics must fall back to SQLite.
        return {
            "backend": "sqlite",
            "rows": sqlite_rows,
            "parity_ok": True,
            "fallback_reason": f"duckdb_error:{exc}",
        }
    if _normalized_rows(duck_rows) != _normalized_rows(sqlite_rows):
        return {
            "backend": "sqlite",
            "rows": sqlite_rows,
            "parity_ok": False,
            "fallback_reason": "duckdb_sqlite_parity_mismatch",
            "duckdb_rows": duck_rows,
        }
    return {
        "backend": "duckdb",
        "rows": duck_rows,
        "parity_ok": True,
        "fallback_reason": None,
    }


def grouped_counts(
    *,
    sqlite_conn: Any,
    db_path: Path,
    table: str,
    column: str,
    requested_backend: str = "auto",
) -> dict[str, Any]:
    sqlite_rows = sqlite_conn.execute(
        f"SELECT {column} AS key, COUNT(*) AS count FROM {table} GROUP BY {column}"
    ).fetchall()
    sqlite_counts = {str(row["key"]): int(row["count"]) for row in sqlite_rows}
    status = duckdb_status(db_path, requested=requested_backend)
    if not status.get("active"):
        return {
            "backend": "sqlite",
            "counts": sqlite_counts,
            "parity_ok": True,
            "fallback_reason": status.get("reason"),
        }
    try:
        with DuckDBReplica(db_path) as replica:
            duck_rows = replica.query(
                f"""
                SELECT {column} AS key, COUNT(*) AS count
                FROM sqlite_db.{table}
                GROUP BY {column}
                """
            )
        duck_counts = {str(row["key"]): int(row["count"]) for row in duck_rows}
    except Exception as exc:  # noqa: BLE001 - analytics must fall back to SQLite.
        return {
            "backend": "sqlite",
            "counts": sqlite_counts,
            "parity_ok": True,
            "fallback_reason": f"duckdb_error:{exc}",
        }
    if duck_counts != sqlite_counts:
        return {
            "backend": "sqlite",
            "counts": sqlite_counts,
            "parity_ok": False,
            "fallback_reason": "duckdb_sqlite_parity_mismatch",
            "duckdb_counts": duck_counts,
        }
    return {
        "backend": "duckdb",
        "counts": duck_counts,
        "parity_ok": True,
        "fallback_reason": None,
    }


def _row_dicts(rows: list[Any]) -> list[dict[str, Any]]:
    return [dict(row) for row in rows]


def _normalized_rows(rows: list[dict[str, Any]]) -> list[dict[str, str]]:
    return [
        {str(key): str(value) for key, value in sorted(row.items())}
        for row in rows
    ]
