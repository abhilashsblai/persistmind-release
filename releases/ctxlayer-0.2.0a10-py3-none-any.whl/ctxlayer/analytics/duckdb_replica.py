from __future__ import annotations

from pathlib import Path
from typing import Any


WRITE_PREFIXES = {
    "alter",
    "attach",
    "create",
    "delete",
    "detach",
    "drop",
    "insert",
    "merge",
    "pragma",
    "replace",
    "truncate",
    "update",
    "vacuum",
}


def duckdb_status(db_path: Path, *, requested: str = "auto") -> dict[str, Any]:
    requested = requested.strip().lower()
    if requested == "sqlite":
        return {
            "active": False,
            "analytics_backend": "sqlite",
            "reason": "sqlite_configured",
            "read_only": True,
        }
    try:
        import duckdb  # noqa: F401
    except Exception as exc:  # noqa: BLE001
        return {
            "active": False,
            "analytics_backend": "sqlite",
            "reason": "duckdb_not_installed",
            "error": str(exc),
            "read_only": True,
        }
    return {
        "active": True,
        "analytics_backend": "duckdb",
        "reason": None,
        "db_path": str(db_path),
        "read_only": True,
    }


class DuckDBReplica:
    """Read-only DuckDB view over the live SQLite database.

    DuckDB is a derived analytics satellite here. It never becomes authoritative:
    all writes stay in SQLite, and this wrapper rejects write-shaped statements.
    """

    def __init__(self, db_path: Path):
        self.db_path = Path(db_path)
        import duckdb

        self.conn = duckdb.connect(database=":memory:")
        self.conn.execute("INSTALL sqlite")
        self.conn.execute("LOAD sqlite")
        escaped = str(self.db_path).replace("'", "''")
        self.conn.execute(f"ATTACH '{escaped}' AS sqlite_db (TYPE SQLITE, READ_ONLY)")

    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> "DuckDBReplica":
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def query(self, sql: str, params: list[Any] | tuple[Any, ...] | None = None) -> list[dict[str, Any]]:
        normalized = sql.strip().split(None, 1)[0].lower() if sql.strip() else ""
        if normalized in WRITE_PREFIXES:
            raise PermissionError("duckdb replica is read-only")
        rows = self.conn.execute(sql, params or []).fetchall()
        columns = [item[0] for item in self.conn.description or []]
        return [dict(zip(columns, row, strict=False)) for row in rows]
