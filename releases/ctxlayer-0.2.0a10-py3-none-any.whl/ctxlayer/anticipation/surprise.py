from __future__ import annotations

import math
from typing import Any

from ctxlayer.learning.online import OnlineLearner
from ctxlayer.store import SQLiteStore

from .world_model import WorldModel, negative_log


class SurpriseEngine:
    def __init__(self, store: SQLiteStore, model: WorldModel):
        self.store = store
        self.model = model

    def score(
        self,
        *,
        context: dict[str, Any],
        observation: dict[str, Any],
        session_id: str | None = None,
        task_session_id: str | None = None,
        online: OnlineLearner | None = None,
    ) -> dict[str, Any]:
        model = self.model.latest()
        if not model or int(model.get("trained_on_count") or 0) <= 0:
            return {
                "surprise": None,
                "surprise_raw": None,
                "components": {},
                "model_id": None,
                "reason": "insufficient_history",
            }
        params = model["params"]
        if hasattr(self.model, "score_observation"):
            semantic = self.model.score_observation(
                context=context, observation=observation
            )
            if semantic.get("model_id"):
                return self._record_semantic_score(
                    model=model,
                    semantic=semantic,
                    context=context,
                    observation=observation,
                    session_id=session_id,
                    task_session_id=task_session_id,
                    online=online,
                )
        prediction = self.model.predict(context)
        event_type = str(observation.get("event_type") or "__other__")
        target_dir = str(observation.get("target_dir") or "")
        event_probability = float(
            prediction.get("event_type", {}).get(event_type, 0.0) or 0.0
        )
        if event_probability <= 0:
            event_probability = float(
                prediction.get("event_type", {}).get("__other__", 0.01) or 0.01
            )
        dir_probability = float(
            prediction.get("target_dir", {}).get(target_dir, 0.0) or 0.0
        )
        if dir_probability <= 0:
            dir_probability = float(
                prediction.get("target_dir", {}).get("__other__", 0.01) or 0.01
            )
        outcome_prior = float(
            params.get("outcome_failure_prior", {}).get(
                target_dir, prediction.get("failure_prior", 0.0)
            )
            or 0.0
        )
        lesson_prior = float(
            params.get("failure_lesson_prior", {}).get(target_dir, 0.0) or 0.0
        )
        failure_prior = max(outcome_prior, lesson_prior)
        weights = params.get("weights", {})
        seq_surprise = negative_log(event_probability)
        locality_surprise = negative_log(dir_probability)
        online_delta: dict[str, Any] = {}
        if online is not None:
            online_delta = online.adjust(context=context, observation=observation)
            failure_prior = min(
                1.0,
                failure_prior + float(online_delta.get("failure_boost", 0.0) or 0.0),
            )
        surprise_raw = (
            float(weights.get("sequence", 0.45)) * _squash_log(seq_surprise)
            + float(weights.get("locality", 0.25)) * _squash_log(locality_surprise)
            + float(weights.get("failure", 0.30)) * failure_prior
        )
        calibration_input = max(failure_prior, min(1.0, surprise_raw))
        calibrated = _apply_calibration(calibration_input, model.get("calibration", {}))
        surprise = max(failure_prior, calibrated)
        components = {
            "sequence": round(_squash_log(seq_surprise), 6),
            "locality": round(_squash_log(locality_surprise), 6),
            "failure_prior": round(failure_prior, 6),
            "event_probability": round(event_probability, 6),
            "target_dir_probability": round(dir_probability, 6),
            "calibration_input": round(calibration_input, 6),
        }
        if online_delta:
            components["online_delta"] = online_delta
        prediction_id = self.store.record_anticipation_prediction(
            repo_id=self.model.repo_id,
            workspace_id=model.get("workspace_id"),
            session_id=session_id,
            task_session_id=task_session_id,
            model_id=model["model_id"],
            context=context,
            observation=observation,
            surprise_raw=surprise_raw,
            surprise=surprise,
            components=components,
        )
        return {
            "surprise": round(surprise, 6),
            "surprise_raw": round(surprise_raw, 6),
            "components": components,
            "model_id": model["model_id"],
            "prediction_id": prediction_id,
            "reason": None,
        }

    def _record_semantic_score(
        self,
        *,
        model: dict[str, Any],
        semantic: dict[str, Any],
        context: dict[str, Any],
        observation: dict[str, Any],
        session_id: str | None,
        task_session_id: str | None,
        online: OnlineLearner | None,
    ) -> dict[str, Any]:
        failure_prior = float(semantic.get("failure_prior", 0.0) or 0.0)
        online_delta: dict[str, Any] = {}
        if online is not None:
            online_delta = online.adjust(context=context, observation=observation)
            failure_prior = min(
                1.0,
                failure_prior + float(online_delta.get("failure_boost", 0.0) or 0.0),
            )
        surprise_raw = max(
            failure_prior, min(1.0, float(semantic.get("surprise_raw", 0.0) or 0.0))
        )
        calibration_input = surprise_raw
        calibrated = _apply_calibration(calibration_input, model.get("calibration", {}))
        surprise = max(failure_prior, calibrated)
        components = dict(semantic.get("components", {}) or {})
        components["failure_prior"] = round(failure_prior, 6)
        components["calibration_input"] = round(calibration_input, 6)
        if online_delta:
            components["online_delta"] = online_delta
        prediction_id = self.store.record_anticipation_prediction(
            repo_id=self.model.repo_id,
            workspace_id=model.get("workspace_id"),
            session_id=session_id,
            task_session_id=task_session_id,
            model_id=model["model_id"],
            context=context,
            observation=observation,
            surprise_raw=surprise_raw,
            surprise=surprise,
            components=components,
        )
        return {
            "surprise": round(surprise, 6),
            "surprise_raw": round(surprise_raw, 6),
            "components": components,
            "model_id": model["model_id"],
            "prediction_id": prediction_id,
            "reason": None,
        }


def _squash_log(value: float) -> float:
    if not math.isfinite(value):
        return 1.0
    return min(1.0, value / 5.0)


def _apply_calibration(value: float, calibration: dict[str, Any]) -> float:
    bounded = min(1.0, max(0.0, float(value)))
    bins = calibration.get("bins", []) if isinstance(calibration, dict) else []
    usable = [
        item
        for item in bins
        if isinstance(item, dict)
        and item.get("raw_score") is not None
        and item.get("calibrated_score") is not None
    ]
    if not usable:
        return bounded
    nearest = min(
        usable,
        key=lambda item: abs(float(item.get("raw_score") or 0.0) - bounded),
    )
    if abs(float(nearest.get("raw_score") or 0.0) - bounded) > 0.25:
        return bounded
    return min(1.0, max(0.0, float(nearest.get("calibrated_score") or bounded)))
