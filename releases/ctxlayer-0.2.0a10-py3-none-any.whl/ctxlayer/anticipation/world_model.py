from __future__ import annotations

import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from ctxlayer.store import SQLiteStore


MODEL_KIND = "frequency_v0"


class WorldModel:
    """Deterministic frequency model of normal agent behavior for one repo."""

    def __init__(self, store: SQLiteStore, repo_id: str, *, kind: str = MODEL_KIND):
        self.store = store
        self.repo_id = repo_id
        self.kind = kind
        self._row: Any | None = None
        self._params: dict[str, Any] | None = None

    def train(
        self,
        *,
        workspace_id: str | None = None,
        outcome_rows: list[dict[str, Any]] | None = None,
    ) -> str:
        events = self._event_rows(workspace_id=workspace_id)
        seq_counts: dict[str, Counter[str]] = defaultdict(Counter)
        dir_counts: Counter[str] = Counter()
        conditioned_dir_counts: dict[str, Counter[str]] = defaultdict(Counter)
        event_vocab: set[str] = set()
        last_by_session: dict[str, str] = {}
        trained_on_count = 0
        for row in events:
            session_id = str(row["session_id"])
            event_type = str(row["event_type"])
            payload = _json(row["payload_json"])
            state = str(payload.get("state") or payload.get("task_state") or "unknown")
            task_terms = _top_terms(
                str(payload.get("task") or payload.get("task_text") or "")
            )
            last_event = last_by_session.get(session_id, "START")
            seq_key = _seq_key(state, last_event)
            seq_counts[seq_key][event_type] += 1
            event_vocab.add(event_type)
            for target in _payload_paths(payload):
                directory = _dirname(target)
                dir_counts[directory] += 1
                conditioned_dir_counts[_condition_key(state, task_terms)][
                    directory
                ] += 1
            last_by_session[session_id] = event_type
            trained_on_count += 1

        outcome_rows = self._outcome_rows() if outcome_rows is None else outcome_rows
        outcome_stats = _outcome_failure_stats(outcome_rows)
        holdout_stats = _outcome_failure_stats(_holdout_rows(outcome_rows))
        outcome_priors = {
            key: value["smoothed_failure_rate"]
            for key, value in sorted(outcome_stats.items())
        }
        memory_priors = self._failure_lesson_priors()
        params = {
            "schema": "ctxlayer.anticipation.frequency_v0",
            "repo_id": self.repo_id,
            "seq_counts": {
                key: dict(sorted(counter.items()))
                for key, counter in sorted(seq_counts.items())
            },
            "dir_counts": dict(sorted(dir_counts.items())),
            "conditioned_dir_counts": {
                key: dict(sorted(counter.items()))
                for key, counter in sorted(conditioned_dir_counts.items())
            },
            "event_vocab": sorted(event_vocab),
            "outcome_failure_prior": outcome_priors,
            "failure_lesson_prior": memory_priors,
            "weights": {"sequence": 0.45, "locality": 0.25, "failure": 0.30},
            "smoothing": 1.0,
        }
        calibration = _calibration_from_outcome_stats(outcome_stats, holdout_stats)
        model_id = self.store.put_anticipation_model(
            repo_id=self.repo_id,
            workspace_id=workspace_id,
            kind=self.kind,
            params=params,
            calibration=calibration,
            trained_on_count=trained_on_count,
            ece=calibration.get("ece"),
        )
        self._row = self.store.conn.execute(
            "SELECT * FROM anticipation_models WHERE model_id = ?", (model_id,)
        ).fetchone()
        return model_id

    def latest(self) -> dict[str, Any] | None:
        row = self._latest_row()
        if row is None:
            return None
        return {
            "model_id": row["model_id"],
            "repo_id": row["repo_id"],
            "workspace_id": row["workspace_id"],
            "kind": row["kind"],
            "params": json.loads(row["params_json"] or "{}"),
            "calibration": json.loads(row["calibration_json"] or "{}"),
            "trained_on_count": int(row["trained_on_count"] or 0),
            "ece": row["ece"],
            "params_hash": row["params_hash"],
            "created_at": row["created_at"],
        }

    def predict(self, context: dict[str, Any]) -> dict[str, Any]:
        model = self.latest()
        if not model or int(model["trained_on_count"] or 0) <= 0:
            return {
                "model_id": None,
                "reason": "insufficient_history",
                "event_type": {},
                "target_dir": {},
                "failure_prior": 0.0,
            }
        params = model["params"]
        state = str(context.get("state") or "unknown")
        last_event = str(context.get("last_event") or "START")
        seq = params.get("seq_counts", {}).get(_seq_key(state, last_event), {})
        event_dist = _smoothed_distribution(seq, params.get("event_vocab", []))
        task_terms = [
            str(term) for term in context.get("task_terms", []) if str(term).strip()
        ]
        conditioned_counts = params.get("conditioned_dir_counts", {}).get(
            _condition_key(state, task_terms), {}
        )
        locality_counts = conditioned_counts or params.get("dir_counts", {})
        target_dist = _smoothed_distribution(
            locality_counts, list(params.get("dir_counts", {}).keys())
        )
        active_dir = _dirname(
            str(context.get("active_path") or context.get("active_dir") or "")
        )
        failure_prior = float(
            params.get("outcome_failure_prior", {}).get(
                active_dir, params.get("failure_lesson_prior", {}).get(active_dir, 0.0)
            )
            or 0.0
        )
        return {
            "model_id": model["model_id"],
            "params_hash": model["params_hash"],
            "event_type": event_dist,
            "target_dir": target_dist,
            "failure_prior": round(failure_prior, 6),
        }

    def _latest_row(self) -> Any | None:
        if self._row is None:
            self._row = self.store.latest_anticipation_model(
                repo_id=self.repo_id, kind=self.kind
            )
        return self._row

    def _event_rows(self, *, workspace_id: str | None) -> list[Any]:
        clauses = ["s.repo_id = ?"]
        params: list[Any] = [self.repo_id]
        if workspace_id:
            clauses.append("s.workspace_id = ?")
            params.append(workspace_id)
        return self.store.conn.execute(
            f"""
            SELECT e.*, s.workspace_id, s.repo_id
            FROM agent_session_events e
            JOIN agent_sessions s ON s.session_id = e.session_id
            WHERE {" AND ".join(clauses)}
            ORDER BY e.event_time, e.event_id
            """,
            params,
        ).fetchall()

    def _outcome_rows(self) -> list[dict[str, Any]]:
        rows = self.store.conn.execute(
            "SELECT result, files_changed_json FROM outcomes ORDER BY rowid"
        ).fetchall()
        return [
            {
                "result": str(row["result"] or ""),
                "files": _json_list(row["files_changed_json"]),
            }
            for row in rows
        ]

    def _failure_lesson_priors(self) -> dict[str, float]:
        priors: dict[str, float] = {}
        try:
            rows = self.store.memory_records(
                type="failure_lesson", repo_id=self.repo_id
            )
        except Exception:
            rows = []
        for row in rows:
            text = " ".join(
                str(row[key] or "")
                for key in ("subject_key", "assertion", "applies_when", "avoid_when")
                if key in row.keys()
            )
            for token in text.replace("\\", "/").split():
                if "/" not in token:
                    continue
                priors[_dirname(token.strip("`'\".,:;()[]{}"))] = 0.8
        return dict(sorted(priors.items()))


def context_from_payload(
    payload: dict[str, Any], *, previous_event: str = "START"
) -> dict[str, Any]:
    paths = _payload_paths(payload)
    active = paths[0] if paths else ""
    task_text = str(payload.get("task") or payload.get("task_text") or "")
    return {
        "task_terms": _top_terms(task_text),
        "state": str(payload.get("state") or payload.get("task_state") or "unknown"),
        "last_event": previous_event,
        "active_dir": _dirname(active),
        "active_path": active,
    }


def observation_from_event(event_type: str, payload: dict[str, Any]) -> dict[str, Any]:
    paths = _payload_paths(payload)
    return {
        "event_type": event_type,
        "target_paths": paths,
        "target_dir": _dirname(paths[0]) if paths else "",
        "touches_critical": any(_looks_critical(path) for path in paths),
    }


def _seq_key(state: str, last_event: str) -> str:
    return (
        f"{state.strip().lower() or 'unknown'}|{last_event.strip().lower() or 'START'}"
    )


def _condition_key(state: str, task_terms: list[str]) -> str:
    terms = ",".join(sorted(str(term).lower() for term in task_terms if term))
    return f"{state.strip().lower() or 'unknown'}|{terms}"


def _smoothed_distribution(
    counts: dict[str, Any], vocab: list[str]
) -> dict[str, float]:
    keys = sorted(set(vocab) | set(counts) | {"__other__"})
    total = sum(int(counts.get(key, 0) or 0) for key in keys)
    denominator = total + len(keys)
    return {
        key: round((int(counts.get(key, 0) or 0) + 1) / denominator, 6) for key in keys
    }


def _outcome_failure_stats(rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    totals: Counter[str] = Counter()
    failures: Counter[str] = Counter()
    for row in rows:
        failed = str(row.get("result") or "").lower().startswith(("fail", "blocked"))
        for path in row.get("files", []):
            directory = _dirname(str(path))
            totals[directory] += 1
            if failed:
                failures[directory] += 1
    return {
        key: {
            "total": int(totals[key]),
            "failures": int(failures[key]),
            "failure_rate": round(failures[key] / totals[key], 6),
            "smoothed_failure_rate": round((failures[key] + 1) / (totals[key] + 2), 6),
        }
        for key in sorted(totals)
        if totals[key] > 0
    }


def _holdout_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if len(rows) < 4:
        return rows
    split = max(1, int(len(rows) * 0.7))
    return rows[split:]


def _calibration_from_outcome_stats(
    stats: dict[str, dict[str, Any]], holdout_stats: dict[str, dict[str, Any]]
) -> dict[str, Any]:
    if not stats:
        return {"method": "outcome_bins_v1", "bins": [], "ece": None}
    bins = []
    weighted_error = 0.0
    weight_total = 0
    for bucket, item in sorted(stats.items()):
        holdout = holdout_stats.get(bucket)
        expected = float(item["smoothed_failure_rate"])
        observed = (
            float(holdout["failure_rate"]) if holdout else float(item["failure_rate"])
        )
        weight = int(holdout["total"] if holdout else item["total"])
        weighted_error += weight * abs(expected - observed)
        weight_total += weight
        bins.append(
            {
                "bucket": bucket,
                "raw_score": round(expected, 6),
                "calibrated_score": round(float(item["failure_rate"]), 6),
                "failure_rate": round(float(item["failure_rate"]), 6),
                "count": int(item["total"]),
                "holdout_failure_rate": round(observed, 6),
                "holdout_count": weight,
            }
        )
    ece = weighted_error / weight_total if weight_total else 0.0
    return {
        "method": "outcome_bins_v1",
        "bins": bins,
        "ece": round(ece, 6),
        "holdout": bool(holdout_stats),
    }


def _payload_paths(payload: dict[str, Any]) -> list[str]:
    paths: list[str] = []
    for key in ("path", "file_path", "filepath", "target_path"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            paths.append(value)
    value = payload.get("target_paths") or payload.get("paths") or payload.get("files")
    if isinstance(value, list):
        paths.extend(str(item) for item in value if str(item).strip())
    args = payload.get("args") or payload.get("arguments") or payload.get("input")
    if isinstance(args, dict):
        paths.extend(_payload_paths(args))
    return sorted({_normalize_path(path) for path in paths})


def _dirname(path: str) -> str:
    normalized = _normalize_path(path)
    if not normalized:
        return ""
    parent = str(Path(normalized).parent).replace("\\", "/")
    return "" if parent == "." else parent


def _normalize_path(path: str) -> str:
    return str(path).replace("\\", "/").lstrip("./")


def _json(value: str | None) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _json_list(value: str | None) -> list[str]:
    try:
        parsed = json.loads(value or "[]")
    except json.JSONDecodeError:
        return []
    return [str(item) for item in parsed] if isinstance(parsed, list) else []


def _top_terms(text: str, limit: int = 5) -> list[str]:
    words = [
        token.strip(".,:;()[]{}").lower()
        for token in text.split()
        if len(token.strip(".,:;()[]{}")) >= 4
    ]
    return sorted(Counter(words), key=lambda key: (-Counter(words)[key], key))[:limit]


def _looks_critical(path: str) -> bool:
    lowered = _normalize_path(path).lower()
    return any(
        part in lowered for part in ("/auth/", "/billing/", "/payments/", "migration")
    )


def negative_log(probability: float) -> float:
    return -math.log(max(min(float(probability), 1.0), 1e-9))
