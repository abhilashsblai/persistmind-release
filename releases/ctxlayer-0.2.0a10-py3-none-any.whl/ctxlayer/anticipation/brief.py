from __future__ import annotations

import time
from pathlib import Path
from typing import Any

from ctxlayer.anticipation.interoception import build_nudge_message
from ctxlayer.anticipation.ui_redundancy import review_ui_redundancy


def build_brief(
    *,
    engine: Any,
    mode: str,
    degraded: dict[str, Any] | None,
    repo_root: Path,
    snapshot: Any,
    task: str,
    seed_paths: list[str] | None = None,
    session_id: str | None = None,
    task_session_id: str | None = None,
    settings: Any,
    pack: dict[str, Any] | None = None,
    source: str = "intuition_brief",
    proposed_content: str | None = None,
    proposed_path: str | None = None,
) -> dict[str, Any]:
    started = time.perf_counter()
    paths = list(seed_paths or [])
    brief_config = getattr(settings.anticipation, "brief", None)
    if mode == "off" or not getattr(brief_config, "enabled", True):
        return _base(
            available=False,
            mode=mode,
            confidence="low",
            degraded=degraded,
            started=started,
            message="Intuition brief is disabled.",
        )
    try:
        status = engine.status()
        confidence = _confidence(status, settings)
        gut = None
        if session_id:
            gut = engine.gut(
                session_id=session_id,
                task_session_id=task_session_id,
                active_paths=paths,
            )
        foresight = _foresight(
            engine=engine,
            snapshot=snapshot,
            task=task,
            paths=paths,
            pack=pack,
            settings=settings,
        )
        ui_redundancy = None
        if getattr(brief_config, "ui_redundancy_enabled", True):
            ui_redundancy = review_ui_redundancy(
                repo_root,
                task=task,
                paths=paths,
                proposed_content=proposed_content,
                proposed_path=proposed_path,
                max_findings=int(getattr(brief_config, "max_ui_findings", 5)),
            )
        available = bool(
            not status.get("cold_start")
            or (ui_redundancy and ui_redundancy.get("relevant"))
            or foresight
            or gut
        )
        message = _brief_message(
            status=status,
            gut=gut,
            foresight=foresight,
            ui_redundancy=ui_redundancy,
        )
        _record_ui_prediction(
            engine=engine,
            source=source,
            session_id=session_id,
            task_session_id=task_session_id,
            task=task,
            paths=paths,
            ui_redundancy=ui_redundancy,
            latency_ms=round((time.perf_counter() - started) * 1000, 3),
        )
        return {
            **_base(
                available=available,
                mode=mode,
                confidence=confidence,
                degraded=degraded,
                started=started,
                message=message,
            ),
            "model": status.get("latest_model"),
            "gut": _gut_summary(gut),
            "foresight": foresight,
            "ui_redundancy": ui_redundancy,
        }
    except Exception as exc:  # noqa: BLE001 - intuition must never break packs/hooks.
        return _base(
            available=False,
            mode=mode,
            confidence="low",
            degraded={
                "status": "degraded",
                "reason": "intuition_brief_error",
                "error": str(exc),
            },
            started=started,
            message="Intuition brief could not be built.",
        )


def _base(
    *,
    available: bool,
    mode: str,
    confidence: str,
    degraded: dict[str, Any] | None,
    started: float,
    message: str,
) -> dict[str, Any]:
    return {
        "schema_version": "ctxlayer.intuition_brief.v1",
        "available": available,
        "mode": mode,
        "confidence": confidence,
        "message": message,
        "degraded": degraded,
        "latency_ms": round((time.perf_counter() - started) * 1000, 3),
        "advisory_only": True,
    }


def _confidence(status: dict[str, Any], settings: Any) -> str:
    latest = status.get("latest_model") or {}
    trained = int(latest.get("trained_on_count") or 0)
    ece = latest.get("ece")
    if status.get("cold_start") or trained < 5 or ece is None:
        return "low"
    threshold = float(settings.anticipation.guards.enforce_requires_ece_below)
    if float(ece) <= threshold:
        return "high" if trained >= 25 else "medium"
    return "low"


def _foresight(
    *,
    engine: Any,
    snapshot: Any,
    task: str,
    paths: list[str],
    pack: dict[str, Any] | None,
    settings: Any,
) -> list[dict[str, Any]]:
    brief_config = getattr(settings.anticipation, "brief", None)
    top_k = int(getattr(brief_config, "max_foresight", 3))
    if top_k <= 0:
        return []
    try:
        report = engine.lookahead(
            snapshot=snapshot,
            task=task,
            current_paths=paths,
            pack=pack,
            top_k=top_k,
        )
    except Exception:
        return []
    entries = []
    for item in report.get("candidates", [])[:top_k]:
        entries.append(
            {
                "concern": item.get("rationale"),
                "expected_risk": item.get("expected_risk"),
                "uncertainty": item.get("expected_uncertainty"),
                "recommendation": item.get("recommended_action"),
                "paths": item.get("predicted_paths", []),
            }
        )
    return entries


def _gut_summary(gut: dict[str, Any] | None) -> dict[str, Any] | None:
    if not gut:
        return None
    components = gut.get("components") or {}
    top = sorted(
        (
            {"name": name, "value": value}
            for name, value in components.items()
            if isinstance(value, int | float)
        ),
        key=lambda item: float(item["value"]),
        reverse=True,
    )[:3]
    score = float(gut.get("gut") or 0.0)
    level = "fragile" if score >= 0.7 else "elevated" if score >= 0.35 else "calm"
    return {
        "score": round(score, 6),
        "level": level,
        "top_components": top,
        "summary": gut.get("summary"),
    }


def _brief_message(
    *,
    status: dict[str, Any],
    gut: dict[str, Any] | None,
    foresight: list[dict[str, Any]],
    ui_redundancy: dict[str, Any] | None,
) -> str:
    if ui_redundancy and ui_redundancy.get("finding_count"):
        return str(ui_redundancy.get("message"))
    if foresight:
        first = foresight[0]
        return (
            "Anticipation foresight: "
            f"{first.get('recommendation')} recommended for "
            f"{', '.join(first.get('paths') or []) or 'this task'}."
        )
    if gut:
        return build_nudge_message(
            target_paths=[],
            surprise={"surprise": 0.0, "components": {}},
            level="advisory",
            interoception=gut,
        )
    if status.get("cold_start"):
        return "Intuition is still learning; no calibrated prior is available yet."
    return "No elevated intuition concerns detected."


def _record_ui_prediction(
    *,
    engine: Any,
    source: str,
    session_id: str | None,
    task_session_id: str | None,
    task: str,
    paths: list[str],
    ui_redundancy: dict[str, Any] | None,
    latency_ms: float,
) -> None:
    if not ui_redundancy or not ui_redundancy.get("relevant"):
        return
    score = min(1.0, float(ui_redundancy.get("finding_count") or 0) / 3.0)
    try:
        engine.store.record_anticipation_prediction(
            repo_id=engine.repo_id,
            workspace_id=engine.workspace_id,
            session_id=session_id,
            task_session_id=task_session_id,
            model_id="deterministic_ui_redundancy_v1",
            context={"kind": "ui_redundancy", "task": task},
            observation={
                "paths": paths,
                "finding_count": ui_redundancy.get("finding_count", 0),
            },
            surprise_raw=score,
            surprise=score,
            components={"ui_redundancy": ui_redundancy},
            latency_ms=latency_ms,
            timed_out=False,
            source=source,
        )
    except Exception:
        return
