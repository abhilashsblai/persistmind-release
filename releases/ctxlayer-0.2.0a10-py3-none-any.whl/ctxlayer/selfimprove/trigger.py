from __future__ import annotations

from typing import Any


def maybe_run_daily(engine: Any) -> dict[str, Any]:
    status = engine.status()
    today = status.get("today")
    if today:
        return {"ok": True, "ran": False, "reason": "already_ran_today", "run": today}
    return engine.brief(force=True)
