from __future__ import annotations

from pathlib import Path
from typing import Any

from ctxlayer.agents.adapters import resolve
from ctxlayer.agents.adapters.base import BootstrapContext
from ctxlayer.agents.contract import (
    agent_contract,
    capabilities_yaml,
    claude_command,
    codex_agent_toml,
    codex_hooks_json,
    codex_mcp_config,
    codex_project_config,
    ensure_agent_contract_guidance,
    hook_script,
    mcp_readme,
    production_asset_verifier,
    powershell_string,
    replace_inline_json_plan_commands,
    toml_string,
    write_if_changed,
    SUBAGENT_SPECS,
)


def bootstrap_project(
    repo_root: Path,
    *,
    agents: list[str],
    mcp_command: str = "ctxlayer",
    mcp_repo: str = ".",
) -> dict[str, Any]:
    adapters = resolve(agents)
    agent_names = [adapter.name for adapter in adapters]
    ctx = BootstrapContext(
        repo_root=repo_root,
        mcp_command=mcp_command,
        mcp_repo=mcp_repo,
        shell="powershell",
        agent_names=agent_names,
    )

    mcp_dir = repo_root / ".ctxlayer" / "mcp"
    mcp_dir.mkdir(parents=True, exist_ok=True)
    shared_written = [
        write_if_changed(mcp_dir / "README.md", mcp_readme(mcp_command, mcp_repo))
    ]

    capabilities_path = repo_root / "ctxlayer.capabilities.yaml"
    capabilities_created = False
    if not capabilities_path.exists():
        write_if_changed(capabilities_path, capabilities_yaml())
        capabilities_created = True

    verifier_path = repo_root / "tools" / "verify-production-assets.mjs"
    verifier_created = False
    if not verifier_path.exists():
        write_if_changed(verifier_path, production_asset_verifier())
        verifier_created = True

    agents_file = repo_root / "AGENTS.md"
    agents_before = (
        agents_file.read_text(encoding="utf-8") if agents_file.exists() else None
    )
    surfaces: dict[str, list[str]] = {}
    enforcement: dict[str, str] = {}
    for adapter in adapters:
        written = adapter.render(ctx)
        surfaces[adapter.name] = [str(path) for path in written]
        enforcement[adapter.name] = "hooks" if adapter.supports_hooks else "mcp-only"

    codex_files = surfaces.get("codex", [])
    agents_after = (
        agents_file.read_text(encoding="utf-8") if agents_file.exists() else None
    )
    agents_file_updated = agents_before != agents_after
    return {
        "agents": agent_names,
        "agents_configured": agent_names,
        "agents_file": str(agents_file),
        "agents_file_updated": agents_file_updated,
        "capabilities_file": str(capabilities_path),
        "capabilities_file_created": capabilities_created,
        "production_asset_verifier": str(verifier_path),
        "production_asset_verifier_created": verifier_created,
        "mcp_dir": str(mcp_dir),
        "mcp_repo": mcp_repo,
        "mcp_files": [str(path) for path in shared_written],
        "surfaces": surfaces,
        "enforcement_level": enforcement,
        "codex_dir": str(repo_root / ".codex"),
        "codex_files": codex_files,
    }


def _write_if_changed(path: Path, content: str) -> Path:
    return write_if_changed(path, content)


def _write_codex_project_surfaces(
    repo_root: Path, command: str, mcp_repo: str
) -> list[Path]:
    from ctxlayer.agents.adapters.codex import CodexAdapter

    ctx = BootstrapContext(
        repo_root=repo_root,
        mcp_command=command,
        mcp_repo=mcp_repo,
        shell="powershell",
        agent_names=["codex"],
    )
    return CodexAdapter().render(ctx)


def _ensure_agent_contract_guidance(existing: str) -> str:
    return ensure_agent_contract_guidance(existing)


def _replace_inline_json_plan_commands(existing: str) -> str:
    return replace_inline_json_plan_commands(existing)


def _agent_contract(agents: list[str]) -> str:
    return agent_contract(agents)


def _codex_config(command: str, mcp_repo: str) -> str:
    return codex_mcp_config(command, mcp_repo)


def _codex_project_config(command: str, mcp_repo: str) -> str:
    return codex_project_config(command, mcp_repo)


def _codex_hooks_json(repo_root: Path | None = None) -> str:
    return codex_hooks_json(repo_root)


def _codex_agent_explorer() -> str:
    return codex_agent_toml(SUBAGENT_SPECS[0])


def _codex_agent_worker() -> str:
    return codex_agent_toml(SUBAGENT_SPECS[1])


def _codex_agent_reviewer() -> str:
    return codex_agent_toml(SUBAGENT_SPECS[2])


def _codex_agent_verifier() -> str:
    return codex_agent_toml(SUBAGENT_SPECS[3])


def _codex_hook_script() -> str:
    return hook_script()


def _claude_command(command: str, mcp_repo: str) -> str:
    return claude_command(command, mcp_repo)


def _mcp_readme(command: str, mcp_repo: str) -> str:
    return mcp_readme(command, mcp_repo)


def _toml_string(value: str) -> str:
    return toml_string(value)


def _powershell_string(value: str) -> str:
    return powershell_string(value)


def _capabilities_yaml() -> str:
    return capabilities_yaml()


def _production_asset_verifier() -> str:
    return production_asset_verifier()
