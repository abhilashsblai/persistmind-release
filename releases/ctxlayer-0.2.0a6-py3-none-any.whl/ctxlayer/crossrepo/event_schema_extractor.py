from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def extract(repo_root: Path) -> list[dict[str, Any]]:
    contracts: list[dict[str, Any]] = []
    for path in [*repo_root.rglob("*event*.json"), *repo_root.rglob("*schema*.json")]:
        rel = path.relative_to(repo_root).as_posix()
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        name = data.get("title") or data.get("$id") or path.stem
        kind = "publishes_event" if "event" in rel.lower() else "reads_shared_schema"
        contracts.append({"path": rel, "kind": kind, "name": str(name), "metadata": {}})
    return contracts
