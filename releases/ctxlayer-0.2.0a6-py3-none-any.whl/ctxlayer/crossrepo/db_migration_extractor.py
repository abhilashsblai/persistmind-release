from __future__ import annotations

import re
from pathlib import Path
from typing import Any


def extract(repo_root: Path) -> list[dict[str, Any]]:
    contracts: list[dict[str, Any]] = []
    for path in repo_root.rglob("*"):
        rel = path.relative_to(repo_root).as_posix()
        if not path.is_file() or "migration" not in rel.lower():
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        for table in re.findall(
            r"\b(?:CREATE|ALTER)\s+TABLE\s+([A-Za-z_][A-Za-z0-9_]*)", text, re.I
        ):
            contracts.append(
                {"path": rel, "kind": "uses_migration", "name": table, "metadata": {}}
            )
    return contracts
