from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from ctxlayer.utils import stable_id


WRITE_CAPABLE_TOOLS = {
    "apply_patch",
    "edit",
    "write",
    "bash",
    "shell",
    "mcp",
}

BROAD_TASK_TERMS = {
    "all",
    "complete",
    "entire",
    "extensive",
    "implement",
    "phase",
    "phases",
    "plan",
    "plans",
    "refactor",
    "system",
}


def enforcement_status(repo_root: Path, readiness: dict[str, Any]) -> dict[str, Any]:
    checks = readiness.get("checks", {}) if isinstance(readiness, dict) else {}
    hook_status = {
        "session_start": bool(checks.get("codex_hooks")),
        "user_prompt_submit": bool(checks.get("codex_hooks")),
        "pre_tool_use": bool(checks.get("codex_hooks")),
        "post_tool_use": bool(checks.get("codex_hooks")),
        "subagent_start": bool(checks.get("codex_hooks")),
        "subagent_stop": bool(checks.get("codex_hooks")),
        "stop": bool(checks.get("codex_hooks")),
    }
    blocking = []
    if not checks.get("agents_contract"):
        blocking.append("AGENTS.md CTX contract is missing")
    if not checks.get("codex_project_config"):
        blocking.append(".codex/config.toml is missing")
    if not checks.get("codex_hooks"):
        blocking.append("Codex hook surface is missing")
    if not checks.get("codex_agents"):
        blocking.append("CTX Codex custom agents are missing")
    if not checks.get("codex_mcp_snippet"):
        blocking.append("CTX MCP snippet is missing")

    return {
        "ok": not blocking,
        "schema_version": "ctxlayer.codex_enforcement.v1",
        "repo": str(repo_root),
        "preflight_required": True,
        "preflight_ready": False,
        "blocking_reasons": blocking,
        "hook_status": hook_status,
        "mcp_status": {
            "snippet_present": bool(checks.get("codex_mcp_snippet")),
            "project_config_present": bool(checks.get("codex_project_config")),
        },
        "agent_surfaces": {
            "custom_agents_present": bool(checks.get("codex_agents")),
            "max_depth": 1,
            "max_threads": 4,
        },
        "setup": readiness,
        "enforcement_scope": "repo-local trusted-project hooks plus AGENTS.md, Git hooks, CI, and audit",
        "tamper_model": "tamper-evident repo-local enforcement; use managed requirements for hard enterprise control",
    }


def memory_retrieval_manifest(
    *,
    task: str,
    pack: dict[str, Any],
    recall: dict[str, Any],
) -> dict[str, Any]:
    retrieval = (
        pack.get("memory_retrieval", {})
        if isinstance(pack.get("memory_retrieval"), dict)
        else {}
    )
    served_counts = dict(retrieval.get("served_counts_by_type", {}) or {})
    for section, memory_type in [
        ("continuations", "continuation"),
        ("policy_references", "policy_reference"),
        ("project_memory", "project_memory"),
        ("skills", "skill_reference"),
    ]:
        items = pack.get(section, []) if isinstance(pack.get(section), list) else []
        if items:
            served_counts[memory_type] = max(
                int(served_counts.get(memory_type, 0)), len(items)
            )

    recall_records = (
        recall.get("records", []) if isinstance(recall.get("records"), list) else []
    )
    for record in recall_records:
        record_type = str(record.get("type") or "memory")
        served_counts[record_type] = served_counts.get(record_type, 0) + 1

    return {
        "memory_retrieval_id": stable_id(
            pack.get("pack_id", ""), task, "codex-memory-retrieval"
        ),
        "query": task,
        "weights": retrieval.get("weights", {}),
        "backend_status": retrieval.get("backend_status", {"lexical": "ok"}),
        "excluded_counts": retrieval.get("excluded_counts", {}),
        "served_counts_by_type": served_counts,
        "stale_count": int(retrieval.get("stale_count", 0) or 0),
        "quarantine_count": int(retrieval.get("quarantine_count", 0) or 0),
        "no_backend_diagnostics": retrieval.get("no_backend_diagnostics", []),
    }


def parallel_plan(
    *,
    task: str,
    task_session_id: str,
    pack_id: str,
    paths: list[str] | None = None,
    impact_report: dict[str, Any] | None = None,
    max_threads: int = 4,
    preflight_ready: bool = True,
    worktree_clean: bool = True,
) -> dict[str, Any]:
    paths = sorted({path for path in paths or [] if path})
    terms = {part.strip(".,:;()[]{}").lower() for part in task.split()}
    impacted = impact_report.get("impacted_paths", []) if impact_report else []
    risk = (impact_report.get("risk", {}) if impact_report else {}) or {}
    risk_score = float(risk.get("score", 0.0) or 0.0)
    broad = bool(terms & BROAD_TASK_TERMS) or len(paths) >= 3 or len(impacted) >= 8
    blockers = []
    if not preflight_ready:
        blockers.append("preflight is not ready")
    if not worktree_clean:
        blockers.append("worktree is not clean")
    if max_threads < 2:
        blockers.append("parallel agent thread budget is below 2")
    if paths and _has_overlapping_directories(paths):
        conflict_policy = "parent-only integration"
    else:
        conflict_policy = "disjoint writes"

    if blockers:
        recommendation = "blocked"
        reason = "; ".join(blockers)
        agent_tasks: list[dict[str, Any]] = []
    elif broad:
        recommendation = "required"
        reason = "broad task benefits from independent exploration, implementation, review, and verification"
        agent_tasks = _agent_tasks(task, paths, required=True)
    elif risk_score >= 5.0 or len(impacted) >= 4:
        recommendation = "optional"
        reason = "moderate impact or risk makes parallel review and verification useful"
        agent_tasks = _agent_tasks(task, paths, required=False)
    else:
        recommendation = "none"
        reason = "task appears narrow enough for a single parent agent"
        agent_tasks = []

    parallel_run_id = stable_id(
        task_session_id, pack_id, task, json.dumps(paths, sort_keys=True)
    )
    return {
        "ok": True,
        "schema_version": "ctxlayer.codex_parallel_plan.v1",
        "parallel_run_id": parallel_run_id,
        "task_session_id": task_session_id,
        "pack_id": pack_id,
        "parallel_recommendation": recommendation,
        "recommendation": recommendation,
        "reason": reason,
        "agent_tasks": agent_tasks[: max(0, min(max_threads, 4))],
        "conflict_policy": conflict_policy,
        "waiver_reason": None,
        "merge_contract": {
            "parent_integrates": True,
            "child_agents_do_not_revert_peer_changes": True,
            "final_parent_checks": ["check-diff", "impact", "tests", "outcome"],
        },
    }


def pre_tool_gate(
    *,
    tool_name: str,
    preflight_ready: bool,
    active_plan_step: bool,
    read_only: bool = False,
    target_paths: list[str] | None = None,
    proposed_content: str | None = None,
    diff: str | None = None,
    directives: list[dict[str, Any]] | None = None,
    guardrails_mode: str = "warn",
    block_min_severity: str = "high",
    min_block_confidence: float = 0.7,
    content_match_required_for_block: bool = True,
    surprise: dict[str, Any] | None = None,
    interoception: dict[str, Any] | None = None,
    surprise_nudge_threshold: float = 0.5,
    surprise_block_threshold: float = 0.85,
    surprise_requires_corroboration: bool = True,
    anticipation_mode: str = "warn",
    surprise_nudge_count: int = 0,
    max_nudges_per_session: int = 8,
) -> dict[str, Any]:
    normalized = tool_name.strip().lower()
    write_capable = any(term in normalized for term in WRITE_CAPABLE_TOOLS)
    if read_only or not write_capable:
        return {
            "ok": True,
            "decision": "allow",
            "reason": "read-only or non-writing tool",
        }
    if not preflight_ready:
        return {
            "ok": False,
            "decision": "block",
            "reason": "write-capable Codex tool use requires ready CTX preflight",
        }
    if not active_plan_step:
        return {
            "ok": False,
            "decision": "block",
            "reason": "write-capable Codex tool use requires an active CTX plan step",
        }
    semantic = _semantic_guardrail_decision(
        directives or [],
        text=diff if diff is not None else proposed_content,
        mode=guardrails_mode,
        block_min_severity=block_min_severity,
        min_block_confidence=min_block_confidence,
        content_match_required_for_block=content_match_required_for_block,
    )
    if semantic["decision"] == "block":
        result = {
            "ok": False,
            "decision": "block",
            "reason": semantic["reason"],
            "matched": semantic["matched"],
            "target_paths": target_paths or [],
            "override": _guardrail_override_help(semantic["matched"]),
        }
        return _with_surprise(
            result,
            surprise=surprise,
            interoception=interoception,
            target_paths=target_paths or [],
            matched=semantic["matched"],
            nudge_threshold=surprise_nudge_threshold,
            block_threshold=surprise_block_threshold,
            requires_corroboration=surprise_requires_corroboration,
            anticipation_mode=anticipation_mode,
            nudge_count=surprise_nudge_count,
            max_nudges=max_nudges_per_session,
        )
    if semantic["decision"] == "warn":
        result = {
            "ok": True,
            "decision": "warn",
            "reason": semantic["reason"],
            "matched": semantic["matched"],
            "target_paths": target_paths or [],
            "override": _guardrail_override_help(semantic["matched"]),
        }
        return _with_surprise(
            result,
            surprise=surprise,
            interoception=interoception,
            target_paths=target_paths or [],
            matched=semantic["matched"],
            nudge_threshold=surprise_nudge_threshold,
            block_threshold=surprise_block_threshold,
            requires_corroboration=surprise_requires_corroboration,
            anticipation_mode=anticipation_mode,
            nudge_count=surprise_nudge_count,
            max_nudges=max_nudges_per_session,
        )
    result = {
        "ok": True,
        "decision": "allow",
        "reason": "preflight and active plan step are ready",
    }
    return _with_surprise(
        result,
        surprise=surprise,
        interoception=interoception,
        target_paths=target_paths or [],
        matched=[],
        nudge_threshold=surprise_nudge_threshold,
        block_threshold=surprise_block_threshold,
        requires_corroboration=surprise_requires_corroboration,
        anticipation_mode=anticipation_mode,
        nudge_count=surprise_nudge_count,
        max_nudges=max_nudges_per_session,
    )


def _with_surprise(
    result: dict[str, Any],
    *,
    surprise: dict[str, Any] | None,
    interoception: dict[str, Any] | None,
    target_paths: list[str],
    matched: list[dict[str, Any]],
    nudge_threshold: float,
    block_threshold: float,
    requires_corroboration: bool,
    anticipation_mode: str,
    nudge_count: int,
    max_nudges: int,
) -> dict[str, Any]:
    if surprise is None:
        return result
    from ctxlayer.anticipation.interoception import (
        InteroceptiveState,
        build_nudge_message,
    )

    mode = anticipation_mode.strip().lower()
    score = surprise.get("surprise")
    if mode == "off" or score is None:
        enriched = dict(result)
        enriched["surprise"] = _surprise_section(
            surprise, level="silent", message="", corroborated_by=[]
        )
        return enriched
    gut = float((interoception or {}).get("gut", 0.0) or 0.0)
    signal = InteroceptiveState.blend(surprise=float(score), gut=gut)["signal"]
    corroborated_by = _surprise_corroboration(
        target_paths=target_paths, matched=matched, surprise=surprise
    )
    level = "silent"
    if signal >= float(nudge_threshold):
        level = "nudge"
    if nudge_count >= max(0, int(max_nudges)) and level == "nudge":
        level = "silent"
    if signal >= float(block_threshold) and mode in {"block", "enforce"}:
        if not requires_corroboration or corroborated_by:
            level = "block"
        else:
            level = "nudge"
    message = (
        build_nudge_message(
            target_paths=target_paths,
            surprise={**surprise, "surprise": signal},
            level=level,
            interoception=interoception,
        )
        if level != "silent"
        else ""
    )
    enriched = dict(result)
    enriched["surprise"] = _surprise_section(
        surprise,
        level=level,
        message=message,
        corroborated_by=corroborated_by,
        score=signal,
    )
    if level == "block" and result.get("decision") != "block":
        enriched.update(
            {
                "ok": False,
                "decision": "block",
                "reason": "anticipation surprise corroborated by independent risk signal",
            }
        )
    elif level == "nudge" and result.get("decision") == "allow":
        enriched.update(
            {
                "ok": True,
                "decision": "warn",
                "reason": "anticipation surprise nudge",
            }
        )
    return enriched


def _surprise_section(
    surprise: dict[str, Any],
    *,
    level: str,
    message: str,
    corroborated_by: list[str],
    score: float | None = None,
) -> dict[str, Any]:
    return {
        "score": score if score is not None else surprise.get("surprise"),
        "level": level,
        "message": message,
        "components": surprise.get("components", {}),
        "corroborated_by": corroborated_by,
        "model_id": surprise.get("model_id"),
        "prediction_id": surprise.get("prediction_id"),
    }


def _surprise_corroboration(
    *,
    target_paths: list[str],
    matched: list[dict[str, Any]],
    surprise: dict[str, Any],
) -> list[str]:
    reasons: list[str] = []
    for item in matched:
        if item.get("directive_id"):
            reasons.append(f"guardrail:{item['directive_id']}")
    if any(_critical_path(path) for path in target_paths):
        reasons.append("critical_path")
    components = surprise.get("components", {}) if isinstance(surprise, dict) else {}
    if float(components.get("failure_prior", 0.0) or 0.0) >= 0.5:
        reasons.append("failure_lesson")
    return sorted(set(reasons))


def _critical_path(path: str) -> bool:
    lowered = path.replace("\\", "/").lower()
    return any(
        token in lowered for token in ("/auth/", "/billing/", "/payments/", "migration")
    )


def _semantic_guardrail_decision(
    directives: list[dict[str, Any]],
    *,
    text: str | None,
    mode: str,
    block_min_severity: str,
    min_block_confidence: float,
    content_match_required_for_block: bool,
) -> dict[str, Any]:
    normalized_mode = mode.strip().lower()
    if normalized_mode == "off" or not directives:
        return {
            "decision": "allow",
            "reason": "no semantic guardrails matched",
            "matched": [],
        }
    content = text or ""
    matched: list[dict[str, Any]] = []
    strongest = "allow"
    for directive in directives:
        violation = _directive_violation(directive, content)
        if not violation:
            continue
        level = str(
            directive.get("effective_level") or directive.get("enforcement_level")
        )
        desired = "block" if level == "block" else "warn"
        if not bool(violation.get("content_matcher")):
            desired = "warn"
        item = {
            "directive_id": directive.get("directive_id"),
            "record_id": directive.get("record_id"),
            "level": directive.get("enforcement_level"),
            "effective_level": directive.get(
                "effective_level", directive.get("enforcement_level")
            ),
            "severity": directive.get("severity"),
            "confidence": float(directive.get("confidence") or 0.0),
            "assertion": directive.get("assertion"),
            "matched_path": directive.get("matched_path"),
            "matched_pattern": violation.get("matched_pattern"),
            "violation_kind": violation.get("kind"),
            "remediation": directive.get("remediation"),
            "rationale": directive.get("rationale"),
            "content_matcher": bool(violation.get("content_matcher")),
            "decision": desired,
        }
        matched.append(item)
        strongest = _stronger_decision(strongest, desired)
    if strongest == "allow":
        return {
            "decision": "allow",
            "reason": "no semantic guardrails matched",
            "matched": [],
        }
    if strongest == "block":
        blockable = normalized_mode == "block" and any(
            item["decision"] == "block"
            and (item["content_matcher"] or not content_match_required_for_block)
            and item["confidence"] >= float(min_block_confidence)
            and _severity_rank(str(item.get("severity") or "low"))
            >= _severity_rank(block_min_severity)
            for item in matched
        )
        strongest = "block" if blockable else "warn"
    elif normalized_mode == "off":
        strongest = "allow"
    reason = (
        "edit matches enforceable memory guardrail"
        if strongest == "block"
        else "edit matches memory guardrail warning"
    )
    return {"decision": strongest, "reason": reason, "matched": matched}


def _directive_violation(
    directive: dict[str, Any], content: str
) -> dict[str, Any] | None:
    anti_patterns = [str(item) for item in directive.get("anti_patterns") or []]
    required_patterns = [str(item) for item in directive.get("required_patterns") or []]
    for pattern in anti_patterns:
        if _regex_search(pattern, content):
            return {
                "kind": "anti_pattern",
                "matched_pattern": pattern,
                "content_matcher": True,
            }
    for pattern in required_patterns:
        if not _regex_search(pattern, content):
            return {
                "kind": "required_pattern_absent",
                "matched_pattern": pattern,
                "content_matcher": True,
            }
    if not anti_patterns and not required_patterns:
        return {
            "kind": "path_scope",
            "matched_pattern": None,
            "content_matcher": False,
        }
    return None


def _regex_search(pattern: str, content: str) -> bool:
    try:
        return re.search(pattern, content, flags=re.MULTILINE) is not None
    except re.error:
        return False


def _stronger_decision(left: str, right: str) -> str:
    rank = {"allow": 0, "warn": 1, "block": 2}
    return left if rank.get(left, 0) >= rank.get(right, 0) else right


def _severity_rank(value: str) -> int:
    return {"low": 0, "medium": 1, "high": 2, "critical": 3}.get(
        value.strip().lower(), 0
    )


def _guardrail_override_help(matched: list[dict[str, Any]]) -> dict[str, Any]:
    directive_id = next(
        (str(item.get("directive_id")) for item in matched if item.get("directive_id")),
        "<directive_id>",
    )
    return {
        "allowed": True,
        "how": f'ctxlayer guardrail override {directive_id} --rationale "<reason>"',
        "or_mark_stale": (
            f'ctxlayer memory unenforce {directive_id} --reason "rule outdated"'
        ),
    }


def _agent_tasks(
    task: str, paths: list[str], *, required: bool
) -> list[dict[str, Any]]:
    write_scope = paths[:2] if paths else []
    read_scope = paths or ["repo"]
    return [
        {
            "role": "ctx-explorer",
            "objective": f"Map relevant context for: {task}",
            "read_scope": read_scope,
            "write_scope": [],
            "required_pack_sections": [
                "items",
                "project_memory",
                "continuations",
                "policy_references",
            ],
            "expected_output": "findings, risks, and suggested file ownership",
            "timeout_seconds": 900,
        },
        {
            "role": "ctx-worker",
            "objective": f"Implement assigned slice for: {task}",
            "read_scope": read_scope,
            "write_scope": write_scope,
            "required_pack_sections": [
                "items",
                "skills",
                "project_memory",
                "policy_references",
            ],
            "expected_output": "changed files, checkpoints, and verification notes",
            "timeout_seconds": 1800,
        },
        {
            "role": "ctx-reviewer",
            "objective": f"Review correctness, security, and test gaps for: {task}",
            "read_scope": read_scope,
            "write_scope": [],
            "required_pack_sections": [
                "items",
                "memory_retrieval",
                "policy_references",
            ],
            "expected_output": "ordered findings with file references",
            "timeout_seconds": 900,
        },
        {
            "role": "ctx-verifier",
            "objective": f"Run or analyze verification for: {task}",
            "read_scope": read_scope,
            "write_scope": [] if required else write_scope[:1],
            "required_pack_sections": ["items", "parallel_agent_plan"],
            "expected_output": "commands, exits, failures, and likely owning files",
            "timeout_seconds": 1200,
        },
    ]


def _has_overlapping_directories(paths: list[str]) -> bool:
    parents = [str(Path(path).parent).replace("\\", "/") for path in paths]
    return len(set(parents)) < len(parents)
