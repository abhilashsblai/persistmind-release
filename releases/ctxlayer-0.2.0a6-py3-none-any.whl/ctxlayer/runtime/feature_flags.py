from __future__ import annotations

import json
from pathlib import Path


def load(path: Path) -> list[dict[str, str]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    return [
        {
            "title": f"Feature flag changed: {name}",
            "message": str(value),
            "path": path.as_posix(),
            "severity": "low",
        }
        for name, value in (data.items() if isinstance(data, dict) else [])
    ]
