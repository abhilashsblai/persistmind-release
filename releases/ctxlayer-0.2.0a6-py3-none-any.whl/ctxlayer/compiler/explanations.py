from __future__ import annotations

from typing import Any


SIGNAL_REASONS = {
    "lexical": "Task text matched this chunk through lexical search.",
    "vector": "Task text was semantically close to this chunk.",
    "seed_path": "User explicitly seeded this path.",
    "fallback": "Included as broad fallback context because no stronger candidates were found.",
    "linked_test": "Included because it tests a selected implementation path.",
    "skeleton_fallback": "Full chunk was too large, so a deterministic skeleton was served.",
}


def explain_item(
    item: dict[str, Any],
    *,
    business_rules: list[dict[str, Any]] | None = None,
    runtime_evidence: list[dict[str, Any]] | None = None,
    project_memory: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    signals = []
    provenance = item.get("provenance", [])
    score = float(item.get("score", 0.0))
    for raw in provenance:
        kind = str(raw)
        reason = SIGNAL_REASONS.get(kind)
        if kind.startswith("graph:"):
            reason = (
                f"Repository graph linked this path by {kind.split(':', 1)[1]} edge."
            )
        elif kind.startswith("history:"):
            reason = "Git history shows this path co-changed with selected context."
        elif reason is None:
            reason = f"Selected by {kind} retrieval signal."
        signals.append({"kind": kind, "score": round(score, 6), "reason": reason})

    path = item.get("path")
    risk_covered: list[str] = []
    related_rules = [
        rule.get("rule_id")
        for rule in business_rules or []
        if rule.get("scope") and _matches_scope(path, rule.get("scope"))
    ]
    if related_rules:
        risk_covered.append("approved business rule scope")
        signals.append(
            {
                "kind": "business_rule",
                "score": 0.5,
                "reason": "Approved business rule scope intersects this path.",
            }
        )
    if any(item.get("path") == path for item in runtime_evidence or []):
        risk_covered.append("runtime evidence near changed area")
        signals.append(
            {
                "kind": "runtime_evidence",
                "score": 0.45,
                "reason": "Runtime evidence references this path.",
            }
        )
    if any(
        evidence.get("path") == path
        for memory in project_memory or []
        for evidence in memory.get("evidence", [])
    ):
        risk_covered.append("project memory evidence")
        signals.append(
            {
                "kind": "project_memory",
                "score": 0.4,
                "reason": "Approved project memory has evidence in this path.",
            }
        )
    if not risk_covered and path:
        if "/test" in f"/{path}" or path.startswith("tests/"):
            risk_covered.append("test coverage context")
        elif any(part in path for part in ["auth", "billing", "payment", "migration"]):
            risk_covered.append("critical path context")

    return {
        "summary": _summary(path, signals),
        "signals": signals
        or [{"kind": "unknown", "score": score, "reason": "Selected by compiler."}],
        "risk_covered": sorted(set(risk_covered)),
        "related_rules": sorted(rule for rule in related_rules if rule),
    }


def negative_context(
    selected_paths: list[str], seed_paths: list[str]
) -> dict[str, Any]:
    selected = sorted(set(selected_paths))
    seeds = sorted(set(seed_paths))
    return {
        "schema_version": "ctxlayer.negative_context.v1",
        "scope_boundary": "Files outside selected paths, seed paths, and impact closure are out of scope unless the plan is amended.",
        "selected_paths": selected,
        "seed_paths": seeds,
    }


def _summary(path: str | None, signals: list[dict[str, Any]]) -> str:
    if not path:
        return "Included by context compiler."
    if signals:
        return f"Included {path} because {signals[0]['reason'][0].lower()}{signals[0]['reason'][1:]}"
    return f"Included {path} by context compiler."


def _matches_scope(path: str | None, scope: str | None) -> bool:
    if not path or not scope:
        return False
    if scope in {"*", "**"}:
        return True
    normalized = scope.replace("\\", "/").rstrip("*")
    return path.startswith(normalized)
