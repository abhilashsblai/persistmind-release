from __future__ import annotations

from typing import Any


def github_annotations(report: dict[str, Any]) -> list[str]:
    annotations = []
    for violation in report.get("violations", []):
        path = violation.get("path") or "."
        level = "error" if violation.get("severity") == "high" else "warning"
        annotations.append(
            f"::{level} file={path},title=CTXLAYER {violation.get('type')}::{violation.get('reason')}"
        )
    return annotations


def gitlab_annotations(report: dict[str, Any]) -> dict[str, Any]:
    return {
        "status": report.get("status"),
        "violations": report.get("violations", []),
        "selected_tests": report.get("selected_tests", []),
    }
