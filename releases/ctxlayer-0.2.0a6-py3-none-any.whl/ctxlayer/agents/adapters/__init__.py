from __future__ import annotations

from typing import Iterable, Mapping

from ctxlayer.agents.adapters.base import AgentAdapter, BootstrapContext
from ctxlayer.agents.adapters.claude import ClaudeAdapter
from ctxlayer.agents.adapters.codex import CodexAdapter
from ctxlayer.agents.adapters.cursor import CursorAdapter


ADAPTERS: tuple[AgentAdapter, ...] = (
    CodexAdapter(),
    ClaudeAdapter(),
    CursorAdapter(),
)
REGISTRY = {adapter.name: adapter for adapter in ADAPTERS}
ALIASES = {
    alias: adapter.name for adapter in ADAPTERS for alias in (adapter.aliases or ())
}


def known_agent_names() -> list[str]:
    return sorted(REGISTRY)


def resolve(names: Iterable[str]) -> list[AgentAdapter]:
    adapters: list[AgentAdapter] = []
    seen: set[str] = set()
    for raw in names:
        for part in str(raw).replace(",", " ").split():
            name = part.strip().lower()
            if not name:
                continue
            canonical = ALIASES.get(name, name)
            if canonical not in REGISTRY:
                known = ", ".join(known_agent_names())
                raise ValueError(f"unknown agent '{part}' (known: {known})")
            if canonical not in seen:
                adapters.append(REGISTRY[canonical])
                seen.add(canonical)
    return sorted(adapters, key=lambda adapter: adapter.name)


def detect_running(env: Mapping[str, str]) -> list[AgentAdapter]:
    return [adapter for adapter in ADAPTERS if adapter.detect(env)]
