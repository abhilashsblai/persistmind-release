from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from ctxlayer.agents.adapters.base import BootstrapContext
from ctxlayer.agents.contract import (
    HOOK_EVENTS,
    SUBAGENT_SPECS,
    claude_agent_markdown,
    claude_command,
    claude_mcp_json,
    claude_settings_json,
    claude_skill,
    ensure_instruction_contract,
    hook_script,
    write_if_changed,
)


class ClaudeAdapter:
    name = "claude"
    aliases = ("claude-code", "claudecode")
    supports_hooks = True
    supports_subagents = True
    supports_skills = True
    instruction_file = "CLAUDE.md"

    def detect(self, env: Mapping[str, str]) -> bool:
        return bool(env.get("CLAUDECODE")) or any(
            key.startswith("CLAUDE_") for key in env
        )

    def render(self, ctx: BootstrapContext) -> list[Path]:
        written: list[Path] = []
        path, _changed = ensure_instruction_contract(
            ctx.repo_root / self.instruction_file,
            ctx.agent_names,
            agent_label="Claude Code",
        )
        written.append(path)
        written.extend(
            [
                write_if_changed(
                    ctx.repo_root / ".ctxlayer" / "mcp" / "claude-code.ps1",
                    claude_command(ctx.mcp_command, ctx.mcp_repo),
                ),
                write_if_changed(
                    ctx.repo_root / ".mcp.json",
                    claude_mcp_json(ctx.mcp_command, ctx.mcp_repo),
                ),
                write_if_changed(
                    ctx.repo_root / ".claude" / "settings.json",
                    claude_settings_json(ctx.repo_root),
                ),
                write_if_changed(
                    ctx.repo_root / ".claude" / "skills" / "ctx-loop" / "SKILL.md",
                    claude_skill(ctx.mcp_command, ctx.mcp_repo),
                ),
                write_if_changed(
                    ctx.repo_root
                    / ".ctxlayer"
                    / "claude"
                    / "hooks"
                    / "ctxlayer_hook.py",
                    hook_script(),
                ),
            ]
        )
        for spec in SUBAGENT_SPECS:
            written.append(
                write_if_changed(
                    ctx.repo_root / ".claude" / "agents" / f"{spec.name}.md",
                    claude_agent_markdown(spec),
                )
            )
        return written

    def configure_mcp(
        self, ctx: BootstrapContext, *, config_path: Path | None = None
    ) -> dict[str, Any]:
        return {
            "ok": True,
            "agent": self.name,
            "changed": False,
            "hint": self.mcp_setup_hint(ctx),
            "project_config": str(ctx.repo_root / ".mcp.json"),
        }

    def readiness(self, repo_root: Path) -> dict[str, Any]:
        claude = repo_root / ".claude"
        settings = claude / "settings.json"
        checks = {
            "claude_instruction": (repo_root / "CLAUDE.md").exists(),
            "claude_mcp_project": (repo_root / ".mcp.json").exists(),
            "claude_settings": settings.exists(),
            "claude_hooks": settings.exists()
            and (
                repo_root / ".ctxlayer" / "claude" / "hooks" / "ctxlayer_hook.py"
            ).exists(),
            "claude_agents": all(
                (claude / "agents" / f"{name}.md").exists()
                for name in [
                    "ctx-explorer",
                    "ctx-worker",
                    "ctx-reviewer",
                    "ctx-verifier",
                ]
            ),
            "claude_skill": (claude / "skills" / "ctx-loop" / "SKILL.md").exists(),
        }
        missing = [name for name, ok in checks.items() if not ok]
        return {
            "agent": self.name,
            "ok": not missing,
            "checks": checks,
            "missing": missing,
            "enforcement_level": "hooks",
            "hook_events": list(HOOK_EVENTS),
        }

    def mcp_setup_hint(self, ctx: BootstrapContext) -> str:
        return f'Run `claude mcp add ctxlayer -- {ctx.mcp_command} mcp --repo "{ctx.mcp_repo}"`.'
