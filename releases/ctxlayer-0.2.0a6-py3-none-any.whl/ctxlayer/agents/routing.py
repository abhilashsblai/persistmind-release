from __future__ import annotations

from typing import Any


class AgentRouter:
    def route(
        self,
        *,
        task: str,
        risk_score: float = 0.0,
        capabilities: list[str] | None = None,
        remote_review_enabled: bool = False,
    ) -> dict[str, Any]:
        capabilities = capabilities or []
        high_risk = risk_score >= 7.0 or any(
            capability
            in {"edit_critical_path", "modify_migration", "touch_env_secrets"}
            for capability in capabilities
        )
        route = {
            "ok": True,
            "schema_version": "ctxlayer.agent_route.v1",
            "task": task,
            "risk_score": risk_score,
            "capabilities": capabilities,
            "implementation_agent": "codex",
            "review_agent": None,
            "remote_inference": False,
            "audit_markers": ["single-agent-default"],
        }
        if high_risk:
            route["audit_markers"] = ["high-risk-plan"]
            if remote_review_enabled:
                route["review_agent"] = "configured-remote-reviewer"
                route["remote_inference"] = True
                route["audit_markers"].append("remote-review-opt-in")
            else:
                route["review_agent"] = "local-human-review"
                route["audit_markers"].append("remote-review-disabled")
        return route
