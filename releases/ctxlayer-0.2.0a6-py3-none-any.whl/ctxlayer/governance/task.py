from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ctxlayer.config import Settings
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import sha256_text, stable_id

STATES = ["INTAKE", "PACK", "PLAN", "EXECUTE", "PREFLIGHT", "OUTCOME"]


class TaskGovernance:
    def __init__(
        self,
        repo_root: Path,
        store: SQLiteStore,
        settings: Settings,
        *,
        workspace_id: str,
        repo_id: str | None,
    ):
        self.repo_root = repo_root
        self.store = store
        self.settings = settings
        self.workspace_id = workspace_id
        self.repo_id = repo_id

    def start(
        self,
        *,
        task: str,
        constitution_hash: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        task_session_id = stable_id(
            self.workspace_id,
            self.repo_id or "",
            sha256_text(task),
            constitution_hash or "",
        )
        self.store.start_task_session(
            task_session_id=task_session_id,
            workspace_id=self.workspace_id,
            repo_id=self.repo_id,
            task_text_hash=sha256_text(task),
            constitution_hash=constitution_hash,
            metadata=metadata,
        )
        return {
            "ok": True,
            "task_session_id": task_session_id,
            "state": "INTAKE",
            "constitution_hash": constitution_hash,
        }

    def transition(
        self,
        task_session_id: str,
        to_state: str,
        *,
        actor: str = "local-user",
        reason: str | None = None,
        pack_id: str | None = None,
        constitution_hash: str | None = None,
    ) -> dict[str, Any]:
        to_state = to_state.upper()
        if to_state not in STATES:
            raise ValueError(f"unknown task state: {to_state}")
        row = self.store.task_session(task_session_id)
        if not row:
            raise KeyError(f"task session not found: {task_session_id}")
        from_state = row["current_state"]
        if not _allowed_transition(from_state, to_state):
            raise ValueError(f"invalid task transition: {from_state} -> {to_state}")
        transition_id = self.store.append_task_session_transition(
            task_session_id=task_session_id,
            from_state=from_state,
            to_state=to_state,
            actor=actor,
            reason=reason,
            pack_id=pack_id,
            constitution_hash=constitution_hash,
        )
        return {
            "ok": True,
            "task_session_id": task_session_id,
            "transition_id": transition_id,
            "from_state": from_state,
            "to_state": to_state,
        }

    def show(self, task_session_id: str) -> dict[str, Any]:
        row = self.store.task_session(task_session_id)
        if not row:
            return {
                "ok": False,
                "error": "task session not found",
                "task_session_id": task_session_id,
            }
        transitions = [
            dict(item) for item in self.store.task_session_transitions(task_session_id)
        ]
        return {
            "ok": True,
            "session": {
                **dict(row),
                "metadata": _json(row["metadata_json"]),
            },
            "transitions": transitions,
            "chain": _verify_transition_chain(transitions),
        }


def _allowed_transition(from_state: str, to_state: str) -> bool:
    if from_state == to_state:
        return True
    return STATES.index(to_state) == STATES.index(from_state) + 1


def _verify_transition_chain(transitions: list[dict[str, Any]]) -> dict[str, Any]:
    prev_hash = ""
    for transition in transitions:
        if transition["prev_hash"] != prev_hash:
            return {"ok": False, "transition_id": transition["transition_id"]}
        prev_hash = transition["transition_hash"]
    return {"ok": True, "rows": len(transitions), "tip": prev_hash}


def _json(value: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}
