from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from ctxlayer.impact import ImpactEngine
from ctxlayer.memory import UnifiedMemory
from ctxlayer.snapshot import SnapshotInfo
from ctxlayer.store import SQLiteStore

TRUST_CONFIDENCE = {
    "deterministic": 1.0,
    "source": 0.95,
    "high": 0.85,
    "approved_org_memory": 0.75,
    "approved_project_memory": 0.75,
    "medium": 0.6,
    "advisory": 0.55,
    "low": 0.35,
    "untrusted": 0.1,
    "unknown": 0.0,
}


class DecisionAssembler:
    def __init__(
        self,
        *,
        repo_root: Path,
        store: SQLiteStore,
        impact: ImpactEngine,
        memory: UnifiedMemory,
    ):
        self.repo_root = repo_root
        self.store = store
        self.impact = impact
        self.memory = memory

    def assemble(
        self,
        *,
        question: str,
        options: list[dict[str, Any]],
        seed_paths: list[str],
        snapshot: SnapshotInfo,
    ) -> dict[str, Any]:
        assembled: list[dict[str, Any]] = []
        trust_summary: dict[str, int] = {}
        for option in options:
            paths = _option_paths(self.repo_root, option, seed_paths)
            technical_report = self.impact.report(snapshot=snapshot, paths=paths)
            business_report = self.impact.report(
                snapshot=snapshot, paths=paths, business=True
            )
            technical = {
                "source": "impact_engine",
                "trust_tier": "deterministic",
                "confidence": 1.0,
                "input_paths": technical_report.get("analyzed_paths") or [],
                "impacted_paths": technical_report.get("impacted_paths") or [],
                "risk": technical_report.get("risk") or {},
            }
            business = _business_exposure(
                business_report.get("business_exposure") or {}
            )
            org_context = _org_context(
                self.memory.recall(
                    f"{question} {option.get('statement', '')}",
                    paths=paths,
                    types=["decision", "org_knowledge"],
                    limit=10,
                    include_org=True,
                )
            )
            goal_alignment = _goal_alignment(
                self.store.list_goals(repo_id=snapshot.repo_id, status=None, limit=25),
                f"{question} {option.get('statement', '')}",
            )
            evidence_refs = _evidence_refs(
                option_id=str(option["id"]),
                technical=technical,
                business=business,
                org_context=org_context,
                goal_alignment=goal_alignment,
            )
            assembled.append(
                {
                    **option,
                    "paths": paths,
                    "technical_impact": technical,
                    "business_exposure": business,
                    "org_context": org_context,
                    "goal_alignment": goal_alignment,
                    "evidence_refs": evidence_refs,
                    "unknowns": [],
                }
            )
            for ref in evidence_refs:
                tier = str(ref.get("trust_tier") or "unknown")
                trust_summary[tier] = trust_summary.get(tier, 0) + 1
        return {
            "options": assembled,
            "input_trust_summary": dict(sorted(trust_summary.items())),
        }


def _option_paths(
    repo_root: Path, option: dict[str, Any], seed_paths: list[str]
) -> list[str]:
    candidates = list(option.get("seed_paths") or []) or list(seed_paths)
    statement = str(option.get("statement") or "")
    for token in re.findall(r"[\w./\\-]+\.[A-Za-z0-9]+", statement):
        rel = token.replace("\\", "/").strip("./")
        if (repo_root / rel).exists():
            candidates.append(rel)
    return sorted({path.replace("\\", "/") for path in candidates if path})


def _business_exposure(exposure: dict[str, Any]) -> dict[str, Any]:
    tier = str(exposure.get("lowest_trust_tier") or "unknown")
    return {
        **exposure,
        "source": "business_graph",
        "trust_tier": tier,
        "confidence": TRUST_CONFIDENCE.get(tier, 0.0),
        "authoritative": False,
        "requires_human_review": True,
    }


def _org_context(recall: dict[str, Any]) -> list[dict[str, Any]]:
    items = []
    for item in recall.get("results") or []:
        metadata = item.get("metadata") or {}
        provenance = item.get("provenance") or {}
        tier = str(item.get("trust") or "unknown")
        items.append(
            {
                "record_id": item.get("record_id"),
                "extracted_type": item.get("type"),
                "source_ref": item.get("title") or item.get("record_id"),
                "captured_at": provenance.get("validated_at")
                or provenance.get("captured_at"),
                "trust_tier": tier,
                "confidence": float(item.get("score") or item.get("confidence") or 0.0),
                "stale": item.get("staleness_state") == "stale",
                "source": "memory_recall",
                "text": item.get("text") or item.get("assertion"),
                "metadata": metadata,
            }
        )
    return items


def _goal_alignment(rows: list[Any], query: str) -> dict[str, Any]:
    query_terms = _terms(query)
    best: Any | None = None
    best_score = 0.0
    for row in rows:
        row_terms = _terms(
            f"{row['statement']} {row['success_metric']} {row['hypothesis'] or ''}"
        )
        overlap = len(query_terms & row_terms)
        score = overlap / max(1, len(query_terms))
        if score > best_score:
            best = row
            best_score = score
    if best is None or best_score <= 0:
        return {
            "source": "goal_governance",
            "trust_tier": "advisory",
            "confidence": 0.0,
            "goal_id": None,
            "projected_metric_delta": None,
            "rationale": "No matching goal governance record was found.",
        }
    metadata = _json_obj(best["metadata_json"])
    confidence = min(
        1.0, max(0.0, float(best["confidence"] or 0.0) * max(0.5, best_score))
    )
    return {
        "source": "goal_governance",
        "trust_tier": "advisory",
        "confidence": round(confidence, 4),
        "goal_id": best["goal_id"],
        "projected_metric_delta": metadata.get("projected_metric_delta"),
        "rationale": f"Matched goal: {best['statement']}",
    }


def _evidence_refs(
    *,
    option_id: str,
    technical: dict[str, Any],
    business: dict[str, Any],
    org_context: list[dict[str, Any]],
    goal_alignment: dict[str, Any],
) -> list[dict[str, Any]]:
    refs = [
        {
            "ref": f"{option_id}:technical",
            "source_type": "impact_engine",
            "trust_tier": technical["trust_tier"],
            "confidence": technical["confidence"],
        },
        {
            "ref": f"{option_id}:business",
            "source_type": "business_graph",
            "trust_tier": business["trust_tier"],
            "confidence": business["confidence"],
        },
        {
            "ref": f"{option_id}:goal",
            "source_type": "goal_governance",
            "trust_tier": goal_alignment["trust_tier"],
            "confidence": goal_alignment["confidence"],
        },
    ]
    for item in org_context:
        refs.append(
            {
                "ref": str(item.get("record_id")),
                "source_type": "org_context",
                "trust_tier": item.get("trust_tier") or "unknown",
                "confidence": item.get("confidence") or 0.0,
            }
        )
    return refs


def _terms(value: str) -> set[str]:
    return {part for part in re.split(r"[^a-z0-9]+", value.casefold()) if len(part) > 2}


def _json_obj(value: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}
