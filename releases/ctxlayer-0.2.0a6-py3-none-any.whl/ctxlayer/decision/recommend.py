from __future__ import annotations

from typing import Any

from .scoring import DIMENSIONS, trust_weight

CONFIDENCE_FLOOR = 0.55


def build_recommendation(options: list[dict[str, Any]]) -> dict[str, Any]:
    low_trust_inputs = _low_trust_inputs(options)
    gaps = _gaps(options)
    coverage = _coverage(options)
    mean_trust = _mean_trust(options)
    confidence = round(coverage * mean_trust, 4)
    ranked = sorted(options, key=_option_value, reverse=True)
    decisive_unknown = any(
        any(item.get("dimension") == "revenue" for item in option.get("unknowns") or [])
        for option in options
    )
    if not ranked or confidence < CONFIDENCE_FLOOR or decisive_unknown:
        recommendation = {
            "option_id": None,
            "confidence": confidence,
            "rationale": "No responsible recommendation: decisive inputs are missing or confidence is below the floor.",
            "low_trust_inputs": low_trust_inputs,
            "gaps": gaps or ["confidence below recommendation floor"],
            "presented_as": "recommendation",
        }
    else:
        top = ranked[0]
        recommendation = {
            "option_id": top["id"],
            "confidence": confidence,
            "rationale": (
                "Highest advisory score across available impact, risk, revenue, "
                "and strategic-alignment evidence."
            ),
            "low_trust_inputs": low_trust_inputs,
            "gaps": gaps,
            "presented_as": "recommendation",
        }
    assert_recommendation_label(recommendation)
    return recommendation


def assert_recommendation_label(recommendation: dict[str, Any]) -> None:
    if recommendation.get("presented_as") != "recommendation":
        raise ValueError(
            "decision support output must present recommendations as recommendations"
        )


def _option_value(option: dict[str, Any]) -> float:
    total = 0.0
    weight = 0.0
    for dimension in DIMENSIONS:
        score = (option.get("scores") or {}).get(dimension) or {}
        value = score.get("value")
        if value is None:
            continue
        dim_weight = 1.25 if dimension in {"risk", "revenue"} else 1.0
        total += float(value) * dim_weight
        weight += dim_weight
    return total / max(1.0, weight)


def _coverage(options: list[dict[str, Any]]) -> float:
    possible = max(1, len(options) * len(DIMENSIONS))
    present = 0
    for option in options:
        for dimension in DIMENSIONS:
            if ((option.get("scores") or {}).get(dimension) or {}).get(
                "value"
            ) is not None:
                present += 1
    return present / possible


def _mean_trust(options: list[dict[str, Any]]) -> float:
    weights: list[float] = []
    for option in options:
        for score in (option.get("scores") or {}).values():
            weights.extend(
                trust_weight(tier) for tier in score.get("inputs_trust") or []
            )
    return sum(weights) / max(1, len(weights))


def _low_trust_inputs(options: list[dict[str, Any]]) -> list[dict[str, Any]]:
    low = []
    for option in options:
        for ref in option.get("evidence_refs") or []:
            tier = str(ref.get("trust_tier") or "unknown")
            if tier in {"low", "untrusted", "unknown"}:
                low.append(
                    {
                        "ref": ref.get("ref"),
                        "trust_tier": tier,
                        "why_it_matters": "Low-trust evidence cannot support a confident advisory score.",
                    }
                )
    return low


def _gaps(options: list[dict[str, Any]]) -> list[str]:
    gaps: list[str] = []
    for option in options:
        for item in option.get("unknowns") or []:
            gap = f"{option.get('id')}:{item.get('dimension')}:{item.get('reason')}"
            if gap not in gaps:
                gaps.append(gap)
    return gaps
