from __future__ import annotations

import fnmatch
from pathlib import Path


def parse_codeowners(repo_root: Path) -> list[dict[str, object]]:
    candidates = [
        repo_root / "CODEOWNERS",
        repo_root / ".github" / "CODEOWNERS",
        repo_root / "docs" / "CODEOWNERS",
    ]
    for path in candidates:
        if path.exists():
            return _parse(path)
    return []


def _parse(path: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        pattern = parts[0]
        owners = parts[1:]
        if pattern.startswith("/"):
            pattern = pattern[1:]
        if pattern.endswith("/"):
            pattern = pattern + "**"
        for owner in owners:
            rows.append(
                {
                    "path_glob": pattern or "**",
                    "owner": owner,
                    "source": str(path.name),
                    "confidence": 1.0,
                }
            )
    return rows


def owners_for_path(path: str, ownership_rows: list[dict[str, object]]) -> list[str]:
    owners: list[str] = []
    for row in ownership_rows:
        pattern = str(row["path_glob"])
        if fnmatch.fnmatch(path, pattern) or fnmatch.fnmatch("/" + path, pattern):
            owners.append(str(row["owner"]))
    return sorted(set(owners))
