from __future__ import annotations


def retention_policy(
    keep_days: int, keep_abandoned_days: int, keep_merged: bool
) -> dict[str, object]:
    return {
        "keep_days": keep_days,
        "keep_abandoned_days": keep_abandoned_days,
        "keep_merged": keep_merged,
    }
