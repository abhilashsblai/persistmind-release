from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any

from ctxlayer.utils import utc_now

# Global, cross-project registry of where CTX Layer is installed/updated.
#
# CTX Layer's per-project state lives in each repo's `.ctxlayer/`, so the engine otherwise has
# no way to enumerate the projects it manages. This registry is the one piece of user-level
# (home-directory) state: a small JSON file recording every project that has been installed or
# updated, so `ctxlayer registry list` / the GUI can track them and rollups can be collected
# across deployments.
#
# Location precedence: $CTXLAYER_HOME, else %APPDATA%\ctxlayer (Windows), else ~/.ctxlayer.

SCHEMA_VERSION = "ctxlayer.project_registry.v1"


def registry_home() -> Path:
    override = os.environ.get("CTXLAYER_HOME")
    if override:
        return Path(override).expanduser()
    if os.name == "nt":
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / "ctxlayer"
    return Path.home() / ".ctxlayer"


def registry_disabled() -> bool:
    """Allow opting out of all registry writes (privacy / CI)."""
    return os.environ.get("CTXLAYER_NO_REGISTRY", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _normalize(path: str | os.PathLike[str]) -> str:
    try:
        return str(Path(path).resolve())
    except OSError:
        return str(Path(path))


def is_temp_project_path(path: str | os.PathLike[str]) -> bool:
    """Return true for pytest/temp projects that should not clutter fleet views."""
    normalized = _normalize(path)
    lowered = normalized.lower()
    candidates = {
        tempfile.gettempdir(),
        os.environ.get("TMP", ""),
        os.environ.get("TEMP", ""),
    }
    local_appdata = os.environ.get("LOCALAPPDATA")
    if local_appdata:
        candidates.add(str(Path(local_appdata) / "Temp"))
    for candidate in candidates:
        if not candidate:
            continue
        root = _normalize(candidate).lower().rstrip("\\/")
        if lowered == root or lowered.startswith(root + os.sep.lower()):
            return True
    parts = {part.lower() for part in Path(normalized).parts}
    return any(part.startswith("pytest-") for part in parts) or "pytest-of-" in parts


def path_under_root(
    path: str | os.PathLike[str], root: str | os.PathLike[str] | None
) -> bool:
    if not root:
        return True
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except (OSError, ValueError):
        return False


class ProjectRegistry:
    def __init__(self, home: Path | None = None):
        self.home = home or registry_home()
        self.path = self.home / "projects.json"

    # ----- persistence ----------------------------------------------------
    def _load(self) -> dict[str, Any]:
        if not self.path.is_file():
            return {"schema_version": SCHEMA_VERSION, "projects": {}}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {"schema_version": SCHEMA_VERSION, "projects": {}}
        if not isinstance(data, dict) or not isinstance(data.get("projects"), dict):
            return {"schema_version": SCHEMA_VERSION, "projects": {}}
        return data

    def _save(self, data: dict[str, Any]) -> None:
        self.home.mkdir(parents=True, exist_ok=True)
        # Atomic write so a crash never leaves a half-written registry.
        fd, tmp = tempfile.mkstemp(
            prefix="projects-", suffix=".json", dir=str(self.home)
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(data, handle, indent=2, sort_keys=True)
            os.replace(tmp, self.path)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)

    # ----- operations -----------------------------------------------------
    def register(
        self,
        path: str | os.PathLike[str],
        *,
        label: str | None = None,
        repo_id: str | None = None,
        engine_version: str | None = None,
        action: str = "install",
        now: str | None = None,
    ) -> dict[str, Any]:
        """Upsert a project. Records first_seen once, then updates on every install/update."""
        key = _normalize(path)
        stamp = now or utc_now()
        data = self._load()
        projects = data["projects"]
        existing = projects.get(key, {})
        record = {
            "path": key,
            "label": label or existing.get("label") or Path(key).name,
            "repo_id": repo_id or existing.get("repo_id"),
            "engine_version": engine_version or existing.get("engine_version"),
            "first_seen": existing.get("first_seen", stamp),
            "last_action": action,
            "last_updated": stamp,
            "install_count": int(existing.get("install_count", 0))
            + (1 if action == "install" else 0),
            "update_count": int(existing.get("update_count", 0))
            + (1 if action == "update" else 0),
        }
        projects[key] = record
        data["schema_version"] = SCHEMA_VERSION
        self._save(data)
        return record

    def list(self) -> list[dict[str, Any]]:
        data = self._load()
        return [data["projects"][key] for key in sorted(data["projects"])]

    def remove(self, path: str | os.PathLike[str]) -> bool:
        key = _normalize(path)
        data = self._load()
        if key in data["projects"]:
            del data["projects"][key]
            self._save(data)
            return True
        return False

    def prune(self) -> list[str]:
        """Drop entries whose project no longer has a `.ctxlayer/` directory."""
        data = self._load()
        removed: list[str] = []
        for key in list(data["projects"]):
            if not (Path(key) / ".ctxlayer").is_dir():
                del data["projects"][key]
                removed.append(key)
        if removed:
            self._save(data)
        return removed
