from __future__ import annotations

import json
from typing import Any

from ctxlayer.store import SQLiteStore


DEFAULT_WEIGHTS = {
    "recent_failure_proximity": 0.3,
    "memory_conflict_density": 0.15,
    "plan_drift": 0.2,
    "critical_path_pressure": 0.15,
    "behavioral_anomaly": 0.1,
    "context_coverage_gap": 0.1,
}


class InteroceptiveState:
    def __init__(
        self,
        store: SQLiteStore,
        repo_id: str,
        *,
        behavior_engine: Any | None = None,
        impact_engine: Any | None = None,
        plans: Any | None = None,
    ):
        self.store = store
        self.repo_id = repo_id
        self.behavior_engine = behavior_engine
        self.impact_engine = impact_engine
        self.plans = plans

    def vector(
        self,
        *,
        session_id: str,
        task_session_id: str | None = None,
        active_paths: list[str] | None = None,
    ) -> dict[str, Any]:
        paths = [_normalize_path(path) for path in active_paths or [] if path]
        components = {
            "recent_failure_proximity": self._recent_failure_proximity(),
            "memory_conflict_density": self._memory_conflict_density(),
            "plan_drift": self._plan_drift(task_session_id, paths),
            "critical_path_pressure": self._critical_path_pressure(paths),
            "behavioral_anomaly": self._behavioral_anomaly(session_id),
            "context_coverage_gap": 0.0 if paths else 0.2,
        }
        gut = _weighted(components)
        summary = _summary(components)
        self.store.record_interoception_sample(
            repo_id=self.repo_id,
            session_id=session_id,
            task_session_id=task_session_id,
            components=components,
            gut=gut,
            summary=summary,
        )
        return {
            "components": components,
            "gut": gut,
            "summary": summary,
            "session_id": session_id,
            "task_session_id": task_session_id,
        }

    @staticmethod
    def blend(*, surprise: float | None, gut: float) -> dict[str, Any]:
        s = 0.0 if surprise is None else _clamp(float(surprise))
        g = _clamp(float(gut))
        signal = round(max(s, (0.65 * s) + (0.35 * g)), 6)
        dominant = "interoception" if g > s else "surprise"
        why = []
        if s:
            why.append(f"surprise={s:.2f}")
        if g:
            why.append(f"gut={g:.2f}")
        return {"signal": signal, "dominant": dominant, "why": why}

    def _recent_failure_proximity(self) -> float:
        rows = self.store.conn.execute(
            "SELECT result FROM outcomes ORDER BY created_at DESC LIMIT 10"
        ).fetchall()
        if not rows:
            return 0.0
        failures = sum(
            1
            for row in rows
            if str(row["result"] or "").lower().startswith(("fail", "blocked"))
        )
        return round(failures / len(rows), 6)

    def _memory_conflict_density(self) -> float:
        try:
            count = self.store.conn.execute(
                "SELECT COUNT(*) AS count FROM memory_review_queue WHERE status != 'resolved'"
            ).fetchone()["count"]
        except Exception:
            count = 0
        return round(min(1.0, int(count or 0) / 10), 6)

    def _plan_drift(self, task_session_id: str | None, paths: list[str]) -> float:
        if not task_session_id or not paths:
            return 0.0
        try:
            rows = self.store.conn.execute(
                """
                SELECT plan_json FROM task_plans
                WHERE task_session_id = ?
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (task_session_id,),
            ).fetchall()
        except Exception:
            return 0.0
        intended: set[str] = set()
        for row in rows:
            try:
                plan = json.loads(row["plan_json"] or "{}")
            except json.JSONDecodeError:
                plan = {}
            for step in plan.get("steps", []) if isinstance(plan, dict) else []:
                if isinstance(step, dict):
                    intended.update(
                        _normalize_path(path) for path in step.get("intended_files", [])
                    )
        if not intended:
            return 0.0
        drift = [path for path in paths if path not in intended]
        return round(len(drift) / len(paths), 6)

    def _critical_path_pressure(self, paths: list[str]) -> float:
        if not paths:
            return 0.0
        critical = sum(1 for path in paths if _critical(path))
        return round(critical / len(paths), 6)

    def _behavioral_anomaly(self, session_id: str) -> float:
        if self.behavior_engine is None or not hasattr(self.behavior_engine, "anomaly"):
            return 0.0
        try:
            return _clamp(float(self.behavior_engine.anomaly(session_id=session_id)))
        except Exception:
            return 0.0


def build_nudge_message(
    *,
    target_paths: list[str] | None,
    surprise: dict[str, Any],
    level: str,
    interoception: dict[str, Any] | None = None,
) -> str:
    paths = ", ".join(target_paths or []) or "this action"
    score = surprise.get("surprise")
    components = surprise.get("components", {}) if isinstance(surprise, dict) else {}
    parts = [f"Anticipation {level}: {paths} is unusual for this context"]
    if score is not None:
        parts.append(f"(surprise {float(score):.2f})")
    reasons = []
    if float(components.get("failure_prior", 0.0) or 0.0) >= 0.5:
        reasons.append("similar history has failed before")
    if float(components.get("locality", 0.0) or 0.0) >= 0.5:
        reasons.append("target area is uncommon for the current trajectory")
    if interoception and interoception.get("summary"):
        reasons.append(str(interoception["summary"]))
    if reasons:
        parts.append(": " + "; ".join(reasons))
    return " ".join(parts).strip()


def _summary(components: dict[str, float]) -> str:
    elevated = [
        name.replace("_", " ")
        for name, value in sorted(components.items())
        if float(value) >= 0.5
    ]
    return (
        "fragile internal state: " + ", ".join(elevated)
        if elevated
        else "internal state stable"
    )


def _weighted(components: dict[str, float]) -> float:
    total = sum(DEFAULT_WEIGHTS.values())
    value = sum(
        float(components.get(name, 0.0)) * weight
        for name, weight in DEFAULT_WEIGHTS.items()
    )
    return round(_clamp(value / total), 6)


def _critical(path: str) -> bool:
    lowered = _normalize_path(path).lower()
    return any(
        token in lowered for token in ("/auth/", "/billing/", "/payments/", "migration")
    )


def _normalize_path(path: str) -> str:
    return str(path).replace("\\", "/").lstrip("./")


def _clamp(value: float) -> float:
    return min(1.0, max(0.0, value))
