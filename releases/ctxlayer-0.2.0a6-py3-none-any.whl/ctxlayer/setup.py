from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any

from ctxlayer.agents.adapters import resolve
from ctxlayer.agents.adapters.base import BootstrapContext
from ctxlayer.agents.adapters.codex import CodexAdapter


def is_git_repo(repo_root: Path) -> bool:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            cwd=repo_root,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=10,
        )
    except (FileNotFoundError, subprocess.SubprocessError):
        return False
    return result.returncode == 0 and result.stdout.strip() == "true"


def init_git_repo(repo_root: Path) -> dict[str, Any]:
    result = subprocess.run(
        ["git", "init"],
        cwd=repo_root,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=30,
    )
    return {
        "ok": result.returncode == 0,
        "command": ["git", "init"],
        "returncode": result.returncode,
        "stdout": result.stdout.strip(),
        "stderr": result.stderr.strip(),
    }


def default_codex_config_path() -> Path:
    return Path.home() / ".codex" / "config.toml"


def merge_codex_mcp_config(
    config_path: Path,
    *,
    command: str = "ctxlayer",
    mcp_repo: str = ".",
) -> dict[str, Any]:
    ctx = BootstrapContext(
        repo_root=Path.cwd(),
        mcp_command=command,
        mcp_repo=mcp_repo,
        shell="powershell",
        agent_names=["codex"],
    )
    return CodexAdapter().configure_mcp(ctx, config_path=config_path)


def setup_readiness(repo_root: Path, agents: list[str] | None = None) -> dict[str, Any]:
    adapters = resolve(agents or ["codex"])
    agent_names = {adapter.name for adapter in adapters}
    agents_path = repo_root / "AGENTS.md"
    agents_text = (
        agents_path.read_text(encoding="utf-8") if agents_path.exists() else ""
    )
    hooks_dir = repo_root / ".git" / "hooks"
    checks = {
        "git_repo": is_git_repo(repo_root),
        "capabilities_file": (repo_root / "ctxlayer.capabilities.yaml").exists(),
        "pre_commit_hook": (hooks_dir / "pre-commit").exists(),
        "post_commit_hook": (hooks_dir / "post-commit").exists(),
        "ctxlayer_ignored": _gitignore_has_ctxlayer(repo_root),
    }
    if "codex" in agent_names:
        checks.update(
            {
                "agents_file": agents_path.exists(),
                "agents_contract": "<!-- ctxlayer-agent-contract -->" in agents_text,
                "codex_mcp_snippet": (
                    repo_root / ".ctxlayer" / "mcp" / "codex.config.toml"
                ).exists(),
                "codex_project_config": (repo_root / ".codex" / "config.toml").exists(),
                "codex_hooks": (repo_root / ".codex" / "hooks.json").exists()
                and (
                    repo_root / ".ctxlayer" / "codex" / "hooks" / "ctxlayer_hook.py"
                ).exists(),
                "codex_agents": all(
                    (repo_root / ".codex" / "agents" / name).exists()
                    for name in [
                        "ctx-explorer.toml",
                        "ctx-worker.toml",
                        "ctx-reviewer.toml",
                        "ctx-verifier.toml",
                    ]
                ),
            }
        )
    agent_readiness = {
        adapter.name: adapter.readiness(repo_root) for adapter in adapters
    }
    for readiness in agent_readiness.values():
        checks.update(readiness.get("checks", {}))
    advisory = {"pre_commit_hook", "post_commit_hook"}
    missing = [name for name, ok in checks.items() if not ok and name not in advisory]
    advisory_missing = [
        name for name, ok in checks.items() if not ok and name in advisory
    ]
    return {
        "ok": not missing,
        "checks": checks,
        "missing": missing,
        "advisory_missing": advisory_missing,
        "agents": agent_readiness,
    }


def _replace_toml_table(existing: str, table_name: str, block: str) -> str:
    lines = existing.splitlines()
    header = f"[{table_name}]"
    output: list[str] = []
    idx = 0
    replaced = False
    while idx < len(lines):
        if lines[idx].strip() == header:
            if output and output[-1].strip():
                output.append("")
            output.extend(block.strip().splitlines())
            replaced = True
            idx += 1
            while idx < len(lines):
                stripped = lines[idx].strip()
                if stripped.startswith("[") and stripped.endswith("]"):
                    break
                idx += 1
            continue
        output.append(lines[idx])
        idx += 1

    if not replaced:
        if output and output[-1].strip():
            output.append("")
        output.extend(block.strip().splitlines())

    return "\n".join(output).rstrip() + "\n"


def _gitignore_has_ctxlayer(repo_root: Path) -> bool:
    gitignore = repo_root / ".gitignore"
    if not gitignore.exists():
        return False
    return ".ctxlayer/" in gitignore.read_text(encoding="utf-8").splitlines()
