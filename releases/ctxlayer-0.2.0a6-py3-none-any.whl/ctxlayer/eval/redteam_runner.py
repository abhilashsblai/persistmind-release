from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ctxlayer.security.memory_defense import evaluate_ingest, serve_decision
from ctxlayer.utils import stable_id, utc_now


ATTACK_CLASSES = {
    "prompt_injection",
    "memory_poison",
    "exfiltration",
    "authority_spoof",
    "contradiction_flood",
}


class RedTeamRunner:
    def __init__(self, fixtures_dir: Path):
        self.fixtures_dir = fixtures_dir

    def run(
        self, *, output: Path | None = None, strict: bool = False
    ) -> dict[str, Any]:
        fixtures = self._load()
        results = [self._evaluate(item) for item in fixtures]
        attacks = [item for item in results if item["attack_class"] in ATTACK_CLASSES]
        benign = [item for item in results if item["attack_class"] == "benign_control"]
        served_authoritative_count = sum(
            1 for item in attacks if item["served_authoritative"] is True
        )
        attack_passed = sum(1 for item in attacks if item["passed"])
        benign_false_quarantine = sum(
            1 for item in benign if item["decision"] in {"deny", "quarantine"}
        )
        report = {
            "ok": served_authoritative_count == 0 and attack_passed == len(attacks),
            "redteam_run_id": stable_id(str(self.fixtures_dir), utc_now()),
            "generated_at": utc_now(),
            "fixtures_dir": str(self.fixtures_dir),
            "total": len(results),
            "attacks": len(attacks),
            "attacks_passed": attack_passed,
            "quarantined": sum(
                1 for item in results if item["decision"] == "quarantine"
            ),
            "denied": sum(1 for item in results if item["decision"] == "deny"),
            "served_authoritative_count": served_authoritative_count,
            "benign_controls": len(benign),
            "false_quarantine_rate": (
                round(benign_false_quarantine / len(benign), 6) if benign else 0.0
            ),
            "results": results,
        }
        if strict and not report["ok"]:
            report["error"] = "red-team gate failed"
        if output:
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(
                json.dumps(report, indent=2, sort_keys=True), encoding="utf-8"
            )
            report["output"] = str(output)
        return report

    def _load(self) -> list[dict[str, Any]]:
        if not self.fixtures_dir.exists():
            raise FileNotFoundError(f"redteam fixtures not found: {self.fixtures_dir}")
        fixtures: list[dict[str, Any]] = []
        for path in sorted(self.fixtures_dir.glob("*.json")):
            data = json.loads(path.read_text(encoding="utf-8"))
            for item in data.get("fixtures", []):
                fixtures.append({**item, "_fixture_file": path.name})
        return fixtures

    def _evaluate(self, item: dict[str, Any]) -> dict[str, Any]:
        defense = evaluate_ingest(
            str(item.get("content") or ""),
            actor="redteam",
            source_connector=str(item.get("source_connector") or "external"),
            external=True,
        )
        serving = serve_decision(
            defense,
            {"external": True, "source_connector": item.get("source_connector")},
        )
        expected = item.get("expected") or {}
        required_flags = set(expected.get("must_flag") or [])
        observed_flags = set(defense.get("injection_flags") or []) | set(
            defense.get("poison_flags") or []
        )
        decision = str(defense.get("decision") or serving["decision"])
        served_authoritative = bool(serving["serve_authoritative"])
        passed = (
            decision
            in set(expected.get("decision_any") or [expected.get("decision", decision)])
            and served_authoritative
            is bool(expected.get("served_authoritative", False))
            and required_flags <= observed_flags
        )
        return {
            "id": item["id"],
            "fixture_file": item.get("_fixture_file"),
            "source_connector": item.get("source_connector"),
            "attack_class": item.get("attack_class"),
            "decision": decision,
            "served_authoritative": served_authoritative,
            "required_flags": sorted(required_flags),
            "observed_flags": sorted(observed_flags),
            "passed": passed,
            "defense_result": defense,
        }
