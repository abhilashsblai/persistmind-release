from __future__ import annotations

import json
import os
import urllib.parse
import urllib.request
from dataclasses import dataclass


@dataclass(frozen=True)
class ProviderPR:
    merge_commit_sha: str
    title: str
    body: str


def fetch_provider_prs(
    provider: str, project: str | None, limit: int
) -> dict[str, ProviderPR]:
    if provider == "git" or not project:
        return {}
    if provider == "github":
        return _github_prs(project, limit)
    if provider == "gitlab":
        return _gitlab_prs(project, limit)
    raise ValueError(f"unknown eval provider: {provider}")


def _github_prs(project: str, limit: int) -> dict[str, ProviderPR]:
    token = os.environ.get("GITHUB_TOKEN")
    url = f"https://api.github.com/repos/{project}/pulls?state=closed&per_page={min(limit, 100)}"
    headers = {"Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    data = _get_json(url, headers)
    prs: dict[str, ProviderPR] = {}
    for item in data if isinstance(data, list) else []:
        sha = item.get("merge_commit_sha")
        if sha:
            prs[sha] = ProviderPR(
                merge_commit_sha=sha,
                title=str(item.get("title") or ""),
                body=str(item.get("body") or ""),
            )
    return prs


def _gitlab_prs(project: str, limit: int) -> dict[str, ProviderPR]:
    token = os.environ.get("GITLAB_TOKEN")
    encoded = urllib.parse.quote_plus(project)
    base = os.environ.get("GITLAB_URL", "https://gitlab.com").rstrip("/")
    url = f"{base}/api/v4/projects/{encoded}/merge_requests?state=merged&per_page={min(limit, 100)}"
    headers = {}
    if token:
        headers["PRIVATE-TOKEN"] = token
    data = _get_json(url, headers)
    prs: dict[str, ProviderPR] = {}
    for item in data if isinstance(data, list) else []:
        sha = item.get("merge_commit_sha")
        if sha:
            prs[sha] = ProviderPR(
                merge_commit_sha=sha,
                title=str(item.get("title") or ""),
                body=str(item.get("description") or ""),
            )
    return prs


def _get_json(url: str, headers: dict[str, str]) -> object:
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(
        request, timeout=20
    ) as response:  # noqa: S310 - configured URL.
        return json.loads(response.read().decode("utf-8"))
