from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ctxlayer.snapshot import SnapshotInfo
from ctxlayer.store import SQLiteStore

CONFIDENCE_THRESHOLD = 0.7


class ComponentEvalHarness:
    def __init__(self, store: SQLiteStore):
        self.store = store

    def run_path(self, *, snapshot: SnapshotInfo, path: Path) -> dict[str, Any]:
        if not path.exists():
            return {
                "ok": False,
                "schema_version": "ctxlayer.component_eval.v1",
                "error": "ground truth file not found",
                "ground_truth_path": str(path),
            }
        data = json.loads(path.read_text(encoding="utf-8"))
        report = self.run(snapshot=snapshot, ground_truth=data)
        report["ground_truth_path"] = str(path)
        return report

    def run(
        self, *, snapshot: SnapshotInfo, ground_truth: dict[str, Any]
    ) -> dict[str, Any]:
        imports = _component_spec(ground_truth, "imports")
        test_links = _component_spec(ground_truth, "test_links")
        return {
            "ok": True,
            "schema_version": "ctxlayer.component_eval.v1",
            "snapshot_id": snapshot.snapshot_id,
            "repo_id": snapshot.repo_id,
            "ground_truth_version": ground_truth.get("schema_version"),
            "imports": self._score_kind(
                snapshot=snapshot,
                kind="imports",
                expected=_pairs(imports.get("edges", []), "src", "dst"),
                scope_sources=set(imports.get("scope_files", [])),
            ),
            "test_links": self._score_kind(
                snapshot=snapshot,
                kind="tests",
                expected=_pairs(test_links.get("edges", []), "test", "source"),
                scope_sources=set(test_links.get("scope_tests", [])),
            ),
        }

    def _score_kind(
        self,
        *,
        snapshot: SnapshotInfo,
        kind: str,
        expected: set[tuple[str, str]],
        scope_sources: set[str],
    ) -> dict[str, Any]:
        predicted: set[tuple[str, str]] = set()
        confidence_by_edge: dict[tuple[str, str], float] = {}
        for edge in self.store.logical_edges(
            """
            scope_snapshot_id = ?
            AND src_repo_id = ?
            AND dst_repo_id = ?
            AND src_node_type = 'file'
            AND dst_node_type = 'file'
            AND kind = ?
            """,
            (snapshot.snapshot_id, snapshot.repo_id, snapshot.repo_id, kind),
        ):
            pair = (edge["src_node_id"], edge["dst_node_id"])
            if scope_sources and pair[0] not in scope_sources:
                continue
            predicted.add(pair)
            confidence_by_edge[pair] = max(
                confidence_by_edge.get(pair, 0.0), float(edge["confidence"])
            )
        scored = _score_pairs(expected, predicted)
        true_positive = expected & predicted
        expected_confidences = [
            confidence_by_edge.get(pair, 0.0) for pair in sorted(expected)
        ]
        true_positive_confidences = [
            confidence_by_edge[pair] for pair in sorted(true_positive)
        ]
        low_confidence_true_edges = [
            {
                "src": src,
                "dst": dst,
                "confidence": round(confidence_by_edge[(src, dst)], 4),
            }
            for src, dst in sorted(true_positive)
            if confidence_by_edge.get((src, dst), 0.0) < CONFIDENCE_THRESHOLD
        ]
        return {
            **scored,
            "scope_sources": sorted(scope_sources),
            "confidence_threshold": CONFIDENCE_THRESHOLD,
            "confidence_recall_at_threshold": _confidence_recall(expected_confidences),
            "mean_expected_confidence": _mean(expected_confidences),
            "mean_true_positive_confidence": _mean(true_positive_confidences),
            "low_confidence_true_edges": low_confidence_true_edges,
            "low_confidence_true_edge_count": len(low_confidence_true_edges),
        }


def _component_spec(ground_truth: dict[str, Any], key: str) -> dict[str, Any]:
    value = ground_truth.get(key, {})
    return value if isinstance(value, dict) else {}


def _pairs(
    items: list[dict[str, Any]], src_key: str, dst_key: str
) -> set[tuple[str, str]]:
    pairs: set[tuple[str, str]] = set()
    for item in items:
        src = item.get(src_key)
        dst = item.get(dst_key)
        if isinstance(src, str) and isinstance(dst, str) and src and dst:
            pairs.add((src.replace("\\", "/"), dst.replace("\\", "/")))
    return pairs


def _score_pairs(
    expected: set[tuple[str, str]], predicted: set[tuple[str, str]]
) -> dict[str, Any]:
    true_positive = expected & predicted
    false_positive = predicted - expected
    false_negative = expected - predicted
    precision = (
        len(true_positive) / len(predicted)
        if predicted
        else (1.0 if not expected else 0.0)
    )
    recall = len(true_positive) / len(expected) if expected else 1.0
    f1 = (2 * precision * recall / (precision + recall)) if precision + recall else 0.0
    return {
        "expected": len(expected),
        "predicted": len(predicted),
        "true_positive": len(true_positive),
        "false_positive": len(false_positive),
        "false_negative": len(false_negative),
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "false_positive_edges": _edge_dicts(false_positive),
        "false_negative_edges": _edge_dicts(false_negative),
    }


def _edge_dicts(edges: set[tuple[str, str]]) -> list[dict[str, str]]:
    return [{"src": src, "dst": dst} for src, dst in sorted(edges)]


def _confidence_recall(confidences: list[float]) -> float:
    if not confidences:
        return 1.0
    return round(
        sum(1 for confidence in confidences if confidence >= CONFIDENCE_THRESHOLD)
        / len(confidences),
        4,
    )


def _mean(values: list[float]) -> float:
    if not values:
        return 0.0
    return round(sum(values) / len(values), 4)
