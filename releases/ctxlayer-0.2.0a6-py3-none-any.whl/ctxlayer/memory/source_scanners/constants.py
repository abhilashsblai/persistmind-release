from __future__ import annotations

import re
from pathlib import Path

from ctxlayer.memory.evidence import RuleCandidate, RuleEvidence


def scan(root: Path) -> list[RuleCandidate]:
    candidates: list[RuleCandidate] = []
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {
            ".py",
            ".ts",
            ".tsx",
            ".js",
        }:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        rel = path.relative_to(root).as_posix()
        for match in re.finditer(
            r"([A-Z][A-Z0-9_]*(?:LIMIT|THRESHOLD|MAX|MIN)[A-Z0-9_]*)\s*[:=]\s*([0-9_]+)",
            text,
        ):
            name, value = match.groups()
            readable = name.lower().replace("_", " ")
            line = text[: match.start()].count("\n") + 1
            rule = f"{readable} is {value.replace('_', '')}."
            candidates.append(
                RuleCandidate(
                    text=rule,
                    source_type="code",
                    confidence=0.62,
                    evidence=[
                        RuleEvidence(rel, "constant", match.group(0), line, line)
                    ],
                )
            )
    return candidates
