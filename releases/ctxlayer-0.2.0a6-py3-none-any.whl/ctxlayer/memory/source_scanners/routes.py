from __future__ import annotations

import re
from pathlib import Path

from ctxlayer.memory.evidence import RuleCandidate, RuleEvidence


def scan(root: Path) -> list[RuleCandidate]:
    candidates: list[RuleCandidate] = []
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {
            ".py",
            ".ts",
            ".tsx",
            ".js",
        }:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        rel = path.relative_to(root).as_posix()
        for match in re.finditer(
            r"(?:permission_required|Depends|guard|authorize|requireRole)\(([^)]{3,120})\)",
            text,
        ):
            line = text[: match.start()].count("\n") + 1
            rule = f"Route guarded by {match.group(1).strip()}."
            candidates.append(
                RuleCandidate(
                    text=rule,
                    source_type="code",
                    confidence=0.64,
                    evidence=[
                        RuleEvidence(rel, "route_guard", match.group(0), line, line)
                    ],
                )
            )
    return candidates
