from __future__ import annotations

import json
import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from ctxlayer.memory.unified import UnifiedMemory
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import sha256_text, stable_id, utc_now


ACTIVE_STATES = {
    "intake",
    "packed",
    "planned",
    "editing",
    "checking",
    "blocked",
    "ready_to_resume",
}
STALE_STATES = {"expired", "stale"}


class ContinuationMemory:
    def __init__(
        self,
        store: SQLiteStore,
        *,
        workspace_id: str,
        repo_id: str | None,
        recall_weights: dict[str, float] | None = None,
        repo_root: Path | None = None,
    ):
        self.store = store
        self.workspace_id = workspace_id
        self.repo_id = repo_id
        self.repo_root = repo_root
        self.memory = UnifiedMemory(
            store,
            workspace_id=workspace_id,
            repo_id=repo_id,
            recall_weights=recall_weights,
        )

    def upsert_for_task_session(
        self,
        task_session_id: str,
        *,
        agent_session_id: str | None = None,
        event: str = "task_session",
        state: str | None = None,
        next_action: str | None = None,
        blockers: list[str] | None = None,
        reason: str | None = None,
    ) -> dict[str, Any]:
        if not self.store.task_session(task_session_id):
            return {
                "ok": False,
                "error": "task session not found",
                "task_session_id": task_session_id,
            }
        capsule = self._build_capsule(
            task_session_id,
            agent_session_id=agent_session_id,
            state=state,
            next_action=next_action,
            blockers=blockers,
        )
        record_id = continuation_record_id(
            self.workspace_id, self.repo_id, task_session_id
        )
        status = "active" if capsule["current_state"] in ACTIVE_STATES else "expired"
        payload = {
            "type": "continuation",
            "title": capsule["objective"],
            "assertion": _assertion(capsule),
            "scope_kind": "task",
            "scope_refs": [task_session_id],
            "source_kind": f"continuation:{event}",
            "confidence": 1.0,
            "importance": (
                1.0
                if capsule["current_state"] in {"blocked", "ready_to_resume"}
                else 0.8
            ),
            "status": status,
            "trust": "active",
            "metadata": capsule,
            "provenance": {
                "generator": "ctxlayer:continuation",
                "validator": "task_session_events",
                "task_session_id": task_session_id,
                "updated_by_event": event,
            },
        }
        existing = self.store.memory_record(record_id)
        if existing:
            updated = self.memory.update(
                record_id,
                {
                    "title": payload["title"],
                    "assertion": payload["assertion"],
                    "status": status,
                    "trust": "active",
                    "importance": payload["importance"],
                    "source_kind": payload["source_kind"],
                    "metadata": payload["metadata"],
                    "provenance": payload["provenance"],
                },
                actor="continuation",
                reason=reason or event,
            )
            return {"ok": True, "continuation": updated["record"], "updated": True}
        created = self.memory.create_typed({**payload, "record_id": record_id})
        return {"ok": True, "continuation": created["record"], "updated": False}

    def upsert_for_agent_session(
        self,
        session_id: str,
        *,
        event: str,
        state: str | None = None,
        next_action: str | None = None,
        blockers: list[str] | None = None,
        reason: str | None = None,
    ) -> dict[str, Any]:
        task_session_id = self._task_session_id_for_agent_session(session_id)
        if not task_session_id:
            return {
                "ok": False,
                "error": "task session artifact not found",
                "session_id": session_id,
            }
        return self.upsert_for_task_session(
            task_session_id,
            agent_session_id=session_id,
            event=event,
            state=state,
            next_action=next_action,
            blockers=blockers,
            reason=reason,
        )

    def list(self, *, status: str | None = None, limit: int = 20) -> dict[str, Any]:
        rows = self.store.memory_records(
            type="continuation",
            status=status,
            repo_id=self.repo_id,
            workspace_id=self.workspace_id,
        )
        return {
            "ok": True,
            "continuations": [
                self._project_with_staleness(row) for row in rows[:limit]
            ],
        }

    def show(self, continuation_id: str) -> dict[str, Any]:
        row = self.store.memory_record(continuation_id)
        if not row or row["type"] != "continuation":
            return {
                "ok": False,
                "error": "continuation not found",
                "continuation_id": continuation_id,
            }
        return {
            "ok": True,
            "continuation": self._project_with_staleness(row),
            "revisions": [
                dict(item) for item in self.store.memory_revisions(continuation_id)
            ],
        }

    def update(
        self,
        continuation_id: str,
        *,
        state: str | None = None,
        next_action: str | None = None,
        blockers: list[str] | None = None,
        reason: str = "manual continuation update",
    ) -> dict[str, Any]:
        row = self.store.memory_record(continuation_id)
        if not row or row["type"] != "continuation":
            return {
                "ok": False,
                "error": "continuation not found",
                "continuation_id": continuation_id,
            }
        capsule = _json(row["metadata_json"])
        if state:
            capsule["current_state"] = state
        if next_action is not None:
            capsule["next_action"] = next_action
        if blockers is not None:
            capsule["blockers"] = blockers
        capsule["last_activity_at"] = utc_now()
        capsule["expires_at"] = _expires_at(
            capsule["last_activity_at"], capsule.get("current_state")
        )
        status = (
            "active" if capsule.get("current_state") in ACTIVE_STATES else "expired"
        )
        updated = self.memory.update(
            continuation_id,
            {
                "assertion": _assertion(capsule),
                "status": status,
                "metadata": capsule,
                "source_kind": "continuation:manual",
            },
            actor="local-user",
            reason=reason,
        )
        return {"ok": True, "continuation": updated["record"]}

    def abandon(self, continuation_id: str, *, reason: str) -> dict[str, Any]:
        return self.update(
            continuation_id,
            state="abandoned",
            next_action="No resume action; task was abandoned.",
            blockers=[reason],
            reason=reason,
        )

    def resume(self, task: str, *, limit: int = 3) -> dict[str, Any]:
        recalled = self.memory.recall(
            task,
            types=["continuation"],
            limit=limit,
            active_only=True,
            include_untrusted_candidates=False,
        )
        return {
            "ok": True,
            "task_text_hash": sha256_text(task),
            "continuations": self._servable_recalled(recalled["results"]),
        }

    def for_pack(
        self, task: str, paths: list[str], *, limit: int = 3
    ) -> list[dict[str, Any]]:
        recalled = self.memory.recall(
            task,
            paths=paths,
            types=["continuation"],
            limit=limit,
            active_only=True,
            include_untrusted_candidates=False,
        )
        return self._servable_recalled(recalled["results"])

    def _build_capsule(
        self,
        task_session_id: str,
        *,
        agent_session_id: str | None,
        state: str | None,
        next_action: str | None,
        blockers: list[str] | None,
    ) -> dict[str, Any]:
        task = self.store.task_session(task_session_id)
        task_metadata = _json(task["metadata_json"])
        plan = self.store.latest_task_plan_for_session(task_session_id)
        plan_payload: dict[str, Any] = {}
        plan_id = None
        pack_id = task["pack_id"]
        completed_steps: list[str] = []
        changed_files: list[str] = []
        checkpoint_blockers: list[str] = []
        if plan:
            plan_id = plan["plan_id"]
            plan_metadata = _json(plan["metadata_json"])
            pack_id = pack_id or plan_metadata.get("pack_id")
            revisions = self.store.task_plan_revisions(plan_id)
            if revisions:
                plan_payload = _json(revisions[-1]["plan_json"])
            for checkpoint in self.store.task_plan_checkpoints(plan_id):
                changed_files.extend(
                    str(path) for path in _json_list(checkpoint["changed_paths_json"])
                )
                if checkpoint["status"] == "pass":
                    completed_steps.append(checkpoint["step_id"])
                else:
                    checkpoint_blockers.append(
                        f"Checkpoint {checkpoint['step_id']} failed."
                    )
        intended_files = sorted(set(_step_values(plan_payload, "intended_files")))
        tests_planned = sorted(set(_step_values(plan_payload, "intended_tests")))
        steps = (
            plan_payload.get("steps", [])
            if isinstance(plan_payload.get("steps"), list)
            else []
        )
        completed = set(completed_steps)
        remaining_steps = [
            str(step.get("id") or step.get("title"))
            for step in steps
            if str(step.get("id") or step.get("title")) not in completed
        ]
        latest_outcome = self._latest_outcome(agent_session_id)
        all_blockers = [*(blockers or []), *checkpoint_blockers]
        current_state = state or _state_from(
            task["current_state"],
            plan_id,
            completed_steps,
            remaining_steps,
            latest_outcome,
            all_blockers,
        )
        next_action = next_action or _next_action(
            current_state, remaining_steps, tests_planned, all_blockers
        )
        objective = (
            task_metadata.get("objective")
            or task_metadata.get("task")
            or f"Task {task_session_id}"
        )
        last_activity_at = utc_now()
        pack_manifest = _pack_manifest(self.store, pack_id)
        return {
            "continuation_id": continuation_record_id(
                self.workspace_id, self.repo_id, task_session_id
            ),
            "task_session_id": task_session_id,
            "agent_session_id": agent_session_id
            or self._session_id_for_task_session(task_session_id),
            "plan_id": plan_id,
            "pack_id": pack_id,
            "base_snapshot_id": pack_manifest.get("snapshot_id"),
            "base_commit_sha": pack_manifest.get("base_commit_sha"),
            "objective": objective,
            "current_state": current_state,
            "active_step_id": remaining_steps[0] if remaining_steps else None,
            "completed_steps": completed_steps,
            "remaining_steps": remaining_steps,
            "intended_files": intended_files,
            "changed_files": sorted(set(changed_files)),
            "files_read": [],
            "tests_planned": tests_planned,
            "tests_run": [],
            "latest_verification": None,
            "latest_outcome": latest_outcome,
            "blockers": all_blockers,
            "next_action": next_action,
            "resume_instructions": _resume_instructions(
                current_state, next_action, all_blockers
            ),
            "risks": [] if plan_id else ["missing_structured_plan"],
            "ttl_days": _ttl_days(current_state),
            "expires_at": _expires_at(last_activity_at, current_state),
            "last_activity_at": last_activity_at,
            "supersedes_continuation_id": None,
            "evidence": _evidence_refs(task_session_id, plan_id, pack_id),
        }

    def _latest_outcome(self, session_id: str | None) -> dict[str, Any] | None:
        if not session_id:
            return None
        events = [
            event
            for event in self.store.agent_session_events(session_id)
            if event["event_type"] == "outcome"
        ]
        if not events:
            return None
        payload = _json(events[-1]["payload_json"])
        return {
            "outcome_id": payload.get("outcome_id"),
            "pack_id": payload.get("pack_id"),
            "result": payload.get("result"),
            "files_changed": payload.get("files_changed", []),
        }

    def _task_session_id_for_agent_session(self, session_id: str) -> str | None:
        for artifact in self.store.agent_session_artifacts(session_id):
            if artifact["artifact_type"] == "task_session":
                return artifact["ref"]
        return None

    def _session_id_for_task_session(self, task_session_id: str) -> str | None:
        row = self.store.agent_session_for_artifact("task_session", task_session_id)
        return row["session_id"] if row else None

    def _project(self, row: Any) -> dict[str, Any]:
        metadata = _json(row["metadata_json"])
        return {
            **metadata,
            "continuation_id": row["record_id"],
            "record_id": row["record_id"],
            "status": row["status"],
            "trust": row["trust"],
            "score": 1.0,
        }

    def _project_with_staleness(self, row: Any) -> dict[str, Any]:
        projected = self._project(row)
        diagnostics = self._staleness_diagnostics(projected)
        projected.update(diagnostics)
        if (
            diagnostics["staleness_state"] in STALE_STATES
            and projected["status"] == "active"
        ):
            projected["status"] = "expired"
        return projected

    def _servable_recalled(self, items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        served: list[dict[str, Any]] = []
        for item in items:
            row = self.store.memory_record(item["record_id"])
            if not row:
                continue
            projected = self._project_recalled(item)
            diagnostics = self._staleness_diagnostics(projected)
            if diagnostics["staleness_state"] in STALE_STATES:
                self._expire_stale(row, projected, diagnostics)
                continue
            projected.update(diagnostics)
            served.append(projected)
        return served

    def _expire_stale(
        self,
        row: Any,
        projected: dict[str, Any],
        diagnostics: dict[str, Any],
    ) -> None:
        metadata = _json(row["metadata_json"])
        metadata.update(diagnostics)
        metadata["risks"] = sorted(
            {*(metadata.get("risks") or []), *diagnostics.get("staleness_reasons", [])}
        )
        self.memory.update(
            projected["record_id"],
            {
                "status": "expired",
                "metadata": metadata,
                "source_kind": "continuation:staleness",
            },
            actor="continuation",
            reason="continuation staleness detected before serving",
        )

    def _staleness_diagnostics(self, capsule: dict[str, Any]) -> dict[str, Any]:
        reasons: list[str] = []
        now = _parse_time(utc_now())
        expires_at = _parse_time(capsule.get("expires_at"))
        if expires_at and now and expires_at <= now:
            reasons.append("ttl_expired")
        base_commit = str(capsule.get("base_commit_sha") or "")
        head = _git_head(self.repo_root)
        if base_commit and head and base_commit != head:
            reasons.append("base_commit_diverged")
        missing_intended = _missing_paths(
            self.repo_root, capsule.get("intended_files", [])
        )
        missing_changed = _missing_paths(
            self.repo_root, capsule.get("changed_files", [])
        )
        if missing_intended:
            reasons.append("intended_file_deleted")
        if missing_changed:
            reasons.append("changed_file_deleted")
        changed_since_base = (
            _changed_paths_since(
                self.repo_root, base_commit, capsule.get("intended_files", [])
            )
            if base_commit and head and base_commit != head
            else []
        )
        state = "fresh"
        if "ttl_expired" in reasons:
            state = "expired"
        elif reasons:
            state = "stale"
        return {
            "staleness_state": state,
            "staleness_reasons": sorted(set(reasons)),
            "staleness_diagnostics": {
                "base_commit_sha": base_commit or None,
                "current_head_sha": head,
                "base_snapshot_id": capsule.get("base_snapshot_id"),
                "expires_at": capsule.get("expires_at"),
                "missing_intended_files": missing_intended,
                "missing_changed_files": missing_changed,
                "changed_intended_files_since_base": changed_since_base,
            },
        }

    def _project_recalled(self, item: dict[str, Any]) -> dict[str, Any]:
        metadata = dict(item.get("metadata") or {})
        return {
            **metadata,
            "continuation_id": item["record_id"],
            "record_id": item["record_id"],
            "status": item["status"],
            "trust": item["trust"],
            "score": item["score"],
            "signals": item["signals"],
            "why_recalled": item["why_recalled"],
            "evidence": metadata.get("evidence", item.get("evidence", [])),
        }


def continuation_record_id(
    workspace_id: str, repo_id: str | None, task_session_id: str
) -> str:
    return stable_id("continuation", workspace_id, repo_id or "", task_session_id)


def _state_from(
    task_state: str,
    plan_id: str | None,
    completed_steps: list[str],
    remaining_steps: list[str],
    latest_outcome: dict[str, Any] | None,
    blockers: list[str],
) -> str:
    if latest_outcome and str(latest_outcome.get("result", "")).lower() in {
        "pass",
        "passed",
        "ok",
        "success",
    }:
        return "completed"
    if blockers:
        return "blocked"
    if task_state == "INTAKE":
        return "intake"
    if task_state == "PACK":
        return "packed"
    if task_state == "PLAN" or plan_id:
        return "planned" if not completed_steps else "editing"
    if task_state == "PREFLIGHT":
        return "checking"
    if remaining_steps:
        return "ready_to_resume"
    return "ready_to_resume"


def _next_action(
    state: str, remaining_steps: list[str], tests: list[str], blockers: list[str]
) -> str:
    if state == "blocked" and blockers:
        return f"Resolve blocker: {blockers[0]}"
    if remaining_steps:
        return f"Resume plan step: {remaining_steps[0]}"
    if tests:
        return f"Run verification: {tests[0]}"
    if state == "completed":
        return "No action; task completed."
    if state == "abandoned":
        return "No action; task abandoned."
    return "Review current diff, then continue with the task plan."


def _resume_instructions(state: str, next_action: str, blockers: list[str]) -> str:
    if state == "blocked":
        return f"Do not continue edits until blocker is resolved. {next_action}"
    return next_action


def _assertion(capsule: dict[str, Any]) -> str:
    parts = [
        f"Continuation for {capsule['objective']}.",
        f"State: {capsule['current_state']}.",
        f"Next action: {capsule['next_action']}",
    ]
    if capsule.get("intended_files"):
        parts.append("Files: " + ", ".join(capsule["intended_files"][:8]) + ".")
    return " ".join(parts)


def _pack_manifest(store: SQLiteStore, pack_id: str | None) -> dict[str, Any]:
    if not pack_id:
        return {}
    row = store.get_pack(pack_id)
    if not row:
        return {}
    return _json(row["manifest_json"])


def _ttl_days(state: str | None) -> int:
    if state == "blocked":
        return 30
    if state in {"intake", "packed"}:
        return 7
    if state in ACTIVE_STATES:
        return 14
    return 0


def _expires_at(last_activity_at: str, state: str | None) -> str | None:
    ttl = _ttl_days(state)
    if ttl <= 0:
        return last_activity_at
    parsed = _parse_time(last_activity_at)
    if not parsed:
        return None
    return (parsed + timedelta(days=ttl)).isoformat(timespec="seconds")


def _parse_time(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _git_head(repo_root: Path | None) -> str | None:
    if not repo_root:
        return None
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_root,
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=10,
        )
    except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return None
    return result.stdout.strip() or None


def _missing_paths(repo_root: Path | None, paths: Any) -> list[str]:
    if not repo_root or not isinstance(paths, list):
        return []
    missing = []
    for path in paths:
        normalized = str(path).replace("\\", "/").strip()
        if normalized and not (repo_root / normalized).exists():
            missing.append(normalized)
    return sorted(set(missing))


def _changed_paths_since(
    repo_root: Path | None, base_commit: str, paths: Any
) -> list[str]:
    if not repo_root or not base_commit or not isinstance(paths, list) or not paths:
        return []
    requested = [
        str(path).replace("\\", "/").strip() for path in paths if str(path).strip()
    ]
    if not requested:
        return []
    try:
        result = subprocess.run(
            ["git", "diff", "--name-only", f"{base_commit}..HEAD", "--", *requested],
            cwd=repo_root,
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=10,
        )
    except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return []
    return sorted(
        {
            line.strip().replace("\\", "/")
            for line in result.stdout.splitlines()
            if line.strip()
        }
    )


def _evidence_refs(
    task_session_id: str, plan_id: str | None, pack_id: str | None
) -> list[dict[str, Any]]:
    refs = [{"kind": "task_session", "ref": task_session_id}]
    if plan_id:
        refs.append({"kind": "plan", "ref": plan_id})
    if pack_id:
        refs.append({"kind": "pack", "ref": pack_id})
    return refs


def _step_values(plan: dict[str, Any], key: str) -> list[str]:
    values: list[str] = []
    steps = plan.get("steps", []) if isinstance(plan.get("steps"), list) else []
    for step in steps:
        raw = step.get(key, [])
        if isinstance(raw, list):
            values.extend(str(item) for item in raw)
    return values


def _json(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    try:
        parsed = json.loads(value or "{}")
    except (json.JSONDecodeError, TypeError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _json_list(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    try:
        parsed = json.loads(value or "[]")
    except (json.JSONDecodeError, TypeError):
        return []
    return parsed if isinstance(parsed, list) else []
