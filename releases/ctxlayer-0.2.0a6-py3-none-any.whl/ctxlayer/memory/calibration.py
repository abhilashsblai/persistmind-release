from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ctxlayer.store import SQLiteStore
from ctxlayer.utils import utc_now

SOURCE_TYPES = (
    "tests",
    "validations",
    "constants",
    "routes",
    "docs",
    "prs",
    "incidents",
)

SOURCE_ALIASES = {
    "test": "tests",
    "tests": "tests",
    "validation": "validations",
    "validations": "validations",
    "constant": "constants",
    "constants": "constants",
    "route": "routes",
    "routes": "routes",
    "doc": "docs",
    "docs": "docs",
    "pr": "prs",
    "prs": "prs",
    "incident": "incidents",
    "runtime": "incidents",
    "incidents": "incidents",
}

PRIOR_TIERS = {
    "tests": ("medium", 0.45),
    "validations": ("medium", 0.45),
    "constants": ("medium", 0.45),
    "routes": ("medium", 0.45),
    "docs": ("low", 0.45),
    "prs": ("low", 0.45),
    "incidents": ("low", 0.45),
}


@dataclass(frozen=True)
class Calibration:
    source_type: str
    default_tier: str
    approvals: int
    rejections: int
    approval_rate: float
    sample_size: int
    confidence_floor: float
    method: str

    def as_row(self, repo_id: str | None) -> dict[str, Any]:
        return {
            "repo_id": repo_id,
            "source_type": self.source_type,
            "default_tier": self.default_tier,
            "approvals": self.approvals,
            "rejections": self.rejections,
            "approval_rate": self.approval_rate,
            "sample_size": self.sample_size,
            "confidence_floor": self.confidence_floor,
            "method": self.method,
            "computed_at": utc_now(),
        }


class TrustCalibrator:
    def __init__(
        self,
        store: SQLiteStore,
        repo_id: str | None,
        *,
        min_sample: int = 5,
        alpha: float = 1.0,
        beta: float = 1.0,
    ) -> None:
        self.store = store
        self.repo_id = repo_id
        self.min_sample = min_sample
        self.alpha = alpha
        self.beta = beta

    def recompute(self, *, apply: bool = False) -> dict[str, Any]:
        old = {
            row["source_type"]: dict(row)
            for row in self.store.trust_calibration_for(self.repo_id)
        }
        counts = {
            canonical_source_type(row["source_type"]): {
                "approvals": int(row["approvals"] or 0),
                "rejections": int(row["rejections"] or 0),
            }
            for row in self.store.approval_counts_by_source(self.repo_id)
        }
        calibrations = [
            self._calibration_for(source, counts.get(source, {}))
            for source in SOURCE_TYPES
        ]
        deltas = []
        for calibration in calibrations:
            previous = old.get(calibration.source_type) or {}
            item = {
                "source_type": calibration.source_type,
                "old_tier": previous.get("default_tier"),
                "new_tier": calibration.default_tier,
                "old_floor": previous.get("confidence_floor"),
                "new_floor": calibration.confidence_floor,
                "approval_rate": calibration.approval_rate,
                "sample_size": calibration.sample_size,
                "method": calibration.method,
                "changed": previous.get("default_tier") != calibration.default_tier
                or previous.get("confidence_floor") != calibration.confidence_floor,
            }
            deltas.append(item)
            if apply:
                self.store.write_trust_calibration(calibration.as_row(self.repo_id))
        audit = None
        if apply:
            audit = self.store.append_audit(
                pack_id=f"trust-calibration:{self.repo_id or 'global'}",
                payload={
                    "kind": "trust_calibration",
                    "repo_id": self.repo_id,
                    "deltas": deltas,
                    "min_sample": self.min_sample,
                },
            )
        return {"ok": True, "applied": apply, "deltas": deltas, "audit": audit}

    def tier_for(self, source_type: str) -> dict[str, Any]:
        source = canonical_source_type(source_type)
        rows = self.store.trust_calibration_for(self.repo_id, source)
        if rows:
            row = rows[0]
            return {
                "source_type": source,
                "trust_tier": row["default_tier"],
                "confidence_floor": float(row["confidence_floor"]),
                "method": row["method"],
                "approval_rate": float(row["approval_rate"]),
                "sample_size": int(row["sample_size"]),
            }
        calibration = self._calibration_for(source, {})
        return {
            "source_type": source,
            "trust_tier": calibration.default_tier,
            "confidence_floor": calibration.confidence_floor,
            "method": calibration.method,
            "approval_rate": calibration.approval_rate,
            "sample_size": calibration.sample_size,
        }

    def calibrate_confidence(
        self, source_type: str, raw_score: float
    ) -> dict[str, Any]:
        tier = self.tier_for(source_type)
        multiplier = {"high": 1.08, "medium": 1.0, "low": 0.86}.get(
            tier["trust_tier"], 0.9
        )
        rate = float(tier.get("approval_rate") or 0.5)
        calibrated = _clamp((float(raw_score) * multiplier * 0.75) + (rate * 0.25))
        return {
            **tier,
            "raw_score": _round(float(raw_score)),
            "calibrated_confidence": _round(calibrated),
            "confidence_method": f"{tier['method']}+raw_score",
        }

    def _calibration_for(self, source: str, counts: dict[str, int]) -> Calibration:
        approvals = int(counts.get("approvals") or 0)
        rejections = int(counts.get("rejections") or 0)
        sample_size = approvals + rejections
        if sample_size < self.min_sample:
            tier, floor = PRIOR_TIERS.get(source, ("low", 0.65))
            return Calibration(
                source_type=source,
                default_tier=tier,
                approvals=approvals,
                rejections=rejections,
                approval_rate=_round(
                    (approvals + self.alpha) / (sample_size + self.alpha + self.beta)
                ),
                sample_size=sample_size,
                confidence_floor=floor,
                method="prior_fallback",
            )
        rate = (approvals + self.alpha) / (sample_size + self.alpha + self.beta)
        tier = _tier(rate)
        floor = _floor(rate)
        return Calibration(
            source_type=source,
            default_tier=tier,
            approvals=approvals,
            rejections=rejections,
            approval_rate=_round(rate),
            sample_size=sample_size,
            confidence_floor=floor,
            method="beta_posterior",
        )


def canonical_source_type(source_type: str | None) -> str:
    token = str(source_type or "").strip().lower().replace("-", "_")
    return SOURCE_ALIASES.get(token, token if token in SOURCE_TYPES else "docs")


def _tier(rate: float) -> str:
    if rate >= 0.75:
        return "high"
    if rate >= 0.40:
        return "medium"
    return "low"


def _floor(rate: float) -> float:
    if rate >= 0.75:
        return 0.45
    if rate >= 0.40:
        return 0.55
    return 0.72


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, value))


def _round(value: float) -> float:
    return round(value, 6)
