from __future__ import annotations

from dataclasses import dataclass

from ctxlayer.utils import sha256_text


@dataclass(frozen=True)
class RuleEvidence:
    path: str
    evidence_kind: str
    text: str
    line_start: int | None = None
    line_end: int | None = None
    symbol_identity_id: str | None = None

    @property
    def evidence_hash(self) -> str:
        return sha256_text(self.text)


@dataclass(frozen=True)
class RuleCandidate:
    text: str
    source_type: str
    confidence: float
    evidence: list[RuleEvidence]
