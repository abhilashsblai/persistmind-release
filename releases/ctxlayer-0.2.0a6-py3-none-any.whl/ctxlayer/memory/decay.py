from __future__ import annotations


def decayed_confidence(confidence: float, age_days: int) -> float:
    return round(max(0.1, confidence * (0.995**age_days)), 4)
