def event(name: str, data: str) -> str:
    return f"event: {name}\ndata: {data}\n\n"
