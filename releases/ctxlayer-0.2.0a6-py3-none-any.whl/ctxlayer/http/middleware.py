"""HTTP middleware hooks live here for future ASGI deployment."""
