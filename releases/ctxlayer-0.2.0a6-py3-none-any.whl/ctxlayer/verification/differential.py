from __future__ import annotations

from typing import Any, Callable, Iterable

# Differential / behavioral checking: passing the existing suite does NOT mean a patch is
# behavior-preserving where it should be. PatchDiff found ~30% of test-passing patches are
# behaviorally divergent. For pure functions we can run the pre- and post-change versions on
# the same inputs and flag divergence — a stronger signal than path-membership check-diff.

_SENTINEL = object()


def _eval_function(source: str, func_name: str) -> Callable[..., Any] | None:
    namespace: dict[str, Any] = {}
    try:
        exec(compile(source, f"<diff:{func_name}>", "exec"), namespace)  # noqa: S102
    except Exception:  # noqa: BLE001
        return None
    func = namespace.get(func_name)
    return func if callable(func) else None


def differential_check(
    *,
    old_source: str,
    new_source: str,
    func_name: str,
    sample_args: Iterable[tuple],
) -> dict[str, Any]:
    """Compare outputs of ``func_name`` across two source versions on the same inputs.

    Returns ``{"ok": bool, "divergences": [...]}``. ``ok`` is True when behavior matches on
    all sampled inputs (or the function could not be evaluated, which is reported separately).
    """
    old_func = _eval_function(old_source, func_name)
    new_func = _eval_function(new_source, func_name)
    if old_func is None or new_func is None:
        return {
            "ok": True,
            "reason": "function_not_evaluable",
            "evaluable": {"old": old_func is not None, "new": new_func is not None},
            "divergences": [],
        }
    divergences: list[dict[str, Any]] = []
    samples = 0
    for args in sample_args:
        samples += 1
        old_out = _call(old_func, args)
        new_out = _call(new_func, args)
        if old_out != new_out:
            divergences.append(
                {
                    "args": repr(args),
                    "old": _safe_repr(old_out),
                    "new": _safe_repr(new_out),
                }
            )
    return {
        "ok": not divergences,
        "reason": "behavior_preserved" if not divergences else "behavior_diverged",
        "samples": samples,
        "divergences": divergences,
    }


def _call(func: Callable[..., Any], args: tuple) -> Any:
    try:
        return func(*args)
    except Exception as exc:  # noqa: BLE001 — an exception IS an observable behavior
        return ("<raised>", type(exc).__name__)


def _safe_repr(value: Any) -> str:
    try:
        return repr(value)
    except Exception:  # noqa: BLE001
        return "<unreprable>"
