from __future__ import annotations

import fnmatch
import re
from pathlib import Path
from typing import Any

from ctxlayer.config import Settings
from ctxlayer.impact import ImpactEngine
from ctxlayer.snapshot import SnapshotInfo
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import stable_id


DESTRUCTIVE_SQL_RE = re.compile(
    r"\b(DROP\s+TABLE|DROP\s+COLUMN|TRUNCATE|DELETE\s+FROM)\b", re.I
)
PUBLIC_CONTRACT_RE = re.compile(
    r"\b(openapi|swagger|graphql|schema|proto|package\.json)\b", re.I
)


class BehaviorEngine:
    def __init__(
        self,
        repo_root: Path,
        store: SQLiteStore,
        settings: Settings,
        impact: ImpactEngine,
    ):
        self.repo_root = repo_root
        self.store = store
        self.settings = settings
        self.impact = impact

    def check(
        self,
        *,
        snapshot: SnapshotInfo,
        paths: list[str],
        diff: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        normalized = sorted(
            {path.replace("\\", "/").removeprefix("./") for path in paths if path}
        )
        impact_report = self.impact.report(
            snapshot=snapshot, paths=normalized, pack_id=pack_id
        )
        findings: list[dict[str, Any]] = []
        for path in normalized:
            protected = self._protection(snapshot.repo_id, path)
            critical = any(
                fnmatch.fnmatch(path, glob)
                for glob in self.settings.eval.critical_paths
            )
            if critical and protected["score"] == 0:
                findings.append(
                    {
                        "type": "characterization_required",
                        "path": path,
                        "severity": "high",
                        "blocking": True,
                        "reason": "Critical path has no linked test coverage; add a characterization test before editing.",
                    }
                )
            if _looks_like_contract(path):
                findings.append(
                    {
                        "type": "contract_compatibility_review",
                        "path": path,
                        "severity": "medium",
                        "blocking": False,
                        "reason": "Public contract changed; check generated clients and consumers.",
                    }
                )
            if path.endswith(".sql") or "migration" in path.lower():
                text = self._diff_for_path(diff or "", path)
                if DESTRUCTIVE_SQL_RE.search(text):
                    findings.append(
                        {
                            "type": "destructive_migration",
                            "path": path,
                            "severity": "critical",
                            "blocking": True,
                            "reason": "Migration contains destructive SQL and requires explicit approval.",
                        }
                    )
        score_components = {
            "impact": impact_report["risk"]["score"],
            "findings": sum(3 if item["blocking"] else 1 for item in findings),
            "critical_paths": len(impact_report["risk"].get("critical_paths", [])) * 2,
        }
        risk_score = min(10.0, round(sum(score_components.values()), 2))
        return {
            "ok": not any(item["blocking"] for item in findings),
            "schema_version": "ctxlayer.behavior_report.v1",
            "behavior_report_id": stable_id(
                snapshot.snapshot_id, normalized, diff or ""
            ),
            "snapshot_id": snapshot.snapshot_id,
            "input_paths": normalized,
            "risk": {"score": risk_score, "components": score_components},
            "protection": [
                self._protection(snapshot.repo_id, path) for path in normalized
            ],
            "findings": findings,
            "impact_report": impact_report,
        }

    def anomaly(self, *, session_id: str) -> float:
        events = self.store.agent_session_events(session_id)
        if not events:
            return 0.0
        writes = 0
        reads = 0
        tests = 0
        targets: set[str] = set()
        for event in events:
            event_type = str(event["event_type"] or "").lower()
            if any(term in event_type for term in ("edit", "write", "apply_patch")):
                writes += 1
            if any(term in event_type for term in ("read", "open", "search")):
                reads += 1
            if any(term in event_type for term in ("test", "pytest", "verify")):
                tests += 1
            targets.update(_payload_paths(event["payload_json"]))
        total = max(1, len(events))
        write_ratio = writes / total
        test_ratio = tests / total
        locality_ratio = min(
            1.0, len({Path(path).parent for path in targets}) / max(1, len(targets))
        )
        anomaly = 0.0
        if write_ratio > 0.65 and test_ratio < 0.15:
            anomaly += 0.45
        if reads == 0 and writes > 0:
            anomaly += 0.25
        anomaly += 0.30 * locality_ratio
        return round(min(1.0, anomaly), 6)

    def _protection(self, repo_id: str, path: str) -> dict[str, Any]:
        tests = []
        for neighbor in self.store.neighbors(
            repo_id=repo_id,
            node_type="file",
            node_id=path,
            kinds=["tests"],
            direction="in",
        ):
            if neighbor.node_type == "file":
                tests.append(
                    {"path": neighbor.node_id, "confidence": neighbor.confidence}
                )
        return {
            "path": path,
            "score": round(
                min(1.0, sum(float(item["confidence"]) for item in tests)), 3
            ),
            "linked_tests": sorted(tests, key=lambda item: item["path"]),
        }

    def _diff_for_path(self, diff: str, path: str) -> str:
        if not diff:
            target = self.repo_root / path
            return (
                target.read_text(encoding="utf-8", errors="replace")
                if target.exists()
                else ""
            )
        chunks = []
        active = False
        for line in diff.splitlines():
            if line.startswith("diff --git "):
                active = f" b/{path}" in line or f" a/{path}" in line
            if active:
                chunks.append(line)
        return "\n".join(chunks)


def _looks_like_contract(path: str) -> bool:
    return bool(PUBLIC_CONTRACT_RE.search(path.replace("\\", "/")))


def _payload_paths(payload_json: str) -> list[str]:
    import json

    try:
        payload = json.loads(payload_json or "{}")
    except json.JSONDecodeError:
        return []
    if not isinstance(payload, dict):
        return []
    paths: list[str] = []
    for key in ("path", "file_path", "filepath", "target_path"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            paths.append(value.replace("\\", "/").lstrip("./"))
    value = payload.get("target_paths") or payload.get("paths")
    if isinstance(value, list):
        paths.extend(str(item).replace("\\", "/").lstrip("./") for item in value)
    return sorted({path for path in paths if path})
