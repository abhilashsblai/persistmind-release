from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from ctxlayer.utils import canonical_json, stable_id, utc_now


class GlobalSkillRegistry:
    """Machine-local, opt-in registry for privacy-safe skill guidance."""

    def __init__(self, db_path: Path | None = None) -> None:
        self.db_path = db_path or Path.home() / ".ctxlayer" / "global" / "skills.db"
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.db_path), timeout=5.0)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA busy_timeout=5000")
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS global_skills (
              global_skill_id TEXT PRIMARY KEY,
              source_repo_id TEXT NOT NULL,
              source_skill_id TEXT NOT NULL,
              name TEXT NOT NULL,
              trigger_signature TEXT NOT NULL,
              guidance_summary TEXT NOT NULL,
              evidence_count INTEGER NOT NULL DEFAULT 0,
              privacy_status TEXT NOT NULL,
              status TEXT NOT NULL DEFAULT 'available',
              created_at TEXT NOT NULL,
              metadata_json TEXT NOT NULL DEFAULT '{}'
            );

            CREATE INDEX IF NOT EXISTS idx_global_skills_trigger
              ON global_skills(trigger_signature, status);
            """
        )

    def upsert(
        self,
        *,
        source_repo_id: str,
        source_skill_id: str,
        name: str,
        trigger_signature: str,
        guidance_summary: str,
        evidence_count: int,
        privacy_status: str,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        global_skill_id = stable_id(
            "global_skill", source_repo_id, source_skill_id, trigger_signature
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO global_skills(
                  global_skill_id, source_repo_id, source_skill_id, name,
                  trigger_signature, guidance_summary, evidence_count,
                  privacy_status, status, created_at, metadata_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'available', ?, ?)
                ON CONFLICT(global_skill_id) DO UPDATE SET
                  name=excluded.name,
                  trigger_signature=excluded.trigger_signature,
                  guidance_summary=excluded.guidance_summary,
                  evidence_count=excluded.evidence_count,
                  privacy_status=excluded.privacy_status,
                  metadata_json=excluded.metadata_json
                """,
                (
                    global_skill_id,
                    source_repo_id,
                    source_skill_id,
                    name,
                    trigger_signature,
                    guidance_summary,
                    evidence_count,
                    privacy_status,
                    utc_now(),
                    canonical_json(metadata or {}),
                ),
            )
        return global_skill_id

    def get(self, global_skill_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM global_skills WHERE global_skill_id = ?",
            (global_skill_id,),
        ).fetchone()

    def list(self, *, limit: int = 100) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM global_skills
            WHERE status = 'available'
            ORDER BY evidence_count DESC, created_at DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
