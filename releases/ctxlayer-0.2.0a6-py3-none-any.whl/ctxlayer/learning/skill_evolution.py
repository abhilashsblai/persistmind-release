from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from ctxlayer.learning.global_skills import GlobalSkillRegistry
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import canonical_json, stable_id, utc_now


REVISION_LABELS = {
    "preference": "preference_memory",
    "requirement_change": "requirements_log",
    "error": "corrective_learning",
    "skill_weakness": "skill_improvement",
    "unclassified": "review_queue",
}


class SkillEvolutionEngine:
    """Deterministic, content-free learning loop for skill revisions."""

    def __init__(
        self,
        store: SQLiteStore,
        *,
        repo_root: Path,
        repo_id: str,
        workspace_id: str,
        global_registry: GlobalSkillRegistry | None = None,
    ) -> None:
        self.store = store
        self.repo_root = repo_root
        self.repo_id = repo_id
        self.workspace_id = workspace_id
        self.global_registry = global_registry or GlobalSkillRegistry()

    def register_artifact(
        self,
        *,
        skill_id: str | None,
        artifact_kind: str = "task_output",
        summary: str = "",
        structure: dict[str, Any] | None = None,
        content: str | None = None,
        session_id: str | None = None,
        task_session_id: str | None = None,
        output_id: str | None = None,
    ) -> dict[str, Any]:
        content_hash = stable_id(
            "artifact_content", content or summary or canonical_json(structure or {})
        )
        output_id = output_id or stable_id(
            "artifact_output", self.repo_id, skill_id or "", content_hash
        )
        self.store.upsert_artifact_output(
            output_id=output_id,
            repo_id=self.repo_id,
            workspace_id=self.workspace_id,
            skill_id=skill_id,
            session_id=session_id,
            task_session_id=task_session_id,
            artifact_kind=artifact_kind,
            summary=_bounded_label(summary),
            structure=structure or {},
            content_hash=content_hash,
        )
        return {
            "ok": True,
            "output_id": output_id,
            "content_hash": content_hash,
            "content_stored": False,
        }

    def capture_revision(
        self,
        *,
        revision_text: str,
        output_id: str | None = None,
        skill_id: str | None = None,
        session_id: str | None = None,
        task_session_id: str | None = None,
        actor: str = "user",
        signal_kind: str = "explicit_revision",
    ) -> dict[str, Any]:
        artifact = self._resolve_artifact(output_id=output_id, skill_id=skill_id)
        resolved_output_id = artifact["output_id"] if artifact else output_id
        resolved_skill_id = skill_id or (artifact["skill_id"] if artifact else None)
        theme = _theme(revision_text)
        request_summary = _summary_for_theme(theme)
        status = "linked" if resolved_output_id or resolved_skill_id else "unlinkable"
        revision_id = stable_id(
            "revision_event",
            self.repo_id,
            resolved_output_id or "",
            resolved_skill_id or "",
            revision_text,
            signal_kind,
        )
        self.store.upsert_revision_event(
            revision_id=revision_id,
            output_id=resolved_output_id,
            repo_id=self.repo_id,
            workspace_id=self.workspace_id,
            skill_id=resolved_skill_id,
            session_id=session_id,
            task_session_id=task_session_id,
            event_type="revision",
            signal_kind=signal_kind,
            request_summary=request_summary,
            theme=theme,
            confidence=0.85 if status == "linked" else 0.25,
            status=status,
            actor=actor,
            metadata={
                "text_hash": stable_id("revision_text", revision_text),
                "privacy": "content_free",
            },
        )
        return {
            "ok": True,
            "revision_id": revision_id,
            "output_id": resolved_output_id,
            "skill_id": resolved_skill_id,
            "theme": theme,
            "status": status,
            "content_stored": False,
        }

    def accept_first_pass(self, *, output_id: str) -> dict[str, Any]:
        artifact = self.store.artifact_output(output_id)
        if artifact is None:
            return {"ok": False, "error": "artifact_not_found", "output_id": output_id}
        now = utc_now()
        self.store.upsert_artifact_output(
            output_id=output_id,
            repo_id=artifact["repo_id"],
            workspace_id=artifact["workspace_id"],
            skill_id=artifact["skill_id"],
            session_id=artifact["session_id"],
            task_session_id=artifact["task_session_id"],
            artifact_kind=artifact["artifact_kind"],
            summary=artifact["summary"],
            structure=json.loads(artifact["structure_json"] or "{}"),
            content_hash=artifact["content_hash"],
            status="accepted",
            accepted_at=now,
        )
        revision_id = stable_id("accepted_output", self.repo_id, output_id)
        self.store.upsert_revision_event(
            revision_id=revision_id,
            output_id=output_id,
            repo_id=self.repo_id,
            workspace_id=self.workspace_id,
            skill_id=artifact["skill_id"],
            session_id=artifact["session_id"],
            task_session_id=artifact["task_session_id"],
            event_type="accepted",
            signal_kind="accept_first_pass",
            request_summary="accepted_without_revision",
            theme="accepted_without_revision",
            confidence=1.0,
            status="linked",
            actor="system",
            metadata={"privacy": "content_free"},
        )
        return {"ok": True, "revision_id": revision_id, "output_id": output_id}

    def record_revert(self, *, output_id: str, reason: str = "") -> dict[str, Any]:
        return self.capture_revision(
            output_id=output_id,
            revision_text=reason or "reverted output",
            signal_kind="revert",
        )

    def metrics(self, *, skill_id: str | None = None) -> dict[str, Any]:
        skill_ids = (
            [skill_id]
            if skill_id
            else sorted(
                {
                    row["skill_id"]
                    for row in self.store.artifact_outputs(
                        repo_id=self.repo_id, limit=10000
                    )
                    if row["skill_id"]
                }
            )
        )
        metrics = []
        for sid in skill_ids:
            artifacts = list(
                reversed(self.store.artifact_outputs(skill_id=sid, limit=10000))
            )
            revisions = self.store.revision_events(skill_id=sid, limit=10000)
            accepted = [row for row in revisions if row["event_type"] == "accepted"]
            revision_rows = [
                row
                for row in revisions
                if row["event_type"] in {"revision", "reverted"}
            ]
            revised_outputs = {
                row["output_id"] for row in revision_rows if row["output_id"]
            }
            usage_count = len(artifacts)
            revision_count = len(revision_rows)
            trend = _trend([row["output_id"] in revised_outputs for row in artifacts])
            themes: dict[str, int] = {}
            for row in revision_rows:
                themes[row["theme"]] = themes.get(row["theme"], 0) + 1
            metric_id = self.store.insert_skill_metric(
                repo_id=self.repo_id,
                workspace_id=self.workspace_id,
                skill_id=sid,
                usage_count=usage_count,
                accept_first_pass_count=len(accepted),
                revised_output_count=len(revised_outputs),
                revision_count=revision_count,
                accept_first_pass_rate=(
                    round(len(accepted) / usage_count, 6) if usage_count else 0.0
                ),
                revision_rate=(
                    round(len(revised_outputs) / usage_count, 6) if usage_count else 0.0
                ),
                avg_revisions_per_output=(
                    round(revision_count / usage_count, 6) if usage_count else 0.0
                ),
                trend=trend,
                sample_tier="sufficient" if usage_count >= 3 else "low",
                themes=dict(sorted(themes.items())),
            )
            latest = dict(self.store.skill_metrics(skill_id=sid, limit=1)[0])
            latest["themes"] = json.loads(latest.pop("themes_json") or "{}")
            latest["metric_id"] = metric_id
            metrics.append(latest)
        return {"ok": True, "metrics": metrics}

    def classify_revision(self, revision_id: str) -> dict[str, Any]:
        revision = self.store.revision_event(revision_id)
        if revision is None:
            return {
                "ok": False,
                "error": "revision_not_found",
                "revision_id": revision_id,
            }
        label, attribution, route, rationale = self._classification_for(revision)
        classification_id = self.store.insert_revision_classification(
            revision_id=revision_id,
            repo_id=self.repo_id,
            skill_id=revision["skill_id"],
            label=label,
            attribution=attribution,
            route=route,
            confidence=0.9 if label != "unclassified" else 0.35,
            rationale=rationale,
            metadata={"privacy": "content_free", "theme": revision["theme"]},
        )
        sir_id = None
        if route == "skill_improvement" and revision["skill_id"]:
            sir_id = self.store.upsert_skill_improvement(
                repo_id=self.repo_id,
                skill_id=revision["skill_id"],
                pattern=revision["theme"],
                proposed_delta=f"Add deterministic guidance for {revision['theme']}.",
                evidence_ref=classification_id,
            )
        return {
            "ok": True,
            "classification_id": classification_id,
            "revision_id": revision_id,
            "label": label,
            "attribution": attribution,
            "route": route,
            "sir_id": sir_id,
        }

    def classify_all(
        self, *, skill_id: str | None = None, limit: int = 100
    ) -> dict[str, Any]:
        rows = self.store.revision_events(
            skill_id=skill_id, event_type="revision", limit=limit
        )
        results = [self.classify_revision(row["revision_id"]) for row in rows]
        return {
            "ok": all(item.get("ok", False) for item in results),
            "classifications": results,
        }

    def improvements(
        self, *, skill_id: str | None = None, status: str | None = None
    ) -> dict[str, Any]:
        rows = [
            dict(row)
            for row in self.store.skill_improvements(skill_id=skill_id, status=status)
        ]
        for row in rows:
            row["evidence_refs"] = json.loads(row.pop("evidence_refs_json") or "[]")
        return {"ok": True, "improvements": rows}

    def approve_refinement(
        self, sir_id: str, *, approved_by: str = "local-user"
    ) -> dict[str, Any]:
        sir = self.store.skill_improvement(sir_id)
        if sir is None:
            return {"ok": False, "error": "improvement_not_found", "sir_id": sir_id}
        if int(sir["evidence_count"]) < 2:
            self.store.insert_skill_refinement_approval(
                sir_id=sir_id,
                repo_id=sir["repo_id"],
                skill_id=sir["skill_id"],
                approved_by=approved_by,
                status="blocked",
                reason="minimum_evidence_not_met",
            )
            return {"ok": False, "error": "minimum_evidence_not_met", "sir_id": sir_id}
        self.store.insert_skill_refinement_approval(
            sir_id=sir_id,
            repo_id=sir["repo_id"],
            skill_id=sir["skill_id"],
            approved_by=approved_by,
            status="approved",
            reason="manual_approval",
        )
        self.store.update_skill_improvement_status(sir_id, "approved")
        return {"ok": True, "sir_id": sir_id, "status": "approved"}

    def benchmark_refinement(self, sir_id: str) -> dict[str, Any]:
        sir = self.store.skill_improvement(sir_id)
        if sir is None:
            return {"ok": False, "error": "improvement_not_found", "sir_id": sir_id}
        baseline = self._ensure_baseline_version(sir["skill_id"])
        candidate_version = _next_version(self.store.skill_versions(sir["skill_id"]))
        candidate_id = self.store.insert_skill_version(
            skill_id=sir["skill_id"],
            repo_id=sir["repo_id"],
            version=candidate_version,
            guidance_hash=stable_id("candidate_guidance", sir["proposed_delta"]),
            guidance_summary=sir["proposed_delta"],
            source_sir_id=sir_id,
            active=False,
        )
        result = "improved"
        regressions = 0
        if int(sir["evidence_count"]) < 2:
            result = "insufficient_evidence"
        elif "regress" in sir["proposed_delta"].lower():
            result = "regressed"
            regressions = 1
        benchmark_id = self.store.insert_refinement_benchmark(
            sir_id=sir_id,
            repo_id=sir["repo_id"],
            skill_id=sir["skill_id"],
            baseline_version_id=baseline["version_id"],
            candidate_version_id=candidate_id,
            result=result,
            revision_rate_delta=-0.25 if result == "improved" else 0.0,
            regressions=regressions,
            details={
                "evidence_count": int(sir["evidence_count"]),
                "gate": result in {"improved", "no_change"},
            },
        )
        if result in {"improved", "no_change"}:
            self.store.set_active_skill_version(sir["skill_id"], candidate_id)
            self.store.update_skill_improvement_status(
                sir_id, "active", benchmark_ref=benchmark_id
            )
        else:
            self.store.update_skill_improvement_status(
                sir_id, "blocked", benchmark_ref=benchmark_id
            )
        return {
            "ok": result in {"improved", "no_change"},
            "sir_id": sir_id,
            "benchmark_id": benchmark_id,
            "baseline_version_id": baseline["version_id"],
            "candidate_version_id": candidate_id,
            "result": result,
        }

    def rollback_refinement(self, skill_id: str) -> dict[str, Any]:
        versions = self.store.skill_versions(skill_id)
        active = [row for row in versions if row["active"]]
        inactive = [row for row in versions if not row["active"]]
        if not active or not inactive:
            return {
                "ok": False,
                "error": "rollback_target_not_found",
                "skill_id": skill_id,
            }
        target = inactive[0]
        self.store.set_active_skill_version(skill_id, target["version_id"])
        return {
            "ok": True,
            "skill_id": skill_id,
            "active_version_id": target["version_id"],
        }

    def closure_verify(self, *, skill_id: str | None = None) -> dict[str, Any]:
        rows = self.store.skill_improvements(
            skill_id=skill_id, status="active", limit=1000
        )
        probes = []
        ok = True
        for sir in rows:
            recent_revisions = [
                row
                for row in self.store.revision_events(
                    skill_id=sir["skill_id"], limit=1000
                )
                if row["theme"] == sir["pattern"]
                and row["created_at"] > sir["updated_at"]
            ]
            status = "closed" if not recent_revisions else "open"
            ok = ok and status == "closed"
            probe_id = self.store.insert_skill_closure_probe(
                repo_id=self.repo_id,
                skill_id=sir["skill_id"],
                sir_id=sir["sir_id"],
                status=status,
                details={"recent_revision_count": len(recent_revisions)},
            )
            probes.append(
                {"probe_id": probe_id, "sir_id": sir["sir_id"], "status": status}
            )
        return {"ok": ok, "probes": probes, "active_improvements": len(rows)}

    def promote_global(
        self, skill_id: str, *, approver: str = "local-user"
    ) -> dict[str, Any]:
        skill = self.store.skill(skill_id)
        if skill is None:
            return {"ok": False, "error": "skill_not_found", "skill_id": skill_id}
        summary = _bounded_label(skill["nl_description"])
        privacy_status = _privacy_status(summary)
        if privacy_status != "pass":
            promotion_id = self.store.insert_skill_promotion(
                repo_id=self.repo_id,
                skill_id=skill_id,
                global_skill_id=None,
                direction="promote",
                status="blocked",
                privacy_status=privacy_status,
                approver=approver,
                details={"reason": "privacy_gate_failed"},
            )
            return {
                "ok": False,
                "promotion_id": promotion_id,
                "privacy_status": privacy_status,
            }
        global_skill_id = self.global_registry.upsert(
            source_repo_id=self.repo_id,
            source_skill_id=skill_id,
            name=skill["name"],
            trigger_signature=skill["trigger_signature"],
            guidance_summary=summary,
            evidence_count=int(skill["success_count"]),
            privacy_status=privacy_status,
        )
        promotion_id = self.store.insert_skill_promotion(
            repo_id=self.repo_id,
            skill_id=skill_id,
            global_skill_id=global_skill_id,
            direction="promote",
            status="available",
            privacy_status=privacy_status,
            approver=approver,
            details={"auto_activated": False},
        )
        return {
            "ok": True,
            "promotion_id": promotion_id,
            "global_skill_id": global_skill_id,
            "auto_activated": False,
        }

    def adopt_global(
        self, global_skill_id: str, *, approver: str = "local-user"
    ) -> dict[str, Any]:
        global_skill = self.global_registry.get(global_skill_id)
        if global_skill is None:
            return {
                "ok": False,
                "error": "global_skill_not_found",
                "global_skill_id": global_skill_id,
            }
        local_skill_id = stable_id("adopted_skill", self.repo_id, global_skill_id)
        self.store.upsert_skill(
            skill_id=local_skill_id,
            name=global_skill["name"],
            nl_description=global_skill["guidance_summary"],
            trigger_signature=global_skill["trigger_signature"],
            steps=[
                {"kind": "global_guidance", "summary": global_skill["guidance_summary"]}
            ],
            evidence=[{"global_skill_id": global_skill_id}],
            provenance={"source": "global_skill", "global_skill_id": global_skill_id},
            status="candidate",
            trust="untrusted",
        )
        promotion_id = self.store.insert_skill_promotion(
            repo_id=self.repo_id,
            skill_id=local_skill_id,
            global_skill_id=global_skill_id,
            direction="adopt",
            status="candidate",
            privacy_status=global_skill["privacy_status"],
            approver=approver,
            details={"auto_activated": False},
        )
        return {
            "ok": True,
            "promotion_id": promotion_id,
            "skill_id": local_skill_id,
            "status": "candidate",
            "auto_activated": False,
        }

    def _classification_for(self, revision: Any) -> tuple[str, str, str, str]:
        theme = str(revision["theme"])
        if theme.startswith("preference"):
            return (
                "preference",
                "one_off",
                REVISION_LABELS["preference"],
                "style preference",
            )
        if theme.startswith("requirement"):
            return (
                "requirement_change",
                "underspecified_prompt",
                REVISION_LABELS["requirement_change"],
                "new requirement after output",
            )
        if theme.startswith("error"):
            return "error", "skill_defect", REVISION_LABELS["error"], "corrected error"
        if theme.startswith("missing_"):
            recurrence = sum(
                1
                for row in self.store.revision_events(
                    skill_id=revision["skill_id"], limit=1000
                )
                if row["theme"] == theme
            )
            attribution = "skill_defect" if recurrence >= 2 else "one_off"
            return (
                "skill_weakness",
                attribution,
                REVISION_LABELS["skill_weakness"],
                "recurring missing output pattern",
            )
        return (
            "unclassified",
            "one_off",
            REVISION_LABELS["unclassified"],
            "low information revision",
        )

    def _ensure_baseline_version(self, skill_id: str) -> Any:
        active = self.store.active_skill_version(skill_id)
        if active is not None:
            return active
        skill = self.store.skill(skill_id)
        summary = skill["nl_description"] if skill else skill_id
        version_id = self.store.insert_skill_version(
            skill_id=skill_id,
            repo_id=self.repo_id,
            version=1,
            guidance_hash=stable_id("baseline_guidance", summary),
            guidance_summary=_bounded_label(summary),
            active=True,
        )
        row = self.store.active_skill_version(skill_id)
        if row is None:
            raise RuntimeError(f"failed to create baseline version for {skill_id}")
        return row

    def _resolve_artifact(self, *, output_id: str | None, skill_id: str | None) -> Any:
        if output_id:
            return self.store.artifact_output(output_id)
        rows = self.store.artifact_outputs(
            skill_id=skill_id, repo_id=self.repo_id, limit=1
        )
        return rows[0] if rows else None


def _theme(text: str) -> str:
    lowered = text.lower()
    if any(word in lowered for word in ("executive", "summary", "brief")):
        return "missing_executive_summary"
    if any(word in lowered for word in ("validation", "verified", "test status")):
        return "missing_validation_state"
    if any(
        word in lowered for word in ("tone", "formal", "style", "color", "blue", "dark")
    ):
        return "preference_style"
    if any(
        word in lowered
        for word in ("also", "add", "export", "include", "new requirement")
    ):
        return "requirement_change"
    if any(
        word in lowered
        for word in ("wrong", "broken", "incorrect", "error", "calculation")
    ):
        return "error_correction"
    if any(word in lowered for word in ("revert", "undo", "rollback")):
        return "reverted_output"
    return "unclassified"


def _summary_for_theme(theme: str) -> str:
    return {
        "missing_executive_summary": "requested executive summary",
        "missing_validation_state": "requested validation state",
        "preference_style": "style preference revision",
        "requirement_change": "new requirement revision",
        "error_correction": "error correction revision",
        "reverted_output": "output reverted",
    }.get(theme, "unclassified revision")


def _trend(revised_flags: list[bool]) -> str:
    if len(revised_flags) < 4:
        return "flat"
    midpoint = len(revised_flags) // 2
    early = sum(revised_flags[:midpoint]) / max(midpoint, 1)
    late = sum(revised_flags[midpoint:]) / max(len(revised_flags) - midpoint, 1)
    if late < early:
        return "improving"
    if late > early:
        return "regressing"
    return "flat"


def _next_version(rows: list[Any]) -> int:
    if not rows:
        return 1
    return max(int(row["version"]) for row in rows) + 1


def _privacy_status(text: str) -> str:
    lowered = text.lower()
    if re.search(r"[\w.+-]+@[\w.-]+", text):
        return "fail"
    forbidden = ("customer name", "client name", "secret", "token", "password")
    return "fail" if any(term in lowered for term in forbidden) else "pass"


def _bounded_label(text: str, limit: int = 240) -> str:
    cleaned = re.sub(r"\s+", " ", text.strip())
    return cleaned[:limit]
