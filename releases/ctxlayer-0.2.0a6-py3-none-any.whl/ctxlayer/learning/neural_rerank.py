from __future__ import annotations

from typing import Any

# Code-specific neural reranker over the fused top-K. The 2024-2026 SOTA adds a trained
# cross-encoder / listwise code reranker on top of fusion (CodeRankLLM, arXiv:2412.01007;
# SWERank, arXiv:2505.07849) rather than relying on fusion-rank order alone. This is an opt-in
# heavy extra: when no cross-encoder is installed it gracefully no-ops (returns input order).
#
# Invariant preserved: this reranker is ORDER-ONLY over the deterministic candidate pool — it
# reorders the exact same items and never adds or removes any, matching BoundedReranker.


def cross_encoder_available(model_name: str) -> bool:
    try:
        from sentence_transformers import CrossEncoder  # noqa: F401
    except Exception:  # noqa: BLE001
        return False
    return bool(model_name)


class NeuralReranker:
    def __init__(self, *, model_name: str = "", top_k: int = 50):
        self.model_name = model_name
        self.top_k = max(1, int(top_k))
        self._model = None

    def _load(self) -> bool:
        if self._model is not None:
            return True
        if not cross_encoder_available(self.model_name):
            return False
        from sentence_transformers import CrossEncoder

        self._model = CrossEncoder(self.model_name)
        return True

    def rerank(self, *, task: str, candidates: list[dict[str, Any]]) -> dict[str, Any]:
        """Reorder ``candidates`` by cross-encoder relevance to ``task`` (order-only).

        Returns the (possibly reordered) candidates plus a status. Only the top_k window is
        reranked; the tail keeps its fused order. If the model is unavailable, the input order
        is returned unchanged so callers can always rely on a valid permutation.
        """
        if not candidates:
            return {"ok": True, "status": "empty", "candidates": candidates}
        original_ids = _ids(candidates)
        if not self._load():
            return {
                "ok": True,
                "status": "model_unavailable_fallback",
                "candidates": candidates,
            }
        head = candidates[: self.top_k]
        tail = candidates[self.top_k :]
        pairs = [
            (task, str(item.get("text") or item.get("path") or "")) for item in head
        ]
        scores = self._model.predict(pairs)
        ordered_head = [
            item
            for _score, item in sorted(
                zip(scores, head, strict=False),
                key=lambda pair: float(pair[0]),
                reverse=True,
            )
        ]
        reranked = [*ordered_head, *tail]
        # Safety: never add/remove items. If the permutation is not exact, fall back.
        if _ids(reranked) != sorted(original_ids):
            return {
                "ok": True,
                "status": "permutation_guard_fallback",
                "candidates": candidates,
            }
        return {
            "ok": True,
            "status": "reranked",
            "candidates": reranked,
            "window": len(head),
        }


def _ids(candidates: list[dict[str, Any]]) -> list[str]:
    # Stable, position-independent identity so the permutation guard only fires when items are
    # genuinely added/removed — not merely reordered.
    out: list[str] = []
    for item in candidates:
        out.append(
            str(
                item.get("id")
                or f"{item.get('path')}:{item.get('start_line')}:{item.get('end_line')}"
            )
        )
    return sorted(out)
