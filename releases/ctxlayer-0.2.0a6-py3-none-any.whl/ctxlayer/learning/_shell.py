from __future__ import annotations

import os
import shlex
import subprocess
from pathlib import Path
from typing import Any


def run_shell(
    command: str | None,
    *,
    cwd: Path,
    timeout: int,
    env: dict[str, str] | None = None,
) -> dict[str, Any]:
    if not command:
        return {
            "command": "",
            "exit_code": 0,
            "timed_out": False,
            "stdout": "",
            "stderr": "",
        }
    try:
        result = subprocess.run(
            command,
            cwd=cwd,
            shell=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            env=env,
            check=False,
        )
        return {
            "command": command,
            "exit_code": result.returncode,
            "timed_out": False,
            "stdout": trim(result.stdout),
            "stderr": trim(result.stderr),
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "command": command,
            "exit_code": 124,
            "timed_out": True,
            "stdout": trim(exc.stdout or ""),
            "stderr": trim(exc.stderr or ""),
        }


def format_command(command: str, values: dict[str, str]) -> str:
    quoted = {key: shell_quote(value) for key, value in values.items()}
    return command.format_map(_DefaultFormatMap(quoted))


def shell_quote(value: str) -> str:
    if os.name == "nt":
        return subprocess.list2cmdline([value])
    return shlex.quote(value)


def trim(value: str | bytes, limit: int = 4000) -> str:
    if isinstance(value, bytes):
        value = value.decode("utf-8", errors="replace")
    if len(value) <= limit:
        return value
    return value[:limit] + "\n...[truncated]"


class _DefaultFormatMap(dict[str, str]):
    def __missing__(self, key: str) -> str:
        return "{" + key + "}"
