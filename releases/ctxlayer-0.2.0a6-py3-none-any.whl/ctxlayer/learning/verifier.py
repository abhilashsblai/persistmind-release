from __future__ import annotations

from typing import Any, Iterable, Mapping

# Heuristic process-reward (PRM) trajectory verifier. Outcome-only gates (final pass/fail)
# give sparse signal; scoring each step by "progress toward goal" enables best-of-N candidate
# selection in repair and denser signal for the optimizer (AgentPRM, arXiv:2511.08325). We use
# a Monte-Carlo/heuristic PRM rather than a learned one because learned PRMs are more
# susceptible to reward hacking — important since CTX self-optimizes (GRPO-as-PRM,
# arXiv:2509.21154). Trajectory score = MIN over step scores (a dead-end step caps the whole
# trajectory), which is the standard process-verifier aggregation.

# Step kinds and their default progress contribution in [0, 1]. Higher = more progress.
_STEP_SIGNALS: dict[str, float] = {
    "test_pass": 1.0,
    "check_diff_clean": 0.9,
    "impact_low_risk": 0.8,
    "edit_in_scope": 0.7,
    "edit_out_of_scope": 0.3,
    "test_fail": 0.1,
    "error": 0.0,
}


def step_score(step: Mapping[str, Any]) -> float:
    """Progress score for a single trajectory step.

    Honors an explicit ``progress`` field in [0, 1] if present; otherwise maps ``kind`` via
    the default signal table; unknown kinds score a neutral 0.5.
    """
    progress = step.get("progress")
    if isinstance(progress, (int, float)) and not isinstance(progress, bool):
        return max(0.0, min(1.0, float(progress)))
    return _STEP_SIGNALS.get(str(step.get("kind") or ""), 0.5)


def score_trajectory(steps: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    """Score a full trajectory. Trajectory score = min over step scores (process verifier)."""
    scores = [step_score(step) for step in steps]
    if not scores:
        return {"score": 0.0, "min_step": 0.0, "mean_step": 0.0, "steps": 0}
    return {
        "score": round(min(scores), 6),
        "min_step": round(min(scores), 6),
        "mean_step": round(sum(scores) / len(scores), 6),
        "steps": len(scores),
    }


def select_best_of_n(candidates: list[Mapping[str, Any]]) -> dict[str, Any]:
    """Pick the best repair/solution candidate by trajectory score.

    Each candidate must carry a ``steps`` list. Ties broken by mean step score then index for
    determinism. Returns the winning candidate annotated with its trajectory verdict.
    """
    scored: list[dict[str, Any]] = []
    for index, candidate in enumerate(candidates):
        verdict = score_trajectory(candidate.get("steps", []))
        scored.append({"index": index, "candidate": candidate, "trajectory": verdict})
    if not scored:
        return {"ok": False, "reason": "no_candidates", "ranked": []}
    scored.sort(
        key=lambda item: (
            -item["trajectory"]["score"],
            -item["trajectory"]["mean_step"],
            item["index"],
        )
    )
    return {"ok": True, "best": scored[0], "ranked": scored}


# ----- Ask-or-assume / abstention gate -------------------------------------------------------

# A coding agent that always completes autonomously will guess when context is insufficient.
# A collaborator monitors uncertainty and asks (Ask-or-Assume, arXiv:2603.26233). Low
# confidence must CHANGE behavior, not just be logged (RiskEval, arXiv:2601.07767).

_EDIT_SCOPE_RANK: dict[str, float] = {
    "seeded": 1.0,
    "partial_seed": 0.5,
    "unseeded": 0.2,
}


def context_sufficiency(
    *,
    edit_scope_confidence: str,
    retrieval_confidence: float,
    risk_score: float,
    low_confidence_flag: bool = False,
    proceed_threshold: float = 0.6,
    abstain_threshold: float = 0.3,
    risk_ceiling: float = 8.0,
) -> dict[str, Any]:
    """Decide whether the agent should proceed, ask for a seed/clarification, or abstain.

    Combines edit-scope confidence (from pack ``seed_coverage``), retrieval confidence (top
    item score), and impact risk. Returns a decision plus an actionable next step.
    """
    scope = _EDIT_SCOPE_RANK.get(str(edit_scope_confidence), 0.2)
    retrieval = max(0.0, min(1.0, float(retrieval_confidence)))
    risk = max(0.0, float(risk_score))
    # Risk erodes confidence; normalize risk to [0,1] against a 10-point scale.
    risk_penalty = min(1.0, risk / 10.0)
    sufficiency = round(((scope + retrieval) / 2.0) * (1.0 - 0.5 * risk_penalty), 6)
    if low_confidence_flag:
        sufficiency = round(sufficiency * 0.7, 6)

    if risk >= risk_ceiling and scope < 1.0:
        decision = "abstain"
        action = (
            "High risk without full seed coverage — escalate to a human before editing."
        )
    elif sufficiency >= proceed_threshold:
        decision = "proceed"
        action = "Context is sufficient; proceed with the edit."
    elif sufficiency <= abstain_threshold:
        decision = "abstain"
        action = "Context is insufficient; abstain and escalate or widen retrieval before acting."
    else:
        decision = "ask"
        action = (
            "Ask for a seed path or clarification, or widen retrieval, before editing."
        )
    return {
        "decision": decision,
        "sufficiency": sufficiency,
        "action": action,
        "signals": {
            "edit_scope_confidence": edit_scope_confidence,
            "scope_rank": scope,
            "retrieval_confidence": retrieval,
            "risk_score": risk,
            "low_confidence_flag": low_confidence_flag,
        },
    }
