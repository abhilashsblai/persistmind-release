from __future__ import annotations

import os


def token(name: str) -> str | None:
    return os.environ.get(name)
