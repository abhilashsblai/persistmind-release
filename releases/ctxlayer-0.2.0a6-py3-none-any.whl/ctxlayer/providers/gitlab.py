from __future__ import annotations

from ctxlayer.eval.providers import fetch_provider_prs
from ctxlayer.providers.base import HarvestedTask


def harvest(project: str, limit: int = 200) -> list[HarvestedTask]:
    prs = fetch_provider_prs("gitlab", project, limit)
    return [
        HarvestedTask("gitlab", sha, pr.title, pr.body, pr.merge_commit_sha)
        for sha, pr in sorted(prs.items())
    ]
