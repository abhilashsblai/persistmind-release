from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping, Protocol


@dataclass(frozen=True)
class ConnectorItem:
    source_ref: str
    raw_text: str
    authored_at: str | None = None
    author: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class Connector(Protocol):
    kind: str

    def is_local_first(self) -> bool: ...

    def fetch(
        self, *, since: str | None, config: Mapping[str, Any]
    ) -> Iterable[ConnectorItem]: ...


def load_json_items(path: Path, *, text_keys: tuple[str, ...]) -> list[ConnectorItem]:
    data = json.loads(path.read_text(encoding="utf-8"))
    rows = (
        data
        if isinstance(data, list)
        else data.get("items") or data.get("messages") or []
    )
    items: list[ConnectorItem] = []
    for idx, row in enumerate(rows):
        if not isinstance(row, dict):
            continue
        raw = ""
        for key in text_keys:
            if row.get(key):
                raw = str(row[key])
                break
        if not raw:
            continue
        items.append(
            ConnectorItem(
                source_ref=str(
                    row.get("source_ref")
                    or row.get("permalink")
                    or row.get("id")
                    or f"{path}:{idx}"
                ),
                raw_text=raw,
                authored_at=row.get("authored_at")
                or row.get("ts")
                or row.get("created_at"),
                author=row.get("author") or row.get("user") or row.get("from"),
                metadata={
                    key: value
                    for key, value in row.items()
                    if key not in set(text_keys)
                },
            )
        )
    return items


def load_text_files(folder: Path, *, suffixes: tuple[str, ...]) -> list[ConnectorItem]:
    paths = [folder] if folder.is_file() else sorted(folder.rglob("*"))
    items: list[ConnectorItem] = []
    for path in paths:
        if not path.is_file() or path.suffix.lower() not in suffixes:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if not text.strip():
            continue
        items.append(
            ConnectorItem(
                source_ref=path.as_posix(),
                raw_text=text,
                authored_at=None,
                author=None,
                metadata={"path": path.as_posix()},
            )
        )
    return items
