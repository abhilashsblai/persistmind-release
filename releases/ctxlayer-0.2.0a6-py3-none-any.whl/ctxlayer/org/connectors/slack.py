from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable, Mapping

from ctxlayer.org.connector import ConnectorItem, load_json_items


class SlackExportConnector:
    kind = "slack"

    def is_local_first(self) -> bool:
        return True

    def fetch(
        self, *, since: str | None, config: Mapping[str, Any]
    ) -> Iterable[ConnectorItem]:
        _ = since
        path = Path(str(config.get("path") or config.get("file") or "slack.json"))
        return load_json_items(path, text_keys=("text", "message", "body"))
