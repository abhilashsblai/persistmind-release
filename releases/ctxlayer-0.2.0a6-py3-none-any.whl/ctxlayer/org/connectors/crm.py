from __future__ import annotations

import csv
from pathlib import Path
from typing import Any, Iterable, Mapping

from ctxlayer.org.connector import ConnectorItem, load_json_items


class CrmExportConnector:
    kind = "crm"

    def is_local_first(self) -> bool:
        return True

    def fetch(
        self, *, since: str | None, config: Mapping[str, Any]
    ) -> Iterable[ConnectorItem]:
        _ = since
        path = Path(str(config.get("path") or config.get("file") or "crm.json"))
        if path.suffix.lower() == ".json":
            return load_json_items(
                path, text_keys=("note", "text", "message", "description")
            )
        items: list[ConnectorItem] = []
        with path.open(newline="", encoding="utf-8") as handle:
            for idx, row in enumerate(csv.DictReader(handle)):
                raw = row.get("note") or row.get("text") or row.get("description") or ""
                if not raw:
                    continue
                items.append(
                    ConnectorItem(
                        source_ref=str(
                            row.get("source_ref") or row.get("id") or f"{path}:{idx}"
                        ),
                        raw_text=raw,
                        authored_at=row.get("authored_at") or row.get("created_at"),
                        author=row.get("owner") or row.get("author"),
                        metadata=dict(row),
                    )
                )
        return items
