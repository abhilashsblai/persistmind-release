from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

from ctxlayer.audit import AuditLog
from ctxlayer.config import Settings
from ctxlayer.impact import ImpactEngine
from ctxlayer.intent import artifact
from ctxlayer.intent.decomposition import build_skeleton
from ctxlayer.intent.evidence import collect_evidence
from ctxlayer.intent.goals import derive_goals
from ctxlayer.intent.proposer import propose
from ctxlayer.intent.rootcause import rank_hypotheses
from ctxlayer.intent.stakeholders import map_stakeholders
from ctxlayer.snapshot import SnapshotInfo
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import stable_id, utc_now

EventLogger = Callable[[str, str, str | None, dict[str, Any]], None]


class IntentEngine:
    def __init__(
        self,
        repo_root: Path,
        store: SQLiteStore,
        settings: Settings,
        impact: ImpactEngine,
        audit: AuditLog,
        *,
        workspace_id: str,
        event_logger: EventLogger | None = None,
    ):
        self.repo_root = repo_root
        self.store = store
        self.settings = settings
        self.impact = impact
        self.audit = audit
        self.workspace_id = workspace_id
        self.event_logger = event_logger

    def start(
        self, *, problem: str, snapshot: SnapshotInfo, llm_propose: bool = False
    ) -> dict[str, Any]:
        normalized = artifact.normalize_problem(problem)
        p_hash = artifact.problem_text_hash(normalized)
        intent_id = stable_id(
            self.workspace_id, snapshot.repo_id, p_hash, snapshot.snapshot_id
        )
        existing = self.store.intent(intent_id)
        created_at = existing["created_at"] if existing else utc_now()
        evidence = collect_evidence(
            repo_root=self.repo_root,
            store=self.store,
            snapshot=snapshot,
            intent_id=intent_id,
            problem=normalized,
        )
        nodes = build_skeleton(
            intent_id=intent_id, problem=normalized, evidence=evidence
        )
        s_hash = artifact.skeleton_hash(nodes)
        hypotheses = rank_hypotheses(
            store=self.store,
            impact=self.impact,
            snapshot=snapshot,
            intent_id=intent_id,
            problem=normalized,
            evidence=evidence,
        )
        stakeholders = map_stakeholders(
            repo_root=self.repo_root,
            store=self.store,
            repo_id=snapshot.repo_id,
            intent_id=intent_id,
            evidence=evidence,
        )
        goals, questions = derive_goals(
            intent_id=intent_id,
            problem=normalized,
            evidence=evidence,
            hypotheses=hypotheses,
        )
        contradictions: list[dict[str, Any]] = []
        if llm_propose:
            proposed = propose(intent_id=intent_id, problem=normalized)
            nodes.extend(proposed["nodes"])
            hypotheses.extend(proposed["hypotheses"])
            goals.extend(proposed["goals"])
        header = {
            "intent_id": intent_id,
            "workspace_id": self.workspace_id,
            "repo_id": snapshot.repo_id,
            "snapshot_id": snapshot.snapshot_id,
            "problem_statement": normalized,
            "problem_text_hash": p_hash,
            "skeleton_hash": s_hash,
            "status": existing["status"] if existing else "draft",
            "selected_goal_id": existing["selected_goal_id"] if existing else None,
            "created_at": created_at,
            "updated_at": utc_now(),
            "metadata": {"llm_propose": bool(llm_propose)},
            "event": "intent_start",
        }
        audit_record = self.audit.record_intent(header)
        header["audit_hash"] = audit_record["row_hash"]
        header["prev_audit_hash"] = audit_record["prev_hash"]
        self.store.write_intent(
            header=header,
            evidence=evidence,
            nodes=nodes,
            hypotheses=hypotheses,
            stakeholders=stakeholders,
            contradictions=contradictions,
            candidate_goals=goals,
            open_questions=questions,
        )
        self._event(
            "intent_start",
            intent_id,
            {"snapshot_id": snapshot.snapshot_id, "llm_propose": llm_propose},
        )
        return self.show(intent_id)

    def show(self, intent_id: str) -> dict[str, Any]:
        return artifact.to_view(
            self.store.intent(intent_id),
            evidence=self.store.intent_evidence(intent_id),
            nodes=self.store.intent_nodes(intent_id),
            hypotheses=self.store.intent_hypotheses(intent_id),
            stakeholders=self.store.intent_stakeholders(intent_id),
            contradictions=self.store.intent_contradictions(intent_id),
            candidate_goals=self.store.intent_candidate_goals(intent_id),
            open_questions=self.store.intent_open_questions(intent_id),
        )

    def list(
        self, *, repo_id: str | None = None, status: str | None = None, limit: int = 50
    ) -> dict[str, Any]:
        rows = [
            dict(row)
            for row in self.store.list_intents(
                repo_id=repo_id, status=status, limit=limit
            )
        ]
        return {"ok": True, "count": len(rows), "intents": rows}

    def refine(
        self,
        *,
        intent_id: str,
        evidence: list[str] | None = None,
        select_goal: str | None = None,
    ) -> dict[str, Any]:
        header = self.store.intent(intent_id)
        if header is None:
            raise KeyError(f"intent not found: {intent_id}")
        selected = select_goal or header["selected_goal_id"]
        if selected:
            goal = self.store.intent_goal(selected)
            if goal is None or goal["intent_id"] != intent_id:
                raise ValueError(f"goal does not belong to intent: {selected}")
            audit_record = self.audit.record_intent(
                {
                    "intent_id": intent_id,
                    "snapshot_id": header["snapshot_id"],
                    "problem_text_hash": header["problem_text_hash"],
                    "skeleton_hash": header["skeleton_hash"],
                    "selected_goal_id": selected,
                    "event": "intent_goal_selected",
                }
            )
            self.store.set_intent_selected_goal(
                intent_id=intent_id,
                goal_id=selected,
                status="refined",
                audit_hash=audit_record["row_hash"],
                prev_audit_hash=audit_record["prev_hash"],
            )
            self._event("intent_goal_selected", intent_id, {"goal_id": selected})
        if evidence:
            self._event("intent_refine", intent_id, {"evidence": sorted(evidence)})
        return self.show(intent_id)

    def seed_for_pack(
        self, *, intent_id: str, goal_id: str | None = None
    ) -> dict[str, Any]:
        view = self.show(intent_id)
        selected_goal_id = goal_id or view.get("selected_goal_id")
        if not selected_goal_id:
            deterministic_goals = [
                row
                for row in view["candidate_goals"]
                if row.get("origin") == "deterministic"
            ]
            if not deterministic_goals:
                raise ValueError(f"intent has no candidate goals: {intent_id}")
            selected_goal_id = deterministic_goals[0]["goal_id"]
            self.refine(intent_id=intent_id, select_goal=selected_goal_id)
            view = self.show(intent_id)
        goals = {row["goal_id"]: row for row in view["candidate_goals"]}
        if selected_goal_id not in goals:
            raise ValueError(f"goal does not belong to intent: {selected_goal_id}")
        paths = sorted({row["path"] for row in view["evidence"] if row.get("path")})
        return {
            "intent_id": intent_id,
            "goal_id": selected_goal_id,
            "task": goals[selected_goal_id]["statement"],
            "seed_paths": paths,
            "snapshot_id": view["snapshot_id"],
            "goal": goals[selected_goal_id],
        }

    def _event(self, kind: str, ref: str, payload: dict[str, Any]) -> None:
        if self.event_logger is not None:
            self.event_logger("A1", kind, ref, payload)
