from __future__ import annotations

from ctxlayer.cie.contracts import CognitiveDebtRecord, RootCauseRecord, deterministic_id


def score_cognitive_debt(
    target_id: str,
    *,
    target_type: str = "root_cause",
    severity: float = 1.0,
    recurrence: float = 1.0,
    correction_cost: float = 1.0,
    user_dissatisfaction: float = 1.0,
    rollback_effort: float = 1.0,
    blast_radius: float = 1.0,
    evidence_refs: list[str] | None = None,
) -> CognitiveDebtRecord:
    score = severity * recurrence * (correction_cost + user_dissatisfaction + rollback_effort + blast_radius)
    return CognitiveDebtRecord(
        debt_id=deterministic_id("debt", target_type, target_id, score),
        target_id=target_id,
        target_type=target_type,
        score=round(float(score), 3),
        severity=severity,
        recurrence=recurrence,
        correction_cost=correction_cost,
        user_dissatisfaction=user_dissatisfaction,
        rollback_effort=rollback_effort,
        blast_radius=blast_radius,
        evidence_refs=evidence_refs or [],
    )


def debt_for_root_causes(root_causes: list[RootCauseRecord]) -> list[CognitiveDebtRecord]:
    debts: list[CognitiveDebtRecord] = []
    for root in root_causes:
        severity = 4.0 if root.category in {"security", "selfmod_safety"} else 2.0
        debts.append(
            score_cognitive_debt(
                root.root_cause_id,
                severity=severity,
                recurrence=max(1.0, float(root.recurrence_count)),
                correction_cost=2.0,
                user_dissatisfaction=2.0,
                rollback_effort=1.0,
                blast_radius=3.0 if root.category in {"security", "surface_parity"} else 1.0,
                evidence_refs=root.evidence_refs,
            )
        )
    return sorted(debts, key=lambda item: item.score, reverse=True)
