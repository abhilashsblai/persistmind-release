from __future__ import annotations

FAILURE_CATEGORIES: tuple[str, ...] = (
    "context_selection",
    "impact_prediction",
    "memory_quality",
    "skill_quality",
    "loop_closure",
    "eval_regression",
    "selfmod_safety",
    "security",
    "goal_alignment",
    "surface_parity",
    "system_health",
    "requirement_analysis",
    "verification_gap",
    "execution_discipline",
)

_ALIASES = {
    "context": "context_selection",
    "scope": "context_selection",
    "impact": "impact_prediction",
    "test": "verification_gap",
    "tests": "verification_gap",
    "verification": "verification_gap",
    "security_scan": "security",
    "secret": "security",
    "policy": "security",
    "selfmod": "selfmod_safety",
    "benchmark": "eval_regression",
    "canary": "eval_regression",
    "dashboard": "surface_parity",
    "http": "surface_parity",
    "mcp": "surface_parity",
}

_DESCRIPTIONS = {
    "context_selection": "Wrong, missing, stale, or excessive context selection.",
    "impact_prediction": "Changed-file impact, test selection, or blast-radius prediction weakness.",
    "memory_quality": "Stale, conflicting, untrusted, or poorly recalled memory.",
    "skill_quality": "Skill trigger, replay, applicability, or maintenance weakness.",
    "loop_closure": "A repeated issue did not affect later behavior.",
    "eval_regression": "Benchmark, holdout, canary, or scorecard regression.",
    "selfmod_safety": "Self-modification validation, allowlist, judge, or approval failure.",
    "security": "Secret, PII, prompt-injection, policy, or redaction risk.",
    "goal_alignment": "Wrong goal, unclear success metric, or unhandled challenge.",
    "surface_parity": "CLI, MCP, HTTP, dashboard, or rollup behavior drift.",
    "system_health": "Audit, snapshot, staleness, concurrency, or storage health issue.",
    "requirement_analysis": "Missed acceptance criteria, edge cases, or requirement details.",
    "verification_gap": "Testing, browser validation, screenshot, or local proof gap.",
    "execution_discipline": "Skipped plan, checkpoint, sequencing, or premature completion.",
}


def normalize_failure_category(value: str) -> str:
    token = "_".join(str(value or "").strip().lower().replace("-", "_").split())
    if token in FAILURE_CATEGORIES:
        return token
    if token in _ALIASES:
        return _ALIASES[token]
    for key, category in _ALIASES.items():
        if key and key in token:
            return category
    return "system_health"


def is_known_failure_category(value: str) -> bool:
    return normalize_failure_category(value) == str(value or "").strip().lower().replace("-", "_")


def failure_category_descriptions() -> dict[str, str]:
    return dict(_DESCRIPTIONS)
