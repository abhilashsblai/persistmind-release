from __future__ import annotations

from ctxlayer.cie.contracts import ConfidenceCalibrationRecord, deterministic_id


def calibrate_confidence(task_type: str, complexity_band: str, *, sample_count: int = 0, success_count: int = 0, agent_profile_id: str = "unknown") -> ConfidenceCalibrationRecord:
    success_rate = round(success_count / sample_count, 6) if sample_count else 0.0
    behavior = "normal"
    if sample_count < 5:
        behavior = "ask_for_review" if complexity_band in {"high", "critical"} else "expand_tests"
    elif success_rate < 0.8:
        behavior = "ask_for_review"
    return ConfidenceCalibrationRecord(
        calibration_id=deterministic_id("calibration", task_type, complexity_band, agent_profile_id),
        task_type=task_type,
        complexity_band=complexity_band,
        agent_profile_id=agent_profile_id,
        sample_count=sample_count,
        success_rate=success_rate,
        recommended_behavior=behavior,
        provisional=sample_count < 5,
    )
