from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields, replace
from typing import Any

from ctxlayer.utils import canonical_json, stable_id, utc_now

SCHEMA_VERSION = "ctxlayer.cie.v1"
HYPOTHESIS_STATUSES = {
    "candidate",
    "collecting_evidence",
    "supported",
    "disconfirmed",
    "inconclusive",
    "retired",
}


def deterministic_id(kind: str, *parts: Any) -> str:
    return stable_id("cie", kind, *[canonical_json(part) if isinstance(part, (dict, list)) else str(part) for part in parts])


def to_json_dict(value: Any) -> dict[str, Any]:
    if hasattr(value, "to_dict"):
        return value.to_dict()
    if hasattr(value, "__dataclass_fields__"):
        return _clean(asdict(value))
    if isinstance(value, dict):
        return _clean(value)
    raise TypeError(f"unsupported CIE payload: {type(value)!r}")


def artifact_to_dicts(values: list[Any]) -> list[dict[str, Any]]:
    return [to_json_dict(value) for value in values]


def semantic_version_update(artifact: Any, *, reason: str = "new_evidence", **changes: Any) -> Any:
    if not hasattr(artifact, "__dataclass_fields__"):
        raise TypeError("artifact must be a dataclass instance")
    data = {field.name: getattr(artifact, field.name) for field in fields(artifact)}
    old_id = _stable_field_value(data)
    data.update(changes)
    data["artifact_version"] = int(data.get("artifact_version") or 1) + 1
    data["supersedes_artifact_id"] = old_id
    data["lineage_reason"] = reason
    return replace(artifact, **{key: data[key] for key in data if any(item.name == key for item in fields(artifact))})


def _stable_field_value(data: dict[str, Any]) -> str | None:
    for key in ("root_cause_id", "pattern_id", "hypothesis_id", "rule_id", "checklist_id", "score_id", "intervention_id", "agent_profile_id", "capability_id"):
        if data.get(key):
            return str(data[key])
    return None


def _clean(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _clean(item) for key, item in sorted(value.items())}
    if isinstance(value, list):
        return [_clean(item) for item in value]
    return value


@dataclass
class CIEPayload:
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        return _clean(asdict(self))


@dataclass
class VersionedArtifact(CIEPayload):
    artifact_version: int = 1
    parent_artifact_id: str | None = None
    supersedes_artifact_id: str | None = None
    lineage_reason: str = "new_evidence"
    created_by_agent_id: str | None = None
    discovered_by_agent_id: str | None = None
    reviewed_by_agent_id: str | None = None


@dataclass
class ErrorEvent(CIEPayload):
    error_id: str = ""
    created_at: str = field(default_factory=utc_now)
    summary: str = ""
    source: str = "learning_event"
    severity: str = "medium"
    evidence_refs: list[str] = field(default_factory=list)
    actor_agent_id: str | None = None
    discoverer_agent_id: str | None = None
    reviewer_agent_id: str | None = None
    agent_profile_id: str = "unknown"
    raw_payload: dict[str, Any] = field(default_factory=dict)


@dataclass
class FailureClassification(CIEPayload):
    classification_id: str = ""
    error_id: str = ""
    category: str = "system_health"
    confidence: float = 0.5
    rationale: str = ""
    evidence_refs: list[str] = field(default_factory=list)


@dataclass
class RootCauseRecord(VersionedArtifact):
    root_cause_id: str = ""
    source_error_ids: list[str] = field(default_factory=list)
    category: str = "system_health"
    root_cause: str = "system_health"
    confidence: float = 0.5
    recurrence_count: int = 1
    affected_task_types: list[str] = field(default_factory=list)
    cognitive_debt_score: float = 0.0
    evidence_refs: list[str] = field(default_factory=list)
    status: str = "active"


@dataclass
class CognitivePatternRecord(VersionedArtifact):
    pattern_id: str = ""
    pattern_type: str = "insufficient_exploration"
    root_cause_ids: list[str] = field(default_factory=list)
    confidence: float = 0.5
    recurrence_count: int = 1
    evidence_refs: list[str] = field(default_factory=list)
    status: str = "candidate"


@dataclass
class HypothesisRecord(VersionedArtifact):
    hypothesis_id: str = ""
    pattern_id: str = ""
    statement: str = ""
    trigger_conditions: list[str] = field(default_factory=list)
    expected_observation: str = ""
    disconfirming_observation: str = ""
    evidence_collection_plan: list[str] = field(default_factory=list)
    status: str = "candidate"
    support_count: int = 0
    contradiction_count: int = 0
    confidence: float = 0.4
    evidence_refs: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.status not in HYPOTHESIS_STATUSES:
            raise ValueError(f"unknown hypothesis status: {self.status}")


@dataclass
class HypothesisRelationship(VersionedArtifact):
    relationship_id: str = ""
    source_hypothesis_id: str = ""
    target_hypothesis_id: str = ""
    relation_type: str = "unrelated"
    evidence_refs: list[str] = field(default_factory=list)
    confidence: float = 0.0
    explanation: str = ""
    detected_by: str = "deterministic"


@dataclass
class MetaRootCauseRecord(VersionedArtifact):
    meta_root_cause_id: str = ""
    root_cause_ids: list[str] = field(default_factory=list)
    label: str = ""
    confidence: float = 0.5
    evidence_refs: list[str] = field(default_factory=list)
    status: str = "candidate"


@dataclass
class PreventionRuleRecord(VersionedArtifact):
    rule_id: str = ""
    source_hypothesis_ids: list[str] = field(default_factory=list)
    rule_text: str = ""
    risk_class: str = "report"
    status: str = "candidate"
    evidence_refs: list[str] = field(default_factory=list)
    effectiveness: float = 0.0


@dataclass
class DynamicChecklist(VersionedArtifact):
    checklist_id: str = ""
    task_type: str = "unknown"
    items: list[dict[str, Any]] = field(default_factory=list)
    source_refs: list[str] = field(default_factory=list)
    status: str = "preview"


@dataclass
class MistakeRecurrencePrediction(VersionedArtifact):
    prediction_id: str = ""
    task_signature: str = ""
    task_type: str = "unknown"
    likely_failure_modes: list[str] = field(default_factory=list)
    recommended_behavior: str = "normal"
    task_complexity_score: float = 0.0
    complexity_band: str = "low"
    confidence: float = 0.0
    provisional: bool = True
    evidence_refs: list[str] = field(default_factory=list)


@dataclass
class CognitiveDebtRecord(VersionedArtifact):
    debt_id: str = ""
    target_id: str = ""
    target_type: str = "root_cause"
    score: float = 0.0
    severity: float = 1.0
    recurrence: float = 1.0
    correction_cost: float = 1.0
    user_dissatisfaction: float = 1.0
    rollback_effort: float = 1.0
    blast_radius: float = 1.0
    evidence_refs: list[str] = field(default_factory=list)


@dataclass
class ConfidenceCalibrationRecord(VersionedArtifact):
    calibration_id: str = ""
    task_type: str = "unknown"
    complexity_band: str = "low"
    agent_profile_id: str = "unknown"
    sample_count: int = 0
    success_rate: float = 0.0
    recommended_behavior: str = "normal"
    provisional: bool = True
    evidence_refs: list[str] = field(default_factory=list)


@dataclass
class LearningDecayRecord(VersionedArtifact):
    decay_id: str = ""
    target_id: str = ""
    target_type: str = "rule"
    action: str = "keep"
    reason: str = ""
    evidence_refs: list[str] = field(default_factory=list)


@dataclass
class CognitiveImprovementScore(VersionedArtifact):
    score_id: str = ""
    period: str = "current"
    score: float = 0.0
    previous_score: float = 0.0
    delta: float = 0.0
    components: dict[str, float] = field(default_factory=dict)
    sample_size: int = 0
    confidence: float = 0.0
    explanation: str = ""
    false_learning_warnings: list[str] = field(default_factory=list)
    provisional: bool = True

    def __post_init__(self) -> None:
        required = {
            "error_recurrence_index",
            "cognitive_debt_index",
            "rule_effectiveness_index",
            "prediction_accuracy_index",
            "confidence_calibration_index",
            "learning_quality_index",
            "near_miss_severity_index",
            "decision_quality_index",
        }
        missing = required - set(self.components)
        if missing:
            raise ValueError(f"missing score components: {sorted(missing)}")


@dataclass
class InterventionRecord(VersionedArtifact):
    intervention_id: str = ""
    kind: str = "report"
    status: str = "proposed"
    summary: str = ""
    source_hypothesis_ids: list[str] = field(default_factory=list)
    risk: str = "low"
    gates: dict[str, Any] = field(default_factory=dict)
    rollback_conditions: list[str] = field(default_factory=list)
    suspension_conditions: list[str] = field(default_factory=list)
    rollback_action: str = "manual_only"
    rollback_window: str = "next_cycle"
    rollback_metrics: list[str] = field(default_factory=list)
    last_rollback_evaluation: str | None = None
    rollback_status: str = "not_applicable"
    evidence_refs: list[str] = field(default_factory=list)


@dataclass
class NearMissEvent(CIEPayload):
    near_miss_id: str = ""
    created_at: str = field(default_factory=utc_now)
    proposed_action: str = ""
    blocked_by: str = ""
    potential_impact: str = ""
    potential_severity: str = "medium"
    confidence_before: float = 0.0
    confidence_after: float = 0.0
    counterfactual_outcome: str = ""
    related_root_causes: list[str] = field(default_factory=list)
    related_patterns: list[str] = field(default_factory=list)
    related_hypotheses: list[str] = field(default_factory=list)
    cognitive_debt_score: float = 0.0
    evidence_refs: list[str] = field(default_factory=list)


@dataclass
class DecisionQualityRecord(CIEPayload):
    decision_quality_id: str = ""
    options_considered: list[str] = field(default_factory=list)
    selected_option: str = ""
    alternative_options: list[str] = field(default_factory=list)
    selection_rationale: str = ""
    outcome_quality: float = 0.0
    quality_gap: float = 0.0
    option_set_coverage: float = 0.0
    exploration_signal: str = "unknown"
    review_source: str = "self_review"
    related_patterns: list[str] = field(default_factory=list)
    related_hypotheses: list[str] = field(default_factory=list)
    evidence_refs: list[str] = field(default_factory=list)


@dataclass
class OpportunityCostRecord(CIEPayload):
    opportunity_cost_id: str = ""
    task_type: str = "unknown"
    task_complexity_band: str = "low"
    agent_profile_id: str = "unknown"
    options_considered_count: int = 0
    option_diversity_score: float = 0.0
    exploration_rate: float = 0.0
    safe_default_rate: float = 0.0
    missed_option_type: str = "unknown"
    estimated_cost: dict[str, float] = field(default_factory=dict)
    evidence_refs: list[str] = field(default_factory=list)
    status: str = "observed"


@dataclass
class CognitiveArtifactLineage(CIEPayload):
    artifact_id: str = ""
    artifact_type: str = ""
    artifact_version: int = 1
    parent_artifact_id: str | None = None
    supersedes_artifact_id: str | None = None
    lineage_reason: str = "new_evidence"


@dataclass
class CognitiveStateSnapshotRef(CIEPayload):
    snapshot_id: str = ""
    created_at: str = field(default_factory=utc_now)
    memory_snapshot_id: str = "memory:none"
    skill_snapshot_id: str = "skill:none"
    rule_snapshot_id: str = "rule:none"
    pattern_snapshot_id: str = "pattern:none"
    hypothesis_snapshot_id: str = "hypothesis:none"
    confidence_snapshot_id: str = "confidence:none"
    debt_snapshot_id: str = "debt:none"
    agent_profile_snapshot_id: str = "agent:default"
    source_counts: dict[str, int] = field(default_factory=dict)
    source_artifact_versions: dict[str, int] = field(default_factory=dict)


@dataclass
class AgentProfileRecord(VersionedArtifact):
    agent_profile_id: str = "unknown"
    agent_name: str = "codex"
    role: str = "codex"
    capabilities: list[str] = field(default_factory=list)
    known_constraints: list[str] = field(default_factory=list)
    preferred_tools: list[str] = field(default_factory=list)
    observed_failure_modes: list[str] = field(default_factory=list)
    observed_strengths: list[str] = field(default_factory=list)
    active_skill_ids: list[str] = field(default_factory=list)
    evidence_refs: list[str] = field(default_factory=list)
    status: str = "active"


@dataclass
class AgentCapabilityModel(VersionedArtifact):
    capability_id: str = ""
    capability_name: str = ""
    success_rate: float = 0.0
    failure_rate: float = 0.0
    confidence: float = 0.0
    sample_size: int = 0
    relevant_task_types: list[str] = field(default_factory=list)
    relevant_complexity_bands: list[str] = field(default_factory=list)
    source_agent_profile_id: str = "unknown"
    transferability: str = "blocked_transfer"
    evidence_refs: list[str] = field(default_factory=list)


@dataclass
class CrossAgentTransferRecord(CIEPayload):
    transfer_id: str = ""
    source_agent_profile_id: str = "unknown"
    target_agent_profile_id: str = "unknown"
    artifact_id: str = ""
    transferability: str = "blocked_transfer"
    status: str = "blocked"
    evidence_refs: list[str] = field(default_factory=list)


@dataclass
class LearningQualityCheck(CIEPayload):
    learning_quality_id: str = ""
    period: str = "current"
    raw_improvement: float = 0.0
    difficulty_adjusted_improvement: float = 0.0
    hard_task_attempt_rate_before: float = 0.0
    hard_task_attempt_rate_after: float = 0.0
    suspected_false_learning_reasons: list[str] = field(default_factory=list)
    status: str = "healthy"
    evidence_refs: list[str] = field(default_factory=list)


@dataclass
class CIECycleReport(CIEPayload):
    run_id: str = ""
    created_at: str = field(default_factory=utc_now)
    mode: str = "report"
    config: dict[str, Any] = field(default_factory=dict)
    signals: dict[str, Any] = field(default_factory=dict)
    diagnoses: list[dict[str, Any]] = field(default_factory=list)
    proposed_interventions: list[dict[str, Any]] = field(default_factory=list)
    blocked_actions: list[dict[str, Any]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    next_recommended_phase: str = "advisory"
    cognitive_state_snapshot: dict[str, Any] = field(default_factory=dict)
