from __future__ import annotations

from ctxlayer.cie.contracts import CognitivePatternRecord, HypothesisRecord, deterministic_id

STATEMENTS = {
    "verification_avoidance": "Verification is skipped when perceived task complexity is low or success seems obvious.",
    "premature_confidence": "Confidence rises before enough independent evidence is collected.",
    "insufficient_exploration": "The agent selects the first viable plan without comparing alternatives.",
    "surface_drift": "One public surface is updated while another equivalent surface is missed.",
    "unsafe_mutation_pressure": "Execution pressure causes sequencing, checkpoint, or gate discipline to degrade.",
    "context_underselection": "Relevant files or memories are underselected during early task framing.",
    "weak_uncertainty_handling": "Impact uncertainty is not translated into broader tests or review.",
}


def generate_hypotheses(patterns: list[CognitivePatternRecord]) -> list[HypothesisRecord]:
    hypotheses: list[HypothesisRecord] = []
    for pattern in patterns:
        status = "collecting_evidence"
        if pattern.recurrence_count >= 3:
            status = "supported"
        hypotheses.append(
            HypothesisRecord(
                hypothesis_id=deterministic_id("hypothesis", pattern.pattern_id, pattern.pattern_type),
                pattern_id=pattern.pattern_id,
                statement=STATEMENTS.get(pattern.pattern_type, f"{pattern.pattern_type} affects task quality."),
                trigger_conditions=[pattern.pattern_type, "matching task type or complexity band"],
                expected_observation="related failures or near misses recur in the same segment",
                disconfirming_observation="future comparable work succeeds without the predicted failure mode",
                evidence_collection_plan=["track recurrence", "compare by task type", "compare by complexity band"],
                status=status,
                support_count=pattern.recurrence_count,
                contradiction_count=0,
                confidence=pattern.confidence,
                evidence_refs=list(pattern.evidence_refs),
            )
        )
    return hypotheses


def validate_hypotheses(hypotheses: list[HypothesisRecord]) -> list[HypothesisRecord]:
    validated: list[HypothesisRecord] = []
    for hypothesis in hypotheses:
        if hypothesis.contradiction_count > hypothesis.support_count:
            status = "disconfirmed"
        elif hypothesis.support_count >= 3 and hypothesis.contradiction_count == 0:
            status = "supported"
        elif hypothesis.support_count and hypothesis.contradiction_count:
            status = "inconclusive"
        else:
            status = hypothesis.status
        validated.append(HypothesisRecord(**{**hypothesis.to_dict(), "status": status}))
    return validated
