from __future__ import annotations

from typing import Any

from ctxlayer.cie.contracts import ErrorEvent, FailureClassification, deterministic_id
from ctxlayer.cie.taxonomy import normalize_failure_category


def capture_error_events(rows: list[dict[str, Any]], *, limit: int = 20) -> list[ErrorEvent]:
    events: list[ErrorEvent] = []
    for row in rows[: max(0, limit)]:
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        text = " ".join(
            str(part)
            for part in [
                row.get("kind"),
                row.get("phase"),
                row.get("target"),
                row.get("kind_name"),
                payload.get("error"),
                payload.get("reason"),
                payload.get("status"),
            ]
            if part
        ).lower()
        failed = (
            row.get("gate_pass") is False
            or row.get("ok") is False
            or "fail" in text
            or "reject" in text
            or "blocked" in text
            or "violation" in text
        )
        if not failed:
            continue
        source_id = str(row.get("event_id") or row.get("run_id") or row.get("ref") or len(events))
        events.append(
            ErrorEvent(
                error_id=deterministic_id("error", source_id, text),
                summary=_safe_summary(text),
                source=str(row.get("source") or row.get("phase") or row.get("kind") or "learning"),
                severity=_severity(text),
                evidence_refs=[source_id],
                actor_agent_id=payload.get("actor_agent_id"),
                discoverer_agent_id=payload.get("discoverer_agent_id"),
                reviewer_agent_id=payload.get("reviewer_agent_id"),
                agent_profile_id=str(payload.get("agent_profile_id") or "unknown"),
                raw_payload={key: payload[key] for key in sorted(payload) if key in {"status", "reason", "error"}},
            )
        )
    return events


def classify_error(event: ErrorEvent) -> FailureClassification:
    category = normalize_failure_category(f"{event.summary} {event.source}")
    return FailureClassification(
        classification_id=deterministic_id("classification", event.error_id, category),
        error_id=event.error_id,
        category=category,
        confidence=0.75 if category != "system_health" else 0.45,
        rationale=f"deterministic keyword mapping to {category}",
        evidence_refs=list(event.evidence_refs),
    )


def classify_errors(events: list[ErrorEvent]) -> list[FailureClassification]:
    return [classify_error(event) for event in events]


def _safe_summary(text: str) -> str:
    cleaned = " ".join(str(text or "").replace("\n", " ").split())
    return cleaned[:180] if cleaned else "recorded learning failure"


def _severity(text: str) -> str:
    if any(token in text for token in ("critical", "secret", "security", "canary")):
        return "critical"
    if any(token in text for token in ("high", "blocked", "violation", "reject")):
        return "high"
    if any(token in text for token in ("low", "warning")):
        return "low"
    return "medium"
