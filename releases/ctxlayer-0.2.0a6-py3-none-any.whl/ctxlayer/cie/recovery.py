from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ctxlayer.utils import canonical_json, stable_id, utc_now


def export_state(store: Any, output: str | None = None, *, limit: int = 100) -> dict[str, Any]:
    runs = [_cie_run(row) for row in store.learning_runs(kind="cie_cycle", limit=limit)]
    events = []
    for row in store.learning_events(limit=limit):
        if row["phase"] != "cie":
            continue
        events.append(_event(row))
    payload = {
        "schema_version": "ctxlayer.cie.export.v1",
        "generated_at": utc_now(),
        "runs": runs,
        "events": events,
        "snapshot_manifest": {
            "run_count": len(runs),
            "event_count": len(events),
            "manifest_hash": stable_id(canonical_json([run["run_id"] for run in runs])),
        },
    }
    if output:
        path = Path(output)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return {"ok": True, "export": payload, "output": output}


def import_state(input_path: str, *, dry_run: bool = True) -> dict[str, Any]:
    payload = json.loads(Path(input_path).read_text(encoding="utf-8"))
    if payload.get("schema_version") != "ctxlayer.cie.export.v1":
        return {"ok": False, "reason": "unsupported_schema"}
    active_high_risk = [
        item
        for run in payload.get("runs", [])
        for item in ((run.get("after") or {}).get("proposed_interventions") or [])
        if item.get("status") == "active" and item.get("risk") in {"high", "critical"}
    ]
    if active_high_risk and dry_run:
        return {
            "ok": True,
            "dry_run": True,
            "status": "would_require_approval",
            "high_risk_active_interventions": len(active_high_risk),
        }
    return {
        "ok": True,
        "dry_run": dry_run,
        "runs_seen": len(payload.get("runs", [])),
        "events_seen": len(payload.get("events", [])),
        "status": "validated",
    }


def rebuild_state(store: Any, *, from_events: bool = True, dry_run: bool = True, limit: int = 100) -> dict[str, Any]:
    runs = [_cie_run(row) for row in store.learning_runs(kind="cie_cycle", limit=limit)]
    artifact_ids = set()
    gaps: list[str] = []
    for run in runs:
        report = run.get("after") or {}
        snapshot = report.get("cognitive_state_snapshot") or {}
        if not snapshot.get("snapshot_id"):
            gaps.append(f"missing_snapshot:{run.get('run_id')}")
        for section in ("diagnoses", "proposed_interventions", "blocked_actions"):
            for item in report.get(section, []) or []:
                for key, value in item.items():
                    if key.endswith("_id") and value:
                        artifact_ids.add(str(value))
    return {
        "ok": True,
        "dry_run": dry_run,
        "from_events": from_events,
        "rebuild_report": {
            "runs_read": len(runs),
            "artifact_ids_seen": len(artifact_ids),
            "gaps": gaps,
            "confidence": 1.0 if runs and not gaps else 0.5 if runs else 0.0,
        },
    }


def _cie_run(row: Any) -> dict[str, Any]:
    return {
        "run_id": row["run_id"],
        "target": row["target"],
        "kind": row["kind"],
        "after": _json(row["after_json"]),
        "train_metrics": _json(row["train_metrics_json"]),
        "holdout_metrics": _json(row["holdout_metrics_json"]),
        "created_at": row["created_at"],
    }


def _event(row: Any) -> dict[str, Any]:
    return {
        "event_id": row["event_id"],
        "ts": row["ts"],
        "phase": row["phase"],
        "kind": row["kind"],
        "ref": row["ref"],
        "payload": _json(row["payload_json"]),
    }


def _json(value: str | None) -> Any:
    try:
        return json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
