from __future__ import annotations

import json
import os
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

from ctxlayer.cie.adoption import (
    adopt_intervention,
    default_report_intervention,
    preview_adoption,
    reject_intervention,
    rollback_intervention,
    suspend_intervention,
)
from ctxlayer.cie.checklists import checklist_preview
from ctxlayer.cie.classification import capture_error_events, classify_errors
from ctxlayer.cie.complexity import estimate_complexity
from ctxlayer.cie.confidence import calibrate_confidence
from ctxlayer.cie.contracts import (
    AgentProfileRecord,
    CIECycleReport,
    CognitiveStateSnapshotRef,
    InterventionRecord,
    artifact_to_dicts,
    deterministic_id,
    to_json_dict,
)
from ctxlayer.cie.counterfactual import record_near_miss
from ctxlayer.cie.debt import debt_for_root_causes
from ctxlayer.cie.decay import decay_guidance
from ctxlayer.cie.decision_quality import assess_decision_quality
from ctxlayer.cie.effectiveness import checklist_compliance, prediction_accuracy, rule_effectiveness
from ctxlayer.cie.hypotheses import generate_hypotheses, validate_hypotheses
from ctxlayer.cie.hypothesis_graph import detect_hypothesis_relationships
from ctxlayer.cie.learning_quality import detect_false_learning
from ctxlayer.cie.opportunity_cost import measure_opportunity_cost
from ctxlayer.cie.patterns import discover_patterns
from ctxlayer.cie.prediction import predict_mistakes
from ctxlayer.cie.recovery import export_state, import_state, rebuild_state
from ctxlayer.cie.root_causes import infer_root_causes
from ctxlayer.learning.provider import AgentProvider
from ctxlayer.utils import canonical_json, stable_id, utc_now


PROVIDER_ALLOWED_INTERVENTION_KINDS = {
    "report",
    "optimizer",
    "memory",
    "skill",
    "eval",
    "config",
    "selfmod",
    "checklist",
}
PROVIDER_ALLOWED_RISKS = {"low", "medium", "high", "critical"}
PROVIDER_ALLOWED_ROLLBACK_ACTIONS = {
    "auto_suspend",
    "lower_rank",
    "retire_candidate",
    "request_review",
    "manual_only",
}
PROVIDER_PROTECTED_TEXT = (
    "bypass audit",
    "bypass gate",
    "disable audit",
    "disable gate",
    "disable security",
    "ignore previous instructions",
    "leak secret",
    "skip security",
    "skip tests",
)
PROVIDER_PROPOSAL_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["interventions"],
    "properties": {
        "interventions": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["kind", "summary", "rationale", "risk"],
                "properties": {
                    "kind": {"type": "string", "enum": sorted(PROVIDER_ALLOWED_INTERVENTION_KINDS)},
                    "summary": {"type": "string"},
                    "rationale": {"type": "string"},
                    "risk": {"type": "string", "enum": sorted(PROVIDER_ALLOWED_RISKS)},
                    "source_hypothesis_ids": {"type": "array", "items": {"type": "string"}},
                    "evidence_refs": {"type": "array", "items": {"type": "string"}},
                    "rollback_conditions": {"type": "array", "items": {"type": "string"}},
                    "suspension_conditions": {"type": "array", "items": {"type": "string"}},
                    "rollback_action": {
                        "type": "string",
                        "enum": sorted(PROVIDER_ALLOWED_ROLLBACK_ACTIONS),
                    },
                },
                "additionalProperties": False,
            },
        }
    },
    "additionalProperties": False,
}


class CIEEngine:
    def __init__(
        self,
        *,
        repo_root: Path,
        store: Any,
        settings: Any,
        provider: AgentProvider | None = None,
        model_family: str | None = None,
        budget_tokens: int | None = None,
    ):
        self.repo_root = repo_root
        self.store = store
        self.settings = settings
        self.provider = provider
        self.model_family = model_family
        self.budget_tokens = budget_tokens

    def status(self) -> dict[str, Any]:
        runs = self.store.learning_runs(kind="cie_cycle", limit=5)
        latest = _run_to_dict(runs[0]) if runs else None
        return {
            "ok": True,
            "enabled": bool(self.settings.learning.cie.enabled),
            "mode": self.settings.learning.cie.default_mode,
            "learning_off": os.environ.get("CTXLAYER_LEARNING_OFF") == "1",
            "allow_adoption": bool(self.settings.learning.cie.allow_adoption),
            "latest_run": latest,
            "archived_runs": len(runs),
            "surfaces": ["service", "cli", "mcp", "http", "dashboard", "rollup"],
        }

    def cycle(self, limit: int = 20, target: str = "cie", task: str = "", paths: list[str] | None = None) -> dict[str, Any]:
        limit = min(max(1, int(limit)), int(self.settings.learning.cie.max_cycles))
        created_at = utc_now()
        self.store.write_learning_event(phase="cie", kind="cie_cycle_started", ref=target, payload={"limit": limit})
        signals = self._signals(limit=limit)
        self.store.write_learning_event(phase="cie", kind="cie_signals_observed", ref=target, payload=_counts(signals))
        report = self._build_report(target=target, task=task, paths=paths or [], signals=signals, created_at=created_at)
        run_id = self.store.write_learning_run(
            target=target,
            kind="cie_cycle",
            before={"signals": _counts(signals), "target": target},
            after=report,
            train_metrics=report.get("metrics", {}),
            holdout_metrics={"sealed": True, "required": bool(self.settings.learning.cie.require_holdout_gate)},
            gate_pass=True,
            archived=True,
            promoted=False,
            run_id=report["run_id"],
        )
        report["run_id"] = run_id
        self.store.write_learning_event(phase="cie", kind="cie_diagnosis_recorded", ref=run_id, payload={"diagnoses": len(report["diagnoses"])})
        self.store.write_learning_event(phase="cie", kind="cie_intervention_proposed", ref=run_id, payload={"interventions": len(report["proposed_interventions"])})
        self.store.write_learning_event(phase="cie", kind="cie_cycle_completed", ref=run_id, payload={"snapshot_id": report["cognitive_state_snapshot"]["snapshot_id"]})
        return {"ok": True, "run_id": run_id, "report": report}

    def archive(self, limit: int = 20, target: str | None = None) -> dict[str, Any]:
        rows = self.store.learning_runs(target=target, kind="cie_cycle", limit=limit)
        return {"ok": True, "runs": [_run_to_dict(row) for row in rows]}

    def show(self, run_id: str) -> dict[str, Any]:
        row = self.store.learning_run(run_id)
        if row is None or row["kind"] != "cie_cycle":
            raise KeyError(f"CIE run not found: {run_id}")
        return {"ok": True, "run": _run_to_dict(row)}

    def predict(self, task: str = "", paths: list[str] | None = None) -> dict[str, Any]:
        prediction = predict_mistakes(task, paths or [], [])
        checklist = checklist_preview(task, paths or [])
        return {"ok": True, "prediction": to_json_dict(prediction), "checklist": to_json_dict(checklist)}

    def checklist_preview(self, task: str = "", paths: list[str] | None = None) -> dict[str, Any]:
        return {"ok": True, "checklist": to_json_dict(checklist_preview(task, paths or []))}

    def score(self, period: str = "current") -> dict[str, Any]:
        rows = self.store.learning_runs(kind="cie_cycle", limit=1)
        if not rows:
            return {"ok": True, "score": None, "period": period}
        report = _json(rows[0]["after_json"])
        return {"ok": True, "score": report.get("score"), "period": period}

    def timeline(self, run_id: str | None = None) -> dict[str, Any]:
        rows = self.store.learning_runs(kind="cie_cycle", limit=50)
        events: list[dict[str, Any]] = []
        for row in rows:
            if run_id and row["run_id"] != run_id:
                continue
            report = _json(row["after_json"])
            snapshot_id = (report.get("cognitive_state_snapshot") or {}).get("snapshot_id")
            for section in ("diagnoses", "proposed_interventions", "blocked_actions"):
                for item in report.get(section, []) or []:
                    events.append(
                        {
                            "ts": report.get("created_at") or row["created_at"],
                            "run_id": row["run_id"],
                            "event_type": section,
                            "artifact_id": _first_id(item),
                            "snapshot_id": snapshot_id,
                            "status": item.get("status"),
                        }
                    )
        return {"ok": True, "events": sorted(events, key=lambda item: (item["ts"], item.get("artifact_id") or ""))}

    def preview_adoption(self, run_id: str, intervention_id: str) -> dict[str, Any]:
        return preview_adoption(self._report(run_id), intervention_id)

    def adopt(self, run_id: str, intervention_id: str, approved_by: str) -> dict[str, Any]:
        result = adopt_intervention(self._report(run_id), intervention_id, approved_by=approved_by, settings=self.settings)
        self.store.write_learning_event(phase="cie", kind="cie_intervention_adopt", ref=run_id, payload=result)
        return result

    def reject(self, run_id: str, intervention_id: str, reason: str, actor: str) -> dict[str, Any]:
        result = reject_intervention(self._report(run_id), intervention_id, reason=reason, actor=actor)
        self.store.write_learning_event(phase="cie", kind="cie_intervention_reject", ref=run_id, payload=result)
        return result

    def suspend(self, run_id: str, intervention_id: str, reason: str, actor: str) -> dict[str, Any]:
        result = suspend_intervention(self._report(run_id), intervention_id, reason=reason, actor=actor)
        self.store.write_learning_event(phase="cie", kind="cie_intervention_suspend", ref=run_id, payload=result)
        return result

    def rollback(self, run_id: str, intervention_id: str, approved_by: str) -> dict[str, Any]:
        result = rollback_intervention(self._report(run_id), intervention_id, approved_by=approved_by)
        self.store.write_learning_event(phase="cie", kind="cie_intervention_rollback", ref=run_id, payload=result)
        return result

    def export_state(self, output: str | None = None) -> dict[str, Any]:
        return export_state(self.store, output)

    def import_state(self, input_path: str, dry_run: bool = True) -> dict[str, Any]:
        return import_state(input_path, dry_run=dry_run)

    def rebuild_state(self, from_events: bool = True, dry_run: bool = True) -> dict[str, Any]:
        return rebuild_state(self.store, from_events=from_events, dry_run=dry_run)

    def _report(self, run_id: str) -> dict[str, Any]:
        row = self.store.learning_run(run_id)
        if row is None or row["kind"] != "cie_cycle":
            raise KeyError(f"CIE run not found: {run_id}")
        return _json(row["after_json"])

    def _signals(self, *, limit: int) -> dict[str, Any]:
        events = []
        for row in self.store.learning_events(limit=limit):
            item = dict(row)
            item["payload"] = _json(item.pop("payload_json"))
            item["source"] = "learning_event"
            events.append(item)
        runs = []
        for row in self.store.learning_runs(limit=limit):
            item = dict(row)
            item["gate_pass"] = bool(item["gate_pass"])
            item["payload"] = _json(item.get("after_json"))
            item["source"] = "learning_run"
            runs.append(item)
        return {
            "recent_events": events,
            "recent_runs": runs,
            "config_flags": _config_dict(self.settings.learning.cie),
            "database": {"empty": not events and not runs},
        }

    def _build_report(self, *, target: str, task: str, paths: list[str], signals: dict[str, Any], created_at: str) -> dict[str, Any]:
        event_inputs = [*signals.get("recent_events", []), *signals.get("recent_runs", [])]
        error_events = capture_error_events(event_inputs, limit=int(self.settings.learning.cie.max_cycles))
        classifications = classify_errors(error_events)
        root_causes = infer_root_causes(classifications)
        patterns = discover_patterns(root_causes)
        hypotheses = validate_hypotheses(generate_hypotheses(patterns))
        relationships = detect_hypothesis_relationships(hypotheses)
        debts = debt_for_root_causes(root_causes)
        complexity = estimate_complexity(task or target, paths, [to_json_dict(item) for item in error_events])
        prediction = predict_mistakes(task or target, paths, [to_json_dict(item) for item in error_events])
        checklist = checklist_preview(task or target, paths, [item.hypothesis_id for item in hypotheses] or ["built_in_baseline"])
        calibration = calibrate_confidence(prediction.task_type, prediction.complexity_band, sample_count=len(error_events), success_count=max(0, len(event_inputs) - len(error_events)))
        near_misses = [
            record_near_miss("blocked risky action", ref, evidence_refs=[ref])
            for ref in _blocked_refs(event_inputs)[:3]
        ]
        decision_quality = assess_decision_quality(["read_only_report", "direct_mutation"], "read_only_report", outcome_quality=0.9)
        opportunity = measure_opportunity_cost(prediction.task_type, prediction.complexity_band, 2)
        learning_quality = detect_false_learning(0.0, 0.0, 0.5, 0.5)
        effectiveness = {
            "rule_effectiveness": rule_effectiveness(1.0, 0.0),
            "prediction_accuracy": prediction_accuracy(len(error_events), 0, 0),
            "checklist_compliance": checklist_compliance(len(checklist.items), 0, 0),
        }
        decays = [decay_guidance(item.get("rule_id", "candidate"), effectiveness=1.0) for item in []]
        components = {
            "error_recurrence_index": max(0, 100 - (len(error_events) * 10)),
            "cognitive_debt_index": max(0, 100 - sum(item.score for item in debts[:3])),
            "rule_effectiveness_index": 100,
            "prediction_accuracy_index": 100 if error_events else 50,
            "confidence_calibration_index": max(20, calibration.success_rate * 100),
            "learning_quality_index": 100 if learning_quality.status == "healthy" else 40,
            "near_miss_severity_index": max(0, 100 - sum(item.cognitive_debt_score for item in near_misses)),
            "decision_quality_index": decision_quality.outcome_quality * 100,
        }
        from ctxlayer.cie.score import compute_improvement_score

        score = compute_improvement_score(
            components,
            sample_size=len(event_inputs),
            warnings=learning_quality.suspected_false_learning_reasons,
        )
        snapshot = self._snapshot(
            memories=0,
            skills=len(_safe_call(lambda: self.store.skills(limit=100), [])),
            rules=0,
            patterns=len(patterns),
            hypotheses=len(hypotheses),
            debt=len(debts),
        )
        diagnoses = [
            *artifact_to_dicts(classifications),
            *artifact_to_dicts(root_causes),
            *artifact_to_dicts(patterns),
            *artifact_to_dicts(hypotheses),
            *artifact_to_dicts(relationships),
            *artifact_to_dicts(debts),
            to_json_dict(calibration),
            to_json_dict(learning_quality),
            to_json_dict(decision_quality),
            to_json_dict(opportunity),
            *artifact_to_dicts(decays),
        ]
        evidence_refs = [ref for item in error_events for ref in item.evidence_refs]
        intervention = default_report_intervention("Read-only CIE report generated; no mutation requested.", evidence_refs)
        provider_proposals = self._provider_candidate_proposals(
            target=target,
            task=task,
            paths=paths,
            diagnoses=diagnoses,
            prediction=to_json_dict(prediction),
            checklist=to_json_dict(checklist),
            score=to_json_dict(score),
            hypotheses=artifact_to_dicts(hypotheses),
            evidence_refs=evidence_refs,
        )
        interventions = [to_json_dict(intervention), *provider_proposals["interventions"]]
        interventions = interventions[: max(1, int(self.settings.learning.cie.max_interventions_per_cycle))]
        report = CIECycleReport(
            run_id=deterministic_id("cycle", target, created_at, _counts(signals)),
            created_at=created_at,
            mode="report",
            config=_config_dict(self.settings.learning.cie),
            signals={
                **_counts(signals),
                "task_complexity": complexity,
                "prediction": to_json_dict(prediction),
                "checklist_preview": to_json_dict(checklist),
                "effectiveness": effectiveness,
                "provider_proposals": provider_proposals["summary"],
            },
            diagnoses=diagnoses,
            proposed_interventions=interventions,
            blocked_actions=artifact_to_dicts(near_misses),
            warnings=[*_warnings(self.settings, signals), *provider_proposals["warnings"]],
            next_recommended_phase="controlled_adoption" if self.settings.learning.cie.allow_adoption else "advisory_measurement",
            cognitive_state_snapshot=to_json_dict(snapshot),
        ).to_dict()
        report["score"] = to_json_dict(score)
        report["agent_profile"] = to_json_dict(AgentProfileRecord(agent_profile_id="unknown", role="codex"))
        report["metrics"] = {"diagnoses": len(diagnoses), "blocked_actions": len(near_misses), "gate": "read_only_pass"}
        return report

    def _provider_candidate_proposals(
        self,
        *,
        target: str,
        task: str,
        paths: list[str],
        diagnoses: list[dict[str, Any]],
        prediction: dict[str, Any],
        checklist: dict[str, Any],
        score: dict[str, Any],
        hypotheses: list[dict[str, Any]],
        evidence_refs: list[str],
    ) -> dict[str, Any]:
        config = self.settings.learning.cie
        provider_id = str(getattr(self.provider, "provider_id", "none") if self.provider is not None else "none")
        summary = {
            "enabled": bool(config.allow_provider_diagnosis and config.allow_candidate_proposals),
            "provider_id": provider_id,
            "requested": 0,
            "accepted": 0,
            "rejected": 0,
        }
        if not summary["enabled"]:
            return {"interventions": [], "warnings": [], "summary": summary}
        if self.provider is None:
            return {"interventions": [], "warnings": ["CIE provider proposals unavailable: no provider configured"], "summary": summary}

        prompt = _provider_proposal_prompt(
            target=target,
            task=task,
            paths=paths,
            diagnoses=diagnoses,
            prediction=prediction,
            checklist=checklist,
            score=score,
            hypotheses=hypotheses,
        )
        try:
            raw = self.provider.complete(
                prompt=prompt,
                role="cie_candidate_proposer",
                schema=PROVIDER_PROPOSAL_SCHEMA,
                model_family=self.model_family,
                budget_tokens=self.budget_tokens,
            )
        except Exception as exc:  # noqa: BLE001
            self.store.write_learning_event(
                phase="cie",
                kind="cie_provider_candidate_failed",
                ref=target,
                payload={"provider_id": provider_id, "reason": type(exc).__name__},
            )
            return {
                "interventions": [],
                "warnings": ["CIE provider proposals unavailable: provider call failed"],
                "summary": summary,
            }
        if raw is None:
            return {"interventions": [], "warnings": [], "summary": summary}
        if not isinstance(raw, dict) or not isinstance(raw.get("interventions"), list):
            summary["rejected"] = 1
            return {
                "interventions": [],
                "warnings": ["CIE provider proposal rejected: invalid_schema"],
                "summary": summary,
            }

        existing_hypothesis_ids = {
            str(item.get("hypothesis_id")) for item in hypotheses if item.get("hypothesis_id")
        }
        allowed_evidence_refs = {str(ref) for ref in evidence_refs}
        accepted: list[dict[str, Any]] = []
        warnings: list[str] = []
        seen: set[str] = set()
        requested = raw.get("interventions") or []
        summary["requested"] = len(requested)
        remaining = max(0, int(config.max_interventions_per_cycle) - 1)
        for index, item in enumerate(requested):
            normalized = _normalize_provider_intervention(
                item,
                index=index,
                provider_id=provider_id,
                existing_hypothesis_ids=existing_hypothesis_ids,
                allowed_evidence_refs=allowed_evidence_refs,
            )
            if not normalized["ok"]:
                summary["rejected"] += 1
                reason = normalized["reason"]
                warnings.append(f"CIE provider proposal rejected: {reason}")
                self.store.write_learning_event(
                    phase="cie",
                    kind="cie_provider_candidate_rejected",
                    ref=target,
                    payload={"provider_id": provider_id, "reason": reason},
                )
                continue
            intervention = normalized["intervention"]
            dedupe_key = canonical_json(
                {
                    "kind": intervention["kind"],
                    "summary": intervention["summary"],
                    "hypotheses": intervention["source_hypothesis_ids"],
                }
            )
            if dedupe_key in seen:
                summary["rejected"] += 1
                warnings.append("CIE provider proposal rejected: duplicate")
                continue
            seen.add(dedupe_key)
            accepted.append(intervention)
            self.store.write_learning_event(
                phase="cie",
                kind="cie_provider_candidate_proposed",
                ref=target,
                payload={
                    "provider_id": provider_id,
                    "intervention_id": intervention["intervention_id"],
                    "kind": intervention["kind"],
                    "risk": intervention["risk"],
                },
            )
            if len(accepted) >= remaining:
                break
        summary["accepted"] = len(accepted)
        return {"interventions": accepted, "warnings": warnings, "summary": summary}

    def _snapshot(self, *, memories: int, skills: int, rules: int, patterns: int, hypotheses: int, debt: int) -> CognitiveStateSnapshotRef:
        source_counts = {
            "memories": memories,
            "skills": skills,
            "rules": rules,
            "patterns": patterns,
            "hypotheses": hypotheses,
            "debt": debt,
            "agent_profiles": 1,
        }
        refs = {
            "memory_snapshot_id": deterministic_id("memory_snapshot", memories),
            "skill_snapshot_id": deterministic_id("skill_snapshot", skills),
            "rule_snapshot_id": deterministic_id("rule_snapshot", rules),
            "pattern_snapshot_id": deterministic_id("pattern_snapshot", patterns),
            "hypothesis_snapshot_id": deterministic_id("hypothesis_snapshot", hypotheses),
            "confidence_snapshot_id": deterministic_id("confidence_snapshot", source_counts),
            "debt_snapshot_id": deterministic_id("debt_snapshot", debt),
            "agent_profile_snapshot_id": deterministic_id("agent_profile_snapshot", "unknown"),
        }
        return CognitiveStateSnapshotRef(
            snapshot_id=stable_id(canonical_json(refs), canonical_json(source_counts)),
            source_counts=source_counts,
            source_artifact_versions={key: 1 for key in source_counts},
            **refs,
        )


def _run_to_dict(row: Any) -> dict[str, Any]:
    return {
        "run_id": row["run_id"],
        "target": row["target"],
        "kind": row["kind"],
        "before": _json(row["before_json"]),
        "after": _json(row["after_json"]),
        "train_metrics": _json(row["train_metrics_json"]),
        "holdout_metrics": _json(row["holdout_metrics_json"]),
        "gate_pass": bool(row["gate_pass"]),
        "archived": bool(row["archived"]),
        "promoted": bool(row["promoted"]),
        "created_at": row["created_at"],
    }


def _json(value: str | None) -> Any:
    try:
        return json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}


def _config_dict(config: Any) -> dict[str, Any]:
    if is_dataclass(config):
        return asdict(config)
    return dict(config)


def _counts(signals: dict[str, Any]) -> dict[str, int | bool]:
    return {
        "recent_events": len(signals.get("recent_events", []) or []),
        "recent_runs": len(signals.get("recent_runs", []) or []),
        "empty_database": bool((signals.get("database") or {}).get("empty")),
    }


def _blocked_refs(rows: list[dict[str, Any]]) -> list[str]:
    refs: list[str] = []
    for row in rows:
        text = canonical_json(row).lower()
        if any(token in text for token in ("blocked", "violation", "checkpoint", "security", "rejected")):
            refs.append(str(row.get("event_id") or row.get("run_id") or row.get("ref") or "signal"))
    return refs


def _warnings(settings: Any, signals: dict[str, Any]) -> list[str]:
    warnings: list[str] = []
    if os.environ.get("CTXLAYER_LEARNING_OFF") == "1":
        warnings.append("CTXLAYER_LEARNING_OFF=1; CIE cycle remains read-only")
    if not settings.learning.cie.allow_adoption:
        warnings.append("CIE adoption disabled; interventions are advisory")
    if (signals.get("database") or {}).get("empty"):
        warnings.append("No learning history found; report is provisional")
    return warnings


def _first_id(item: dict[str, Any]) -> str | None:
    for key, value in item.items():
        if key.endswith("_id") and value:
            return str(value)
    return None


def _safe_call(fn: Any, default: Any) -> Any:
    try:
        return fn()
    except Exception:
        return default


def _provider_proposal_prompt(
    *,
    target: str,
    task: str,
    paths: list[str],
    diagnoses: list[dict[str, Any]],
    prediction: dict[str, Any],
    checklist: dict[str, Any],
    score: dict[str, Any],
    hypotheses: list[dict[str, Any]],
) -> str:
    compact_diagnoses = [
        _compact_mapping(
            item,
            [
                "classification_id",
                "root_cause_id",
                "pattern_id",
                "hypothesis_id",
                "debt_id",
                "category",
                "root_cause",
                "pattern_type",
                "status",
                "confidence",
                "score",
            ],
        )
        for item in diagnoses[:20]
    ]
    compact_hypotheses = [
        _compact_mapping(
            item,
            ["hypothesis_id", "pattern_id", "statement", "status", "confidence"],
        )
        for item in hypotheses[:10]
    ]
    payload = {
        "target": target,
        "task": task,
        "paths": [str(path) for path in paths[:20]],
        "diagnosis_summary": compact_diagnoses,
        "hypotheses": compact_hypotheses,
        "prediction": _compact_mapping(
            prediction,
            [
                "prediction_id",
                "task_type",
                "likely_failure_modes",
                "recommended_behavior",
                "task_complexity_score",
                "complexity_band",
                "confidence",
                "provisional",
            ],
        ),
        "checklist": {
            "checklist_id": checklist.get("checklist_id"),
            "task_type": checklist.get("task_type"),
            "items": [
                _compact_mapping(item, ["id", "text", "severity", "source"])
                for item in (checklist.get("items") or [])[:10]
                if isinstance(item, dict)
            ],
        },
        "score": _compact_mapping(
            score,
            ["score_id", "score", "delta", "components", "sample_size", "confidence", "provisional"],
        ),
        "allowed_intervention_kinds": sorted(PROVIDER_ALLOWED_INTERVENTION_KINDS),
        "allowed_risks": sorted(PROVIDER_ALLOWED_RISKS),
    }
    return "\n".join(
        [
            "Propose bounded Cognitive Improvement Engine candidate interventions.",
            "Return strict JSON only with an interventions array matching the provided schema.",
            "Use only the sanitized summary below. Do not request raw diffs, prompts, holdout answers, canary fixtures, red-team fixtures, secrets, or private source text.",
            "Every proposal must be advisory until an existing CTX Layer delegate and approval gate adopts it.",
            "Do not propose bypassing audit, security, CI, tests, governance, human approval, or existing learning gates.",
            canonical_json(payload),
        ]
    )


def _normalize_provider_intervention(
    raw: Any,
    *,
    index: int,
    provider_id: str,
    existing_hypothesis_ids: set[str],
    allowed_evidence_refs: set[str],
) -> dict[str, Any]:
    if not isinstance(raw, dict):
        return {"ok": False, "reason": "non_object"}
    kind = str(raw.get("kind") or "").strip().lower()
    if kind not in PROVIDER_ALLOWED_INTERVENTION_KINDS:
        return {"ok": False, "reason": "unsupported_kind"}
    risk = str(raw.get("risk") or "medium").strip().lower()
    if risk not in PROVIDER_ALLOWED_RISKS:
        return {"ok": False, "reason": "unsupported_risk"}
    summary = _clean_provider_text(raw.get("summary"), limit=240)
    rationale = _clean_provider_text(raw.get("rationale"), limit=600)
    if not summary or not rationale:
        return {"ok": False, "reason": "missing_summary_or_rationale"}
    lowered = f"{summary} {rationale}".lower()
    if any(phrase in lowered for phrase in PROVIDER_PROTECTED_TEXT):
        return {"ok": False, "reason": "protected_text"}

    source_hypothesis_ids = [
        item
        for item in _string_list(raw.get("source_hypothesis_ids"), limit=10)
        if item in existing_hypothesis_ids
    ]
    evidence_refs = [
        item
        for item in _string_list(raw.get("evidence_refs"), limit=10)
        if item in allowed_evidence_refs
    ]
    rollback_conditions = _string_list(raw.get("rollback_conditions"), limit=5)
    if not rollback_conditions:
        rollback_conditions = _default_rollback_conditions(kind)
    suspension_conditions = _string_list(raw.get("suspension_conditions"), limit=5)
    if not suspension_conditions:
        suspension_conditions = _default_suspension_conditions(kind)
    rollback_action = str(raw.get("rollback_action") or "manual_only").strip()
    if rollback_action not in PROVIDER_ALLOWED_ROLLBACK_ACTIONS:
        rollback_action = "manual_only"
    intervention = InterventionRecord(
        intervention_id=deterministic_id(
            "provider_intervention",
            provider_id,
            index,
            kind,
            summary,
            source_hypothesis_ids,
        ),
        kind=kind,
        status="proposed",
        summary=summary,
        source_hypothesis_ids=source_hypothesis_ids,
        risk=risk,
        gates={
            "config": True,
            "dry_run_preview": True,
            "security_policy": True,
            "provider_candidate": True,
            "delegated_adoption_required": kind != "report",
        },
        rollback_conditions=rollback_conditions,
        suspension_conditions=suspension_conditions,
        rollback_action=rollback_action,
        rollback_status="monitoring" if kind != "report" else "not_applicable",
        evidence_refs=evidence_refs,
        created_by_agent_id=provider_id,
    )
    payload = to_json_dict(intervention)
    return {"ok": True, "intervention": payload}


def _compact_mapping(item: dict[str, Any], keys: list[str]) -> dict[str, Any]:
    if not isinstance(item, dict):
        return {}
    return {key: item[key] for key in keys if key in item and item[key] not in (None, "", [], {})}


def _clean_provider_text(value: Any, *, limit: int) -> str:
    if not isinstance(value, str):
        return ""
    text = " ".join(value.strip().split())
    return text[:limit]


def _string_list(value: Any, *, limit: int) -> list[str]:
    if not isinstance(value, list):
        return []
    result: list[str] = []
    for item in value:
        if isinstance(item, str):
            text = " ".join(item.strip().split())
            if text:
                result.append(text[:200])
        if len(result) >= limit:
            break
    return result


def _default_rollback_conditions(kind: str) -> list[str]:
    if kind == "checklist":
        return ["checklist compliance worsens after adoption", "related failure recurrence increases"]
    if kind == "memory":
        return ["memory candidate fails validation", "reviewer rejects the candidate"]
    if kind == "skill":
        return ["skill replay fails", "related task success rate regresses"]
    if kind == "optimizer":
        return ["holdout gate regresses", "Cognitive Improvement Score component regresses"]
    if kind == "selfmod":
        return ["selfmod validation fails", "benchmark, judge, or canary gate fails"]
    return ["reviewer rejects the intervention", "related failure recurrence increases"]


def _default_suspension_conditions(kind: str) -> list[str]:
    if kind in {"selfmod", "config"}:
        return ["required approval is missing", "security policy blocks the intervention"]
    return ["prediction accuracy regresses", "false-learning check becomes suspected_false_learning"]
