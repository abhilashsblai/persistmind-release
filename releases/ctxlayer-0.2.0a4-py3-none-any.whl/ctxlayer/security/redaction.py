from __future__ import annotations

import re
from typing import Any

from ctxlayer.security.secret_scan import redact_text_with_summary

PII_PATTERNS: dict[str, re.Pattern[str]] = {
    "email": re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
    "phone": re.compile(r"\b(?:\+?\d[\d .()-]{7,}\d)\b"),
    "ssn": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    "credit_card": re.compile(r"\b(?:\d[ -]*?){13,16}\b"),
    "ip_address": re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),
}


def redact_text(text: str) -> str:
    return redact_with_summary(text)[0]


def redact_with_summary(text: str) -> tuple[str, dict[str, Any]]:
    redacted = text
    pii_types: list[str] = []
    redacted_count = 0
    for kind, pattern in PII_PATTERNS.items():
        matches = list(pattern.finditer(redacted))
        if not matches:
            continue
        pii_types.append(kind)
        redacted_count += len(matches)
        redacted = pattern.sub(f"[REDACTED_{kind.upper()}]", redacted)
    redacted, secret_summary = redact_text_with_summary(redacted)
    secret_count = int(secret_summary.get("secret_count", 0) or 0)
    return redacted, {
        "pii_types": sorted(set(pii_types)),
        "secret_kinds": secret_summary.get("secret_kinds", []),
        "redacted_count": redacted_count + secret_count,
        "pii_count": redacted_count,
        "secret_count": secret_count,
    }


__all__ = ["redact_text", "redact_with_summary"]
