"""Privacy-safe, per-project metrics rollup.

This produces a small JSON document summarising how CTX Layer is performing on a
single installed project: agent-benchmark lift, outcome success rates, learning
activity, and the numeric parameter regime currently promoted. It is designed to
be collected manually from each deployment and compared across projects.

By construction the rollup contains ONLY:
  * opaque identifiers (sha256-derived ``project_id``/``repo_id``)
  * an optional human ``label`` the operator chose to attach
  * numeric metrics and scalar (numeric/boolean) parameter values
  * status/kind counts

It never contains file paths, source code, rule/skill text, task text, error
strings, or any other free-form content harvested from the target repository.
That allowlist is enforced in code (see ``_scalars``), not by convention, so a
schema change elsewhere cannot silently start leaking text.
"""

from __future__ import annotations

import json
from typing import Any

from ctxlayer.store import SQLiteStore

SCHEMA = "ctxlayer.metrics-rollup/v1"

# Numeric lift fields on agent_benchmark_run that are safe to surface verbatim.
_BENCHMARK_NUMERIC_FIELDS = (
    "cases",
    "success_rate_delta",
    "tests_pass_rate_delta",
    "wrong_files_touched_reduction",
    "missing_files_reduction",
    "agent_seconds_reduction",
    "memory_score",
    "context_retrieval_score",
)


def _scalars(value: Any) -> Any:
    """Recursively keep only numeric/boolean leaves.

    Dict keys are preserved (they are parameter names like ``lexical_weight``),
    but any string/None/text leaf is dropped so no free-form content escapes.
    """
    if isinstance(value, bool) or isinstance(value, (int, float)):
        return value
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            cleaned = _scalars(item)
            if cleaned is not None:
                out[str(key)] = cleaned
        return out or None
    if isinstance(value, list):
        cleaned = [item for item in (_scalars(v) for v in value) if item is not None]
        return cleaned or None
    return None


class MetricsRollup:
    """Builds a per-project rollup from the local workspace store.

    Every section is computed defensively: a missing table or older schema on a
    given install degrades to an empty section plus an entry in ``errors`` rather
    than aborting the whole rollup, since this runs across heterogeneous
    deployments.
    """

    def __init__(
        self,
        store: SQLiteStore,
        *,
        project_id: str,
        repo_id: str | None,
        label: str | None,
        version: str,
        generated_at: str,
        scale: dict[str, Any],
        limit: int = 30,
    ) -> None:
        self.store = store
        self.project_id = project_id
        self.repo_id = repo_id
        self.label = label
        self.version = version
        self.generated_at = generated_at
        self.scale = scale
        self.limit = limit
        self._errors: list[str] = []

    def data(self) -> dict[str, Any]:
        return {
            "schema": SCHEMA,
            "ok": True,
            "generated_at": self.generated_at,
            "ctxlayer_version": self.version,
            "project": {
                "project_id": self.project_id,
                "repo_id": self.repo_id,
                "label": self.label,
            },
            "scale": self.scale,
            "outcomes": self._section(self._outcomes),
            "benchmark": self._section(self._benchmark),
            "efficacy": self._section(self._efficacy),
            "intent": self._section(self._intent),
            "goals": self._section(self._goals),
            "extraction_quality": self._section(self._extraction_quality),
            "semantic_quality": self._section(self._semantic_quality),
            "business_graph": self._section(self._business_graph),
            "org_ingestion": self._section(self._org_ingestion),
            "decisions": self._section(self._decisions),
            "concurrency": self._section(self._concurrency),
            "loop_security": self._section(self._loop_security),
            "learning": self._section(self._learning),
            "memory": self._section(self._memory),
            "guardrails": self._section(self._guardrails),
            "skills": self._section(self._skills),
            "errors": self._errors,
        }

    def _section(self, builder: Any) -> dict[str, Any]:
        try:
            return builder()
        except (
            Exception
        ) as exc:  # noqa: BLE001 - one weak section must not sink the rollup.
            self._errors.append(f"{builder.__name__}: {exc}")
            return {}

    def _outcomes(self) -> dict[str, Any]:
        # The raw result column can carry a free-text suffix (e.g.
        # "fail: check-diff reported ..."); normalise to a fixed bucket set so
        # no operator-supplied text leaks into the rollup.
        rows = self.store.conn.execute(
            "SELECT result, COUNT(*) AS count FROM outcomes GROUP BY result"
        ).fetchall()
        by_result: dict[str, int] = {}
        for row in rows:
            bucket = _normalize_result(row["result"])
            by_result[bucket] = by_result.get(bucket, 0) + int(row["count"])
        total = sum(by_result.values())
        passed = by_result.get("pass", 0)
        return {
            "total": total,
            "by_result": by_result,
            "success_rate": round(passed / total, 6) if total else 0.0,
        }

    def _benchmark(self) -> dict[str, Any]:
        rows = self.store.agent_benchmark_runs(limit=self.limit)
        runs = [
            {field: _coerce(row[field]) for field in _BENCHMARK_NUMERIC_FIELDS}
            for row in rows
        ]
        for run, row in zip(runs, rows):
            run["gate_ok"] = None if row["gate_ok"] is None else bool(row["gate_ok"])
        summary: dict[str, Any] = {"count": len(runs)}
        if runs:
            latest, oldest = runs[0], runs[-1]
            summary["latest_success_rate_delta"] = latest["success_rate_delta"]
            summary["latest_context_retrieval_score"] = latest[
                "context_retrieval_score"
            ]
            summary["latest_memory_score"] = latest["memory_score"]
            summary["success_rate_delta_change"] = round(
                latest["success_rate_delta"] - oldest["success_rate_delta"], 6
            )
        return {"summary": summary, "trend": runs}

    def _efficacy(self) -> dict[str, Any]:
        rows = self.store.efficacy_scorecards(repo_id=self.repo_id, limit=self.limit)
        trend = []
        by_gate_status: dict[str, int] = {}
        for row in rows:
            report = _load_json(row["report_json"])
            item = _efficacy_rollup_row(report)
            trend.append(item)
            status = _fixed_status(
                row["gate_status"] or _dict(report.get("gate")).get("status")
            )
            by_gate_status[status] = by_gate_status.get(status, 0) + 1
        summary: dict[str, Any] = {
            "count": len(trend),
            "by_gate_status": by_gate_status,
        }
        if trend:
            latest = trend[0]
            summary.update(
                {
                    "latest_gate_pass": latest["gate_pass"],
                    "latest_context_recall": latest["context_recall"],
                    "latest_impact_prediction_f1": latest["impact_prediction_f1"],
                    "latest_out_of_scope_edit_rate_delta": latest[
                        "out_of_scope_edit_rate_delta"
                    ],
                    "latest_hallucination_incident_delta": latest[
                        "hallucination_incident_delta"
                    ],
                    "latest_pack_deterministic": latest["pack_deterministic"],
                    "latest_loop_verified": latest["loop_verified"],
                    "latest_latency_p95_ms": latest["latency_p95_ms"],
                }
            )
        return {"summary": summary, "trend": trend}

    def _learning(self) -> dict[str, Any]:
        rows = self.store.conn.execute(
            """
            SELECT target, kind, COUNT(*) AS runs,
                   SUM(promoted) AS promoted, SUM(gate_pass) AS gate_pass
            FROM learning_run
            GROUP BY target, kind
            """
        ).fetchall()
        by_target: dict[str, Any] = {}
        runs_total = promoted_total = gate_pass_total = 0
        for row in rows:
            target = str(row["target"])
            runs = int(row["runs"] or 0)
            promoted = int(row["promoted"] or 0)
            gate_pass = int(row["gate_pass"] or 0)
            runs_total += runs
            promoted_total += promoted
            gate_pass_total += gate_pass
            bucket = by_target.setdefault(
                target, {"runs": 0, "promoted": 0, "gate_pass": 0}
            )
            bucket["runs"] += runs
            bucket["promoted"] += promoted
            bucket["gate_pass"] += gate_pass
        promoted_parameters: dict[str, Any] = {}
        for row in self.store.promoted_learning_runs():
            # Self-modification runs carry code patches in after_json; never emit them.
            if row["kind"] == "selfmod_variant":
                continue
            params = _scalars(_load_json(row["after_json"]))
            if params:
                promoted_parameters[str(row["target"])] = params
        task_rows = self.store.task_learning_summaries(limit=self.limit)
        task_counts = {
            "tasks_consolidated": len(task_rows),
            "memories_proposed": 0,
            "memories_promoted": 0,
            "conflicts_found": 0,
            "stale_marked": 0,
        }
        for row in task_rows:
            counts = _load_json(row["counts_json"])
            task_counts["memories_proposed"] += int(
                counts.get("memories_proposed", 0) or 0
            )
            task_counts["memories_promoted"] += int(
                counts.get("memories_promoted", 0) or 0
            )
            task_counts["conflicts_found"] += int(counts.get("conflicts_found", 0) or 0)
            task_counts["stale_marked"] += int(counts.get("stale_marked", 0) or 0)
        return {
            "runs_total": runs_total,
            "promoted_total": promoted_total,
            "gate_pass_rate": (
                round(gate_pass_total / runs_total, 6) if runs_total else 0.0
            ),
            "by_target": by_target,
            "promoted_parameters": promoted_parameters,
            "task_learning": task_counts,
        }

    def _concurrency(self) -> dict[str, Any]:
        stats = self.store.concurrency_stats(repo_id=self.repo_id)
        audit = stats.get("audit") or {}
        return {
            "active_leases": int(stats.get("active_leases", 0) or 0),
            "open_conflicts": int(stats.get("open_conflicts", 0) or 0),
            "audit_height": int(audit.get("height", 0) or 0),
        }

    def _loop_security(self) -> dict[str, Any]:
        events = self.store.learning_events(limit=self.limit)
        loop = []
        redteam = []
        for row in events:
            if row["phase"] != "phase_h4":
                continue
            payload = _load_json(row["payload_json"])
            if row["kind"] == "loop_verify_run":
                loop.append(payload)
            elif row["kind"] == "redteam_run":
                redteam.append(payload)
        latest_redteam = redteam[0] if redteam else {}
        return {
            "loop_verify_runs": len(loop),
            "loop_closed_runs": sum(
                1
                for item in loop
                if bool(item.get("attributable") or item.get("gate_closed"))
            ),
            "redteam_runs": len(redteam),
            "redteam_latest_ok": bool(latest_redteam.get("ok")),
            "redteam_served_authoritative_count": int(
                latest_redteam.get("served_authoritative_count", 0) or 0
            ),
            "redteam_false_quarantine_rate": float(
                latest_redteam.get("false_quarantine_rate", 0.0) or 0.0
            ),
        }

    def _intent(self) -> dict[str, Any]:
        total = int(
            self.store.conn.execute("SELECT COUNT(*) AS count FROM intents").fetchone()[
                "count"
            ]
        )
        refined = int(
            self.store.conn.execute(
                "SELECT COUNT(*) AS count FROM intents WHERE selected_goal_id IS NOT NULL"
            ).fetchone()["count"]
        )
        nodes = self.store.conn.execute(
            """
            SELECT origin, status, COUNT(*) AS count
            FROM intent_decomposition_nodes
            GROUP BY origin, status
            """
        ).fetchall()
        by_node_origin: dict[str, int] = {}
        by_node_status: dict[str, int] = {}
        for row in nodes:
            origin = _fixed_origin(row["origin"])
            status = _fixed_node_status(row["status"])
            count = int(row["count"] or 0)
            by_node_origin[origin] = by_node_origin.get(origin, 0) + count
            by_node_status[status] = by_node_status.get(status, 0) + count
        hypothesis_rows = self.store.conn.execute(
            """
            SELECT COUNT(DISTINCT intent_id) AS count
            FROM intent_hypotheses
            WHERE evidence_refs_json != '[]'
            """
        ).fetchone()
        open_questions = int(
            self.store.conn.execute(
                "SELECT COUNT(*) AS count FROM intent_open_questions"
            ).fetchone()["count"]
        )
        packs = int(
            self.store.conn.execute(
                """
                SELECT COUNT(*) AS count
                FROM context_packs
                WHERE metadata_json LIKE '%intent_id%'
                """
            ).fetchone()["count"]
        )
        node_total = sum(by_node_origin.values())
        return {
            "total": total,
            "refined": refined,
            "conversion_packs": packs,
            "with_evidence_linked_hypothesis": int(hypothesis_rows["count"] or 0),
            "open_questions": open_questions,
            "open_question_rate": round(open_questions / total, 6) if total else 0.0,
            "by_node_origin": by_node_origin,
            "by_node_status": by_node_status,
            "deterministic_node_rate": (
                round(by_node_origin.get("deterministic", 0) / node_total, 6)
                if node_total
                else 0.0
            ),
        }

    def _goals(self) -> dict[str, Any]:
        total = int(
            self.store.conn.execute("SELECT COUNT(*) AS count FROM goals").fetchone()[
                "count"
            ]
        )
        by_status_rows = self.store.conn.execute(
            "SELECT status, COUNT(*) AS count FROM goals GROUP BY status"
        ).fetchall()
        by_mode_rows = self.store.conn.execute(
            "SELECT permission_mode, COUNT(*) AS count FROM goals GROUP BY permission_mode"
        ).fetchall()
        decisions = self.store.conn.execute(
            "SELECT kind, COUNT(*) AS count FROM goal_decisions GROUP BY kind"
        ).fetchall()
        alternatives = self.store.conn.execute(
            "SELECT status, COUNT(*) AS count FROM goal_alternatives GROUP BY status"
        ).fetchall()
        challenges = sum(
            int(row["count"] or 0)
            for row in decisions
            if str(row["kind"]) == "challenge_emitted"
        )
        accepted = sum(
            int(row["count"] or 0)
            for row in decisions
            if str(row["kind"]) == "alternative_accepted"
        )
        downgraded = int(
            self.store.conn.execute(
                """
                SELECT COUNT(*) AS count
                FROM goals
                WHERE metadata_json LIKE '%"downgraded":true%'
                """
            ).fetchone()["count"]
        )
        return {
            "total": total,
            "by_status": {
                str(row["status"]): int(row["count"]) for row in by_status_rows
            },
            "by_permission_mode": {
                str(row["permission_mode"]): int(row["count"]) for row in by_mode_rows
            },
            "decisions_by_kind": {
                str(row["kind"]): int(row["count"]) for row in decisions
            },
            "alternatives_by_status": {
                str(row["status"]): int(row["count"]) for row in alternatives
            },
            "challenges_emitted": challenges,
            "alternatives_accepted": accepted,
            "challenge_accept_rate": (
                round(accepted / challenges, 6) if challenges else 0.0
            ),
            "auto_downgraded": downgraded,
        }

    def _memory(self) -> dict[str, Any]:
        rows = self.store.conn.execute(
            "SELECT status, COUNT(*) AS count FROM memory_records GROUP BY status"
        ).fetchall()
        return {"by_status": {str(row["status"]): int(row["count"]) for row in rows}}

    def _guardrails(self) -> dict[str, Any]:
        directives = self.store.conn.execute(
            """
            SELECT status, enforcement_level, severity, COUNT(*) AS count
            FROM memory_enforcement
            GROUP BY status, enforcement_level, severity
            """
        ).fetchall()
        events = self.store.conn.execute(
            """
            SELECT kind, COUNT(*) AS count
            FROM learning_event
            WHERE kind IN (
              'guardrail_decision',
              'guardrail_override',
              'guardrail_degraded',
              'directive_suspended'
            )
            GROUP BY kind
            """
        ).fetchall()
        by_status: dict[str, int] = {}
        by_level: dict[str, int] = {}
        by_severity: dict[str, int] = {}
        for row in directives:
            by_status[str(row["status"])] = (
                by_status.get(str(row["status"]), 0) + int(row["count"])
            )
            by_level[str(row["enforcement_level"])] = (
                by_level.get(str(row["enforcement_level"]), 0) + int(row["count"])
            )
            by_severity[str(row["severity"])] = (
                by_severity.get(str(row["severity"]), 0) + int(row["count"])
            )
        return {
            "directives": {
                "total": sum(by_status.values()),
                "by_status": by_status,
                "by_level": by_level,
                "by_severity": by_severity,
            },
            "events": {str(row["kind"]): int(row["count"]) for row in events},
        }

    def _extraction_quality(self) -> dict[str, Any]:
        rows = self.store.extraction_eval_results(
            repo_id=self.repo_id, limit=self.limit * 10
        )
        latest_by_source: dict[str, dict[str, Any]] = {}
        for row in rows:
            source = str(row["source_type"])
            if source in latest_by_source:
                continue
            latest_by_source[source] = {
                "precision": _number(row["precision"]),
                "recall": _number(row["recall"]),
                "f1": _number(row["f1"]),
                "true_positive": int(row["true_positive"] or 0),
                "false_positive": int(row["false_positive"] or 0),
                "false_negative": int(row["false_negative"] or 0),
            }
        calibration_rows = self.store.conn.execute(
            """
            SELECT * FROM trust_calibration
            WHERE repo_id = ? OR ? IS NULL
            ORDER BY computed_at DESC
            """,
            (self.repo_id, self.repo_id),
        ).fetchall()
        calibration: dict[str, dict[str, Any]] = {}
        for row in calibration_rows:
            source = str(row["source_type"])
            if source in calibration:
                continue
            calibration[source] = {
                "approval_rate": _number(row["approval_rate"]),
                "sample_size": int(row["sample_size"] or 0),
                "confidence_floor": _number(row["confidence_floor"]),
                "prior_fallback": str(row["method"]) == "prior_fallback",
            }
        sources = sorted(set(latest_by_source) | set(calibration))
        by_source = {
            source: {**latest_by_source.get(source, {}), **calibration.get(source, {})}
            for source in sources
        }
        lowest_precision = min(
            (_number(item.get("precision")) for item in by_source.values()),
            default=0.0,
        )
        low_sample_count = sum(
            1
            for item in by_source.values()
            if item.get("prior_fallback") or int(item.get("sample_size") or 0) < 5
        )
        return {
            "source_count": len(by_source),
            "lowest_precision": lowest_precision,
            "low_sample_source_count": low_sample_count,
            "by_source": by_source,
        }

    def _semantic_quality(self) -> dict[str, Any]:
        graph = self.store.graph_stats(self.repo_id)
        latest = graph.get("semantic_accuracy_latest") or {}
        metrics = latest.get("metrics") or {}
        overall_nodes = (metrics.get("nodes") or {}).get("overall") or {}
        overall_edges = (metrics.get("edges") or {}).get("overall") or {}
        confidence = graph.get("semantic_confidence_distribution") or {}
        drift = graph.get("semantic_drift_findings") or {}
        return {
            "latest_accuracy_passed": bool(latest.get("passed")) if latest else False,
            "node_precision": _number(overall_nodes.get("precision")),
            "node_recall": _number(overall_nodes.get("recall")),
            "edge_precision": _number(overall_edges.get("precision")),
            "edge_recall": _number(overall_edges.get("recall")),
            "confidence_distribution": _scalars(confidence) or {},
            "drift_findings": _scalars(drift) or {},
        }

    def _business_graph(self) -> dict[str, Any]:
        graph = self.store.graph_stats(self.repo_id)
        business = graph.get("business_graph") or {}
        active_by_type = _scalars(business.get("active_nodes_by_type") or {})
        by_status = _scalars(business.get("nodes_by_status") or {})
        approvals = _scalars(business.get("approval_funnel") or {})
        return {
            "active_nodes": int(
                sum(int(value or 0) for value in active_by_type.values())
            ),
            "pending_candidates": int(by_status.get("candidate", 0) or 0),
            "rejected_nodes": int(by_status.get("rejected", 0) or 0),
            "active_business_edges": int(business.get("active_business_edges", 0) or 0),
            "active_nodes_by_type": active_by_type,
            "nodes_by_status": by_status,
            "approval_funnel": approvals,
        }

    def _org_ingestion(self) -> dict[str, Any]:
        graph = self.store.graph_stats(self.repo_id)
        org = graph.get("org_ingestion") or {}
        return {
            "runs": int(org.get("runs", 0) or 0),
            "items_seen": int(org.get("items_seen", 0) or 0),
            "items_quarantined": int(org.get("items_quarantined", 0) or 0),
            "items_rejected": int(org.get("items_rejected", 0) or 0),
            "redactions": int(org.get("redactions", 0) or 0),
            "remote_used": int(org.get("remote_used", 0) or 0),
            "candidates_by_status": _scalars(org.get("candidates_by_status") or {}),
            "candidates_by_source": _scalars(org.get("candidates_by_source") or {}),
        }

    def _decisions(self) -> dict[str, Any]:
        rows = self.store.list_decisions(repo_id=self.repo_id, limit=self.limit)
        by_status: dict[str, int] = {}
        recommendation_count = 0
        no_recommendation = 0
        decided = 0
        agreed = 0
        confidence_total = 0.0
        confidence_count = 0
        unknowns = 0
        gaps = 0
        low_trust_inputs = 0
        for row in rows:
            by_status[str(row["status"])] = by_status.get(str(row["status"]), 0) + 1
            briefing = _load_json(row["briefing_json"])
            recommendation = _dict(briefing.get("recommendation"))
            if recommendation:
                if recommendation.get("option_id"):
                    recommendation_count += 1
                else:
                    no_recommendation += 1
                confidence_total += _number(recommendation.get("confidence"))
                confidence_count += 1
                gaps += len(recommendation.get("gaps") or [])
                low_trust_inputs += len(recommendation.get("low_trust_inputs") or [])
            for option in briefing.get("options") or []:
                if isinstance(option, dict):
                    unknowns += len(option.get("unknowns") or [])
            human = _load_json(row["human_decision_json"])
            if human:
                decided += 1
                if bool(human.get("agreed_with_recommendation")):
                    agreed += 1
        return {
            "total": len(rows),
            "by_status": by_status,
            "recommendations": recommendation_count,
            "declined_recommendations": no_recommendation,
            "decided": decided,
            "agreed_with_recommendation": agreed,
            "agreement_rate": round(agreed / decided, 6) if decided else 0.0,
            "avg_recommendation_confidence": (
                round(confidence_total / confidence_count, 6)
                if confidence_count
                else 0.0
            ),
            "unknowns": unknowns,
            "gaps": gaps,
            "low_trust_inputs": low_trust_inputs,
        }

    def _skills(self) -> dict[str, Any]:
        rows = self.store.conn.execute(
            "SELECT status, COUNT(*) AS count FROM skill GROUP BY status"
        ).fetchall()
        by_status = {str(row["status"]): int(row["count"]) for row in rows}
        improvements = self.store.conn.execute(
            """
            SELECT status, COUNT(*) AS count
            FROM skill_improvement_records
            GROUP BY status
            """
        ).fetchall()
        closure = self.store.conn.execute(
            """
            SELECT status, COUNT(*) AS count
            FROM skill_closure_probes
            GROUP BY status
            """
        ).fetchall()
        latest_metrics = self.store.conn.execute(
            """
            SELECT revision_rate, accept_first_pass_rate
            FROM skill_metrics
            ORDER BY measured_at DESC
            LIMIT ?
            """,
            (self.limit,),
        ).fetchall()
        revision_rates = [float(row["revision_rate"] or 0.0) for row in latest_metrics]
        accept_rates = [
            float(row["accept_first_pass_rate"] or 0.0) for row in latest_metrics
        ]
        return {
            "total": sum(by_status.values()),
            "by_status": by_status,
            "improvements_by_status": {
                str(row["status"]): int(row["count"]) for row in improvements
            },
            "closure_by_status": {
                str(row["status"]): int(row["count"]) for row in closure
            },
            "latest_avg_revision_rate": (
                round(sum(revision_rates) / len(revision_rates), 6)
                if revision_rates
                else 0.0
            ),
            "latest_avg_accept_first_pass_rate": (
                round(sum(accept_rates) / len(accept_rates), 6) if accept_rates else 0.0
            ),
        }


_KNOWN_RESULTS = {"pass", "fail", "partial"}


def _normalize_result(value: Any) -> str:
    token = str(value or "").strip().lower()
    # Keep only the leading word, before any ":"/whitespace-delimited detail.
    head = token.replace(":", " ").split()
    head = head[0] if head else ""
    return head if head in _KNOWN_RESULTS else "other"


def _coerce(value: Any) -> float | int:
    if value is None:
        return 0
    if isinstance(value, int):
        return value
    return float(value)


def _load_json(value: str | None) -> Any:
    try:
        return json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}


def _efficacy_rollup_row(report: Any) -> dict[str, Any]:
    payload = report if isinstance(report, dict) else {}
    delta = _dict(payload.get("delta"))
    pack_quality = _dict(payload.get("pack_quality"))
    impact = _dict(pack_quality.get("impact_prediction"))
    determinism = _dict(pack_quality.get("determinism"))
    latency = _dict(pack_quality.get("latency"))
    loop = _dict(payload.get("loop_closure"))
    gate = _dict(payload.get("gate"))
    benchmark = _dict(payload.get("benchmark"))
    return {
        "gate_pass": _fixed_status(gate.get("status")) == "pass",
        "cases": int(benchmark.get("cases") or 0),
        "context_recall": _number(pack_quality.get("context_recall")),
        "impact_prediction_f1": _number(impact.get("f1")),
        "test_selection_precision": _number(
            pack_quality.get("test_selection_precision")
        ),
        "out_of_scope_edit_rate_delta": _number(
            delta.get("out_of_scope_edit_rate_delta")
        ),
        "hallucination_incident_delta": _number(
            delta.get("hallucination_incident_delta")
        ),
        "pack_deterministic": bool(determinism.get("verified")),
        "loop_verified": bool(loop.get("verified")),
        "latency_p95_ms": _number(latency.get("p95_ms")),
    }


def _dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _number(value: Any) -> float:
    try:
        return round(float(value or 0.0), 6)
    except (TypeError, ValueError):
        return 0.0


def _fixed_status(value: Any) -> str:
    token = str(value or "").strip().lower()
    return token if token in {"pass", "fail", "unknown"} else "unknown"


def _fixed_origin(value: Any) -> str:
    token = str(value or "").strip().lower()
    return token if token in {"deterministic", "llm_proposed"} else "unknown"


def _fixed_node_status(value: Any) -> str:
    token = str(value or "").strip().lower()
    return token if token in {"evidence_linked", "unverified"} else "unknown"
