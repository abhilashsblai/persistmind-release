from __future__ import annotations

from typing import Any

from ctxlayer.security.redaction import redact_with_summary


def redact_org_text(raw_text: str) -> tuple[str, dict[str, Any]]:
    redacted, summary = redact_with_summary(raw_text)
    return redacted, {
        "pii_types": summary.get("pii_types", []),
        "secret_kinds": summary.get("secret_kinds", []),
        "redacted_count": int(summary.get("redacted_count", 0) or 0),
        "raw_persisted": False,
    }
