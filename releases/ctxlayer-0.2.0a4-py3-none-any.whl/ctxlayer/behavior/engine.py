from __future__ import annotations

import fnmatch
import re
from pathlib import Path
from typing import Any

from ctxlayer.config import Settings
from ctxlayer.impact import ImpactEngine
from ctxlayer.snapshot import SnapshotInfo
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import stable_id


DESTRUCTIVE_SQL_RE = re.compile(
    r"\b(DROP\s+TABLE|DROP\s+COLUMN|TRUNCATE|DELETE\s+FROM)\b", re.I
)
PUBLIC_CONTRACT_RE = re.compile(
    r"\b(openapi|swagger|graphql|schema|proto|package\.json)\b", re.I
)


class BehaviorEngine:
    def __init__(
        self,
        repo_root: Path,
        store: SQLiteStore,
        settings: Settings,
        impact: ImpactEngine,
    ):
        self.repo_root = repo_root
        self.store = store
        self.settings = settings
        self.impact = impact

    def check(
        self,
        *,
        snapshot: SnapshotInfo,
        paths: list[str],
        diff: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        normalized = sorted(
            {path.replace("\\", "/").removeprefix("./") for path in paths if path}
        )
        impact_report = self.impact.report(
            snapshot=snapshot, paths=normalized, pack_id=pack_id
        )
        findings: list[dict[str, Any]] = []
        for path in normalized:
            protected = self._protection(snapshot.repo_id, path)
            critical = any(
                fnmatch.fnmatch(path, glob)
                for glob in self.settings.eval.critical_paths
            )
            if critical and protected["score"] == 0:
                findings.append(
                    {
                        "type": "characterization_required",
                        "path": path,
                        "severity": "high",
                        "blocking": True,
                        "reason": "Critical path has no linked test coverage; add a characterization test before editing.",
                    }
                )
            if _looks_like_contract(path):
                findings.append(
                    {
                        "type": "contract_compatibility_review",
                        "path": path,
                        "severity": "medium",
                        "blocking": False,
                        "reason": "Public contract changed; check generated clients and consumers.",
                    }
                )
            if path.endswith(".sql") or "migration" in path.lower():
                text = self._diff_for_path(diff or "", path)
                if DESTRUCTIVE_SQL_RE.search(text):
                    findings.append(
                        {
                            "type": "destructive_migration",
                            "path": path,
                            "severity": "critical",
                            "blocking": True,
                            "reason": "Migration contains destructive SQL and requires explicit approval.",
                        }
                    )
        score_components = {
            "impact": impact_report["risk"]["score"],
            "findings": sum(3 if item["blocking"] else 1 for item in findings),
            "critical_paths": len(impact_report["risk"].get("critical_paths", [])) * 2,
        }
        risk_score = min(10.0, round(sum(score_components.values()), 2))
        return {
            "ok": not any(item["blocking"] for item in findings),
            "schema_version": "ctxlayer.behavior_report.v1",
            "behavior_report_id": stable_id(
                snapshot.snapshot_id, normalized, diff or ""
            ),
            "snapshot_id": snapshot.snapshot_id,
            "input_paths": normalized,
            "risk": {"score": risk_score, "components": score_components},
            "protection": [
                self._protection(snapshot.repo_id, path) for path in normalized
            ],
            "findings": findings,
            "impact_report": impact_report,
        }

    def _protection(self, repo_id: str, path: str) -> dict[str, Any]:
        tests = []
        for neighbor in self.store.neighbors(
            repo_id=repo_id,
            node_type="file",
            node_id=path,
            kinds=["tests"],
            direction="in",
        ):
            if neighbor.node_type == "file":
                tests.append(
                    {"path": neighbor.node_id, "confidence": neighbor.confidence}
                )
        return {
            "path": path,
            "score": round(
                min(1.0, sum(float(item["confidence"]) for item in tests)), 3
            ),
            "linked_tests": sorted(tests, key=lambda item: item["path"]),
        }

    def _diff_for_path(self, diff: str, path: str) -> str:
        if not diff:
            target = self.repo_root / path
            return (
                target.read_text(encoding="utf-8", errors="replace")
                if target.exists()
                else ""
            )
        chunks = []
        active = False
        for line in diff.splitlines():
            if line.startswith("diff --git "):
                active = f" b/{path}" in line or f" a/{path}" in line
            if active:
                chunks.append(line)
        return "\n".join(chunks)


def _looks_like_contract(path: str) -> bool:
    return bool(PUBLIC_CONTRACT_RE.search(path.replace("\\", "/")))
