from __future__ import annotations

import json
import sqlite3
import time
from collections.abc import Iterable
from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from typing import Any

from ctxlayer.utils import canonical_json, stable_id, utc_now


@dataclass(frozen=True)
class Neighbor:
    node_type: str
    node_id: str
    repo_id: str
    kind: str
    confidence: float
    metadata: dict[str, Any]


@dataclass(frozen=True)
class Migration:
    version: int
    name: str
    sql: str


class SQLiteStore:
    """SQLite-backed graph store.

    This is intentionally the only module that issues application SQL. Other
    packages use this class rather than depending on table details directly.
    """

    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(db_path))
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.sqlite_vec_loaded = self._try_load_sqlite_vec()

    def _try_load_sqlite_vec(self) -> bool:
        try:
            import sqlite_vec

            self.conn.enable_load_extension(True)
            sqlite_vec.load(self.conn)
        except Exception:
            return False
        finally:
            try:
                self.conn.enable_load_extension(False)
            except Exception:
                pass
        return True

    def capabilities(self) -> dict[str, Any]:
        compile_options = [
            row[0] for row in self.conn.execute("PRAGMA compile_options").fetchall()
        ]
        return {
            "sqlite_version": sqlite3.sqlite_version,
            "wal": True,
            "fts5": any("ENABLE_FTS5" in option for option in compile_options),
            "sqlite_vec": self.sqlite_vec_loaded,
            "vector_store": "sqlite-vec" if self.sqlite_vec_loaded else "json-cosine",
        }

    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> "SQLiteStore":
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def migrate(self) -> None:
        schema = resources.files("ctxlayer.store").joinpath("schema.sql").read_text(encoding="utf-8")
        migrations = [
            Migration(1, "bootstrap_schema", schema),
            Migration(2, "context_pack_metadata_column", "SELECT 1;"),
            Migration(3, "business_memory_v2_columns", "SELECT 1;"),
            Migration(4, "unified_memory_tables", "SELECT 1;"),
            Migration(5, "cognitive_memory_tables", "SELECT 1;"),
            Migration(6, "constitution_governance_tables", "SELECT 1;"),
            Migration(7, "structured_task_plan_tables", "SELECT 1;"),
            Migration(8, "learning_substrate_phase0", "SELECT 1;"),
            Migration(9, "memory_os_foundation", "SELECT 1;"),
        ]
        with self.conn:
            self.conn.executescript(schema)
            for migration in migrations:
                existing = self.conn.execute(
                    "SELECT checksum FROM schema_migrations WHERE version = ?",
                    (migration.version,),
                ).fetchone()
                checksum = stable_id(migration.name, migration.sql)
                if existing:
                    continue
                if migration.version == 2:
                    self._ensure_column(
                        "context_packs", "metadata_json", "TEXT NOT NULL DEFAULT '{}'"
                    )
                elif migration.version == 3:
                    self._ensure_column("business_rules", "supersedes_rule_id", "TEXT")
                    self._ensure_column("business_rules", "updated_at", "TEXT")
                    self._ensure_column("business_rule_evidence", "repo_id", "TEXT")
                    self._ensure_column("business_rule_evidence", "evidence_kind", "TEXT")
                    self._ensure_column("business_rule_evidence", "evidence_hash", "TEXT")
                    self._ensure_column("business_rule_evidence", "line_start", "INTEGER")
                    self._ensure_column("business_rule_evidence", "line_end", "INTEGER")
                elif migration.version == 4:
                    self._seed_memory_decay_policies()
                elif migration.version == 8:
                    self._ensure_learning_substrate()
                elif migration.version == 9:
                    self._ensure_memory_os_schema()
                elif migration.version in {5, 6, 7}:
                    pass
                else:
                    self.conn.executescript(migration.sql)
                self.conn.execute(
                    """
                    INSERT OR IGNORE INTO schema_migrations(version, name, applied_at, checksum)
                    VALUES (?, ?, ?, ?)
                    """,
                    (migration.version, migration.name, utc_now(), checksum),
                )
            self._ensure_learning_substrate()
            self._ensure_memory_os_schema()
            self.deduplicate_edges()

    def _ensure_column(self, table: str, column: str, definition: str) -> None:
        existing = {
            row["name"]
            for row in self.conn.execute(f"PRAGMA table_info({table})").fetchall()
        }
        if column not in existing:
            try:
                self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
            except sqlite3.OperationalError as exc:
                if "duplicate column name" not in str(exc).lower():
                    raise

    def _ensure_learning_substrate(self) -> None:
        self._ensure_column("memory_records", "trust", "TEXT NOT NULL DEFAULT 'candidate'")
        self._ensure_column(
            "memory_records", "provenance_json", "TEXT NOT NULL DEFAULT '{}'"
        )
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS learning_candidate (
              candidate_id TEXT PRIMARY KEY,
              kind TEXT NOT NULL,
              payload_json TEXT NOT NULL,
              provenance_json TEXT NOT NULL DEFAULT '{}',
              confidence REAL NOT NULL DEFAULT 0.0,
              status TEXT NOT NULL DEFAULT 'candidate',
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_learning_candidate_status
              ON learning_candidate(kind, status, created_at);

            CREATE TABLE IF NOT EXISTS skill (
              skill_id TEXT PRIMARY KEY,
              name TEXT NOT NULL,
              nl_description TEXT NOT NULL,
              trigger_signature TEXT NOT NULL,
              steps_json TEXT NOT NULL DEFAULT '[]',
              evidence_json TEXT NOT NULL DEFAULT '[]',
              embedding_ref TEXT,
              provenance_json TEXT NOT NULL DEFAULT '{}',
              success_count INTEGER NOT NULL DEFAULT 0,
              fail_count INTEGER NOT NULL DEFAULT 0,
              last_validated_at TEXT,
              status TEXT NOT NULL DEFAULT 'candidate',
              trust TEXT NOT NULL DEFAULT 'untrusted',
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_skill_status_trust
              ON skill(status, trust, updated_at);

            CREATE TABLE IF NOT EXISTS learning_run (
              run_id TEXT PRIMARY KEY,
              target TEXT NOT NULL,
              kind TEXT NOT NULL,
              before_json TEXT NOT NULL DEFAULT '{}',
              after_json TEXT NOT NULL DEFAULT '{}',
              train_metrics_json TEXT NOT NULL DEFAULT '{}',
              holdout_metrics_json TEXT NOT NULL DEFAULT '{}',
              gate_pass INTEGER NOT NULL DEFAULT 0,
              archived INTEGER NOT NULL DEFAULT 0,
              promoted INTEGER NOT NULL DEFAULT 0,
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_learning_run_kind_target
              ON learning_run(kind, target, created_at);

            CREATE TABLE IF NOT EXISTS learning_event (
              event_id TEXT PRIMARY KEY,
              ts TEXT NOT NULL,
              phase TEXT NOT NULL,
              kind TEXT NOT NULL,
              ref TEXT,
              payload_json TEXT NOT NULL DEFAULT '{}'
            );

            CREATE INDEX IF NOT EXISTS idx_learning_event_ts
              ON learning_event(ts, phase, kind);

            CREATE TABLE IF NOT EXISTS agent_benchmark_run (
              benchmark_run_id TEXT PRIMARY KEY,
              repo_id TEXT NOT NULL,
              cases INTEGER NOT NULL DEFAULT 0,
              success_rate_delta REAL NOT NULL DEFAULT 0.0,
              tests_pass_rate_delta REAL NOT NULL DEFAULT 0.0,
              wrong_files_touched_reduction REAL NOT NULL DEFAULT 0.0,
              missing_files_reduction REAL NOT NULL DEFAULT 0.0,
              agent_seconds_reduction REAL NOT NULL DEFAULT 0.0,
              memory_score REAL NOT NULL DEFAULT 0.0,
              context_retrieval_score REAL NOT NULL DEFAULT 0.0,
              gate_ok INTEGER,
              gate_status TEXT,
              delta_json TEXT NOT NULL DEFAULT '{}',
              lift_attribution_json TEXT NOT NULL DEFAULT '{}',
              roadmap_pruning_json TEXT NOT NULL DEFAULT '{}',
              report_json TEXT NOT NULL DEFAULT '{}',
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_agent_benchmark_run_repo_created
              ON agent_benchmark_run(repo_id, created_at);
            """
        )
        self._ensure_column("skill", "provenance_json", "TEXT NOT NULL DEFAULT '{}'")
        with self.conn:
            self.conn.execute(
                """
                UPDATE memory_records
                SET trust = CASE
                  WHEN status = 'active' THEN 'active'
                  WHEN status = 'approved' THEN 'approved'
                  WHEN status = 'candidate' THEN 'candidate'
                  ELSE COALESCE(NULLIF(trust, ''), 'candidate')
                END
                WHERE trust IS NULL
                   OR trust = ''
                   OR (trust = 'candidate' AND status IN ('active', 'approved'))
                """
            )
            self.conn.execute(
                """
                UPDATE memory_records
                SET provenance_json = ?
                WHERE provenance_json IS NULL OR provenance_json = ''
                """,
                (
                    canonical_json(
                        {
                            "generator": "deterministic",
                            "validator": "none",
                            "input_source": "repo",
                        }
                    ),
                ),
            )

    def _ensure_memory_os_schema(self) -> None:
        self._ensure_column("memory_records", "title", "TEXT")
        self._ensure_column("memory_records", "importance", "REAL NOT NULL DEFAULT 0.5")
        self._ensure_column("memory_records", "applies_when", "TEXT")
        self._ensure_column("memory_records", "avoid_when", "TEXT")
        self._ensure_column("memory_records", "invalidates_when", "TEXT")
        self._ensure_column("memory_records", "last_validated_at", "TEXT")
        self.conn.executescript(
            """
            CREATE INDEX IF NOT EXISTS idx_memory_records_scope_type_status
              ON memory_records(workspace_id, repo_id, type, status, trust);

            CREATE INDEX IF NOT EXISTS idx_memory_records_validation
              ON memory_records(updated_at, last_validated_at);

            CREATE INDEX IF NOT EXISTS idx_memory_records_expiry
              ON memory_records(expires_at, status);

            CREATE TABLE IF NOT EXISTS memory_review_queue (
              review_id TEXT PRIMARY KEY,
              record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
              reason TEXT NOT NULL,
              severity TEXT NOT NULL,
              status TEXT NOT NULL,
              created_at TEXT NOT NULL,
              resolved_at TEXT,
              resolution TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_memory_review_queue_status
              ON memory_review_queue(status, severity, created_at);

            CREATE TABLE IF NOT EXISTS memory_revision (
              revision_id TEXT PRIMARY KEY,
              record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
              previous_hash TEXT,
              record_json TEXT NOT NULL,
              actor TEXT NOT NULL,
              reason TEXT,
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_memory_revision_record
              ON memory_revision(record_id, created_at);
            """
        )
        with self.conn:
            self.conn.execute(
                """
                UPDATE memory_records
                SET importance = confidence
                WHERE importance IS NULL
                """
            )

    def _seed_memory_decay_policies(self) -> None:
        policies = [
            ("runtime_signal", 30, 14, 0),
            ("gotcha", 180, 90, 0),
            ("business_rule", None, None, 1),
            ("architectural_decision", None, None, 1),
            ("convention", 365, 180, 0),
            ("outcome", None, None, 0),
            ("pattern", None, None, 1),
        ]
        self.conn.executemany(
            """
            INSERT OR IGNORE INTO memory_decay_policies(
              type, default_ttl_days, stale_after_days, requires_manual_expiry
            )
            VALUES (?, ?, ?, ?)
            """,
            policies,
        )

    def upsert_repo(self, repo_id: str, root_path: Path, remote_url: str | None = None) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO repos(repo_id, root_path, remote_url, created_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(repo_id) DO UPDATE SET
                  root_path=excluded.root_path,
                  remote_url=COALESCE(excluded.remote_url, repos.remote_url)
                """,
                (repo_id, str(root_path), remote_url, utc_now()),
            )

    def open_snapshot(
        self,
        *,
        snapshot_id: str,
        repo_id: str,
        base_commit_sha: str,
        tree_digest: str,
        dirty_digest: str,
        worktree_state: str,
        branch_hint: str | None,
        parent_snapshot: str | None,
        indexer_version: str,
        parser_bundle_version: str,
        chunker_version: str,
        embed_model: str,
    ) -> str:
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO snapshots(
                  snapshot_id, repo_id, base_commit_sha, tree_digest, dirty_digest,
                  worktree_state, branch_hint, parent_snapshot, indexer_version,
                  parser_bundle_version, chunker_version, embed_model, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    snapshot_id,
                    repo_id,
                    base_commit_sha,
                    tree_digest,
                    dirty_digest,
                    worktree_state,
                    branch_hint,
                    parent_snapshot,
                    indexer_version,
                    parser_bundle_version,
                    chunker_version,
                    embed_model,
                    utc_now(),
                ),
            )
        return snapshot_id

    def snapshot_exists(self, snapshot_id: str) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM snapshots WHERE snapshot_id = ?", (snapshot_id,)
        ).fetchone()
        return row is not None

    def put_file_version(
        self,
        *,
        snapshot_id: str,
        repo_id: str,
        path: str,
        file_version_id: str,
        lang: str | None,
        loc: int,
        skeleton: str,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO file_versions(file_version_id, repo_id, lang, loc, skeleton)
                VALUES (?, ?, ?, ?, ?)
                """,
                (file_version_id, repo_id, lang, loc, skeleton),
            )
            self.conn.execute(
                """
                INSERT OR REPLACE INTO snapshot_files(snapshot_id, path, file_version_id)
                VALUES (?, ?, ?)
                """,
                (snapshot_id, path, file_version_id),
            )

    def resolve_identity(
        self, *, repo_id: str, path: str, kind: str, qualname: str, is_test: bool
    ) -> str:
        symbol_identity_id = stable_id(repo_id, path, kind, qualname)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO symbol_identities(
                  symbol_identity_id, repo_id, path, kind, qualname, is_test
                )
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(symbol_identity_id) DO UPDATE SET is_test=excluded.is_test
                """,
                (symbol_identity_id, repo_id, path, kind, qualname, int(is_test)),
            )
        return symbol_identity_id

    def put_occurrence(
        self,
        *,
        symbol_identity_id: str,
        file_version_id: str,
        start_line: int | None,
        end_line: int | None,
        signature: str,
        docstring: str | None,
    ) -> str:
        symbol_occurrence_id = stable_id(symbol_identity_id, file_version_id, start_line, end_line)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO symbol_occurrences(
                  symbol_occurrence_id, symbol_identity_id, file_version_id,
                  start_line, end_line, signature, docstring
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    symbol_occurrence_id,
                    symbol_identity_id,
                    file_version_id,
                    start_line,
                    end_line,
                    signature,
                    docstring,
                ),
            )
        return symbol_occurrence_id

    def put_edge(
        self,
        *,
        scope_snapshot_id: str | None,
        src_repo_id: str,
        src_node_type: str,
        src_node_id: str,
        dst_repo_id: str,
        dst_node_type: str,
        dst_node_id: str,
        kind: str,
        confidence: float,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        metadata = metadata or {}
        edge_id = stable_id(
            scope_snapshot_id or "",
            src_repo_id,
            src_node_type,
            src_node_id,
            dst_repo_id,
            dst_node_type,
            dst_node_id,
            kind,
        )
        with self.conn:
            existing = self.conn.execute(
                "SELECT confidence, metadata_json FROM edges WHERE edge_id = ?",
                (edge_id,),
            ).fetchone()
            if existing:
                confidence = max(float(existing["confidence"]), float(confidence))
                metadata = _merge_metadata(json.loads(existing["metadata_json"] or "{}"), metadata)
            self.conn.execute(
                """
                INSERT INTO edges(
                  edge_id, scope_snapshot_id, src_repo_id, src_node_type, src_node_id,
                  dst_repo_id, dst_node_type, dst_node_id, kind, confidence, metadata_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(edge_id) DO UPDATE SET
                  confidence=excluded.confidence,
                  metadata_json=excluded.metadata_json
                """,
                (
                    edge_id,
                    scope_snapshot_id,
                    src_repo_id,
                    src_node_type,
                    src_node_id,
                    dst_repo_id,
                    dst_node_type,
                    dst_node_id,
                    kind,
                    confidence,
                    canonical_json(metadata),
                ),
            )
        return edge_id

    def deduplicate_edges(self) -> dict[str, Any]:
        rows = self.conn.execute("SELECT * FROM edges ORDER BY edge_id").fetchall()
        grouped: dict[tuple[Any, ...], dict[str, Any]] = {}
        rewrite_needed = False
        for row in rows:
            key = _edge_logical_key(row)
            canonical_edge_id = stable_id(*[part or "" for part in key])
            if row["edge_id"] != canonical_edge_id:
                rewrite_needed = True
            current = grouped.get(key)
            metadata = json.loads(row["metadata_json"] or "{}")
            if current is None:
                grouped[key] = {
                    "edge_id": canonical_edge_id,
                    "scope_snapshot_id": row["scope_snapshot_id"],
                    "src_repo_id": row["src_repo_id"],
                    "src_node_type": row["src_node_type"],
                    "src_node_id": row["src_node_id"],
                    "dst_repo_id": row["dst_repo_id"],
                    "dst_node_type": row["dst_node_type"],
                    "dst_node_id": row["dst_node_id"],
                    "kind": row["kind"],
                    "confidence": float(row["confidence"]),
                    "metadata": metadata,
                    "count": 1,
                }
                continue
            current["confidence"] = max(float(current["confidence"]), float(row["confidence"]))
            current["metadata"] = _merge_metadata(current["metadata"], metadata)
            current["count"] += 1

        duplicates = sum(item["count"] - 1 for item in grouped.values())
        if duplicates or rewrite_needed:
            with self.conn:
                self.conn.execute("DELETE FROM edges")
                self.conn.executemany(
                    """
                    INSERT INTO edges(
                      edge_id, scope_snapshot_id, src_repo_id, src_node_type, src_node_id,
                      dst_repo_id, dst_node_type, dst_node_id, kind, confidence, metadata_json
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    [
                        (
                            item["edge_id"],
                            item["scope_snapshot_id"],
                            item["src_repo_id"],
                            item["src_node_type"],
                            item["src_node_id"],
                            item["dst_repo_id"],
                            item["dst_node_type"],
                            item["dst_node_id"],
                            item["kind"],
                            item["confidence"],
                            canonical_json(
                                _merge_metadata(
                                    item["metadata"],
                                    {"deduped_edge_count": item["count"]},
                                )
                                if item["count"] > 1
                                else item["metadata"]
                            ),
                        )
                        for item in grouped.values()
                    ],
                )
        return {"ok": True, "edges": len(grouped), "duplicates_removed": duplicates}

    def clear_snapshot_derived(self, snapshot_id: str) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM chunks_fts WHERE chunk_id IN (SELECT chunk_id FROM chunks WHERE snapshot_id = ?)", (snapshot_id,))
            self.conn.execute("DELETE FROM chunks WHERE snapshot_id = ?", (snapshot_id,))
            self.conn.execute("DELETE FROM edges WHERE scope_snapshot_id = ?", (snapshot_id,))

    def put_chunk(
        self,
        *,
        chunk_id: str,
        snapshot_id: str,
        repo_id: str,
        path: str,
        symbol_identity_id: str | None,
        category: str,
        start_line: int | None,
        end_line: int | None,
        text: str,
        text_normalized: str,
        token_count: int,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO chunks(
                  chunk_id, snapshot_id, repo_id, path, symbol_identity_id,
                  category, start_line, end_line, text, text_normalized, token_count
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    chunk_id,
                    snapshot_id,
                    repo_id,
                    path,
                    symbol_identity_id,
                    category,
                    start_line,
                    end_line,
                    text,
                    text_normalized,
                    token_count,
                ),
            )
            self.conn.execute(
                "INSERT OR REPLACE INTO chunks_fts(chunk_id, text_normalized) VALUES (?, ?)",
                (chunk_id, text_normalized),
            )

    def put_chunk_vector(self, *, chunk_id: str, dims: int, vector: list[float], model: str) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO chunk_vectors(chunk_id, dims, vector_json, model)
                VALUES (?, ?, ?, ?)
                """,
                (chunk_id, dims, canonical_json(vector), model),
            )
            if self.sqlite_vec_loaded:
                self._ensure_vec_table(dims)
                row = self.conn.execute(
                    "SELECT vec_rowid FROM chunk_vector_rows WHERE chunk_id = ?", (chunk_id,)
                ).fetchone()
                if row:
                    vec_rowid = int(row["vec_rowid"])
                    self.conn.execute(f"DELETE FROM {self._vec_table(dims)} WHERE rowid = ?", (vec_rowid,))
                    self.conn.execute(
                        """
                        UPDATE chunk_vector_rows
                        SET dims = ?, model = ?
                        WHERE chunk_id = ?
                        """,
                        (dims, model, chunk_id),
                    )
                else:
                    cur = self.conn.execute(
                        """
                        INSERT INTO chunk_vector_rows(chunk_id, dims, model)
                        VALUES (?, ?, ?)
                        """,
                        (chunk_id, dims, model),
                    )
                    vec_rowid = int(cur.lastrowid)
                self.conn.execute(
                    f"INSERT INTO {self._vec_table(dims)}(rowid, embedding) VALUES (?, ?)",
                    (vec_rowid, canonical_json(vector)),
                )

    def _vec_table(self, dims: int) -> str:
        return f"vec_chunks_{int(dims)}"

    def _ensure_vec_table(self, dims: int) -> None:
        if not self.sqlite_vec_loaded:
            return
        self.conn.execute(
            f"CREATE VIRTUAL TABLE IF NOT EXISTS {self._vec_table(dims)} USING vec0(embedding float[{int(dims)}])"
        )

    def chunk_vectors(self, snapshot_id: str, model: str | None = None) -> list[sqlite3.Row]:
        params: list[Any] = [snapshot_id]
        where_model = ""
        if model:
            where_model = " AND v.model = ?"
            params.append(model)
        return self.conn.execute(
            f"""
            SELECT c.*, v.vector_json, v.dims, v.model
            FROM chunks c
            JOIN chunk_vectors v ON v.chunk_id = c.chunk_id
            WHERE c.snapshot_id = ? {where_model}
            """,
            params,
        ).fetchall()

    def search_vector_chunks(
        self,
        *,
        snapshot_id: str,
        model: str,
        dims: int,
        vector: list[float],
        limit: int,
    ) -> list[dict[str, Any]]:
        if not self.sqlite_vec_loaded:
            return []
        self._ensure_vec_table(dims)
        rows = self.conn.execute(
            f"""
            SELECT c.*, v.distance AS distance
            FROM {self._vec_table(dims)} v
            JOIN chunk_vector_rows r ON r.vec_rowid = v.rowid
            JOIN chunks c ON c.chunk_id = r.chunk_id
            WHERE v.embedding MATCH ?
              AND k = ?
              AND c.snapshot_id = ?
              AND r.model = ?
            ORDER BY v.distance
            """,
            (canonical_json(vector), limit, snapshot_id, model),
        ).fetchall()
        results: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            item["_vector_score"] = 1.0 / (1.0 + float(row["distance"]))
            results.append(item)
        return results

    def search_chunks(self, snapshot_id: str, query: str, limit: int = 50) -> list[sqlite3.Row]:
        terms = [term for term in query.replace('"', " ").split() if len(term) > 1]
        if not terms:
            return []
        fts_query = " OR ".join(f'"{term}"' for term in terms[:8])
        try:
            rows = self.conn.execute(
                """
                SELECT c.*, bm25(chunks_fts) AS rank
                FROM chunks_fts
                JOIN chunks c ON c.chunk_id = chunks_fts.chunk_id
                WHERE c.snapshot_id = ? AND chunks_fts MATCH ?
                ORDER BY rank
                LIMIT ?
                """,
                (snapshot_id, fts_query, limit),
            ).fetchall()
        except sqlite3.OperationalError:
            rows = []
        if rows:
            return rows
        like = "%" + "%".join(terms[:4]) + "%"
        return self.conn.execute(
            """
            SELECT *, 100.0 AS rank
            FROM chunks
            WHERE snapshot_id = ? AND text_normalized LIKE ?
            ORDER BY token_count ASC
            LIMIT ?
            """,
            (snapshot_id, like, limit),
        ).fetchall()

    def chunks_by_paths(self, snapshot_id: str, paths: Iterable[str], limit_per_path: int = 3) -> list[sqlite3.Row]:
        rows: list[sqlite3.Row] = []
        for path in sorted(set(paths)):
            rows.extend(
                self.conn.execute(
                    """
                    SELECT * FROM chunks
                    WHERE snapshot_id = ? AND path = ?
                    ORDER BY token_count ASC, start_line
                    LIMIT ?
                    """,
                    (snapshot_id, path, limit_per_path),
                ).fetchall()
            )
        return rows

    def fallback_chunks(self, snapshot_id: str, limit: int = 25) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM chunks
            WHERE snapshot_id = ?
            ORDER BY token_count ASC, path
            LIMIT ?
            """,
            (snapshot_id, limit),
        ).fetchall()

    def neighbors(
        self,
        *,
        repo_id: str,
        node_type: str,
        node_id: str,
        kinds: Iterable[str] | None = None,
        direction: str = "out",
    ) -> list[Neighbor]:
        kind_filter = tuple(kinds or ())
        params: list[Any] = [repo_id, node_type, node_id]
        where_kind = ""
        if kind_filter:
            where_kind = f" AND kind IN ({','.join('?' for _ in kind_filter)})"
            params.extend(kind_filter)
        if direction == "in":
            sql = f"""
                SELECT src_node_type AS node_type, src_node_id AS node_id, src_repo_id AS repo_id,
                       kind, confidence, metadata_json
                FROM edges
                WHERE dst_repo_id = ? AND dst_node_type = ? AND dst_node_id = ? {where_kind}
            """
        else:
            sql = f"""
                SELECT dst_node_type AS node_type, dst_node_id AS node_id, dst_repo_id AS repo_id,
                       kind, confidence, metadata_json
                FROM edges
                WHERE src_repo_id = ? AND src_node_type = ? AND src_node_id = ? {where_kind}
            """
        merged: dict[tuple[str, str, str, str], Neighbor] = {}
        for row in self.conn.execute(sql, params).fetchall():
            key = (row["repo_id"], row["node_type"], row["node_id"], row["kind"])
            metadata = json.loads(row["metadata_json"] or "{}")
            existing = merged.get(key)
            if existing is None:
                merged[key] = Neighbor(
                    node_type=row["node_type"],
                    node_id=row["node_id"],
                    repo_id=row["repo_id"],
                    kind=row["kind"],
                    confidence=float(row["confidence"]),
                    metadata=metadata,
                )
            else:
                merged[key] = Neighbor(
                    node_type=existing.node_type,
                    node_id=existing.node_id,
                    repo_id=existing.repo_id,
                    kind=existing.kind,
                    confidence=max(existing.confidence, float(row["confidence"])),
                    metadata=_merge_metadata(existing.metadata, metadata),
                )
        return [merged[key] for key in sorted(merged)]

    def logical_edges(self, where_sql: str = "", params: Iterable[Any] = ()) -> list[dict[str, Any]]:
        sql = "SELECT * FROM edges"
        if where_sql:
            sql += f" WHERE {where_sql}"
        rows = self.conn.execute(sql, tuple(params)).fetchall()
        grouped: dict[tuple[Any, ...], dict[str, Any]] = {}
        for row in rows:
            key = _edge_logical_key(row)
            item = grouped.get(key)
            metadata = json.loads(row["metadata_json"] or "{}")
            if item is None:
                grouped[key] = {
                    "edge_id": row["edge_id"],
                    "scope_snapshot_id": row["scope_snapshot_id"],
                    "src_repo_id": row["src_repo_id"],
                    "src_node_type": row["src_node_type"],
                    "src_node_id": row["src_node_id"],
                    "dst_repo_id": row["dst_repo_id"],
                    "dst_node_type": row["dst_node_type"],
                    "dst_node_id": row["dst_node_id"],
                    "kind": row["kind"],
                    "confidence": float(row["confidence"]),
                    "metadata": metadata,
                    "metadata_json": canonical_json(metadata),
                    "deduped_edge_count": 1,
                }
            else:
                item["confidence"] = max(float(item["confidence"]), float(row["confidence"]))
                item["metadata"] = _merge_metadata(item["metadata"], metadata)
                item["deduped_edge_count"] += 1
                item["metadata_json"] = canonical_json(item["metadata"])
        return sorted(
            grouped.values(),
            key=lambda item: (
                item["src_repo_id"],
                item["src_node_id"],
                item["dst_repo_id"],
                item["dst_node_id"],
                item["kind"],
            ),
        )

    def snapshot_files(self, snapshot_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT sf.path, sf.file_version_id, fv.lang, fv.loc, fv.skeleton
            FROM snapshot_files sf
            JOIN file_versions fv ON fv.file_version_id = sf.file_version_id
            WHERE sf.snapshot_id = ?
            ORDER BY sf.path
            """,
            (snapshot_id,),
        ).fetchall()

    def symbol_rows_for_snapshot(self, snapshot_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT si.*, so.start_line, so.end_line, so.signature, so.docstring, sf.path
            FROM snapshot_files sf
            JOIN symbol_occurrences so ON so.file_version_id = sf.file_version_id
            JOIN symbol_identities si ON si.symbol_identity_id = so.symbol_identity_id
            WHERE sf.snapshot_id = ?
            ORDER BY si.path, si.qualname
            """,
            (snapshot_id,),
        ).fetchall()

    def symbols_named(self, repo_id: str, names: Iterable[str]) -> list[sqlite3.Row]:
        names = sorted({name for name in names if name})
        if not names:
            return []
        rows: dict[str, sqlite3.Row] = {}
        for name in names:
            for row in self.conn.execute(
                """
                SELECT * FROM symbol_identities
                WHERE repo_id = ? AND (qualname = ? OR qualname LIKE ?)
                ORDER BY path, qualname
                """,
                (repo_id, name, f"%.{name}"),
            ).fetchall():
                rows[row["symbol_identity_id"]] = row
        return list(rows.values())

    def symbol_identity(self, symbol_identity_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM symbol_identities WHERE symbol_identity_id = ?",
            (symbol_identity_id,),
        ).fetchone()

    def put_test_command(self, *, repo_id: str, path_glob: str, command: str) -> str:
        command_id = stable_id(repo_id, path_glob, command)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO test_commands(command_id, repo_id, path_glob, command)
                VALUES (?, ?, ?, ?)
                """,
                (command_id, repo_id, path_glob, command),
            )
        return command_id

    def test_commands(self, repo_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM test_commands WHERE repo_id = ? ORDER BY path_glob, command", (repo_id,)
        ).fetchall()

    def replace_ownership(self, repo_id: str, rows: Iterable[dict[str, Any]]) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM ownership WHERE repo_id = ?", (repo_id,))
            for row in rows:
                owner_id = stable_id(repo_id, row["path_glob"], row["owner"], row["source"])
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO ownership(
                      owner_id, repo_id, path_glob, owner, source, confidence
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        owner_id,
                        repo_id,
                        row["path_glob"],
                        row["owner"],
                        row["source"],
                        float(row.get("confidence", 1.0)),
                    ),
                )

    def ownership(self, repo_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM ownership WHERE repo_id = ? ORDER BY path_glob, owner", (repo_id,)
        ).fetchall()

    def replace_history_signals(
        self,
        *,
        repo_id: str,
        churn_rows: Iterable[dict[str, Any]],
        cochange_rows: Iterable[dict[str, Any]],
    ) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM churn WHERE repo_id = ?", (repo_id,))
            self.conn.execute("DELETE FROM cochange WHERE repo_id = ?", (repo_id,))
            for row in churn_rows:
                churn_id = stable_id(repo_id, row["path"], row.get("author") or "")
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO churn(
                      churn_id, repo_id, path, author, commits, last_commit_sha, last_touched_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        churn_id,
                        repo_id,
                        row["path"],
                        row.get("author"),
                        int(row["commits"]),
                        row.get("last_commit_sha"),
                        row.get("last_touched_at"),
                    ),
                )
            for row in cochange_rows:
                a, b = sorted([row["path_a"], row["path_b"]])
                cochange_id = stable_id(repo_id, a, b)
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO cochange(
                      cochange_id, repo_id, path_a, path_b, commits_together,
                      commits_a, commits_b, jaccard
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        cochange_id,
                        repo_id,
                        a,
                        b,
                        int(row["commits_together"]),
                        int(row["commits_a"]),
                        int(row["commits_b"]),
                        float(row["jaccard"]),
                    ),
                )

    def cochanged_paths(self, repo_id: str, path: str, limit: int = 10) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT CASE WHEN path_a = ? THEN path_b ELSE path_a END AS path,
                   commits_together, commits_a, commits_b, jaccard
            FROM cochange
            WHERE repo_id = ? AND (path_a = ? OR path_b = ?)
            ORDER BY jaccard DESC, commits_together DESC, path
            LIMIT ?
            """,
            (path, repo_id, path, path, limit),
        ).fetchall()

    def churn_for_path(self, repo_id: str, path: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT path, SUM(commits) AS commits, MAX(last_touched_at) AS last_touched_at
            FROM churn
            WHERE repo_id = ? AND path = ?
            GROUP BY path
            """,
            (repo_id, path),
        ).fetchone()

    def write_eval_run(
        self,
        *,
        eval_run_id: str,
        repo_id: str,
        mode: str,
        train_count: int,
        holdout_count: int,
        metrics: dict[str, Any],
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO eval_runs(
                  eval_run_id, repo_id, mode, train_count, holdout_count, metrics_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    eval_run_id,
                    repo_id,
                    mode,
                    train_count,
                    holdout_count,
                    canonical_json(metrics),
                    utc_now(),
                ),
            )

    def write_agent_benchmark_run(
        self,
        *,
        repo_id: str,
        report: dict[str, Any],
    ) -> str:
        created_at = str(report.get("created_at") or utc_now())
        delta = _dict(report.get("delta"))
        lift_attribution = _dict(report.get("lift_attribution"))
        roadmap_pruning = _dict(report.get("roadmap_pruning"))
        components = _dict(lift_attribution.get("components"))
        memory = _dict(components.get("memory"))
        context_retrieval = _dict(components.get("context_retrieval"))
        gate = _dict(report.get("gate"))
        gate_ok = gate.get("ok")
        if isinstance(gate_ok, bool):
            gate_ok_value: int | None = int(gate_ok)
        else:
            gate_ok_value = None
        benchmark_run_id = stable_id(
            "agent_benchmark_run",
            repo_id,
            canonical_json(delta),
            canonical_json(lift_attribution),
            canonical_json(roadmap_pruning),
            created_at,
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO agent_benchmark_run(
                  benchmark_run_id, repo_id, cases, success_rate_delta,
                  tests_pass_rate_delta, wrong_files_touched_reduction,
                  missing_files_reduction, agent_seconds_reduction, memory_score,
                  context_retrieval_score, gate_ok, gate_status, delta_json,
                  lift_attribution_json, roadmap_pruning_json, report_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    benchmark_run_id,
                    repo_id,
                    int(report.get("cases") or 0),
                    _float_metric(delta, "success_rate_delta"),
                    _float_metric(delta, "tests_pass_rate_delta"),
                    _float_metric(delta, "wrong_files_touched_reduction"),
                    _float_metric(delta, "missing_files_reduction"),
                    _float_metric(delta, "agent_seconds_reduction"),
                    _float_metric(memory, "score"),
                    _float_metric(context_retrieval, "score"),
                    gate_ok_value,
                    str(gate.get("status") or "") or None,
                    canonical_json(delta),
                    canonical_json(lift_attribution),
                    canonical_json(roadmap_pruning),
                    canonical_json(report),
                    created_at,
                ),
            )
        return benchmark_run_id

    def agent_benchmark_runs(
        self,
        *,
        repo_id: str | None = None,
        limit: int = 20,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if repo_id:
            clauses.append("repo_id = ?")
            params.append(repo_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM agent_benchmark_run
            {where}
            ORDER BY created_at DESC, benchmark_run_id DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def put_dirty_blob(self, *, snapshot_id: str, path: str, content_hash: str, content: bytes) -> str:
        blob_id = stable_id(snapshot_id, path, content_hash)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO dirty_blobs(blob_id, snapshot_id, path, content_hash, content)
                VALUES (?, ?, ?, ?, ?)
                """,
                (blob_id, snapshot_id, path, content_hash, content),
            )
        return blob_id

    def write_release_report(self, *, repo_id: str, version: str, report: dict[str, Any]) -> str:
        report_id = stable_id(repo_id, version, canonical_json(report), utc_now())
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO release_reports(release_report_id, repo_id, version, report_json, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (report_id, repo_id, version, canonical_json(report), utc_now()),
            )
        return report_id

    def latest_release_report(self, repo_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT * FROM release_reports
            WHERE repo_id = ?
            ORDER BY created_at DESC
            LIMIT 1
            """,
            (repo_id,),
        ).fetchone()

    def write_ci_report(self, *, repo_id: str, status: str, report: dict[str, Any]) -> str:
        report_id = stable_id(repo_id, status, canonical_json(report), utc_now())
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO ci_reports(ci_report_id, repo_id, status, report_json, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (report_id, repo_id, status, canonical_json(report), utc_now()),
            )
        return report_id

    def write_constitution(
        self,
        *,
        workspace_id: str,
        repo_id: str,
        manifest: dict[str, Any],
    ) -> str:
        constitution_hash = str(manifest.get("constitution_hash") or stable_id(canonical_json(manifest)))
        constitution_id = stable_id(workspace_id, repo_id, constitution_hash)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO constitutions(
                  constitution_id, workspace_id, repo_id, constitution_hash,
                  manifest_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    constitution_id,
                    workspace_id,
                    repo_id,
                    constitution_hash,
                    canonical_json(manifest),
                    utc_now(),
                ),
            )
        return constitution_id

    def latest_constitution(self, repo_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT * FROM constitutions
            WHERE repo_id = ?
            ORDER BY created_at DESC
            LIMIT 1
            """,
            (repo_id,),
        ).fetchone()

    def constitution_by_hash(self, constitution_hash: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT * FROM constitutions
            WHERE constitution_hash = ?
            ORDER BY created_at DESC
            LIMIT 1
            """,
            (constitution_hash,),
        ).fetchone()

    def add_workspace_repo(
        self, *, workspace_root: str, repo_id: str, name: str, root_path: str
    ) -> str:
        workspace_repo_id = stable_id(workspace_root, repo_id, root_path)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO workspace_repos(
                  workspace_repo_id, workspace_root, repo_id, name, root_path
                )
                VALUES (?, ?, ?, ?, ?)
                """,
                (workspace_repo_id, workspace_root, repo_id, name, root_path),
            )
        return workspace_repo_id

    def workspace_repos(self, workspace_root: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM workspace_repos WHERE workspace_root = ? ORDER BY name",
            (workspace_root,),
        ).fetchall()

    def replace_contracts(self, *, repo_id: str, contracts: Iterable[dict[str, Any]]) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM crossrepo_contracts WHERE repo_id = ?", (repo_id,))
            for contract in contracts:
                contract_id = stable_id(
                    repo_id,
                    contract["path"],
                    contract["kind"],
                    contract["name"],
                    canonical_json(contract.get("metadata", {})),
                )
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO crossrepo_contracts(
                      contract_id, repo_id, path, kind, name, metadata_json
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        contract_id,
                        repo_id,
                        contract["path"],
                        contract["kind"],
                        contract["name"],
                        canonical_json(contract.get("metadata", {})),
                    ),
                )

    def contracts(self, repo_id: str | None = None) -> list[sqlite3.Row]:
        if repo_id:
            return self.conn.execute(
                "SELECT * FROM crossrepo_contracts WHERE repo_id = ? ORDER BY kind, name",
                (repo_id,),
            ).fetchall()
        return self.conn.execute(
            "SELECT * FROM crossrepo_contracts ORDER BY repo_id, kind, name"
        ).fetchall()

    def write_audit_anchor(self, *, target: str, tip_hash: str, location: str | None) -> str:
        anchor_id = stable_id(target, tip_hash, location or "", utc_now())
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO audit_anchors(anchor_id, target, tip_hash, location, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (anchor_id, target, tip_hash, location, utc_now()),
            )
        return anchor_id

    def upsert_business_rule(
        self,
        *,
        workspace_id: str,
        repo_id: str | None,
        scope_glob: str | None,
        rule_text: str,
        source_type: str,
        source_ref: str,
        confidence: float,
        status: str = "candidate",
    ) -> str:
        rule_id = stable_id(workspace_id, repo_id or "", scope_glob or "", rule_text, source_ref)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO business_rules(
                  rule_id, workspace_id, repo_id, scope_glob, rule_text, source_type,
                  source_ref, confidence, status, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(rule_id) DO UPDATE SET confidence=excluded.confidence
                """,
                (
                    rule_id,
                    workspace_id,
                    repo_id,
                    scope_glob,
                    rule_text,
                    source_type,
                    source_ref,
                    confidence,
                    status,
                    utc_now(),
                ),
            )
        return rule_id

    def upsert_business_rule_candidate(
        self,
        *,
        workspace_id: str,
        repo_id: str | None,
        rule_text: str,
        source_type: str,
        confidence: float,
        status: str = "candidate",
    ) -> str:
        candidate_id = stable_id(workspace_id, repo_id or "", rule_text, source_type)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO business_rule_candidates(
                  candidate_id, workspace_id, repo_id, rule_text, source_type,
                  confidence, status, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(candidate_id) DO UPDATE SET
                  confidence=excluded.confidence,
                  status=CASE
                    WHEN business_rule_candidates.status = 'rejected' THEN 'rejected'
                    ELSE excluded.status
                  END
                """,
                (
                    candidate_id,
                    workspace_id,
                    repo_id,
                    rule_text,
                    source_type,
                    confidence,
                    status,
                    utc_now(),
                ),
            )
        return candidate_id

    def put_business_rule_candidate_evidence(
        self,
        *,
        candidate_id: str,
        repo_id: str | None,
        path: str | None,
        symbol_identity_id: str | None,
        evidence_kind: str,
        evidence_hash: str,
        line_start: int | None = None,
        line_end: int | None = None,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO business_rule_candidate_evidence(
                  candidate_id, repo_id, path, symbol_identity_id, evidence_kind,
                  evidence_hash, line_start, line_end
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    candidate_id,
                    repo_id,
                    path,
                    symbol_identity_id,
                    evidence_kind,
                    evidence_hash,
                    line_start,
                    line_end,
                ),
            )

    def business_rule_candidates(self, status: str | None = None) -> list[sqlite3.Row]:
        if status:
            return self.conn.execute(
                """
                SELECT * FROM business_rule_candidates
                WHERE status = ?
                ORDER BY confidence DESC, rule_text
                """,
                (status,),
            ).fetchall()
        return self.conn.execute(
            "SELECT * FROM business_rule_candidates ORDER BY status, confidence DESC, rule_text"
        ).fetchall()

    def business_rule_candidate(self, candidate_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM business_rule_candidates WHERE candidate_id = ?", (candidate_id,)
        ).fetchone()

    def candidate_evidence(self, candidate_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM business_rule_candidate_evidence
            WHERE candidate_id = ?
            ORDER BY path, line_start
            """,
            (candidate_id,),
        ).fetchall()

    def set_candidate_status(self, candidate_id: str, status: str) -> None:
        with self.conn:
            self.conn.execute(
                "UPDATE business_rule_candidates SET status = ? WHERE candidate_id = ?",
                (status, candidate_id),
            )

    def put_business_rule_evidence(
        self,
        *,
        rule_id: str,
        path: str | None,
        symbol_identity_id: str | None,
        quote_hash: str | None,
        evidence_type: str,
        repo_id: str | None = None,
        evidence_hash: str | None = None,
        line_start: int | None = None,
        line_end: int | None = None,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO business_rule_evidence(
                  rule_id, repo_id, path, symbol_identity_id, quote_hash, evidence_type,
                  evidence_kind, evidence_hash, line_start, line_end
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    rule_id,
                    repo_id,
                    path,
                    symbol_identity_id,
                    quote_hash,
                    evidence_type,
                    evidence_type,
                    evidence_hash or quote_hash or "",
                    line_start,
                    line_end,
                ),
            )

    def business_rules(self, status: str | None = None) -> list[sqlite3.Row]:
        if status:
            return self.conn.execute(
                "SELECT * FROM business_rules WHERE status = ? ORDER BY confidence DESC, rule_text",
                (status,),
            ).fetchall()
        return self.conn.execute(
            "SELECT * FROM business_rules ORDER BY status, confidence DESC, rule_text"
        ).fetchall()

    def set_business_rule_status(
        self,
        *,
        rule_id: str,
        status: str,
        approved_by: str | None = None,
        supersedes_rule_id: str | None = None,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                UPDATE business_rules
                SET status = ?, approved_by = ?, approved_at = ?,
                    supersedes_rule_id = COALESCE(?, supersedes_rule_id),
                    updated_at = ?
                WHERE rule_id = ?
                """,
                (
                    status,
                    approved_by,
                    utc_now() if status in {"approved", "active"} else None,
                    supersedes_rule_id,
                    utc_now(),
                    rule_id,
                ),
            )

    def record_business_rule_approval(
        self,
        *,
        rule_id: str,
        approver: str,
        source: str,
        decision: str,
        notes: str | None = None,
    ) -> str:
        approval_id = stable_id(rule_id, approver, source, decision, notes or "", utc_now())
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO business_rule_approvals(
                  approval_id, rule_id, approver, source, decision, notes, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (approval_id, rule_id, approver, source, decision, notes, utc_now()),
            )
        return approval_id

    def rule_evidence(self, rule_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM business_rule_evidence
            WHERE rule_id = ?
            ORDER BY path, line_start
            """,
            (rule_id,),
        ).fetchall()

    def add_runtime_event(
        self,
        *,
        source: str,
        repo_id: str | None,
        title: str,
        message: str,
        path: str | None,
        symbol_identity_id: str | None,
        severity: str,
        event_hash: str,
    ) -> str:
        event_id = stable_id(source, repo_id or "", title, message, event_hash)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO runtime_events(
                  runtime_event_id, source, repo_id, title, message, path,
                  symbol_identity_id, severity, event_hash, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    event_id,
                    source,
                    repo_id,
                    title,
                    message,
                    path,
                    symbol_identity_id,
                    severity,
                    event_hash,
                    utc_now(),
                ),
            )
        return event_id

    def runtime_events(self, repo_id: str | None = None) -> list[sqlite3.Row]:
        if repo_id:
            return self.conn.execute(
                "SELECT * FROM runtime_events WHERE repo_id = ? ORDER BY created_at DESC",
                (repo_id,),
            ).fetchall()
        return self.conn.execute("SELECT * FROM runtime_events ORDER BY created_at DESC").fetchall()

    def replace_semantic_graph(
        self,
        *,
        repo_id: str,
        nodes: Iterable[dict[str, Any]],
        edges: Iterable[dict[str, Any]],
        evidence: Iterable[dict[str, Any]],
        file_index: Iterable[dict[str, Any]] | None = None,
    ) -> None:
        with self.conn:
            existing_node_ids = [
                row["node_id"]
                for row in self.conn.execute(
                    "SELECT node_id FROM semantic_nodes WHERE repo_id = ?", (repo_id,)
                ).fetchall()
            ]
            if existing_node_ids:
                placeholders = ",".join("?" for _ in existing_node_ids)
                self.conn.execute(
                    f"DELETE FROM semantic_edges WHERE src_node_id IN ({placeholders}) "
                    f"OR dst_node_id IN ({placeholders})",
                    [*existing_node_ids, *existing_node_ids],
                )
                self.conn.execute(
                    f"DELETE FROM semantic_evidence WHERE node_id IN ({placeholders})",
                    existing_node_ids,
                )
            self.conn.execute("DELETE FROM semantic_nodes WHERE repo_id = ?", (repo_id,))

            for node in nodes:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO semantic_nodes(
                      node_id, repo_id, node_type, name, stable_key, confidence, source,
                      metadata_json, created_at, updated_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        node["node_id"],
                        node.get("repo_id"),
                        node["node_type"],
                        node["name"],
                        node["stable_key"],
                        float(node["confidence"]),
                        node["source"],
                        canonical_json(node.get("metadata", {})),
                        utc_now(),
                        utc_now(),
                    ),
                )

            for edge in edges:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO semantic_edges(
                      edge_id, src_node_id, dst_node_id, kind, confidence,
                      evidence_json, metadata_json, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        edge["edge_id"],
                        edge["src_node_id"],
                        edge["dst_node_id"],
                        edge["kind"],
                        float(edge["confidence"]),
                        canonical_json(edge.get("evidence", [])),
                        canonical_json(edge.get("metadata", {})),
                        utc_now(),
                    ),
                )

            for item in evidence:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO semantic_evidence(
                      evidence_id, node_id, edge_id, repo_id, path, symbol_identity_id,
                      line_start, line_end, evidence_kind, evidence_hash
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        item["evidence_id"],
                        item.get("node_id"),
                        item.get("edge_id"),
                        item.get("repo_id"),
                        item.get("path"),
                        item.get("symbol_identity_id"),
                        item.get("line_start"),
                        item.get("line_end"),
                        item["evidence_kind"],
                        item["evidence_hash"],
                    ),
                )
            if file_index is not None:
                self.conn.execute("DELETE FROM semantic_file_index WHERE repo_id = ?", (repo_id,))
                for item in file_index:
                    self.conn.execute(
                        """
                        INSERT OR REPLACE INTO semantic_file_index(
                          repo_id, path, file_version_id, parser_backend, indexed_at
                        )
                        VALUES (?, ?, ?, ?, ?)
                        """,
                        (
                            repo_id,
                            item["path"],
                            item["file_version_id"],
                            item["parser_backend"],
                            utc_now(),
                        ),
                    )

    def semantic_nodes(self, repo_id: str | None = None) -> list[sqlite3.Row]:
        if repo_id:
            return self.conn.execute(
                """
                SELECT * FROM semantic_nodes
                WHERE repo_id = ?
                ORDER BY node_type, name
                """,
                (repo_id,),
            ).fetchall()
        return self.conn.execute(
            "SELECT * FROM semantic_nodes ORDER BY repo_id, node_type, name"
        ).fetchall()

    def semantic_node(self, node_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM semantic_nodes WHERE node_id = ?", (node_id,)
        ).fetchone()

    def semantic_search(self, repo_id: str, query: str, limit: int = 20) -> list[sqlite3.Row]:
        terms = [term.lower() for term in query.split() if len(term) > 1]
        if not terms:
            return []
        like = "%" + "%".join(terms[:5]) + "%"
        return self.conn.execute(
            """
            SELECT * FROM semantic_nodes
            WHERE repo_id = ?
              AND (
                lower(name) LIKE ?
                OR lower(node_type) LIKE ?
                OR lower(metadata_json) LIKE ?
              )
            ORDER BY confidence DESC, node_type, name
            LIMIT ?
            """,
            (repo_id, like, like, like, limit),
        ).fetchall()

    def semantic_edges_for_node(self, node_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT e.*, src.node_type AS src_type, src.name AS src_name,
                   dst.node_type AS dst_type, dst.name AS dst_name
            FROM semantic_edges e
            JOIN semantic_nodes src ON src.node_id = e.src_node_id
            JOIN semantic_nodes dst ON dst.node_id = e.dst_node_id
            WHERE e.src_node_id = ? OR e.dst_node_id = ?
            ORDER BY e.kind, src.name, dst.name
            """,
            (node_id, node_id),
        ).fetchall()

    def semantic_evidence(
        self, *, node_id: str | None = None, edge_id: str | None = None
    ) -> list[sqlite3.Row]:
        if node_id:
            return self.conn.execute(
                """
                SELECT * FROM semantic_evidence
                WHERE node_id = ?
                ORDER BY path, line_start, evidence_kind
                """,
                (node_id,),
            ).fetchall()
        if edge_id:
            return self.conn.execute(
                """
                SELECT * FROM semantic_evidence
                WHERE edge_id = ?
                ORDER BY path, line_start, evidence_kind
                """,
                (edge_id,),
            ).fetchall()
        return self.conn.execute(
            "SELECT * FROM semantic_evidence ORDER BY path, line_start, evidence_kind"
        ).fetchall()

    def semantic_file_index(self, repo_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM semantic_file_index
            WHERE repo_id = ?
            ORDER BY path
            """,
            (repo_id,),
        ).fetchall()

    def graph_file_centrality(
        self,
        repo_id: str,
        *,
        kinds: Iterable[str] | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        kind_filter = tuple(kinds or ("imports", "tests", "calls"))
        params: list[Any] = [repo_id, repo_id]
        where_kind = ""
        if kind_filter:
            where_kind = f" AND kind IN ({','.join('?' for _ in kind_filter)})"
            params.extend(kind_filter)
        rows = self.conn.execute(
            f"""
            SELECT * FROM edges
            WHERE src_repo_id = ? AND dst_repo_id = ? {where_kind}
            ORDER BY src_node_type, src_node_id, dst_node_type, dst_node_id, kind
            """,
            params,
        ).fetchall()
        symbol_paths = {
            row["symbol_identity_id"]: row["path"]
            for row in self.conn.execute(
                "SELECT symbol_identity_id, path FROM symbol_identities WHERE repo_id = ?",
                (repo_id,),
            ).fetchall()
        }
        by_path: dict[str, dict[str, Any]] = {}

        def edge_path(node_type: str, node_id: str) -> str | None:
            if node_type == "file":
                return node_id
            if node_type == "symbol":
                return symbol_paths.get(node_id)
            return None

        def ensure(path: str) -> dict[str, Any]:
            item = by_path.get(path)
            if item is None:
                item = {
                    "path": path,
                    "in_degree": 0,
                    "out_degree": 0,
                    "degree": 0,
                    "kinds": {},
                    "score": 0.0,
                }
                by_path[path] = item
            return item

        for row in rows:
            src_path = edge_path(row["src_node_type"], row["src_node_id"])
            dst_path = edge_path(row["dst_node_type"], row["dst_node_id"])
            if not src_path and not dst_path:
                continue
            kind = row["kind"]
            if src_path:
                item = ensure(src_path)
                item["out_degree"] += 1
                item["degree"] += 1
                item["kinds"][kind] = item["kinds"].get(kind, 0) + 1
            if dst_path and dst_path != src_path:
                item = ensure(dst_path)
                item["in_degree"] += 1
                item["degree"] += 1
                item["kinds"][kind] = item["kinds"].get(kind, 0) + 1

        max_degree = max((int(item["degree"]) for item in by_path.values()), default=0)
        ranked = []
        for item in by_path.values():
            clone = dict(item)
            clone["kinds"] = dict(sorted(clone["kinds"].items()))
            clone["score"] = round((int(clone["degree"]) / max_degree) if max_degree else 0.0, 4)
            ranked.append(clone)
        ranked.sort(key=lambda item: (-float(item["score"]), item["path"]))
        return ranked[:limit] if limit else ranked

    def graph_stats(self, repo_id: str | None = None) -> dict[str, Any]:
        edge_params: list[Any] = []
        edge_where = ""
        if repo_id:
            edge_where = "WHERE src_repo_id = ? OR dst_repo_id = ?"
            edge_params.extend([repo_id, repo_id])
        edge_counts = {
            row["kind"]: int(row["count"])
            for row in self.conn.execute(
                f"""
                SELECT kind, COUNT(*) AS count
                FROM edges
                {edge_where}
                GROUP BY kind
                ORDER BY kind
                """,
                edge_params,
            ).fetchall()
        }
        node_params: list[Any] = []
        node_where = ""
        if repo_id:
            node_where = "WHERE repo_id = ?"
            node_params.append(repo_id)
        semantic_node_counts = {
            row["node_type"]: int(row["count"])
            for row in self.conn.execute(
                f"""
                SELECT node_type, COUNT(*) AS count
                FROM semantic_nodes
                {node_where}
                GROUP BY node_type
                ORDER BY node_type
                """,
                node_params,
            ).fetchall()
        }
        semantic_edge_params: list[Any] = []
        semantic_edge_repo = ""
        if repo_id:
            semantic_edge_repo = """
            JOIN semantic_nodes src ON src.node_id = e.src_node_id
            JOIN semantic_nodes dst ON dst.node_id = e.dst_node_id
            WHERE src.repo_id = ? OR dst.repo_id = ?
            """
            semantic_edge_params.extend([repo_id, repo_id])
        semantic_edge_counts = {
            row["kind"]: int(row["count"])
            for row in self.conn.execute(
                f"""
                SELECT e.kind, COUNT(*) AS count
                FROM semantic_edges e
                {semantic_edge_repo}
                GROUP BY e.kind
                ORDER BY e.kind
                """,
                semantic_edge_params,
            ).fetchall()
        }
        file_params: list[Any] = []
        file_join = ""
        file_where = ""
        if repo_id:
            file_join = "JOIN snapshots s ON s.snapshot_id = sf.snapshot_id"
            file_where = "WHERE s.repo_id = ?"
            file_params.append(repo_id)
        file_count = self.conn.execute(
            f"""
            SELECT COUNT(DISTINCT sf.path) AS count
            FROM snapshot_files sf
            {file_join}
            {file_where}
            """,
            file_params,
        ).fetchone()
        symbol_params: list[Any] = []
        symbol_where = ""
        if repo_id:
            symbol_where = "WHERE repo_id = ?"
            symbol_params.append(repo_id)
        symbol_count = self.conn.execute(
            f"""
            SELECT COUNT(*) AS count
            FROM symbol_identities
            {symbol_where}
            """,
            symbol_params,
        ).fetchone()
        return {
            "ok": True,
            "repo_id": repo_id,
            "files": int(file_count["count"] if file_count else 0),
            "symbols": int(symbol_count["count"] if symbol_count else 0),
            "logical_edges": edge_counts,
            "semantic_nodes": semantic_node_counts,
            "semantic_edges": semantic_edge_counts,
            "semantic_file_index": len(self.semantic_file_index(repo_id)) if repo_id else 0,
            "central_files": self.graph_file_centrality(repo_id, limit=10) if repo_id else [],
        }

    def graph_walk(
        self,
        *,
        repo_id: str,
        start_paths: Iterable[str],
        kinds: Iterable[str] | None = None,
        max_hops: int = 2,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        graph_kinds = tuple(kinds or ("imports", "tests", "calls", "defines"))
        normalized = sorted({path.replace("\\", "/").removeprefix("./") for path in start_paths if path})
        symbol_paths = {
            row["symbol_identity_id"]: row["path"]
            for row in self.conn.execute(
                "SELECT symbol_identity_id, path FROM symbol_identities WHERE repo_id = ?",
                (repo_id,),
            ).fetchall()
        }

        def readable(node_type: str, node_id: str) -> dict[str, Any]:
            item: dict[str, Any] = {"node_type": node_type, "node_id": node_id}
            if node_type == "file":
                item["path"] = node_id
            elif node_type == "symbol":
                item["path"] = symbol_paths.get(node_id)
                row = self.symbol_identity(node_id)
                if row:
                    item["qualname"] = row["qualname"]
                    item["kind"] = row["kind"]
            return item

        seen: set[tuple[str, str]] = {("file", path) for path in normalized}
        queue: list[tuple[str, str, int, float, list[str]]] = [
            ("file", path, 0, 1.0, [path]) for path in normalized
        ]
        results: dict[tuple[str, str, str, str, str], dict[str, Any]] = {}
        while queue and len(results) < limit:
            node_type, node_id, depth, confidence, route = queue.pop(0)
            if depth >= max(0, max_hops):
                continue
            for direction in ("out", "in"):
                for neighbor in self.neighbors(
                    repo_id=repo_id,
                    node_type=node_type,
                    node_id=node_id,
                    kinds=graph_kinds,
                    direction=direction,
                ):
                    next_confidence = confidence * neighbor.confidence
                    if next_confidence < 0.2:
                        continue
                    next_node = (neighbor.node_type, neighbor.node_id)
                    source = readable(node_type, node_id)
                    target = readable(neighbor.node_type, neighbor.node_id)
                    route_label = str(target.get("path") or target.get("qualname") or neighbor.node_id)
                    record = {
                        "from": source,
                        "to": target,
                        "direction": direction,
                        "kind": neighbor.kind,
                        "depth": depth + 1,
                        "confidence": round(next_confidence, 4),
                        "route": [*route, route_label],
                        "metadata": neighbor.metadata,
                    }
                    key = (
                        source["node_type"],
                        source["node_id"],
                        target["node_type"],
                        target["node_id"],
                        neighbor.kind,
                    )
                    existing = results.get(key)
                    if existing is None or float(record["confidence"]) > float(existing["confidence"]):
                        results[key] = record
                    if next_node not in seen:
                        seen.add(next_node)
                        queue.append(
                            (
                                neighbor.node_type,
                                neighbor.node_id,
                                depth + 1,
                                next_confidence,
                                [*route, route_label],
                            )
                        )
                    if len(results) >= limit:
                        break
                if len(results) >= limit:
                    break
        return sorted(
            results.values(),
            key=lambda item: (int(item["depth"]), item["kind"], item["route"]),
        )

    def write_memory_eval_run(self, *, repo_id: str, metrics: dict[str, Any]) -> str:
        run_id = stable_id(repo_id, canonical_json(metrics), utc_now())
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_eval_runs(memory_eval_run_id, repo_id, metrics_json, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (run_id, repo_id, canonical_json(metrics), utc_now()),
            )
        return run_id

    def snapshot_diff(self, left_snapshot: str, right_snapshot: str) -> dict[str, list[str]]:
        left = {
            row["path"]: row["file_version_id"]
            for row in self.conn.execute(
                "SELECT path, file_version_id FROM snapshot_files WHERE snapshot_id = ?",
                (left_snapshot,),
            ).fetchall()
        }
        right = {
            row["path"]: row["file_version_id"]
            for row in self.conn.execute(
                "SELECT path, file_version_id FROM snapshot_files WHERE snapshot_id = ?",
                (right_snapshot,),
            ).fetchall()
        }
        added: list[str] = []
        removed: list[str] = []
        changed: list[str] = []
        for path in sorted(set(left) | set(right)):
            if path not in left:
                added.append(path)
            elif path not in right:
                removed.append(path)
            elif left[path] != right[path]:
                changed.append(path)
        return {"added": added, "removed": removed, "changed": changed}

    def upsert_memory_record(
        self,
        *,
        record_id: str,
        workspace_id: str,
        repo_id: str | None,
        scope: str,
        type: str,
        subject_key: str,
        assertion: str,
        status: str,
        confidence: float,
        source_kind: str,
        extraction_method: str,
        title: str | None = None,
        importance: float | None = None,
        applies_when: str | None = None,
        avoid_when: str | None = None,
        trust: str | None = None,
        owner: str | None = None,
        expires_at: str | None = None,
        invalidates_when: str | None = None,
        last_validated_at: str | None = None,
        superseded_by: str | None = None,
        provenance: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        actor: str = "system",
        reason: str = "upsert_memory_record",
    ) -> str:
        now = utc_now()
        actual_trust = trust or _memory_trust_for_status(status)
        actual_importance = confidence if importance is None else importance
        actual_provenance = provenance or {
            "generator": "deterministic",
            "validator": "none",
            "input_source": "repo",
        }
        if status in {"approved", "active"} and _is_unvalidated_agent_memory(actual_provenance):
            raise ValueError("agent-generated memory requires a validator before promotion")
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_records(
                  record_id, workspace_id, repo_id, scope, type, subject_key,
                  title, assertion, status, trust, confidence, importance, source_kind,
                  extraction_method, applies_when, avoid_when, owner, expires_at,
                  invalidates_when, last_validated_at, superseded_by, provenance_json,
                  metadata_json, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(record_id) DO UPDATE SET
                  workspace_id=excluded.workspace_id,
                  repo_id=excluded.repo_id,
                  scope=excluded.scope,
                  type=excluded.type,
                  subject_key=excluded.subject_key,
                  title=excluded.title,
                  assertion=excluded.assertion,
                  status=excluded.status,
                  trust=excluded.trust,
                  confidence=excluded.confidence,
                  importance=excluded.importance,
                  source_kind=excluded.source_kind,
                  extraction_method=excluded.extraction_method,
                  applies_when=excluded.applies_when,
                  avoid_when=excluded.avoid_when,
                  owner=excluded.owner,
                  expires_at=excluded.expires_at,
                  invalidates_when=excluded.invalidates_when,
                  last_validated_at=excluded.last_validated_at,
                  superseded_by=COALESCE(excluded.superseded_by, memory_records.superseded_by),
                  provenance_json=excluded.provenance_json,
                  metadata_json=excluded.metadata_json,
                  updated_at=excluded.updated_at
                """,
                (
                    record_id,
                    workspace_id,
                    repo_id,
                    scope,
                    type,
                    subject_key,
                    title,
                    assertion,
                    status,
                    actual_trust,
                    confidence,
                    actual_importance,
                    source_kind,
                    extraction_method,
                    applies_when,
                    avoid_when,
                    owner,
                    expires_at,
                    invalidates_when,
                    last_validated_at,
                    superseded_by,
                    canonical_json(actual_provenance),
                    canonical_json(metadata or {}),
                    now,
                    now,
                ),
            )
            if status in {"rejected", "expired", "quarantined", "superseded"}:
                self.conn.execute("DELETE FROM memory_vectors WHERE record_id = ?", (record_id,))
        self.write_memory_revision(record_id=record_id, actor=actor, reason=reason)
        return record_id

    def memory_record(self, record_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM memory_records WHERE record_id = ?", (record_id,)
        ).fetchone()

    def memory_records(
        self,
        *,
        type: str | None = None,
        status: str | None = None,
        repo_id: str | None = None,
        workspace_id: str | None = None,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if type:
            clauses.append("type = ?")
            params.append(type)
        if status:
            clauses.append("status = ?")
            params.append(status)
        if repo_id:
            clauses.append("(repo_id = ? OR scope = 'workspace')")
            params.append(repo_id)
        if workspace_id:
            clauses.append("workspace_id = ?")
            params.append(workspace_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        return self.conn.execute(
            f"""
            SELECT * FROM memory_records
            {where}
            ORDER BY status, confidence DESC, assertion
            """,
            params,
        ).fetchall()

    def update_memory_record(
        self,
        *,
        record_id: str,
        patch: dict[str, Any],
        actor: str = "system",
        reason: str | None = None,
    ) -> None:
        allowed = {
            "type",
            "scope",
            "subject_key",
            "title",
            "assertion",
            "status",
            "trust",
            "confidence",
            "importance",
            "source_kind",
            "extraction_method",
            "applies_when",
            "avoid_when",
            "owner",
            "expires_at",
            "invalidates_when",
            "last_validated_at",
            "superseded_by",
            "provenance_json",
            "metadata_json",
        }
        selected = {key: value for key, value in patch.items() if key in allowed}
        if not selected:
            return
        row = self.memory_record(record_id)
        if row is None:
            raise KeyError(f"memory record not found: {record_id}")
        provenance = _json_dict(selected.get("provenance_json") or row["provenance_json"])
        next_status = str(selected.get("status", row["status"]))
        if next_status in {"approved", "active"} and _is_unvalidated_agent_memory(provenance):
            raise ValueError("agent-generated memory requires real-outcome or human validation")
        assignments = [f"{key} = ?" for key in selected]
        values = list(selected.values())
        assignments.append("updated_at = ?")
        values.append(utc_now())
        values.append(record_id)
        with self.conn:
            self.conn.execute(
                f"UPDATE memory_records SET {', '.join(assignments)} WHERE record_id = ?",
                values,
            )
            if next_status in {"rejected", "expired", "quarantined", "superseded"}:
                self.conn.execute("DELETE FROM memory_vectors WHERE record_id = ?", (record_id,))
        self.write_memory_revision(record_id=record_id, actor=actor, reason=reason or "update")

    def write_memory_revision(
        self,
        *,
        record_id: str,
        actor: str,
        reason: str | None = None,
    ) -> str:
        row = self.memory_record(record_id)
        if row is None:
            raise KeyError(f"memory record not found: {record_id}")
        record_json = canonical_json(dict(row))
        previous = self.conn.execute(
            """
            SELECT record_json FROM memory_revision
            WHERE record_id = ?
            ORDER BY rowid DESC
            LIMIT 1
            """,
            (record_id,),
        ).fetchone()
        previous_hash = stable_id(previous["record_json"]) if previous else None
        revision_id = stable_id(record_id, previous_hash or "", record_json, actor, reason or "", utc_now())
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_revision(
                  revision_id, record_id, previous_hash, record_json, actor, reason, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (revision_id, record_id, previous_hash, record_json, actor, reason, utc_now()),
            )
        return revision_id

    def memory_revisions(self, record_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM memory_revision
            WHERE record_id = ?
            ORDER BY rowid
            """,
            (record_id,),
        ).fetchall()

    def memory_revision(self, revision_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM memory_revision WHERE revision_id = ?", (revision_id,)
        ).fetchone()

    def enqueue_memory_review(
        self,
        *,
        record_id: str,
        reason: str,
        severity: str,
    ) -> str:
        sequence = self.conn.execute(
            "SELECT COUNT(*) FROM memory_review_queue WHERE record_id = ?", (record_id,)
        ).fetchone()[0]
        review_id = stable_id(record_id, reason, severity, utc_now(), sequence)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_review_queue(
                  review_id, record_id, reason, severity, status, created_at
                )
                VALUES (?, ?, ?, ?, 'open', ?)
                """,
                (review_id, record_id, reason, severity, utc_now()),
            )
        return review_id

    def memory_review_queue(self, status: str | None = None) -> list[sqlite3.Row]:
        if status:
            return self.conn.execute(
                """
                SELECT * FROM memory_review_queue
                WHERE status = ?
                ORDER BY severity DESC, created_at DESC
                """,
                (status,),
            ).fetchall()
        return self.conn.execute(
            """
            SELECT * FROM memory_review_queue
            ORDER BY status, severity DESC, created_at DESC
            """
        ).fetchall()

    def memory_review(self, review_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM memory_review_queue WHERE review_id = ?",
            (review_id,),
        ).fetchone()

    def resolve_memory_review(
        self,
        *,
        review_id: str,
        status: str,
        resolution: dict[str, Any],
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                UPDATE memory_review_queue
                SET status = ?, resolved_at = ?, resolution = ?
                WHERE review_id = ?
                """,
                (status, utc_now(), canonical_json(resolution), review_id),
            )

    def memory_records_by_subject(
        self,
        *,
        subject_key: str,
        type: str | None = None,
        repo_id: str | None = None,
        workspace_id: str | None = None,
    ) -> list[sqlite3.Row]:
        clauses = ["subject_key = ?"]
        params: list[Any] = [subject_key]
        if type:
            clauses.append("type = ?")
            params.append(type)
        if repo_id:
            clauses.append("(repo_id = ? OR scope = 'workspace')")
            params.append(repo_id)
        if workspace_id:
            clauses.append("workspace_id = ?")
            params.append(workspace_id)
        return self.conn.execute(
            f"""
            SELECT * FROM memory_records
            WHERE {' AND '.join(clauses)}
            ORDER BY status, confidence DESC, assertion
            """,
            params,
        ).fetchall()

    def put_memory_evidence(
        self,
        *,
        record_id: str,
        repo_id: str | None,
        path: str | None,
        symbol_identity_id: str | None,
        evidence_kind: str,
        evidence_hash: str,
        line_start: int | None = None,
        line_end: int | None = None,
        source_ref: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        evidence_id = stable_id(
            record_id,
            repo_id or "",
            path or "",
            symbol_identity_id or "",
            evidence_kind,
            evidence_hash,
            str(line_start or ""),
            str(line_end or ""),
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO memory_evidence(
                  evidence_id, record_id, repo_id, path, symbol_identity_id,
                  line_start, line_end, evidence_kind, evidence_hash,
                  source_ref, metadata_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    evidence_id,
                    record_id,
                    repo_id,
                    path,
                    symbol_identity_id,
                    line_start,
                    line_end,
                    evidence_kind,
                    evidence_hash,
                    source_ref,
                    canonical_json(metadata or {}),
                ),
            )
        return evidence_id

    def memory_evidence(self, record_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM memory_evidence
            WHERE record_id = ?
            ORDER BY path, line_start, evidence_kind
            """,
            (record_id,),
        ).fetchall()

    def append_memory_transition(
        self,
        *,
        record_id: str,
        from_status: str | None,
        to_status: str,
        actor: str,
        reason: str | None = None,
    ) -> str:
        sequence = self.conn.execute(
            "SELECT COUNT(*) FROM memory_transitions WHERE record_id = ?", (record_id,)
        ).fetchone()[0]
        transition_id = stable_id(
            record_id,
            from_status or "",
            to_status,
            actor,
            reason or "",
            utc_now(),
            sequence,
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_transitions(
                  transition_id, record_id, from_status, to_status, actor, reason, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (transition_id, record_id, from_status, to_status, actor, reason, utc_now()),
            )
        return transition_id

    def memory_transitions(self, record_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM memory_transitions
            WHERE record_id = ?
            ORDER BY created_at, transition_id
            """,
            (record_id,),
        ).fetchall()

    def upsert_memory_conflict(
        self,
        *,
        left_record_id: str,
        right_record_id: str,
        conflict_type: str,
        summary: str,
        status: str = "open",
    ) -> str:
        ordered = sorted([left_record_id, right_record_id])
        conflict_id = stable_id(ordered[0], ordered[1], conflict_type)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_conflicts(
                  conflict_id, left_record_id, right_record_id, conflict_type,
                  summary, status, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(conflict_id) DO UPDATE SET
                  summary=excluded.summary,
                  status=excluded.status
                """,
                (
                    conflict_id,
                    ordered[0],
                    ordered[1],
                    conflict_type,
                    summary,
                    status,
                    utc_now(),
                ),
            )
        return conflict_id

    def memory_conflicts(self, status: str | None = None) -> list[sqlite3.Row]:
        if status:
            return self.conn.execute(
                "SELECT * FROM memory_conflicts WHERE status = ? ORDER BY created_at DESC",
                (status,),
            ).fetchall()
        return self.conn.execute(
            "SELECT * FROM memory_conflicts ORDER BY status, created_at DESC"
        ).fetchall()

    def set_memory_record_status(
        self,
        *,
        record_id: str,
        status: str,
        actor: str = "system",
        reason: str | None = None,
        superseded_by: str | None = None,
        trust: str | None = None,
        provenance: dict[str, Any] | None = None,
        confidence: float | None = None,
    ) -> None:
        row = self.memory_record(record_id)
        previous = row["status"] if row else None
        actual_trust = trust or _memory_trust_for_status(status)
        actual_provenance = provenance
        if row and actual_provenance is None:
            actual_provenance = _json_dict(row["provenance_json"])
        if (
            row
            and status in {"approved", "active"}
            and actor == "system"
            and _is_unvalidated_agent_memory(actual_provenance or {})
        ):
            raise ValueError("agent-generated memory requires real-outcome or human validation")
        with self.conn:
            self.conn.execute(
                """
                UPDATE memory_records
                SET status = ?,
                    trust = ?,
                    confidence = COALESCE(?, confidence),
                    superseded_by = COALESCE(?, superseded_by),
                    provenance_json = COALESCE(?, provenance_json),
                    updated_at = ?
                WHERE record_id = ?
                """,
                (
                    status,
                    actual_trust,
                    confidence,
                    superseded_by,
                    canonical_json(actual_provenance) if provenance is not None else None,
                    utc_now(),
                    record_id,
                ),
            )
            if status in {"rejected", "expired", "quarantined", "superseded"}:
                self.conn.execute("DELETE FROM memory_vectors WHERE record_id = ?", (record_id,))
        if row and previous != status:
            self.append_memory_transition(
                record_id=record_id,
                from_status=previous,
                to_status=status,
                actor=actor,
                reason=reason,
            )
            self.write_memory_revision(record_id=record_id, actor=actor, reason=reason or status)

    def memory_search(
        self,
        query: str,
        *,
        types: list[str] | None = None,
        status: str | None = None,
        repo_id: str | None = None,
        workspace_id: str | None = None,
    ) -> list[sqlite3.Row]:
        terms = [term.lower() for term in query.split() if len(term) >= 2]
        rows = self.memory_records(
            status=status,
            repo_id=repo_id,
            workspace_id=workspace_id,
        )
        results = []
        allowed = set(types or [])
        for row in rows:
            if allowed and row["type"] not in allowed:
                continue
            assertion = row["assertion"].lower()
            if not terms or any(term in assertion for term in terms):
                results.append(row)
        return sorted(results, key=lambda row: (-float(row["confidence"]), row["type"], row["assertion"]))

    def put_memory_vector(
        self, *, record_id: str, dims: int, vector: list[float], model: str
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO memory_vectors(record_id, dims, vector_json, model, updated_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (record_id, dims, canonical_json(vector), model, utc_now()),
            )

    def memory_vectors(self, model: str | None = None) -> list[sqlite3.Row]:
        if model:
            return self.conn.execute(
                "SELECT * FROM memory_vectors WHERE model = ? ORDER BY record_id", (model,)
            ).fetchall()
        return self.conn.execute("SELECT * FROM memory_vectors ORDER BY record_id").fetchall()

    def upsert_memory_association(
        self,
        *,
        record_id: str,
        target_type: str,
        target_ref: str,
        kind: str,
        weight: float = 1.0,
        evidence: dict[str, Any] | None = None,
    ) -> str:
        association_id = stable_id(record_id, target_type, target_ref, kind)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_associations(
                  association_id, record_id, target_type, target_ref, kind,
                  weight, evidence_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(association_id) DO UPDATE SET
                  weight=excluded.weight,
                  evidence_json=excluded.evidence_json
                """,
                (
                    association_id,
                    record_id,
                    target_type,
                    target_ref,
                    kind,
                    weight,
                    canonical_json(evidence or {}),
                    utc_now(),
                ),
            )
        return association_id

    def memory_associations(
        self,
        *,
        record_id: str | None = None,
        target_type: str | None = None,
        target_ref: str | None = None,
        kind: str | None = None,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if record_id:
            clauses.append("record_id = ?")
            params.append(record_id)
        if target_type:
            clauses.append("target_type = ?")
            params.append(target_type)
        if target_ref:
            clauses.append("target_ref = ?")
            params.append(target_ref)
        if kind:
            clauses.append("kind = ?")
            params.append(kind)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        return self.conn.execute(
            f"""
            SELECT * FROM memory_associations
            {where}
            ORDER BY weight DESC, target_type, target_ref
            """,
            params,
        ).fetchall()

    def start_agent_session(
        self,
        *,
        session_id: str,
        workspace_id: str,
        repo_id: str | None,
        task_text_hash: str,
        agent_name: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        merged_metadata = {}
        existing = self.agent_session(session_id)
        if existing:
            try:
                parsed = json.loads(existing["metadata_json"] or "{}")
            except json.JSONDecodeError:
                parsed = {}
            if isinstance(parsed, dict):
                merged_metadata.update(parsed)
        merged_metadata.update(metadata or {})
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO agent_sessions(
                  session_id, workspace_id, repo_id, task_text_hash, agent_name,
                  started_at, ended_at, status, metadata_json
                )
                VALUES (?, ?, ?, ?, ?, ?, NULL, 'active', ?)
                ON CONFLICT(session_id) DO UPDATE SET
                  workspace_id=excluded.workspace_id,
                  repo_id=excluded.repo_id,
                  task_text_hash=excluded.task_text_hash,
                  agent_name=excluded.agent_name,
                  ended_at=NULL,
                  status='active',
                  metadata_json=excluded.metadata_json
                """,
                (
                    session_id,
                    workspace_id,
                    repo_id,
                    task_text_hash,
                    agent_name,
                    utc_now(),
                    canonical_json(merged_metadata),
                ),
            )
        return session_id

    def append_agent_session_event(
        self, *, session_id: str, event_type: str, payload: dict[str, Any]
    ) -> str:
        payload_json = canonical_json(payload)
        created_at = utc_now()
        with self.conn:
            sequence = self.conn.execute(
                """
                SELECT COUNT(*) AS event_count
                FROM agent_session_events
                WHERE session_id = ?
                """,
                (session_id,),
            ).fetchone()["event_count"]
            event_id = stable_id(session_id, event_type, payload_json, created_at, sequence)
            self.conn.execute(
                """
                INSERT INTO agent_session_events(
                  event_id, session_id, event_type, event_time, payload_json, payload_hash
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (event_id, session_id, event_type, created_at, payload_json, stable_id(payload_json)),
            )
        return event_id

    def put_agent_session_artifact(
        self,
        *,
        session_id: str,
        artifact_type: str,
        ref: str,
        content_hash: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        artifact_id = stable_id(session_id, artifact_type, ref, content_hash or "")
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO agent_session_artifacts(
                  artifact_id, session_id, artifact_type, ref, content_hash, metadata_json
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    artifact_id,
                    session_id,
                    artifact_type,
                    ref,
                    content_hash,
                    canonical_json(metadata or {}),
                ),
            )
        return artifact_id

    def finish_agent_session(
        self, *, session_id: str, status: str, metadata: dict[str, Any] | None = None
    ) -> None:
        with self.conn:
            row = self.agent_session(session_id)
            merged = {}
            if row:
                try:
                    merged = json.loads(row["metadata_json"] or "{}")
                except json.JSONDecodeError:
                    merged = {}
            merged.update(metadata or {})
            self.conn.execute(
                """
                UPDATE agent_sessions
                SET status = ?, ended_at = ?, metadata_json = ?
                WHERE session_id = ?
                """,
                (status, utc_now(), canonical_json(merged), session_id),
            )

    def agent_session(self, session_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM agent_sessions WHERE session_id = ?", (session_id,)
        ).fetchone()

    def agent_sessions(
        self,
        *,
        workspace_id: str | None = None,
        repo_id: str | None = None,
        status: str | None = None,
        limit: int = 20,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if workspace_id:
            clauses.append("workspace_id = ?")
            params.append(workspace_id)
        if repo_id:
            clauses.append("repo_id = ?")
            params.append(repo_id)
        if status:
            clauses.append("status = ?")
            params.append(status)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM agent_sessions
            {where}
            ORDER BY started_at DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def agent_session_events(self, session_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM agent_session_events
            WHERE session_id = ?
            ORDER BY event_time, event_id
            """,
            (session_id,),
        ).fetchall()

    def agent_session_artifacts(self, session_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM agent_session_artifacts
            WHERE session_id = ?
            ORDER BY artifact_type, ref
            """,
            (session_id,),
        ).fetchall()

    def agent_session_for_artifact(self, artifact_type: str, ref: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT s.*
            FROM agent_session_artifacts a
            JOIN agent_sessions s ON s.session_id = a.session_id
            WHERE a.artifact_type = ? AND a.ref = ?
            ORDER BY s.started_at DESC, s.session_id
            LIMIT 1
            """,
            (artifact_type, ref),
        ).fetchone()

    def start_task_session(
        self,
        *,
        task_session_id: str,
        workspace_id: str,
        repo_id: str | None,
        task_text_hash: str,
        constitution_hash: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO task_sessions(
                  task_session_id, workspace_id, repo_id, task_text_hash, current_state,
                  pack_id, constitution_hash, created_at, updated_at, metadata_json
                )
                VALUES (?, ?, ?, ?, COALESCE(
                  (SELECT current_state FROM task_sessions WHERE task_session_id = ?),
                  'INTAKE'
                ), COALESCE(
                  (SELECT pack_id FROM task_sessions WHERE task_session_id = ?),
                  NULL
                ), ?, COALESCE(
                  (SELECT created_at FROM task_sessions WHERE task_session_id = ?), ?
                ), ?, ?)
                """,
                (
                    task_session_id,
                    workspace_id,
                    repo_id,
                    task_text_hash,
                    task_session_id,
                    task_session_id,
                    constitution_hash,
                    task_session_id,
                    utc_now(),
                    utc_now(),
                    canonical_json(metadata or {}),
                ),
            )
        self.append_task_session_transition(
            task_session_id=task_session_id,
            from_state=None,
            to_state="INTAKE",
            actor="system",
            reason="task session started",
        )
        return task_session_id

    def append_task_session_transition(
        self,
        *,
        task_session_id: str,
        from_state: str | None,
        to_state: str,
        actor: str,
        reason: str | None = None,
        pack_id: str | None = None,
        constitution_hash: str | None = None,
    ) -> str:
        previous = self.conn.execute(
            """
            SELECT transition_hash
            FROM task_session_transitions
            WHERE task_session_id = ?
            ORDER BY rowid DESC
            LIMIT 1
            """,
            (task_session_id,),
        ).fetchone()
        prev_hash = previous["transition_hash"] if previous else ""
        created_at = utc_now()
        payload = canonical_json(
            {
                "task_session_id": task_session_id,
                "from_state": from_state,
                "to_state": to_state,
                "actor": actor,
                "reason": reason,
                "pack_id": pack_id,
                "constitution_hash": constitution_hash,
                "created_at": created_at,
            }
        )
        transition_hash = stable_id(prev_hash, payload)
        transition_id = stable_id(task_session_id, to_state, actor, reason or "", created_at)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO task_session_transitions(
                  transition_id, task_session_id, from_state, to_state, actor, reason,
                  prev_hash, transition_hash, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    transition_id,
                    task_session_id,
                    from_state,
                    to_state,
                    actor,
                    reason,
                    prev_hash,
                    transition_hash,
                    created_at,
                ),
            )
            self.conn.execute(
                """
                UPDATE task_sessions
                SET current_state = ?,
                    pack_id = COALESCE(?, pack_id),
                    constitution_hash = COALESCE(?, constitution_hash),
                    updated_at = ?
                WHERE task_session_id = ?
                """,
                (to_state, pack_id, constitution_hash, created_at, task_session_id),
            )
        return transition_id

    def task_session(self, task_session_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM task_sessions WHERE task_session_id = ?", (task_session_id,)
        ).fetchone()

    def task_session_transitions(self, task_session_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM task_session_transitions
            WHERE task_session_id = ?
            ORDER BY rowid
            """,
            (task_session_id,),
        ).fetchall()

    def write_task_plan(
        self,
        *,
        workspace_id: str,
        repo_id: str | None,
        plan_hash: str,
        plan: dict[str, Any],
        validation: dict[str, Any],
        author: str,
        task_session_id: str | None = None,
        reason: str | None = None,
        status: str = "active",
        metadata: dict[str, Any] | None = None,
        previous_plan_hash: str | None = None,
        plan_id: str | None = None,
    ) -> dict[str, Any]:
        plan_id = plan_id or stable_id(
            workspace_id,
            repo_id or "",
            task_session_id or "",
            plan_hash,
        )
        latest = self.conn.execute(
            """
            SELECT revision_number, plan_hash
            FROM task_plan_revisions
            WHERE plan_id = ?
            ORDER BY revision_number DESC
            LIMIT 1
            """,
            (plan_id,),
        ).fetchone()
        revision_number = 1 if latest is None else int(latest["revision_number"]) + 1
        previous_hash = previous_plan_hash
        if previous_hash is None and latest is not None:
            previous_hash = latest["plan_hash"]
        created_at = utc_now()
        revision_id = stable_id(plan_id, revision_number, plan_hash, previous_hash or "", created_at)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO task_plans(
                  plan_id, task_session_id, workspace_id, repo_id, plan_hash, status,
                  current_revision_id, created_at, updated_at, metadata_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(plan_id) DO UPDATE SET
                  task_session_id=excluded.task_session_id,
                  workspace_id=excluded.workspace_id,
                  repo_id=excluded.repo_id,
                  plan_hash=excluded.plan_hash,
                  status=excluded.status,
                  current_revision_id=excluded.current_revision_id,
                  updated_at=excluded.updated_at,
                  metadata_json=excluded.metadata_json
                """,
                (
                    plan_id,
                    task_session_id,
                    workspace_id,
                    repo_id,
                    plan_hash,
                    status,
                    revision_id,
                    created_at,
                    created_at,
                    canonical_json(metadata or {}),
                ),
            )
            self.conn.execute(
                """
                INSERT INTO task_plan_revisions(
                  revision_id, plan_id, revision_number, plan_hash, previous_plan_hash,
                  author, reason, plan_json, validation_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    revision_id,
                    plan_id,
                    revision_number,
                    plan_hash,
                    previous_hash,
                    author,
                    reason,
                    canonical_json(plan),
                    canonical_json(validation),
                    created_at,
                ),
            )
        return {
            "plan_id": plan_id,
            "revision_id": revision_id,
            "revision_number": revision_number,
            "plan_hash": plan_hash,
            "previous_plan_hash": previous_hash,
        }

    def task_plan(self, plan_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM task_plans WHERE plan_id = ?", (plan_id,)
        ).fetchone()

    def latest_task_plan_for_session(self, task_session_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT * FROM task_plans
            WHERE task_session_id = ?
            ORDER BY updated_at DESC, plan_id
            LIMIT 1
            """,
            (task_session_id,),
        ).fetchone()

    def task_plan_revisions(self, plan_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM task_plan_revisions
            WHERE plan_id = ?
            ORDER BY revision_number
            """,
            (plan_id,),
        ).fetchall()

    def record_task_plan_checkpoint(
        self,
        *,
        plan_id: str,
        step_id: str,
        status: str,
        changed_paths: list[str],
        violations: list[dict[str, Any]],
    ) -> str:
        created_at = utc_now()
        checkpoint_id = stable_id(
            plan_id,
            step_id,
            status,
            canonical_json(changed_paths),
            canonical_json(violations),
            created_at,
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO task_plan_checkpoints(
                  checkpoint_id, plan_id, step_id, status, changed_paths_json,
                  violations_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    checkpoint_id,
                    plan_id,
                    step_id,
                    status,
                    canonical_json(changed_paths),
                    canonical_json(violations),
                    created_at,
                ),
            )
        return checkpoint_id

    def task_plan_checkpoints(self, plan_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM task_plan_checkpoints
            WHERE plan_id = ?
            ORDER BY rowid
            """,
            (plan_id,),
        ).fetchall()

    def record_memory_access(
        self, *, pack_id: str, memory_record_id: str, score: float, signals: list[dict[str, Any]]
    ) -> str:
        access_id = stable_id(pack_id, memory_record_id, utc_now())
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_access_log(
                  access_id, pack_id, memory_record_id, served_at, score, signals_json
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (access_id, pack_id, memory_record_id, utc_now(), score, canonical_json(signals)),
            )
        return access_id

    def memory_accesses(self, pack_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT l.*, r.type, r.assertion
            FROM memory_access_log l
            JOIN memory_records r ON r.record_id = l.memory_record_id
            WHERE l.pack_id = ?
            ORDER BY l.score DESC, r.type, r.assertion
            """,
            (pack_id,),
        ).fetchall()

    def record_memory_utilization(
        self,
        *,
        pack_id: str,
        memory_record_id: str,
        utilization_kind: str,
        score: float,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        utilization_id = stable_id(
            pack_id,
            memory_record_id,
            utilization_kind,
            canonical_json(metadata or {}),
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO memory_utilization(
                  utilization_id, pack_id, memory_record_id, utilization_kind,
                  score, metadata_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    utilization_id,
                    pack_id,
                    memory_record_id,
                    utilization_kind,
                    score,
                    canonical_json(metadata or {}),
                    utc_now(),
                ),
            )
        return utilization_id

    def memory_utilization(self, pack_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT u.*, r.type, r.assertion
            FROM memory_utilization u
            JOIN memory_records r ON r.record_id = u.memory_record_id
            WHERE u.pack_id = ?
            ORDER BY u.score DESC, r.type, r.assertion
            """,
            (pack_id,),
        ).fetchall()

    def outcome(self, outcome_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM outcomes WHERE outcome_id = ?",
            (outcome_id,),
        ).fetchone()

    def write_learning_event(
        self,
        *,
        phase: str,
        kind: str,
        ref: str | None = None,
        payload: dict[str, Any] | None = None,
    ) -> str:
        ts = utc_now()
        event_id = stable_id(
            "learning_event",
            phase,
            kind,
            ref or "",
            canonical_json(payload or {}),
            ts,
            time.time_ns(),
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO learning_event(event_id, ts, phase, kind, ref, payload_json)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (event_id, ts, phase, kind, ref, canonical_json(payload or {})),
            )
        return event_id

    def learning_events(self, limit: int = 50) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM learning_event
            ORDER BY ts DESC, event_id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()

    def write_learning_run(
        self,
        *,
        target: str,
        kind: str,
        before: dict[str, Any],
        after: dict[str, Any],
        train_metrics: dict[str, Any] | None = None,
        holdout_metrics: dict[str, Any] | None = None,
        gate_pass: bool = False,
        archived: bool = True,
        promoted: bool = False,
        run_id: str | None = None,
    ) -> str:
        created_at = utc_now()
        run_id = run_id or stable_id(
            "learning_run",
            target,
            kind,
            canonical_json(before),
            canonical_json(after),
            created_at,
        )
        with self.conn:
            if promoted:
                self.conn.execute(
                    "UPDATE learning_run SET promoted = 0 WHERE target = ?",
                    (target,),
                )
            self.conn.execute(
                """
                INSERT OR REPLACE INTO learning_run(
                  run_id, target, kind, before_json, after_json, train_metrics_json,
                  holdout_metrics_json, gate_pass, archived, promoted, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    target,
                    kind,
                    canonical_json(before),
                    canonical_json(after),
                    canonical_json(train_metrics or {}),
                    canonical_json(holdout_metrics or {}),
                    int(gate_pass),
                    int(archived),
                    int(promoted),
                    created_at,
                ),
            )
        return run_id

    def learning_run(self, run_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM learning_run WHERE run_id = ?",
            (run_id,),
        ).fetchone()

    def learning_runs(
        self,
        *,
        target: str | None = None,
        kind: str | None = None,
        promoted: bool | None = None,
        limit: int = 50,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if target:
            clauses.append("target = ?")
            params.append(target)
        if kind:
            clauses.append("kind = ?")
            params.append(kind)
        if promoted is not None:
            clauses.append("promoted = ?")
            params.append(int(promoted))
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM learning_run
            {where}
            ORDER BY promoted DESC, gate_pass DESC, created_at DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def promoted_learning_runs(self) -> list[sqlite3.Row]:
        return self.learning_runs(promoted=True, limit=100)

    def promote_learning_run(self, run_id: str) -> None:
        row = self.learning_run(run_id)
        if row is None:
            raise KeyError(f"learning run not found: {run_id}")
        with self.conn:
            self.conn.execute(
                "UPDATE learning_run SET promoted = 0 WHERE target = ?",
                (row["target"],),
            )
            self.conn.execute(
                "UPDATE learning_run SET promoted = 1, archived = 1 WHERE run_id = ?",
                (run_id,),
            )

    def unpromote_learning_run(self, run_id: str) -> None:
        with self.conn:
            self.conn.execute(
                "UPDATE learning_run SET promoted = 0 WHERE run_id = ?",
                (run_id,),
            )

    def upsert_skill(
        self,
        *,
        skill_id: str,
        name: str,
        nl_description: str,
        trigger_signature: str,
        steps: list[dict[str, Any]],
        evidence: list[dict[str, Any]] | None = None,
        embedding_ref: str | None = None,
        provenance: dict[str, Any] | None = None,
        success_count: int = 0,
        fail_count: int = 0,
        last_validated_at: str | None = None,
        status: str = "candidate",
        trust: str = "untrusted",
    ) -> str:
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO skill(
                  skill_id, name, nl_description, trigger_signature, steps_json,
                  evidence_json, embedding_ref, provenance_json, success_count,
                  fail_count, last_validated_at, status, trust, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(skill_id) DO UPDATE SET
                  name=excluded.name,
                  nl_description=excluded.nl_description,
                  trigger_signature=excluded.trigger_signature,
                  steps_json=excluded.steps_json,
                  evidence_json=excluded.evidence_json,
                  embedding_ref=excluded.embedding_ref,
                  provenance_json=excluded.provenance_json,
                  success_count=MAX(skill.success_count, excluded.success_count),
                  fail_count=MAX(skill.fail_count, excluded.fail_count),
                  last_validated_at=COALESCE(excluded.last_validated_at, skill.last_validated_at),
                  status=excluded.status,
                  trust=excluded.trust,
                  updated_at=excluded.updated_at
                """,
                (
                    skill_id,
                    name,
                    nl_description,
                    trigger_signature,
                    canonical_json(steps),
                    canonical_json(evidence or []),
                    embedding_ref,
                    canonical_json(provenance or {}),
                    success_count,
                    fail_count,
                    last_validated_at,
                    status,
                    trust,
                    now,
                    now,
                ),
            )
        return skill_id

    def skill(self, skill_id: str) -> sqlite3.Row | None:
        return self.conn.execute("SELECT * FROM skill WHERE skill_id = ?", (skill_id,)).fetchone()

    def skills(
        self,
        *,
        status: str | None = None,
        trust: str | None = None,
        limit: int = 100,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if status:
            clauses.append("status = ?")
            params.append(status)
        if trust:
            clauses.append("trust = ?")
            params.append(trust)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM skill
            {where}
            ORDER BY status, trust, success_count DESC, fail_count ASC, updated_at DESC, name
            LIMIT ?
            """,
            params,
        ).fetchall()

    def set_skill_status(
        self,
        *,
        skill_id: str,
        status: str,
        trust: str | None = None,
        provenance: dict[str, Any] | None = None,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                UPDATE skill
                SET status = ?,
                    trust = COALESCE(?, trust),
                    provenance_json = COALESCE(?, provenance_json),
                    updated_at = ?
                WHERE skill_id = ?
                """,
                (
                    status,
                    trust,
                    canonical_json(provenance) if provenance is not None else None,
                    utc_now(),
                    skill_id,
                ),
            )

    def record_skill_replay(
        self,
        *,
        skill_id: str,
        success: bool,
        promoted: bool = False,
        provenance: dict[str, Any] | None = None,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                UPDATE skill
                SET success_count = success_count + ?,
                    fail_count = fail_count + ?,
                    last_validated_at = CASE WHEN ? THEN ? ELSE last_validated_at END,
                    status = CASE WHEN ? THEN 'active' ELSE status END,
                    trust = CASE WHEN ? THEN 'approved' ELSE trust END,
                    provenance_json = COALESCE(?, provenance_json),
                    updated_at = ?
                WHERE skill_id = ?
                """,
                (
                    1 if success else 0,
                    0 if success else 1,
                    1 if success else 0,
                    utc_now(),
                    1 if promoted else 0,
                    1 if promoted else 0,
                    canonical_json(provenance) if provenance is not None else None,
                    utc_now(),
                    skill_id,
                ),
            )

    def write_pack(
        self,
        *,
        pack_id: str,
        snapshot_id: str,
        repo_id: str,
        task_text_hash: str,
        manifest: dict[str, Any],
        reconstructible: bool,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO context_packs(
                  pack_id, snapshot_id, repo_id, task_text_hash,
                  manifest_json, reconstructible, created_at, metadata_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    pack_id,
                    snapshot_id,
                    repo_id,
                    task_text_hash,
                    canonical_json(manifest),
                    int(reconstructible),
                    utc_now(),
                    canonical_json(metadata or {}),
                ),
            )

    def get_pack(self, pack_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM context_packs WHERE pack_id = ?", (pack_id,)
        ).fetchone()

    def append_audit(self, *, pack_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        previous = self.conn.execute(
            "SELECT row_hash FROM audit_log ORDER BY audit_id DESC LIMIT 1"
        ).fetchone()
        prev_hash = previous["row_hash"] if previous else ""
        payload_json = canonical_json(payload)
        row_hash = stable_id(prev_hash, payload_json)
        with self.conn:
            cur = self.conn.execute(
                """
                INSERT INTO audit_log(pack_id, prev_hash, row_hash, payload_json, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (pack_id, prev_hash, row_hash, payload_json, utc_now()),
            )
        return {"audit_id": cur.lastrowid, "prev_hash": prev_hash, "row_hash": row_hash}

    def audit_record(self, pack_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM audit_log WHERE pack_id = ? ORDER BY audit_id DESC LIMIT 1", (pack_id,)
        ).fetchone()

    def verify_audit_chain(self) -> dict[str, Any]:
        rows = self.conn.execute("SELECT * FROM audit_log ORDER BY audit_id").fetchall()
        prev_hash = ""
        for row in rows:
            expected = stable_id(prev_hash, row["payload_json"])
            if row["prev_hash"] != prev_hash or row["row_hash"] != expected:
                return {
                    "ok": False,
                    "audit_id": row["audit_id"],
                    "expected": expected,
                    "actual": row["row_hash"],
                }
            prev_hash = row["row_hash"]
        return {"ok": True, "rows": len(rows), "tip": prev_hash}

    def record_outcome(self, *, pack_id: str, result: str, files_changed: list[str]) -> str:
        outcome_id = stable_id(pack_id, result, canonical_json(files_changed), utc_now())
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO outcomes(outcome_id, pack_id, result, files_changed_json, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (outcome_id, pack_id, result, canonical_json(files_changed), utc_now()),
            )
        return outcome_id

    def delete_unreferenced_file_versions(self) -> int:
        with self.conn:
            cur = self.conn.execute(
                """
                DELETE FROM file_versions
                WHERE file_version_id NOT IN (SELECT file_version_id FROM snapshot_files)
                """
            )
        return cur.rowcount

    def gc(self) -> dict[str, int]:
        deleted_file_versions = self.delete_unreferenced_file_versions()
        with self.conn:
            cur = self.conn.execute(
                """
                DELETE FROM chunks
                WHERE snapshot_id NOT IN (SELECT snapshot_id FROM snapshots)
                """
            )
            deleted_chunks = cur.rowcount
        return {"deleted_file_versions": deleted_file_versions, "deleted_chunks": deleted_chunks}


def _edge_logical_key(row: Any) -> tuple[Any, ...]:
    return (
        row["scope_snapshot_id"],
        row["src_repo_id"],
        row["src_node_type"],
        row["src_node_id"],
        row["dst_repo_id"],
        row["dst_node_type"],
        row["dst_node_id"],
        row["kind"],
    )


def _merge_metadata(left: dict[str, Any], right: dict[str, Any]) -> dict[str, Any]:
    merged: dict[str, Any] = dict(left)
    for key, value in right.items():
        if key not in merged:
            merged[key] = value
            continue
        if key == "deduped_edge_count":
            merged[key] = max(int(merged[key]), int(value))
            continue
        merged[key] = _merge_metadata_value(merged[key], value)
    return {key: merged[key] for key in sorted(merged)}


def _merge_metadata_value(left: Any, right: Any) -> Any:
    if left == right:
        return left
    left_values = _metadata_values(left)
    right_values = _metadata_values(right)
    by_json = {canonical_json(value): value for value in [*left_values, *right_values]}
    values = [by_json[key] for key in sorted(by_json)]
    if all(not isinstance(value, (dict, list)) for value in values):
        return values
    return values


def _metadata_values(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    return [value]


def _memory_trust_for_status(status: str) -> str:
    if status in {"active", "approved", "candidate", "untrusted"}:
        return status
    return "candidate"


def _json_dict(value: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _float_metric(values: dict[str, Any], key: str) -> float:
    value = values.get(key)
    return round(float(value), 6) if isinstance(value, (int, float)) else 0.0


def _is_unvalidated_agent_memory(provenance: dict[str, Any]) -> bool:
    generator = str(provenance.get("generator", ""))
    validator = str(provenance.get("validator", "none") or "none")
    return generator.startswith("agent:") and validator in {"", "none", "null"}
