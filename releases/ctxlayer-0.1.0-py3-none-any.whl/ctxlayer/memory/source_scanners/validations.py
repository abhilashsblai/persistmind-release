from __future__ import annotations

import re
from pathlib import Path

from ctxlayer.memory.evidence import RuleCandidate, RuleEvidence
from ctxlayer.memory.source_scanners.common import scan_rule_text


def scan(root: Path) -> list[RuleCandidate]:
    candidates: list[RuleCandidate] = []
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".py", ".ts", ".tsx", ".js", ".java", ".go"}:
            continue
        rel = path.relative_to(root).as_posix()
        text = path.read_text(encoding="utf-8", errors="replace")
        if any(token in text.lower() for token in ["validate", "permission", "refund", "payment", "billing"]):
            candidates.extend(scan_rule_text(path, root, "code", 0.68))
        for match in re.finditer(r"raise\s+\w*Error\(['\"]([^'\"]{12,180})['\"]\)|throw new \w+\(['\"]([^'\"]{12,180})['\"]\)", text):
            message = match.group(1) or match.group(2)
            if any(word in message.lower() for word in ["cannot", "must", "required", "not allowed"]):
                line = text[: match.start()].count("\n") + 1
                candidates.append(
                    RuleCandidate(
                        text=message,
                        source_type="code",
                        confidence=0.7,
                        evidence=[
                            RuleEvidence(rel, "validation_error", message, line_start=line, line_end=line)
                        ],
                    )
                )
    return candidates
