from __future__ import annotations

import re
from pathlib import Path

from ctxlayer.memory.evidence import RuleCandidate, RuleEvidence
from ctxlayer.memory.source_scanners.common import scan_rule_text


def scan(root: Path) -> list[RuleCandidate]:
    candidates: list[RuleCandidate] = []
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".py", ".ts", ".tsx", ".js"}:
            continue
        rel = path.relative_to(root).as_posix()
        if not ("/test" in rel or path.name.startswith("test_") or ".test." in path.name):
            continue
        candidates.extend(scan_rule_text(path, root, "test", 0.82))
        text = path.read_text(encoding="utf-8", errors="replace")
        for match in re.finditer(r"def\s+test_([A-Za-z0-9_]+)|it\(['\"]([^'\"]+)['\"]", text):
            raw = (match.group(1) or match.group(2) or "").replace("_", " ")
            if any(word in raw.lower() for word in ["must", "should", "require", "cannot", "never"]):
                line = text[: match.start()].count("\n") + 1
                candidates.append(
                    RuleCandidate(
                        text=raw,
                        source_type="test",
                        confidence=0.72,
                        evidence=[
                            RuleEvidence(rel, "test_name", raw, line_start=line, line_end=line)
                        ],
                    )
                )
    return candidates
