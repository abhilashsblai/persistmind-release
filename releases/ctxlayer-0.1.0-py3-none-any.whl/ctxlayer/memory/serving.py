from __future__ import annotations

import fnmatch
from typing import Any


def relevant_rules(rules: list[dict[str, Any]], paths: list[str]) -> list[dict[str, Any]]:
    selected = []
    for rule in rules:
        scope = rule.get("scope_glob") or "**"
        if any(fnmatch.fnmatch(path, scope) or fnmatch.fnmatch(scope, path) for path in paths):
            selected.append(rule)
    return selected
