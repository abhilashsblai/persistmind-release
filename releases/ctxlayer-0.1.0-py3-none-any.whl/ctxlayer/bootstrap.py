from __future__ import annotations

import json
from pathlib import Path
from typing import Any


CONTRACT_MARKER = "<!-- ctxlayer-agent-contract -->"
PLAN_CREATE_FILE_SNIPPET = """$planPath = Join-Path $env:TEMP "ctxlayer-plan.json"
$planJson = @'
{
  "objective": "<objective>",
  "steps": [
    {
      "id": "edit",
      "title": "<step title>",
      "intended_files": ["<path>"],
      "intended_tests": [],
      "capabilities": ["edit_source"],
      "risk": "medium"
    }
  ]
}
'@
[System.IO.File]::WriteAllText($planPath, $planJson, [System.Text.UTF8Encoding]::new($false))
ctxlayer --repo . plan create --task-session-id <task_session_id> --pack-id <pack_id> --file $planPath"""
POWERSHELL_PLAN_FILE_GUIDANCE = (
    "Do not pass plan JSON inline on PowerShell. Always write the plan payload to a\n"
    "UTF-8 JSON file and pass it with `ctxlayer plan create --file`."
)
CODEX_MEMORY_PARALLEL_GUIDANCE = """## Codex Memory and Parallel-Agent Enforcement

Before write-capable Codex work, run:

```powershell
ctxlayer --repo . codex preflight --task "<task>"
```

Treat the returned `memory_retrieval_id`, `continuation_matches`,
`served_memory_counts_by_type`, `policy_reference_count`, `skill_match_count`,
and `parallel_recommendation` as required context. Use the relevant memory area
for the task: active continuations for interrupted work, project memory for
facts/decisions/gotchas, policy references for governance pointers, and skills
for repeatable workflows.

For broad or disjoint work, follow the returned `parallel_agent_plan`. Spawn
CTX-scoped explorer, worker, reviewer, and verifier agents when recommended,
keep worker write scopes disjoint, and let the parent agent perform final
integration, CTX checks, tests, and outcome recording.
"""


def bootstrap_project(
    repo_root: Path,
    *,
    agents: list[str],
    mcp_command: str = "ctxlayer",
    mcp_repo: str = ".",
) -> dict[str, Any]:
    agents = sorted({agent.strip().lower() for agent in agents if agent.strip()})
    ag_path = repo_root / "AGENTS.md"
    existing = ag_path.read_text(encoding="utf-8") if ag_path.exists() else ""
    changed_agents = False
    if CONTRACT_MARKER not in existing:
        addition = _agent_contract(agents)
        if existing and not existing.endswith("\n"):
            existing += "\n"
        existing = f"{existing}\n{addition}" if existing else addition
        ag_path.write_text(existing, encoding="utf-8")
        changed_agents = True
    else:
        updated = _ensure_agent_contract_guidance(existing)
        if updated != existing:
            ag_path.write_text(updated, encoding="utf-8")
            changed_agents = True

    mcp_dir = repo_root / ".ctxlayer" / "mcp"
    mcp_dir.mkdir(parents=True, exist_ok=True)
    written = [
        _write_if_changed(mcp_dir / "codex.config.toml", _codex_config(mcp_command, mcp_repo)),
        _write_if_changed(mcp_dir / "claude-code.ps1", _claude_command(mcp_command, mcp_repo)),
        _write_if_changed(mcp_dir / "README.md", _mcp_readme(mcp_command, mcp_repo)),
    ]
    codex_written = _write_codex_project_surfaces(repo_root, mcp_command, mcp_repo)
    capabilities_path = repo_root / "ctxlayer.capabilities.yaml"
    capabilities_created = False
    if not capabilities_path.exists():
        _write_if_changed(capabilities_path, _capabilities_yaml())
        capabilities_created = True

    return {
        "agents": agents,
        "agents_file": str(ag_path),
        "agents_file_updated": changed_agents,
        "capabilities_file": str(capabilities_path),
        "capabilities_file_created": capabilities_created,
        "mcp_dir": str(mcp_dir),
        "mcp_repo": mcp_repo,
        "mcp_files": [str(path) for path in written],
        "codex_dir": str(repo_root / ".codex"),
        "codex_files": [str(path) for path in codex_written],
    }


def _write_if_changed(path: Path, content: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists() or path.read_text(encoding="utf-8") != content:
        path.write_text(content, encoding="utf-8")
    return path


def _write_codex_project_surfaces(repo_root: Path, command: str, mcp_repo: str) -> list[Path]:
    codex_dir = repo_root / ".codex"
    agents_dir = codex_dir / "agents"
    hook_dir = repo_root / ".ctxlayer" / "codex" / "hooks"
    return [
        _write_if_changed(codex_dir / "config.toml", _codex_project_config(command, mcp_repo)),
        _write_if_changed(codex_dir / "hooks.json", _codex_hooks_json(repo_root)),
        _write_if_changed(agents_dir / "ctx-explorer.toml", _codex_agent_explorer()),
        _write_if_changed(agents_dir / "ctx-worker.toml", _codex_agent_worker()),
        _write_if_changed(agents_dir / "ctx-reviewer.toml", _codex_agent_reviewer()),
        _write_if_changed(agents_dir / "ctx-verifier.toml", _codex_agent_verifier()),
        _write_if_changed(hook_dir / "ctxlayer_hook.py", _codex_hook_script()),
    ]


def _ensure_agent_contract_guidance(existing: str) -> str:
    updated = _replace_inline_json_plan_commands(existing)
    if "## Codex Memory and Parallel-Agent Enforcement" not in updated:
        updated = updated.rstrip() + "\n\n" + CODEX_MEMORY_PARALLEL_GUIDANCE.rstrip() + "\n"
    if "Do not pass plan JSON inline on PowerShell." in updated:
        return updated

    guidance = f"{POWERSHELL_PLAN_FILE_GUIDANCE}\n\n"
    before_plan_rules = "The plan must include an objective and a `steps` list."
    if before_plan_rules in updated:
        return updated.replace(before_plan_rules, guidance + before_plan_rules, 1)

    if updated.endswith("\n"):
        return updated + "\n" + guidance.rstrip() + "\n"
    return updated + "\n\n" + guidance.rstrip() + "\n"


def _replace_inline_json_plan_commands(existing: str) -> str:
    lines: list[str] = []
    for line in existing.splitlines(keepends=True):
        stripped = line.strip()
        newline = "\n" if line.endswith("\n") else ""
        if stripped.startswith("ctxlayer --repo . plan create ") and " --json " in stripped:
            lines.append(PLAN_CREATE_FILE_SNIPPET + newline)
        elif stripped.startswith("ctxlayer --repo . plan amend ") and " --json " in stripped:
            lines.append(
                'ctxlayer --repo . plan amend <plan_id> --reason "<reason>" '
                "--file <updated_plan_json_file>" + newline
            )
        else:
            lines.append(line)
    return "".join(lines)


def _agent_contract(agents: list[str]) -> str:
    names = ", ".join(agents) if agents else "Claude, Codex"
    return f"""# CTX Layer Agent Usage Contract
{CONTRACT_MARKER}

This project is guided by CTX Layer for AI coding agents: {names}.

Before editing this repository, request a CTX Layer context pack:

```powershell
ctxlayer --repo . task start --task "<task>"
ctxlayer --repo . pack --task "<task>"
```

Record the returned `task_session_id`, `pack_id`, and `agent_session_id`. Task
start, pack serving, plans, checkpoints, verification runs, and outcomes are
mirrored into agent session memory automatically. Create a structured task plan
before coding:

```powershell
{PLAN_CREATE_FILE_SNIPPET}
```

{POWERSHELL_PLAN_FILE_GUIDANCE}

{CODEX_MEMORY_PARALLEL_GUIDANCE}

The plan must include an objective and a `steps` list. Each step must include
`id`, `title`, `intended_files`, `intended_tests`, `capabilities`, and `risk`
(`low`, `medium`, `high`, or `critical`).

During or after edits, checkpoint changed files against the active plan step:

```powershell
ctxlayer --repo . plan checkpoint <plan_id> --step-id <step_id> --path <changed_path>
```

If a checkpoint fails, amend the plan with a reason or remove the out-of-step
edit before continuing:

```powershell
ctxlayer --repo . plan amend <plan_id> --reason "<reason>" --file <updated_plan_json_file>
```

Before declaring work complete, run the local preflight and impact report:

```powershell
git diff HEAD | ctxlayer --repo . check-diff --pack-id <pack_id>
git diff --name-only HEAD | ctxlayer --repo . check-diff --pack-id <pack_id> --paths-from-stdin
git diff --name-only HEAD | ctxlayer --repo . impact --paths-from-stdin
```

Run the tests named by the impact report where practical, then record the outcome:

```powershell
ctxlayer --repo . outcome --pack-id <pack_id> --result pass
```

To inspect the remembered development episode, explain the returned session:

```powershell
ctxlayer --repo . session explain --session-id <agent_session_id>
```

If any CTX Layer check fails, do not declare the task complete. Fix the issue or
report the exact blocker.

The audit chain is tamper-evident for accidental edits and partial tampering. It is
not tamper-proof against an actor with full filesystem control who can rewrite the
database and recompute the chain.
"""


def codex_mcp_config(command: str = "ctxlayer", mcp_repo: str = ".") -> str:
    return f"""# Copy this block into your Codex config when you want this project to use CTX Layer.
[mcp_servers.ctxlayer]
command = {_toml_string(command)}
args = ["mcp", "--repo", {_toml_string(mcp_repo)}]
"""


def _codex_config(command: str, mcp_repo: str) -> str:
    return codex_mcp_config(command, mcp_repo)


def _codex_project_config(command: str, mcp_repo: str) -> str:
    return f"""# Generated by CTX Layer. Project-local Codex config loads only when this repo is trusted.
[features]
hooks = true
multi_agent = true
memories = true

[agents]
max_threads = 4
max_depth = 1

[mcp_servers.ctxlayer]
command = {_toml_string(command)}
args = ["mcp", "--repo", {_toml_string(mcp_repo)}]
"""


def _codex_hooks_json(repo_root: Path | None = None) -> str:
    hook = 'python "$(git rev-parse --show-toplevel)/.ctxlayer/codex/hooks/ctxlayer_hook.py"'
    initial_repo = _powershell_string(str(repo_root)) if repo_root else "$null"
    hook_windows = (
        'powershell -NoProfile -ExecutionPolicy Bypass -Command '
        '"$payload = [Console]::In.ReadToEnd(); '
        f'$repo = {initial_repo}; '
        'if (-not $repo -or -not (Test-Path $repo)) { '
        '$repo = git rev-parse --show-toplevel; '
        'if ($LASTEXITCODE -ne 0 -or -not $repo) { $repo = $env:CODEX_PROJECT_DIR } '
        '}; '
        '$env:CTXLAYER_REPO = $repo; '
        '$payload | & python (Join-Path $repo \'.ctxlayer/codex/hooks/ctxlayer_hook.py\') '
    )
    payload = {
        "hooks": {
            "SessionStart": [
                {
                    "matcher": "startup|resume|clear|compact",
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} SessionStart",
                            "commandWindows": f"{hook_windows}SessionStart; exit $LASTEXITCODE\"",
                            "timeout": 30,
                            "statusMessage": "Checking CTX Layer setup",
                        }
                    ],
                }
            ],
            "UserPromptSubmit": [
                {
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} UserPromptSubmit",
                            "commandWindows": f"{hook_windows}UserPromptSubmit; exit $LASTEXITCODE\"",
                            "timeout": 30,
                            "statusMessage": "Preparing CTX Layer preflight",
                        }
                    ]
                }
            ],
            "PreToolUse": [
                {
                    "matcher": "Bash|apply_patch|Edit|Write|mcp__.*",
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} PreToolUse",
                            "commandWindows": f"{hook_windows}PreToolUse; exit $LASTEXITCODE\"",
                            "timeout": 30,
                            "statusMessage": "Checking CTX Layer tool gate",
                        }
                    ],
                }
            ],
            "PostToolUse": [
                {
                    "matcher": "Bash|apply_patch|Edit|Write|mcp__.*",
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} PostToolUse",
                            "commandWindows": f"{hook_windows}PostToolUse; exit $LASTEXITCODE\"",
                            "timeout": 30,
                            "statusMessage": "Recording CTX Layer tool evidence",
                        }
                    ],
                }
            ],
            "SubagentStart": [
                {
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} SubagentStart",
                            "commandWindows": f"{hook_windows}SubagentStart; exit $LASTEXITCODE\"",
                            "timeout": 30,
                            "statusMessage": "Registering CTX Layer child session",
                        }
                    ]
                }
            ],
            "SubagentStop": [
                {
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} SubagentStop",
                            "commandWindows": f"{hook_windows}SubagentStop; exit $LASTEXITCODE\"",
                            "timeout": 30,
                            "statusMessage": "Recording CTX Layer child summary",
                        }
                    ]
                }
            ],
            "Stop": [
                {
                    "hooks": [
                        {
                            "type": "command",
                            "command": f"{hook} Stop",
                            "commandWindows": f"{hook_windows}Stop; exit $LASTEXITCODE\"",
                            "timeout": 30,
                            "statusMessage": "Recording CTX Layer continuation state",
                        }
                    ]
                }
            ],
        }
    }
    return json.dumps(payload, indent=2, sort_keys=True) + "\n"


def _codex_agent_explorer() -> str:
    return """name = "ctx-explorer"
description = "Read-heavy CTX-aware explorer for codebase questions, context discovery, and risk triage."
sandbox_mode = "read-only"
developer_instructions = \"\"\"
Use CTX Layer context before analysis. Stay read-only. Return concise findings with file references, uncertainty, and suggested follow-up checks. Do not edit files.
\"\"\"
"""


def _codex_agent_worker() -> str:
    return """name = "ctx-worker"
description = "Scoped CTX-aware implementation worker for disjoint file ownership."
developer_instructions = \"\"\"
Before edits, require parent task_session_id, pack_id, plan_id, active step, and assigned write scope. Do not revert other agents' work. Edit only assigned files, checkpoint changed paths, run assigned checks, and return changed files plus verification results.
\"\"\"
"""


def _codex_agent_reviewer() -> str:
    return """name = "ctx-reviewer"
description = "CTX-aware reviewer focused on correctness, security, regressions, and missing tests."
sandbox_mode = "read-only"
developer_instructions = \"\"\"
Review using CTX Layer pack, impact, memory, and policy context. Stay read-only. Prioritize bugs, security risks, regressions, and missing tests with concrete file references.
\"\"\"
"""


def _codex_agent_verifier() -> str:
    return """name = "ctx-verifier"
description = "CTX-aware verification worker for tests, logs, impact reports, and failure localization."
developer_instructions = \"\"\"
Use CTX Layer impact and plan context to run bounded verification. Prefer read-only diagnostics unless explicitly assigned a repair scope. Report commands, exits, failures, and likely owning files.
\"\"\"
"""


def _codex_hook_script() -> str:
    return '''from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path


def main() -> int:
    event = sys.argv[1] if len(sys.argv) > 1 else "unknown"
    repo = _repo_root()
    payload = _read_stdin_json()
    result = _ctxlayer_event(repo, event, payload)
    if repo:
        log_dir = repo / ".ctxlayer" / "codex"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / "hook-events.jsonl"
        with log_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps({"event": event, "payload": payload, "result": result}, sort_keys=True) + "\\n")
    print(json.dumps(_codex_hook_output(result), sort_keys=True))
    return 1 if result.get("decision") == "block" else 0


def _codex_hook_output(result: dict) -> dict:
    event = str(result.get("event") or "")

    if event == "PreToolUse":
        if result.get("decision") == "block":
            return {
                "decision": "block",
                "reason": str(result.get("reason") or "CTX Layer hook blocked this tool call"),
            }
        return {"decision": "allow"}

    # Non-tool-gating Codex hook events do not accept PreToolUse decisions.
    # Keep stdout as valid, minimal JSON and rely on hook-events.jsonl for audit detail.
    if event in {
        "PostToolUse",
        "SessionStart",
        "UserPromptSubmit",
        "SubagentStart",
        "SubagentStop",
        "Stop",
    }:
        return {}

    if result.get("decision") == "block":
        return {
            "decision": "block",
            "reason": str(result.get("reason") or "CTX Layer hook blocked this tool call"),
        }
    return {}


def _daemon_result(event: str, body: dict) -> dict | None:
    base_url = os.environ.get("CTXLAYER_DAEMON")
    if not base_url:
        return None
    import urllib.request

    data = json.dumps({"event": event, "payload": body}).encode("utf-8")
    request = urllib.request.Request(
        base_url.rstrip("/") + "/v1/codex/hook-event",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    token = os.environ.get("CTXLAYER_TOKEN")
    if token:
        request.add_header("Authorization", "Bearer " + token)
    try:
        with urllib.request.urlopen(request, timeout=3) as response:
            parsed = json.loads(response.read().decode("utf-8"))
            return parsed if isinstance(parsed, dict) else None
    except Exception:  # noqa: BLE001 - fall back to the in-process service.
        return None


def _ctxlayer_event(repo: Path | None, event: str, payload: object) -> dict:
    base = {
        "ok": True,
        "event": event,
        "repo": str(repo) if repo else None,
        "ctxlayer_available": shutil.which("ctxlayer") is not None,
        "mode": "enforcing" if event == "PreToolUse" else "audit",
    }
    if not repo:
        return {**base, "ok": event != "PreToolUse", "decision": "block", "reason": "no git repo root"}
    body = payload if isinstance(payload, dict) else {"payload": payload}
    if event == "PreToolUse":
        # Hot path: the write gate is pure logic. Import only the lightweight
        # gate module so every tool call does not pay for the full service.
        try:
            from ctxlayer.codex import pre_tool_gate

            gate = pre_tool_gate(
                tool_name=str(body.get("tool_name") or body.get("tool") or ""),
                preflight_ready=bool(body.get("preflight_ready")),
                active_plan_step=bool(body.get("active_plan_step")),
                read_only=bool(body.get("read_only")),
            )
            return {**base, **gate}
        except Exception as exc:  # noqa: BLE001 - fail closed for the write gate.
            return {**base, "ok": False, "decision": "block", "reason": str(exc)}
    daemon = _daemon_result(event, body)
    if daemon is not None:
        return {**base, **daemon}
    try:
        from ctxlayer.service import CtxLayerService

        with CtxLayerService(repo) as service:
            return {**base, **service.codex_hook_event(event, body)}
    except Exception as exc:  # noqa: BLE001
        return {**base, "ok": False, "reason": str(exc)}


def _repo_root() -> Path | None:
    env_repo = _repo_from_env()
    if env_repo:
        return env_repo
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=5,
        )
    except (FileNotFoundError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    return Path(result.stdout.strip())


def _repo_from_env() -> Path | None:
    for name in ("CTXLAYER_REPO", "CODEX_PROJECT_DIR", "CODEX_WORKSPACE_ROOT"):
        value = os.environ.get(name)
        if not value:
            continue
        candidate = Path(value)
        if candidate.exists():
            return candidate
    return None


def _read_stdin_json() -> object:
    raw = sys.stdin.read()
    if not raw.strip():
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {"raw": raw[:4000]}


if __name__ == "__main__":
    raise SystemExit(main())
'''


def _claude_command(command: str, mcp_repo: str) -> str:
    return f"""# Run from this project root to register CTX Layer with Claude Code.
claude mcp add ctxlayer -- {command} mcp --repo "{mcp_repo}"
"""


def _mcp_readme(command: str, mcp_repo: str) -> str:
    return f"""# CTX Layer MCP Setup

This folder contains local setup snippets generated by `ctxlayer bootstrap`.

## Codex

Copy `.ctxlayer/mcp/codex.config.toml` into the relevant Codex config file.

## Claude Code

Run:

```powershell
claude mcp add ctxlayer -- {command} mcp --repo "{mcp_repo}"
```

## Direct MCP Smoke Test

```powershell
{command} mcp --repo "{mcp_repo}"
```
"""


def _toml_string(value: str) -> str:
    return json.dumps(value)


def _powershell_string(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _capabilities_yaml() -> str:
    return """schema_version: ctxlayer.capabilities.v1
require_task_session: false
missing_session_mode: warn
capabilities:
  edit_source:
    mode: free
  edit_tests:
    mode: free
  add_dependency:
    mode: warn
    paths: [package.json, package-lock.json, pnpm-lock.yaml, yarn.lock, pyproject.toml, requirements*.txt]
  modify_migration:
    mode: warn
    paths: [migrations/**, **/migrations/**]
  delete_file:
    mode: warn
  edit_critical_path:
    mode: warn
    paths: [src/auth/**, src/billing/**, src/payments/**, migrations/**]
  modify_ci_config:
    mode: warn
    paths: [.github/**, .gitlab-ci.yml, ctxlayer.toml, ctxlayer.capabilities.yaml]
  touch_env_secrets:
    mode: forbidden
    paths: [.env, .env.*, **/.env, **/.env.*, **/*.pem, **/*.key]
  run_destructive_command:
    mode: forbidden
"""
