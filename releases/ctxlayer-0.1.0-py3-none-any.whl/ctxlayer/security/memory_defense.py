from __future__ import annotations

import math
import re
from typing import Any, Iterable, Mapping, Sequence

# Runtime defenses against memory poisoning. CTX Layer already has trust tiers and poisoning
# *tests*; these are the *runtime* detectors the 2024-2026 literature shows are needed:
#  - embedding-space cluster/anomaly detection for optimized triggers (AgentPoison,
#    arXiv:2407.12784),
#  - query-only injection detection (MINJA),
#  - trust-aware retrieval (bias recall toward approved memories),
#  - trust-threshold calibration (the dominant failure mode is mis-calibration).
# All functions are pure and dependency-free so they can run inline in the recall path.


# ----- Query-only injection detection (MINJA-style) ------------------------------------------

_INJECTION_PATTERNS: tuple[tuple[str, str], ...] = (
    ("ignore_previous", r"ignore\s+(all\s+)?previous\s+(instructions|context)"),
    ("override_instructions", r"disregard\s+(the\s+)?(system|prior)\s+(prompt|instructions)"),
    ("persist_instruction", r"(from\s+now\s+on|always|whenever)\b.*\b(remember|store|retrieve|use)"),
    ("indication_prompt", r"\b(you\s+must|you\s+should\s+always)\b"),
    ("bridging_step", r"\b(first|then)\b.*\b(then|finally)\b.*\b(do|run|execute)\b"),
    ("exfiltrate", r"(send|post|upload|leak)\b.*\b(secret|token|key|password|credential)"),
)


def detect_query_injection(text: str) -> dict[str, Any]:
    """Flag MINJA-style injection patterns in untrusted text (queries or memory content)."""
    lowered = (text or "").lower()
    matched = [name for name, pattern in _INJECTION_PATTERNS if re.search(pattern, lowered)]
    return {
        "ok": not matched,
        "flagged": matched,
        "reason": "clean" if not matched else "query_injection_suspected",
    }


# ----- Embedding-space cluster anomaly (AgentPoison-style) ------------------------------------


def _cosine(a: Sequence[float], b: Sequence[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b, strict=False))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


def detect_embedding_cluster_anomaly(
    embeddings: Mapping[str, Sequence[float]],
    *,
    cohesion_threshold: float = 0.92,
    min_cluster: int = 2,
) -> dict[str, Any]:
    """Detect a tight, unusual cluster of memory embeddings (an optimized-trigger signature).

    Poisoned items injected by trigger optimization collapse into an abnormally cohesive
    cluster relative to the corpus. We flag any group of >= min_cluster items whose mutual
    cosine similarity exceeds cohesion_threshold while the corpus-average similarity is lower.
    """
    ids = list(embeddings)
    if len(ids) < min_cluster:
        return {"ok": True, "flagged": [], "reason": "too_few_items"}
    # Corpus-average pairwise similarity as the baseline.
    pair_sims: list[float] = []
    sim: dict[tuple[str, str], float] = {}
    for i, a in enumerate(ids):
        for b in ids[i + 1 :]:
            s = _cosine(embeddings[a], embeddings[b])
            sim[(a, b)] = s
            pair_sims.append(s)
    baseline = sum(pair_sims) / len(pair_sims) if pair_sims else 0.0
    # Greedy cohesive grouping: items whose similarity to a seed exceeds the threshold.
    flagged: set[str] = set()
    for (a, b), s in sim.items():
        if s >= cohesion_threshold and s > baseline + 0.1:
            flagged.add(a)
            flagged.add(b)
    cluster = sorted(flagged)
    return {
        "ok": len(cluster) < min_cluster,
        "flagged": cluster,
        "baseline_similarity": round(baseline, 4),
        "cohesion_threshold": cohesion_threshold,
        "reason": "clean" if len(cluster) < min_cluster else "cohesive_anomaly_cluster",
    }


# ----- Trust-aware retrieval ------------------------------------------------------------------

_TRUST_WEIGHTS: dict[str, float] = {
    "approved": 1.0,
    "active": 0.95,
    "approved_project_memory": 0.95,
    "approved_business_rule": 0.95,
    "approved_consolidated_memory": 0.9,
    "runtime_evidence_active": 0.8,
    "trusted": 0.9,
    "candidate": 0.5,
    "untrusted": 0.2,
}


def trust_aware_rank(
    candidates: Iterable[Mapping[str, Any]],
    *,
    trust_weights: Mapping[str, float] | None = None,
    score_key: str = "score",
    trust_key: str = "trust",
) -> list[dict[str, Any]]:
    """Re-rank recall candidates so approved memories are preferred and untrusted ones are
    down-weighted (trust-aware retrieval). Never drops items - only reorders by adjusted score.
    """
    weights = dict(_TRUST_WEIGHTS)
    if trust_weights:
        weights.update(trust_weights)
    enriched: list[dict[str, Any]] = []
    for item in candidates:
        base = float(item.get(score_key) or 0.0)
        trust = str(item.get(trust_key) or "untrusted")
        factor = weights.get(trust, 0.2)
        enriched.append({**item, "adjusted_score": round(base * factor, 6), "trust_factor": factor})
    enriched.sort(key=lambda it: (-it["adjusted_score"], str(it.get("id") or "")))
    return enriched


# ----- Trust-threshold calibration -----------------------------------------------------------


ACTOR_ROLE_TIERS: dict[str, int] = {
    "agent": 10,
    "local-user": 20,
    "reviewer": 30,
    "codeowner": 30,
    "admin": 40,
    "system": 40,
}


def actor_role(actor: str | None) -> str:
    """Map a caller identity into the coarse security roles used by memory governance."""
    value = (actor or "agent").strip().lower()
    if value in ACTOR_ROLE_TIERS:
        return value
    if value.startswith(("system", "memory_", "memory-", "ctxlayer")):
        return "system"
    if value.startswith(("admin", "security-admin")):
        return "admin"
    if value.startswith(("codeowner", "owner", "reviewer", "http")):
        return "codeowner"
    if value.startswith(("local", "user", "human")):
        return "local-user"
    if value.startswith(("agent", "bot", "codex")):
        return "agent"
    return "local-user"


def require_actor_role(actor: str | None, minimum: str, action: str) -> dict[str, Any]:
    """Return a fail-closed authorization result for actor-tiered memory actions."""
    actual_role = actor_role(actor)
    actual_tier = ACTOR_ROLE_TIERS[actual_role]
    required_tier = ACTOR_ROLE_TIERS[minimum]
    ok = actual_tier >= required_tier
    return {
        "ok": ok,
        "actor": actor or "agent",
        "actor_role": actual_role,
        "required_role": minimum,
        "action": action,
        "reason": "authorized" if ok else "insufficient_actor_role",
    }


def calibrate_trust_threshold(
    labeled: Sequence[Mapping[str, Any]],
    *,
    thresholds: Iterable[float] = tuple(i / 20 for i in range(21)),
    score_key: str = "score",
    label_key: str = "poison",
) -> dict[str, Any]:
    """Compute false-accept / false-reject rates across thresholds on a labeled set.

    ``labeled`` items carry a numeric score and a boolean ``poison`` label. An item is
    "accepted" when its score >= threshold. Returns the curve plus the threshold minimizing
    total error - surfacing the mis-calibration that research flags as the dominant failure.
    """
    items = list(labeled)
    poison = [it for it in items if bool(it.get(label_key))]
    benign = [it for it in items if not bool(it.get(label_key))]
    curve: list[dict[str, float]] = []
    for threshold in thresholds:
        # False accept: poison whose score clears the threshold (wrongly trusted).
        fa = sum(1 for it in poison if float(it.get(score_key) or 0.0) >= threshold)
        # False reject: benign whose score is below the threshold (wrongly dropped).
        fr = sum(1 for it in benign if float(it.get(score_key) or 0.0) < threshold)
        far = fa / len(poison) if poison else 0.0
        frr = fr / len(benign) if benign else 0.0
        curve.append(
            {
                "threshold": round(threshold, 4),
                "false_accept_rate": round(far, 4),
                "false_reject_rate": round(frr, 4),
                "total_error": round(far + frr, 4),
            }
        )
    best = min(curve, key=lambda row: (row["total_error"], row["threshold"])) if curve else None
    return {"ok": True, "curve": curve, "recommended_threshold": best}
