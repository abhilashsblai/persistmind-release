from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class SemanticEvidence:
    evidence_id: str
    repo_id: str
    path: str
    evidence_kind: str
    evidence_hash: str
    node_id: str | None = None
    edge_id: str | None = None
    symbol_identity_id: str | None = None
    line_start: int | None = None
    line_end: int | None = None

    def as_row(self) -> dict[str, Any]:
        return {
            "evidence_id": self.evidence_id,
            "node_id": self.node_id,
            "edge_id": self.edge_id,
            "repo_id": self.repo_id,
            "path": self.path,
            "symbol_identity_id": self.symbol_identity_id,
            "line_start": self.line_start,
            "line_end": self.line_end,
            "evidence_kind": self.evidence_kind,
            "evidence_hash": self.evidence_hash,
        }


@dataclass
class SemanticNode:
    node_id: str
    repo_id: str
    node_type: str
    name: str
    stable_key: str
    confidence: float
    source: str
    metadata: dict[str, Any] = field(default_factory=dict)
    evidence: list[SemanticEvidence] = field(default_factory=list)

    def as_row(self) -> dict[str, Any]:
        return {
            "node_id": self.node_id,
            "repo_id": self.repo_id,
            "node_type": self.node_type,
            "name": self.name,
            "stable_key": self.stable_key,
            "confidence": self.confidence,
            "source": self.source,
            "metadata": self.metadata,
        }


@dataclass
class SemanticEdge:
    edge_id: str
    src_node_id: str
    dst_node_id: str
    kind: str
    confidence: float
    evidence: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def as_row(self) -> dict[str, Any]:
        return {
            "edge_id": self.edge_id,
            "src_node_id": self.src_node_id,
            "dst_node_id": self.dst_node_id,
            "kind": self.kind,
            "confidence": self.confidence,
            "evidence": self.evidence,
            "metadata": self.metadata,
        }
