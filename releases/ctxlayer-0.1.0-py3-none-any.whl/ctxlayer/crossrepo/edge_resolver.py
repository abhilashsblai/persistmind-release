from __future__ import annotations

from collections import defaultdict
from typing import Any


def resolve(contracts: list[dict[str, Any]]) -> list[dict[str, Any]]:
    provided: dict[str, list[dict[str, Any]]] = defaultdict(list)
    consumed: list[dict[str, Any]] = []
    for contract in contracts:
        if contract["kind"] in {"provides_api", "publishes_event", "provides_package"}:
            provided[contract["name"]].append(contract)
        if contract["kind"] in {"consumes_api", "subscribes_event", "depends_on_package"}:
            consumed.append(contract)
    impacts: list[dict[str, Any]] = []
    for consumer in consumed:
        for provider in provided.get(consumer["name"], []):
            if provider["repo_id"] == consumer["repo_id"]:
                continue
            impacts.append(
                {
                    "src_repo_id": provider["repo_id"],
                    "src_path": provider["path"],
                    "dst_repo_id": consumer["repo_id"],
                    "dst_path": consumer["path"],
                    "kind": consumer["kind"],
                    "name": consumer["name"],
                    "confidence": 0.95,
                }
            )
    return impacts
