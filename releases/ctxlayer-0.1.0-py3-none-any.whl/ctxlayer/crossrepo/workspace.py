from __future__ import annotations

from pathlib import Path
from typing import Any

from ctxlayer.crossrepo import db_migration_extractor as db_migration_extractor
from ctxlayer.crossrepo import event_schema_extractor as event_schema_extractor
from ctxlayer.crossrepo import graphql_extractor as graphql_extractor
from ctxlayer.crossrepo import openapi_extractor as openapi_extractor
from ctxlayer.crossrepo import package_extractor as package_extractor
from ctxlayer.crossrepo.edge_resolver import resolve
from ctxlayer.crossrepo.report import impact_report
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import stable_id


class WorkspaceManager:
    def __init__(self, workspace_root: Path, store: SQLiteStore):
        self.workspace_root = workspace_root.resolve()
        self.store = store

    def init(self) -> dict[str, Any]:
        (self.workspace_root / ".ctxlayer").mkdir(parents=True, exist_ok=True)
        return {"ok": True, "workspace": str(self.workspace_root)}

    def add_repo(self, repo_path: str | Path) -> dict[str, Any]:
        root = Path(repo_path).resolve()
        repo_id = stable_id(str(root))[:16]
        name = root.name
        row_id = self.store.add_workspace_repo(
            workspace_root=str(self.workspace_root), repo_id=repo_id, name=name, root_path=str(root)
        )
        return {"ok": True, "workspace_repo_id": row_id, "repo_id": repo_id, "name": name}

    def index(self) -> dict[str, Any]:
        indexed = []
        all_contracts: list[dict[str, Any]] = []
        for row in self.store.workspace_repos(str(self.workspace_root)):
            repo_root = Path(row["root_path"])
            contracts = self._extract(repo_root, row["repo_id"])
            self.store.replace_contracts(repo_id=row["repo_id"], contracts=contracts)
            all_contracts.extend(contracts)
            indexed.append({"repo_id": row["repo_id"], "name": row["name"], "contracts": len(contracts)})
        impacts = resolve(all_contracts)
        for impact in impacts:
            self.store.put_edge(
                scope_snapshot_id=None,
                src_repo_id=impact["src_repo_id"],
                src_node_type="file",
                src_node_id=impact["src_path"],
                dst_repo_id=impact["dst_repo_id"],
                dst_node_type="file",
                dst_node_id=impact["dst_path"],
                kind=impact["kind"],
                confidence=impact["confidence"],
                metadata={"name": impact["name"], "cross_repo": True},
            )
        return {"ok": True, "indexed": indexed, "cross_repo_edges": len(impacts)}

    def impact(self, changed_repo: str) -> dict[str, Any]:
        impacts = []
        for row in self.store.contracts():
            _ = row
        edge_rows = self.store.logical_edges(
            "src_repo_id = ? AND src_repo_id != dst_repo_id",
            (changed_repo,),
        )
        for row in edge_rows:
            impacts.append(
                {
                    "src_repo_id": row["src_repo_id"],
                    "src_path": row["src_node_id"],
                    "dst_repo_id": row["dst_repo_id"],
                    "dst_path": row["dst_node_id"],
                    "kind": row["kind"],
                    "confidence": row["confidence"],
                }
            )
        return impact_report(changed_repo, impacts)

    def status(self) -> dict[str, Any]:
        repos = [dict(row) for row in self.store.workspace_repos(str(self.workspace_root))]
        contracts = [dict(row) for row in self.store.contracts()]
        edge_count = len(self.store.logical_edges("src_repo_id != dst_repo_id"))
        return {
            "ok": True,
            "workspace": str(self.workspace_root),
            "repos": repos,
            "contracts": len(contracts),
            "cross_repo_edges": edge_count,
            "ready": bool(repos),
        }

    def rule_promotions(self) -> dict[str, Any]:
        rows = self.store.conn.execute(
            """
            SELECT assertion, type, COUNT(DISTINCT repo_id) AS repo_count,
                   GROUP_CONCAT(DISTINCT repo_id) AS repos
            FROM memory_records
            WHERE status = 'active' AND type IN ('business_rule', 'convention', 'gotcha')
            GROUP BY assertion, type
            HAVING COUNT(DISTINCT repo_id) >= 2
            ORDER BY repo_count DESC, assertion
            """
        ).fetchall()
        return {
            "ok": True,
            "schema_version": "ctxlayer.workspace_rule_promotions.v1",
            "promotions": [
                {
                    "type": row["type"],
                    "assertion": row["assertion"],
                    "repo_count": row["repo_count"],
                    "repos": sorted((row["repos"] or "").split(",")),
                    "status": "candidate",
                }
                for row in rows
            ],
        }

    def _extract(self, repo_root: Path, repo_id: str) -> list[dict[str, Any]]:
        contracts: list[dict[str, Any]] = []
        for extractor in [
            openapi_extractor.extract,
            graphql_extractor.extract,
            package_extractor.extract,
            event_schema_extractor.extract,
            db_migration_extractor.extract,
        ]:
            contracts.extend(extractor(repo_root))
        return [{**contract, "repo_id": repo_id} for contract in contracts]
