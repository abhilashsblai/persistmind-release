from __future__ import annotations

import re
from pathlib import Path
from typing import Any


def extract(repo_root: Path) -> list[dict[str, Any]]:
    contracts: list[dict[str, Any]] = []
    for path in repo_root.rglob("*.graphql"):
        text = path.read_text(encoding="utf-8", errors="replace")
        rel = path.relative_to(repo_root).as_posix()
        for name in re.findall(r"\b(?:type|interface|input|enum)\s+([A-Za-z_][A-Za-z0-9_]*)", text):
            contracts.append(
                {"path": rel, "kind": "provides_api", "name": f"graphql:{name}", "metadata": {}}
            )
    return contracts
