from __future__ import annotations

import math
from typing import Any, Iterable, Mapping

# Spectrum-based fault localization (SBFL): rank code elements by how strongly they correlate
# with test failures (AutoCodeRover/SpecRover, arXiv:2408.02232). CTX Layer already stores
# test->symbol links, so given a failing/passing test split we can compute suspiciousness for
# free. Paired with hierarchical (file -> symbol -> line) narrowing and a Hit@k metric so
# localization quality is measurable (Agentless, arXiv:2407.01489).

CoverageMap = Mapping[str, Iterable[str]]  # test_id -> covered elements


def suspiciousness(
    coverage: CoverageMap,
    *,
    failing: Iterable[str],
    passing: Iterable[str],
    formula: str = "ochiai",
) -> dict[str, float]:
    """Score each covered element by its correlation with failing tests.

    ``coverage`` maps a test id to the elements (symbols/files/lines) it exercises.
    Returns ``{element: score}`` in [0, 1]; higher = more suspicious.
    """
    failing_set = set(failing)
    passing_set = set(passing)
    total_failed = len(failing_set)
    total_passed = len(passing_set)

    elements: set[str] = set()
    for test_id, covered in coverage.items():
        if test_id in failing_set or test_id in passing_set:
            elements.update(covered)

    scores: dict[str, float] = {}
    for element in elements:
        ef = sum(1 for t in failing_set if element in set(coverage.get(t, ())))
        ep = sum(1 for t in passing_set if element in set(coverage.get(t, ())))
        nf = total_failed - ef
        scores[element] = _score(formula, ef=ef, ep=ep, nf=nf, total_failed=total_failed, total_passed=total_passed)
    return scores


def _score(formula: str, *, ef: int, ep: int, nf: int, total_failed: int, total_passed: int) -> float:
    if formula == "tarantula":
        if total_failed == 0:
            return 0.0
        fail_ratio = ef / total_failed
        pass_ratio = (ep / total_passed) if total_passed else 0.0
        denom = fail_ratio + pass_ratio
        return round(fail_ratio / denom, 6) if denom > 0 else 0.0
    # default: Ochiai
    denom = math.sqrt((ef + nf) * (ef + ep)) if (ef + nf) and (ef + ep) else 0.0
    return round(ef / denom, 6) if denom > 0 else 0.0


def rank_suspicious(scores: Mapping[str, float]) -> list[dict[str, Any]]:
    """Return elements sorted by descending suspiciousness (ties broken by name)."""
    ranked = sorted(scores.items(), key=lambda item: (-item[1], item[0]))
    return [{"element": element, "score": score} for element, score in ranked]


def hit_at_k(ranked: list[dict[str, Any]], expected: Iterable[str], k: int) -> bool:
    """True if any expected (faulty) element appears in the top-k of ``ranked``."""
    top = {item["element"] for item in ranked[: max(0, k)]}
    return bool(top & set(expected))


def localization_metrics(
    ranked: list[dict[str, Any]],
    expected: Iterable[str],
    *,
    ks: Iterable[int] = (1, 3, 5, 10),
) -> dict[str, Any]:
    expected_set = set(expected)
    elements = [item["element"] for item in ranked]
    first_rank = next((i + 1 for i, e in enumerate(elements) if e in expected_set), None)
    return {
        "hit_at_k": {f"hit@{k}": hit_at_k(ranked, expected_set, k) for k in ks},
        "first_hit_rank": first_rank,
        "reciprocal_rank": round(1.0 / first_rank, 6) if first_rank else 0.0,
        "ranked_count": len(ranked),
        "expected_count": len(expected_set),
    }


def hierarchical_localize(
    *,
    file_scores: Mapping[str, float],
    symbol_scores: Mapping[str, float] | None = None,
    top_files: int = 5,
    top_symbols: int = 10,
) -> dict[str, Any]:
    """Coarse-to-fine localization output: most suspicious files, then symbols within them."""
    files = rank_suspicious(file_scores)[: max(0, top_files)]
    symbols = rank_suspicious(symbol_scores or {})[: max(0, top_symbols)]
    return {
        "schema_version": "ctxlayer.localization.v1",
        "files": files,
        "symbols": symbols,
    }
