"""Privacy-safe, per-project metrics rollup.

This produces a small JSON document summarising how CTX Layer is performing on a
single installed project: agent-benchmark lift, outcome success rates, learning
activity, and the numeric parameter regime currently promoted. It is designed to
be collected manually from each deployment and compared across projects.

By construction the rollup contains ONLY:
  * opaque identifiers (sha256-derived ``project_id``/``repo_id``)
  * an optional human ``label`` the operator chose to attach
  * numeric metrics and scalar (numeric/boolean) parameter values
  * status/kind counts

It never contains file paths, source code, rule/skill text, task text, error
strings, or any other free-form content harvested from the target repository.
That allowlist is enforced in code (see ``_scalars``), not by convention, so a
schema change elsewhere cannot silently start leaking text.
"""

from __future__ import annotations

import json
from typing import Any

from ctxlayer.store import SQLiteStore

SCHEMA = "ctxlayer.metrics-rollup/v1"

# Numeric lift fields on agent_benchmark_run that are safe to surface verbatim.
_BENCHMARK_NUMERIC_FIELDS = (
    "cases",
    "success_rate_delta",
    "tests_pass_rate_delta",
    "wrong_files_touched_reduction",
    "missing_files_reduction",
    "agent_seconds_reduction",
    "memory_score",
    "context_retrieval_score",
)


def _scalars(value: Any) -> Any:
    """Recursively keep only numeric/boolean leaves.

    Dict keys are preserved (they are parameter names like ``lexical_weight``),
    but any string/None/text leaf is dropped so no free-form content escapes.
    """
    if isinstance(value, bool) or isinstance(value, (int, float)):
        return value
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            cleaned = _scalars(item)
            if cleaned is not None:
                out[str(key)] = cleaned
        return out or None
    if isinstance(value, list):
        cleaned = [item for item in (_scalars(v) for v in value) if item is not None]
        return cleaned or None
    return None


class MetricsRollup:
    """Builds a per-project rollup from the local workspace store.

    Every section is computed defensively: a missing table or older schema on a
    given install degrades to an empty section plus an entry in ``errors`` rather
    than aborting the whole rollup, since this runs across heterogeneous
    deployments.
    """

    def __init__(
        self,
        store: SQLiteStore,
        *,
        project_id: str,
        repo_id: str | None,
        label: str | None,
        version: str,
        generated_at: str,
        scale: dict[str, Any],
        limit: int = 30,
    ) -> None:
        self.store = store
        self.project_id = project_id
        self.repo_id = repo_id
        self.label = label
        self.version = version
        self.generated_at = generated_at
        self.scale = scale
        self.limit = limit
        self._errors: list[str] = []

    def data(self) -> dict[str, Any]:
        return {
            "schema": SCHEMA,
            "ok": True,
            "generated_at": self.generated_at,
            "ctxlayer_version": self.version,
            "project": {
                "project_id": self.project_id,
                "repo_id": self.repo_id,
                "label": self.label,
            },
            "scale": self.scale,
            "outcomes": self._section(self._outcomes),
            "benchmark": self._section(self._benchmark),
            "learning": self._section(self._learning),
            "memory": self._section(self._memory),
            "skills": self._section(self._skills),
            "errors": self._errors,
        }

    def _section(self, builder: Any) -> dict[str, Any]:
        try:
            return builder()
        except Exception as exc:  # noqa: BLE001 - one weak section must not sink the rollup.
            self._errors.append(f"{builder.__name__}: {exc}")
            return {}

    def _outcomes(self) -> dict[str, Any]:
        # The raw result column can carry a free-text suffix (e.g.
        # "fail: check-diff reported ..."); normalise to a fixed bucket set so
        # no operator-supplied text leaks into the rollup.
        rows = self.store.conn.execute(
            "SELECT result, COUNT(*) AS count FROM outcomes GROUP BY result"
        ).fetchall()
        by_result: dict[str, int] = {}
        for row in rows:
            bucket = _normalize_result(row["result"])
            by_result[bucket] = by_result.get(bucket, 0) + int(row["count"])
        total = sum(by_result.values())
        passed = by_result.get("pass", 0)
        return {
            "total": total,
            "by_result": by_result,
            "success_rate": round(passed / total, 6) if total else 0.0,
        }

    def _benchmark(self) -> dict[str, Any]:
        rows = self.store.agent_benchmark_runs(limit=self.limit)
        runs = [
            {field: _coerce(row[field]) for field in _BENCHMARK_NUMERIC_FIELDS}
            for row in rows
        ]
        for run, row in zip(runs, rows):
            run["gate_ok"] = None if row["gate_ok"] is None else bool(row["gate_ok"])
        summary: dict[str, Any] = {"count": len(runs)}
        if runs:
            latest, oldest = runs[0], runs[-1]
            summary["latest_success_rate_delta"] = latest["success_rate_delta"]
            summary["latest_context_retrieval_score"] = latest["context_retrieval_score"]
            summary["latest_memory_score"] = latest["memory_score"]
            summary["success_rate_delta_change"] = round(
                latest["success_rate_delta"] - oldest["success_rate_delta"], 6
            )
        return {"summary": summary, "trend": runs}

    def _learning(self) -> dict[str, Any]:
        rows = self.store.conn.execute(
            """
            SELECT target, kind, COUNT(*) AS runs,
                   SUM(promoted) AS promoted, SUM(gate_pass) AS gate_pass
            FROM learning_run
            GROUP BY target, kind
            """
        ).fetchall()
        by_target: dict[str, Any] = {}
        runs_total = promoted_total = gate_pass_total = 0
        for row in rows:
            target = str(row["target"])
            runs = int(row["runs"] or 0)
            promoted = int(row["promoted"] or 0)
            gate_pass = int(row["gate_pass"] or 0)
            runs_total += runs
            promoted_total += promoted
            gate_pass_total += gate_pass
            bucket = by_target.setdefault(
                target, {"runs": 0, "promoted": 0, "gate_pass": 0}
            )
            bucket["runs"] += runs
            bucket["promoted"] += promoted
            bucket["gate_pass"] += gate_pass
        promoted_parameters: dict[str, Any] = {}
        for row in self.store.promoted_learning_runs():
            # Self-modification runs carry code patches in after_json; never emit them.
            if row["kind"] == "selfmod_variant":
                continue
            params = _scalars(_load_json(row["after_json"]))
            if params:
                promoted_parameters[str(row["target"])] = params
        return {
            "runs_total": runs_total,
            "promoted_total": promoted_total,
            "gate_pass_rate": round(gate_pass_total / runs_total, 6) if runs_total else 0.0,
            "by_target": by_target,
            "promoted_parameters": promoted_parameters,
        }

    def _memory(self) -> dict[str, Any]:
        rows = self.store.conn.execute(
            "SELECT status, COUNT(*) AS count FROM memory_records GROUP BY status"
        ).fetchall()
        return {"by_status": {str(row["status"]): int(row["count"]) for row in rows}}

    def _skills(self) -> dict[str, Any]:
        rows = self.store.conn.execute(
            "SELECT status, COUNT(*) AS count FROM skill GROUP BY status"
        ).fetchall()
        by_status = {str(row["status"]): int(row["count"]) for row in rows}
        return {"total": sum(by_status.values()), "by_status": by_status}


_KNOWN_RESULTS = {"pass", "fail", "partial"}


def _normalize_result(value: Any) -> str:
    token = str(value or "").strip().lower()
    # Keep only the leading word, before any ":"/whitespace-delimited detail.
    head = token.replace(":", " ").split()
    head = head[0] if head else ""
    return head if head in _KNOWN_RESULTS else "other"


def _coerce(value: Any) -> float | int:
    if value is None:
        return 0
    if isinstance(value, int):
        return value
    return float(value)


def _load_json(value: str | None) -> Any:
    try:
        return json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
