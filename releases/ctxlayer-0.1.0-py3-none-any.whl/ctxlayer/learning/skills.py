from __future__ import annotations

import json
import fnmatch
import re
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ctxlayer.config import Settings
from ctxlayer.governance import CapabilityPolicy
from ctxlayer.learning._shell import run_shell
from ctxlayer.learning.provider import AgentProvider
from ctxlayer.loop import CORE_LOOP_DEFINITION_OF_DONE
from ctxlayer.memory.session import AgentSessionMemory
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import canonical_json, estimate_tokens, sha256_text, stable_id, utc_now


SENSITIVE_PATH_PATTERNS: tuple[tuple[str, str], ...] = (
    (".env", "secret_path"),
    (".pem", "secret_path"),
    (".key", "secret_path"),
    ("secrets/", "secret_path"),
    ("src/auth/", "auth_path"),
    ("/auth/", "auth_path"),
    ("src/billing/", "billing_path"),
    ("/billing/", "billing_path"),
    ("src/payments/", "payment_path"),
    ("/payments/", "payment_path"),
    ("migrations/", "migration_path"),
    ("/migrations/", "migration_path"),
)


SKILL_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": [
        "name",
        "nl_description",
        "trigger_signature",
        "steps",
        "evidence_refs",
        "confidence",
    ],
    "properties": {
        "name": {"type": "string"},
        "nl_description": {"type": "string"},
        "trigger_signature": {"type": "string"},
        "steps": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["name", "kind"],
                "properties": {
                    "name": {"type": "string"},
                    "kind": {
                        "type": "string",
                        "enum": ["command", "test", "codemod", "note", "manual_check"],
                    },
                    "command": {"type": "string"},
                    "timeout_seconds": {"type": "integer", "minimum": 1},
                    "expected_exit_code": {"type": "integer"},
                    "creates_or_changes": {"type": "array", "items": {"type": "string"}},
                    "requires_clean_worktree": {"type": "boolean"},
                },
                "additionalProperties": False,
            },
        },
        "scope_kind": {"type": "string"},
        "scope_refs": {"type": "array", "items": {"type": "string"}},
        "preconditions": {"type": "array", "items": {"type": "string"}},
        "inputs": {"type": "array", "items": {"type": "string"}},
        "expected_outputs": {"type": "array", "items": {"type": "string"}},
        "verification_commands": {"type": "array", "items": {"type": "string"}},
        "rollback_notes": {"type": "string"},
        "safe_path_globs": {"type": "array", "items": {"type": "string"}},
        "forbidden_path_globs": {"type": "array", "items": {"type": "string"}},
        "required_capabilities": {"type": "array", "items": {"type": "string"}},
        "evidence_refs": {"type": "array", "items": {"type": "string"}},
        "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
    },
    "additionalProperties": False,
}


class SkillLibrary:
    def __init__(
        self,
        *,
        store: SQLiteStore,
        repo_root: Path,
        workspace_id: str,
        repo_id: str | None,
        provider: AgentProvider | None = None,
        model_family: str | None = None,
        budget_tokens: int | None = None,
        settings: Settings | None = None,
        critical_path_globs: list[str] | None = None,
    ):
        self.store = store
        self.repo_root = repo_root
        self.workspace_id = workspace_id
        self.repo_id = repo_id
        self.provider = provider
        self.model_family = model_family
        self.budget_tokens = budget_tokens
        self.settings = settings
        self.critical_path_globs = critical_path_globs or []
        self.sessions = AgentSessionMemory(store, workspace_id, repo_id)

    def ensure_seed_skill(self) -> str:
        skill_id = "ctxlayer-core-loop"
        if self.store.skill(skill_id):
            return skill_id
        steps = [
            {"name": "pack", "kind": "note", "command": "Create a CTX Layer context pack before edits."},
            {"name": "plan", "kind": "note", "command": "Create a structured task plan before coding."},
            {
                "name": "checkpoint",
                "kind": "note",
                "command": "Checkpoint changed files against the active plan step.",
            },
            {
                "name": "preflight",
                "kind": "note",
                "command": "Run check-diff, impact, relevant tests, and record outcome.",
            },
        ]
        return self.store.upsert_skill(
            skill_id=skill_id,
            name="CTX Layer core loop",
            nl_description=(
                "Reusable CTX Layer workflow for pack, plan, checkpoint, check-diff, "
                "impact, tests, outcome, and session explain."
            ),
            trigger_signature="ctxlayer pack plan checkpoint check-diff impact tests outcome",
            steps=steps,
            evidence=[{"source": "loop.py", "definition_of_done": CORE_LOOP_DEFINITION_OF_DONE}],
            provenance={
                "generator": "deterministic",
                "validator": "deterministic:seed",
                "input_source": "repo",
            },
            success_count=1,
            last_validated_at=utc_now(),
            status="active",
            trust="approved",
        )

    def induce(self, *, session_id: str) -> dict[str, Any]:
        if self.provider is None:
            return {"ok": True, "proposed": [], "skipped": [{"reason": "no_provider"}]}
        explanation = self.sessions.explain(session_id)
        if not explanation.get("ok"):
            return {"ok": False, "error": explanation.get("error", "session not found")}
        prompt = skill_prompt(explanation)
        raw = self.provider.complete(
            prompt=prompt,
            role="skill_author",
            schema=SKILL_SCHEMA,
            model_family=self.model_family,
            budget_tokens=self.budget_tokens,
        )
        if raw is None:
            return {"ok": True, "proposed": [], "skipped": []}
        normalized = normalize_skill(raw)
        if normalized is None:
            self._event("skill_drop", session_id, {"reason": "invalid_skill"})
            return {"ok": True, "proposed": [], "skipped": [{"reason": "invalid_skill"}]}
        provider_id = str(getattr(self.provider, "provider_id", self.provider.__class__.__name__))
        skill_id = stable_id(
            "skill",
            self.workspace_id,
            normalized["name"],
            normalized["trigger_signature"],
            canonical_json(normalized["steps"]),
        )
        provenance = {
            "generator": f"agent:{sha256_text(provider_id)[:12]}",
            "validator": "none",
            "input_source": "session",
            "input_ref": session_id,
            "model_family": self.model_family,
            "skill_model": normalized["skill_model"],
        }
        self.store.upsert_skill(
            skill_id=skill_id,
            name=normalized["name"],
            nl_description=normalized["nl_description"],
            trigger_signature=normalized["trigger_signature"],
            steps=normalized["steps"],
            evidence=[
                {
                    "session_id": session_id,
                    "repo_id": self.repo_id,
                    "refs": normalized["evidence_refs"],
                    "confidence": normalized["confidence"],
                }
            ],
            provenance=provenance,
            status="candidate",
            trust="untrusted",
        )
        payload = {"session_id": session_id, "name": normalized["name"], "trust": "untrusted"}
        self._event("skill_candidate", skill_id, payload)
        return {
            "ok": True,
            "proposed": [
                {
                    "skill_id": skill_id,
                    "name": normalized["name"],
                    "status": "candidate",
                    "trust": "untrusted",
                }
            ],
            "skipped": [],
        }

    def approve(self, skill_id: str, *, approved_by: str = "local-user") -> dict[str, Any]:
        row = self.store.skill(skill_id)
        if not row:
            raise KeyError(f"skill not found: {skill_id}")
        provenance = _json(row["provenance_json"])
        provenance = {
            **provenance,
            "validator": f"human:{approved_by}",
            "validated_at": utc_now(),
        }
        self.store.set_skill_status(
            skill_id=skill_id,
            status="active",
            trust="approved",
            provenance=provenance,
        )
        self._event("skill_promoted", skill_id, {"validator": provenance["validator"]})
        return {"ok": True, "skill_id": skill_id, "status": "active", "trust": "approved"}

    def reject(self, skill_id: str, *, reason: str = "manual reject") -> dict[str, Any]:
        row = self.store.skill(skill_id)
        if not row:
            raise KeyError(f"skill not found: {skill_id}")
        provenance = {**_json(row["provenance_json"]), "rejected_at": utc_now(), "reject_reason": reason}
        self.store.set_skill_status(
            skill_id=skill_id,
            status="rejected",
            trust="untrusted",
            provenance=provenance,
        )
        self._event("skill_rejected", skill_id, {"reason": reason})
        return {"ok": True, "skill_id": skill_id, "status": "rejected", "trust": "untrusted"}

    def replay(self, skill_id: str, *, timeout: int = 120) -> dict[str, Any]:
        row = self.store.skill(skill_id)
        if not row:
            raise KeyError(f"skill not found: {skill_id}")
        steps = _json_list(row["steps_json"])
        skill_model = _skill_model(row)
        safety = self._safety_check(steps, skill_model)
        if not safety["ok"]:
            self.store.record_skill_replay(skill_id=skill_id, success=False)
            self._event("skill_replay_failed", skill_id, safety)
            return {"ok": False, "skill_id": skill_id, "promoted": False, "safety": safety}
        replay = self._run_steps_in_worktree(steps, skill_model=skill_model, timeout=timeout)
        success = replay["ok"]
        provenance = _json(row["provenance_json"])
        promoted = False
        if success:
            validated_at = utc_now()
            provenance = {
                **provenance,
                "validator": f"replay:{stable_id(skill_id, validated_at)[:12]}",
                "validated_at": validated_at,
                "repo_id": self.repo_id,
            }
            if self.repo_id:
                evidence = _json_list(row["evidence_json"])
                if not any(
                    isinstance(item, dict) and item.get("repo_id") == self.repo_id
                    for item in evidence
                ):
                    evidence.append(
                        {
                            "source": "skill_replay",
                            "repo_id": self.repo_id,
                            "validated_at": validated_at,
                        }
                    )
                    self.store.upsert_skill(
                        skill_id=skill_id,
                        name=row["name"],
                        nl_description=row["nl_description"],
                        trigger_signature=row["trigger_signature"],
                        steps=_json_list(row["steps_json"]),
                        evidence=evidence,
                        embedding_ref=row["embedding_ref"],
                        provenance=provenance,
                        success_count=int(row["success_count"]),
                        fail_count=int(row["fail_count"]),
                        last_validated_at=row["last_validated_at"],
                        status=row["status"],
                        trust=row["trust"],
                    )
            promoted = True
        self.store.record_skill_replay(
            skill_id=skill_id,
            success=success,
            promoted=promoted,
            provenance=provenance if promoted else None,
        )
        self._event(
            "skill_replay_passed" if success else "skill_replay_failed",
            skill_id,
            {"promoted": promoted, "steps": replay["steps"]},
        )
        return {
            "ok": success,
            "skill_id": skill_id,
            "promoted": promoted,
            "steps": replay["steps"],
            "changed_paths": replay.get("changed_paths", []),
            "policy": replay.get("policy"),
            "path_gate": replay.get("path_gate"),
        }

    def search(
        self,
        query: str,
        *,
        limit: int = 5,
        include_untrusted: bool = False,
    ) -> dict[str, Any]:
        self.ensure_seed_skill()
        query_terms = _terms(query)
        rows = self.store.skills(limit=500)
        results = []
        for row in rows:
            cross_repo = _is_cross_repo_transfer(row, self.repo_id)
            requires_revalidation = (
                cross_repo
                and _skill_config(self.settings, "cross_repo_requires_revalidation", True)
            )
            if row["status"] != "active":
                if not (include_untrusted and row["trust"] == "untrusted"):
                    continue
            elif row["trust"] != "approved":
                continue
            if requires_revalidation and not include_untrusted:
                continue
            haystack = f"{row['name']} {row['nl_description']} {row['trigger_signature']}"
            hay_terms = _terms(haystack)
            overlap = query_terms & hay_terms
            if query_terms and not overlap:
                continue
            reliability = _reliability(row)
            freshness = _validation_freshness(
                row,
                half_life_days=int(_skill_config(self.settings, "validation_half_life_days", 90)),
            )
            weights = _rank_weights(self.settings)
            relevance = 1.0 if not query_terms else len(overlap) / max(1, len(query_terms))
            score = round(
                (weights["relevance"] * relevance)
                + (weights["reliability"] * reliability)
                + (weights["freshness"] * freshness),
                6,
            )
            if requires_revalidation:
                score = round(score * 0.5, 6)
            item = {
                **project_skill(row),
                "score": score,
                "requires_revalidation": requires_revalidation,
                "cross_repo_transfer": cross_repo,
                "signals": [
                    {
                        "kind": "lexical",
                        "score": round(relevance, 4),
                        "reason": f"Matched skill terms: {', '.join(sorted(overlap)[:6])}.",
                    },
                    {
                        "kind": "reliability",
                        "score": round(reliability, 4),
                        "reason": (
                            f"{row['success_count']} replay success(es), "
                            f"{row['fail_count']} failure(s)."
                        ),
                    },
                    {
                        "kind": "freshness",
                        "score": round(freshness, 4),
                        "reason": (
                            "Validation recency decays with a "
                            f"{int(_skill_config(self.settings, 'validation_half_life_days', 90))}-day half-life."
                        ),
                    },
                ],
            }
            if requires_revalidation:
                item["signals"].append(
                    {
                        "kind": "revalidation_required",
                        "score": 0.0,
                        "reason": (
                            "Skill evidence comes from a different repo; replay must validate it "
                            "in this repo before normal injection."
                        ),
                    }
                )
            results.append(
                item
            )
        results.sort(key=lambda item: (-float(item["score"]), item["name"], item["skill_id"]))
        return {"ok": True, "query": query, "results": results[:limit]}

    def list(self, *, status: str | None = None, trust: str | None = None) -> dict[str, Any]:
        self.ensure_seed_skill()
        return {
            "ok": True,
            "skills": [project_skill(row) for row in self.store.skills(status=status, trust=trust)],
        }

    def show(self, skill_id: str) -> dict[str, Any]:
        row = self.store.skill(skill_id)
        if not row:
            raise KeyError(f"skill not found: {skill_id}")
        return {"ok": True, "skill": project_skill(row)}

    def prune(self, *, max_failures: int = 3) -> dict[str, Any]:
        pruned = []
        for row in self.store.skills(limit=500):
            if row["status"] == "active":
                continue
            if int(row["fail_count"]) >= max_failures:
                self.store.set_skill_status(skill_id=row["skill_id"], status="rejected")
                pruned.append(row["skill_id"])
                self._event(
                    "skill_pruned",
                    row["skill_id"],
                    {"fail_count": int(row["fail_count"]), "max_failures": max_failures},
                )
        return {"ok": True, "pruned": pruned}

    def maintain(self, *, max_failures: int = 3, stale_after_days: int | None = None) -> dict[str, Any]:
        stale_days = stale_after_days or int(_skill_config(self.settings, "validation_half_life_days", 90))
        rejected: list[str] = []
        stale: list[str] = []
        quarantined: list[str] = []
        for row in self.store.skills(limit=500):
            skill_id = row["skill_id"]
            steps = _json_list(row["steps_json"])
            safety = self._safety_check(steps, _skill_model(row))
            if not safety["ok"] and row["status"] != "rejected":
                self.store.set_skill_status(skill_id=skill_id, status="rejected", trust="untrusted")
                quarantined.append(skill_id)
                self._event("skill_quarantined", skill_id, safety)
                continue
            if row["status"] != "active" and int(row["fail_count"]) >= max_failures:
                self.store.set_skill_status(skill_id=skill_id, status="rejected", trust="untrusted")
                rejected.append(skill_id)
                self._event(
                    "skill_pruned",
                    skill_id,
                    {"fail_count": int(row["fail_count"]), "max_failures": max_failures},
                )
                continue
            if row["status"] == "active" and _age_days(row["last_validated_at"]) > stale_days:
                self.store.set_skill_status(skill_id=skill_id, status="stale", trust="approved")
                stale.append(skill_id)
                self._event("skill_stale", skill_id, {"stale_after_days": stale_days})
        return {"ok": True, "rejected": rejected, "stale": stale, "quarantined": quarantined}

    def _run_steps_in_worktree(
        self, steps: list[dict[str, Any]], *, skill_model: dict[str, Any], timeout: int
    ) -> dict[str, Any]:
        executable = [
            step
            for step in steps
            if step.get("kind") in {"command", "test", "codemod"} and str(step.get("command", "")).strip()
        ]
        for command in skill_model.get("verification_commands", []):
            executable.append(
                {
                    "name": f"verify-{len(executable) + 1}",
                    "kind": "test",
                    "command": command,
                    "expected_exit_code": 0,
                }
            )
        if not executable:
            return {"ok": True, "steps": []}
        with tempfile.TemporaryDirectory(prefix="ctxlayer-skill-replay-") as tmp:
            worktree = Path(tmp) / "worktree"
            added = self._git_worktree_add(worktree)
            if not added:
                return {
                    "ok": False,
                    "reason": "worktree_unavailable",
                    "steps": [],
                    "changed_paths": [],
                    "policy": None,
                }
            results = []
            commands_ok = True
            changed_paths: list[str] = []
            policy = {"ok": True, "violations": []}
            path_gate = {"ok": True, "violations": []}
            try:
                for step in executable:
                    if bool(step.get("requires_clean_worktree")) and self._git_changed_paths(worktree):
                        results.append(
                            {
                                "name": step["name"],
                                "kind": step["kind"],
                                "command": step["command"],
                                "exit_code": None,
                                "timed_out": False,
                                "stdout": "",
                                "stderr": "worktree was not clean before step",
                            }
                        )
                        commands_ok = False
                        break
                    step_timeout = int(step.get("timeout_seconds") or timeout)
                    result = run_shell(str(step["command"]), cwd=worktree, timeout=step_timeout)
                    expected_exit = int(step.get("expected_exit_code", 0))
                    item = {
                        "name": step["name"],
                        "kind": step["kind"],
                        "command": step["command"],
                        "exit_code": result["exit_code"],
                        "expected_exit_code": expected_exit,
                        "timed_out": result["timed_out"],
                        "stdout": result["stdout"],
                        "stderr": result["stderr"],
                    }
                    results.append(item)
                    if int(result["exit_code"]) != expected_exit:
                        commands_ok = False
                        break
                changed_paths = self._git_changed_paths(worktree)
                path_gate = self._path_gate(changed_paths, steps, skill_model)
                if commands_ok:
                    policy = self._policy_check(worktree, changed_paths)
                return {
                    "ok": commands_ok and policy["ok"] and path_gate["ok"],
                    "steps": results,
                    "changed_paths": changed_paths,
                    "policy": policy,
                    "path_gate": path_gate,
                }
            finally:
                if added:
                    subprocess.run(
                        ["git", "worktree", "remove", "--force", str(worktree)],
                        cwd=self.repo_root,
                        text=True,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        check=False,
                    )

    def _git_worktree_add(self, worktree: Path) -> bool:
        probe = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            cwd=self.repo_root,
            text=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        if probe.returncode != 0:
            return False
        result = subprocess.run(
            ["git", "worktree", "add", "--detach", str(worktree), "HEAD"],
            cwd=self.repo_root,
            text=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        return result.returncode == 0

    def _git_changed_paths(self, worktree: Path) -> list[str]:
        result = subprocess.run(
            ["git", "status", "--porcelain", "--untracked-files=all"],
            cwd=worktree,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        if result.returncode != 0:
            return []
        return sorted(
            {
                line[3:].strip().replace("\\", "/")
                for line in result.stdout.splitlines()
                if line.strip()
                and line[3:].strip()
                and not _is_tool_workspace_path(line[3:].strip())
            }
        )

    def _policy_check(self, worktree: Path, changed_paths: list[str]) -> dict[str, Any]:
        if self.settings is None or not changed_paths:
            return {"ok": True, "violations": []}
        return CapabilityPolicy(worktree, self.settings).check_paths(changed_paths)

    def _path_gate(
        self, changed_paths: list[str], steps: list[dict[str, Any]], skill_model: dict[str, Any]
    ) -> dict[str, Any]:
        expected = set(skill_model.get("creates_or_changes", []))
        for step in steps:
            expected.update(_string_list(step.get("creates_or_changes")))
        safe_globs = skill_model.get("safe_path_globs", [])
        forbidden_globs = skill_model.get("forbidden_path_globs", [])
        violations = []
        for path in changed_paths:
            if forbidden_globs and any(fnmatch.fnmatch(path, pattern) for pattern in forbidden_globs):
                violations.append({"path": path, "reason": "forbidden_path_glob"})
            if safe_globs and not any(fnmatch.fnmatch(path, pattern) for pattern in safe_globs):
                violations.append({"path": path, "reason": "outside_safe_path_globs"})
            if expected and path not in expected and not any(fnmatch.fnmatch(path, pattern) for pattern in expected):
                violations.append({"path": path, "reason": "unexpected_change"})
        return {"ok": not violations, "violations": violations}

    def _safety_check(self, steps: list[dict[str, Any]], skill_model: dict[str, Any] | None = None) -> dict[str, Any]:
        blocked = []
        for step in steps:
            command = str(step.get("command", ""))
            for pattern in self.critical_path_globs:
                needle = pattern.replace("**/", "").replace("/**", "").replace("*", "")
                if needle and needle.strip("/") in command.replace("\\", "/"):
                    blocked.append({"step": step.get("name"), "pattern": pattern})
            lowered = command.lower()
            if _suspicious_command(lowered):
                blocked.append({"step": step.get("name"), "pattern": "suspicious_command"})
            for reason in _sensitive_command_references(command):
                blocked.append({"step": step.get("name"), "pattern": reason})
        for pattern in (skill_model or {}).get("forbidden_path_globs", []):
            for step in steps:
                command = str(step.get("command", "")).replace("\\", "/")
                needle = pattern.replace("**/", "").replace("/**", "").replace("*", "")
                if needle and needle.strip("/") in command:
                    blocked.append({"step": step.get("name"), "pattern": pattern})
        if blocked:
            return {"ok": False, "reason": "critical_path_reference", "blocked": blocked}
        return {"ok": True}

    def _event(self, kind: str, ref: str | None, payload: dict[str, Any]) -> None:
        self.store.write_learning_event(phase="phase2", kind=kind, ref=ref, payload=payload)


def skill_prompt(explanation: dict[str, Any]) -> str:
    return "\n".join(
        [
            "Author one reusable CTX Layer skill from this successful coding session.",
            "Return strict JSON only. The skill must be executable, evidence-grounded, and safe.",
            "Use command/test steps only for commands that can be replayed in a clean worktree.",
            canonical_json({"session": explanation}),
        ]
    )


def normalize_skill(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    name = str(value.get("name") or "").strip()
    description = str(value.get("nl_description") or "").strip()
    trigger = str(value.get("trigger_signature") or "").strip()
    raw_steps = value.get("steps")
    evidence_refs = value.get("evidence_refs")
    confidence = value.get("confidence")
    if not name or not description or not trigger:
        return None
    if not isinstance(raw_steps, list) or not raw_steps:
        return None
    if not isinstance(evidence_refs, list) or not all(isinstance(ref, str) for ref in evidence_refs):
        return None
    if not isinstance(confidence, (int, float)) or isinstance(confidence, bool):
        return None
    steps = []
    for index, step in enumerate(raw_steps, start=1):
        if not isinstance(step, dict):
            return None
        kind = str(step.get("kind") or "").strip().lower()
        if kind not in {"command", "test", "codemod", "note", "manual_check"}:
            return None
        step_name = str(step.get("name") or f"step-{index}").strip()
        command = str(step.get("command") or "").strip()
        normalized_step: dict[str, Any] = {"name": step_name, "kind": kind, "command": command}
        if "timeout_seconds" in step:
            timeout = _positive_int(step.get("timeout_seconds"))
            if timeout is None:
                return None
            normalized_step["timeout_seconds"] = timeout
        if "expected_exit_code" in step:
            expected = _int_value(step.get("expected_exit_code"))
            if expected is None:
                return None
            normalized_step["expected_exit_code"] = expected
        if "creates_or_changes" in step:
            normalized_step["creates_or_changes"] = _string_list(step.get("creates_or_changes"))
        if "requires_clean_worktree" in step:
            normalized_step["requires_clean_worktree"] = bool(step.get("requires_clean_worktree"))
        steps.append(normalized_step)
    skill_model = {
        "scope_kind": str(value.get("scope_kind") or "repo").strip(),
        "scope_refs": _string_list(value.get("scope_refs")),
        "preconditions": _string_list(value.get("preconditions")),
        "inputs": _string_list(value.get("inputs")),
        "expected_outputs": _string_list(value.get("expected_outputs")),
        "verification_commands": _string_list(value.get("verification_commands")),
        "rollback_notes": str(value.get("rollback_notes") or "").strip(),
        "safe_path_globs": _string_list(value.get("safe_path_globs")),
        "forbidden_path_globs": _string_list(value.get("forbidden_path_globs")),
        "required_capabilities": _string_list(value.get("required_capabilities")),
    }
    return {
        "name": name,
        "nl_description": description,
        "trigger_signature": trigger,
        "steps": steps,
        "evidence_refs": [ref.strip() for ref in evidence_refs if ref.strip()],
        "skill_model": skill_model,
        "confidence": max(0.0, min(1.0, float(confidence))),
    }


def project_skill(row: Any) -> dict[str, Any]:
    skill_model = _skill_model(row)
    return {
        "skill_id": row["skill_id"],
        "name": row["name"],
        "nl_description": row["nl_description"],
        "trigger_signature": row["trigger_signature"],
        "scope_kind": skill_model.get("scope_kind", "repo"),
        "scope_refs": skill_model.get("scope_refs", []),
        "preconditions": skill_model.get("preconditions", []),
        "inputs": skill_model.get("inputs", []),
        "steps": _json_list(row["steps_json"]),
        "expected_outputs": skill_model.get("expected_outputs", []),
        "verification_commands": skill_model.get("verification_commands", []),
        "rollback_notes": skill_model.get("rollback_notes", ""),
        "safe_path_globs": skill_model.get("safe_path_globs", []),
        "forbidden_path_globs": skill_model.get("forbidden_path_globs", []),
        "required_capabilities": skill_model.get("required_capabilities", []),
        "evidence": _json_list(row["evidence_json"]),
        "provenance": _json(row["provenance_json"]),
        "success_count": row["success_count"],
        "fail_count": row["fail_count"],
        "last_validated_at": row["last_validated_at"],
        "status": row["status"],
        "trust": row["trust"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def pack_skill(item: dict[str, Any]) -> dict[str, Any]:
    steps = item.get("steps", [])
    text = canonical_json(
        {
            "name": item["name"],
            "description": item["nl_description"],
            "trigger": item["trigger_signature"],
            "scope_kind": item.get("scope_kind", "repo"),
            "scope_refs": item.get("scope_refs", []),
            "inputs": item.get("inputs", []),
            "steps": steps,
            "safe_path_globs": item.get("safe_path_globs", []),
            "forbidden_path_globs": item.get("forbidden_path_globs", []),
            "required_capabilities": item.get("required_capabilities", []),
        }
    )
    return {
        "skill_id": item["skill_id"],
        "name": item["name"],
        "description": item["nl_description"],
        "trigger_signature": item["trigger_signature"],
        "scope_kind": item.get("scope_kind", "repo"),
        "scope_refs": item.get("scope_refs", []),
        "preconditions": item.get("preconditions", []),
        "inputs": item.get("inputs", []),
        "steps": steps,
        "expected_outputs": item.get("expected_outputs", []),
        "verification_commands": item.get("verification_commands", []),
        "rollback_notes": item.get("rollback_notes", ""),
        "safe_path_globs": item.get("safe_path_globs", []),
        "forbidden_path_globs": item.get("forbidden_path_globs", []),
        "required_capabilities": item.get("required_capabilities", []),
        "status": item["status"],
        "trust": item["trust"],
        "score": item.get("score", 0.0),
        "signals": item.get("signals", []),
        "requires_revalidation": bool(item.get("requires_revalidation", False)),
        "provenance": item.get("provenance", {}),
        "token_count": estimate_tokens(text),
    }


def _reliability(row: Any) -> float:
    success = int(row["success_count"])
    fail = int(row["fail_count"])
    return success / max(1, success + fail)


def _validation_freshness(row: Any, *, half_life_days: int) -> float:
    timestamp = row["last_validated_at"] or row["updated_at"] or row["created_at"]
    age = _age_days(timestamp)
    half_life = max(1, half_life_days)
    return max(0.0, min(1.0, 0.5 ** (age / half_life)))


def _age_days(timestamp: str | None) -> int:
    if not timestamp:
        return 0
    try:
        parsed = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
    except ValueError:
        return 0
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return max(0, (datetime.now(timezone.utc) - parsed).days)


def _rank_weights(settings: Settings | None) -> dict[str, float]:
    weights = {
        "relevance": float(_skill_config(settings, "rank_relevance_weight", 0.7)),
        "reliability": float(_skill_config(settings, "rank_reliability_weight", 0.2)),
        "freshness": float(_skill_config(settings, "rank_freshness_weight", 0.1)),
    }
    weights = {key: max(0.0, value) for key, value in weights.items()}
    total = sum(weights.values())
    if total <= 0:
        return {"relevance": 0.7, "reliability": 0.2, "freshness": 0.1}
    return {key: value / total for key, value in weights.items()}


def _skill_config(settings: Settings | None, name: str, default: Any) -> Any:
    if settings is None:
        return default
    return getattr(settings.learning.skills, name, default)


def _is_cross_repo_transfer(row: Any, repo_id: str | None) -> bool:
    if not repo_id:
        return False
    evidence = _json_list(row["evidence_json"])
    evidence_repos = {
        str(item.get("repo_id"))
        for item in evidence
        if isinstance(item, dict) and item.get("repo_id")
    }
    if evidence_repos and repo_id not in evidence_repos:
        return True
    provenance = _json(row["provenance_json"])
    provenance_repo = provenance.get("repo_id")
    return bool(provenance_repo and str(provenance_repo) != repo_id)


def _skill_model(row: Any) -> dict[str, Any]:
    provenance = _json(row["provenance_json"])
    raw = provenance.get("skill_model")
    if not isinstance(raw, dict):
        raw = {}
    return {
        "scope_kind": str(raw.get("scope_kind") or "repo"),
        "scope_refs": _string_list(raw.get("scope_refs")),
        "preconditions": _string_list(raw.get("preconditions")),
        "inputs": _string_list(raw.get("inputs")),
        "expected_outputs": _string_list(raw.get("expected_outputs")),
        "verification_commands": _string_list(raw.get("verification_commands")),
        "rollback_notes": str(raw.get("rollback_notes") or ""),
        "safe_path_globs": _string_list(raw.get("safe_path_globs")),
        "forbidden_path_globs": _string_list(raw.get("forbidden_path_globs")),
        "required_capabilities": _string_list(raw.get("required_capabilities")),
        "creates_or_changes": _string_list(raw.get("creates_or_changes")),
    }


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item).strip() for item in value if str(item).strip()]


def _positive_int(value: Any) -> int | None:
    parsed = _int_value(value)
    if parsed is None or parsed <= 0:
        return None
    return parsed


def _int_value(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _suspicious_command(command: str) -> bool:
    return any(
        phrase in command
        for phrase in (
            "rm -rf",
            "del /f",
            "remove-item",
            "curl ",
            "invoke-webrequest",
            "wget ",
            "api_key",
            "password",
        )
    )


def _sensitive_command_references(command: str) -> list[str]:
    normalized = command.replace("\\", "/").lower()
    padded = f"/{normalized}"
    matches = []
    for pattern, reason in SENSITIVE_PATH_PATTERNS:
        if pattern in normalized or pattern in padded:
            matches.append(reason)
    return sorted(set(matches))


def _terms(text: str) -> set[str]:
    return {term for term in re.findall(r"[a-zA-Z][a-zA-Z0-9_]{2,}", text.lower())}


def _is_tool_workspace_path(path: str) -> bool:
    normalized = path.replace("\\", "/")
    while normalized.startswith("./"):
        normalized = normalized[2:]
    return normalized == ".ctxlayer" or normalized.startswith(".ctxlayer/")


def _json(value: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _json_list(value: str) -> list[Any]:
    try:
        parsed = json.loads(value or "[]")
    except json.JSONDecodeError:
        return []
    return parsed if isinstance(parsed, list) else []
