from __future__ import annotations

import math
from typing import Any

from ctxlayer.learning.provider import AgentProvider
from ctxlayer.utils import canonical_json


JUDGE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["verdict", "reason"],
    "properties": {
        "verdict": {"type": "string", "enum": ["pass", "fail"]},
        "reason": {"type": "string"},
    },
    "additionalProperties": False,
}


# Single-provider "jury" approximation: distinct rubric framings (personas) reduce the
# correlated-error problem that makes same-prompt multi-vote weak (Cohere "Replacing Judges
# with Juries"; self-preference bias arXiv:2410.21819). Votes cycle through these framings
# deterministically so results stay reproducible. A `judge_providers` config seam can later
# swap in true cross-family juries without changing this contract.
DEFAULT_JUDGE_PERSONAS: tuple[str, ...] = (
    "strict reviewer: only pass if the result is clearly correct and complete",
    "adversarial skeptic: actively look for a reason this result is wrong before passing",
    "correctness-first auditor: ignore style; judge only behavioral correctness",
)


def deterministic_first_judge(
    *,
    name: str,
    deterministic: dict[str, Any],
    provider: AgentProvider | None = None,
    prompt_payload: dict[str, Any] | None = None,
    model_family: str | None = None,
    budget_tokens: int | None = None,
    votes: int = 1,
    min_pass_rate: float = 1.0,
    personas: list[str] | tuple[str, ...] | None = None,
    fail_closed_on_disagreement: bool = False,
    max_disagreement: float = 0.5,
) -> dict[str, Any]:
    if not deterministic.get("ok", False):
        return {
            "ok": False,
            "name": name,
            "source": "deterministic",
            "reason": deterministic.get("reason", "deterministic_check_failed"),
            "deterministic": deterministic,
        }
    if provider is None or prompt_payload is None:
        return {
            "ok": True,
            "name": name,
            "source": "deterministic",
            "deterministic": deterministic,
        }
    requested_votes = max(1, int(votes or 1))
    required = min(1.0, max(0.0, float(min_pass_rate)))
    persona_pool = tuple(personas) if personas else DEFAULT_JUDGE_PERSONAS
    raw_votes: list[dict[str, Any]] = []
    vote_personas: list[str] = []
    for index in range(requested_votes):
        # Deterministic persona cycling gives jury-style diversity while keeping reruns stable.
        persona = persona_pool[index % len(persona_pool)] if persona_pool else ""
        raw = provider.complete(
            prompt=judge_prompt(name=name, payload=prompt_payload, persona=persona),
            role="judge",
            schema=JUDGE_SCHEMA,
            model_family=model_family,
            budget_tokens=budget_tokens,
        )
        if isinstance(raw, dict):
            raw_votes.append(raw)
            vote_personas.append(persona)
    if not raw_votes:
        return {
            "ok": False,
            "name": name,
            "source": "judge",
            "reason": "judge_no_parseable_votes",
            "deterministic": deterministic,
            "judge": {
                "votes": [],
                "pass_votes": 0,
                "total_votes": 0,
                "requested_votes": requested_votes,
                "pass_rate": 0.0,
                "min_pass_rate": required,
                "disagreement": 1.0,
                "consistency": 0.0,
                "model_family": model_family,
                "personas": list(persona_pool),
            },
        }
    pass_votes = [
        vote for vote in raw_votes if str(vote.get("verdict") or "").strip().lower() == "pass"
    ]
    pass_rate = len(pass_votes) / len(raw_votes)
    # Disagreement peaks (1.0) at a 50/50 split and is 0.0 when the jury is unanimous.
    # Consistency is the fraction agreeing with the majority verdict (test-retest signal).
    disagreement = round(1.0 - abs((2.0 * pass_rate) - 1.0), 4)
    consistency = round(max(pass_rate, 1.0 - pass_rate), 4)
    required_votes = math.ceil(required * len(raw_votes))
    ok = len(pass_votes) >= required_votes
    reason = (
        "judge_vote_pass"
        if ok
        else f"judge_vote_failed:{len(pass_votes)}/{len(raw_votes)}"
    )
    # Fail closed when the jury is too split to be trusted, even if the threshold is nominally
    # met. Mirrors the existing "fail closed on empty votes" stance for high-disagreement cases.
    if ok and fail_closed_on_disagreement and disagreement > max(0.0, float(max_disagreement)):
        ok = False
        reason = f"judge_disagreement_too_high:{disagreement}>{max_disagreement}"
    return {
        "ok": ok,
        "name": name,
        "source": "judge",
        "reason": reason,
        "deterministic": deterministic,
        "judge": {
            "votes": raw_votes,
            "pass_votes": len(pass_votes),
            "total_votes": len(raw_votes),
            "requested_votes": requested_votes,
            "pass_rate": round(pass_rate, 4),
            "min_pass_rate": required,
            "disagreement": disagreement,
            "consistency": consistency,
            "fail_closed_on_disagreement": bool(fail_closed_on_disagreement),
            "max_disagreement": round(max(0.0, float(max_disagreement)), 4),
            "model_family": model_family,
            "personas": vote_personas,
        },
    }


def judge_prompt(*, name: str, payload: dict[str, Any], persona: str | None = None) -> str:
    lines = [
        "Check this CTX Layer agent result after deterministic validation has passed.",
        "Return strict JSON with verdict pass or fail and a concise reason.",
    ]
    if persona:
        lines.append(f"Adopt this reviewing stance: {persona}.")
    lines.append(canonical_json({"name": name, "payload": payload}))
    return "\n".join(lines)
