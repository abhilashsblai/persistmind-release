from __future__ import annotations

from typing import Any


def ci_report_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "required": ["status", "violations", "selected_tests", "required_acknowledgement"],
    }
