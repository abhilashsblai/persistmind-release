from __future__ import annotations

import math
import sys
from dataclasses import dataclass
from typing import Protocol

from persistmind.utils import sha256_bytes, split_identifier_text


class Embedder(Protocol):
    @property
    def model_name(self) -> str: ...

    @property
    def dims(self) -> int: ...

    @property
    def backend(self) -> str: ...

    @property
    def degraded_reason(self) -> str | None: ...

    @property
    def degraded_severity(self) -> str | None: ...

    @property
    def degraded_remediation(self) -> str | None: ...

    @property
    def requested_backend(self) -> str: ...

    @property
    def encoding(self) -> str: ...

    @property
    def implementation_signature(self) -> str: ...

    def embed(self, text: str) -> list[float]: ...

    def embed_many(self, texts: list[str]) -> list[list[float]]: ...


@dataclass(frozen=True)
class LocalHashEmbedder:
    """Deterministic CPU-only embedding fallback.

    The production plan calls for sentence-transformers plus sqlite-vec. This
    class gives the same interface and stable vector leg without downloading a
    model during local bootstrap.
    """

    model_name: str = "local-hash-embedder-v1"
    dims: int = 128
    backend: str = "local"
    requested_backend: str = "local"
    encoding: str = "f32"
    degraded_reason: str | None = "lexical_embedding_fallback"
    degraded_severity: str | None = "warning"
    degraded_remediation: str | None = (
        "Install persistmind[full] and set embed_backend='sentence-transformers' "
        "for semantic embeddings."
    )

    @property
    def implementation_signature(self) -> str:
        return f"persistmind.local-hash-v1:python-{sys.version_info.major}.{sys.version_info.minor}"

    def embed(self, text: str) -> list[float]:
        vector = [0.0] * self.dims
        for token in split_identifier_text(text).split():
            digest = sha256_bytes(token.encode("utf-8"))
            bucket = int(digest[:8], 16) % self.dims
            sign = -1.0 if int(digest[8:10], 16) % 2 else 1.0
            vector[bucket] += sign
        norm = math.sqrt(sum(value * value for value in vector)) or 1.0
        return [round(value / norm, 6) for value in vector]

    def embed_many(self, texts: list[str]) -> list[list[float]]:
        return [self.embed(text) for text in texts]


class SentenceTransformerEmbedder:
    def __init__(
        self,
        model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
        *,
        model_path: str | object | None = None,
        requested_backend: str = "sentence-transformers",
    ):
        try:
            from sentence_transformers import SentenceTransformer  # type: ignore[import-not-found]
        except Exception as exc:
            raise RuntimeError(
                "sentence-transformers is not installed; install persistmind[full] or set embed_backend='local'"
            ) from exc
        self.model_name = model_name
        self.backend = "sentence-transformers"
        self.requested_backend = requested_backend
        self.encoding = "f32"
        self.degraded_reason: str | None = None
        self.degraded_severity: str | None = None
        self.degraded_remediation: str | None = None
        self._model = SentenceTransformer(
            str(model_path) if model_path is not None else model_name,
            local_files_only=model_path is not None,
        )
        if hasattr(self._model, "get_embedding_dimension"):
            dims = self._model.get_embedding_dimension()
        else:
            dims = self._model.get_sentence_embedding_dimension()
        self.dims = int(dims or 384)

    @property
    def implementation_signature(self) -> str:
        model_type = type(self._model)
        return f"{model_type.__module__}.{model_type.__qualname__}"

    def embed(self, text: str) -> list[float]:
        return self.embed_many([text])[0]

    def embed_many(self, texts: list[str]) -> list[list[float]]:
        vectors = self._model.encode(
            texts,
            batch_size=64,
            normalize_embeddings=True,
            show_progress_bar=False,
        )
        return [[round(float(value), 6) for value in vector] for vector in vectors]


def make_embedder(*, model_name: str, backend: str = "auto") -> Embedder:
    if backend == "local":
        return LocalHashEmbedder(model_name=model_name, requested_backend=backend)
    if backend == "sentence-transformers":
        return SentenceTransformerEmbedder(model_name=model_name, requested_backend=backend)
    if backend != "auto":
        raise ValueError(f"unknown embed backend: {backend}")
    if model_name.startswith("local-"):
        return LocalHashEmbedder(model_name=model_name, requested_backend=backend)
    try:
        return SentenceTransformerEmbedder(model_name=model_name, requested_backend=backend)
    except Exception:
        return LocalHashEmbedder(
            model_name=f"local-fallback-for:{model_name}",
            requested_backend=backend,
            degraded_reason="embedder_fallback_lexical",
        )


def cosine(left: list[float], right: list[float]) -> float:
    if not left or not right or len(left) != len(right):
        return 0.0
    return sum(a * b for a, b in zip(left, right, strict=True))
