from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from persistmind.parsing.extractors import ExtractedFile
from persistmind.utils import estimate_tokens, split_identifier_text, stable_id

DEFAULT_TARGET_TOKENS = 800
DEFAULT_MAX_TOKENS = 1_200
DEFAULT_MIN_TOKENS = 120
DEFAULT_OVERLAP_LINES = 8
DEFAULT_MAX_CHUNKS_PER_FILE = 1_024
MARKDOWN_HEADING_RE = re.compile(r"^\s{0,3}#{1,6}\s+\S")


@dataclass(frozen=True)
class Chunk:
    chunk_id: str
    path: str
    symbol_identity_id: str | None
    category: str
    start_line: int | None
    end_line: int | None
    text: str
    text_normalized: str
    token_count: int


@dataclass(frozen=True)
class _Region:
    start_line: int
    end_line: int
    text: str


def chunk_file(
    *,
    snapshot_id: str,
    repo_id: str,
    path: str,
    text: str,
    extracted: ExtractedFile,
    symbol_ids: dict[str, str],
    chunking: Any | None = None,
) -> list[Chunk]:
    lines = text.splitlines()
    target_tokens = _config_int(chunking, "target_tokens", DEFAULT_TARGET_TOKENS, minimum=1)
    max_tokens = max(
        target_tokens,
        _config_int(chunking, "max_tokens", DEFAULT_MAX_TOKENS, minimum=1),
    )
    min_tokens = min(
        max_tokens,
        _config_int(chunking, "min_tokens", DEFAULT_MIN_TOKENS, minimum=0),
    )
    overlap_lines = _config_int(chunking, "overlap_lines", DEFAULT_OVERLAP_LINES, minimum=0)
    max_chunks = _config_int(
        chunking, "max_chunks_per_file", DEFAULT_MAX_CHUNKS_PER_FILE, minimum=1
    )
    if not _config_bool(chunking, "adaptive_enabled", True):
        chunks = [_chunk(snapshot_id, repo_id, path, None, "file", 1, len(lines), text)]
    elif extracted.symbols_authoritative and lines:
        chunks = _structural_chunks(
            snapshot_id=snapshot_id,
            repo_id=repo_id,
            path=path,
            lines=lines,
            extracted=extracted,
            symbol_ids=symbol_ids,
            chunking=chunking,
            target_tokens=target_tokens,
            max_tokens=max_tokens,
            min_tokens=min_tokens,
            overlap_lines=overlap_lines,
        )
    else:
        chunks = _file_chunks(
            snapshot_id=snapshot_id,
            repo_id=repo_id,
            path=path,
            text=text,
            lines=lines,
            chunking=chunking,
            target_tokens=target_tokens,
            max_tokens=max_tokens,
            min_tokens=min_tokens,
            overlap_lines=overlap_lines,
            max_chunks=max_chunks,
        )
        chunks.extend(
            _symbol_hint_chunks(
                snapshot_id,
                repo_id,
                path,
                lines,
                extracted,
                symbol_ids,
            )[: max(0, max_chunks - len(chunks))]
        )
    _assert_complete_coverage(path, lines, chunks)
    if len(chunks) > max_chunks:
        raise ValueError(
            f"chunk_limit_incomplete: {path} requires {len(chunks)} chunks, limit is {max_chunks}"
        )
    return chunks


def _structural_chunks(
    *,
    snapshot_id: str,
    repo_id: str,
    path: str,
    lines: list[str],
    extracted: ExtractedFile,
    symbol_ids: dict[str, str],
    chunking: Any | None,
    target_tokens: int,
    max_tokens: int,
    min_tokens: int,
    overlap_lines: int,
) -> list[Chunk]:
    chunks: list[Chunk] = []
    covered: set[int] = set()
    valid_symbols = sorted(
        (
            symbol
            for symbol in extracted.symbols
            if 1 <= symbol.start_line <= symbol.end_line <= len(lines)
        ),
        key=lambda item: (item.start_line, item.end_line, item.qualname),
    )
    for symbol in valid_symbols:
        covered.update(range(symbol.start_line, symbol.end_line + 1))
        body = "\n".join(lines[symbol.start_line - 1 : symbol.end_line])
        category = "test" if symbol.is_test else "implementation"
        regions = (
            _nextgen_region(
                lines,
                symbol.start_line,
                symbol.end_line,
                target_tokens=target_tokens,
                max_tokens=max_tokens,
                min_tokens=min_tokens,
                overlap_lines=overlap_lines,
            )
            if _config_bool(chunking, "split_oversized_symbols", True)
            and estimate_tokens(body) > max_tokens
            else [_Region(symbol.start_line, symbol.end_line, body or symbol.signature)]
        )
        for region in regions:
            chunks.append(
                _chunk(
                    snapshot_id,
                    repo_id,
                    path,
                    symbol_ids.get(symbol.qualname),
                    category,
                    region.start_line,
                    region.end_line,
                    region.text,
                )
            )
    for start, end in _uncovered_intervals(lines, covered):
        for region in _nextgen_region(
            lines,
            start,
            end,
            target_tokens=target_tokens,
            max_tokens=max_tokens,
            min_tokens=min_tokens,
            overlap_lines=overlap_lines,
        ):
            chunks.append(
                _chunk(
                    snapshot_id,
                    repo_id,
                    path,
                    None,
                    "file",
                    region.start_line,
                    region.end_line,
                    region.text,
                )
            )
    return chunks


def _symbol_hint_chunks(
    snapshot_id: str,
    repo_id: str,
    path: str,
    lines: list[str],
    extracted: ExtractedFile,
    symbol_ids: dict[str, str],
) -> list[Chunk]:
    chunks = []
    for symbol in extracted.symbols:
        if not (1 <= symbol.start_line <= symbol.end_line <= len(lines)):
            continue
        chunks.append(
            _chunk(
                snapshot_id,
                repo_id,
                path,
                symbol_ids.get(symbol.qualname),
                "symbol_hint",
                symbol.start_line,
                symbol.end_line,
                "\n".join(lines[symbol.start_line - 1 : symbol.end_line]),
            )
        )
    return chunks


def _uncovered_intervals(lines: list[str], covered: set[int]) -> list[tuple[int, int]]:
    missing = [
        line for line in range(1, len(lines) + 1) if line not in covered and lines[line - 1].strip()
    ]
    if not missing:
        return []
    intervals: list[tuple[int, int]] = []
    start = previous = missing[0]
    for line in missing[1:]:
        if line != previous + 1:
            intervals.append((start, previous))
            start = line
        previous = line
    intervals.append((start, previous))
    return intervals


def _assert_complete_coverage(path: str, lines: list[str], chunks: list[Chunk]) -> None:
    covered: set[int] = set()
    for chunk in chunks:
        if chunk.start_line is None or chunk.end_line is None:
            continue
        covered.update(range(chunk.start_line, chunk.end_line + 1))
    indexable = {line for line, text in enumerate(lines, 1) if text.strip()}
    missing = sorted(indexable - covered)
    if missing:
        raise ValueError(f"chunk_coverage_incomplete: {path} omits lines {missing[:20]}")


def _legacy_chunk_file(
    *,
    snapshot_id: str,
    repo_id: str,
    path: str,
    text: str,
    extracted: ExtractedFile,
    symbol_ids: dict[str, str],
) -> list[Chunk]:
    chunks: list[Chunk] = []
    lines = text.splitlines()
    for symbol in extracted.symbols:
        body = "\n".join(lines[max(symbol.start_line - 1, 0) : symbol.end_line])
        if not body.strip():
            body = symbol.signature
        symbol_id = symbol_ids.get(symbol.qualname)
        category = "test" if symbol.is_test else "implementation"
        chunks.append(
            _chunk(
                snapshot_id,
                repo_id,
                path,
                symbol_id,
                category,
                symbol.start_line,
                symbol.end_line,
                body,
            )
        )
    if not chunks:
        chunks.append(
            _chunk(snapshot_id, repo_id, path, None, "file", 1, len(lines), text[:12_000])
        )
    return chunks


def _file_chunks(
    *,
    snapshot_id: str,
    repo_id: str,
    path: str,
    text: str,
    lines: list[str],
    chunking: Any | None,
    target_tokens: int,
    max_tokens: int,
    min_tokens: int,
    overlap_lines: int,
    max_chunks: int,
) -> list[Chunk]:
    if not lines:
        return [_chunk(snapshot_id, repo_id, path, None, "file", 1, 0, text)]
    if (
        not _config_bool(chunking, "split_symbol_free_files", True)
        or estimate_tokens(text) <= max_tokens
    ):
        return [_chunk(snapshot_id, repo_id, path, None, "file", 1, len(lines), text)]

    regions = _markdown_regions(lines) if _should_nextgen_markdown(path, chunking) else []
    if not regions:
        regions = [_Region(1, len(lines), "\n".join(lines))]

    chunks: list[Chunk] = []
    for region in regions:
        if not region.text.strip():
            continue
        subregions = (
            [region]
            if estimate_tokens(region.text) <= max_tokens
            else _nextgen_region(
                lines,
                region.start_line,
                region.end_line,
                target_tokens=target_tokens,
                max_tokens=max_tokens,
                min_tokens=min_tokens,
                overlap_lines=overlap_lines,
            )
        )
        for subregion in subregions:
            chunks.append(
                _chunk(
                    snapshot_id,
                    repo_id,
                    path,
                    None,
                    "file",
                    subregion.start_line,
                    subregion.end_line,
                    subregion.text,
                )
            )
            if len(chunks) >= max_chunks:
                return chunks
    if not chunks:
        return [_chunk(snapshot_id, repo_id, path, None, "file", 1, len(lines), text)]
    return chunks


def _nextgen_region(
    lines: list[str],
    start_line: int,
    end_line: int,
    *,
    target_tokens: int,
    max_tokens: int,
    min_tokens: int,
    overlap_lines: int,
) -> list[_Region]:
    start_line = max(1, start_line)
    end_line = min(len(lines), max(start_line, end_line))
    regions: list[_Region] = []
    current_start = start_line
    current_lines: list[str] = []
    line_no = start_line
    while line_no <= end_line:
        line = lines[line_no - 1]
        if not current_lines and estimate_tokens(line) > max_tokens:
            regions.extend(_nextgen_long_line(line, line_no, max_tokens=max_tokens))
            line_no += 1
            current_start = line_no
            continue

        next_lines = [*current_lines, line]
        next_text = "\n".join(next_lines)
        if current_lines and estimate_tokens(next_text) > max_tokens:
            region = _Region(current_start, line_no - 1, "\n".join(current_lines))
            regions.append(region)
            current_start, current_lines = _overlap_tail(
                lines, region.start_line, region.end_line, overlap_lines
            )
            if current_lines and estimate_tokens("\n".join(current_lines)) >= target_tokens:
                current_start = line_no
                current_lines = []
            continue

        if not current_lines:
            current_start = line_no
        current_lines.append(line)
        current_text = "\n".join(current_lines)
        if estimate_tokens(current_text) >= target_tokens and line_no < end_line:
            region = _Region(current_start, line_no, current_text)
            regions.append(region)
            current_start, current_lines = _overlap_tail(
                lines, region.start_line, region.end_line, overlap_lines
            )
            while current_lines and estimate_tokens("\n".join(current_lines)) >= target_tokens:
                current_lines.pop(0)
                current_start += 1
        line_no += 1

    if current_lines:
        regions.append(_Region(current_start, end_line, "\n".join(current_lines)))
    return _merge_small_tail(regions, min_tokens=min_tokens, max_tokens=max_tokens)


def _nextgen_long_line(line: str, line_no: int, *, max_tokens: int) -> list[_Region]:
    chunk_chars = max(1, max_tokens * 4)
    regions: list[_Region] = []
    for index in range(0, len(line), chunk_chars):
        regions.append(_Region(line_no, line_no, line[index : index + chunk_chars]))
    return regions or [_Region(line_no, line_no, line)]


def _overlap_tail(
    lines: list[str], start_line: int, end_line: int, overlap_lines: int
) -> tuple[int, list[str]]:
    if overlap_lines <= 0:
        return end_line + 1, []
    overlap_start = max(start_line, end_line - overlap_lines + 1)
    if overlap_start <= start_line:
        return end_line + 1, []
    return (
        overlap_start,
        [lines[index - 1] for index in range(overlap_start, end_line + 1)],
    )


def _merge_small_tail(regions: list[_Region], *, min_tokens: int, max_tokens: int) -> list[_Region]:
    if len(regions) < 2 or min_tokens <= 0:
        return regions
    tail = regions[-1]
    previous = regions[-2]
    merged_text = "\n".join([previous.text, tail.text])
    if estimate_tokens(tail.text) < min_tokens and estimate_tokens(merged_text) <= max_tokens:
        return [
            *regions[:-2],
            _Region(previous.start_line, tail.end_line, merged_text),
        ]
    return regions


def _markdown_regions(lines: list[str]) -> list[_Region]:
    headings = [
        index for index, line in enumerate(lines, start=1) if MARKDOWN_HEADING_RE.match(line)
    ]
    if not headings:
        return []
    regions: list[_Region] = []
    if headings[0] > 1:
        regions.append(_region(lines, 1, headings[0] - 1))
    for index, start in enumerate(headings):
        end = headings[index + 1] - 1 if index + 1 < len(headings) else len(lines)
        regions.append(_region(lines, start, end))
    return regions


def _region(lines: list[str], start_line: int, end_line: int) -> _Region:
    return _Region(start_line, end_line, "\n".join(lines[start_line - 1 : end_line]))


def _should_nextgen_markdown(path: str, chunking: Any | None) -> bool:
    return path.lower().endswith(".md") and _config_bool(chunking, "markdown_heading_split", True)


def _config_bool(config: Any | None, name: str, default: bool) -> bool:
    if config is None:
        return default
    return bool(getattr(config, name, default))


def _config_int(config: Any | None, name: str, default: int, *, minimum: int) -> int:
    if config is None:
        return max(minimum, default)
    try:
        value = int(getattr(config, name, default))
    except (TypeError, ValueError):
        value = default
    return max(minimum, value)


def _chunk(
    snapshot_id: str,
    repo_id: str,
    path: str,
    symbol_identity_id: str | None,
    category: str,
    start_line: int | None,
    end_line: int | None,
    text: str,
) -> Chunk:
    normalized = split_identifier_text(f"{path}\n{text}")
    chunk_id = stable_id(
        snapshot_id, repo_id, path, symbol_identity_id or "", start_line, end_line, text
    )
    return Chunk(
        chunk_id=chunk_id,
        path=path,
        symbol_identity_id=symbol_identity_id,
        category=category,
        start_line=start_line,
        end_line=end_line,
        text=text,
        text_normalized=normalized,
        token_count=estimate_tokens(text),
    )
