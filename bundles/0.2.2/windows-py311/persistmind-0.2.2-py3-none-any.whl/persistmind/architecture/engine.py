from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from persistmind.config import Settings
from persistmind.snapshot import SnapshotInfo
from persistmind.utils import stable_id


class ArchitectureEngine:
    def __init__(self, repo_root: Path, store: Any, settings: Settings):
        self.repo_root = repo_root
        self.store = store
        self.settings = settings

    def infer(self, snapshot: SnapshotInfo) -> dict[str, Any]:
        nodes = [self._node(row) for row in self.store.semantic_nodes(snapshot.repo_id)]
        files = [dict(row) for row in self.store.snapshot_files(snapshot.snapshot_id)]
        services = self._services(nodes, files)
        dependency_graph = self._dependency_graph(snapshot.repo_id)
        contracts = [node for node in nodes if node["node_type"] == "api_contract"]
        entities = [node for node in nodes if node["node_type"] == "data_entity"]
        flags = [node for node in nodes if node["node_type"] == "feature_flag"]
        critical_paths = [
            row["path"]
            for row in files
            if any(_match(row["path"], pattern) for pattern in self.settings.eval.critical_paths)
        ]
        return {
            "ok": True,
            "schema_version": "persistmind.architecture.v1",
            "architecture_id": stable_id(
                snapshot.snapshot_id, "architecture", len(nodes), len(files)
            ),
            "repo_id": snapshot.repo_id,
            "snapshot_id": snapshot.snapshot_id,
            "service_map": services,
            "contracts": contracts,
            "data_entities": entities,
            "feature_flags": flags,
            "critical_paths": sorted(critical_paths),
            "dependency_graph": dependency_graph,
            "community_summaries": self._community_summaries(
                services=services,
                nodes=nodes,
                dependencies=dependency_graph,
            ),
            "global_explanation": self._global_explanation(
                services=services,
                dependencies=dependency_graph,
                critical_paths=critical_paths,
            ),
            "summary": {
                "services": len(services),
                "contracts": len(contracts),
                "data_entities": len(entities),
                "feature_flags": len(flags),
                "critical_paths": len(critical_paths),
                "communities": len(services),
            },
        }

    def explain(self, snapshot: SnapshotInfo, service_name: str) -> dict[str, Any]:
        architecture = self.infer(snapshot)
        service = next(
            (item for item in architecture["service_map"] if item["name"] == service_name),
            None,
        )
        if service is None:
            return {
                "ok": False,
                "error": "service not found",
                "service": service_name,
                "available": [item["name"] for item in architecture["service_map"]],
            }
        prefix = f"{service_name}/"
        return {
            "ok": True,
            "service": service_name,
            "owned_files": service["files"],
            "contracts": self._nodes_for_prefix(snapshot.repo_id, "api_contract", prefix),
            "workflows": self._nodes_for_prefix(snapshot.repo_id, "workflow", prefix),
            "data_entities": self._nodes_for_prefix(snapshot.repo_id, "data_entity", prefix),
            "feature_flags": self._nodes_for_prefix(snapshot.repo_id, "feature_flag", prefix),
            "tests": [path for path in service["files"] if _is_test(path)],
            "risky_dependencies": [
                edge
                for edge in architecture["dependency_graph"]
                if edge["src"].startswith(prefix) or edge["dst"].startswith(prefix)
            ],
        }

    def drift(
        self,
        snapshot: SnapshotInfo,
        *,
        strict: bool = False,
        low_confidence_threshold: float = 0.5,
        persist: bool = True,
    ) -> dict[str, Any]:
        file_rows = [dict(row) for row in self.store.snapshot_files(snapshot.snapshot_id)]
        files = [row["path"] for row in file_rows]
        current_versions = {row["path"]: row["file_version_id"] for row in file_rows}
        indexed_versions = {
            row["path"]: row["file_version_id"]
            for row in self.store.semantic_file_index(snapshot.repo_id)
        }
        tests = {path for path in files if _is_test(path)}
        nodes = [self._node(row) for row in self.store.semantic_nodes(snapshot.repo_id)]
        findings: list[dict[str, Any]] = []
        for contract in [node for node in nodes if node["node_type"] == "api_contract"]:
            evidence = self.store.semantic_evidence(node_id=contract["node_id"])
            paths = [row["path"] for row in evidence if row["path"]]
            if paths and not any(_has_nearby_test(path, tests) for path in paths):
                findings.append(
                    _finding(
                        snapshot,
                        "route_without_nearby_test",
                        "warn",
                        f"API contract {contract['name']} has no nearby test evidence.",
                        node_id=contract["node_id"],
                        node=contract["name"],
                        paths=sorted(set(paths)),
                        confidence=contract.get("confidence"),
                    )
                )
        defined_flags = {
            node["name"]
            for node in nodes
            if node["node_type"] == "feature_flag" and node["source"] != "feature_flag_reference"
        }
        for flag in [node for node in nodes if node["node_type"] == "feature_flag"]:
            if defined_flags and flag["name"] not in defined_flags:
                findings.append(
                    _finding(
                        snapshot,
                        "feature_flag_referenced_not_defined",
                        "warn",
                        f"Feature flag {flag['name']} is referenced but not defined.",
                        node_id=flag["node_id"],
                        node=flag["name"],
                        confidence=flag.get("confidence"),
                    )
                )
        for node in nodes:
            evidence = self.store.semantic_evidence(node_id=node["node_id"])
            paths = sorted({row["path"] for row in evidence if row["path"]})
            missing = [path for path in paths if path not in current_versions]
            changed = [
                path
                for path in paths
                if path in current_versions
                and indexed_versions.get(path)
                and indexed_versions.get(path) != current_versions[path]
            ]
            if missing:
                findings.append(
                    _finding(
                        snapshot,
                        "stale_node",
                        "error",
                        f"Semantic node {node['name']} has evidence paths no longer in the snapshot.",
                        node_id=node["node_id"],
                        node=node["name"],
                        paths=missing,
                        confidence=node.get("confidence"),
                    )
                )
            if changed:
                findings.append(
                    _finding(
                        snapshot,
                        "divergence",
                        "warn",
                        f"Semantic node {node['name']} evidence changed since indexing.",
                        node_id=node["node_id"],
                        node=node["name"],
                        paths=changed,
                        confidence=node.get("confidence"),
                    )
                )
            provenance = node.get("metadata", {}).get("provenance")
            if not isinstance(provenance, dict) or not provenance.get("inference_method"):
                findings.append(
                    _finding(
                        snapshot,
                        "low_confidence",
                        "warn",
                        f"Semantic node {node['name']} has missing inference provenance.",
                        node_id=node["node_id"],
                        node=node["name"],
                        paths=paths,
                        confidence=node.get("confidence"),
                    )
                )
            elif float(node.get("confidence") or 0.0) < low_confidence_threshold:
                findings.append(
                    _finding(
                        snapshot,
                        "low_confidence",
                        "warn",
                        f"Semantic node {node['name']} is below confidence threshold {low_confidence_threshold}.",
                        node_id=node["node_id"],
                        node=node["name"],
                        paths=paths,
                        confidence=node.get("confidence"),
                    )
                )
        for edge in self.store.semantic_edges(snapshot.repo_id):
            metadata = json.loads(edge["metadata_json"] or "{}")
            provenance = metadata.get("provenance") if isinstance(metadata, dict) else {}
            if (
                not isinstance(provenance, dict)
                or not provenance.get("inference_method")
                or float(edge["confidence"] or 0.0) < low_confidence_threshold
            ):
                findings.append(
                    _finding(
                        snapshot,
                        "low_confidence",
                        "warn",
                        f"Semantic edge {edge['kind']} from {edge['src_name']} to {edge['dst_name']} is low confidence or missing provenance.",
                        edge_id=edge["edge_id"],
                        paths=[],
                        confidence=edge["confidence"],
                    )
                )
        if persist:
            persisted_ids = self.store.write_semantic_drift_findings(
                repo_id=snapshot.repo_id,
                snapshot_id=snapshot.snapshot_id,
                findings=findings,
            )
            for item, finding_id in zip(findings, persisted_ids, strict=False):
                item["finding_id"] = finding_id
        has_error = any(item["severity"] == "error" for item in findings)
        has_warn = any(item["severity"] == "warn" for item in findings)
        status = "fail" if has_error or (strict and has_warn) else "warn" if has_warn else "pass"
        return {
            "ok": True,
            "schema_version": "persistmind.architecture_drift.v2",
            "repo_id": snapshot.repo_id,
            "snapshot_id": snapshot.snapshot_id,
            "findings": findings,
            "strict": strict,
            "status": status,
        }

    def critical_paths(self, snapshot: SnapshotInfo) -> dict[str, Any]:
        paths = [
            row["path"]
            for row in self.store.snapshot_files(snapshot.snapshot_id)
            if any(_match(row["path"], pattern) for pattern in self.settings.eval.critical_paths)
        ]
        return {"ok": True, "repo_id": snapshot.repo_id, "paths": sorted(paths)}

    def _services(
        self, nodes: list[dict[str, Any]], files: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        service_names = {
            node["name"] for node in nodes if node["node_type"] == "service_boundary"
        } | {
            row["path"].split("/", 1)[0]
            for row in files
            if "/" in row["path"] and not row["path"].startswith(("tests/", "docs/"))
        }
        services = []
        for name in sorted(service_names):
            owned = sorted(row["path"] for row in files if row["path"].startswith(f"{name}/"))
            services.append({"name": name, "files": owned, "file_count": len(owned)})
        return services

    def _dependency_graph(self, repo_id: str) -> list[dict[str, Any]]:
        rows = self.store.logical_edges(
            "src_repo_id = ? AND dst_repo_id = ? AND src_node_type = 'file' AND dst_node_type = 'file'",
            (repo_id, repo_id),
        )
        return [
            {
                "src": row["src_node_id"],
                "dst": row["dst_node_id"],
                "kind": row["kind"],
                "confidence": row["confidence"],
            }
            for row in rows
        ]

    def _community_summaries(
        self,
        *,
        services: list[dict[str, Any]],
        nodes: list[dict[str, Any]],
        dependencies: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        by_service = {service["name"]: service for service in services}
        summaries: list[dict[str, Any]] = []
        for name, service in sorted(by_service.items()):
            prefix = f"{name}/"
            service_nodes = [
                node
                for node in nodes
                if str(node.get("metadata", {}).get("path") or "").startswith(prefix)
                or str(node.get("name") or "").startswith(prefix)
            ]
            inbound = []
            outbound = []
            for edge in dependencies:
                src_service = _service_for_path(edge["src"])
                dst_service = _service_for_path(edge["dst"])
                if src_service == name and dst_service and dst_service != name:
                    outbound.append(edge)
                if dst_service == name and src_service and src_service != name:
                    inbound.append(edge)
            summaries.append(
                {
                    "community_id": stable_id("architecture-community", name)[:16],
                    "name": name,
                    "file_count": service["file_count"],
                    "files": service["files"][:25],
                    "node_types": _count_by(service_nodes, "node_type"),
                    "inbound_dependencies": _dependency_counts(inbound, incoming=True),
                    "outbound_dependencies": _dependency_counts(outbound, incoming=False),
                    "summary": _community_summary_text(
                        name=name,
                        file_count=service["file_count"],
                        node_types=_count_by(service_nodes, "node_type"),
                        inbound_count=len(inbound),
                        outbound_count=len(outbound),
                    ),
                }
            )
        return summaries

    def _global_explanation(
        self,
        *,
        services: list[dict[str, Any]],
        dependencies: list[dict[str, Any]],
        critical_paths: list[str],
    ) -> dict[str, Any]:
        central_services = _central_services(dependencies)
        return {
            "why_this_context": (
                "Architecture inference groups indexed semantic nodes and file-level "
                "dependency edges by service-like path communities, then highlights "
                "critical paths configured for evaluation gates."
            ),
            "service_count": len(services),
            "dependency_edge_count": len(dependencies),
            "critical_path_count": len(critical_paths),
            "central_services": central_services[:10],
        }

    def _nodes_for_prefix(self, repo_id: str, node_type: str, prefix: str) -> list[dict[str, Any]]:
        results = []
        for node in self.store.semantic_nodes(repo_id):
            item = self._node(node)
            if item["node_type"] != node_type:
                continue
            evidence = self.store.semantic_evidence(node_id=item["node_id"])
            if any((row["path"] or "").startswith(prefix) for row in evidence):
                results.append(item)
        return results

    def _node(self, row: Any) -> dict[str, Any]:
        return {
            "node_id": row["node_id"],
            "node_type": row["node_type"],
            "name": row["name"],
            "confidence": row["confidence"],
            "source": row["source"],
            "metadata": json.loads(row["metadata_json"] or "{}"),
        }


def _is_test(path: str) -> bool:
    name = Path(path).name
    return path.startswith("tests/") or name.startswith("test_") or ".test." in name


def _has_nearby_test(path: str, tests: set[str]) -> bool:
    stem = Path(path).stem.replace("route", "").replace("api", "")
    return any(stem and stem in Path(test).stem for test in tests)


def _match(path: str, pattern: str) -> bool:
    import fnmatch

    return fnmatch.fnmatch(path, pattern)


def _service_for_path(path: str) -> str | None:
    if not path or "/" not in path:
        return None
    first = path.split("/", 1)[0]
    return None if first in {"tests", "docs"} else first


def _count_by(items: list[dict[str, Any]], key: str) -> dict[str, int]:
    counts: dict[str, int] = {}
    for item in items:
        value = str(item.get(key) or "unknown")
        counts[value] = counts.get(value, 0) + 1
    return dict(sorted(counts.items()))


def _dependency_counts(edges: list[dict[str, Any]], *, incoming: bool) -> list[dict[str, Any]]:
    counts: dict[str, int] = {}
    key = "src" if incoming else "dst"
    for edge in edges:
        service = _service_for_path(edge.get(key, ""))
        if service:
            counts[service] = counts.get(service, 0) + 1
    return [
        {"service": service, "edge_count": count}
        for service, count in sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    ]


def _community_summary_text(
    *,
    name: str,
    file_count: int,
    node_types: dict[str, int],
    inbound_count: int,
    outbound_count: int,
) -> str:
    prominent = (
        ", ".join(f"{key}:{value}" for key, value in node_types.items()) or "no semantic nodes"
    )
    return (
        f"{name} owns {file_count} files, has {prominent}, "
        f"{inbound_count} inbound cross-service edges, and {outbound_count} outbound cross-service edges."
    )


def _central_services(edges: list[dict[str, Any]]) -> list[dict[str, Any]]:
    counts: dict[str, int] = {}
    for edge in edges:
        for key in ["src", "dst"]:
            service = _service_for_path(edge.get(key, ""))
            if service:
                counts[service] = counts.get(service, 0) + 1
    return [
        {"service": service, "edge_count": count}
        for service, count in sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    ]


def _finding(
    snapshot: SnapshotInfo,
    finding_type: str,
    severity: str,
    detail: str,
    *,
    node_id: str | None = None,
    edge_id: str | None = None,
    node: str | None = None,
    paths: list[str] | None = None,
    confidence: float | None = None,
) -> dict[str, Any]:
    return {
        "finding_type": finding_type,
        "type": finding_type,
        "severity": severity,
        "repo_id": snapshot.repo_id,
        "snapshot_id": snapshot.snapshot_id,
        "node_id": node_id,
        "edge_id": edge_id,
        "node": node,
        "paths": paths or [],
        "detail": detail,
        "confidence": confidence,
        "status": "open",
        "detected_at": snapshot.snapshot_id,
    }
