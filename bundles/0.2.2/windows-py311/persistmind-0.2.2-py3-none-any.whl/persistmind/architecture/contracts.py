from __future__ import annotations

import json
import hashlib
from importlib import resources
from pathlib import Path
from typing import Any

from persistmind.application.registry import validate_operation_catalog


REQUIRED_ARCHITECTURE_RESOURCES = (
    "bounded-domains.v1.json",
    "growth-ratchets.v1.json",
    "operation-dispositions.v2.json",
    "operations.v2.json",
)


def validate_architecture_contracts(repo_root: Path) -> dict[str, Any]:
    repo_root = repo_root.resolve()
    source_package = repo_root / "src" / "persistmind"
    source_checkout = source_package.is_dir()
    package_root = (
        source_package if source_checkout else Path(str(resources.files("persistmind"))).resolve()
    )
    resource_root = package_root / "architecture"
    checks: list[dict[str, Any]] = []
    for name in REQUIRED_ARCHITECTURE_RESOURCES:
        path = resource_root / name
        problems: list[str] = []
        document: dict[str, Any] = {}
        if not path.exists():
            problems.append("missing")
        else:
            try:
                loaded = json.loads(path.read_text(encoding="utf-8"))
                if not isinstance(loaded, dict):
                    problems.append("not_object")
                else:
                    document = loaded
            except (OSError, json.JSONDecodeError):
                problems.append("invalid_json")
        if (
            document
            and name != "operation-dispositions.v2.json"
            and not document.get("generated_for_commit")
        ):
            problems.append("missing_source_commit")
        for relative, expected in document.get("input_hashes", {}).items():
            source = _contract_input(
                repo_root,
                package_root,
                str(relative),
                source_checkout=source_checkout,
            )
            if not source.is_file():
                if not source_checkout and not str(relative).replace("\\", "/").startswith(
                    "src/persistmind/"
                ):
                    continue
                problems.append(f"missing_input:{relative}")
                continue
            actual = hashlib.sha256(source.read_bytes().replace(b"\r\n", b"\n")).hexdigest()
            if actual != expected:
                problems.append(f"stale_input:{relative}")
        checks.append({"resource": name, "ok": not problems, "problems": problems})
    try:
        catalog = validate_operation_catalog()
    except Exception as exc:  # noqa: BLE001 - validation reports the exact contract failure.
        catalog = {"ok": False, "status": "invalid", "error": str(exc)}
    storage_calls = package_root / "storage" / "resources" / "storage-call-sites.v1.json"
    storage_problems: list[str] = []
    if not storage_calls.exists():
        storage_problems.append("missing")
    else:
        try:
            storage_document = json.loads(storage_calls.read_text(encoding="utf-8"))
            for relative, expected in storage_document.get("input_hashes", {}).items():
                source = _contract_input(
                    repo_root,
                    package_root,
                    str(relative),
                    source_checkout=source_checkout,
                )
                if not source.is_file():
                    if not source_checkout and not str(relative).replace("\\", "/").startswith(
                        "src/persistmind/"
                    ):
                        continue
                    storage_problems.append(f"missing_input:{relative}")
                elif (
                    hashlib.sha256(source.read_bytes().replace(b"\r\n", b"\n")).hexdigest()
                    != expected
                ):
                    storage_problems.append(f"stale_input:{relative}")
        except (OSError, json.JSONDecodeError):
            storage_problems.append("invalid_json")
    checks.append(
        {
            "resource": "storage-call-sites.v1.json",
            "ok": not storage_problems,
            "problems": storage_problems,
        }
    )
    ok = all(item["ok"] for item in checks) and bool(catalog.get("ok"))
    return {
        "ok": ok,
        "status": "verified" if ok else "invalid",
        "schema_version": "persistmind.architecture_contract_validation.v1",
        "checks": checks,
        "operation_catalog": catalog,
        "validation_scope": "source_checkout" if source_checkout else "installed_runtime",
    }


def _contract_input(
    repo_root: Path,
    package_root: Path,
    relative: str,
    *,
    source_checkout: bool,
) -> Path:
    if source_checkout:
        return repo_root / relative
    package_prefix = "src/persistmind/"
    normalized = relative.replace("\\", "/")
    if normalized.startswith(package_prefix):
        return package_root / normalized.removeprefix(package_prefix)
    return repo_root / normalized
