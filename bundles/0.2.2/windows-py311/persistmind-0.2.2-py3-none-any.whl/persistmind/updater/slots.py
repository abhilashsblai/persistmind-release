from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import sysconfig
import venv
import time
import uuid
from pathlib import Path
from typing import Any

from .atomic import replace, write_json
from .errors import UpdateError
from .paths import python_in_slot, update_home


class EngineSlotManager:
    def __init__(self, home: Path | None = None):
        self.home = (home or update_home()).resolve()
        self.engines = self.home / "engines" / _python_tag()

    def slot_for(self, version: str, digest: str) -> Path:
        return self.engines / f"{version}-{digest}"

    def relative_slot(self, slot: Path) -> str:
        return slot.resolve().relative_to(self.home).as_posix()

    def ensure(
        self,
        *,
        version: str,
        digest: str,
        wheel: Path,
        wheelhouse: Path | None = None,
        wheel_filename: str | None = None,
        profile: str = "core",
    ) -> Path:
        slot = self.slot_for(version, digest)
        if (slot / "READY").is_file():
            self.verify(slot, version)
            return slot
        self.engines.mkdir(parents=True, exist_ok=True)
        temporary = slot.with_name(f".{slot.name}.partial-{os.getpid()}")
        staging = self.home / "staging" / f"{os.getpid()}-{uuid.uuid4().hex[:8]}"
        if temporary.exists():
            shutil.rmtree(temporary)
        try:
            venv.EnvBuilder(with_pip=True, clear=True).create(temporary)
            python = python_in_slot(temporary)
            canonical_name = wheel_filename or wheel.name
            if Path(canonical_name).name != canonical_name or not canonical_name.endswith(".whl"):
                raise UpdateError("release_metadata_invalid", "wheel filename is unsafe")
            # Keep the canonical wheel outside the already long digest-named
            # engine path.  Otherwise Windows installations without long-path
            # support can fail before pip starts (WinError 3).
            staged = staging / canonical_name
            staged.parent.mkdir(parents=True, exist_ok=True)
            if wheelhouse is not None:
                for dependency in wheelhouse.glob("*.whl"):
                    shutil.copy2(dependency, staging / dependency.name)
            else:
                shutil.copy2(wheel, staged)
            target = str(staged.resolve())
            if profile in {"analytics", "full"}:
                distribution = (
                    "persistmind"
                    if canonical_name.casefold().startswith("persistmind-")
                    else "persistmind"
                )
                target = f"{distribution}[{profile}] @ {staged.resolve().as_uri()}"
            _run(
                [
                    str(python),
                    "-m",
                    "pip",
                    "install",
                    "--disable-pip-version-check",
                    "--no-input",
                    *(["--no-index", "--find-links", str(staging.resolve())] if wheelhouse else []),
                    target,
                ],
                status="dependency_install_failed",
                timeout=900,
            )
            self.verify(temporary, version)
            write_json(
                temporary / "slot.json",
                {
                    "schema_version": "persistmind.engine_slot.v1",
                    "version": version,
                    "wheel_sha256": digest,
                    "profile": profile,
                    "python": str(python),
                },
            )
            (temporary / "READY").write_text(f"{version}\n{digest}\n", encoding="utf-8")
            replace(temporary, slot)
        except Exception:
            shutil.rmtree(temporary, ignore_errors=True)
            raise
        finally:
            shutil.rmtree(staging, ignore_errors=True)
        return slot

    def verify(self, slot: Path, version: str) -> dict[str, Any]:
        python = python_in_slot(slot)
        script = (
            "import json, pathlib, persistmind; "
            "print(json.dumps({'version':persistmind.__version__,'path':str(pathlib.Path(persistmind.__file__).resolve())}))"
        )
        result = _run(
            [str(python), "-I", "-c", script],
            status="candidate_smoke_failed",
            timeout=60,
        )
        try:
            value = json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise UpdateError(
                "candidate_smoke_failed", "candidate returned invalid smoke output"
            ) from exc
        package_path = Path(str(value.get("path") or "")).resolve()
        try:
            package_path.relative_to(slot.resolve())
        except ValueError as exc:
            raise UpdateError(
                "candidate_smoke_failed", "candidate imported outside its engine slot"
            ) from exc
        if str(value.get("version")) != version:
            raise UpdateError("candidate_smoke_failed", "candidate version does not match release")
        _run(
            [str(python), "-I", "-m", "persistmind", "--version"],
            status="candidate_smoke_failed",
            timeout=60,
        )
        return value

    def garbage_collect(
        self, *, referenced: set[str], minimum_age_seconds: float = 30 * 86400
    ) -> list[str]:
        """Remove only old READY slots that no registry/transaction references."""
        removed: list[str] = []
        if not self.engines.is_dir():
            return removed
        now = time.time()
        for slot in self.engines.iterdir():
            if not slot.is_dir() or not (slot / "READY").is_file():
                continue
            relative = self.relative_slot(slot)
            if relative in referenced or now - slot.stat().st_mtime < minimum_age_seconds:
                continue
            shutil.rmtree(slot)
            removed.append(relative)
        return removed


def install_profile(home: Path | None = None) -> str:
    path = (home or update_home()) / "install.json"
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return "core"
    profile = str(value.get("profile") or "core") if isinstance(value, dict) else "core"
    return profile if profile in {"core", "analytics", "full"} else "core"


def _python_tag() -> str:
    implementation = sys.implementation.name
    return f"{implementation}{sys.version_info.major}{sys.version_info.minor}-{sysconfig.get_platform()}"


def _run(
    command: list[str],
    *,
    status: str,
    timeout: float,
    cwd: Path | None = None,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    try:
        result = subprocess.run(
            command,
            cwd=cwd,
            env=env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise UpdateError(status, f"command failed to start: {exc}") from exc
    if result.returncode:
        detail = (result.stderr or result.stdout).strip()[-2000:]
        raise UpdateError(status, detail or f"command exited with {result.returncode}")
    return result
