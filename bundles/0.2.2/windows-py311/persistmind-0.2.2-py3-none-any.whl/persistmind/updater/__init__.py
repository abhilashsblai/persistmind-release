"""Verified, transactional PersistMind wheel updates."""

from .command import run_update

__all__ = ["run_update"]
