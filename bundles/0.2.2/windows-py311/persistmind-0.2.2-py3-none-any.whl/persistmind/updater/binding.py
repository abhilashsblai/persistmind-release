from __future__ import annotations

from pathlib import Path
from typing import Any

from .atomic import read_json, write_json
from .errors import UpdateError
from .paths import binding_path, python_in_slot, update_home

SCHEMA_VERSION = "persistmind.project_engine.v1"
LEGACY_SCHEMA_VERSION = "persistmind.project_engine.v1"


def read_binding(repo: Path) -> dict[str, Any] | None:
    value = read_json(binding_path(repo))
    if value is None:
        return None
    if value.get("schema_version") not in {SCHEMA_VERSION, LEGACY_SCHEMA_VERSION}:
        raise UpdateError("project_binding_invalid", "unsupported project engine binding")
    required = {"version", "channel", "wheel_sha256", "slot", "transaction_id"}
    if any(not value.get(item) for item in required):
        raise UpdateError("project_binding_invalid", "project engine binding is incomplete")
    return value


def write_binding(repo: Path, value: dict[str, Any]) -> Path:
    document = {"schema_version": SCHEMA_VERSION, **value}
    write_json(binding_path(repo), document)
    return binding_path(repo)


def resolve_bound_python(repo: Path) -> Path | None:
    binding = read_binding(repo)
    if not binding:
        return None
    slot = (update_home() / str(binding["slot"])).resolve()
    engines = (update_home() / "engines").resolve()
    try:
        slot.relative_to(engines)
    except ValueError as exc:
        raise UpdateError(
            "project_binding_invalid", "engine slot escapes PersistMind home"
        ) from exc
    python = python_in_slot(slot)
    ready = slot / "READY"
    if not python.is_file() or not ready.is_file():
        raise UpdateError(
            "engine_slot_missing",
            f"bound engine slot is unavailable: {slot}",
            remediation="Run persistmind update --rollback or reinstall the bootstrap wheel.",
        )
    return python
