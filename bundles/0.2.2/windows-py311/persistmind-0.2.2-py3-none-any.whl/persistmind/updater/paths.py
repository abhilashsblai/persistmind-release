from __future__ import annotations

import os
from pathlib import Path

from persistmind.branding import canonical_user_home, resolve_project_state


def update_home() -> Path:
    return canonical_user_home()


def transaction_control_home() -> Path:
    override = os.environ.get("PERSISTMIND_CONTROL_HOME")
    if override:
        return Path(override).expanduser().resolve() / "transactions"
    product_override = os.environ.get("PERSISTMIND_HOME") or os.environ.get("PERSISTMIND_HOME")
    if product_override:
        return (
            Path(product_override).expanduser().resolve().parent
            / "PersistMindControl"
            / "transactions"
        )
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
    else:
        base = Path(os.environ.get("XDG_STATE_HOME") or Path.home() / ".local" / "state")
    return (base / "persistmind-control" / "transactions").resolve()


def project_root(repo: str | os.PathLike[str]) -> Path:
    path = Path(repo).expanduser().resolve()
    if not path.is_dir():
        raise ValueError(f"project directory does not exist: {path}")
    return path


def binding_path(repo: Path) -> Path:
    return resolve_project_state(repo) / "engine.json"


def python_in_slot(slot: Path) -> Path:
    return slot / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
