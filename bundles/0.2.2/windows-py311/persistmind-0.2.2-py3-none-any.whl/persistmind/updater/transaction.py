from __future__ import annotations

import hashlib
import json
import os
import secrets
import shutil
import sqlite3
import tempfile
from pathlib import Path
from typing import Any

from persistmind.utils import utc_now
from persistmind.registry import ProjectRegistry
from persistmind.branding import PROJECT_STATE_DIR, resolve_project_state

from .atomic import read_json, replace, write_json
from .errors import UpdateError
from .paths import transaction_control_home, update_home


class UpdateTransaction:
    def __init__(self, repo: Path, transaction_id: str | None = None):
        self.repo = repo.resolve()
        self.transaction_id = transaction_id or _new_id()
        self.root = transaction_control_home() / self.transaction_id
        self.path = self.root / "transaction.json"
        self.records = self.root / "records"
        self.document: dict[str, Any] = {
            "schema_version": "persistmind.install_transaction.v2",
            "transaction_id": self.transaction_id,
            "repo": str(self.repo),
            "state": "created",
            "created_at": utc_now(),
            "updated_at": utc_now(),
            "history": [],
        }
        self.root.mkdir(parents=True, exist_ok=False)
        self.records.mkdir()
        self.advance("created")

    def advance(self, state: str, **fields: Any) -> None:
        self.document.update(fields)
        self.document["state"] = state
        self.document["updated_at"] = utc_now()
        self.document.setdefault("history", []).append({"state": state, "at": utc_now()})
        _append_immutable_record(self.records, self.document)
        write_json(self.path, self.document)

    def backup_project(self) -> Path:
        source = resolve_project_state(self.repo)
        if not source.is_dir():
            raise UpdateError(
                "project_preflight_failed",
                f"this repository has no {PROJECT_STATE_DIR} installation",
                remediation="Install PersistMind in the project before running persistmind update.",
            )
        destination = self.root / "project-state"
        _safe_copy_project_state(source, destination)
        manifest = _tree_manifest(destination)
        write_json(self.root / "backup-manifest.json", manifest)
        write_json(
            self.root / "registry-snapshot.json",
            {
                "schema_version": "persistmind.update_registry_snapshot.v1",
                "record": ProjectRegistry().record_for(self.repo),
            },
        )
        self.advance(
            "backed_up",
            backup=str(destination),
            backup_sha256=manifest["sha256"],
            project_state_dir=source.name,
        )
        return destination

    def activate(self, binding: dict[str, Any]) -> None:
        from .binding import write_binding

        write_binding(self.repo, binding)
        self.advance("activated", binding=binding)

    def rollback(self, *, recovery: bool = False) -> None:
        backup = self.root / "project-state"
        manifest = read_json(self.root / "backup-manifest.json")
        if not backup.is_dir() or not manifest or not _backup_verifies(backup, manifest):
            self.advance("rollback_failed", rollback_error="backup verification failed")
            raise UpdateError("rollback_failed", "project-state backup is unavailable or invalid")
        target = self.repo / str(self.document.get("project_state_dir") or ".persistmind")
        failed = self.root / "failed-project-state"
        try:
            # Preserve the failed state as evidence, but never replace the whole
            # live tree. Files may have been created by the user or another
            # process after the backup and are not ours to delete.
            if target.exists() and not failed.exists():
                shutil.copytree(target, failed, symlinks=True)
            target.mkdir(parents=True, exist_ok=True)
            _remove_created_paths(target, self.document.get("created_paths", []))
            preserved_roots = _remove_created_roots(
                target,
                self.document.get("created_roots", []),
            )
            _restore_project_state(backup, target)
            # This is the one candidate-created path declared by protocol v1.
            (target / "updates" / f"{self.transaction_id}.json").unlink(missing_ok=True)
            registry_snapshot = read_json(self.root / "registry-snapshot.json")
            if registry_snapshot:
                ProjectRegistry().restore_record(self.repo, registry_snapshot.get("record"))
        except Exception as exc:
            self.advance("rollback_failed", rollback_error=str(exc))
            raise UpdateError("rollback_failed", f"failed to restore project state: {exc}") from exc
        self.advance(
            "recovered_rolled_back" if recovery else "rolled_back",
            preserved_unjournaled_roots=preserved_roots,
        )

    @classmethod
    def load(cls, root: Path) -> "UpdateTransaction":
        value = _read_authoritative_document(root)
        if not value:
            raise UpdateError("rollback_failed", "update transaction is unreadable")
        instance = object.__new__(cls)
        instance.repo = Path(str(value["repo"])).resolve()
        instance.transaction_id = str(value["transaction_id"])
        instance.root = root
        instance.path = root / "transaction.json"
        instance.records = root / "records"
        instance.document = value
        return instance


def latest_rollback_transaction(repo: Path) -> UpdateTransaction:
    candidates: list[tuple[str, Path]] = []
    for updates in transaction_roots():
        for path in updates.iterdir():
            value = _read_authoritative_document(path, required=False)
            if not value or Path(str(value.get("repo") or "")).resolve() != repo.resolve():
                continue
            if value.get("state") in {
                "committed",
                "post_verified",
                "activated",
                "update_failed",
                "recovered_rolled_back",
            }:
                candidates.append((str(value.get("updated_at") or ""), path))
    if not candidates:
        raise UpdateError(
            "rollback_failed", "no rollback-capable transaction exists for this project"
        )
    return UpdateTransaction.load(max(candidates)[1])


def latest_transaction_status(repo: Path) -> dict[str, Any] | None:
    candidates: list[tuple[str, dict[str, Any]]] = []
    for updates in transaction_roots():
        for path in updates.iterdir():
            value = _read_authoritative_document(path, required=False)
            if value and Path(str(value.get("repo") or "")).resolve() == repo.resolve():
                candidates.append((str(value.get("updated_at") or ""), value))
    return max(candidates, key=lambda item: item[0])[1] if candidates else None


def recover_incomplete_transaction(repo: Path) -> dict[str, Any] | None:
    terminal = {
        "committed",
        "rolled_back",
        "recovered_rolled_back",
        "dry_run_complete",
        "abandoned",
        "aborted_no_change",
    }
    candidates: list[tuple[str, Path, dict[str, Any]]] = []
    for updates in transaction_roots():
        for path in updates.iterdir():
            value = _read_authoritative_document(path, required=False)
            if not value or Path(str(value.get("repo") or "")).resolve() != repo.resolve():
                continue
            if value.get("state") not in terminal:
                candidates.append((str(value.get("updated_at") or ""), path, value))
    if not candidates:
        return None
    _, path, value = max(candidates, key=lambda item: item[0])
    transaction = UpdateTransaction.load(path)
    states = {str(item.get("state")) for item in value.get("history", []) if isinstance(item, dict)}
    if "backed_up" in states:
        transaction.rollback(recovery=True)
        return {"transaction_id": transaction.transaction_id, "status": "rolled_back"}
    transaction.advance("abandoned", recovery_reason="no project mutation had started")
    return {"transaction_id": transaction.transaction_id, "status": "abandoned"}


def transaction_roots() -> list[Path]:
    current = transaction_control_home()
    legacy = update_home() / "updates"
    roots: list[Path] = []
    for root in (current, legacy):
        if root.is_dir() and root not in roots:
            roots.append(root)
    return roots


def _read_authoritative_document(root: Path, *, required: bool = True) -> dict[str, Any] | None:
    records = root / "records"
    if records.is_dir() and any(records.glob("*.json")):
        return _validate_immutable_records(records)[-1]["document"]
    value = read_json(root / "transaction.json")
    if value is None and required:
        raise UpdateError("rollback_failed", "update transaction is unreadable")
    return value


def _append_immutable_record(records: Path, document: dict[str, Any]) -> Path:
    existing = _validate_immutable_records(records) if any(records.glob("*.json")) else []
    sequence = len(existing)
    previous = existing[-1]["record_sha256"] if existing else "0" * 64
    body: dict[str, Any] = {
        "schema_version": "persistmind.install_transaction_record.v2",
        "sequence": sequence,
        "previous_record_sha256": previous,
        "transaction_id": str(document["transaction_id"]),
        "state": str(document["state"]),
        "recorded_at": utc_now(),
        "document": document,
    }
    digest = hashlib.sha256(_canonical_json(body)).hexdigest()
    record = {**body, "record_sha256": digest}
    # The complete digest remains authoritative inside the immutable record.
    # A bounded filename keeps transaction journals usable when Windows test
    # workers or deeply nested repositories consume most of MAX_PATH.
    destination = records / f"{sequence:08d}-{digest[:16]}.json"
    if destination.exists():
        raise UpdateError("transaction_journal_corrupt", "journal sequence already exists")
    descriptor, name = tempfile.mkstemp(prefix=".record-", suffix=".tmp", dir=records)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(_canonical_json(record) + b"\n")
            handle.flush()
            os.fsync(handle.fileno())
        replace(temporary, destination)
        _fsync_directory(records)
    finally:
        temporary.unlink(missing_ok=True)
    return destination


def _validate_immutable_records(records: Path) -> list[dict[str, Any]]:
    paths = sorted(records.glob("*.json"), key=lambda item: item.name)
    values: list[dict[str, Any]] = []
    previous = "0" * 64
    transaction_id: str | None = None
    for expected_sequence, path in enumerate(paths):
        try:
            raw = path.read_bytes()
            value = json.loads(raw.decode("utf-8"))
        except (OSError, UnicodeError, ValueError) as exc:
            raise UpdateError(
                "transaction_journal_corrupt", f"journal record is unreadable: {path.name}"
            ) from exc
        if not isinstance(value, dict):
            raise UpdateError("transaction_journal_corrupt", "journal record is not an object")
        if raw != _canonical_json(value) + b"\n":
            raise UpdateError("transaction_journal_corrupt", "journal record is not canonical")
        digest = value.get("record_sha256")
        unsigned = {key: item for key, item in value.items() if key != "record_sha256"}
        actual = hashlib.sha256(_canonical_json(unsigned)).hexdigest()
        if digest != actual or path.name != f"{expected_sequence:08d}-{actual[:16]}.json":
            raise UpdateError("transaction_journal_corrupt", "journal record hash mismatch")
        if value.get("sequence") != expected_sequence:
            raise UpdateError("transaction_journal_corrupt", "journal sequence is not contiguous")
        if value.get("previous_record_sha256") != previous:
            raise UpdateError("transaction_journal_corrupt", "journal hash chain is broken")
        current_transaction = value.get("transaction_id")
        if transaction_id is None:
            transaction_id = str(current_transaction)
        elif current_transaction != transaction_id:
            raise UpdateError("transaction_journal_corrupt", "journal transaction ID changed")
        document = value.get("document")
        if not isinstance(document, dict) or document.get("transaction_id") != transaction_id:
            raise UpdateError("transaction_journal_corrupt", "journal document is invalid")
        previous = actual
        values.append(value)
    if not values:
        raise UpdateError("transaction_journal_corrupt", "transaction journal is empty")
    return values


def _canonical_json(value: dict[str, Any]) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def _fsync_directory(path: Path) -> None:
    if os.name == "nt":
        # os.open() cannot acquire a flushable directory handle on Windows.
        # Atomic replacement still prevents a torn final record; Windows
        # power-loss durability is release-qualified separately.
        return
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _tree_manifest(root: Path) -> dict[str, Any]:
    digest = hashlib.sha256()
    files = 0
    total = 0
    for path in sorted(
        (
            item
            for item in root.rglob("*")
            if item.is_file() and not _transient_sqlite_sidecar(item)
        ),
        key=lambda item: item.as_posix(),
    ):
        relative = path.relative_to(root).as_posix().encode("utf-8")
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
                total += len(block)
        files += 1
    return {
        "schema_version": "persistmind.update_backup.v1",
        "files": files,
        "bytes": total,
        "sha256": digest.hexdigest(),
    }


def _safe_copy_project_state(source: Path, destination: Path) -> None:
    def ignored(_directory: str, names: list[str]) -> set[str]:
        return {
            name
            for name in names
            if name == "update.lock" or name.endswith("-wal") or name.endswith("-shm")
        }

    shutil.copytree(source, destination, symlinks=True, ignore=ignored)
    for database in source.rglob("*.db"):
        if not database.is_file():
            continue
        with database.open("rb") as handle:
            if handle.read(16) != b"SQLite format 3\x00":
                # Some integrations use the .db suffix for opaque or encrypted
                # state. copytree already captured those byte-for-byte.
                continue
        relative = database.relative_to(source)
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.unlink(missing_ok=True)
        try:
            with sqlite3.connect(f"file:{database.as_posix()}?mode=ro", uri=True) as source_db:
                with sqlite3.connect(target) as target_db:
                    source_db.backup(target_db)
                    result = target_db.execute("PRAGMA integrity_check").fetchone()
                    if not result or result[0] != "ok":
                        raise RuntimeError(f"integrity check failed for {relative}")
        except sqlite3.Error as exc:
            raise UpdateError(
                "project_preflight_failed",
                f"could not create an online backup of {relative}: {exc}",
            ) from exc


def _restore_project_state(backup: Path, target: Path) -> None:
    """Overlay verified backup files without deleting post-backup user state."""
    for source in sorted(backup.rglob("*"), key=lambda item: item.as_posix()):
        relative = source.relative_to(backup)
        destination = target / relative
        if source.is_symlink():
            if destination.exists() or destination.is_symlink():
                destination.unlink()
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.symlink_to(os.readlink(source), target_is_directory=source.is_dir())
        elif source.is_dir():
            destination.mkdir(parents=True, exist_ok=True)
        elif source.is_file():
            destination.parent.mkdir(parents=True, exist_ok=True)
            if source.suffix == ".db" and _is_sqlite_file(source):
                _restore_sqlite_semantic(source, destination)
                continue
            temporary = destination.with_name(f".{destination.name}.rollback-{os.getpid()}")
            shutil.copy2(source, temporary)
            replace(temporary, destination)


def _restore_sqlite_semantic(source: Path, destination: Path) -> None:
    """Restore through SQLite so an existing database path/inode stays live."""

    if destination.exists() and not _is_sqlite_file(destination):
        raise UpdateError(
            "rollback_failed",
            f"refusing to replace non-SQLite database path during recovery: {destination}",
        )
    try:
        with sqlite3.connect(
            f"file:{source.as_posix()}?mode=ro", uri=True, timeout=30
        ) as source_db:
            with sqlite3.connect(destination, timeout=30) as target_db:
                target_db.execute("PRAGMA busy_timeout=30000")
                source_db.backup(target_db)
                result = target_db.execute("PRAGMA integrity_check").fetchone()
                if not result or result[0] != "ok":
                    raise UpdateError(
                        "rollback_failed", f"SQLite recovery integrity failed: {destination}"
                    )
    except sqlite3.Error as exc:
        raise UpdateError(
            "rollback_failed", f"failed semantic SQLite recovery for {destination}: {exc}"
        ) from exc


def _is_sqlite_file(path: Path) -> bool:
    try:
        with path.open("rb") as handle:
            return handle.read(16) == b"SQLite format 3\x00"
    except OSError:
        return False


def _remove_created_paths(target: Path, values: Any) -> None:
    if not isinstance(values, list):
        return
    root = target.resolve()
    paths: list[Path] = []
    for value in values:
        candidate = (root / str(value)).resolve()
        try:
            candidate.relative_to(root)
        except ValueError:
            raise UpdateError("rollback_failed", "candidate mutation path escapes project state")
        paths.append(candidate)
    for path in sorted(paths, key=lambda item: len(item.parts), reverse=True):
        if path.is_symlink() or path.is_file():
            path.unlink(missing_ok=True)
        elif path.is_dir():
            try:
                path.rmdir()
            except OSError:
                # A non-empty directory can contain concurrent/user state; it
                # is preserved while known candidate files are removed.
                pass


def _remove_created_roots(target: Path, values: Any) -> list[str]:
    if not isinstance(values, list):
        return []
    root = target.resolve()
    preserved: list[str] = []
    for value in values:
        candidate = (root / str(value)).resolve()
        try:
            relative = candidate.relative_to(root)
        except ValueError:
            raise UpdateError("rollback_failed", "candidate mutation root escapes project state")
        if len(relative.parts) != 1:
            raise UpdateError("rollback_failed", "candidate mutation root must be top-level")
        if candidate.is_dir():
            try:
                candidate.rmdir()
            except OSError:
                # A root name is not ownership of its descendants. Any entry
                # not separately journaled is preserved for explicit recovery.
                preserved.append(relative.as_posix())
        elif candidate.exists() or candidate.is_symlink():
            candidate.unlink(missing_ok=True)
    return preserved


def _transient_sqlite_sidecar(path: Path) -> bool:
    return path.name.endswith(("-wal", "-shm", "-journal"))


def _backup_verifies(backup: Path, manifest: dict[str, Any]) -> bool:
    actual = _tree_manifest(backup)
    if actual["sha256"] == manifest.get("sha256"):
        return True
    # v1 manifests could race SQLite sidecar removal after backup connections
    # closed. Accept only the narrow legacy shape and independently verify all
    # retained SQLite images before recovery.
    missing_files = int(manifest.get("files", 0)) - int(actual["files"])
    missing_bytes = int(manifest.get("bytes", 0)) - int(actual["bytes"])
    if not (0 < missing_files <= 3 and 0 <= missing_bytes <= 64 * 1024 * 1024):
        return False
    for database in backup.rglob("*.db"):
        try:
            with sqlite3.connect(f"file:{database.as_posix()}?mode=ro", uri=True) as connection:
                result = connection.execute("PRAGMA integrity_check").fetchone()
        except sqlite3.Error:
            return False
        if not result or result[0] != "ok":
            return False
    return True


def _new_id() -> str:
    return f"upd-{utc_now().replace(':', '').replace('-', '')}-{secrets.token_hex(6)}"
