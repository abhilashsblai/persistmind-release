from __future__ import annotations

import json
import os
import secrets
import time
from pathlib import Path
from types import TracebackType
from typing import Any

from .errors import UpdateError


class UpdateLock:
    def __init__(self, path: Path, *, stale_after: float = 3600.0):
        self.path = path
        self.stale_after = stale_after
        self.acquired = False
        self.owner_nonce = secrets.token_hex(16)

    def __enter__(self) -> "UpdateLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        for _ in range(2):
            try:
                fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            except FileExistsError:
                if self._stale():
                    self.path.unlink(missing_ok=True)
                    continue
                detail = self._detail()
                raise UpdateError(
                    "update_lock_busy", f"another PersistMind update is active{detail}"
                )
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(
                    {
                        "pid": os.getpid(),
                        "started_at": time.time(),
                        "owner_nonce": self.owner_nonce,
                    },
                    handle,
                )
                handle.flush()
                os.fsync(handle.fileno())
            self.acquired = True
            return self
        raise UpdateError("update_lock_busy", "unable to acquire PersistMind update lock")

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        if self.acquired:
            if self._document().get("owner_nonce") == self.owner_nonce:
                self.path.unlink(missing_ok=True)
            self.acquired = False

    def _document(self) -> dict[str, Any]:
        try:
            value = json.loads(self.path.read_text(encoding="utf-8"))
            return value if isinstance(value, dict) else {}
        except (OSError, json.JSONDecodeError):
            return {}

    def _stale(self) -> bool:
        value = self._document()
        started = float(value.get("started_at") or 0)
        pid = int(value.get("pid") or 0)
        return time.time() - started > self.stale_after and not _pid_alive(pid)

    def _detail(self) -> str:
        value = self._document()
        return f" (pid={value.get('pid')}, started_at={value.get('started_at')})" if value else ""


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True
