from __future__ import annotations

import hashlib
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from packaging.version import Version

from persistmind import __version__
from persistmind.release_identity import (
    TRUSTED_MANIFEST_NAME,
    TRUSTED_MANIFEST_SIGNATURE_NAME,
)
from persistmind.registry import ProjectRegistry
from persistmind.utils import utc_now
from persistmind.branding import (
    PROJECT_STATE_DIR,
    migrate_user_home,
    resolve_project_state,
)

from .atomic import read_json
from .binding import read_binding
from .errors import UpdateError
from .lock import UpdateLock
from .paths import python_in_slot, transaction_control_home, update_home
from .release import DriveReleaseClient, _manifest_wheel
from .slots import EngineSlotManager, install_profile
from .transaction import (
    UpdateTransaction,
    latest_rollback_transaction,
    latest_transaction_status,
    recover_incomplete_transaction,
    transaction_roots,
)

RESTART_REQUIRED = ["externally_owned_ide_or_mcp_sessions"]


def run_update(
    repo: Path,
    *,
    action: str = "apply",
    channel: str | None = None,
    exact_version: str | None = None,
    dry_run: bool = False,
    force: bool = False,
) -> dict[str, Any]:
    repo = repo.resolve()
    if action == "status":
        return _status(repo)
    if action == "rollback":
        return _rollback(repo)
    binding = read_binding(repo)
    current = str(binding.get("version")) if binding else __version__
    selected_channel = channel or (str(binding.get("channel")) if binding else None)
    selected_channel = selected_channel or (
        "preview" if Version(current).is_prerelease else "stable"
    )
    migrate_user_home()
    home = update_home()
    with UpdateLock(home / "update.lock"), UpdateLock(_project_lock(home, repo)):
        recover_incomplete_transaction(repo)
        brand_migrated = False
        client = DriveReleaseClient()
        resolved = client.resolve(channel=selected_channel, exact_version=exact_version)
        minimum_bootstrap = Version(str(resolved.manifest["min_bootstrap_version"]))
        if Version(__version__) < minimum_bootstrap:
            raise UpdateError(
                "bootstrap_upgrade_required",
                f"release requires bootstrap {minimum_bootstrap} or newer",
                remediation="Install the latest bootstrap wheel once, then rerun persistmind update.",
            )
        project_protocol = int(resolved.manifest["project_state_protocol"])
        if project_protocol not in {1, 2}:
            raise UpdateError(
                "release_metadata_invalid",
                "release uses an unsupported project-state protocol",
            )
        candidate = Version(resolved.version)
        installed = Version(current)
        project_upgrade_needed = brand_migrated or _project_upgrade_needed(repo)
        if candidate == installed and not force and not project_upgrade_needed:
            return _result(
                repo,
                status="already_current",
                from_version=current,
                to_version=resolved.version,
                channel=resolved.channel,
                release_tag=str(resolved.manifest["release_tag"]),
                wheel_sha256=str(_manifest_wheel(resolved.manifest)["sha256"]),
            )
        if candidate < installed and not force:
            raise UpdateError(
                "release_metadata_invalid",
                f"refusing downgrade from {installed} to {candidate}",
                remediation="Use --version with --force or persistmind update --rollback.",
            )
        artifact = _manifest_wheel(resolved.manifest)
        digest = str(artifact["sha256"])
        if action == "check":
            return _result(
                repo,
                status=(
                    "project_upgrade_required"
                    if candidate == installed and project_upgrade_needed
                    else "update_available"
                ),
                from_version=current,
                to_version=resolved.version,
                channel=resolved.channel,
                release_tag=str(resolved.manifest["release_tag"]),
                wheel_sha256=digest,
            )
        wheelhouse = None
        if resolved.manifest.get("dependency_lock"):
            bundle_digest = str(resolved.manifest["dependency_lock"]["sha256"])
            wheelhouse = home / "downloads" / f"bundle-{bundle_digest}"
            client.download_wheelhouse(resolved, wheelhouse)
            wheel = wheelhouse / str(artifact["filename"])
        else:
            wheel = home / "downloads" / f"{digest}.whl"
            if not wheel.is_file():
                client.download_wheel(resolved, wheel)
            else:
                # A content-addressed cache is still revalidated by the normal download verifier.
                if hashlib.sha256(wheel.read_bytes()).hexdigest() != digest:
                    wheel.unlink()
                    client.download_wheel(resolved, wheel)
        slots = EngineSlotManager(home)
        slot = slots.ensure(
            version=resolved.version,
            digest=digest,
            wheel=wheel,
            wheelhouse=wheelhouse,
            wheel_filename=str(artifact["filename"]),
            profile=install_profile(home),
        )
        _activate_trusted_release(slot, resolved)
        preflight = _candidate_project_preflight(slot, repo)
        if dry_run:
            return _result(
                repo,
                status="dry_run_complete",
                from_version=current,
                to_version=resolved.version,
                channel=resolved.channel,
                release_tag=str(resolved.manifest["release_tag"]),
                wheel_sha256=digest,
            )
        transaction = UpdateTransaction(repo)
        transaction.advance(
            "verified",
            from_version=current,
            to_version=resolved.version,
            channel=resolved.channel,
            release_tag=resolved.manifest["release_tag"],
            wheel_sha256=digest,
        )
        transaction.advance(
            "slot_ready",
            slot=slots.relative_slot(slot),
            created_roots=preflight.get("created_roots", []),
        )
        transaction.backup_project()
        try:
            application = _candidate_project_upgrade(
                slot, repo, transaction.transaction_id, project_protocol
            )
            transaction.advance(
                "applied",
                created_paths=application.get("created_paths", []),
                index=application.get("index"),
            )
            binding_value = {
                "version": resolved.version,
                "channel": resolved.channel,
                "wheel_sha256": digest,
                "python_tag": f"{sys.implementation.name}{sys.version_info.major}{sys.version_info.minor}",
                "slot": slots.relative_slot(slot),
                "activated_at": utc_now(),
                "transaction_id": transaction.transaction_id,
            }
            transaction.activate(binding_value)
            _post_cutover_verify(slot, repo, resolved.version)
            ProjectRegistry().register(
                repo,
                label=repo.name,
                engine_version=resolved.version,
                action="update",
                channel=resolved.channel,
                wheel_sha256=digest,
                slot=slots.relative_slot(slot),
                release_tag=str(resolved.manifest["release_tag"]),
                transaction_id=transaction.transaction_id,
                bootstrap_version=__version__,
                restart_required=RESTART_REQUIRED,
            )
            surface_refresh = _candidate_surface_refresh(slot, repo)
            transaction.advance("post_verified", surface_refresh=surface_refresh)
            transaction.advance("committed")
            slots.garbage_collect(referenced=_referenced_slots(home))
        except Exception as exc:
            transaction.advance("update_failed", error=str(exc))
            transaction.rollback()
            if isinstance(exc, UpdateError):
                raise
            raise UpdateError("project_upgrade_failed", str(exc)) from exc
        return _result(
            repo,
            status="updated",
            from_version=current,
            to_version=resolved.version,
            channel=resolved.channel,
            release_tag=str(resolved.manifest["release_tag"]),
            wheel_sha256=digest,
            slot=slots.relative_slot(slot),
            transaction_id=transaction.transaction_id,
            project_binding=f"{PROJECT_STATE_DIR}/engine.json",
            restart_required=RESTART_REQUIRED,
            index=application.get("index"),
            surface_refresh=surface_refresh,
        )


def _activate_trusted_release(slot: Path, resolved: Any) -> None:
    if resolved.manifest.get("schema_version") != "persistmind.update_manifest.v4":
        return
    if not resolved.manifest_signature:
        raise UpdateError(
            "artifact_verification_failed",
            "trusted Windows release activation lacks the verified manifest signature",
        )
    destination = slot / "share" / "persistmind"
    destination.mkdir(parents=True, exist_ok=True)
    for name, content in (
        (TRUSTED_MANIFEST_NAME, resolved.manifest_bytes),
        (TRUSTED_MANIFEST_SIGNATURE_NAME, resolved.manifest_signature),
    ):
        target = destination / name
        temporary = target.with_suffix(target.suffix + ".tmp")
        temporary.write_bytes(content)
        os.replace(temporary, target)


def _candidate_project_upgrade(
    slot: Path, repo: Path, transaction_id: str, target_protocol: int = 1
) -> dict[str, Any]:
    # Until the versioned project-upgrade protocol can declare and back up all
    # generated surfaces, the update phase is deliberately read-only. Running
    # `setup` here could modify hooks and agent files outside .persistmind without
    # a rollback inventory.
    _candidate_project_preflight(slot, repo)
    python = python_in_slot(slot)
    env = os.environ.copy()
    env["PERSISTMIND_ENGINE_ACTIVE"] = "1"
    env["PERSISTMIND_TARGET_PROJECT_PROTOCOL"] = str(target_protocol)
    env["PERSISTMIND_PROTOCOL_BACKUP_ROOT"] = str(
        transaction_control_home() / transaction_id / "protocol"
    )
    application: dict[str, Any] = {}
    for action in ("apply", "verify"):
        result = _run_candidate(
            [
                str(python),
                "-I",
                "-m",
                "persistmind",
                "--repo",
                str(repo),
                "internal",
                "project-upgrade",
                action,
                "--transaction",
                transaction_id,
            ],
            env=env,
            status="project_upgrade_failed",
            timeout=3600,
        )
        if action == "apply":
            try:
                import json

                application = json.loads(result.stdout)
            except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                raise UpdateError(
                    "project_upgrade_failed", "candidate apply returned invalid JSON"
                ) from exc
    return application


def _candidate_project_preflight(slot: Path, repo: Path) -> dict[str, Any]:
    python = python_in_slot(slot)
    env = os.environ.copy()
    env["PERSISTMIND_ENGINE_ACTIVE"] = "1"
    planned = _run_candidate(
        [
            str(python),
            "-I",
            "-m",
            "persistmind",
            "--repo",
            str(repo),
            "internal",
            "project-upgrade",
            "plan",
        ],
        env=env,
        status="project_preflight_failed",
        timeout=120,
    )
    try:
        import json

        plan = json.loads(planned.stdout)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise UpdateError(
            "project_preflight_failed", "candidate plan returned invalid JSON"
        ) from exc
    _run_candidate(
        [str(python), "-I", "-m", "persistmind", "--repo", str(repo), "config", "validate"],
        env=env,
        status="project_preflight_failed",
        timeout=120,
    )
    return plan


def _post_cutover_verify(slot: Path, repo: Path, version: str) -> None:
    python = python_in_slot(slot)
    env = os.environ.copy()
    env["PERSISTMIND_ENGINE_ACTIVE"] = "1"
    result = _run_candidate(
        [str(python), "-I", "-c", "import persistmind; print(persistmind.__version__)"],
        env=env,
        status="post_cutover_verification_failed",
        timeout=60,
    )
    if result.stdout.strip() != version:
        raise UpdateError(
            "post_cutover_verification_failed", "activated engine reports the wrong version"
        )
    # Prove that the stable bootstrap observes the newly written binding and
    # dispatches a fresh process into the selected slot.
    bootstrap_env = os.environ.copy()
    bootstrap_env.pop("PERSISTMIND_ENGINE_ACTIVE", None)
    stable = _run_candidate(
        [str(sys.executable), "-m", "persistmind", "--repo", str(repo), "version"],
        env=bootstrap_env,
        status="post_cutover_verification_failed",
        timeout=60,
    )
    try:
        import json

        stable_value = json.loads(stable.stdout)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise UpdateError(
            "post_cutover_verification_failed", "stable launcher returned invalid version output"
        ) from exc
    if str(stable_value.get("version")) != version:
        raise UpdateError(
            "post_cutover_verification_failed",
            "stable launcher did not select the candidate engine",
        )
    _run_candidate(
        [str(sys.executable), "-m", "persistmind", "--repo", str(repo), "doctor"],
        env=bootstrap_env,
        status="post_cutover_verification_failed",
        timeout=300,
    )


def _candidate_surface_refresh(slot: Path, repo: Path) -> dict[str, Any] | None:
    profile = _setup_profile(repo)
    if not profile or not profile.get("agents"):
        return None
    python = python_in_slot(slot)
    command = [
        str(python),
        "-I",
        "-m",
        "persistmind",
        "--repo",
        str(repo),
        "install",
        "--agents",
        ",".join(str(item) for item in profile["agents"]),
        "--skip-index",
    ]
    if not bool(profile.get("install_hooks", False)):
        command.append("--no-install-hooks")
    if not bool(profile.get("configure_mcp", False)):
        command.append("--no-configure-mcp")
    if not bool(profile.get("absolute_mcp_repo", False)):
        command.append("--no-absolute-mcp-repo")
    runtime = profile.get("runtime_invocation")
    if isinstance(runtime, dict) and runtime.get("executable"):
        command.extend(["--runtime-executable", str(runtime["executable"])])
        for item in runtime.get("prefix_args") or []:
            command.extend(["--runtime-prefix-arg", str(item)])
        if runtime.get("source"):
            command.extend(["--runtime-source", str(runtime["source"])])
    elif profile.get("mcp_command"):
        command.extend(["--mcp-command", str(profile["mcp_command"])])
    if profile.get("codex_config"):
        command.extend(["--codex-config", str(profile["codex_config"])])
    env = os.environ.copy()
    env["PERSISTMIND_ENGINE_ACTIVE"] = "1"
    result = _run_candidate(
        command,
        env=env,
        status="project_surface_refresh_failed",
        timeout=600,
    )
    try:
        import json

        value = json.loads(result.stdout)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise UpdateError(
            "project_surface_refresh_failed",
            "candidate install returned invalid surface-refresh output",
        ) from exc
    if not isinstance(value, dict) or not value.get("ok"):
        raise UpdateError(
            "project_surface_refresh_failed", "candidate surface refresh did not succeed"
        )
    return {
        "status": value.get("status"),
        "agents": value.get("agents"),
        "installation_manifest": value.get("installation_manifest"),
        "backup_root": value.get("backup_root"),
    }


def _rollback(repo: Path) -> dict[str, Any]:
    home = update_home()
    with UpdateLock(home / "update.lock"), UpdateLock(_project_lock(home, repo)):
        transaction = latest_rollback_transaction(repo)
        current = read_binding(repo)
        transaction.rollback()
        restored = read_binding(repo)
        version = str(restored.get("version")) if restored else __version__
        ProjectRegistry().register(repo, engine_version=version, action="rollback")
        return _result(
            repo,
            status="rolled_back",
            from_version=str(current.get("version")) if current else __version__,
            to_version=version,
            transaction_id=transaction.transaction_id,
        )


def _status(repo: Path) -> dict[str, Any]:
    binding = read_binding(repo)
    return {
        "ok": True,
        "status": "bound" if binding else "bootstrap_fallback",
        "schema_version": "persistmind.update_status.v1",
        "repo": str(repo),
        "bootstrap_version": __version__,
        "binding": binding,
        "latest_transaction": latest_transaction_status(repo),
    }


def _setup_profile(repo: Path) -> dict[str, Any] | None:
    value = read_json(resolve_project_state(repo) / "setup-profile.json")
    if value and isinstance(value.get("agents"), list):
        return value
    agents: list[str] = []
    if (repo / ".codex").exists():
        agents.append("codex")
    if (repo / ".claude").exists():
        agents.append("claude")
    if (repo / ".gemini").exists():
        agents.append("gemini")
    if (repo / ".grok").exists():
        agents.append("grok")
    return {"agents": agents} if agents else None


def _run_candidate(
    command: list[str], *, env: dict[str, str], status: str, timeout: float
) -> subprocess.CompletedProcess[str]:
    try:
        result = subprocess.run(
            command,
            env=env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise UpdateError(status, f"candidate command failed: {exc}") from exc
    if result.returncode:
        detail = (result.stderr or result.stdout).strip()[-3000:]
        raise UpdateError(status, detail or f"candidate exited with {result.returncode}")
    return result


def _result(repo: Path, *, status: str, **fields: Any) -> dict[str, Any]:
    return {
        "ok": True,
        "status": status,
        "schema_version": "persistmind.update_result.v1",
        "repo": str(repo),
        **fields,
    }


def _project_lock(home: Path, repo: Path) -> Path:
    digest = hashlib.sha256(str(repo.resolve()).casefold().encode("utf-8")).hexdigest()
    return home / "locks" / f"project-{digest}.lock"


def _project_upgrade_needed(repo: Path) -> bool:
    state = resolve_project_state(repo)
    return (state / "workspace.db").is_file() and not (state / "catalog" / "current.json").is_file()


def _referenced_slots(home: Path) -> set[str]:
    referenced = {
        str(record["slot"]) for record in ProjectRegistry(home).list() if record.get("slot")
    }
    for updates in transaction_roots():
        for path in updates.iterdir():
            value = read_json(path / "transaction.json")
            if not value:
                continue
            prior = read_json(path / "project-state" / "engine.json")
            if prior and prior.get("slot"):
                referenced.add(str(prior["slot"]))
            if value.get("state") in {
                "committed",
                "rolled_back",
                "recovered_rolled_back",
                "abandoned",
                "aborted_no_change",
            }:
                continue
            if value.get("slot"):
                referenced.add(str(value["slot"]))
            binding = value.get("binding")
            if isinstance(binding, dict) and binding.get("slot"):
                referenced.add(str(binding["slot"]))
    return referenced
