from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from .binding import resolve_bound_python


def maybe_dispatch(argv: list[str]) -> int | None:
    """Run a normal command in the project's bound immutable engine slot."""
    if os.environ.get("PERSISTMIND_ENGINE_ACTIVE") == "1":
        return None
    command = _command(argv)
    if command in {None, "update"}:
        return None
    repo = _repo(argv)
    python = resolve_bound_python(repo)
    if python is None or Path(sys.executable).resolve() == python.resolve():
        return None
    env = os.environ.copy()
    env["PERSISTMIND_ENGINE_ACTIVE"] = "1"
    result = subprocess.run([str(python), "-I", "-m", "persistmind", *argv], env=env)
    return int(result.returncode)


def _repo(argv: list[str]) -> Path:
    try:
        idx = argv.index("--repo")
        return Path(argv[idx + 1]).expanduser().resolve()
    except (ValueError, IndexError):
        return Path.cwd().resolve()


def _command(argv: list[str]) -> str | None:
    skip = False
    for value in argv:
        if skip:
            skip = False
            continue
        if value == "--repo":
            skip = True
            continue
        if value.startswith("-"):
            continue
        return value
    return None
