from __future__ import annotations


class UpdateError(RuntimeError):
    """A typed update failure that is safe to expose through the CLI."""

    def __init__(self, status: str, message: str, *, remediation: str | None = None):
        super().__init__(message)
        self.status = status
        self.remediation = remediation
