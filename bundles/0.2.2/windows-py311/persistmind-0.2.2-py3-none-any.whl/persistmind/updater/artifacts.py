from __future__ import annotations

import hashlib
import os
import re
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, BinaryIO, Mapping, Protocol

from persistmind.storage.local_path import require_local_live_state_path

from .atomic import replace
from .errors import UpdateError


MAX_ARTIFACT_BYTES = 2 * 1024 * 1024 * 1024
_DRIVE_HOSTS = frozenset(
    {
        "drive.google.com",
        "drive.usercontent.google.com",
        "docs.googleusercontent.com",
    }
)


@dataclass(frozen=True, slots=True)
class ArtifactReference:
    filename: str
    size: int
    sha256: str
    media_type: str
    transport: str
    transport_record: Mapping[str, Any]

    @classmethod
    def from_manifest(cls, artifact: Mapping[str, Any]) -> "ArtifactReference":
        filename = str(artifact.get("filename") or "")
        digest = str(artifact.get("sha256") or "")
        size = int(artifact.get("size") or 0)
        media_type = str(artifact.get("media_type") or "application/octet-stream")
        transport = artifact.get("transport")
        if Path(filename).name != filename or not filename:
            raise UpdateError("release_metadata_invalid", "artifact filename is unsafe")
        if size <= 0 or size > MAX_ARTIFACT_BYTES or not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise UpdateError("release_metadata_invalid", "artifact size or digest is invalid")
        if not isinstance(transport, Mapping):
            raise UpdateError(
                "release_metadata_invalid", "Drive manifest artifact transport is absent"
            )
        kind = str(transport.get("kind") or "")
        if kind != "google_drive":
            raise UpdateError("release_metadata_invalid", f"unsupported artifact transport: {kind}")
        return cls(filename, size, digest, media_type, kind, dict(transport))


class ArtifactFetcher(Protocol):
    def fetch(self, reference: ArtifactReference, destination: Path) -> Path: ...


class ArtifactResolver:
    def __init__(self, fetchers: Mapping[str, ArtifactFetcher] | None = None) -> None:
        self.fetchers = dict(fetchers or {"google_drive": DriveArtifactFetcher()})

    def fetch(self, artifact: Mapping[str, Any], destination: Path) -> Path:
        reference = ArtifactReference.from_manifest(artifact)
        fetcher = self.fetchers.get(reference.transport)
        if fetcher is None:
            raise UpdateError(
                "download_failed", f"artifact transport unavailable: {reference.transport}"
            )
        require_local_live_state_path(destination.parent)
        target = fetcher.fetch(reference, destination)
        if target.resolve() != destination.resolve() or not target.is_file():
            raise UpdateError(
                "artifact_verification_failed", "artifact fetcher returned an invalid path"
            )
        if target.stat().st_size != reference.size or _sha256(target) != reference.sha256:
            target.unlink(missing_ok=True)
            raise UpdateError("artifact_verification_failed", "artifact size or SHA-256 mismatch")
        return target


class DriveArtifactFetcher:
    def __init__(self, *, timeout: float = 60.0) -> None:
        self.timeout = timeout

    def fetch(self, reference: ArtifactReference, destination: Path) -> Path:
        record = reference.transport_record
        file_id = str(record.get("file_id") or "")
        url = str(record.get("url") or "")
        allowed = tuple(str(item).casefold() for item in record.get("allowed_redirect_hosts") or ())
        if not re.fullmatch(r"[A-Za-z0-9_-]{10,200}", file_id):
            raise UpdateError("release_metadata_invalid", "Drive file ID is invalid")
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme != "https" or parsed.hostname not in _DRIVE_HOSTS:
            raise UpdateError("release_metadata_invalid", "Drive artifact origin is not trusted")
        if file_id not in urllib.parse.unquote(url):
            raise UpdateError(
                "release_metadata_invalid", "Drive URL is not bound to its immutable file ID"
            )
        if not allowed or any(host not in _DRIVE_HOSTS for host in allowed):
            raise UpdateError("release_metadata_invalid", "Drive redirect host policy is invalid")
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_suffix(destination.suffix + ".part")
        temporary.unlink(missing_ok=True)
        opener = _drive_opener(frozenset(allowed))
        request = urllib.request.Request(url, headers={"User-Agent": "persistmind-updater/3"})
        try:
            with (
                opener.open(request, timeout=self.timeout) as response,
                temporary.open("wb") as output,
            ):
                final = urllib.parse.urlparse(response.geturl())
                if final.scheme != "https" or final.hostname not in allowed:
                    raise UpdateError(
                        "download_failed", "Drive response escaped the signed host policy"
                    )
                content_type = str(response.headers.get_content_type()).casefold()
                if content_type != reference.media_type.casefold():
                    raise UpdateError(
                        "artifact_verification_failed",
                        f"Drive media type mismatch: expected {reference.media_type}, got {content_type}",
                    )
                _copy_bounded(response, output, reference.size)
                output.flush()
                os.fsync(output.fileno())
            replace(temporary, destination)
        except UpdateError:
            raise
        except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, OSError) as exc:
            raise UpdateError("download_failed", f"Drive artifact download failed: {exc}") from exc
        finally:
            temporary.unlink(missing_ok=True)
        return destination


def _drive_opener(allowed_hosts: frozenset[str]) -> urllib.request.OpenerDirector:
    class SignedDriveRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[no-untyped-def]
            parsed = urllib.parse.urlparse(newurl)
            if parsed.scheme != "https" or parsed.hostname not in allowed_hosts:
                raise UpdateError(
                    "download_failed", "Drive redirect escaped the signed host policy"
                )
            return super().redirect_request(req, fp, code, msg, headers, newurl)

    return urllib.request.build_opener(SignedDriveRedirect())


def _copy_bounded(source: BinaryIO, destination: BinaryIO, expected_size: int) -> None:
    copied = 0
    while True:
        block = source.read(min(1024 * 1024, expected_size + 1 - copied))
        if not block:
            break
        copied += len(block)
        if copied > expected_size:
            raise UpdateError("artifact_verification_failed", "Drive artifact exceeds signed size")
        destination.write(block)
    if copied != expected_size:
        raise UpdateError(
            "artifact_verification_failed",
            f"Drive artifact is truncated: expected {expected_size}, got {copied}",
        )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


__all__ = [
    "ArtifactFetcher",
    "ArtifactReference",
    "ArtifactResolver",
    "DriveArtifactFetcher",
    "MAX_ARTIFACT_BYTES",
]
