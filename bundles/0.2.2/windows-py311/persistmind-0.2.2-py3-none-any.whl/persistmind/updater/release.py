from __future__ import annotations

import base64
import hashlib
import importlib.metadata
import json
import os
import sys
import platform
import re
import shutil
import subprocess
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from packaging.specifiers import SpecifierSet
from packaging.tags import sys_tags
from packaging.utils import parse_wheel_filename

from .atomic import replace
from packaging.version import InvalidVersion, Version

from persistmind.branding import (
    PYTHON_DISTRIBUTION,
    PRODUCT_ID,
    RELEASE_DRIVE_FOLDER_ID,
    RELEASE_REPOSITORY,
    SOURCE_REPOSITORY,
    UPDATE_MANIFEST_SCHEMA,
    UPDATE_MANIFEST_V3_SCHEMA,
    UPDATE_MANIFEST_V4_SCHEMA,
)

from .errors import UpdateError
from .artifacts import ArtifactReference, ArtifactResolver, _DRIVE_HOSTS, _drive_opener


def _installed_release_repository() -> str:
    try:
        importlib.metadata.version(PYTHON_DISTRIBUTION)
    except importlib.metadata.PackageNotFoundError:
        return RELEASE_REPOSITORY
    return RELEASE_REPOSITORY


REPOSITORY = _installed_release_repository()
TRUSTED_REPOSITORIES = (RELEASE_REPOSITORY,)
API_ROOT = "https://api.github.com"
MANIFEST_NAME = "persistmind-update-manifest.v4.json"
V3_MANIFEST_NAME = "persistmind-update-manifest.v3.json"
V2_MANIFEST_NAME = "persistmind-update-manifest.v2.json"
V1_MANIFEST_NAME = "persistmind-update-manifest.v1.json"
MANIFEST_NAMES = (MANIFEST_NAME, V3_MANIFEST_NAME, V2_MANIFEST_NAME, V1_MANIFEST_NAME)
MANIFEST_SCHEMAS = (
    UPDATE_MANIFEST_V4_SCHEMA,
    UPDATE_MANIFEST_V3_SCHEMA,
    UPDATE_MANIFEST_SCHEMA,
    "persistmind.update_manifest.v1",
)
MAX_METADATA_BYTES = 1_000_000
MAX_WHEEL_BYTES = 250_000_000

# Release-key policy v1. Rotate additively and retain an offline recovery key.
# The corresponding online private key is held only by the protected release
# environment as PERSISTMIND_UPDATE_SIGNING_KEY_B64.
UPDATE_ROOT_KEYS = (
    "2zTxhUn/x3MO0ju5mXYuEmbJfAGWj6BE9nWkgBb43do=",
    "kuh85P8eq5Qp1S4kIUJ2LoUfxZX+TbEstEaKgJtlV4A=",
)


@dataclass(frozen=True)
class ResolvedRelease:
    release: dict[str, Any]
    manifest: dict[str, Any]
    manifest_bytes: bytes
    wheel_asset: dict[str, Any]
    uploaded_assets: dict[str, dict[str, Any]] = field(default_factory=dict)
    manifest_signature: bytes = b""

    @property
    def version(self) -> str:
        return str(self.manifest["version"])

    @property
    def channel(self) -> str:
        return str(self.manifest["channel"])


class GitHubReleaseClient:
    def __init__(
        self,
        *,
        repository: str = REPOSITORY,
        api_root: str = API_ROOT,
        token: str | None = None,
        timeout: float = 30.0,
    ):
        self.repository = repository
        self.api_root = api_root.rstrip("/")
        self.timeout = timeout
        self.token = token if token is not None else _github_token()

    def resolve(self, *, channel: str, exact_version: str | None = None) -> ResolvedRelease:
        if exact_version:
            try:
                wanted = Version(exact_version)
            except InvalidVersion as exc:
                raise UpdateError(
                    "release_metadata_invalid", f"invalid version: {exact_version}"
                ) from exc
            release = self._json(
                f"/repos/{self.repository}/releases/tags/{urllib.parse.quote('v' + str(wanted), safe='')}"
            )
        elif channel in {"stable", "preview"}:
            values = self._json(f"/repos/{self.repository}/releases?per_page=100")
            if not isinstance(values, list):
                raise UpdateError("release_metadata_invalid", "GitHub release list is not an array")
            candidates: list[tuple[Version, dict[str, Any]]] = []
            for value in values:
                if not isinstance(value, dict) or value.get("draft"):
                    continue
                tag = str(value.get("tag_name") or "")
                if not tag.startswith("v"):
                    continue
                try:
                    version = Version(tag[1:])
                except InvalidVersion:
                    continue
                channel_matches = (
                    version.is_prerelease and bool(value.get("prerelease"))
                    if channel == "preview"
                    else not version.is_prerelease and not bool(value.get("prerelease"))
                )
                if channel_matches:
                    candidates.append((version, value))
            if not candidates:
                raise UpdateError(
                    "release_unavailable", f"no published {channel} release is available"
                )
            failures: list[str] = []
            for _, candidate in sorted(candidates, key=lambda item: item[0], reverse=True):
                try:
                    resolved = self._resolve_assets(
                        candidate, requested_channel=channel, exact_version=None
                    )
                except UpdateError as exc:
                    failures.append(str(exc))
                    continue
                if _manifest_is_qualified(resolved.manifest):
                    return resolved
            raise UpdateError(
                "release_unavailable",
                "no promoted qualified release is available; " + "; ".join(failures[:3]),
            )
        else:
            raise UpdateError("release_metadata_invalid", f"unsupported update channel: {channel}")
        if not isinstance(release, dict) or release.get("draft"):
            raise UpdateError("release_unavailable", "release is unavailable or still a draft")
        resolved = self._resolve_assets(
            release, requested_channel=channel, exact_version=exact_version
        )
        if not _manifest_is_qualified(resolved.manifest):
            raise UpdateError(
                "release_unqualified",
                "release exists but has not been promoted with qualification evidence",
            )
        return resolved

    def download_wheel(self, resolved: ResolvedRelease, destination: Path) -> Path:
        artifact = _manifest_wheel(resolved.manifest)
        expected_size = int(artifact["size"])
        if expected_size <= 0 or expected_size > MAX_WHEEL_BYTES:
            raise UpdateError("release_metadata_invalid", "wheel size exceeds update policy")
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_suffix(destination.suffix + ".part")
        temporary.unlink(missing_ok=True)
        if resolved.manifest.get("schema_version") in {
            UPDATE_MANIFEST_V3_SCHEMA,
            UPDATE_MANIFEST_V4_SCHEMA,
        }:
            ArtifactResolver().fetch(artifact, destination)
            _verify_wheel_identity(destination, resolved.manifest)
            return destination
        try:
            self._download(
                str(resolved.wheel_asset["browser_download_url"]), temporary, MAX_WHEEL_BYTES
            )
            actual_size = temporary.stat().st_size
            if actual_size != expected_size:
                raise UpdateError(
                    "artifact_verification_failed",
                    f"wheel size mismatch: expected {expected_size}, got {actual_size}",
                )
            digest = _sha256(temporary)
            if digest != str(artifact["sha256"]):
                raise UpdateError("artifact_verification_failed", "wheel SHA-256 mismatch")
            github_digest = str(resolved.wheel_asset.get("digest") or "")
            if github_digest and github_digest != f"sha256:{digest}":
                raise UpdateError("artifact_verification_failed", "GitHub asset digest mismatch")
            _verify_wheel_identity(temporary, resolved.manifest)
            replace(temporary, destination)
        finally:
            temporary.unlink(missing_ok=True)
        return destination

    def download_wheelhouse(self, resolved: ResolvedRelease, destination: Path) -> Path:
        artifacts = [
            item
            for item in resolved.manifest.get("artifacts", [])
            if isinstance(item, dict) and str(item.get("filename", "")).endswith(".whl")
        ]
        if not artifacts:
            raise UpdateError("release_metadata_invalid", "release has no dependency wheelhouse")
        destination.mkdir(parents=True, exist_ok=True)
        if resolved.manifest.get("schema_version") in {
            UPDATE_MANIFEST_V3_SCHEMA,
            UPDATE_MANIFEST_V4_SCHEMA,
        }:
            resolver = ArtifactResolver()
            for artifact in artifacts:
                resolver.fetch(artifact, destination / str(artifact["filename"]))
            for key in ("dependency_lock", "sbom"):
                binding = resolved.manifest.get(key)
                if not isinstance(binding, dict):
                    raise UpdateError(
                        "release_metadata_invalid", f"release {key} binding is absent"
                    )
                resolver.fetch(binding, destination / str(binding["filename"]))
            _verify_dependency_lock(destination, resolved.manifest)
            return destination
        for artifact in artifacts:
            name = str(artifact.get("filename", ""))
            if Path(name).name != name:
                raise UpdateError("release_metadata_invalid", "wheelhouse filename is unsafe")
            asset = resolved.uploaded_assets.get(name)
            if not asset or int(asset.get("size", -1)) != int(artifact.get("size", 0)):
                raise UpdateError(
                    "artifact_verification_failed", "wheelhouse asset binding differs"
                )
            target = destination / name
            self._download(str(asset["browser_download_url"]), target, MAX_WHEEL_BYTES)
            if target.stat().st_size != int(artifact["size"]) or _sha256(target) != str(
                artifact["sha256"]
            ):
                raise UpdateError("artifact_verification_failed", "wheelhouse digest mismatch")
        for key in ("dependency_lock", "sbom"):
            binding = resolved.manifest.get(key)
            if not isinstance(binding, dict):
                raise UpdateError("release_metadata_invalid", f"release {key} binding is absent")
            name = str(binding.get("filename", ""))
            asset = resolved.uploaded_assets.get(name)
            if not asset or Path(name).name != name:
                raise UpdateError("release_metadata_invalid", f"release {key} asset is absent")
            target = destination / name
            self._download(str(asset["browser_download_url"]), target, MAX_METADATA_BYTES)
            if target.stat().st_size != int(binding.get("size", 0)) or _sha256(target) != str(
                binding.get("sha256", "")
            ):
                raise UpdateError("artifact_verification_failed", f"release {key} digest mismatch")
        _verify_dependency_lock(destination, resolved.manifest)
        return destination

    def _resolve_assets(
        self,
        release: dict[str, Any],
        *,
        requested_channel: str,
        exact_version: str | None,
    ) -> ResolvedRelease:
        assets = release.get("assets")
        if not isinstance(assets, list):
            raise UpdateError("release_metadata_invalid", "release has no asset list")
        uploaded = [
            asset
            for asset in assets
            if isinstance(asset, dict) and asset.get("state") == "uploaded"
        ]
        names = [str(asset.get("name")) for asset in uploaded]
        if len(names) != len(set(names)):
            raise UpdateError("release_metadata_invalid", "release contains duplicate asset names")
        by_name = {str(asset.get("name")): asset for asset in uploaded}
        manifest_name = next((name for name in MANIFEST_NAMES if name in by_name), None)
        manifest_asset = by_name.get(manifest_name) if manifest_name else None
        signature_asset = by_name.get(f"{manifest_name}.sig") if manifest_name else None
        if not manifest_asset or not signature_asset:
            raise UpdateError(
                "release_metadata_invalid", "release is missing signed update metadata"
            )
        manifest_bytes = self._bytes(
            str(manifest_asset["browser_download_url"]), MAX_METADATA_BYTES
        )
        signature = self._bytes(str(signature_asset["browser_download_url"]), 16_384)
        _verify_signature(manifest_bytes, signature)
        try:
            manifest = json.loads(manifest_bytes)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise UpdateError(
                "release_metadata_invalid", "update manifest is invalid JSON"
            ) from exc
        _validate_manifest(
            manifest,
            release=release,
            repository=self.repository,
            requested_channel=requested_channel,
            exact_version=exact_version,
        )
        if not _manifest_is_qualified(manifest):
            raise UpdateError(
                "release_unqualified",
                "Drive release has not been promoted with matching qualification evidence",
            )
        artifact = _manifest_wheel(manifest)
        is_drive_manifest = manifest.get("schema_version") in {
            UPDATE_MANIFEST_V3_SCHEMA,
            UPDATE_MANIFEST_V4_SCHEMA,
        }
        wheel_asset = (
            {
                "name": artifact["filename"],
                "size": artifact["size"],
                "transport": artifact["transport"],
            }
            if is_drive_manifest
            else by_name.get(str(artifact["filename"]))
        )
        if not wheel_asset:
            raise UpdateError("no_compatible_wheel", "release does not contain the declared wheel")
        if int(wheel_asset.get("size") or -1) != int(artifact["size"]):
            raise UpdateError(
                "artifact_verification_failed", "release and manifest wheel sizes differ"
            )
        if is_drive_manifest:
            return ResolvedRelease(
                release,
                manifest,
                manifest_bytes,
                wheel_asset,
                by_name,
                manifest_signature=signature,
            )
        for binding in [
            *manifest.get("artifacts", []),
            manifest.get("dependency_lock"),
            manifest.get("sbom"),
        ]:
            if not isinstance(binding, dict):
                continue
            name = str(binding.get("filename", ""))
            asset = by_name.get(name)
            if not asset or int(asset.get("size", -1)) != int(binding.get("size", 0)):
                raise UpdateError("artifact_verification_failed", f"release asset differs: {name}")
        return ResolvedRelease(
            release,
            manifest,
            manifest_bytes,
            wheel_asset,
            by_name,
            manifest_signature=signature,
        )

    def _json(self, path: str) -> Any:
        raw = self._bytes(f"{self.api_root}{path}", MAX_METADATA_BYTES)
        try:
            return json.loads(raw)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise UpdateError("release_metadata_invalid", "GitHub returned invalid JSON") from exc

    def _bytes(self, url: str, maximum: int) -> bytes:
        request = urllib.request.Request(url, headers=self._headers())
        try:
            with _safe_opener(url).open(request, timeout=self.timeout) as response:
                content = response.read(maximum + 1)
        except urllib.error.HTTPError as exc:
            if exc.code in {401, 403, 404}:
                status = "authentication_required" if not self.token else "release_unavailable"
                raise UpdateError(status, f"GitHub request failed with HTTP {exc.code}") from exc
            raise UpdateError(
                "download_failed", f"GitHub request failed with HTTP {exc.code}"
            ) from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise UpdateError("download_failed", f"GitHub request failed: {exc}") from exc
        if len(content) > maximum:
            raise UpdateError("release_metadata_invalid", "GitHub response exceeds size limit")
        return content

    def _download(self, url: str, destination: Path, maximum: int) -> None:
        request = urllib.request.Request(url, headers=self._headers())
        try:
            with (
                _safe_opener(url).open(request, timeout=self.timeout) as response,
                destination.open("wb") as output,
            ):
                copied = 0
                while True:
                    block = response.read(1024 * 1024)
                    if not block:
                        break
                    copied += len(block)
                    if copied > maximum:
                        raise UpdateError(
                            "artifact_verification_failed", "wheel exceeds size limit"
                        )
                    output.write(block)
                output.flush()
                os.fsync(output.fileno())
        except UpdateError:
            raise
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError) as exc:
            raise UpdateError("download_failed", f"wheel download failed: {exc}") from exc

    def _headers(self) -> dict[str, str]:
        headers = {
            "Accept": "application/vnd.github+json",
            "User-Agent": "persistmind-updater/2",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers


class DriveReleaseClient(GitHubReleaseClient):
    """Resolve a signed release manifest directly from Google Drive.

    Artifact bytes are always fetched through the immutable bindings inside the
    signed manifest. The two discovery URLs may point only at Google Drive and
    are normally supplied by the versioned closed-beta channel configuration.
    """

    def __init__(
        self,
        *,
        manifest_url: str | None = None,
        signature_url: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        super().__init__(repository=SOURCE_REPOSITORY, token="", timeout=timeout)
        self.manifest_url = manifest_url or os.environ.get("PERSISTMIND_RELEASE_MANIFEST_URL")
        self.signature_url = signature_url or os.environ.get(
            "PERSISTMIND_RELEASE_MANIFEST_SIGNATURE_URL"
        )

    def resolve(self, *, channel: str, exact_version: str | None = None) -> ResolvedRelease:
        if not self.manifest_url or not self.signature_url:
            raise UpdateError(
                "release_unavailable",
                "the Google Drive release manifest channel is not configured",
                remediation=(
                    "Set PERSISTMIND_RELEASE_MANIFEST_URL and "
                    "PERSISTMIND_RELEASE_MANIFEST_SIGNATURE_URL to the qualified "
                    "Drive release metadata."
                ),
            )
        manifest_bytes = self._drive_metadata_bytes(self.manifest_url, MAX_METADATA_BYTES)
        signature = self._drive_metadata_bytes(self.signature_url, 16_384)
        _verify_signature(manifest_bytes, signature)
        try:
            manifest = json.loads(manifest_bytes)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise UpdateError(
                "release_metadata_invalid", "update manifest is invalid JSON"
            ) from exc
        if not isinstance(manifest, dict):
            raise UpdateError("release_metadata_invalid", "update manifest is not an object")
        release = {
            "tag_name": manifest.get("release_tag"),
            "prerelease": Version(str(manifest.get("version"))).is_prerelease,
            "published_at": manifest.get("published_at"),
            "draft": False,
        }
        _validate_manifest(
            manifest,
            release=release,
            repository=SOURCE_REPOSITORY,
            requested_channel=channel,
            exact_version=exact_version,
        )
        if not _manifest_is_qualified(manifest):
            raise UpdateError(
                "release_unqualified",
                "Drive release has not been promoted with matching qualification evidence",
            )
        artifact = _manifest_wheel(manifest)
        wheel_asset = {
            "name": artifact["filename"],
            "size": artifact["size"],
            "transport": artifact.get("transport"),
        }
        return ResolvedRelease(
            release,
            manifest,
            manifest_bytes,
            wheel_asset,
            {},
            manifest_signature=signature,
        )

    def _drive_metadata_bytes(self, url: str, maximum: int) -> bytes:
        parsed = urllib.parse.urlparse(url)
        decoded = urllib.parse.unquote(url)
        if (
            parsed.scheme != "https"
            or parsed.hostname not in _DRIVE_HOSTS
            or not re.search(r"[A-Za-z0-9_-]{10,200}", decoded)
        ):
            raise UpdateError(
                "release_metadata_invalid", "release metadata is not hosted on Google Drive"
            )
        request = urllib.request.Request(url, headers={"User-Agent": "persistmind-updater/4"})
        try:
            with _drive_opener(_DRIVE_HOSTS).open(request, timeout=self.timeout) as response:
                content = response.read(maximum + 1)
                final = urllib.parse.urlparse(response.geturl())
                if final.scheme != "https" or final.hostname not in _DRIVE_HOSTS:
                    raise UpdateError(
                        "download_failed", "Drive metadata response escaped the host policy"
                    )
        except UpdateError:
            raise
        except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, OSError) as exc:
            raise UpdateError(
                "download_failed", f"Drive release metadata download failed: {exc}"
            ) from exc
        if len(content) > maximum:
            raise UpdateError("release_metadata_invalid", "Drive metadata exceeds size limit")
        return content


def _github_token() -> str | None:
    for name in ("GH_TOKEN", "GITHUB_TOKEN"):
        if os.environ.get(name):
            return os.environ[name].strip()
    if not shutil.which("gh"):
        return None
    try:
        result = subprocess.run(
            ["gh", "auth", "token"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    return result.stdout.strip() if result.returncode == 0 else None


def _safe_opener(origin: str) -> urllib.request.OpenerDirector:
    origin_host = urllib.parse.urlparse(origin).hostname

    class SafeRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[no-untyped-def]
            redirected = super().redirect_request(req, fp, code, msg, headers, newurl)
            if redirected is not None and urllib.parse.urlparse(newurl).hostname != origin_host:
                redirected.remove_header("Authorization")
            return redirected

    return urllib.request.build_opener(SafeRedirect())


def _verify_signature(document: bytes, encoded_signature: bytes) -> None:
    try:
        signature = base64.b64decode(encoded_signature.strip(), validate=True)
    except ValueError as exc:
        raise UpdateError(
            "artifact_verification_failed", "manifest signature is not valid base64"
        ) from exc
    for encoded_key in UPDATE_ROOT_KEYS:
        try:
            key = Ed25519PublicKey.from_public_bytes(base64.b64decode(encoded_key, validate=True))
            key.verify(signature, document)
            return
        except (ValueError, InvalidSignature):
            continue
    raise UpdateError("artifact_verification_failed", "manifest signature is not trusted")


def _validate_manifest(
    manifest: Any,
    *,
    release: dict[str, Any],
    repository: str,
    requested_channel: str,
    exact_version: str | None,
) -> None:
    if not isinstance(manifest, dict) or manifest.get("schema_version") not in MANIFEST_SCHEMAS:
        raise UpdateError("release_metadata_invalid", "unsupported update manifest schema")
    required = {
        "repository",
        "release_tag",
        "version",
        "channel",
        "commit_sha",
        "published_at",
        "min_bootstrap_version",
        "requires_python",
        "project_state_protocol",
        "artifacts",
    }
    if any(key not in manifest for key in required):
        raise UpdateError("release_metadata_invalid", "update manifest is incomplete")
    if manifest.get("schema_version") == UPDATE_MANIFEST_SCHEMA:
        for key in ("dependency_lock", "sbom"):
            binding = manifest.get(key)
            if not isinstance(binding, dict) or set(binding) != {
                "filename",
                "size",
                "sha256",
            }:
                raise UpdateError(
                    "release_metadata_invalid", f"canonical release {key} binding is incomplete"
                )
            if (
                Path(str(binding["filename"])).name != str(binding["filename"])
                or int(binding["size"]) <= 0
                or not re.fullmatch(r"[0-9a-f]{64}", str(binding["sha256"]))
            ):
                raise UpdateError(
                    "release_metadata_invalid", f"canonical release {key} binding is invalid"
                )
    if manifest.get("schema_version") in {
        UPDATE_MANIFEST_V3_SCHEMA,
        UPDATE_MANIFEST_V4_SCHEMA,
    }:
        for key in (
            "dependency_lock",
            "sbom",
            "build_identity",
            "product_id",
        ):
            if key not in manifest:
                raise UpdateError("release_metadata_invalid", f"Drive manifest {key} is absent")
        if manifest.get("schema_version") == UPDATE_MANIFEST_V3_SCHEMA and not re.fullmatch(
            r"[0-9a-f]{40}", str(manifest.get("release_repository_commit"))
        ):
            raise UpdateError("release_metadata_invalid", "release repository commit is invalid")
        if manifest.get("schema_version") == UPDATE_MANIFEST_V4_SCHEMA:
            drive_required = {
                "artifact_transport",
                "release_root_folder_id",
                "release_folder_id",
            }
            if not drive_required <= set(manifest):
                raise UpdateError(
                    "release_metadata_invalid", "manifest-v4 Drive identity is absent"
                )
            if (
                manifest.get("artifact_transport") != "google_drive"
                or manifest.get("release_root_folder_id") != RELEASE_DRIVE_FOLDER_ID
                or not re.fullmatch(
                    r"[A-Za-z0-9_-]{10,200}", str(manifest.get("release_folder_id"))
                )
            ):
                raise UpdateError(
                    "release_metadata_invalid", "manifest-v4 Drive identity is invalid"
                )
        if manifest.get("product_id") != PRODUCT_ID or not str(manifest["build_identity"]).strip():
            raise UpdateError(
                "release_metadata_invalid", "manifest-v3 product or build identity is invalid"
            )
        if manifest.get("revoked") is True:
            raise UpdateError("artifact_verification_failed", "release manifest is revoked")
        if manifest.get("expires_at"):
            try:
                expires = _timestamp(str(manifest["expires_at"]))
            except ValueError as exc:
                raise UpdateError(
                    "release_metadata_invalid", "Drive manifest expiry is invalid"
                ) from exc
            if expires <= datetime.now(timezone.utc):
                raise UpdateError("artifact_verification_failed", "release manifest is expired")
        drive_ids: list[str] = []
        for binding in [
            *manifest.get("artifacts", []),
            manifest.get("dependency_lock"),
            manifest.get("sbom"),
        ]:
            if not isinstance(binding, dict):
                raise UpdateError("release_metadata_invalid", "Drive manifest binding is invalid")
            reference = ArtifactReference.from_manifest(binding)
            drive_ids.append(str(reference.transport_record["file_id"]))
        if len(drive_ids) != len(set(drive_ids)):
            raise UpdateError(
                "release_metadata_invalid", "Drive file IDs must be immutable and unique"
            )
    storage = manifest.get("storage_compatibility")
    storage_required = {
        "minimum_readable_schema",
        "maximum_readable_schema",
        "target_schema",
        "rollback_requires_backup",
    }
    if not isinstance(storage, dict) or not storage_required <= set(storage):
        raise UpdateError("release_metadata_invalid", "storage compatibility is incomplete")
    if not all(
        isinstance(storage[name], int) for name in storage_required - {"rollback_requires_backup"}
    ):
        raise UpdateError(
            "release_metadata_invalid", "storage compatibility schemas must be integers"
        )
    if storage.get("rollback_requires_backup") is not True:
        raise UpdateError("release_metadata_invalid", "release must require a rollback backup")
    if (
        repository not in (*TRUSTED_REPOSITORIES, SOURCE_REPOSITORY)
        or manifest["repository"] != repository
        or manifest["release_tag"] != release.get("tag_name")
    ):
        raise UpdateError(
            "release_metadata_invalid", "manifest release identity does not match the channel"
        )
    try:
        version = Version(str(manifest["version"]))
        tag_version = Version(str(manifest["release_tag"])[1:])
    except (InvalidVersion, IndexError) as exc:
        raise UpdateError(
            "release_metadata_invalid", "manifest contains an invalid version"
        ) from exc
    if version != tag_version or (exact_version and version != Version(exact_version)):
        raise UpdateError(
            "release_metadata_invalid", "manifest, tag, and requested versions differ"
        )
    if requested_channel == "stable" and version.is_prerelease:
        raise UpdateError("release_metadata_invalid", "stable channel resolved to a prerelease")
    if str(manifest["channel"]) not in {"stable", "preview"}:
        raise UpdateError("release_metadata_invalid", "manifest channel is invalid")
    expected_channel = "preview" if version.is_prerelease else "stable"
    if manifest["channel"] != expected_channel:
        raise UpdateError("release_metadata_invalid", "manifest channel disagrees with its version")
    if bool(release.get("prerelease")) != version.is_prerelease:
        raise UpdateError(
            "release_metadata_invalid", "release-channel prerelease flag disagrees with version"
        )
    if release.get("published_at"):
        try:
            manifest_time = _timestamp(str(manifest["published_at"]))
            release_time = _timestamp(str(release["published_at"]))
        except ValueError as exc:
            raise UpdateError(
                "release_metadata_invalid", "release publication time is invalid"
            ) from exc
        delay = (release_time - manifest_time).total_seconds()
        if delay < 0 or delay > 24 * 60 * 60:
            raise UpdateError(
                "release_metadata_invalid",
                "manifest signing time is outside the publication window",
            )
    if not re.fullmatch(r"[0-9a-f]{40}", str(manifest["commit_sha"])):
        raise UpdateError("release_metadata_invalid", "manifest commit SHA is invalid")
    try:
        compatible = SpecifierSet(str(manifest["requires_python"])).contains(
            f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        )
    except Exception as exc:
        raise UpdateError("release_metadata_invalid", "requires_python is invalid") from exc
    if not compatible:
        raise UpdateError("unsupported_python", "this release does not support the active Python")


def _manifest_wheel(manifest: dict[str, Any]) -> dict[str, Any]:
    artifacts = manifest.get("artifacts")
    if not isinstance(artifacts, list):
        raise UpdateError("release_metadata_invalid", "manifest artifacts must be an array")
    supported_tags = set(sys_tags())
    compatible: list[dict[str, Any]] = []
    for artifact in artifacts:
        if not isinstance(artifact, dict) or not str(artifact.get("filename") or "").endswith(
            ".whl"
        ):
            continue
        required = {"filename", "size", "sha256"}
        if any(key not in artifact for key in required):
            continue
        try:
            _, version, _, tags = parse_wheel_filename(str(artifact["filename"]))
        except Exception:
            continue
        if version == Version(str(manifest["version"])) and tags & supported_tags:
            compatible.append(artifact)
    if len(compatible) != 1:
        raise UpdateError(
            "no_compatible_wheel", "release must declare exactly one compatible wheel"
        )
    artifact = compatible[0]
    if not re.fullmatch(r"[0-9a-f]{64}", str(artifact["sha256"])):
        raise UpdateError("release_metadata_invalid", "wheel SHA-256 is invalid")
    return artifact


def _manifest_is_qualified(manifest: dict[str, Any]) -> bool:
    """Qualification, not semantic version ordering, controls promotion."""

    identity = manifest.get("release_identity")
    if not isinstance(identity, dict):
        return False
    if identity.get("schema_version") not in {
        "persistmind.release_identity.v3",
        "persistmind.release_identity.v4",
    }:
        return False
    try:
        from persistmind.release_identity import migrate_release_identity, validate_release_identity

        identity = migrate_release_identity(identity)
        validate_release_identity(identity)
    except (TypeError, ValueError):
        return False
    if manifest.get("promotion_status") not in {"qualified", "promoted"}:
        return False
    if manifest.get("revoked") is True or manifest.get("superseded") is True:
        return False
    qualified_python = {str(item) for item in identity.get("qualified_python", [])}
    current_python = f"{sys.version_info.major}.{sys.version_info.minor}"
    qualified_os = {str(item).casefold() for item in identity.get("qualified_os", [])}
    current_os = platform.system().casefold()
    evidence = identity.get("qualification_evidence_ids")
    hashes = identity.get("artifact_hashes")
    try:
        wheel = _manifest_wheel(manifest)
    except UpdateError:
        return False
    return bool(
        current_python in qualified_python
        and any(current_os in item for item in qualified_os)
        and isinstance(evidence, list)
        and evidence
        and isinstance(hashes, dict)
        and hashes.get("wheel_sha256") == wheel.get("sha256")
        and identity.get("version") == manifest.get("version")
        and identity.get("source_commit") == manifest.get("commit_sha")
        and identity.get("maturity")
        == ("public_beta" if Version(str(manifest["version"])).is_prerelease else "production")
        and identity.get("officially_signed") is True
        and identity.get("signing_status") == "signed-trusted-update"
        and identity.get("runtime_profile") == "windows-stable"
        and identity.get("profile_locked") is True
        and isinstance(identity.get("operation_catalog_sha256"), str)
        and len(identity["operation_catalog_sha256"]) == 64
    )


def _verify_wheel_identity(path: Path, manifest: dict[str, Any]) -> None:
    import zipfile

    try:
        with zipfile.ZipFile(path) as archive:
            metadata_names = [
                name for name in archive.namelist() if name.endswith(".dist-info/METADATA")
            ]
            if len(metadata_names) != 1:
                raise UpdateError(
                    "artifact_verification_failed", "wheel has invalid METADATA layout"
                )
            metadata = archive.read(metadata_names[0]).decode("utf-8")
    except (OSError, zipfile.BadZipFile, UnicodeDecodeError) as exc:
        raise UpdateError("artifact_verification_failed", "wheel is unreadable") from exc
    fields: dict[str, str] = {}
    for line in metadata.splitlines():
        if ": " in line:
            key, value = line.split(": ", 1)
            fields.setdefault(key, value)
    package_names = {PYTHON_DISTRIBUTION.casefold()}
    if fields.get("Name", "").casefold() not in package_names or Version(
        fields.get("Version", "0")
    ) != Version(str(manifest["version"])):
        raise UpdateError(
            "artifact_verification_failed", "wheel METADATA identity differs from manifest"
        )


def _verify_dependency_lock(directory: Path, manifest: dict[str, Any]) -> None:
    try:
        lock = json.loads((directory / "dependency-lock.v1.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise UpdateError("artifact_verification_failed", "dependency lock is unreadable") from exc
    entries = lock.get("wheels") if isinstance(lock, dict) else None
    if (
        lock.get("schema_version") != "persistmind.dependency_lock.v1"
        or not isinstance(entries, list)
        or not entries
    ):
        raise UpdateError("artifact_verification_failed", "dependency lock identity is invalid")
    declared = {
        str(item["filename"]): (int(item["size"]), str(item["sha256"]))
        for item in manifest.get("artifacts", [])
        if isinstance(item, dict) and str(item.get("filename", "")).endswith(".whl")
    }
    locked = {
        str(item["filename"]): (int(item["size"]), str(item["sha256"]))
        for item in entries
        if isinstance(item, dict)
    }
    if declared != locked or set(declared) != {path.name for path in directory.glob("*.whl")}:
        raise UpdateError("artifact_verification_failed", "dependency lock and wheelhouse differ")
    root = _manifest_wheel(manifest)
    if lock.get("root_wheel") != root.get("filename"):
        raise UpdateError("artifact_verification_failed", "dependency lock root differs")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _timestamp(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("timestamp must include a timezone")
    return parsed.astimezone(timezone.utc)
