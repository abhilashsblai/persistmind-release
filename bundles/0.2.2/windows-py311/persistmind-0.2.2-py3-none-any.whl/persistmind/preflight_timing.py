from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, TypeVar

T = TypeVar("T")


class PreflightDeadlineExceeded(TimeoutError):
    def __init__(self, stage: str, elapsed_seconds: float, hard_timeout_seconds: float):
        self.stage = stage
        self.elapsed_seconds = elapsed_seconds
        self.hard_timeout_seconds = hard_timeout_seconds
        super().__init__(
            f"preflight hard timeout exceeded during {stage}: "
            f"{elapsed_seconds:.3f}s > {hard_timeout_seconds:.3f}s"
        )


@dataclass
class PreflightTiming:
    slo_seconds: float
    hard_timeout_seconds: float
    started: float = field(default_factory=lambda: time.perf_counter())
    stages: list[dict[str, Any]] = field(default_factory=list)
    timed_out: bool = False
    timed_out_stage: str | None = None

    def run(self, stage: str, operation: Callable[[], T]) -> T:
        self._raise_if_timed_out(stage)
        stage_started = time.perf_counter()
        try:
            return operation()
        finally:
            finished = time.perf_counter()
            self.stages.append(
                {
                    "stage": stage,
                    "elapsed_ms": round((finished - stage_started) * 1000, 2),
                    "cumulative_ms": round((finished - self.started) * 1000, 2),
                }
            )
            self._raise_if_timed_out(stage, now=finished)

    def report(self) -> dict[str, Any]:
        elapsed_seconds = max(0.0, time.perf_counter() - self.started)
        return {
            "mode": "codex_preflight_full",
            "elapsed_ms": round(elapsed_seconds * 1000, 2),
            "slo_seconds": self.slo_seconds,
            "hard_timeout_seconds": self.hard_timeout_seconds,
            "within_slo": elapsed_seconds <= self.slo_seconds,
            "timed_out": self.timed_out,
            "timed_out_stage": self.timed_out_stage,
            "stages": list(self.stages),
        }

    def _raise_if_timed_out(self, stage: str, *, now: float | None = None) -> None:
        elapsed = (time.perf_counter() if now is None else now) - self.started
        if elapsed <= self.hard_timeout_seconds:
            return
        self.timed_out = True
        self.timed_out_stage = stage
        raise PreflightDeadlineExceeded(stage, elapsed, self.hard_timeout_seconds)
