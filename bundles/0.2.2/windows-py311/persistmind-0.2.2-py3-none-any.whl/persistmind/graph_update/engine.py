from __future__ import annotations

import json
import ast
import time
from pathlib import Path
from pathlib import PurePosixPath
from typing import Any

from persistmind.utils import canonical_json, stable_id, utc_now


def _loads(value: str | None, default: Any) -> Any:
    try:
        return json.loads(value or "")
    except (TypeError, json.JSONDecodeError):
        return default


class LivingGraphEngine:
    """Versioned materialization over authoritative CTX stores.

    Versions are copy-on-write: a row in a child version shadows the same stable
    node or edge in its ancestors. A tombstone is represented by ``valid_to``.
    """

    def __init__(self, conn: Any, repo_id: str, repo_root: Path | None = None) -> None:
        self.conn = conn
        self.repo_id = repo_id
        self.repo_root = repo_root.resolve() if repo_root else None

    def status(self, branch: str | None = None) -> dict[str, Any]:
        sql = "SELECT * FROM graph_versions WHERE repo_id=?"
        params: list[Any] = [self.repo_id]
        if branch is not None:
            sql += " AND branch=?"
            params.append(branch)
        sql += " ORDER BY created_at DESC, graph_version_id DESC LIMIT 1"
        row = self.conn.execute(sql, params).fetchone()
        if row is None:
            return {
                "schema_version": "persistmind.graph_status.v1",
                "available": False,
                "freshness": "not_available",
                "graph_version_id": None,
            }
        result = dict(row)
        result.update(
            {
                "schema_version": "persistmind.graph_status.v1",
                "available": True,
                "node_count": len(self._effective_nodes(result["graph_version_id"])),
            }
        )
        return result

    def update(
        self,
        paths: list[str],
        *,
        branch: str | None = None,
        source_ref: str | None = None,
        deleted_paths: list[str] | None = None,
        renames: dict[str, str] | None = None,
        base_commit_sha: str | None = None,
    ) -> dict[str, Any]:
        started = time.perf_counter()
        parent = self.status(branch)
        parent_id = parent.get("graph_version_id") if parent.get("available") else None
        normalized = sorted({self._path(path) for path in paths if path})
        deleted = sorted({self._path(path) for path in deleted_paths or [] if path})
        rename_map = {self._path(old): self._path(new) for old, new in (renames or {}).items()}
        input_digest = canonical_json(
            {"paths": normalized, "deleted": deleted, "renames": rename_map}
        )
        graph_version_id = stable_id(
            "graph-version", self.repo_id, parent_id, branch, source_ref, input_digest
        )
        update_run_id = stable_id("graph-update", graph_version_id, input_digest)
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO graph_versions(
                  graph_version_id, repo_id, branch, base_commit_sha,
                  parent_graph_version_id, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    graph_version_id,
                    self.repo_id,
                    branch,
                    base_commit_sha,
                    parent_id,
                    now,
                    now,
                ),
            )
            self.conn.execute(
                """
                INSERT OR IGNORE INTO graph_update_runs(
                  update_run_id, graph_version_id, status, inputs_json,
                  started_at, completed_at
                ) VALUES (?, ?, 'running', ?, ?, NULL)
                """,
                (update_run_id, graph_version_id, input_digest, now),
            )
            changed_nodes: list[str] = []
            changed_edges: list[str] = []
            for path in normalized + list(rename_map.values()):
                node_id = stable_id("path", path)
                changed_nodes.append(node_id)
                node_type = "test" if path.startswith("tests/") or "/test" in path else "file"
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO graph_nodes(
                      graph_version_id, node_id, node_type, label, source_kind,
                      source_ref, valid_from, metadata_json
                    ) VALUES (?, ?, ?, ?, 'code', ?, ?, ?)
                    """,
                    (
                        graph_version_id,
                        node_id,
                        node_type,
                        path,
                        source_ref or path,
                        now,
                        canonical_json({"path": path}),
                    ),
                )
                nodes, edges = self._extract_code_facts(
                    graph_version_id, path, node_id, now, source_ref
                )
                changed_nodes.extend(nodes)
                changed_edges.extend(edges)
            for path in deleted + list(rename_map):
                candidates = [
                    item
                    for item in self._effective_nodes(str(parent_id))
                    if parent_id and _loads(item.get("metadata_json"), {}).get("path") == path
                ]
                if not candidates:
                    candidates = [
                        {
                            "node_id": stable_id("path", path),
                            "node_type": "file",
                            "label": path,
                            "scope": "repo",
                            "source_kind": "code",
                            "source_ref": source_ref or path,
                            "confidence": 1.0,
                            "metadata_json": canonical_json({"path": path}),
                        }
                    ]
                for candidate in candidates:
                    changed_nodes.append(str(candidate["node_id"]))
                    metadata = _loads(candidate.get("metadata_json"), {})
                    metadata["tombstone"] = True
                    self.conn.execute(
                        """
                        INSERT OR REPLACE INTO graph_nodes(
                          graph_version_id, node_id, node_type, label, scope,
                          truth_state, source_kind, source_ref, confidence,
                          valid_from, valid_to, metadata_json
                        ) VALUES (?, ?, ?, ?, ?, 'stale', ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            graph_version_id,
                            candidate["node_id"],
                            candidate["node_type"],
                            candidate["label"],
                            candidate.get("scope", "repo"),
                            candidate.get("source_kind", "code"),
                            candidate.get("source_ref") or source_ref or path,
                            candidate.get("confidence", 1.0),
                            now,
                            now,
                            canonical_json(metadata),
                        ),
                    )
            teaching_nodes = self._materialize_teaching(graph_version_id, now)
            changed_nodes.extend(teaching_nodes)
            elapsed_ms = round((time.perf_counter() - started) * 1000, 3)
            delta_id = stable_id("graph-delta", graph_version_id, input_digest)
            self.conn.execute(
                """
                INSERT OR REPLACE INTO graph_deltas(
                  delta_id, graph_version_id, changed_paths_json,
                  changed_nodes_json, changed_edges_json,
                  invalidated_caches_json, source_ref,
                  elapsed_ms, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    delta_id,
                    graph_version_id,
                    canonical_json(
                        sorted(
                            set(normalized + deleted + list(rename_map) + list(rename_map.values()))
                        )
                    ),
                    canonical_json(sorted(set(changed_nodes))),
                    canonical_json(sorted(set(changed_edges))),
                    canonical_json(["pack", "impact", "teacher_brief"]),
                    source_ref,
                    elapsed_ms,
                    now,
                ),
            )
            self.conn.execute(
                "UPDATE graph_update_runs SET status='complete', completed_at=? WHERE update_run_id=?",
                (utc_now(), update_run_id),
            )
        return {
            "schema_version": "persistmind.graph_update.v1",
            "ok": True,
            "graph_version_id": graph_version_id,
            "parent_graph_version_id": parent_id,
            "update_run_id": update_run_id,
            "delta_id": delta_id,
            "changed_paths": normalized,
            "deleted_paths": deleted,
            "renames": rename_map,
            "elapsed_ms": elapsed_ms,
        }

    def query(
        self,
        query: str = "",
        *,
        graph_version_id: str | None = None,
        node_type: str | None = None,
        limit: int = 50,
        budget_ms: int = 100,
    ) -> dict[str, Any]:
        started = time.perf_counter()
        version_id = graph_version_id or self.status().get("graph_version_id")
        if not version_id:
            return {
                "schema_version": "persistmind.graph_query.v1",
                "nodes": [],
                "truncated": False,
                "graph_version_id": None,
            }
        matches: list[dict[str, Any]] = []
        truncated = False
        for row in self._effective_nodes(str(version_id)):
            if (time.perf_counter() - started) * 1000 > max(1, budget_ms):
                truncated = True
                break
            if row.get("valid_to"):
                continue
            if node_type and row.get("node_type") != node_type:
                continue
            if query and query.casefold() not in str(row.get("label", "")).casefold():
                continue
            row["metadata"] = _loads(row.pop("metadata_json", "{}"), {})
            matches.append(row)
            if len(matches) >= max(1, limit):
                truncated = True
                break
        return {
            "schema_version": "persistmind.graph_query.v1",
            "graph_version_id": version_id,
            "nodes": matches,
            "truncated": truncated,
            "elapsed_ms": round((time.perf_counter() - started) * 1000, 3),
            "budget_ms": budget_ms,
        }

    def node(self, node_id: str, graph_version_id: str | None = None) -> dict[str, Any]:
        result = self.query(graph_version_id=graph_version_id, limit=100000)
        node = next((item for item in result["nodes"] if item["node_id"] == node_id), None)
        if node is None:
            raise KeyError(f"unknown graph node: {node_id}")
        return {
            "schema_version": "persistmind.graph_node.v1",
            "graph_version_id": result["graph_version_id"],
            "node": node,
        }

    def neighbors(
        self, node_id: str, graph_version_id: str | None = None, limit: int = 50
    ) -> dict[str, Any]:
        version_id = graph_version_id or self.status().get("graph_version_id")
        edges = []
        for row in self._effective_edges(str(version_id)) if version_id else []:
            if row.get("valid_to"):
                continue
            if node_id in {row["source_node_id"], row["target_node_id"]}:
                row["metadata"] = _loads(row.pop("metadata_json", "{}"), {})
                edges.append(row)
            if len(edges) >= max(1, limit):
                break
        return {
            "schema_version": "persistmind.graph_neighbors.v1",
            "graph_version_id": version_id,
            "node_id": node_id,
            "edges": edges,
            "truncated": len(edges) >= max(1, limit),
        }

    def provenance(self, node_id: str, graph_version_id: str | None = None) -> dict[str, Any]:
        item = self.node(node_id, graph_version_id)
        node = item["node"]
        return {
            "schema_version": "persistmind.graph_provenance.v1",
            "graph_version_id": item["graph_version_id"],
            "node_id": node_id,
            "source_kind": node["source_kind"],
            "source_ref": node.get("source_ref"),
            "truth_state": node["truth_state"],
            "confidence": node["confidence"],
        }

    def validate(self, graph_version_id: str | None = None) -> dict[str, Any]:
        version_id = graph_version_id or self.status().get("graph_version_id")
        if not version_id:
            return {
                "schema_version": "persistmind.graph_validate.v1",
                "ok": False,
                "errors": ["no graph version"],
            }
        nodes = {
            item["node_id"]
            for item in self._effective_nodes(str(version_id))
            if not item.get("valid_to")
        }
        errors = []
        for edge in self._effective_edges(str(version_id)):
            if not edge.get("valid_to") and (
                edge["source_node_id"] not in nodes or edge["target_node_id"] not in nodes
            ):
                errors.append(f"dangling edge: {edge['edge_id']}")
        return {
            "schema_version": "persistmind.graph_validate.v1",
            "ok": not errors,
            "graph_version_id": version_id,
            "errors": errors,
        }

    def mark_stale(
        self, graph_version_id: str, reason: str, *, pack_id: str | None = None
    ) -> dict[str, Any]:
        incident_id = stable_id("graph-stale", graph_version_id, pack_id, reason)
        with self.conn:
            self.conn.execute(
                "UPDATE graph_versions SET freshness='stale', updated_at=? WHERE graph_version_id=?",
                (utc_now(), graph_version_id),
            )
            self.conn.execute(
                "INSERT OR IGNORE INTO graph_stale_incidents(incident_id, graph_version_id, pack_id, missed_update, created_at) VALUES (?, ?, ?, ?, ?)",
                (incident_id, graph_version_id, pack_id, reason, utc_now()),
            )
        return {
            "schema_version": "persistmind.graph_stale.v1",
            "incident_id": incident_id,
            "graph_version_id": graph_version_id,
            "freshness": "stale",
            "reason": reason,
        }

    def bind_pack(
        self, pack_id: str, task_session_id: str, graph_version_id: str | None = None
    ) -> dict[str, Any]:
        version_id = graph_version_id or self.status().get("graph_version_id")
        if not version_id:
            return {
                "schema_version": "persistmind.graph_pack_binding.v1",
                "available": False,
                "staleness_state": "not_available",
            }
        freshness = self.conn.execute(
            "SELECT freshness FROM graph_versions WHERE graph_version_id=?", (version_id,)
        ).fetchone()
        state = str(freshness[0] if freshness else "stale")
        with self.conn:
            self.conn.execute(
                "INSERT OR REPLACE INTO graph_pack_bindings(pack_id, task_session_id, graph_version_id, staleness_state, created_at) VALUES (?, ?, ?, ?, ?)",
                (pack_id, task_session_id, version_id, state, utc_now()),
            )
        return {
            "schema_version": "persistmind.graph_pack_binding.v1",
            "available": True,
            "pack_id": pack_id,
            "task_session_id": task_session_id,
            "graph_version_id": version_id,
            "staleness_state": state,
        }

    def fork(
        self,
        source_graph_version_id: str,
        *,
        branch: str,
        worktree_root: str | None = None,
        owner_session_id: str | None = None,
    ) -> dict[str, Any]:
        now = utc_now()
        target_id = stable_id("graph-fork-version", source_graph_version_id, branch, worktree_root)
        fork_id = stable_id("graph-fork", source_graph_version_id, target_id)
        with self.conn:
            self.conn.execute(
                "INSERT OR IGNORE INTO graph_versions(graph_version_id, repo_id, branch, worktree_root, parent_graph_version_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (target_id, self.repo_id, branch, worktree_root, source_graph_version_id, now, now),
            )
            self.conn.execute(
                "INSERT OR IGNORE INTO graph_forks(fork_id, source_graph_version_id, target_graph_version_id, branch, worktree_root, owner_session_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    fork_id,
                    source_graph_version_id,
                    target_id,
                    branch,
                    worktree_root,
                    owner_session_id,
                    now,
                ),
            )
        return {
            "schema_version": "persistmind.graph_fork.v1",
            "fork_id": fork_id,
            "source_graph_version_id": source_graph_version_id,
            "target_graph_version_id": target_id,
            "branch": branch,
            "isolation_status": "isolated",
        }

    def merge_review(
        self, source_graph_version_id: str, target_graph_version_id: str
    ) -> dict[str, Any]:
        source = {item["node_id"]: item for item in self._effective_nodes(source_graph_version_id)}
        target = {item["node_id"]: item for item in self._effective_nodes(target_graph_version_id)}
        conflicts = sorted(
            node_id
            for node_id in source.keys() & target.keys()
            if self._node_signature(source[node_id]) != self._node_signature(target[node_id])
        )
        deltas = sorted(
            node_id
            for node_id in source
            if node_id not in target
            or self._node_signature(source[node_id]) != self._node_signature(target[node_id])
        )
        review_id = stable_id(
            "graph-merge-review",
            source_graph_version_id,
            target_graph_version_id,
            canonical_json(deltas),
        )
        with self.conn:
            self.conn.execute(
                "INSERT OR IGNORE INTO graph_merge_reviews(merge_review_id, source_graph_version_id, target_graph_version_id, conflicts_json, approved_deltas_json, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (
                    review_id,
                    source_graph_version_id,
                    target_graph_version_id,
                    canonical_json(conflicts),
                    canonical_json([] if conflicts else deltas),
                    utc_now(),
                ),
            )
        return {
            "schema_version": "persistmind.graph_merge_review.v1",
            "merge_review_id": review_id,
            "source_graph_version_id": source_graph_version_id,
            "target_graph_version_id": target_graph_version_id,
            "conflicts": conflicts,
            "candidate_deltas": deltas,
            "status": "pending",
        }

    def merge_decide(self, merge_review_id: str, decision: str, reviewer: str) -> dict[str, Any]:
        if decision not in {"approve", "reject", "request_changes"}:
            raise ValueError(f"unsupported merge decision: {decision}")
        row = self.conn.execute(
            "SELECT * FROM graph_merge_reviews WHERE merge_review_id=?", (merge_review_id,)
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown merge review: {merge_review_id}")
        conflicts = _loads(row["conflicts_json"], [])
        if decision == "approve" and conflicts:
            raise ValueError("merge review has unresolved conflicts")
        status = {
            "approve": "approved",
            "reject": "rejected",
            "request_changes": "changes_requested",
        }[decision]
        merged_graph_version_id = None
        with self.conn:
            self.conn.execute(
                "UPDATE graph_merge_reviews SET status=?, reviewer=?, decided_at=? WHERE merge_review_id=?",
                (status, reviewer, utc_now(), merge_review_id),
            )
            if decision == "approve":
                now = utc_now()
                merged_graph_version_id = stable_id(
                    "graph-merge-version",
                    row["source_graph_version_id"],
                    row["target_graph_version_id"],
                    merge_review_id,
                )
                target = self.conn.execute(
                    "SELECT * FROM graph_versions WHERE graph_version_id=?",
                    (row["target_graph_version_id"],),
                ).fetchone()
                self.conn.execute(
                    """
                    INSERT OR IGNORE INTO graph_versions(
                      graph_version_id, repo_id, branch, worktree_root,
                      base_commit_sha, parent_graph_version_id, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        merged_graph_version_id,
                        self.repo_id,
                        target["branch"] if target else None,
                        target["worktree_root"] if target else None,
                        target["base_commit_sha"] if target else None,
                        row["target_graph_version_id"],
                        now,
                        now,
                    ),
                )
                approved = _loads(row["approved_deltas_json"], [])
                source_nodes = {
                    item["node_id"]: item
                    for item in self._effective_nodes(str(row["source_graph_version_id"]))
                }
                for node_id in approved:
                    node = source_nodes.get(node_id)
                    if not node:
                        continue
                    self.conn.execute(
                        """
                        INSERT OR REPLACE INTO graph_nodes(
                          graph_version_id, node_id, node_type, label, scope,
                          truth_state, source_kind, source_ref, confidence,
                          valid_from, valid_to, metadata_json
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            merged_graph_version_id,
                            node["node_id"],
                            node["node_type"],
                            node["label"],
                            node["scope"],
                            node["truth_state"],
                            node["source_kind"],
                            node["source_ref"],
                            node["confidence"],
                            now,
                            node["valid_to"],
                            node["metadata_json"],
                        ),
                    )
        return {
            "schema_version": "persistmind.graph_merge_decision.v1",
            **dict(
                self.conn.execute(
                    "SELECT * FROM graph_merge_reviews WHERE merge_review_id=?", (merge_review_id,)
                ).fetchone()
            ),
            "merged_graph_version_id": merged_graph_version_id,
        }

    def decision(
        self,
        graph_version_id: str,
        decision_key: str,
        summary: str,
        *,
        status: str = "candidate",
        approver: str | None = None,
        evidence_refs: list[str] | None = None,
    ) -> dict[str, Any]:
        decision_id = stable_id("graph-decision", graph_version_id, decision_key)
        now = utc_now()
        with self.conn:
            self.conn.execute(
                "INSERT INTO graph_decision_nodes(graph_decision_id, graph_version_id, decision_key, summary, status, approver, evidence_refs_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(graph_decision_id) DO UPDATE SET summary=excluded.summary, status=excluded.status, approver=excluded.approver, evidence_refs_json=excluded.evidence_refs_json, updated_at=excluded.updated_at",
                (
                    decision_id,
                    graph_version_id,
                    decision_key,
                    summary,
                    status,
                    approver,
                    canonical_json(evidence_refs or []),
                    now,
                    now,
                ),
            )
            self.conn.execute(
                """
                INSERT OR REPLACE INTO graph_nodes(
                  graph_version_id, node_id, node_type, label, truth_state,
                  source_kind, source_ref, valid_from, metadata_json
                ) VALUES (?, ?, 'decision', ?, ?, 'decision', ?, ?, ?)
                """,
                (
                    graph_version_id,
                    decision_id,
                    summary,
                    status,
                    decision_key,
                    now,
                    canonical_json(
                        {"decision_key": decision_key, "evidence_refs": evidence_refs or []}
                    ),
                ),
            )
        return {
            "schema_version": "persistmind.graph_decision.v1",
            **dict(
                self.conn.execute(
                    "SELECT * FROM graph_decision_nodes WHERE graph_decision_id=?", (decision_id,)
                ).fetchone()
            ),
        }

    def _lineage(self, graph_version_id: str) -> list[str]:
        lineage: list[str] = []
        current: str | None = graph_version_id
        seen: set[str] = set()
        while current and current not in seen:
            seen.add(current)
            lineage.append(current)
            row = self.conn.execute(
                "SELECT parent_graph_version_id FROM graph_versions WHERE graph_version_id=?",
                (current,),
            ).fetchone()
            current = str(row[0]) if row and row[0] else None
        return lineage

    def _extract_code_facts(
        self,
        graph_version_id: str,
        path: str,
        file_node_id: str,
        now: str,
        source_ref: str | None,
    ) -> tuple[list[str], list[str]]:
        if self.repo_root is None or not path.endswith(".py"):
            return [], []
        absolute = self.repo_root / path
        if not absolute.is_file():
            return [], []
        try:
            tree = ast.parse(absolute.read_text(encoding="utf-8", errors="ignore"))
        except (OSError, SyntaxError):
            return [], []
        node_ids: list[str] = []
        edge_ids: list[str] = []
        for item in ast.walk(tree):
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                symbol_type = "class" if isinstance(item, ast.ClassDef) else "function"
                node_id = stable_id("symbol", path, item.name, item.lineno)
                node_ids.append(node_id)
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO graph_nodes(
                      graph_version_id, node_id, node_type, label, source_kind,
                      source_ref, valid_from, metadata_json
                    ) VALUES (?, ?, ?, ?, 'code', ?, ?, ?)
                    """,
                    (
                        graph_version_id,
                        node_id,
                        symbol_type,
                        f"{path}::{item.name}",
                        source_ref or path,
                        now,
                        canonical_json({"path": path, "name": item.name, "line": item.lineno}),
                    ),
                )
                edge_ids.append(
                    self._edge(
                        graph_version_id,
                        file_node_id,
                        node_id,
                        "contains",
                        source_ref or path,
                        now,
                    )
                )
            modules: list[str] = []
            if isinstance(item, ast.Import):
                modules = [alias.name for alias in item.names]
            elif isinstance(item, ast.ImportFrom) and item.module:
                modules = [item.module]
            for module in modules:
                module_id = stable_id("module", module)
                node_ids.append(module_id)
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO graph_nodes(
                      graph_version_id, node_id, node_type, label, source_kind,
                      source_ref, valid_from, metadata_json
                    ) VALUES (?, ?, 'module', ?, 'code', ?, ?, ?)
                    """,
                    (
                        graph_version_id,
                        module_id,
                        module,
                        source_ref or path,
                        now,
                        canonical_json({"path": path, "module": module}),
                    ),
                )
                edge_ids.append(
                    self._edge(
                        graph_version_id,
                        file_node_id,
                        module_id,
                        "imports",
                        source_ref or path,
                        now,
                    )
                )
        return node_ids, edge_ids

    def _materialize_teaching(self, graph_version_id: str, now: str) -> list[str]:
        node_ids: list[str] = []
        for row in self.conn.execute(
            "SELECT * FROM lessons WHERE repo_id=? ORDER BY lesson_id", (self.repo_id,)
        ).fetchall():
            node_id = stable_id("graph-lesson", row["lesson_id"])
            node_ids.append(node_id)
            self.conn.execute(
                """
                INSERT OR REPLACE INTO graph_nodes(
                  graph_version_id, node_id, node_type, label, scope,
                  truth_state, source_kind, source_ref, confidence,
                  valid_from, valid_to, metadata_json
                ) VALUES (?, ?, 'lesson', ?, ?, ?, 'teaching', ?, ?, ?, ?, ?)
                """,
                (
                    graph_version_id,
                    node_id,
                    row["summary"],
                    row["scope"],
                    row["status"],
                    row["lesson_id"],
                    min(1.0, float(row["evidence_count"] or 0) / 2.0),
                    now,
                    now if row["status"] in {"tombstoned", "superseded"} else None,
                    canonical_json(
                        {"lesson_id": row["lesson_id"], "privacy_class": row["privacy_class"]}
                    ),
                ),
            )
        return node_ids

    def _edge(
        self,
        graph_version_id: str,
        source_node_id: str,
        target_node_id: str,
        edge_type: str,
        source_ref: str,
        now: str,
    ) -> str:
        edge_id = stable_id("graph-edge", source_node_id, target_node_id, edge_type)
        self.conn.execute(
            """
            INSERT OR REPLACE INTO graph_edges(
              graph_version_id, edge_id, source_node_id, target_node_id,
              edge_type, source_ref, valid_from
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                graph_version_id,
                edge_id,
                source_node_id,
                target_node_id,
                edge_type,
                source_ref,
                now,
            ),
        )
        return edge_id

    def _effective_nodes(self, graph_version_id: str) -> list[dict[str, Any]]:
        effective: dict[str, dict[str, Any]] = {}
        for version_id in self._lineage(graph_version_id):
            for row in self.conn.execute(
                "SELECT * FROM graph_nodes WHERE graph_version_id=? ORDER BY node_id", (version_id,)
            ).fetchall():
                effective.setdefault(str(row["node_id"]), dict(row))
        return [effective[key] for key in sorted(effective)]

    def _effective_edges(self, graph_version_id: str) -> list[dict[str, Any]]:
        effective: dict[str, dict[str, Any]] = {}
        for version_id in self._lineage(graph_version_id):
            for row in self.conn.execute(
                "SELECT * FROM graph_edges WHERE graph_version_id=? ORDER BY edge_id", (version_id,)
            ).fetchall():
                effective.setdefault(str(row["edge_id"]), dict(row))
        return [effective[key] for key in sorted(effective)]

    @staticmethod
    def _path(value: str) -> str:
        return str(PurePosixPath(value.replace("\\", "/")))

    @staticmethod
    def _node_signature(node: dict[str, Any]) -> str:
        return canonical_json(
            {
                key: node.get(key)
                for key in (
                    "node_type",
                    "label",
                    "truth_state",
                    "source_ref",
                    "valid_to",
                    "metadata_json",
                )
            }
        )
