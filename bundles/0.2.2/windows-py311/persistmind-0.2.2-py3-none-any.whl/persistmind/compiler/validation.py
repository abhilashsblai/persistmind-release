from __future__ import annotations

import glob
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from persistmind.config import Settings, is_ignored
from persistmind.application.pack_assembler import assemble_pack
from persistmind.snapshot.resolver import SUPPORTED_EXTS
from persistmind.utils import canonical_repo_path


class SeedResolutionError(ValueError):
    def __init__(self, status: str, path: str, detail: str):
        super().__init__(detail)
        self.status = status
        self.path = path
        self.detail = detail

    def as_result(self) -> dict[str, Any]:
        return {
            "ok": False,
            "status": self.status,
            "path": self.path,
            "error": self.detail,
            "schema_version": "persistmind.seed_resolution.v1",
        }


class PackValidationError(ValueError):
    def __init__(self, status: str, detail: str, diagnostics: dict[str, Any]):
        super().__init__(detail)
        self.status = status
        self.detail = detail
        self.diagnostics = diagnostics

    def as_result(self) -> dict[str, Any]:
        return {
            "ok": False,
            "status": self.status,
            "error": self.detail,
            "diagnostics": self.diagnostics,
            "schema_version": "persistmind.pack_validation.v1",
        }


@dataclass(frozen=True)
class SeedResolution:
    requested_seed_paths: list[str]
    expanded_seed_paths: list[str]
    indexed_seed_paths: list[str]
    intended_new_file_paths: list[str]
    requested_kinds: dict[str, str]

    def as_dict(self) -> dict[str, Any]:
        return {
            "requested_seed_paths": self.requested_seed_paths,
            "expanded_seed_paths": self.expanded_seed_paths,
            "indexed_seed_paths": self.indexed_seed_paths,
            "intended_new_file_paths": self.intended_new_file_paths,
            "requested_kinds": self.requested_kinds,
            "schema_version": "persistmind.seed_resolution.v1",
        }


def resolve_seed_paths(
    repo_root: Path,
    requested_paths: list[str],
    *,
    indexed_paths: set[str],
    settings: Settings,
) -> SeedResolution:
    requested: list[str] = []
    expanded: set[str] = set()
    intended: set[str] = set()
    kinds: dict[str, str] = {}
    limit = max(1, int(settings.reliability.seed_expansion_limit))
    for raw_path in requested_paths:
        try:
            normalized = canonical_repo_path(raw_path, repo_root, reject_outside=True)
        except ValueError as exc:
            raise SeedResolutionError("seed_path_outside_repo", str(raw_path), str(exc)) from exc
        if not normalized:
            continue
        requested.append(normalized)
        candidate = repo_root / normalized
        if candidate.exists():
            try:
                candidate.resolve().relative_to(repo_root.resolve())
            except (OSError, ValueError) as exc:
                raise SeedResolutionError(
                    "seed_path_outside_repo",
                    normalized,
                    "seed resolves outside repository",
                ) from exc
        has_glob = glob.has_magic(normalized)
        if has_glob:
            kinds[normalized] = "glob"
            matches = [
                Path(path)
                for path in glob.glob(
                    str(repo_root / normalized), recursive=True, include_hidden=True
                )
            ]
            supported = _supported_files(repo_root, matches, settings)
            if not supported:
                raise SeedResolutionError(
                    "seed_scope_empty", normalized, "glob expanded to no supported files"
                )
            expanded.update(supported)
        elif candidate.is_dir():
            kinds[normalized] = "directory"
            supported = _supported_files(repo_root, candidate.rglob("*"), settings)
            if not supported:
                raise SeedResolutionError(
                    "seed_scope_empty",
                    normalized,
                    "directory contains no supported, non-ignored files",
                )
            expanded.update(supported)
        elif candidate.is_file():
            kinds[normalized] = "file"
            if candidate.suffix.lower() not in SUPPORTED_EXTS or is_ignored(normalized, settings):
                raise SeedResolutionError(
                    "seed_unsupported", normalized, "seed file is unsupported or ignored"
                )
            expanded.add(normalized)
        elif candidate.suffix.lower() in SUPPORTED_EXTS:
            kinds[normalized] = "intended_new_file"
            intended.add(normalized)
            expanded.add(normalized)
        else:
            raise SeedResolutionError(
                "seed_path_missing",
                normalized,
                "missing seed is not an explicit supported file path",
            )
        if len(expanded) > limit:
            raise SeedResolutionError(
                "seed_expansion_limit",
                normalized,
                f"seed expansion exceeded configured limit {limit}",
            )
    expanded_paths = sorted(expanded)
    return SeedResolution(
        requested_seed_paths=sorted(set(requested)),
        expanded_seed_paths=expanded_paths,
        indexed_seed_paths=sorted(set(expanded_paths) & indexed_paths),
        intended_new_file_paths=sorted(intended),
        requested_kinds=kinds,
    )


class PackValidator:
    def validate(
        self,
        manifest: dict[str, Any],
        *,
        seed_resolution: SeedResolution,
        ready_generation: Any,
    ) -> dict[str, Any]:
        if ready_generation is None or str(ready_generation["index_status"]) != "ready":
            raise PackValidationError(
                "index_required", "pack requires a ready source generation", {}
            )
        source_fingerprint = str(
            ready_generation["source_index_fingerprint"]
            or ready_generation["validation_hash"]
            or ""
        )
        if not source_fingerprint:
            raise PackValidationError(
                "source_index_invalid",
                "ready source generation has no deterministic fingerprint",
                {"generation_id": ready_generation["generation_id"]},
            )
        items = list(manifest.get("items") or [])
        selected_paths = {str(item.get("path")) for item in items if str(item.get("path") or "")}
        indexed = set(seed_resolution.indexed_seed_paths)
        expanded = set(seed_resolution.expanded_seed_paths)
        intended = set(seed_resolution.intended_new_file_paths)
        selected_seed_paths = sorted(indexed & selected_paths)
        unselected = sorted(indexed - selected_paths)
        unindexed = sorted((expanded - indexed) | intended)
        if indexed and not unselected and not (set(unindexed) - intended):
            confidence = "seeded"
        elif expanded:
            confidence = "partial_seed"
        else:
            confidence = "unseeded"
        coverage = {
            **seed_resolution.as_dict(),
            "seeded_paths": seed_resolution.requested_seed_paths,
            "selected_seed_paths": selected_seed_paths,
            "unselected_seed_paths": unselected,
            "unindexed_seed_paths": unindexed,
            "missing_seed_paths": unindexed,
            "edit_scope_confidence": confidence,
        }
        if items:
            quality_status = "ready"
        elif intended:
            quality_status = "scope_only"
        else:
            raise PackValidationError(
                "pack_unusable",
                "pack has neither retrieved content nor explicit intended-new-file scope",
                {"seed_coverage": coverage, "item_count": 0},
            )
        quality = {
            "status": quality_status,
            "item_count": len(items),
            "requested_seed_count": len(seed_resolution.requested_seed_paths),
            "expanded_seed_count": len(seed_resolution.expanded_seed_paths),
            "indexed_seed_count": len(indexed),
            "intended_new_file_count": len(intended),
            "truncated_enrichment": any(
                item.get("kind") == "enrichment_truncated" for item in manifest.get("warnings", [])
            ),
            "schema_version": "persistmind.pack_quality.v1",
        }
        manifest["seed_resolution"] = seed_resolution.as_dict()
        manifest["seed_coverage"] = coverage
        manifest["source_generation_id"] = str(ready_generation["generation_id"])
        manifest["source_index_fingerprint"] = source_fingerprint
        manifest["pack_quality"] = quality
        manifest["lifecycle_status"] = quality_status
        return assemble_pack(manifest)


def _supported_files(repo_root: Path, paths: Any, settings: Settings) -> list[str]:
    supported: set[str] = set()
    for path in paths:
        try:
            if not path.is_file() or path.suffix.lower() not in SUPPORTED_EXTS:
                continue
            relative = path.resolve().relative_to(repo_root.resolve()).as_posix()
        except (OSError, ValueError):
            continue
        if not is_ignored(relative, settings):
            supported.add(relative)
    return sorted(supported)
