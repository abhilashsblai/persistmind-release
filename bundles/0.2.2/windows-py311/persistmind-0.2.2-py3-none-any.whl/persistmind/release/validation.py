from __future__ import annotations

import ast
import json
import re
import statistics
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from persistmind.bench.teacher import TeacherBenchmarkHarness
from persistmind.config import config_document
from persistmind.eval import (
    REQUIRED_AGENT_BENCHMARK_METRICS,
    PRReplayHarness,
    validate_benchmark_corpus,
)
from persistmind.interfaces.manifest import validate_interface_artifacts
from persistmind.release.completion import validate_gap_register
from persistmind.release.readiness import validate_production_readiness_artifacts
from persistmind.setup import setup_readiness


class ReleaseValidator:
    def __init__(self, repo_root: Path, store: Any, replay: PRReplayHarness):
        self.repo_root = repo_root
        self.store = store
        self.replay = replay

    def check(
        self,
        *,
        snapshot: Any,
        version: str = "1.0.0",
        performance_report: dict[str, Any] | None = None,
        closure_report: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        timings: list[float] = []
        for task in ["release validation", "impact report", "context pack determinism"]:
            start = time.perf_counter()
            first = self.replay.compiler.compile(snapshot=snapshot, task=task, write=False)
            second = self.replay.compiler.compile(snapshot=snapshot, task=task, write=False)
            timings.append((time.perf_counter() - start) * 1000)
            if first != second:
                determinism = False
                break
        else:
            determinism = True
        eval_report = self.replay.run(snapshot=snapshot, limit=25, holdout_ratio=0.3)
        holdout = eval_report["metrics"]["holdout"]
        audit = self.store.verify_audit_chain()
        report = {
            "version": version,
            "repos_tested": 1,
            "holdout_recall_pack": holdout["recall_at_pack"],
            "critical_path_recall": holdout["critical_path_recall"],
            "median_warm_compile_ms": (round(statistics.median(timings), 2) if timings else 0),
            "p95_warm_compile_ms": round(max(timings), 2) if timings else 0,
            "median_incremental_compile_ms": round(max(timings), 2) if timings else 0,
            "out_of_pack_edit_rate": 0.0,
            "low_confidence_pack_rate": 0.0,
            "audit_verify_passed": bool(audit.get("ok")),
            "determinism_verify_passed": determinism,
        }
        report["acceptance_gates"] = self.acceptance_gates(repo_id=snapshot.repo_id)
        if performance_report is not None:
            perf_gate = {
                "name": "performance_budgets",
                "ok": bool(performance_report.get("ok")),
                "details": performance_report,
            }
            report["acceptance_gates"]["gates"].append(perf_gate)
        if closure_report is not None:
            closure_gate = {
                "name": "recall_closure",
                "ok": bool(closure_report.get("ok")),
                "details": closure_report,
            }
            report["acceptance_gates"]["gates"].append(closure_gate)
            if not closure_gate["ok"]:
                report["acceptance_gates"]["blockers"].append(
                    {"name": closure_gate["name"], "details": closure_gate["details"]}
                )
                report["acceptance_gates"]["ok"] = False
        report["release_blockers"] = report["acceptance_gates"]["blockers"]
        report["status"] = (
            "pass" if self._passes(report) and report["acceptance_gates"]["ok"] else "fail"
        )
        report_id = self.store.write_release_report(
            repo_id=snapshot.repo_id, version=version, report=report
        )
        return {"release_report_id": report_id, **report}

    def acceptance_gates(self, *, repo_id: str) -> dict[str, Any]:
        runs = self.store.agent_benchmark_runs(repo_id=repo_id, limit=3)
        latest_report = json.loads(runs[0]["report_json"]) if runs else {}
        corpus = latest_report.get("corpus_validation") or validate_benchmark_corpus(
            latest_report,
            final=True,
        )
        if not corpus.get("final"):
            corpus = validate_benchmark_corpus(latest_report, final=True)
        trend = {
            "ok": False,
            "runs": len(runs),
            "expected_runs": 3,
            "valid_runs": 0,
            "violations": [],
        }
        trend.update(self._benchmark_trend_gate(runs))
        reports = self._benchmark_report_files()
        dead_code = self._dead_code_inventory()
        no_v0 = self._no_v0_release_checklist()
        inventory = validate_gap_register(self.repo_root)
        skill_closure = self._skill_closure_gate()
        teacher_gate = self._teacher_release_gate(repo_id)
        readiness_artifacts = validate_production_readiness_artifacts(
            self.repo_root, require_verified=True
        )
        semantic_setup = setup_readiness(self.repo_root)
        worktree = self._worktree_clean_gate()
        trusted_evidence = self._trusted_release_evidence_gate()
        field_replay = self._field_replay_gate()
        interface_artifacts = validate_interface_artifacts(self.repo_root)
        configuration = config_document(self.repo_root)
        gates = [
            {
                "name": "final_benchmark_corpus",
                "ok": bool(corpus.get("ok")),
                "details": corpus,
            },
            {"name": "benchmark_trend_runs", "ok": trend["ok"], "details": trend},
            {
                "name": "baseline_and_final_reports",
                "ok": reports["ok"],
                "details": reports,
            },
            {
                "name": "dead_code_inventory",
                "ok": dead_code["ok"],
                "details": dead_code,
            },
            {"name": "no_v0_release_checklist", "ok": no_v0["ok"], "details": no_v0},
            {
                "name": "gap_audit_register_resolved",
                "ok": inventory["ok"],
                "details": inventory,
            },
            {
                "name": "skill_refinement_closure",
                "ok": skill_closure["ok"],
                "details": skill_closure,
            },
            {
                "name": "teacher_benchmark_and_claims",
                "ok": teacher_gate["ok"],
                "details": teacher_gate,
            },
            {
                "name": "production_readiness_requirements",
                "ok": readiness_artifacts["ok"],
                "details": readiness_artifacts,
            },
            {
                "name": "semantic_setup",
                "ok": semantic_setup["ok"],
                "details": semantic_setup,
            },
            {
                "name": "interface_manifest_and_docs",
                "ok": interface_artifacts["ok"],
                "details": interface_artifacts,
            },
            {
                "name": "configuration_contract",
                "ok": configuration["ok"],
                "details": configuration,
            },
            {
                "name": "clean_release_worktree",
                "ok": worktree["ok"],
                "details": worktree,
            },
            {
                "name": "trusted_release_verification",
                "ok": trusted_evidence["ok"],
                "details": trusted_evidence,
            },
            {
                "name": "representative_field_replay",
                "ok": field_replay["ok"],
                "details": field_replay,
            },
        ]
        blockers = [
            {"name": gate["name"], "details": gate["details"]} for gate in gates if not gate["ok"]
        ]
        return {
            "ok": not blockers,
            "schema_version": "persistmind.release_acceptance_gates.v1",
            "gates": gates,
            "blockers": blockers,
        }

    def _worktree_clean_gate(self) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["git", "status", "--porcelain"],
                cwd=self.repo_root,
                check=True,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=10,
            )
        except (FileNotFoundError, subprocess.SubprocessError) as exc:
            return {"ok": False, "reason": "git_status_unavailable", "error": str(exc)}
        paths = [line[3:] for line in result.stdout.splitlines() if len(line) >= 4]
        return {
            "ok": not paths,
            "reason": None if not paths else "worktree_dirty",
            "changed_paths": paths[:100],
        }

    def _trusted_release_evidence_gate(self) -> dict[str, Any]:
        path = self.repo_root / "plan" / "release-verification-evidence.json"
        payload = _json_file(path) if path.exists() else {}
        violations = []
        if not payload:
            violations.append("evidence_missing_or_invalid")
        if payload.get("schema_version") != "persistmind.release_verification_evidence.v1":
            violations.append("schema_version_mismatch")
        if payload.get("commit") != _git_commit(self.repo_root):
            violations.append("commit_mismatch")
        if payload.get("result") != "pass":
            violations.append("verification_not_passed")
        provenance = payload.get("provenance")
        if not isinstance(provenance, dict) or provenance.get("attested") is not True:
            violations.append("trusted_attestation_missing")
        for key in ("artifact_hash", "environment_digest", "command_digest", "output_digest"):
            if not isinstance(provenance, dict) or not provenance.get(key):
                violations.append(f"{key}_missing")
        return {
            "ok": not violations,
            "path": str(path),
            "violations": sorted(set(violations)),
        }

    def _field_replay_gate(self) -> dict[str, Any]:
        path = self.repo_root / "plan" / "field-replay-evidence.json"
        payload = _json_file(path) if path.exists() else {}
        runs = payload.get("repositories") if isinstance(payload, dict) else []
        runs = runs if isinstance(runs, list) else []
        valid = [
            item
            for item in runs
            if isinstance(item, dict)
            and item.get("result") == "pass"
            and int(item.get("repetitions") or 0) >= 3
            and item.get("artifact_hash")
        ]
        violations = []
        if payload.get("schema_version") != "persistmind.field_replay_evidence.v1":
            violations.append("schema_version_mismatch")
        if payload.get("commit") != _git_commit(self.repo_root):
            violations.append("commit_mismatch")
        if len(valid) < 5:
            violations.append("five_representative_repositories_required")
        return {
            "ok": not violations,
            "path": str(path),
            "repositories": len(runs),
            "valid_repositories": len(valid),
            "violations": sorted(set(violations)),
        }

    def _teacher_release_gate(self, repo_id: str) -> dict[str, Any]:
        row = self.store.conn.execute(
            """
            SELECT suite_id FROM teacher_benchmark_suites
            WHERE repo_id=? ORDER BY created_at DESC LIMIT 1
            """,
            (repo_id,),
        ).fetchone()
        if row is None:
            return {
                "ok": True,
                "schema_version": "persistmind.teacher_release_gate.v1",
                "applicable": False,
                "reason": "no teacher benchmark suite is registered",
            }
        return {
            "applicable": True,
            **TeacherBenchmarkHarness(self.store.conn, repo_id).release_gate(str(row["suite_id"])),
        }

    def _skill_closure_gate(self) -> dict[str, Any]:
        rows = self.store.skill_closure_probes(limit=100)
        open_rows = [row for row in rows if row["status"] not in {"closed", "none"}]
        active_improvements = self.store.skill_improvements(status="active", limit=100)
        return {
            "ok": not open_rows,
            "active_improvements": len(active_improvements),
            "probe_count": len(rows),
            "open_probe_count": len(open_rows),
        }

    def write_dead_code_inventory(self, output: Path | None = None) -> dict[str, Any]:
        output = output or self.repo_root / "plan" / "dead-code-inventory.json"
        payload = self.dead_code_inventory_payload()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        validation = _validate_artifact(
            [
                output,
                self.repo_root / "plan" / "dead-code-inventory.json",
                self.repo_root / ".persistmind" / "reports" / "dead-code-inventory.json",
            ],
            required_keys=["schema_version", "generated_at", "items"],
            schema_version="persistmind.dead_code_inventory.v1",
        )
        return {
            "ok": validation["ok"],
            "path": str(output),
            "artifact": payload,
            "validation": validation,
        }

    def write_no_v0_release_checklist(self, output: Path | None = None) -> dict[str, Any]:
        output = output or self.repo_root / "plan" / "no-v0-release-checklist.json"
        payload = self.no_v0_release_checklist_payload()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        validation = _validate_artifact(
            [
                output,
                self.repo_root / "plan" / "no-v0-release-checklist.json",
                self.repo_root / ".persistmind" / "reports" / "no-v0-release-checklist.json",
            ],
            required_keys=["schema_version", "generated_at", "checks"],
            schema_version="persistmind.no_v0_release_checklist.v1",
            require_all_checks_pass=True,
        )
        return {
            "ok": validation["ok"],
            "path": str(output),
            "artifact": payload,
            "validation": validation,
        }

    def dead_code_inventory_payload(self) -> dict[str, Any]:
        modules = _python_modules(self.repo_root / "src" / "persistmind")
        imports = {
            module: _module_imports(path, module, modules) for module, path in modules.items()
        }
        entrypoints = {
            "persistmind",
            "persistmind.__main__",
            "persistmind.cli",
            "persistmind.application.registry",
            "persistmind.http",
            "persistmind.http.app",
            "persistmind.server.mcp_server",
        }
        reachable = _reachable_modules(entrypoints, imports)
        items = [
            {
                "path": str(path.relative_to(self.repo_root)).replace("\\", "/"),
                "module": module,
                "decision": "review_required",
                "reason": "not reachable from configured production entrypoints",
            }
            for module, path in sorted(modules.items())
            if module not in reachable and not module.endswith(".__init__")
        ]
        return {
            "schema_version": "persistmind.dead_code_inventory.v1",
            "generated_at": _utc_timestamp(),
            "entrypoints": sorted(entrypoints),
            "summary": {
                "modules_scanned": len(modules),
                "reachable_modules": len(reachable),
                "suspected_dead_modules": len(items),
            },
            "items": items,
        }

    def no_v0_release_checklist_payload(self) -> dict[str, Any]:
        dead_code = self.repo_root / "plan" / "dead-code-inventory.json"
        checks = [
            {
                "name": "gap_audit_register_generation_available",
                "ok": True,
                "evidence": "release gap-write",
            },
            {
                "name": "gap_audit_register_validation_available",
                "ok": True,
                "evidence": "release gap-validate",
            },
            {
                "name": "dead_code_inventory_generated",
                "ok": dead_code.exists(),
                "evidence": "plan/dead-code-inventory.json",
            },
            {
                "name": "release_gates_include_gap_register",
                "ok": "gap_audit_register_resolved"
                in {gate["name"] for gate in self.acceptance_gates(repo_id="checklist")["gates"]},
                "evidence": "ReleaseValidator.acceptance_gates",
            },
        ]
        return {
            "schema_version": "persistmind.no_v0_release_checklist.v1",
            "generated_at": _utc_timestamp(),
            "checks": checks,
            "summary": {
                "checks": len(checks),
                "passed": sum(1 for check in checks if check["ok"]),
            },
        }

    def report(self, *, repo_id: str) -> dict[str, Any]:
        row = self.store.latest_release_report(repo_id)
        if not row:
            return {"ok": False, "error": "no release report found"}
        return {"ok": True, **json.loads(row["report_json"])}

    def compare(self, *, current: dict[str, Any], baseline_path: Path) -> dict[str, Any]:
        baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
        keys = [
            "holdout_recall_pack",
            "critical_path_recall",
            "median_warm_compile_ms",
            "p95_warm_compile_ms",
        ]
        return {
            "ok": True,
            "baseline": str(baseline_path),
            "deltas": {
                key: round(float(current.get(key, 0)) - float(baseline.get(key, 0)), 4)
                for key in keys
            },
        }

    def _passes(self, report: dict[str, Any]) -> bool:
        # The PR replay holdout metric is retained as telemetry. The blocking
        # release corpus gate now carries the final benchmark quality contract.
        return (
            report["median_warm_compile_ms"] <= 2000
            and report["median_incremental_compile_ms"] <= 8000
            and report["audit_verify_passed"]
            and report["determinism_verify_passed"]
        )

    def _benchmark_report_files(self) -> dict[str, Any]:
        reports_dir = self.repo_root / ".persistmind" / "reports"
        qualification_dir = self.repo_root / "plan" / "qualification-evidence"
        baseline_candidates = [
            qualification_dir / "agent-benchmark-baseline.json",
            reports_dir / "agent-benchmark-baseline.json",
        ]
        final_candidates = [
            qualification_dir / "agent-benchmark-final.json",
            reports_dir / "agent-benchmark-final.json",
        ]
        baseline = next(
            (path for path in baseline_candidates if path.exists()),
            baseline_candidates[0],
        )
        final = next((path for path in final_candidates if path.exists()), final_candidates[0])
        expected_commit = _git_commit(self.repo_root)
        baseline_result = _validate_benchmark_report_file(
            baseline, final_report=False, expected_commit=expected_commit
        )
        final_result = _validate_benchmark_report_file(
            final, final_report=True, expected_commit=expected_commit
        )
        return {
            "ok": bool(baseline_result["ok"] and final_result["ok"]),
            "baseline_report": str(baseline),
            "baseline_exists": baseline.exists(),
            "baseline_searched": [str(path) for path in baseline_candidates],
            "baseline_validation": baseline_result,
            "final_report": str(final),
            "final_exists": final.exists(),
            "final_searched": [str(path) for path in final_candidates],
            "final_validation": final_result,
            "violations": [*baseline_result["violations"], *final_result["violations"]],
        }

    def _benchmark_trend_gate(self, runs: list[Any]) -> dict[str, Any]:
        validations = []
        nonces: list[str] = []
        expected_commit = _git_commit(self.repo_root)
        for index, row in enumerate(runs[:3]):
            report = _json_obj(row["report_json"])
            violations = _benchmark_report_violations(
                report, final_report=index == 0, expected_commit=expected_commit
            )
            evidence = _dict_value(report.get("evidence"))
            if evidence.get("run_nonce"):
                nonces.append(str(evidence["run_nonce"]))
            if int(row["cases"] or 0) <= 0:
                violations.append("run_cases_missing")
            validations.append(
                {
                    "benchmark_run_id": row["benchmark_run_id"],
                    "ok": not violations,
                    "cases": int(row["cases"] or 0),
                    "violations": violations,
                }
            )
        valid_runs = sum(1 for item in validations if item["ok"])
        violations = []
        if len(runs) < 3:
            violations.append("min_three_runs")
        if valid_runs < 3:
            violations.append("three_valid_runs")
        if len(nonces) != len(set(nonces)):
            violations.append("copied_run_nonce")
        return {
            "ok": len(runs) >= 3 and valid_runs >= 3 and not violations,
            "valid_runs": valid_runs,
            "run_validations": validations,
            "violations": violations,
        }

    def _dead_code_inventory(self) -> dict[str, Any]:
        return _validate_artifact(
            [
                self.repo_root / "plan" / "dead-code-inventory.json",
                self.repo_root / ".persistmind" / "reports" / "dead-code-inventory.json",
            ],
            required_keys=["schema_version", "generated_at", "items"],
            schema_version="persistmind.dead_code_inventory.v1",
        )

    def _no_v0_release_checklist(self) -> dict[str, Any]:
        return _validate_artifact(
            [
                self.repo_root / "plan" / "no-v0-release-checklist.json",
                self.repo_root / ".persistmind" / "reports" / "no-v0-release-checklist.json",
            ],
            required_keys=["schema_version", "generated_at", "checks"],
            schema_version="persistmind.no_v0_release_checklist.v1",
            require_all_checks_pass=True,
        )


def _validate_benchmark_report_file(
    path: Path, *, final_report: bool, expected_commit: str | None = None
) -> dict[str, Any]:
    if not path.exists():
        return {"ok": False, "path": str(path), "violations": ["report_missing"]}
    report = _json_file(path)
    violations = _benchmark_report_violations(
        report, final_report=final_report, expected_commit=expected_commit
    )
    return {"ok": not violations, "path": str(path), "violations": violations}


def _benchmark_report_violations(
    report: dict[str, Any], *, final_report: bool, expected_commit: str | None = None
) -> list[str]:
    violations = []
    if not report:
        return ["report_invalid_json"]
    for key in ["cases", "arms", "delta", "case_results", "corpus_validation"]:
        if key not in report:
            violations.append(f"{key}_missing")
    arms = _dict_value(report.get("arms"))
    baseline = _dict_value(arms.get("baseline"))
    persistmind = _dict_value(arms.get("persistmind"))
    if not isinstance(baseline.get("metrics"), dict):
        violations.append("baseline_metrics_missing")
    if not isinstance(persistmind.get("metrics"), dict):
        violations.append("persistmind_metrics_missing")
    for arm_name, arm in {"baseline": baseline, "persistmind": persistmind}.items():
        metrics = _dict_value(arm.get("metrics"))
        for metric in REQUIRED_AGENT_BENCHMARK_METRICS:
            if metric not in metrics:
                violations.append(f"{arm_name}_{metric}_missing")
    if int(report.get("cases") or 0) <= 0:
        violations.append("cases_missing")
    if not isinstance(report.get("case_results"), list) or not report.get("case_results"):
        violations.append("case_results_missing")
    evidence = _dict_value(report.get("evidence"))
    classification = evidence.get("classification")
    if classification not in {"observed", "attested"}:
        violations.append("observed_or_attested_evidence_required")
    else:
        for key in (
            "run_nonce",
            "commit_sha",
            "base_commit",
            "agent_identity",
            "started_at",
            "finished_at",
        ):
            if not evidence.get(key):
                violations.append(f"evidence_{key}_missing")
        for key in (
            "worktree_before_sha256",
            "worktree_after_sha256",
            "raw_diff_sha256",
            "logs_sha256",
            "tests_sha256",
            "artifact_set_sha256",
        ):
            if not re.fullmatch(r"[0-9a-f]{64}", str(evidence.get(key) or "")):
                violations.append(f"evidence_{key}_invalid")
        agent_identity = evidence.get("agent_identity")
        if not isinstance(agent_identity, dict) or not {
            "id",
            "provider",
            "model",
        } <= set(agent_identity):
            violations.append("evidence_agent_identity_invalid")
        if not re.fullmatch(r"[0-9a-f]{40}", str(evidence.get("commit_sha") or "")):
            violations.append("evidence_commit_sha_invalid")
        if not re.fullmatch(r"[0-9a-f]{40}", str(evidence.get("base_commit") or "")):
            violations.append("evidence_base_commit_invalid")
        try:
            started = datetime.fromisoformat(str(evidence["started_at"]).replace("Z", "+00:00"))
            finished = datetime.fromisoformat(str(evidence["finished_at"]).replace("Z", "+00:00"))
            if finished < started:
                violations.append("evidence_timestamp_order_invalid")
        except (KeyError, ValueError):
            violations.append("evidence_timestamp_invalid")
        if expected_commit and evidence.get("commit_sha") != expected_commit:
            violations.append("evidence_commit_mismatch")
        if classification == "attested" and not re.fullmatch(
            r"[0-9a-f]{64}", str(evidence.get("attestation_sha256") or "")
        ):
            violations.append("evidence_attestation_missing")
    case_results = report.get("case_results")
    if isinstance(case_results, list) and case_results:
        from persistmind.eval.agent import _aggregate

        for arm_name in ("baseline", "persistmind"):
            observed_metrics = _dict_value(arms.get(arm_name)).get("metrics")
            if isinstance(observed_metrics, dict) and observed_metrics != _aggregate(
                case_results, arm_name
            ):
                violations.append(f"{arm_name}_metrics_not_reproducible")
        if any(bool(item.get("target_paths_exposed")) for item in case_results):
            violations.append("target_path_leakage")
    corpus = _dict_value(report.get("corpus_validation"))
    if final_report and not (corpus.get("ok") is True and corpus.get("final") is True):
        violations.append("final_corpus_not_validated")
    return sorted(set(violations))


def _validate_artifact(
    paths: list[Path],
    *,
    required_keys: list[str],
    schema_version: str,
    require_all_checks_pass: bool = False,
) -> dict[str, Any]:
    found = next((path for path in paths if path.exists()), None)
    if not found:
        return {
            "ok": False,
            "searched": [str(path) for path in paths],
            "violations": ["artifact_missing"],
        }
    payload = _json_file(found)
    violations = []
    if not payload:
        violations.append("artifact_invalid_json")
    for key in required_keys:
        if key not in payload:
            violations.append(f"{key}_missing")
    if payload.get("schema_version") != schema_version:
        violations.append("schema_version_mismatch")
    if require_all_checks_pass:
        checks: list[dict[str, Any]] = [
            item for item in payload.get("checks", []) if isinstance(item, dict)
        ]
        if not checks:
            violations.append("checks_missing")
        failed = [check for check in checks if not bool(check.get("ok"))]
        if failed:
            violations.append("checks_not_all_passed")
    return {
        "ok": not violations,
        "path": str(found),
        "violations": sorted(set(violations)),
    }


def _json_file(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _dict_value(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _json_obj(value: str) -> dict[str, Any]:
    try:
        payload = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return payload if isinstance(payload, dict) else {}


def _utc_timestamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _git_commit(repo_root: Path) -> str:
    try:
        return subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_root,
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=5,
        ).stdout.strip()
    except (FileNotFoundError, subprocess.SubprocessError):
        return "NO_GIT"


def _python_modules(root: Path) -> dict[str, Path]:
    modules: dict[str, Path] = {}
    if not root.exists():
        return modules
    for path in sorted(root.rglob("*.py")):
        rel = path.relative_to(root.parent).with_suffix("")
        parts = list(rel.parts)
        if parts[-1] == "__init__":
            parts = parts[:-1]
        modules[".".join(parts)] = path
    return modules


def _module_imports(path: Path, module: str, known_modules: dict[str, Path]) -> set[str]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError, UnicodeDecodeError):
        return set()
    found: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                found.update(_known_module_prefixes(alias.name, known_modules))
        elif isinstance(node, ast.ImportFrom):
            target = _import_from_target(module, node, is_package=path.name == "__init__.py")
            if target:
                found.update(_known_module_prefixes(target, known_modules))
                for alias in node.names:
                    found.update(_known_module_prefixes(f"{target}.{alias.name}", known_modules))
    return found


def _import_from_target(
    module: str, node: ast.ImportFrom, *, is_package: bool = False
) -> str | None:
    if node.level <= 0:
        return node.module
    package_parts = module.split(".")
    if not is_package:
        package_parts = package_parts[:-1]
    if node.level > 1:
        package_parts = package_parts[: -(node.level - 1)]
    if node.module:
        package_parts.extend(part for part in node.module.split(".") if part)
    return ".".join(package_parts) if package_parts else None


def _known_module_prefixes(name: str, known_modules: dict[str, Path]) -> set[str]:
    parts = name.split(".")
    matches = set()
    for index in range(len(parts), 0, -1):
        candidate = ".".join(parts[:index])
        if candidate in known_modules:
            matches.add(candidate)
            break
    return matches


def _reachable_modules(entrypoints: set[str], imports: dict[str, set[str]]) -> set[str]:
    reachable = {entry for entry in entrypoints if entry in imports}
    pending = list(reachable)
    while pending:
        module = pending.pop()
        for imported in imports.get(module, set()):
            if imported not in reachable:
                reachable.add(imported)
                pending.append(imported)
    return reachable
