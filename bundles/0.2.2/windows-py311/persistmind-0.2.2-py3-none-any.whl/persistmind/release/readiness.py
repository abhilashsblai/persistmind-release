from __future__ import annotations

import ast
import json
import re
import subprocess
from pathlib import Path
from typing import Any, Iterable

from persistmind.release.scope import (
    WINDOWS_RELEASE_SCOPE_PATH,
    WINDOWS_RELEASE_SCOPE_SCHEMA,
    load_windows_release_scope,
    validate_support_matrix_against_scope,
    windows_support_matrix,
)
from persistmind.release.agents import (
    AGENT_COMPATIBILITY_PATH,
    load_agent_compatibility,
    validate_agent_compatibility,
)


INVENTORY_SCHEMA = "persistmind.production_inventory.v1"
REQUIREMENTS_SCHEMA = "persistmind.production_requirements.v1"
SUPPORT_SCHEMA = "persistmind.support_matrix.v1"
SLO_SCHEMA = "persistmind.slo_baseline.v1"

_PREVIEW_AREAS = {
    "anticipation",
    "cie",
    "judgment",
    "nextgen",
    "orchestration",
    "selfimprove",
}

REQUIREMENT_CLASSIFICATIONS = frozenset(
    {"beta_blocker", "production_blocker", "deferred_feature", "verified", "invalid_or_duplicate"}
)


def _requirement_ids(prefix: str, start: int, end: int) -> set[str]:
    return {f"{prefix}{index:02d}" for index in range(start, end + 1)}


_VERIFIED_REQUIREMENTS = set().union(
    _requirement_ids("PR-P0-", 2, 10),
    _requirement_ids("PR-P1-", 1, 10),
    _requirement_ids("PR-P2-", 1, 11),
    _requirement_ids("PR-P3-", 1, 9),
    _requirement_ids("PR-P4-", 1, 8),
    _requirement_ids("PR-P5-", 1, 11),
    _requirement_ids("PR-P6-", 1, 7),
    {"PR-P7-01", "PR-P7-02", "PR-P7-03", "PR-P7-04", "PR-P7-08"},
    {"PR-P8-01", "PR-P8-02", "PR-P8-05", "PR-P8-08"},
    {"PR-P9-01", "PR-P9-02", "PR-P9-03"},
    {"PR-DOD-01", *(_requirement_ids("PR-DOD-", 3, 13)), "PR-DOD-17", "PR-DOD-19"},
    _requirement_ids("RES-ACC-", 1, 13),
)
_BETA_BLOCKER_REQUIREMENTS = {
    "PR-P8-03",
    "PR-P8-06",
    "PR-P8-07",
    "PR-P9-06",
    "PR-P9-07",
    "PR-DOD-15",
    "PR-DOD-16",
    "PR-DOD-18",
    "PR-DOD-20",
    "RES-ACC-14",
}
_DEFERRED_REQUIREMENTS = {"PR-P7-07", "PR-P7-09"}
_INVALID_REQUIREMENTS = {"PR-P0-01", "PR-DOD-02", "RES-DOD-01"}
_PRODUCTION_BLOCKER_REQUIREMENTS = set().union(
    {"PR-P7-05", "PR-P7-06", "PR-P8-04", "PR-P9-04", "PR-P9-05"},
    {"PR-DOD-14"},
    _requirement_ids("RES-ADV-", 1, 18),
    {"RES-ACC-15"},
)

_REQUIREMENT_EVIDENCE = {
    "phase_0": [
        "plans/remediation/main-issues-remediation-plan.md",
        "tests/test_release_readiness_truth.py",
        "tests/test_setup_semantic_readiness.py",
    ],
    "phase_1": [
        "tests/test_http_authentication.py",
        "tests/test_http_live_authentication.py",
        "tests/test_governance.py",
    ],
    "phase_2": ["tests/test_storage_migration.py", "tests/test_storage_schema_upgrade.py"],
    "phase_3": ["tests/test_source_view_isolation.py", "tests/test_source_chunk_integrity.py"],
    "phase_4": ["tests/test_pack_finalization.py", "tests/test_write_scope_assessment.py"],
    "phase_5": ["tests/test_storage_recovery.py", "tests/test_storage_nextgen_backup.py"],
    "phase_6": ["tests/test_storage_lifecycle.py", "tests/test_typed_workflow_evidence.py"],
    "phase_7": ["tests/test_action_registry.py", "tests/test_learning_safety.py"],
    "phase_8": [
        "tests/test_release_identity.py",
        "tests/test_update_transaction.py",
        "tests/test_release_bootstrap.py",
    ],
    "phase_9": [
        "tests/test_operational_limits.py",
        "tests/test_operation_deadlines.py",
        "SUPPORT.md",
        "scripts/how-to-install_update.md",
    ],
    "final": [
        "plans/remediation/main-issues-remediation-plan.md",
        "plans/remediation/evidence/2026-07-16-qualification.md",
    ],
    "resilience": [
        "tests/test_storage_recovery.py",
        "tests/test_storage_lifecycle.py",
        "tests/test_pack_finalization.py",
    ],
}


def write_phase0_artifacts(repo_root: Path) -> dict[str, Any]:
    repo_root = repo_root.resolve()
    outputs = {
        "source_surface_inventory": (
            repo_root / "plan" / "source-surface-inventory.json",
            generate_source_surface_inventory(repo_root),
        ),
        "production_readiness_requirements": (
            repo_root / "plan" / "production-readiness-requirements.json",
            generate_requirements_register(repo_root),
        ),
        "support_matrix": (
            repo_root / "plan" / "support-matrix.json",
            generate_support_matrix(repo_root),
        ),
        "slo_baseline": (
            repo_root / "plan" / "slo-baseline.json",
            generate_slo_baseline(repo_root),
        ),
    }
    written: list[str] = []
    for path, payload in outputs.values():
        path.parent.mkdir(parents=True, exist_ok=True)
        text = json.dumps(payload, indent=2, sort_keys=True) + "\n"
        if not path.exists() or path.read_text(encoding="utf-8") != text:
            path.write_text(text, encoding="utf-8")
        written.append(path.relative_to(repo_root).as_posix())
    return {
        "ok": True,
        "schema_version": "persistmind.phase0_artifacts.v1",
        "written": sorted(written),
        "validation": validate_production_readiness_artifacts(repo_root, require_verified=False),
    }


def generate_source_surface_inventory(repo_root: Path) -> dict[str, Any]:
    commit = _git_commit(repo_root)
    source_root = repo_root / "src" / "persistmind"
    modules = []
    for path in sorted(source_root.rglob("*.py")):
        relative = path.relative_to(repo_root).as_posix()
        area = _source_area(path.relative_to(source_root))
        maturity = "preview" if area in _PREVIEW_AREAS else "stable"
        modules.append(
            {
                "path": relative,
                "owner": f"persistmind:{area}",
                "profile": "experimental_intelligence" if maturity == "preview" else "local_core",
                "maturity": maturity,
            }
        )

    tests = [
        {
            "path": path.relative_to(repo_root).as_posix(),
            "owner": f"tests:{path.stem.removeprefix('test_')}",
            "profile": "local_core",
            "maturity": "stable",
        }
        for path in sorted((repo_root / "tests").glob("test_*.py"))
    ]
    schema_objects = _schema_inventory(
        repo_root / "src" / "persistmind" / "storage" / "resources" / "schemas",
        repo_root=repo_root,
    )
    mcp_path = repo_root / "src" / "persistmind" / "server" / "mcp_server.py"
    public_operations = [
        *_cli_operations(repo_root / "src" / "persistmind" / "cli.py"),
        *_decorated_operations(
            mcp_path,
            surface="mcp",
            decorator="tool",
            profile="local_core",
            maturity="stable",
            allowed_operations=_declared_string_set(mcp_path, "READ_ONLY_MCP_TOOLS"),
        ),
        *_http_operations(repo_root / "src" / "persistmind" / "http" / "app.py"),
    ]
    required_surfaces = [
        ".codex/config.toml",
        ".codex/hooks.json",
        ".codex/agents/persistmind-explorer.toml",
        ".codex/agents/persistmind-worker.toml",
        ".codex/agents/persistmind-reviewer.toml",
        ".codex/agents/persistmind-verifier.toml",
        ".persistmind/codex/hooks/persistmind_hook.py",
        ".persistmind/mcp/codex.config.toml",
        ".persistmind/mcp/claude-code.ps1",
        ".mcp.json",
        ".claude/settings.json",
        ".claude/skills/persistmind-loop/SKILL.md",
        ".gemini/settings.json",
        ".persistmind/gemini/hooks/persistmind_hook.py",
        ".grok/config.toml",
        ".grok/plugins/persistmind/.grok-plugin/plugin.json",
        ".grok/plugins/persistmind/hooks/hooks.json",
        "AGENTS.md",
        "CLAUDE.md",
        "GEMINI.md",
        "persistmind.capabilities.yaml",
        "features/features.xlsx",
        "scripts/persistmind-self-repair.ps1",
    ]
    generated_roots = [
        ".codex/agents",
        ".claude/agents",
        ".claude/skills",
        ".grok/plugins/persistmind",
    ]
    generated_surfaces = set(required_surfaces)
    for root in generated_roots:
        base = repo_root / root
        if base.exists():
            generated_surfaces.update(
                path.relative_to(repo_root).as_posix() for path in base.rglob("*") if path.is_file()
            )
    surface_rows = [
        {
            "path": path,
            "owner": "persistmind:setup",
            "profile": "local_core",
            "maturity": "stable",
            "present": (repo_root / path).exists(),
        }
        for path in sorted(generated_surfaces)
    ]
    payload: dict[str, Any] = {
        "schema_version": INVENTORY_SCHEMA,
        "generated_for_commit": commit,
        "source_modules": modules,
        "database_objects": schema_objects,
        "public_operations": sorted(
            _dedupe(public_operations, key="id"), key=lambda item: item["id"]
        ),
        "generated_surfaces": surface_rows,
        "test_families": tests,
    }
    payload["counts"] = {
        "source_modules": len(modules),
        "database_objects": len(schema_objects),
        "public_operations": len(payload["public_operations"]),
        "generated_surfaces": len(surface_rows),
        "test_families": len(tests),
    }
    return payload


def generate_requirements_register(repo_root: Path) -> dict[str, Any]:
    commit = _git_commit(repo_root)
    pending = repo_root / "plans" / "pending-work-implementation-plan.md"
    resilience = repo_root / "plans" / "ctx-sqlite-index-pack-resilience-plan.md"
    rows: list[dict[str, Any]] = []

    pending_text = pending.read_text(encoding="utf-8")
    phase_pattern = re.compile(
        r"^## \d+\. Phase (?P<number>\d+) [^\n]*\n(?P<body>.*?)(?=^## \d+\. Phase|^## 14\.)",
        re.MULTILINE | re.DOTALL,
    )
    for phase_match in phase_pattern.finditer(pending_text):
        phase = int(phase_match.group("number"))
        body = phase_match.group("body")
        implementation = _section(body, "### Implementation", "###")
        for index, description in enumerate(_numbered_items(implementation), start=1):
            rows.append(
                _requirement_row(
                    f"PR-P{phase}-{index:02d}",
                    description,
                    source=f"plans/pending-work-implementation-plan.md#phase-{phase}",
                    phase=f"phase_{phase}",
                    owner=f"phase:{phase}",
                    commit=commit,
                )
            )

    final_dod = _section(pending_text, "## 16. Final definition of done", "## 17.")
    for index, description in enumerate(_numbered_items(final_dod), start=1):
        rows.append(
            _requirement_row(
                f"PR-DOD-{index:02d}",
                description,
                source="plans/pending-work-implementation-plan.md#final-definition-of-done",
                phase="final",
                owner="release",
                commit=commit,
            )
        )

    if resilience.is_file():
        resilience_text = resilience.read_text(encoding="utf-8")
        imported_sections = [
            ("ADV", "### Required adversarial cases", "### Verification commands", "fault"),
            ("ACC", "## 12. Acceptance criteria", "## 13.", "acceptance"),
        ]
        for prefix, start, end, test_kind in imported_sections:
            section = _section(resilience_text, start, end)
            for index, description in enumerate(_numbered_items(section), start=1):
                row = _requirement_row(
                    f"RES-{prefix}-{index:02d}",
                    description,
                    source=f"plans/ctx-sqlite-index-pack-resilience-plan.md#{prefix.lower()}",
                    phase="resilience",
                    owner="persistmind:store",
                    commit=commit,
                )
                row["tests"][test_kind] = ["required"]
                rows.append(row)
        dod = _section(resilience_text, "## 16. Definition of done", "## Appendix")
        rows.append(
            _requirement_row(
                "RES-DOD-01",
                " ".join(line.strip() for line in dod.splitlines() if line.strip()),
                source="plans/ctx-sqlite-index-pack-resilience-plan.md#definition-of-done",
                phase="resilience",
                owner="persistmind:store",
                commit=commit,
            )
        )
    else:
        # The historical resilience plan was intentionally retired after its
        # requirements entered the durable machine-readable ledger. Preserve
        # those reviewed rows without treating a deleted prose file as a live
        # release dependency.
        previous_path = repo_root / "plan" / "production-readiness-requirements.json"
        try:
            previous_rows = json.loads(previous_path.read_text(encoding="utf-8")).get(
                "requirements", []
            )
        except (OSError, json.JSONDecodeError):
            previous_rows = []
        rows.extend(
            dict(row) for row in previous_rows if str(row.get("id") or "").startswith("RES-")
        )
    known_ids = set().union(
        _VERIFIED_REQUIREMENTS,
        _BETA_BLOCKER_REQUIREMENTS,
        _PRODUCTION_BLOCKER_REQUIREMENTS,
        _DEFERRED_REQUIREMENTS,
        _INVALID_REQUIREMENTS,
    )
    observed_ids = {str(row["id"]) for row in rows}
    duplicate_ids = [
        item
        for item in known_ids
        if sum(
            item in group
            for group in (
                _VERIFIED_REQUIREMENTS,
                _BETA_BLOCKER_REQUIREMENTS,
                _PRODUCTION_BLOCKER_REQUIREMENTS,
                _DEFERRED_REQUIREMENTS,
                _INVALID_REQUIREMENTS,
            )
        )
        != 1
    ]
    if duplicate_ids:
        raise ValueError(
            "requirements have multiple classifications: " + ", ".join(sorted(duplicate_ids))
        )
    if known_ids != observed_ids:
        missing = sorted(observed_ids - known_ids)
        stale = sorted(known_ids - observed_ids)
        raise ValueError(
            f"requirements classification coverage differs; unclassified={missing}; stale={stale}"
        )
    for row in rows:
        _apply_requirement_classification(row)
    classification_counts = {
        name: sum(1 for row in rows if row["classification"] == name)
        for name in sorted(REQUIREMENT_CLASSIFICATIONS)
    }
    return {
        "schema_version": REQUIREMENTS_SCHEMA,
        "generated_for_commit": commit,
        "requirements": rows,
        "summary": {
            "total": len(rows),
            "stable": sum(1 for row in rows if row["maturity"] == "stable"),
            "verified": sum(1 for row in rows if row["status"] == "verified"),
            "unclassified": sum(
                1 for row in rows if row.get("classification") not in REQUIREMENT_CLASSIFICATIONS
            ),
            "unresolved_beta_blockers": sum(
                1
                for row in rows
                if row.get("classification") == "beta_blocker" and row.get("status") != "verified"
            ),
            "classifications": classification_counts,
        },
    }


def _apply_requirement_classification(row: dict[str, Any]) -> None:
    requirement_id = str(row["id"])
    if requirement_id in _VERIFIED_REQUIREMENTS:
        classification = "verified"
        status = "verified"
        reason = "Implemented within the supported core-local boundary with repository evidence."
        evidence = list(_REQUIREMENT_EVIDENCE.get(str(row["phase"]), ()))
    elif requirement_id in _BETA_BLOCKER_REQUIREMENTS:
        classification = "beta_blocker"
        status = "open"
        reason = "Must be proven against the exact installed beta artifact before closed beta."
        evidence = []
    elif requirement_id in _PRODUCTION_BLOCKER_REQUIREMENTS:
        classification = "production_blocker"
        status = "open"
        reason = "Required for production promotion, but outside the bounded closed-beta gate."
        evidence = []
    elif requirement_id in _DEFERRED_REQUIREMENTS:
        classification = "deferred_feature"
        status = "deferred"
        reason = (
            "Advanced capability is frozen and outside the current core-local support boundary."
        )
        evidence = []
    elif requirement_id in _INVALID_REQUIREMENTS:
        classification = "invalid_or_duplicate"
        status = "removed"
        reason = (
            "The item targets another repository or duplicates an aggregate gate already represented "
            "by individually classified requirements."
        )
        evidence = []
    else:  # Coverage is checked before this function is called.
        raise ValueError(f"unclassified production requirement: {requirement_id}")
    row.update(
        {
            "classification": classification,
            "classification_reason": reason,
            "status": status,
            "evidence": evidence,
        }
    )


def generate_support_matrix(repo_root: Path) -> dict[str, Any]:
    scope = load_windows_release_scope(repo_root)
    return windows_support_matrix(scope, generated_for_commit=_git_commit(repo_root))


def generate_slo_baseline(repo_root: Path) -> dict[str, Any]:
    bench = _json_file(repo_root / ".persistmind" / "reports" / "bench.json")
    measurements = {
        str(item.get("name")): {
            "measured_ms": item.get("elapsed_ms"),
            "budget_ms": item.get("budget_ms"),
            "ok": bool(item.get("ok")),
            "statistic": (item.get("details") or {}).get("statistic"),
            "samples": (item.get("details") or {}).get("samples"),
        }
        for item in bench.get("budgets") or []
        if item.get("name")
    }
    return {
        "schema_version": SLO_SCHEMA,
        "generated_for_commit": _git_commit(repo_root),
        "budgets": {
            "cold_import_median_ms": {"maximum": 250},
            "warm_service_construction_median_ms": {"maximum": 50},
            "pre_tool_use_p95_ms": {"maximum": 5},
            "non_pre_tool_hook_p95_ms": {"maximum": 150},
            "memory_recall_p95_ms": {"maximum": 300},
            "warm_pack_p95_ms": {"maximum": 2000},
            "cli_help_p95_ms": {"maximum": 1000},
            "mcp_initialization_p95_ms": {"maximum": 2000},
            "local_http_health_p95_ms": {"maximum": 250},
            "warm_doctor_p95_ms": {"maximum": 5000},
            "resource_regression_percent": {"maximum": 15},
        },
        "deadline_cleanup": {"formula": "min(5 seconds, 10% of deadline)"},
        "resource_metrics": ["indexed_loc_per_sec", "peak_rss", "wal_growth", "disk_amplification"],
        "representative_measurement": {
            "schema_version": bench.get("schema_version"),
            "snapshot_id": bench.get("snapshot_id"),
            "files": bench.get("files"),
            "loc": bench.get("loc"),
            "index_ms": bench.get("index_ms"),
            "indexed_loc_per_sec": bench.get("parse_loc_per_sec"),
            "database_bytes": bench.get("db_size_bytes"),
            "measurements": measurements,
            "complete": bool(bench.get("ok")) and bool(measurements),
        },
    }


def validate_production_readiness_artifacts(
    repo_root: Path, *, require_verified: bool = True
) -> dict[str, Any]:
    expected = {
        "inventory": (repo_root / "plan" / "source-surface-inventory.json", INVENTORY_SCHEMA),
        "requirements": (
            repo_root / "plan" / "production-readiness-requirements.json",
            REQUIREMENTS_SCHEMA,
        ),
        "support_matrix": (repo_root / "plan" / "support-matrix.json", SUPPORT_SCHEMA),
        "slo_baseline": (repo_root / "plan" / "slo-baseline.json", SLO_SCHEMA),
    }
    checks: dict[str, Any] = {}
    blockers: list[str] = []
    payloads: dict[str, dict[str, Any]] = {}
    for name, (path, schema) in expected.items():
        payload = _json_file(path)
        payloads[name] = payload
        violations = []
        if not path.exists():
            violations.append("missing")
        elif not payload:
            violations.append("invalid_json")
        if payload.get("schema_version") != schema:
            violations.append("schema_version_mismatch")
        generated_commit = str(payload.get("generated_for_commit") or "")
        if not _git_is_ancestor(repo_root, generated_commit):
            violations.append("commit_mismatch")
        checks[name] = {"ok": not violations, "path": str(path), "violations": violations}
        blockers.extend(f"{name}:{item}" for item in violations)

    inventory = payloads.get("inventory") or {}
    for family in (
        "source_modules",
        "database_objects",
        "public_operations",
        "generated_surfaces",
        "test_families",
    ):
        rows = inventory.get(family)
        if not isinstance(rows, list) or not rows:
            blockers.append(f"inventory:{family}_empty")
            continue
        if any(not row.get("owner") or not row.get("maturity") for row in rows):
            blockers.append(f"inventory:{family}_unowned")

    requirements = (payloads.get("requirements") or {}).get("requirements") or []
    if not requirements:
        blockers.append("requirements:empty")
    stable_open = [
        row.get("id")
        for row in requirements
        if row.get("maturity") == "stable"
        and row.get("status") == "open"
        and row.get("classification") in {"beta_blocker", "production_blocker"}
    ]
    unclassified = [
        row.get("id")
        for row in requirements
        if row.get("classification") not in REQUIREMENT_CLASSIFICATIONS
    ]
    unresolved_beta_blockers = [
        row.get("id")
        for row in requirements
        if row.get("classification") == "beta_blocker" and row.get("status") != "verified"
    ]
    if unclassified:
        blockers.append("requirements:unclassified")
    if require_verified and unresolved_beta_blockers:
        blockers.append("requirements:unresolved_beta_blockers")
    support = payloads.get("support_matrix") or {}
    if not support.get("operating_systems") or not support.get("python"):
        blockers.append("support_matrix:empty")
    scope_path = repo_root / WINDOWS_RELEASE_SCOPE_PATH
    try:
        scope = load_windows_release_scope(repo_root)
    except ValueError as exc:
        scope = {}
        blockers.append("windows_release_scope:invalid")
        checks["windows_release_scope"] = {
            "ok": False,
            "path": str(scope_path),
            "violations": [str(exc)],
        }
    else:
        scope_violations: list[str] = []
        if scope.get("schema_version") != WINDOWS_RELEASE_SCOPE_SCHEMA:
            scope_violations.append("schema_version_mismatch")
        try:
            validate_support_matrix_against_scope(support, scope)
        except ValueError as exc:
            scope_violations.append(str(exc))
        checks["windows_release_scope"] = {
            "ok": not scope_violations,
            "path": str(scope_path),
            "violations": scope_violations,
        }
        blockers.extend(f"windows_release_scope:{item}" for item in scope_violations)
    compatibility_path = repo_root / AGENT_COMPATIBILITY_PATH
    try:
        compatibility = load_agent_compatibility(repo_root)
        compatibility_violations = validate_agent_compatibility(
            compatibility,
            require_qualified=require_verified,
            required_agents=set(scope.get("agents") or ()),
        )
    except ValueError as exc:
        compatibility_violations = [str(exc)]
    checks["agent_compatibility"] = {
        "ok": not compatibility_violations,
        "path": str(compatibility_path),
        "violations": compatibility_violations,
    }
    blockers.extend(f"agent_compatibility:{item}" for item in compatibility_violations)
    slo = payloads.get("slo_baseline") or {}
    if not slo.get("budgets"):
        blockers.append("slo_baseline:empty")
    measurement = slo.get("representative_measurement") or {}
    if not measurement.get("complete"):
        blockers.append("slo_baseline:measurement_missing")
    return {
        "ok": not blockers,
        "schema_version": "persistmind.production_readiness_artifact_validation.v1",
        "require_verified": require_verified,
        "checks": checks,
        "stable_open_count": len(stable_open),
        "stable_open_sample": stable_open[:20],
        "unclassified_count": len(unclassified),
        "unclassified_sample": unclassified[:20],
        "unresolved_beta_blocker_count": len(unresolved_beta_blockers),
        "unresolved_beta_blocker_sample": unresolved_beta_blockers[:20],
        "blockers": sorted(set(blockers)),
    }


def validate_release_contracts(repo_root: Path, *, version: str = "current") -> dict[str, Any]:
    """Validate current source contracts without constructing a product store."""

    repo_root = repo_root.resolve()
    from persistmind.application.registry import validate_operation_catalog
    from persistmind.architecture.contracts import validate_architecture_contracts
    from persistmind.composition.validation import validate_active_handlers
    from persistmind.interfaces.manifest import validate_interface_artifacts
    from persistmind.release_identity import public_release_identity
    from persistmind.storage.operations import resources_status

    checks = {
        "operation_catalog": validate_operation_catalog(),
        "active_handlers": validate_active_handlers(),
        "architecture": validate_architecture_contracts(repo_root),
        "interfaces": validate_interface_artifacts(repo_root),
        "storage_resources": resources_status(),
    }
    blockers = [name for name, value in checks.items() if not value.get("ok")]
    return {
        "ok": not blockers,
        "status": "pass" if not blockers else "blocked",
        "schema_version": "persistmind.release_contract_validation.v2",
        "version": version,
        "source_commit": _git_commit(repo_root),
        "release_identity": public_release_identity(),
        "checks": checks,
        "blockers": blockers,
    }


def _requirement_row(
    requirement_id: str,
    description: str,
    *,
    source: str,
    phase: str,
    owner: str,
    commit: str,
) -> dict[str, Any]:
    return {
        "id": requirement_id,
        "description": description,
        "source": source,
        "profile": "local_core",
        "maturity": "stable",
        "phase": phase,
        "owner": owner,
        "intended_files": [],
        "schema_objects": [],
        "public_surfaces": [],
        "tests": {
            "positive": [],
            "negative": [],
            "fault": [],
            "compatibility": [],
            "rollback": [],
        },
        "required_evidence": [],
        "environment_digest": None,
        "commit": commit,
        "status": "open",
        "waiver": None,
    }


def _source_area(relative: Path) -> str:
    if len(relative.parts) == 1:
        return relative.stem
    return relative.parts[0]


def _schema_inventory(path: Path, *, repo_root: Path) -> list[dict[str, Any]]:
    pattern = re.compile(
        r"CREATE\s+(?:(VIRTUAL)\s+)?(TABLE|INDEX|TRIGGER)\s+(?:IF\s+NOT\s+EXISTS\s+)?[\"`\[]?([A-Za-z_][A-Za-z0-9_]*)",
        re.IGNORECASE,
    )
    sources = sorted(path.rglob("*.sql")) if path.is_dir() else [path]
    rows = []
    for source in sources:
        if not source.exists():
            continue
        text = source.read_text(encoding="utf-8")
        owner = source.parent.name if path.is_dir() else "unknown"
        for virtual, kind, name in pattern.findall(text):
            rows.append(
                {
                    "name": name,
                    "kind": "virtual_table" if virtual else kind.lower(),
                    "owner": f"persistmind:{owner}",
                    "schema_resource": source.relative_to(repo_root).as_posix(),
                    "profile": "local_core",
                    "maturity": "stable",
                }
            )
    return sorted(_dedupe(rows, key="name"), key=lambda item: (item["kind"], item["name"]))


def _cli_operations(path: Path) -> list[dict[str, Any]]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    names = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not node.args:
            continue
        func = node.func
        if isinstance(func, ast.Attribute) and func.attr == "add_parser":
            first = node.args[0]
            if isinstance(first, ast.Constant) and isinstance(first.value, str):
                names.add(first.value)
    return [
        {
            "id": f"cli:{name}",
            "surface": "cli",
            "operation": name,
            "owner": "persistmind:cli",
            "profile": "local_core",
            "maturity": "stable",
        }
        for name in sorted(names)
    ]


def _decorated_operations(
    path: Path,
    *,
    surface: str,
    decorator: str,
    profile: str,
    maturity: str,
    allowed_operations: set[str] | None = None,
) -> list[dict[str, Any]]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    names = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if any(_decorator_name(item) == decorator for item in node.decorator_list):
            if allowed_operations is None or node.name in allowed_operations:
                names.append(node.name)
    return [
        {
            "id": f"{surface}:{name}",
            "surface": surface,
            "operation": name,
            "owner": f"persistmind:{surface}",
            "profile": profile,
            "maturity": maturity,
        }
        for name in sorted(set(names))
    ]


def _declared_string_set(path: Path, name: str) -> set[str]:
    """Read a literal module-level set declaration without importing runtime code."""

    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if not isinstance(node, ast.Assign) or not any(
            isinstance(target, ast.Name) and target.id == name for target in node.targets
        ):
            continue
        value = node.value
        if (
            isinstance(value, ast.Call)
            and isinstance(value.func, ast.Name)
            and value.func.id == "frozenset"
            and len(value.args) == 1
        ):
            value = value.args[0]
        try:
            declared = ast.literal_eval(value)
        except (ValueError, TypeError):
            break
        if isinstance(declared, (set, frozenset, tuple, list)) and all(
            isinstance(item, str) for item in declared
        ):
            return set(declared)
        break
    raise ValueError(f"{path}: missing literal string set {name}")


def _http_operations(path: Path) -> list[dict[str, Any]]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    routes = {
        node.value
        for node in ast.walk(tree)
        if isinstance(node, ast.Constant)
        and isinstance(node.value, str)
        and node.value.startswith("/")
        and " " not in node.value
        and len(node.value) > 1
    }
    return [
        {
            "id": f"http:{route}",
            "surface": "http",
            "operation": route,
            "owner": "persistmind:http",
            "profile": "built_in_http",
            "maturity": "preview",
        }
        for route in sorted(routes)
    ]


def _decorator_name(node: ast.expr) -> str:
    if isinstance(node, ast.Call):
        node = node.func
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Name):
        return node.id
    return ""


def _section(text: str, start: str, end: str) -> str:
    start_index = text.find(start)
    if start_index < 0:
        return ""
    start_index += len(start)
    end_index = text.find(end, start_index)
    return text[start_index:] if end_index < 0 else text[start_index:end_index]


def _numbered_items(text: str) -> list[str]:
    matches = list(re.finditer(r"(?m)^(\d+)\.\s+(.+)$", text))
    items = []
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        block = text[match.start(2) : end]
        lines = []
        for line in block.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("###") or stripped.startswith("##"):
                continue
            lines.append(stripped)
        items.append(" ".join(lines))
    return items


def _dedupe(rows: Iterable[dict[str, Any]], *, key: str) -> list[dict[str, Any]]:
    found: dict[str, dict[str, Any]] = {}
    for row in rows:
        found[str(row[key])] = row
    return list(found.values())


def _json_file(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def _git_commit(repo_root: Path) -> str:
    try:
        return subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_root,
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=5,
        ).stdout.strip()
    except (FileNotFoundError, subprocess.SubprocessError):
        return "NO_GIT"


def _git_is_ancestor(repo_root: Path, candidate: str) -> bool:
    if not candidate or candidate == "NO_GIT":
        return candidate == _git_commit(repo_root)
    try:
        result = subprocess.run(
            ["git", "merge-base", "--is-ancestor", candidate, "HEAD"],
            cwd=repo_root,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=5,
        )
    except (FileNotFoundError, subprocess.SubprocessError):
        return False
    return result.returncode == 0


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description="Generate Phase 0 readiness evidence")
    parser.add_argument("--repo", default=".")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    repo_root = Path(args.repo).resolve()
    result = (
        validate_production_readiness_artifacts(repo_root, require_verified=False)
        if args.check
        else write_phase0_artifacts(repo_root)
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    if not result.get("ok"):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
