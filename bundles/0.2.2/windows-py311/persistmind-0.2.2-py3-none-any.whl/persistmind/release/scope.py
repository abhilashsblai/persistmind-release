from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any

WINDOWS_RELEASE_SCOPE_SCHEMA = "persistmind.windows_release_scope.v1"
WINDOWS_RELEASE_SCOPE_PATH = Path("plan/windows-release-scope.v1.json")

_REQUIRED_AGENTS = frozenset({"codex", "gemini"})
_REQUIRED_PYTHON = ("3.11", "3.12", "3.13")
_REQUIRED_RUNTIME_PROFILE = "windows-stable"


def load_windows_release_scope(repo_root: Path) -> dict[str, Any]:
    path = repo_root.resolve() / WINDOWS_RELEASE_SCOPE_PATH
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError(f"Windows release scope is missing: {path}") from exc
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"Windows release scope is unreadable: {path}") from exc
    if not isinstance(value, dict):
        raise ValueError("Windows release scope must be a JSON object")
    validate_windows_release_scope(value)
    return value


def validate_windows_release_scope(value: Mapping[str, Any]) -> None:
    if value.get("schema_version") != WINDOWS_RELEASE_SCOPE_SCHEMA:
        raise ValueError("unsupported Windows release scope schema")
    if value.get("product") != "PersistMind":
        raise ValueError("Windows release scope product must be PersistMind")
    if value.get("release_claim") != "windows-only":
        raise ValueError("Windows release scope must declare the windows-only claim")
    if value.get("release_channel") != _REQUIRED_RUNTIME_PROFILE:
        raise ValueError("Windows release channel must be windows-stable")

    operating_systems = value.get("operating_systems")
    if not isinstance(operating_systems, list) or len(operating_systems) != 1:
        raise ValueError("Windows release scope must declare exactly one operating system")
    platform = operating_systems[0]
    if not isinstance(platform, Mapping):
        raise ValueError("Windows release platform must be an object")
    expected_platform = {
        "name": "windows",
        "family": "Windows 11",
        "architecture": "x86_64",
        "lifecycle": "microsoft-supported-ga",
    }
    for key, expected in expected_platform.items():
        if platform.get(key) != expected:
            raise ValueError(f"Windows release platform {key} must be {expected!r}")

    filesystems = value.get("filesystems")
    if filesystems != [{"name": "ntfs", "storage": "local"}]:
        raise ValueError("Windows release scope supports local NTFS only")
    if tuple(value.get("python") or ()) != _REQUIRED_PYTHON:
        raise ValueError("Windows release scope requires CPython 3.11, 3.12, and 3.13")
    if set(value.get("agents") or ()) != _REQUIRED_AGENTS:
        raise ValueError("Windows release scope must advertise Codex and Gemini")
    if value.get("runtime_profiles") != [_REQUIRED_RUNTIME_PROFILE]:
        raise ValueError("Windows release scope must advertise only windows-stable")

    installer = value.get("installer")
    if not isinstance(installer, Mapping):
        raise ValueError("Windows release installer policy is missing")
    if installer.get("posix") is not False or installer.get("powershell") is not True:
        raise ValueError("Windows release installer must be PowerShell-only")
    if not installer.get("offline_wheelhouse_required"):
        raise ValueError("Windows release installer requires an offline wheelhouse")

    distribution = value.get("distribution")
    if not isinstance(distribution, Mapping):
        raise ValueError("Windows release distribution policy is missing")
    if distribution.get("artifact_transport") != "google_drive":
        raise ValueError("Windows release artifacts must use Google Drive transport")
    if distribution.get("manifest_schema") != "persistmind.update_manifest.v4":
        raise ValueError("Windows release requires update manifest v4")
    if distribution.get("signature_algorithm") != "ed25519":
        raise ValueError("Windows release manifest signatures must use Ed25519")
    if distribution.get("signed_manifest_required") is not True:
        raise ValueError("Windows release manifest must be signed")

    excluded = value.get("out_of_scope")
    if not isinstance(excluded, Mapping):
        raise ValueError("Windows release scope must declare excluded surfaces")
    required_exclusions = {
        "claude",
        "cursor",
        "grok",
        "linux",
        "macos",
        "ubuntu",
        "windows-server",
        "apfs",
        "ext4",
        "npm",
        "posix",
    }
    observed_exclusions = {
        str(item) for values in excluded.values() if isinstance(values, list) for item in values
    }
    missing = sorted(required_exclusions - observed_exclusions)
    if missing:
        raise ValueError(f"Windows release scope exclusions are incomplete: {missing}")


def windows_support_matrix(
    scope: Mapping[str, Any], *, generated_for_commit: str
) -> dict[str, Any]:
    validate_windows_release_scope(scope)
    platform = dict(scope["operating_systems"][0])
    filesystem = dict(scope["filesystems"][0])
    payload = {
        "schema_version": "persistmind.support_matrix.v1",
        "generated_for_commit": generated_for_commit,
        "release_scope": {
            "schema_version": WINDOWS_RELEASE_SCOPE_SCHEMA,
            "sha256": scope_sha256(scope),
            "path": WINDOWS_RELEASE_SCOPE_PATH.as_posix(),
        },
        "profiles": {
            _REQUIRED_RUNTIME_PROFILE: {
                "maturity": "stable_after_promotion",
                "mandatory": True,
            }
        },
        "operating_systems": [
            {
                "name": platform["name"],
                "family": platform["family"],
                "versions": [platform["lifecycle"]],
                "arch": platform["architecture"],
                "level": "full",
            }
        ],
        "python": list(scope["python"]),
        "agents": list(scope["agents"]),
        "installer": dict(scope["installer"]),
        "distribution": dict(scope["distribution"]),
        "node": [],
        "sqlite": {"wal": True, "fts5": True, "sqlite_vec": "required_windows_wheelhouse"},
        "filesystems": {
            "supported": [filesystem["name"]],
            "storage": filesystem["storage"],
            "unsupported": list(scope["out_of_scope"]["filesystems"]),
        },
        "unsupported": dict(scope["out_of_scope"]),
    }
    validate_support_matrix_against_scope(payload, scope)
    return payload


def validate_support_matrix_against_scope(
    matrix: Mapping[str, Any], scope: Mapping[str, Any]
) -> None:
    validate_windows_release_scope(scope)
    allowed_os = {str(item["name"]) for item in scope["operating_systems"]}
    observed_os = {
        str(item.get("name"))
        for item in matrix.get("operating_systems") or []
        if isinstance(item, Mapping)
    }
    if not observed_os or not observed_os <= allowed_os:
        raise ValueError("support matrix operating-system claims exceed Windows release scope")
    if tuple(matrix.get("python") or ()) != tuple(scope["python"]):
        raise ValueError("support matrix Python claims differ from Windows release scope")
    if set(matrix.get("agents") or ()) != set(scope["agents"]):
        raise ValueError("support matrix agent claims differ from Windows release scope")
    supported_filesystems = set((matrix.get("filesystems") or {}).get("supported") or [])
    allowed_filesystems = {str(item["name"]) for item in scope["filesystems"]}
    if supported_filesystems != allowed_filesystems:
        raise ValueError("support matrix filesystem claims differ from Windows release scope")
    if matrix.get("node"):
        raise ValueError("Windows release support matrix must not advertise Node/npm")


def scope_sha256(value: Mapping[str, Any]) -> str:
    canonical = json.dumps(dict(value), sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


__all__ = [
    "WINDOWS_RELEASE_SCOPE_PATH",
    "WINDOWS_RELEASE_SCOPE_SCHEMA",
    "load_windows_release_scope",
    "scope_sha256",
    "validate_support_matrix_against_scope",
    "validate_windows_release_scope",
    "windows_support_matrix",
]
