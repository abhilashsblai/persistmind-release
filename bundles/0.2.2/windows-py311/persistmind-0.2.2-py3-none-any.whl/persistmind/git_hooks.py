from __future__ import annotations

import hashlib
import json
import os
import shlex
import stat
import subprocess
import tempfile
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from persistmind.runtime_invocation import RuntimeInvocation
from persistmind.repo_identity import canonical_path_identity


MARKER = "# persistmind-managed-hook-v1"
OWNERSHIP_SCHEMA = "persistmind.git_hook_ownership.v1"


class GitHookError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


@dataclass(frozen=True)
class GitHookTarget:
    hook: str
    active_path: Path
    hooks_dir: Path
    git_common_dir: Path
    git_dir: Path
    shared_worktree_target: bool
    external_hooks_path: bool


def hook_target_key(target: GitHookTarget) -> str:
    parent = canonical_path_identity(target.hooks_dir)
    leaf = unicodedata.normalize("NFC", target.active_path.name)
    if not bool(parent.get("case_sensitive", True)):
        leaf = leaf.casefold()
    payload = _canonical_json(
        {
            "schema_version": "persistmind.hook_target_key.v1",
            "parent_identity": parent,
            "leaf": leaf,
        }
    ).rstrip(b"\n")
    return hashlib.sha256(b"persistmind.hook_target_key.v1\0" + payload).hexdigest()


def resolve_git_hook_target(repo: Path, hook: str) -> GitHookTarget:
    if hook not in {"pre-commit", "post-commit"}:
        raise GitHookError("unsupported_hook", f"unsupported Git hook: {hook}")
    root = Path(repo).resolve()
    common = _git_path(root, "--git-common-dir")
    git_dir = _git_path(root, "--git-dir")
    active = _git_path(root, "--git-path", f"hooks/{hook}", require_exists=False)
    hooks_dir = active.parent.resolve()
    expected = (common / "hooks").resolve()
    return GitHookTarget(
        hook=hook,
        active_path=active,
        hooks_dir=hooks_dir,
        git_common_dir=common,
        git_dir=git_dir,
        shared_worktree_target=not _same_path(common, git_dir),
        external_hooks_path=not _same_path(hooks_dir, expected),
    )


def install_git_hooks(
    repo: Path,
    invocation: RuntimeInvocation,
    *,
    allow_shared: bool = False,
) -> dict[str, Any]:
    root = Path(repo).resolve()
    targets = [resolve_git_hook_target(root, name) for name in ("pre-commit", "post-commit")]
    for target in targets:
        if target.external_hooks_path:
            raise GitHookError(
                "external_hooks_path",
                f"refusing external core.hooksPath target: {target.hooks_dir}",
            )
        if target.shared_worktree_target and not allow_shared:
            raise GitHookError(
                "shared_git_hooks",
                "linked worktrees share this Git hook target; explicit shared-hook ownership is required",
            )
        if target.shared_worktree_target and allow_shared:
            raise GitHookError(
                "shared_hook_registry_required",
                "shared Git hook opt-in requires the target-keyed multi-owner registry",
            )

    state_root = root / ".persistmind" / "git-hooks"
    state_root.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, Any]] = []
    for target in targets:
        target.hooks_dir.mkdir(parents=True, exist_ok=True)
        before_observation = _leaf_observation(target.active_path)
        existing = target.active_path.read_bytes() if target.active_path.is_file() else None
        backup: Path | None = None
        original_sha: str | None = None
        if existing is not None and not _is_owned(existing):
            original_sha = hashlib.sha256(existing).hexdigest()
            backup = target.hooks_dir / f".{target.hook}.persistmind-backup-{original_sha}"
            if backup.exists() and _sha256_file(backup) != original_sha:
                raise GitHookError(
                    "hook_backup_conflict", f"Git hook backup hash conflict: {backup}"
                )
            if not backup.exists():
                _atomic_replace_bytes(backup, existing, mode=_mode(target.active_path))
        elif existing is not None:
            previous = _ownership_record(state_root, target.hook)
            if previous and previous.get("backup"):
                candidate = Path(str(previous["backup"]))
                if candidate.is_file():
                    backup = candidate
                    original_sha = str(previous.get("original_sha256") or "") or None

        rendered = _render_hook(target.hook, root, invocation, backup)
        _atomic_replace_bytes(target.active_path, rendered.encode("utf-8"), mode=0o755)
        record = {
            "hook": target.hook,
            "target_key": hook_target_key(target),
            "active_path": str(target.active_path),
            "before_observation": before_observation,
            "after_observation": _leaf_observation(target.active_path),
            "shim_sha256": hashlib.sha256(rendered.encode("utf-8")).hexdigest(),
            "backup": str(backup) if backup else None,
            "original_sha256": original_sha,
        }
        _atomic_replace_bytes(
            state_root / f"{target.hook}.json",
            _canonical_json({"schema_version": OWNERSHIP_SCHEMA, **record}),
            mode=0o600,
        )
        records.append(record)
    return {"ok": True, "hooks": records, "shared": False}


def _render_hook(
    hook: str,
    repo: Path,
    invocation: RuntimeInvocation,
    backup: Path | None,
) -> str:
    command = invocation.render_posix()
    backup_command = ""
    if backup is not None:
        quoted = shlex.quote(str(backup))
        backup_command = (
            f"if [ -x {quoted} ]; then\n"
            f'  {quoted} "$@"\n'
            "  persistmind_previous_status=$?\n"
            f"elif [ -f {quoted} ]; then\n"
            f'  /bin/sh {quoted} "$@"\n'
            "  persistmind_previous_status=$?\n"
            "fi\n"
        )
    header = (
        "#!/bin/sh\n"
        f"{MARKER}\n"
        f"# repository: {hashlib.sha256(str(repo).encode('utf-8')).hexdigest()}\n"
        "persistmind_previous_status=0\n"
        f"{backup_command}"
    )
    if hook == "pre-commit":
        return (
            header
            + 'if [ "$persistmind_previous_status" -ne 0 ]; then exit "$persistmind_previous_status"; fi\n'
            + 'repo="$(git rev-parse --show-toplevel)" || exit 1\n'
            + 'PERSISTMIND_TASK_SESSION_ID="${PERSISTMIND_TASK_SESSION_ID:-${PERSISTMIND_TASK_SESSION_ID:-}}"\n'
            + 'if [ -n "$PERSISTMIND_TASK_SESSION_ID" ]; then\n'
            + f'  {command} --repo "$repo" constitution check --staged --fail-on-violation --task-session-id "$PERSISTMIND_TASK_SESSION_ID"\n'
            + "else\n"
            + f'  {command} --repo "$repo" constitution check --staged --fail-on-violation\n'
            + "fi\n"
        )
    runtime = shlex.quote(invocation.executable) + " -I -m persistmind.git_hook_runtime"
    return (
        header
        + 'repo="$(git rev-parse --show-toplevel)" || exit "$persistmind_previous_status"\n'
        + f'{runtime} --repo "$repo" --hook post_commit\n'
        + 'if [ "$persistmind_previous_status" -ne 0 ]; then exit "$persistmind_previous_status"; fi\n'
        + "exit 0\n"
    )


def _git_path(
    repo: Path,
    *args: str,
    require_exists: bool = True,
) -> Path:
    result = subprocess.run(
        ["git", "-C", str(repo), "rev-parse", "--path-format=absolute", *args],
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=10,
    )
    if result.returncode != 0 or not result.stdout.strip():
        detail = result.stderr.strip() or "not a Git repository"
        raise GitHookError("not_git_repository", detail)
    path = Path(result.stdout.strip())
    if not path.is_absolute():
        path = repo / path
    if require_exists:
        try:
            return path.resolve(strict=True)
        except OSError as exc:
            raise GitHookError("git_path_missing", f"Git path is unavailable: {path}") from exc
    return path.resolve(strict=False)


def _is_owned(content: bytes) -> bool:
    return MARKER.encode("utf-8") in content[:1024]


def _same_path(left: Path, right: Path) -> bool:
    try:
        return os.path.samefile(left, right)
    except OSError:
        return os.path.normcase(str(left.resolve())) == os.path.normcase(str(right.resolve()))


def _mode(path: Path) -> int:
    try:
        return stat.S_IMODE(path.stat().st_mode)
    except OSError:
        return 0o755


def _sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _leaf_observation(path: Path) -> dict[str, Any]:
    if not path.exists() and not path.is_symlink():
        return {"state": "absent"}
    try:
        stat_result = path.stat()
    except OSError as exc:
        raise GitHookError("hook_observation_failed", f"cannot observe Git hook: {path}") from exc
    kind = "file" if path.is_file() else "other"
    value: dict[str, Any] = {
        "state": "present",
        "kind": kind,
        "device": int(stat_result.st_dev),
        "file_id": int(stat_result.st_ino),
        "mode": stat.S_IMODE(stat_result.st_mode),
    }
    if kind == "file":
        value["sha256"] = _sha256_file(path)
    return value


def _ownership_record(root: Path, hook: str) -> dict[str, Any] | None:
    path = root / f"{hook}.json"
    if not path.is_file():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return value if isinstance(value, dict) else None


def _canonical_json(value: dict[str, Any]) -> bytes:
    return (
        json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n"
    ).encode("utf-8")


def _atomic_replace_bytes(path: Path, content: bytes, *, mode: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        try:
            temporary.chmod(mode)
        except OSError:
            pass
        os.replace(temporary, path)
        _fsync_parent(path.parent)
    finally:
        temporary.unlink(missing_ok=True)


def _fsync_parent(path: Path) -> None:
    if os.name == "nt":
        return
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


__all__ = [
    "GitHookError",
    "GitHookTarget",
    "hook_target_key",
    "install_git_hooks",
    "resolve_git_hook_target",
]
