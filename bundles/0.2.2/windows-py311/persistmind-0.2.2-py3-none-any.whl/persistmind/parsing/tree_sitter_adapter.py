from __future__ import annotations

import importlib
from pathlib import Path
from typing import Any


_MODULES = {
    "python": "tree_sitter_python",
    "javascript": "tree_sitter_javascript",
    "typescript": "tree_sitter_typescript",
    "go": "tree_sitter_go",
    "java": "tree_sitter_java",
    "php": "tree_sitter_php",
    "ruby": "tree_sitter_ruby",
    "rust": "tree_sitter_rust",
}

_SYMBOL_TYPES: dict[str, dict[str, str]] = {
    "python": {
        "class_definition": "class",
        "function_definition": "function",
    },
    "javascript": {
        "class_declaration": "class",
        "function_declaration": "function",
        "method_definition": "method",
        "generator_function_declaration": "function",
    },
    "typescript": {
        "class_declaration": "class",
        "interface_declaration": "interface",
        "type_alias_declaration": "type",
        "enum_declaration": "enum",
        "function_declaration": "function",
        "method_definition": "method",
        "abstract_method_signature": "method",
    },
    "go": {
        "function_declaration": "function",
        "method_declaration": "method",
        "type_declaration": "type",
    },
    "java": {
        "class_declaration": "class",
        "interface_declaration": "interface",
        "enum_declaration": "enum",
        "method_declaration": "method",
        "constructor_declaration": "method",
    },
    "php": {
        "class_declaration": "class",
        "interface_declaration": "interface",
        "trait_declaration": "trait",
        "function_definition": "function",
        "method_declaration": "method",
    },
    "ruby": {
        "class": "class",
        "module": "module",
        "method": "method",
        "singleton_method": "method",
    },
    "rust": {
        "function_item": "function",
        "struct_item": "struct",
        "enum_item": "enum",
        "trait_item": "trait",
        "impl_item": "impl",
        "type_item": "type",
    },
}

_IMPORT_TYPES = {
    "import_statement",
    "import_declaration",
    "use_declaration",
    "use_clause",
    "namespace_use_declaration",
}
_CALL_TYPES = {"call", "call_expression", "function_call_expression", "method_invocation"}


def grammar_module(language: str) -> Any:
    module_name = _MODULES.get(language)
    if not module_name:
        raise RuntimeError(f"no tree-sitter grammar is registered for {language}")
    try:
        return importlib.import_module(module_name)
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"tree-sitter grammar is unavailable for {language}") from exc


def parse_tree_sitter(path: str | Path, text: str, language: str):
    from tree_sitter import Language, Parser  # type: ignore[import-not-found]

    from persistmind.parsing.extractors import ExtractedFile, ImportObservation, Symbol

    module = grammar_module(language)
    if language == "typescript":
        factory = (
            module.language_tsx
            if Path(path).suffix.lower() == ".tsx"
            else module.language_typescript
        )
    elif language == "php":
        factory = module.language_php
    else:
        factory = module.language
    grammar = Language(factory())
    parser = Parser(grammar)
    source = text.encode("utf-8")
    tree = parser.parse(source)
    symbols: list[Symbol] = []
    imports: list[ImportObservation] = []
    calls: set[str] = set()
    stack = [tree.root_node]
    while stack:
        node = stack.pop()
        stack.extend(reversed(node.children))
        symbol_kind = _SYMBOL_TYPES.get(language, {}).get(node.type)
        if symbol_kind:
            name_node = node.child_by_field_name("name")
            name = (
                _node_text(name_node, source)
                if name_node is not None
                else _fallback_name(node, source)
            )
            if name:
                start = node.start_point.row + 1
                end = max(start, node.end_point.row + 1)
                signature = text.splitlines()[start - 1].strip() if text.splitlines() else name
                is_test = _is_test(path, name)
                kind = "test" if is_test and symbol_kind in {"function", "method"} else symbol_kind
                symbols.append(Symbol(kind, name, start, end, signature, None, is_test))
        if node.type in _IMPORT_TYPES:
            module_name = _import_target(node, source)
            if module_name:
                imports.append(ImportObservation(module_name, None, None, node.start_point.row + 1))
        if node.type in _CALL_TYPES:
            target = node.child_by_field_name("function") or node.child_by_field_name("name")
            name = _node_text(target, source) if target is not None else ""
            if name:
                calls.add(name)
    diagnostics = ("tree_sitter_parse_error",) if tree.root_node.has_error else ()
    authoritative = not diagnostics
    return ExtractedFile(
        lang=language,
        symbols=sorted(symbols, key=lambda item: (item.start_line, item.qualname)),
        imports=sorted(imports, key=lambda item: (item.line or 0, item.module)),
        calls=sorted(calls),
        skeleton="\n".join(symbol.signature for symbol in symbols),
        requested_backend="tree-sitter",
        effective_backend=f"tree-sitter-{language}",
        support_tier="production_structural" if authoritative else "structural_preview",
        symbols_authoritative=authoritative,
        diagnostics=diagnostics,
    )


def _node_text(node: Any, source: bytes) -> str:
    return source[node.start_byte : node.end_byte].decode("utf-8", errors="replace").strip()


def _fallback_name(node: Any, source: bytes) -> str:
    for child in node.named_children:
        if child.type in {"identifier", "constant", "type_identifier", "name"}:
            return _node_text(child, source)
    return ""


def _import_target(node: Any, source: bytes) -> str:
    for child in node.named_children:
        if child.type in {
            "string",
            "string_literal",
            "scoped_identifier",
            "identifier",
            "package_identifier",
        }:
            return _node_text(child, source).strip("'\"")
    value = _node_text(node, source)
    return value.split(maxsplit=1)[-1].rstrip(";").strip("'\"") if value else ""


def _is_test(path: str | Path, name: str) -> bool:
    normalized = str(path).replace("\\", "/").casefold()
    lowered = name.casefold()
    return "/test" in normalized or lowered.startswith("test") or lowered.endswith("test")
