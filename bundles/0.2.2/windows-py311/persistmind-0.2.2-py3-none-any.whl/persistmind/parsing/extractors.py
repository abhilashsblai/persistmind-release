from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True)
class Symbol:
    kind: str
    qualname: str
    start_line: int
    end_line: int
    signature: str
    docstring: str | None = None
    is_test: bool = False


@dataclass(frozen=True)
class ImportObservation:
    module: str
    name: str | None = None
    alias: str | None = None
    line: int | None = None


@dataclass(frozen=True)
class ExtractedFile:
    lang: str | None
    symbols: list[Symbol] = field(default_factory=list)
    imports: list[ImportObservation] = field(default_factory=list)
    calls: list[str] = field(default_factory=list)
    skeleton: str = ""
    requested_backend: str = "auto"
    effective_backend: str = "complete-text"
    support_tier: str = "complete_unstructured"
    symbols_authoritative: bool = False
    diagnostics: tuple[str, ...] = ()


PY_EXTS = {".py"}
TS_EXTS = {".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"}
GO_EXTS = {".go"}
JAVA_EXTS = {".java"}
PHP_EXTS = {".php"}
RUBY_EXTS = {".rb"}
RUST_EXTS = {".rs"}


def language_for(path: str | Path) -> str | None:
    suffix = Path(path).suffix.lower()
    if suffix in PY_EXTS:
        return "python"
    if suffix in TS_EXTS:
        return "typescript" if "ts" in suffix else "javascript"
    if suffix in GO_EXTS:
        return "go"
    if suffix in JAVA_EXTS:
        return "java"
    if suffix in PHP_EXTS:
        return "php"
    if suffix in RUBY_EXTS:
        return "ruby"
    if suffix in RUST_EXTS:
        return "rust"
    return None


def parse_file(path: str | Path, text: str, backend: str = "auto") -> ExtractedFile:
    lang = language_for(path)
    if backend == "tree-sitter":
        if lang is None:
            raise RuntimeError(f"tree-sitter backend has no registered language for {path}")
        from persistmind.parsing.tree_sitter_adapter import parse_tree_sitter

        return parse_tree_sitter(path, text, lang)
    elif backend not in {"auto", "stdlib"}:
        raise ValueError(f"unknown parser backend: {backend}")
    if lang == "python":
        return _parse_python(str(path), text, requested_backend=backend)
    if lang in {"javascript", "typescript"}:
        parsed = _parse_js_ts(text, lang)
        return _with_backend(parsed, backend, "regex-hints", "complete_unstructured")
    if lang in {"go", "java", "php", "ruby", "rust"}:
        parsed = _parse_regex_language(text, lang)
        return _with_backend(parsed, backend, "regex-hints", "complete_unstructured")
    return ExtractedFile(
        lang=lang,
        skeleton=_generic_skeleton(text),
        requested_backend=backend,
        effective_backend="complete-text",
        support_tier="complete_unstructured",
    )


class _PythonExtractor(ast.NodeVisitor):
    def __init__(self, lines: list[str], path: str):
        self.lines = lines
        self.path = path
        self.stack: list[str] = []
        self.symbols: list[Symbol] = []
        self.imports: list[ImportObservation] = []
        self.calls: list[str] = []

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            self.imports.append(
                ImportObservation(alias.name, None, alias.asname, getattr(node, "lineno", None))
            )

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        module = "." * int(node.level or 0) + (node.module or "")
        for alias in node.names:
            self.imports.append(
                ImportObservation(module, alias.name, alias.asname, getattr(node, "lineno", None))
            )

    def visit_Call(self, node: ast.Call) -> None:
        name = _call_name(node.func)
        if name:
            self.calls.append(name)
        self.generic_visit(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self._add_symbol("class", node)
        self.stack.append(node.name)
        self.generic_visit(node)
        self.stack.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._add_symbol("method" if self.stack else "function", node)
        self.stack.append(node.name)
        self.generic_visit(node)
        self.stack.pop()

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self.visit_FunctionDef(node)  # type: ignore[arg-type]

    def _add_symbol(
        self, kind: str, node: ast.ClassDef | ast.FunctionDef | ast.AsyncFunctionDef
    ) -> None:
        qualname = ".".join([*self.stack, node.name])
        signature = (
            self.lines[node.lineno - 1].strip() if node.lineno <= len(self.lines) else node.name
        )
        docstring = ast.get_docstring(node)
        is_test = node.name.startswith("test_") or "/test" in self.path or "\\test" in self.path
        if is_test and kind in {"function", "method"}:
            kind = "test"
        self.symbols.append(
            Symbol(
                kind=kind,
                qualname=qualname,
                start_line=node.lineno,
                end_line=getattr(node, "end_lineno", node.lineno),
                signature=signature,
                docstring=docstring,
                is_test=is_test,
            )
        )


def _parse_python(path: str, text: str, *, requested_backend: str) -> ExtractedFile:
    lines = text.splitlines()
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return ExtractedFile(
            lang="python",
            skeleton=_generic_skeleton(text),
            requested_backend=requested_backend,
            effective_backend="complete-text",
            support_tier="degraded",
            diagnostics=("python_ast_syntax_error",),
        )
    extractor = _PythonExtractor(lines, path)
    extractor.visit(tree)
    skeleton = _python_skeleton(extractor.symbols)
    return ExtractedFile(
        lang="python",
        symbols=extractor.symbols,
        imports=extractor.imports,
        calls=sorted(set(extractor.calls)),
        skeleton=skeleton,
        requested_backend=requested_backend,
        effective_backend="python-ast",
        support_tier="authoritative_structural",
        symbols_authoritative=True,
    )


def _with_backend(
    extracted: ExtractedFile,
    requested: str,
    effective: str,
    tier: str,
) -> ExtractedFile:
    return ExtractedFile(
        lang=extracted.lang,
        symbols=extracted.symbols,
        imports=extracted.imports,
        calls=extracted.calls,
        skeleton=extracted.skeleton,
        requested_backend=requested,
        effective_backend=effective,
        support_tier=tier,
        symbols_authoritative=False,
        diagnostics=extracted.diagnostics,
    )


def _call_name(node: ast.AST) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = _call_name(node.value)
        return f"{base}.{node.attr}" if base else node.attr
    return None


JS_SYMBOL_RE = re.compile(
    r"^\s*(?:export\s+)?(?:async\s+)?(?:function\s+([A-Za-z_$][\w$]*)|"
    r"(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?\(?[^=]*?\)?\s*=>|"
    r"class\s+([A-Za-z_$][\w$]*))",
    re.MULTILINE,
)
JS_IMPORT_RE = re.compile(
    r"^\s*import\s+(?:.+?\s+from\s+)?['\"]([^'\"]+)['\"]|"
    r"^\s*(?:const|let|var)\s+.+?=\s+require\(['\"]([^'\"]+)['\"]\)",
    re.MULTILINE,
)


def _parse_js_ts(text: str, lang: str) -> ExtractedFile:
    lines = text.splitlines()
    symbols: list[Symbol] = []
    for match in JS_SYMBOL_RE.finditer(text):
        name = next(group for group in match.groups() if group)
        line_no = text[: match.start()].count("\n") + 1
        line = lines[line_no - 1].strip() if line_no <= len(lines) else name
        kind = "class" if line.lstrip().startswith("class") or " class " in line else "function"
        symbols.append(Symbol(kind, name, line_no, line_no, line, None, name.startswith("test")))
    imports = [
        ImportObservation(
            match.group(1) or match.group(2),
            None,
            None,
            text[: match.start()].count("\n") + 1,
        )
        for match in JS_IMPORT_RE.finditer(text)
    ]
    skeleton = "\n".join(symbol.signature for symbol in symbols) or _generic_skeleton(text)
    return ExtractedFile(lang=lang, symbols=symbols, imports=imports, skeleton=skeleton)


def _python_skeleton(symbols: list[Symbol]) -> str:
    if not symbols:
        return ""
    lines: list[str] = []
    for symbol in symbols:
        indent = "    " if "." in symbol.qualname and symbol.kind in {"method", "test"} else ""
        lines.append(f"{indent}{symbol.signature}")
        if symbol.docstring:
            first = symbol.docstring.strip().splitlines()[0]
            lines.append(f'{indent}    """{first}"""')
        lines.append(f"{indent}    ...")
    return "\n".join(lines)


def _generic_skeleton(text: str) -> str:
    lines = [line.rstrip() for line in text.splitlines() if line.strip()]
    return "\n".join(lines[:120])


REGEX_LANG_SYMBOLS = {
    "go": re.compile(r"^\s*func\s+(?:\([^)]+\)\s*)?([A-Za-z_][\w]*)\s*\(", re.MULTILINE),
    "java": re.compile(
        r"^\s*(?:public|private|protected)?\s*(?:class|interface|enum)\s+([A-Za-z_][\w]*)|^\s*(?:public|private|protected)?\s*(?:static\s+)?[\w<>\[\]]+\s+([A-Za-z_][\w]*)\s*\(",
        re.MULTILINE,
    ),
    "php": re.compile(
        r"^\s*(?:class|interface|trait)\s+([A-Za-z_][\w]*)|^\s*(?:public|private|protected)?\s*function\s+([A-Za-z_][\w]*)\s*\(",
        re.MULTILINE,
    ),
    "ruby": re.compile(
        r"^\s*(?:class|module)\s+([A-Za-z_:][\w:]*)|^\s*def\s+([A-Za-z_][\w!?=]*)",
        re.MULTILINE,
    ),
    "rust": re.compile(
        r"^\s*(?:pub\s+)?(?:struct|enum|trait)\s+([A-Za-z_][\w]*)|^\s*(?:pub\s+)?fn\s+([A-Za-z_][\w]*)\s*\(",
        re.MULTILINE,
    ),
}

REGEX_LANG_IMPORTS = {
    "go": re.compile(r'^\s*import\s+(?:\(\s*)?"([^"]+)"', re.MULTILINE),
    "java": re.compile(r"^\s*import\s+([A-Za-z0-9_.]+);", re.MULTILINE),
    "php": re.compile(r"^\s*use\s+([A-Za-z0-9_\\]+);", re.MULTILINE),
    "ruby": re.compile(r"^\s*require(?:_relative)?\s+['\"]([^'\"]+)['\"]", re.MULTILINE),
    "rust": re.compile(r"^\s*use\s+([A-Za-z0-9_:]+);", re.MULTILINE),
}


def _parse_regex_language(text: str, lang: str) -> ExtractedFile:
    lines = text.splitlines()
    symbols: list[Symbol] = []
    for match in REGEX_LANG_SYMBOLS[lang].finditer(text):
        name = next(group for group in match.groups() if group)
        line_no = text[: match.start()].count("\n") + 1
        signature = lines[line_no - 1].strip() if line_no <= len(lines) else name
        kind = (
            "class"
            if any(
                word in signature for word in ["class ", "struct ", "enum ", "trait ", "interface "]
            )
            else "function"
        )
        symbols.append(
            Symbol(kind, name, line_no, line_no, signature, None, name.startswith("test"))
        )
    imports = [
        ImportObservation(match.group(1), None, None, text[: match.start()].count("\n") + 1)
        for match in REGEX_LANG_IMPORTS[lang].finditer(text)
    ]
    skeleton = "\n".join(symbol.signature for symbol in symbols) or _generic_skeleton(text)
    return ExtractedFile(lang=lang, symbols=symbols, imports=imports, skeleton=skeleton)
