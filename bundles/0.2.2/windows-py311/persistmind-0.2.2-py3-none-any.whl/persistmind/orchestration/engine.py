from __future__ import annotations

import json
from typing import Any

from persistmind.application.orchestration_ports import OrchestrationTaskPort
from persistmind.utils import canonical_json, stable_id, utc_now


def _loads(value: str | None, default: Any) -> Any:
    try:
        return json.loads(value or "")
    except (TypeError, json.JSONDecodeError):
        return default


class OrchestrationEngine:
    def __init__(self, task: OrchestrationTaskPort) -> None:
        self.conn = task

    def create(
        self,
        parent_task_session_id: str,
        objective: str,
        tasks: list[dict[str, Any]],
        *,
        dependencies: list[dict[str, str]] | None = None,
        strategy: str = "parallel",
        graph_version_id: str | None = None,
        budget: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        orchestration_id = stable_id("orchestration", parent_task_session_id, objective)
        normalized_tasks = []
        keys: dict[str, str] = {}
        for index, task in enumerate(tasks):
            key = str(task.get("id") or f"task-{index + 1}")
            task_id = stable_id("orchestration-task", orchestration_id, key)
            if key in keys:
                raise ValueError(f"duplicate orchestration task id: {key}")
            keys[key] = task_id
            normalized_tasks.append((key, task_id, task))
        normalized_deps = []
        for dep in dependencies or []:
            before, after = str(dep["predecessor"]), str(dep["successor"])
            if before not in keys or after not in keys:
                raise ValueError("orchestration dependency references unknown task")
            normalized_deps.append((keys[before], keys[after], str(dep.get("type") or "requires")))
        self._assert_acyclic(list(keys.values()), [(a, b) for a, b, _ in normalized_deps])
        now = utc_now()
        with self.conn:
            self.conn.execute(
                "INSERT INTO orchestration_runs(orchestration_id, parent_task_session_id, objective, strategy, graph_version_id, budget_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(orchestration_id) DO UPDATE SET updated_at=excluded.updated_at",
                (
                    orchestration_id,
                    parent_task_session_id,
                    objective,
                    strategy,
                    graph_version_id,
                    canonical_json(budget or {}),
                    now,
                    now,
                ),
            )
            for key, task_id, task in normalized_tasks:
                self.conn.execute(
                    "INSERT OR IGNORE INTO orchestration_tasks(orchestration_task_id, orchestration_id, objective, role_type, read_scope_json, write_scope_json, evidence_contract_json, pack_id, graph_version_id, budget_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        task_id,
                        orchestration_id,
                        str(task.get("objective") or key),
                        str(task.get("role") or "worker"),
                        canonical_json(sorted(set(task.get("read_scope") or []))),
                        canonical_json(sorted(set(task.get("write_scope") or []))),
                        canonical_json(task.get("evidence_contract") or {}),
                        task.get("pack_id"),
                        task.get("graph_version_id") or graph_version_id,
                        canonical_json(task.get("budget") or {}),
                        now,
                        now,
                    ),
                )
                role_id = stable_id("orchestration-role", orchestration_id, task_id)
                self.conn.execute(
                    "INSERT OR IGNORE INTO orchestration_roles(role_id, orchestration_id, orchestration_task_id, role_type, read_scope_json, write_scope_json, budget_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        role_id,
                        orchestration_id,
                        task_id,
                        str(task.get("role") or "worker"),
                        canonical_json(sorted(set(task.get("read_scope") or []))),
                        canonical_json(sorted(set(task.get("write_scope") or []))),
                        canonical_json(task.get("budget") or {}),
                        now,
                        now,
                    ),
                )
            for predecessor, successor, dep_type in normalized_deps:
                self.conn.execute(
                    "INSERT OR IGNORE INTO orchestration_dependencies(orchestration_id, predecessor_task_id, successor_task_id, dependency_type) VALUES (?, ?, ?, ?)",
                    (orchestration_id, predecessor, successor, dep_type),
                )
        return self.status(orchestration_id)

    def status(self, orchestration_id: str) -> dict[str, Any]:
        run = self.conn.execute(
            "SELECT * FROM orchestration_runs WHERE orchestration_id=?", (orchestration_id,)
        ).fetchone()
        if run is None:
            raise KeyError(f"unknown orchestration: {orchestration_id}")
        tasks = [
            self._task(row)
            for row in self.conn.execute(
                "SELECT * FROM orchestration_tasks WHERE orchestration_id=? ORDER BY orchestration_task_id",
                (orchestration_id,),
            ).fetchall()
        ]
        deps = [
            dict(row)
            for row in self.conn.execute(
                "SELECT * FROM orchestration_dependencies WHERE orchestration_id=? ORDER BY predecessor_task_id, successor_task_id",
                (orchestration_id,),
            ).fetchall()
        ]
        roles = [
            self._role(row)
            for row in self.conn.execute(
                "SELECT * FROM orchestration_roles WHERE orchestration_id=? ORDER BY role_id",
                (orchestration_id,),
            ).fetchall()
        ]
        return {
            "schema_version": "persistmind.orchestration_status.v1",
            "run": dict(run),
            "tasks": tasks,
            "dependencies": deps,
            "roles": roles,
            "ready_task_ids": self.ready(orchestration_id),
        }

    def ready(self, orchestration_id: str) -> list[str]:
        tasks = {
            str(row["orchestration_task_id"]): str(row["status"])
            for row in self.conn.execute(
                "SELECT orchestration_task_id, status FROM orchestration_tasks WHERE orchestration_id=?",
                (orchestration_id,),
            ).fetchall()
        }
        blocked: dict[str, list[str]] = {}
        for row in self.conn.execute(
            "SELECT predecessor_task_id, successor_task_id FROM orchestration_dependencies WHERE orchestration_id=?",
            (orchestration_id,),
        ).fetchall():
            blocked.setdefault(str(row["successor_task_id"]), []).append(
                str(row["predecessor_task_id"])
            )
        return sorted(
            task_id
            for task_id, status in tasks.items()
            if status in {"pending", "ready"}
            and all(tasks.get(dep) == "completed" for dep in blocked.get(task_id, []))
        )

    def assign(self, orchestration_task_id: str, agent_session_id: str) -> dict[str, Any]:
        now = utc_now()
        with self.conn:
            self.conn.execute(
                "UPDATE orchestration_roles SET assigned_agent_session_id=?, status='active', updated_at=? WHERE orchestration_task_id=?",
                (agent_session_id, now, orchestration_task_id),
            )
            self.conn.execute(
                "UPDATE orchestration_tasks SET status='active', updated_at=? WHERE orchestration_task_id=?",
                (now, orchestration_task_id),
            )
        row = self.conn.execute(
            "SELECT * FROM orchestration_roles WHERE orchestration_task_id=?",
            (orchestration_task_id,),
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown orchestration task: {orchestration_task_id}")
        return {"schema_version": "persistmind.orchestration_assignment.v1", **self._role(row)}

    def checkpoint(
        self,
        orchestration_id: str,
        *,
        role_id: str | None = None,
        changed_files: list[str] | None = None,
        tests: list[str] | None = None,
        blockers: list[str] | None = None,
        evidence_refs: list[str] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        payload = {
            "changed_files": sorted(set(changed_files or [])),
            "tests": tests or [],
            "blockers": blockers or [],
            "evidence_refs": evidence_refs or [],
        }
        if role_id:
            role = self.conn.execute(
                "SELECT * FROM orchestration_roles WHERE role_id=? AND orchestration_id=?",
                (role_id, orchestration_id),
            ).fetchone()
            if role is None:
                raise KeyError(f"unknown orchestration role: {role_id}")
            write_scope = set(_loads(role["write_scope_json"], []))
            out_of_scope = [path for path in payload["changed_files"] if path not in write_scope]
            if out_of_scope:
                raise PermissionError(
                    f"checkpoint files outside role scope: {', '.join(out_of_scope)}"
                )
            budget = _loads(role["budget_json"], {})
            max_files = int(budget.get("max_files") or 0)
            if max_files and len(payload["changed_files"]) > max_files:
                raise RuntimeError("orchestration role file budget exceeded")
        key = idempotency_key or stable_id(
            "orchestration-checkpoint", orchestration_id, role_id, canonical_json(payload)
        )
        checkpoint_id = stable_id("orchestration-checkpoint", key)
        with self.conn:
            self.conn.execute(
                "INSERT OR IGNORE INTO orchestration_checkpoints(checkpoint_id, orchestration_id, role_id, evidence_refs_json, changed_files_json, tests_json, blockers_json, idempotency_key, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    checkpoint_id,
                    orchestration_id,
                    role_id,
                    canonical_json(payload["evidence_refs"]),
                    canonical_json(payload["changed_files"]),
                    canonical_json(payload["tests"]),
                    canonical_json(payload["blockers"]),
                    key,
                    utc_now(),
                ),
            )
        return {
            "schema_version": "persistmind.orchestration_checkpoint.v1",
            "checkpoint_id": checkpoint_id,
            "orchestration_id": orchestration_id,
            "role_id": role_id,
            **payload,
        }

    def output(
        self,
        orchestration_id: str,
        output_type: str,
        payload: dict[str, Any],
        *,
        role_id: str | None = None,
        provenance: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        output_id = stable_id(
            "subagent-output", orchestration_id, role_id, output_type, canonical_json(payload)
        )
        with self.conn:
            self.conn.execute(
                "INSERT OR IGNORE INTO subagent_outputs(output_id, orchestration_id, role_id, output_type, payload_json, provenance_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    output_id,
                    orchestration_id,
                    role_id,
                    output_type,
                    canonical_json(payload),
                    canonical_json(provenance or {}),
                    utc_now(),
                ),
            )
        return {
            "schema_version": "persistmind.orchestration_output.v1",
            "output_id": output_id,
            "status": "candidate",
            "payload": payload,
            "provenance": provenance or {},
        }

    def task_transition(self, orchestration_task_id: str, action: str) -> dict[str, Any]:
        statuses = {
            "complete": "completed",
            "fail": "failed",
            "cancel": "cancelled",
            "retry": "pending",
            "resume": "pending",
        }
        if action not in statuses:
            raise ValueError(f"unsupported orchestration task action: {action}")
        increment = ", retry_count=retry_count+1" if action == "retry" else ""
        with self.conn:
            self.conn.execute(
                f"UPDATE orchestration_tasks SET status=?, updated_at=?{increment} WHERE orchestration_task_id=?",
                (statuses[action], utc_now(), orchestration_task_id),
            )
        row = self.conn.execute(
            "SELECT * FROM orchestration_tasks WHERE orchestration_task_id=?",
            (orchestration_task_id,),
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown orchestration task: {orchestration_task_id}")
        task = self._task(row)
        orchestration_id = str(task["orchestration_id"])
        states = [
            str(item[0])
            for item in self.conn.execute(
                "SELECT status FROM orchestration_tasks WHERE orchestration_id=?",
                (orchestration_id,),
            ).fetchall()
        ]
        with self.conn:
            if states and all(state == "completed" for state in states):
                self.conn.execute(
                    "UPDATE orchestration_runs SET status='ready_to_integrate', updated_at=? WHERE orchestration_id=?",
                    (utc_now(), orchestration_id),
                )
            elif action in {"fail", "cancel"}:
                self.conn.execute(
                    "UPDATE orchestration_runs SET status='degraded', updated_at=? WHERE orchestration_id=?",
                    (utc_now(), orchestration_id),
                )
        return {"schema_version": "persistmind.orchestration_task.v1", **task}

    def integrate(
        self,
        orchestration_id: str,
        output_id: str,
        decision: str,
        *,
        actor: str,
        rationale: str = "",
        verifier_status: str | None = None,
    ) -> dict[str, Any]:
        if decision == "approve" and verifier_status != "pass":
            raise ValueError("integration approval requires verifier_status=pass")
        if decision not in {"approve", "reject", "request_changes"}:
            raise ValueError(f"unsupported integration decision: {decision}")
        decision_id = stable_id("integration-decision", orchestration_id, output_id, decision)
        with self.conn:
            self.conn.execute(
                "INSERT OR IGNORE INTO integration_decisions(integration_decision_id, orchestration_id, output_id, decision, rationale, verifier_status, actor, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    decision_id,
                    orchestration_id,
                    output_id,
                    decision,
                    rationale,
                    verifier_status,
                    actor,
                    utc_now(),
                ),
            )
            self.conn.execute(
                "UPDATE subagent_outputs SET status=? WHERE output_id=?",
                (
                    "approved"
                    if decision == "approve"
                    else "rejected"
                    if decision == "reject"
                    else "changes_requested",
                    output_id,
                ),
            )
            if decision == "approve":
                remaining = self.conn.execute(
                    "SELECT COUNT(*) FROM subagent_outputs WHERE orchestration_id=? AND status='candidate'",
                    (orchestration_id,),
                ).fetchone()[0]
                if remaining == 0:
                    self.conn.execute(
                        "UPDATE orchestration_runs SET status='complete', closed_at=?, updated_at=? WHERE orchestration_id=?",
                        (utc_now(), utc_now(), orchestration_id),
                    )
        return {
            "schema_version": "persistmind.orchestration_integration.v1",
            "integration_decision_id": decision_id,
            "orchestration_id": orchestration_id,
            "output_id": output_id,
            "decision": decision,
            "verifier_status": verifier_status,
        }

    @staticmethod
    def _assert_acyclic(nodes: list[str], edges: list[tuple[str, str]]) -> None:
        successors: dict[str, list[str]] = {node: [] for node in nodes}
        indegree = {node: 0 for node in nodes}
        for before, after in edges:
            successors[before].append(after)
            indegree[after] += 1
        ready = [node for node in nodes if indegree[node] == 0]
        visited = 0
        while ready:
            node = ready.pop()
            visited += 1
            for successor in successors[node]:
                indegree[successor] -= 1
                if indegree[successor] == 0:
                    ready.append(successor)
        if visited != len(nodes):
            raise ValueError("orchestration dependencies must form an acyclic DAG")

    @staticmethod
    def _task(row: Any) -> dict[str, Any]:
        result = dict(row)
        for key in ("read_scope_json", "write_scope_json", "evidence_contract_json", "budget_json"):
            result[key.removesuffix("_json")] = _loads(
                result.pop(key), [] if "scope" in key else {}
            )
        return result

    @staticmethod
    def _role(row: Any) -> dict[str, Any]:
        result = dict(row)
        for key in ("read_scope_json", "write_scope_json", "budget_json"):
            result[key.removesuffix("_json")] = _loads(
                result.pop(key), [] if "scope" in key else {}
            )
        return result
