from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import StrEnum
from typing import Any


class PrivacyClass(StrEnum):
    STORE_FULL = "store_full"
    SUMMARY_ONLY = "summary_only"
    NO_RAW_CONTENT = "no_raw_content"
    SECRET_REDACTED = "secret_redacted"
    DO_NOT_STORE = "do_not_store"


class MasteryLevel(StrEnum):
    L0 = "L0"
    L1 = "L1"
    L2 = "L2"
    L3 = "L3"
    L4 = "L4"
    L5 = "L5"


class AutonomyLevel(StrEnum):
    A0 = "A0"
    A1 = "A1"
    A2 = "A2"
    A3 = "A3"
    A4 = "A4"
    A5 = "A5"
    A6 = "A6"


@dataclass(frozen=True)
class TeachingEvent:
    event_type: str
    source: str
    summary: str
    privacy_class: PrivacyClass = PrivacyClass.SUMMARY_ONLY
    evidence_refs: list[str] = field(default_factory=list)
    task_session_id: str | None = None
    agent_session_id: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class CoachingDirective:
    directive_type: str
    message: str
    severity: str = "medium"
    evidence_refs: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ExamResult:
    exam_type: str
    result: str
    required_evidence: list[str] = field(default_factory=list)
    failed_criteria: list[str] = field(default_factory=list)
    verification_ref: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)
