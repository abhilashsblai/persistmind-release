from __future__ import annotations

import json
import re
import sqlite3
from datetime import datetime, timedelta, timezone
from typing import Any

from persistmind.teaching.contracts import AutonomyLevel, MasteryLevel, PrivacyClass
from persistmind.utils import canonical_json, stable_id, utc_now
from persistmind.security.context import require_current_principal

_SECRET_RE = re.compile(r"(?i)(password|secret|token|api[_-]?key)\s*[:=]\s*([^\s,;]+)")
_MASTERY = [level.value for level in MasteryLevel]
_AUTONOMY = [level.value for level in AutonomyLevel]


def _dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row is not None else None


def _dicts(rows: list[sqlite3.Row]) -> list[dict[str, Any]]:
    return [dict(row) for row in rows]


def _json(value: Any) -> str:
    return canonical_json(value if value is not None else {})


def _privacy_safe(text: str, privacy_class: str) -> str:
    privacy = PrivacyClass(privacy_class)
    if privacy == PrivacyClass.DO_NOT_STORE:
        return "[content intentionally not stored]"
    if privacy == PrivacyClass.NO_RAW_CONTENT:
        return "[raw content omitted]"
    if privacy == PrivacyClass.SECRET_REDACTED:
        return _SECRET_RE.sub(lambda match: f"{match.group(1)}=[REDACTED]", text)
    return text


class TeachingEngine:
    def __init__(self, conn: sqlite3.Connection, repo_id: str) -> None:
        self.conn = conn
        self.repo_id = repo_id

    def runtime_start(
        self,
        task_session_id: str,
        task: str,
        *,
        pack_id: str | None = None,
        agent_session_id: str | None = None,
        hook_session_id: str | None = None,
        branch: str | None = None,
        worktree_root: str | None = None,
        base_commit_sha: str | None = None,
        graph_version_id: str | None = None,
        enforcement_mode: str = "warn",
    ) -> dict[str, Any]:
        run_id = stable_id("codex-runtime", self.repo_id, task_session_id)
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO codex_runtime_runs(
                  run_id, task_session_id, pack_id, agent_session_id,
                  hook_session_id, repo_id, branch, worktree_root,
                  base_commit_sha, graph_version_id, enforcement_mode,
                  task_text, opened_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(repo_id, task_session_id) DO UPDATE SET
                  pack_id=COALESCE(excluded.pack_id, codex_runtime_runs.pack_id),
                  agent_session_id=COALESCE(excluded.agent_session_id, codex_runtime_runs.agent_session_id),
                  hook_session_id=COALESCE(excluded.hook_session_id, codex_runtime_runs.hook_session_id),
                  branch=COALESCE(excluded.branch, codex_runtime_runs.branch),
                  worktree_root=COALESCE(excluded.worktree_root, codex_runtime_runs.worktree_root),
                  base_commit_sha=COALESCE(excluded.base_commit_sha, codex_runtime_runs.base_commit_sha),
                  graph_version_id=COALESCE(excluded.graph_version_id, codex_runtime_runs.graph_version_id),
                  enforcement_mode=excluded.enforcement_mode,
                  task_text=excluded.task_text,
                  updated_at=excluded.updated_at
                """,
                (
                    run_id,
                    task_session_id,
                    pack_id,
                    agent_session_id,
                    hook_session_id,
                    self.repo_id,
                    branch,
                    worktree_root,
                    base_commit_sha,
                    graph_version_id,
                    enforcement_mode,
                    task,
                    now,
                    now,
                ),
            )
            for kind, before, message in (
                ("read_teacher_context", "write", "Review the task teacher brief."),
                ("create_structured_plan", "write", "Create a structured CTX plan."),
                ("record_exam", "outcome", "Record a task verification exam."),
                ("record_reflection", "outcome", "Record a task reflection."),
                ("record_outcome", "outcome", "Record a durable task outcome."),
            ):
                obligation_id = stable_id("runtime-obligation", run_id, kind, before)
                self.conn.execute(
                    """
                    INSERT OR IGNORE INTO codex_runtime_obligations(
                      obligation_id, run_id, kind, required_before, message, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (obligation_id, run_id, kind, before, message, now),
                )
            if graph_version_id:
                obligation_id = stable_id("runtime-obligation", run_id, "graph_freshness", "write")
                self.conn.execute(
                    """
                    INSERT OR IGNORE INTO codex_runtime_obligations(
                      obligation_id, run_id, kind, required_before, message, created_at
                    ) VALUES (?, ?, 'graph_freshness', 'write', ?, ?)
                    """,
                    (
                        obligation_id,
                        run_id,
                        "Confirm the bound living graph version is fresh.",
                        now,
                    ),
                )
        return self.runtime_status(run_id=run_id) or {"run_id": run_id}

    def runtime_status(
        self,
        *,
        run_id: str | None = None,
        task_session_id: str | None = None,
    ) -> dict[str, Any] | None:
        if run_id:
            row = self.conn.execute(
                "SELECT * FROM codex_runtime_runs WHERE run_id = ?", (run_id,)
            ).fetchone()
        elif task_session_id:
            row = self.conn.execute(
                """
                SELECT * FROM codex_runtime_runs
                WHERE repo_id = ? AND task_session_id = ?
                ORDER BY updated_at DESC LIMIT 1
                """,
                (self.repo_id, task_session_id),
            ).fetchone()
        else:
            row = self.conn.execute(
                """
                SELECT * FROM codex_runtime_runs
                WHERE repo_id = ? AND status = 'active'
                ORDER BY updated_at DESC LIMIT 1
                """,
                (self.repo_id,),
            ).fetchone()
        result = _dict(row)
        if result:
            result["obligations"] = self.runtime_obligations(str(result["run_id"]))
        return result

    def runtime_obligations(
        self, run_id: str, *, status: str | None = None
    ) -> list[dict[str, Any]]:
        sql = "SELECT * FROM codex_runtime_obligations WHERE run_id = ?"
        params: list[Any] = [run_id]
        if status:
            sql += " AND status = ?"
            params.append(status)
        sql += " ORDER BY created_at, obligation_id"
        return _dicts(list(self.conn.execute(sql, params).fetchall()))

    def runtime_resolve(
        self, obligation_id: str, evidence_ref: str, actor: str = "codex"
    ) -> dict[str, Any]:
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """
                UPDATE codex_runtime_obligations
                SET status='resolved', evidence_ref=?, resolved_at=?
                WHERE obligation_id=?
                """,
                (evidence_ref, now, obligation_id),
            )
        row = self.conn.execute(
            "SELECT * FROM codex_runtime_obligations WHERE obligation_id = ?",
            (obligation_id,),
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown runtime obligation: {obligation_id}")
        result = dict(row)
        result["resolved_by"] = actor
        return result

    def project_workflow_event(
        self,
        task_session_id: str,
        event_type: str,
        evidence: dict[str, Any],
        *,
        actor: str = "workflow-lifecycle",
    ) -> dict[str, Any] | None:
        """Idempotently converge canonical workflow state into teacher runtime."""

        runtime = self.runtime_status(task_session_id=task_session_id)
        if runtime is None:
            return None
        run_id = str(runtime["run_id"])
        now = utc_now()
        plan_id = str(evidence.get("plan_id") or "") or None
        active_step_id = str(evidence.get("active_step_id") or "") or None
        with self.conn:
            if event_type == "PlanActivated.v1":
                self.conn.execute(
                    "UPDATE codex_runtime_runs SET active_plan_id=?,active_step_id=?,"
                    "updated_at=? WHERE run_id=?",
                    (plan_id, active_step_id, now, run_id),
                )
                self._resolve_runtime_kind(
                    run_id,
                    "create_structured_plan",
                    plan_id or str(evidence.get("event_id") or "plan-activated"),
                    now,
                )
            elif event_type == "PlanCheckpointed.v1":
                self.conn.execute(
                    "UPDATE codex_runtime_runs SET active_step_id=?,updated_at=? WHERE run_id=?",
                    (active_step_id, now, run_id),
                )
            elif event_type == "OutcomeRecorded.v1":
                self._resolve_runtime_kind(
                    run_id,
                    "record_outcome",
                    str(evidence.get("outcome_id") or evidence.get("event_id") or "outcome"),
                    now,
                )
            self.conn.execute(
                "INSERT OR IGNORE INTO codex_runtime_events("
                "event_id,run_id,event_type,idempotency_key,payload_json,actor,created_at) "
                "VALUES(?,?,?,?,?,?,?)",
                (
                    stable_id(
                        "runtime-workflow-event",
                        run_id,
                        str(evidence.get("event_id") or ""),
                        event_type,
                    ),
                    run_id,
                    "workflow_lifecycle_projected",
                    f"workflow:{run_id}:{evidence.get('event_id') or event_type}",
                    _json({"event_type": event_type, **evidence}),
                    actor,
                    now,
                ),
            )
            pending = int(
                self.conn.execute(
                    "SELECT COUNT(*) FROM codex_runtime_obligations "
                    "WHERE run_id=? AND status='pending'",
                    (run_id,),
                ).fetchone()[0]
            )
            if event_type in {"OutcomeRecorded.v1", "TaskCompleted.v1"} and pending == 0:
                self.conn.execute(
                    "UPDATE codex_runtime_runs SET status='complete',closed_at=?,updated_at=? "
                    "WHERE run_id=?",
                    (now, now, run_id),
                )
        return self.runtime_status(run_id=run_id)

    def _resolve_runtime_kind(
        self,
        run_id: str,
        kind: str,
        evidence_ref: str,
        now: str,
    ) -> None:
        self.conn.execute(
            "UPDATE codex_runtime_obligations SET status='resolved',evidence_ref=?,"
            "resolved_at=? WHERE run_id=? AND kind=? AND status='pending'",
            (evidence_ref, now, run_id, kind),
        )

    def runtime_event(
        self,
        event_type: str,
        payload: dict[str, Any],
        *,
        run_id: str | None = None,
        actor: str = "codex",
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        key = idempotency_key or stable_id(event_type, run_id, canonical_json(payload))
        event_id = stable_id("runtime-event", key)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO codex_runtime_events(
                  event_id, run_id, event_type, idempotency_key,
                  payload_json, actor, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (event_id, run_id, event_type, key, _json(payload), actor, utc_now()),
            )
        return dict(
            self.conn.execute(
                "SELECT * FROM codex_runtime_events WHERE idempotency_key = ?", (key,)
            ).fetchone()
        )

    def runtime_gate(
        self,
        run_id: str,
        *,
        tool_name: str,
        target_paths: list[str],
        plan_paths: list[str] | None = None,
        role_paths: list[str] | None = None,
        read_only: bool = False,
    ) -> dict[str, Any]:
        run = self.runtime_status(run_id=run_id)
        if run is None:
            return {"action": "warn", "reason": "runtime run not found"}
        reasons: list[str] = []
        if not read_only:
            pending = [
                item
                for item in run["obligations"]
                if item["status"] == "pending" and item["required_before"] == "write"
            ]
            if pending:
                reasons.append("required runtime obligations are unresolved")
            if plan_paths is not None and any(path not in plan_paths for path in target_paths):
                reasons.append("target path is outside the active plan")
            if role_paths is not None and any(path not in role_paths for path in target_paths):
                reasons.append("target path is outside the assigned role scope")
        mode = str(run.get("enforcement_mode") or "warn")
        action = "allow"
        if reasons:
            action = {
                "off": "allow",
                "audit": "allow",
                "warn": "warn",
                "block": "block",
            }.get(mode, "warn")
        decision_id = stable_id(
            "runtime-gate", run_id, tool_name, canonical_json(target_paths), utc_now()
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO codex_runtime_gate_decisions(
                  decision_id, run_id, tool_name, target_paths_json,
                  mode, action, reason, evidence_refs_json, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    decision_id,
                    run_id,
                    tool_name,
                    _json(target_paths),
                    mode,
                    action,
                    "; ".join(reasons) or "runtime obligations satisfied",
                    _json([item["obligation_id"] for item in run["obligations"]]),
                    utc_now(),
                ),
            )
        return {
            "decision_id": decision_id,
            "action": action,
            "mode": mode,
            "reason": "; ".join(reasons) or "runtime obligations satisfied",
            "run_id": run_id,
            "would_have_blocked": bool(reasons and mode == "audit"),
        }

    def ensure_student(self, agent_kind: str = "codex", model_label: str = "") -> dict[str, Any]:
        student_id = stable_id("teaching-student", self.repo_id, agent_kind, model_label)
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO teaching_students(
                  student_id, repo_id, agent_kind, model_label, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (student_id, self.repo_id, agent_kind, model_label, now, now),
            )
        return dict(
            self.conn.execute(
                "SELECT * FROM teaching_students WHERE student_id = ?", (student_id,)
            ).fetchone()
        )

    def record_event(
        self,
        event_type: str,
        source: str,
        summary: str,
        *,
        task_session_id: str | None = None,
        agent_session_id: str | None = None,
        privacy_class: str = "summary_only",
        evidence_refs: list[str] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        student = self.ensure_student()
        safe_summary = _privacy_safe(summary, privacy_class)
        key = idempotency_key or stable_id(
            "teaching-event", event_type, source, task_session_id, safe_summary
        )
        event_id = stable_id("teaching-event", key)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO teaching_events(
                  event_id, task_session_id, agent_session_id, student_id,
                  event_type, source, summary, evidence_refs_json,
                  privacy_class, idempotency_key, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    event_id,
                    task_session_id,
                    agent_session_id,
                    student["student_id"],
                    event_type,
                    source,
                    safe_summary,
                    _json(evidence_refs or []),
                    privacy_class,
                    key,
                    utc_now(),
                ),
            )
        return dict(
            self.conn.execute(
                "SELECT * FROM teaching_events WHERE idempotency_key = ?", (key,)
            ).fetchone()
        )

    def mastery_update(
        self, skill_key: str, *, success: bool, evidence_ref: str | None = None
    ) -> dict[str, Any]:
        student = self.ensure_student()
        row = self.conn.execute(
            "SELECT * FROM student_mastery WHERE student_id=? AND skill_key=?",
            (student["student_id"], skill_key),
        ).fetchone()
        successes = int(row["success_count"] if row else 0) + int(success)
        failures = int(row["failure_count"] if row else 0) + int(not success)
        current = str(row["mastery_level"] if row else "L0")
        index = _MASTERY.index(current)
        index = min(5, index + 1) if success else max(0, index - 1)
        evidence_count = successes + failures
        confidence = successes / evidence_count if evidence_count else 0.0
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO student_mastery(
                  student_id, skill_key, mastery_level, success_count,
                  failure_count, evidence_count, confidence,
                  last_evidence_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(student_id, skill_key) DO UPDATE SET
                  mastery_level=excluded.mastery_level,
                  success_count=excluded.success_count,
                  failure_count=excluded.failure_count,
                  evidence_count=excluded.evidence_count,
                  confidence=excluded.confidence,
                  last_evidence_at=excluded.last_evidence_at,
                  updated_at=excluded.updated_at
                """,
                (
                    student["student_id"],
                    skill_key,
                    _MASTERY[index],
                    successes,
                    failures,
                    evidence_count,
                    confidence,
                    now,
                    now,
                ),
            )
        result = dict(
            self.conn.execute(
                "SELECT * FROM student_mastery WHERE student_id=? AND skill_key=?",
                (student["student_id"], skill_key),
            ).fetchone()
        )
        result["evidence_ref"] = evidence_ref
        return result

    def student_profile(self, agent_kind: str = "codex") -> dict[str, Any]:
        student = self.ensure_student(agent_kind)
        mastery = _dicts(
            list(
                self.conn.execute(
                    "SELECT * FROM student_mastery WHERE student_id=? ORDER BY skill_key",
                    (student["student_id"],),
                ).fetchall()
            )
        )
        mistakes = _dicts(
            list(
                self.conn.execute(
                    """
                    SELECT * FROM teaching_events
                    WHERE student_id=? AND event_type IN ('correction','failure','scope_violation')
                    ORDER BY created_at DESC LIMIT 50
                    """,
                    (student["student_id"],),
                ).fetchall()
            )
        )
        return {"student": student, "mastery": mastery, "mistakes": mistakes}

    def curriculum_recommend(self, task_session_id: str, objective: str) -> dict[str, Any]:
        profile = self.student_profile()
        weak = [
            item["skill_key"]
            for item in profile["mastery"]
            if item["mastery_level"] in {"L0", "L1", "L2"}
        ]
        lessons = _dicts(
            list(
                self.conn.execute(
                    """
                    SELECT * FROM lessons
                    WHERE repo_id=? AND status IN ('approved','active')
                    ORDER BY updated_at DESC LIMIT 20
                    """,
                    (self.repo_id,),
                ).fetchall()
            )
        )
        curriculum_id = stable_id("curriculum", self.repo_id, task_session_id, objective)
        checks = ["plan_scope_exam", "impact_exam", "test_exam"]
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO curriculum_plans(
                  curriculum_id, task_session_id, student_id, objective,
                  required_lessons_json, recommended_skills_json,
                  required_checks_json, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(curriculum_id) DO UPDATE SET updated_at=excluded.updated_at
                """,
                (
                    curriculum_id,
                    task_session_id,
                    profile["student"]["student_id"],
                    objective,
                    _json([item["lesson_id"] for item in lessons]),
                    _json(weak),
                    _json(checks),
                    now,
                    now,
                ),
            )
        return {
            "curriculum_id": curriculum_id,
            "objective": objective,
            "approved_lessons": lessons,
            "recommended_skills": weak,
            "required_checks": checks,
        }

    def brief(self, task_session_id: str) -> dict[str, Any]:
        run = self.runtime_status(task_session_id=task_session_id)
        profile = self.student_profile()
        curriculum = self.conn.execute(
            """
            SELECT * FROM curriculum_plans WHERE task_session_id=?
            ORDER BY updated_at DESC LIMIT 1
            """,
            (task_session_id,),
        ).fetchone()
        lessons = _dicts(
            list(
                self.conn.execute(
                    """
                    SELECT * FROM lessons
                    WHERE repo_id=? AND status IN ('approved','active')
                    ORDER BY updated_at DESC LIMIT 20
                    """,
                    (self.repo_id,),
                ).fetchall()
            )
        )
        exams = _dicts(
            list(
                self.conn.execute(
                    "SELECT * FROM exam_results WHERE task_session_id=? ORDER BY created_at",
                    (task_session_id,),
                ).fetchall()
            )
        )
        anti_lessons = _dicts(
            list(
                self.conn.execute(
                    """
                    SELECT * FROM lessons
                    WHERE repo_id=? AND lesson_type='anti_lesson' AND status='rejected'
                    ORDER BY updated_at DESC LIMIT 20
                    """,
                    (self.repo_id,),
                ).fetchall()
            )
        )
        return {
            "schema_version": "persistmind.teacher_brief.v1",
            "task_session_id": task_session_id,
            "runtime": run,
            "student": profile["student"],
            "mastery": profile["mastery"],
            "approved_lessons": lessons,
            "anti_lessons": anti_lessons,
            "curriculum": _dict(curriculum),
            "exam_results": exams,
            "exam_required": not any(item["result"] == "pass" for item in exams),
            "reflection_required": any(
                item["event_type"] in {"correction", "failure"}
                for item in profile["mistakes"]
                if item.get("task_session_id") == task_session_id
            ),
        }

    def coach(self, task_session_id: str, event: dict[str, Any]) -> dict[str, Any]:
        directive_type = str(event.get("action") or "verify")
        message = str(event.get("message") or "Review the active teacher obligations.")
        directive_id = stable_id("coaching", task_session_id, directive_type, canonical_json(event))
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO coaching_directives(
                  directive_id, task_session_id, directive_type, message,
                  severity, evidence_refs_json, delivered_channel, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    directive_id,
                    task_session_id,
                    directive_type,
                    message,
                    str(event.get("severity") or "medium"),
                    _json(event.get("evidence_refs") or []),
                    str(event.get("channel") or "workflow"),
                    utc_now(),
                ),
            )
        return dict(
            self.conn.execute(
                "SELECT * FROM coaching_directives WHERE directive_id=?",
                (directive_id,),
            ).fetchone()
        )

    def exam_record(self, task_session_id: str, exam: dict[str, Any]) -> dict[str, Any]:
        exam_type = str(exam.get("exam_type") or "test_exam")
        result = str(exam.get("result") or "fail")
        exam_result_id = stable_id(
            "exam", task_session_id, exam_type, exam.get("verification_ref"), result
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO exam_results(
                  exam_result_id, task_session_id, exam_type, rubric_id,
                  result, required_evidence_json, failed_criteria_json,
                  verification_ref, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    exam_result_id,
                    task_session_id,
                    exam_type,
                    exam.get("rubric_id"),
                    result,
                    _json(exam.get("required_evidence") or []),
                    _json(exam.get("failed_criteria") or []),
                    exam.get("verification_ref"),
                    utc_now(),
                ),
            )
        self.mastery_update(exam_type, success=result == "pass", evidence_ref=exam_result_id)
        return dict(
            self.conn.execute(
                "SELECT * FROM exam_results WHERE exam_result_id=?",
                (exam_result_id,),
            ).fetchone()
        )

    def reflection(self, task_session_id: str, reflection: dict[str, Any]) -> dict[str, Any]:
        return self.record_event(
            "reflection",
            str(reflection.get("source") or "student"),
            str(reflection.get("summary") or "Reflection recorded."),
            task_session_id=task_session_id,
            privacy_class=str(reflection.get("privacy_class") or "summary_only"),
            evidence_refs=list(reflection.get("evidence_refs") or []),
        )

    def lesson_candidate(
        self,
        summary: str,
        *,
        rule_text: str = "",
        lesson_type: str = "technical",
        scope: str = "repo",
        event_id: str | None = None,
        severity: str = "medium",
    ) -> dict[str, Any]:
        lesson_id = stable_id("lesson", self.repo_id, lesson_type, scope, summary)
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO lessons(
                  lesson_id, repo_id, lesson_type, summary, rule_text,
                  scope, severity, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(lesson_id) DO UPDATE SET
                  evidence_count=lessons.evidence_count + 1,
                  recurrence_score=lessons.recurrence_score + 1.0,
                  updated_at=excluded.updated_at
                """,
                (
                    lesson_id,
                    self.repo_id,
                    lesson_type,
                    summary,
                    rule_text,
                    scope,
                    severity,
                    now,
                    now,
                ),
            )
            if event_id:
                evidence_id = stable_id("lesson-evidence", lesson_id, event_id)
                self.conn.execute(
                    """
                    INSERT OR IGNORE INTO lesson_evidence(
                      evidence_id, lesson_id, event_id, created_at
                    ) VALUES (?, ?, ?, ?)
                    """,
                    (evidence_id, lesson_id, event_id, now),
                )
                self.conn.execute(
                    """
                    UPDATE lessons SET evidence_count=(
                      SELECT COUNT(*) FROM lesson_evidence WHERE lesson_id=?
                    ) WHERE lesson_id=?
                    """,
                    (lesson_id, lesson_id),
                )
            self.conn.execute(
                """
                UPDATE lessons SET status='evidence_ready', updated_at=?
                WHERE lesson_id=? AND status='candidate' AND evidence_count >= 2
                """,
                (now, lesson_id),
            )
        return self.lesson_show(lesson_id)

    def lesson_show(self, lesson_id: str) -> dict[str, Any]:
        row = self.conn.execute("SELECT * FROM lessons WHERE lesson_id=?", (lesson_id,)).fetchone()
        if row is None:
            raise KeyError(f"unknown lesson: {lesson_id}")
        result = dict(row)
        result["evidence"] = _dicts(
            list(
                self.conn.execute(
                    "SELECT * FROM lesson_evidence WHERE lesson_id=? ORDER BY created_at",
                    (lesson_id,),
                ).fetchall()
            )
        )
        return result

    def lessons(self, status: str | None = None) -> list[dict[str, Any]]:
        sql = "SELECT * FROM lessons WHERE repo_id=?"
        params: list[Any] = [self.repo_id]
        if status:
            sql += " AND status=?"
            params.append(status)
        if status in {"approved", "benchmarked", "active"}:
            sql += " AND (expires_at IS NULL OR expires_at > ?)"
            params.append(utc_now())
        sql += " ORDER BY updated_at DESC, lesson_id"
        return _dicts(list(self.conn.execute(sql, params).fetchall()))

    def lesson_decide(
        self, lesson_id: str, decision: str, actor: str, rationale: str = ""
    ) -> dict[str, Any]:
        allowed = {
            "approve": "approved",
            "reject": "rejected",
            "benchmark": "benchmarked",
            "activate": "active",
            "rollback": "rolled_back",
        }
        if decision not in allowed:
            raise ValueError(f"unsupported lesson decision: {decision}")
        current = self.lesson_show(lesson_id)
        if decision == "approve":
            if current["status"] != "evidence_ready":
                raise ValueError("lesson requires repeated evidence before approval")
            require_current_principal(roles=frozenset({"admin"}), action="teacher.lesson.approve")
        if decision == "benchmark" and current["status"] != "approved":
            raise ValueError("lesson must be approved before benchmarking")
        if decision == "activate" and current["status"] != "benchmarked":
            raise ValueError("lesson must pass a benchmark before activation")
        if decision == "rollback" and current["status"] != "active":
            raise ValueError("only an active lesson can be rolled back")
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """
                UPDATE lessons SET status=?, approved_by=CASE WHEN ?='approved' THEN ? ELSE approved_by END,
                  lesson_type=CASE WHEN ?='rejected' THEN 'anti_lesson' ELSE lesson_type END,
                  approved_at=CASE WHEN ?='approved' THEN ? ELSE approved_at END,
                  activated_at=CASE WHEN ?='active' THEN ? ELSE activated_at END,
                  rollback_ref=CASE WHEN ?='rolled_back' THEN ? ELSE rollback_ref END,
                  updated_at=? WHERE lesson_id=?
                """,
                (
                    allowed[decision],
                    allowed[decision],
                    actor,
                    allowed[decision],
                    allowed[decision],
                    now,
                    allowed[decision],
                    now,
                    allowed[decision],
                    rationale or f"rollback:{now}",
                    now,
                    lesson_id,
                ),
            )
            self.conn.execute(
                """
                INSERT INTO teaching_decisions(
                  teaching_decision_id, lesson_id, decision_type, status,
                  actor, rationale, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    stable_id("teaching-decision", lesson_id, decision, now),
                    lesson_id,
                    decision,
                    allowed[decision],
                    actor,
                    rationale,
                    now,
                ),
            )
        return self.lesson_show(lesson_id)

    def lesson_conflict(self, lesson_id: str, conflicting_lesson_id: str) -> dict[str, Any]:
        self.lesson_show(lesson_id)
        self.lesson_show(conflicting_lesson_id)
        conflict_id = stable_id("lesson-conflict", lesson_id, conflicting_lesson_id)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO lesson_conflicts(
                  conflict_id, lesson_id, conflicting_lesson_id, created_at
                ) VALUES (?, ?, ?, ?)
                """,
                (conflict_id, lesson_id, conflicting_lesson_id, utc_now()),
            )
        return dict(
            self.conn.execute(
                "SELECT * FROM lesson_conflicts WHERE conflict_id=?", (conflict_id,)
            ).fetchone()
        )

    def lesson_supersede(
        self, lesson_id: str, replacement_lesson_id: str, actor: str
    ) -> dict[str, Any]:
        self.lesson_show(replacement_lesson_id)
        require_current_principal(roles=frozenset({"admin"}), action="teacher.lesson.supersede")
        with self.conn:
            self.conn.execute(
                """
                UPDATE lessons SET status='superseded', supersedes_lesson_id=?,
                  updated_at=? WHERE lesson_id=?
                """,
                (replacement_lesson_id, utc_now(), lesson_id),
            )
        return self.lesson_show(lesson_id)

    def lesson_tombstone(self, lesson_id: str, actor: str) -> dict[str, Any]:
        require_current_principal(roles=frozenset({"admin"}), action="teacher.lesson.delete")
        with self.conn:
            self.conn.execute(
                """
                UPDATE lessons SET status='tombstoned', summary='[deleted]',
                  rule_text='', rollback_ref=?, updated_at=? WHERE lesson_id=?
                """,
                (f"privacy-delete:{actor}", utc_now(), lesson_id),
            )
        return self.lesson_show(lesson_id)

    def lesson_conflict_resolve(
        self, conflict_id: str, resolution: str, actor: str
    ) -> dict[str, Any]:
        require_current_principal(
            roles=frozenset({"admin"}), action="teacher.lesson.conflict.resolve"
        )
        with self.conn:
            self.conn.execute(
                """
                UPDATE lesson_conflicts SET status='resolved', resolution=?,
                  resolved_by=?, resolved_at=? WHERE conflict_id=?
                """,
                (resolution, actor, utc_now(), conflict_id),
            )
        row = self.conn.execute(
            "SELECT * FROM lesson_conflicts WHERE conflict_id=?", (conflict_id,)
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown lesson conflict: {conflict_id}")
        return dict(row)

    def autonomy_propose(
        self, to_level: str, *, actor: str, evidence_refs: list[str] | None = None
    ) -> dict[str, Any]:
        if to_level not in _AUTONOMY:
            raise ValueError(f"unknown autonomy level: {to_level}")
        student = self.ensure_student()
        current = str(student["autonomy_level"])
        decision_id = stable_id(
            "autonomy",
            student["student_id"],
            current,
            to_level,
            canonical_json(evidence_refs or []),
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO autonomy_decisions(
                  autonomy_decision_id, student_id, from_level, to_level,
                  status, approver, evidence_refs_json, created_at
                ) VALUES (?, ?, ?, ?, 'candidate', ?, ?, ?)
                """,
                (
                    decision_id,
                    student["student_id"],
                    current,
                    to_level,
                    actor,
                    _json(evidence_refs or []),
                    utc_now(),
                ),
            )
        return dict(
            self.conn.execute(
                "SELECT * FROM autonomy_decisions WHERE autonomy_decision_id=?",
                (decision_id,),
            ).fetchone()
        )

    def autonomy_decide(
        self,
        autonomy_decision_id: str,
        decision: str,
        *,
        approver: str,
        benchmark_ref: str | None = None,
        rollback_ref: str | None = None,
        expires_in_days: int = 30,
    ) -> dict[str, Any]:
        row = self.conn.execute(
            "SELECT * FROM autonomy_decisions WHERE autonomy_decision_id=?",
            (autonomy_decision_id,),
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown autonomy decision: {autonomy_decision_id}")
        if decision not in {"approve", "reject", "rollback"}:
            raise ValueError(f"unsupported autonomy decision: {decision}")
        to_level = str(row["to_level"])
        if decision == "approve":
            require_current_principal(roles=frozenset({"admin"}), action="teacher.autonomy.approve")
            if not json.loads(row["evidence_refs_json"] or "[]"):
                raise ValueError("autonomy elevation requires evidence")
            if int(to_level[1:]) >= 4 and (not benchmark_ref or not rollback_ref):
                raise ValueError("A4-A6 require benchmark and rollback evidence")
        status = {"approve": "approved", "reject": "rejected", "rollback": "rolled_back"}[decision]
        expiry = (datetime.now(timezone.utc) + timedelta(days=max(1, expires_in_days))).isoformat()
        with self.conn:
            self.conn.execute(
                """
                UPDATE autonomy_decisions SET status=?, approver=?, benchmark_ref=?,
                  rollback_ref=?, expires_at=?, decided_at=?
                WHERE autonomy_decision_id=?
                """,
                (
                    status,
                    approver,
                    benchmark_ref,
                    rollback_ref,
                    expiry if decision == "approve" else None,
                    utc_now(),
                    autonomy_decision_id,
                ),
            )
            if decision == "approve":
                self.conn.execute(
                    "UPDATE teaching_students SET autonomy_level=?, updated_at=? WHERE student_id=?",
                    (to_level, utc_now(), row["student_id"]),
                )
            elif decision == "rollback":
                self.conn.execute(
                    "UPDATE teaching_students SET autonomy_level=?, updated_at=? WHERE student_id=?",
                    (row["from_level"], utc_now(), row["student_id"]),
                )
        return dict(
            self.conn.execute(
                "SELECT * FROM autonomy_decisions WHERE autonomy_decision_id=?",
                (autonomy_decision_id,),
            ).fetchone()
        )

    def directives(self, task_session_id: str, status: str | None = None) -> list[dict[str, Any]]:
        sql = "SELECT * FROM coaching_directives WHERE task_session_id=?"
        params: list[Any] = [task_session_id]
        if status:
            sql += " AND status=?"
            params.append(status)
        sql += " ORDER BY created_at, directive_id"
        return _dicts(list(self.conn.execute(sql, params).fetchall()))

    def directive_resolve(self, directive_id: str, evidence_ref: str) -> dict[str, Any]:
        with self.conn:
            self.conn.execute(
                "UPDATE coaching_directives SET status='resolved', resolved_at=? WHERE directive_id=?",
                (utc_now(), directive_id),
            )
        row = self.conn.execute(
            "SELECT * FROM coaching_directives WHERE directive_id=?", (directive_id,)
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown coaching directive: {directive_id}")
        result = dict(row)
        result["evidence_ref"] = evidence_ref
        return result

    def feedback(
        self,
        correction_summary: str,
        desired_behavior: str,
        *,
        task_session_id: str | None = None,
        actor: str = "local-user",
        scope: str = "repo",
        privacy_class: str = "summary_only",
        evidence_refs: list[str] | None = None,
    ) -> dict[str, Any]:
        student = self.ensure_student()
        feedback_id = stable_id(
            "professional-feedback", self.repo_id, task_session_id, correction_summary
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO professional_teacher_feedback(
                  feedback_id, task_session_id, student_id, correction_summary,
                  desired_behavior, scope, privacy_class, actor,
                  evidence_refs_json, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    feedback_id,
                    task_session_id,
                    student["student_id"],
                    _privacy_safe(correction_summary, privacy_class),
                    _privacy_safe(desired_behavior, privacy_class),
                    scope,
                    privacy_class,
                    actor,
                    _json(evidence_refs or []),
                    utc_now(),
                ),
            )
        return dict(
            self.conn.execute(
                "SELECT * FROM professional_teacher_feedback WHERE feedback_id=?",
                (feedback_id,),
            ).fetchone()
        )

    def review_request(
        self,
        item_type: str,
        item_id: str,
        *,
        requested_by: str,
        risk: str = "medium",
        required_roles: list[str] | None = None,
    ) -> dict[str, Any]:
        roles = required_roles or ["professional_teacher"]
        if required_roles is None and risk in {"high", "critical"}:
            roles.append("repository_maintainer")
        if required_roles is None and risk == "critical":
            roles.append("security_owner")
        review_id = stable_id("professional-review", self.repo_id, item_type, item_id)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO professional_teacher_reviews(
                  review_id, item_type, item_id, repo_id, risk,
                  required_roles_json, requested_by, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    review_id,
                    item_type,
                    item_id,
                    self.repo_id,
                    risk,
                    _json(roles),
                    requested_by,
                    utc_now(),
                ),
            )
        return self.review_show(review_id)

    def review_list(self, status: str | None = "pending") -> list[dict[str, Any]]:
        sql = "SELECT * FROM professional_teacher_reviews WHERE repo_id=?"
        params: list[Any] = [self.repo_id]
        if status:
            sql += " AND status=?"
            params.append(status)
        sql += " ORDER BY created_at, review_id"
        return [self._review(row) for row in self.conn.execute(sql, params).fetchall()]

    def review_show(self, review_id: str) -> dict[str, Any]:
        row = self.conn.execute(
            "SELECT * FROM professional_teacher_reviews WHERE review_id=?",
            (review_id,),
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown professional teacher review: {review_id}")
        return self._review(row)

    def review_decide(
        self, review_id: str, decision: str, *, actor: str, role: str, rationale: str = ""
    ) -> dict[str, Any]:
        review = self.review_show(review_id)
        if decision not in {"approve", "reject", "request_changes"}:
            raise ValueError(f"unsupported review decision: {decision}")
        if role not in review["required_roles"]:
            raise PermissionError(f"review requires one of: {', '.join(review['required_roles'])}")
        votes = json.loads(review.get("assigned_to") or "[]")
        if not isinstance(votes, list):
            votes = []
        if decision == "approve":
            if any(str(vote).split(":", 1)[-1] == actor for vote in votes):
                raise PermissionError("one actor cannot satisfy multiple review roles")
            vote = f"{role}:{actor}"
            if vote not in votes:
                votes.append(vote)
            approved_roles = {str(vote).split(":", 1)[0] for vote in votes}
            status = "approved" if set(review["required_roles"]) <= approved_roles else "pending"
        else:
            status = {
                "reject": "rejected",
                "request_changes": "changes_requested",
            }[decision]
        with self.conn:
            self.conn.execute(
                """
                UPDATE professional_teacher_reviews SET status=?, decision=?,
                  rationale=?, decided_by=?, assigned_to=?, decided_at=? WHERE review_id=?
                """,
                (
                    status,
                    decision,
                    rationale,
                    actor,
                    _json(votes),
                    utc_now() if status != "pending" else None,
                    review_id,
                ),
            )
        return self.review_show(review_id)

    def team_export(self, lesson_ids: list[str], *, scope: str, actor: str) -> dict[str, Any]:
        lessons = [self.lesson_show(lesson_id) for lesson_id in sorted(set(lesson_ids))]
        disallowed = [
            item["lesson_id"]
            for item in lessons
            if item["status"] not in {"approved", "benchmarked", "active"}
            or item["privacy_class"] in {"do_not_store", "no_raw_content"}
        ]
        if disallowed:
            raise ValueError(f"lessons are not exportable: {', '.join(disallowed)}")
        manifest = {
            "schema_version": "persistmind.team_lesson_exchange.v1",
            "source_repo_id": self.repo_id,
            "scope": scope,
            "lessons": [
                {
                    key: item[key]
                    for key in (
                        "lesson_id",
                        "lesson_type",
                        "summary",
                        "rule_text",
                        "scope",
                        "status",
                        "privacy_class",
                        "evidence_count",
                        "approved_by",
                        "approved_at",
                    )
                }
                for item in lessons
            ],
            "created_at": utc_now(),
        }
        content_hash = stable_id(canonical_json(manifest))
        export_id = stable_id("team-export", self.repo_id, content_hash)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO team_lesson_exports(
                  export_id, repo_id, scope, manifest_json, content_hash,
                  created_by, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    export_id,
                    self.repo_id,
                    scope,
                    canonical_json(manifest),
                    content_hash,
                    actor,
                    utc_now(),
                ),
            )
        return {"export_id": export_id, "content_hash": content_hash, "manifest": manifest}

    def team_import(self, source: str, manifest: dict[str, Any]) -> dict[str, Any]:
        if manifest.get("schema_version") != "persistmind.team_lesson_exchange.v1":
            raise ValueError("unsupported team exchange schema")
        lessons = manifest.get("lessons") or []
        existing = {item["lesson_id"] for item in self.lessons()}
        conflicts = sorted(
            str(item.get("lesson_id")) for item in lessons if item.get("lesson_id") in existing
        )
        import_id = stable_id("team-import", self.repo_id, source, canonical_json(manifest))
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO team_lesson_imports(
                  import_id, repo_id, source, manifest_json, conflicts_json,
                  accepted_items_json, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    import_id,
                    self.repo_id,
                    source,
                    canonical_json(manifest),
                    _json(conflicts),
                    _json([]),
                    utc_now(),
                ),
            )
        return {
            "schema_version": "persistmind.team_import.v1",
            "import_id": import_id,
            "status": "candidate",
            "item_count": len(lessons),
            "conflicts": conflicts,
        }

    def team_import_decide(
        self,
        import_id: str,
        decision: str,
        *,
        actor: str,
        role: str,
    ) -> dict[str, Any]:
        del role  # Payload role is audit data only; transport principal owns authority.
        require_current_principal(roles=frozenset({"admin"}), action="teacher.team_import.decide")
        if decision not in {"approve", "reject"}:
            raise ValueError(f"unsupported import decision: {decision}")
        row = self.conn.execute(
            "SELECT * FROM team_lesson_imports WHERE import_id=?", (import_id,)
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown team import: {import_id}")
        manifest = json.loads(row["manifest_json"] or "{}")
        conflicts = set(json.loads(row["conflicts_json"] or "[]"))
        accepted: list[str] = []
        rejected: list[str] = []
        if decision == "approve":
            for imported in manifest.get("lessons") or []:
                source_id = str(imported.get("lesson_id") or "")
                if not source_id or source_id in conflicts:
                    rejected.append(source_id)
                    continue
                lesson = self.lesson_candidate(
                    str(imported.get("summary") or "Imported lesson"),
                    rule_text=str(imported.get("rule_text") or ""),
                    lesson_type=str(imported.get("lesson_type") or "technical"),
                    scope=str(imported.get("scope") or "repo"),
                )
                accepted.append(str(lesson["lesson_id"]))
        else:
            rejected = [str(item.get("lesson_id") or "") for item in manifest.get("lessons") or []]
        status = "approved" if decision == "approve" else "rejected"
        with self.conn:
            self.conn.execute(
                """
                UPDATE team_lesson_imports SET status=?, accepted_items_json=?,
                  rejected_items_json=?, reviewed_at=? WHERE import_id=?
                """,
                (
                    status,
                    _json(accepted),
                    _json(rejected),
                    utc_now(),
                    import_id,
                ),
            )
        return {
            "schema_version": "persistmind.team_import_decision.v1",
            "import_id": import_id,
            "status": status,
            "actor": actor,
            "accepted_items": accepted,
            "rejected_items": rejected,
        }

    @staticmethod
    def _review(row: sqlite3.Row) -> dict[str, Any]:
        result = dict(row)
        result["required_roles"] = json.loads(result.pop("required_roles_json") or "[]")
        try:
            result["votes"] = json.loads(result.get("assigned_to") or "[]")
        except json.JSONDecodeError:
            result["votes"] = []
        return result
