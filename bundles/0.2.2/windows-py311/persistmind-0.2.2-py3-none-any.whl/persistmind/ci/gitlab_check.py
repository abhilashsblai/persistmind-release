GITLAB_CI_YAML = """persistmind:
  image: python:3.12
  script:
    - pip install persistmind
    - persistmind ci check --base origin/main --head HEAD
"""
