GITHUB_ACTION_YAML = """name: PERSISTMIND Safety Check

on:
  pull_request:

jobs:
  persistmind:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - name: Install persistmind
        run: pipx install persistmind
      - name: Run PERSISTMIND CI check
        run: persistmind ci check --base origin/main --head HEAD
"""
