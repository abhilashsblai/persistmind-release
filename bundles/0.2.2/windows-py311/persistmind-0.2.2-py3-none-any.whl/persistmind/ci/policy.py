from __future__ import annotations

import fnmatch
import subprocess
from pathlib import Path
from typing import Any

from persistmind.config import CIConfig
from persistmind.governance import CapabilityPolicy
from persistmind.impact import ImpactEngine
from persistmind.snapshot import SnapshotInfo


class CIChecker:
    def __init__(
        self,
        repo_root: Path,
        store: Any,
        impact: ImpactEngine,
        config: CIConfig,
    ):
        self.repo_root = repo_root
        self.store = store
        self.impact = impact
        self.config = config

    def check(
        self,
        *,
        snapshot: SnapshotInfo,
        base: str = "origin/main",
        head: str = "HEAD",
        pack_id: str | None = None,
        labels: list[str] | None = None,
    ) -> dict[str, Any]:
        diff = self._git_diff(base, head)
        paths = paths_from_diff(diff)
        violations: list[dict[str, Any]] = []
        impact_report = self.impact.report(snapshot=snapshot, paths=paths, pack_id=pack_id)
        if self.config.require_pack and not pack_id:
            violations.append(
                {
                    "type": "missing_pack",
                    "path": "",
                    "severity": "high",
                    "reason": "CI policy requires a context pack generated before edits.",
                }
            )
        for path in impact_report.get("pack_awareness", {}).get("out_of_pack_paths", []):
            severity = "high" if self._is_critical(path) else "medium"
            violations.append(
                {
                    "type": "out_of_pack_edit",
                    "path": path,
                    "severity": severity,
                    "reason": "File was changed but was not included in the served pack or impact closure.",
                }
            )
        selected_tests = [test["command"] for test in impact_report.get("tests", [])]
        if self.config.require_selected_tests and not selected_tests and paths:
            violations.append(
                {
                    "type": "missing_selected_tests",
                    "path": "",
                    "severity": "medium",
                    "reason": "No selected tests were identified or recorded.",
                }
            )
        if self.config.business_rules_enabled:
            violations.extend(self._business_rule_violations(paths))
        capability_report = CapabilityPolicy(
            self.repo_root,
            _settings_from_ci(self.config),
        ).check_paths(
            paths,
            deleted_paths=deleted_paths_from_diff(diff),
            for_ci=True,
        )
        for violation in capability_report["violations"]:
            violations.append(
                {
                    "type": violation["type"],
                    "path": violation["path"],
                    "severity": violation["severity"],
                    "reason": violation["reason"],
                    "capability": violation["capability"],
                    "mode": violation["mode"],
                }
            )
        acknowledged = self.config.allow_out_of_pack_with_label in (labels or [])
        required_ack = bool(violations) and not acknowledged
        fail_closed = any(v["severity"] == "high" for v in violations)
        status = "pass"
        if violations and self.config.mode in {"fail", "strict"}:
            status = "fail"
        elif violations:
            status = "warn"
        if any(
            v["type"] == "business_rule_at_risk" and v["severity"] == "high" for v in violations
        ):
            if self.config.fail_on_high_risk_rule_changes:
                status = "fail"
        if acknowledged and not fail_closed:
            status = "pass"
        report = {
            "status": status,
            "pack_id": pack_id,
            "snapshot_id": snapshot.snapshot_id,
            "violations": violations,
            "selected_tests": selected_tests,
            "required_acknowledgement": required_ack,
            "impact_report": impact_report,
        }
        report_id = self.store.write_ci_report(
            repo_id=snapshot.repo_id, status=status, report=report
        )
        return {"ci_report_id": report_id, **report}

    def _business_rule_violations(self, changed_paths: list[str]) -> list[dict[str, Any]]:
        violations: list[dict[str, Any]] = []
        active_rules = [dict(row) for row in self.store.business_rules("active")]
        for rule in active_rules:
            evidence = [dict(row) for row in self.store.rule_evidence(rule["rule_id"])]
            evidence_paths = {row.get("path") for row in evidence if row.get("path")}
            scope = rule.get("scope_glob") or ""
            touches_scope = any(
                (path in evidence_paths)
                or (scope and fnmatch.fnmatch(path, scope))
                or (scope and fnmatch.fnmatch(scope, path))
                for path in changed_paths
            )
            if touches_scope:
                violations.append(
                    {
                        "type": "business_rule_at_risk",
                        "rule_id": rule["rule_id"],
                        "path": scope,
                        "severity": (
                            "high" if self.config.fail_on_high_risk_rule_changes else "medium"
                        ),
                        "reason": "PR modifies known evidence or scope for an active business rule.",
                        "summary": rule["rule_text"],
                        "required_action": "Run selected tests and request approval from the rule scope owner.",
                    }
                )
            if self.config.warn_on_stale_rules:
                for row in evidence:
                    path = row.get("path")
                    if path and not (self.repo_root / path).exists():
                        violations.append(
                            {
                                "type": "stale_business_rule",
                                "rule_id": rule["rule_id"],
                                "path": path,
                                "severity": "medium",
                                "reason": "Business-rule evidence file no longer exists.",
                            }
                        )
        if self.config.block_on_conflicting_rules:
            rules = active_rules
            seen = set()
            for left in rules:
                for right in rules:
                    key = tuple(sorted([left["rule_id"], right["rule_id"]]))
                    if left["rule_id"] == right["rule_id"] or key in seen:
                        continue
                    seen.add(key)
                    if _threshold_conflict(left["rule_text"], right["rule_text"]):
                        violations.append(
                            {
                                "type": "conflicting_business_rules",
                                "rule_id": left["rule_id"],
                                "path": left.get("scope_glob") or "",
                                "severity": "high",
                                "reason": "Conflicting active business rules were detected.",
                            }
                        )
        return violations

    def explain(self, report: dict[str, Any]) -> str:
        lines = [f"PERSISTMIND CI status: {report.get('status', 'unknown')}"]
        for violation in report.get("violations", []):
            path = f" {violation['path']}" if violation.get("path") else ""
            lines.append(
                f"- {violation['severity']}: {violation['type']}{path}: {violation['reason']}"
            )
        return "\n".join(lines)

    def _is_critical(self, path: str) -> bool:
        return any(fnmatch.fnmatch(path, glob) for glob in self.config.critical_paths)

    def _git_diff(self, base: str, head: str) -> str:
        try:
            diff = subprocess.run(
                ["git", "diff", "--no-ext-diff", f"{base}...{head}"],
                cwd=self.repo_root,
                check=True,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                timeout=30,
            ).stdout
            if diff.strip():
                return diff
        except (subprocess.SubprocessError, FileNotFoundError):
            pass
        return subprocess.run(
            ["git", "diff", "--no-ext-diff", head],
            cwd=self.repo_root,
            check=False,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=30,
        ).stdout


def paths_from_diff(diff: str) -> list[str]:
    paths: set[str] = set()
    for line in diff.splitlines():
        if line.startswith("diff --git "):
            parts = line.split()
            if len(parts) >= 4:
                paths.add(parts[3].removeprefix("b/"))
        elif line.startswith("+++ b/"):
            paths.add(line[6:])
        elif line.startswith("--- a/"):
            paths.add(line[6:])
    return sorted(path for path in paths if path and path != "/dev/null")


def deleted_paths_from_diff(diff: str) -> list[str]:
    paths: set[str] = set()
    current: str | None = None
    for line in diff.splitlines():
        if line.startswith("diff --git "):
            parts = line.split()
            current = parts[3].removeprefix("b/") if len(parts) >= 4 else None
        elif line.startswith("+++ /dev/null") and current:
            paths.add(current)
    return sorted(paths)


def _settings_from_ci(config: CIConfig):
    from persistmind.config import Settings

    return Settings(ci=config)


def _threshold_conflict(left: str, right: str) -> bool:
    import re

    left_numbers = {
        int(num.replace(",", "").replace("_", "")) for num in re.findall(r"\d[\d,_]*", left)
    }
    right_numbers = {
        int(num.replace(",", "").replace("_", "")) for num in re.findall(r"\d[\d,_]*", right)
    }
    if not left_numbers or not right_numbers or left_numbers == right_numbers:
        return False
    left_terms = set(re.findall(r"[a-zA-Z]{4,}", left.lower()))
    right_terms = set(re.findall(r"[a-zA-Z]{4,}", right.lower()))
    return len(left_terms & right_terms) >= 2
