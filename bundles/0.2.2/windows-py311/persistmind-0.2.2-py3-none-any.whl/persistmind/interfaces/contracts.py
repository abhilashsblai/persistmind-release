from __future__ import annotations

from enum import IntEnum, StrEnum
from typing import Any, Mapping

from persistmind.utils import canonical_json, stable_id


RESULT_SCHEMA_VERSION = "persistmind.interface_result.v1"


class InterfaceStatus(StrEnum):
    OK = "ok"
    UNSUPPORTED_OPERATION = "unsupported_operation"
    OPERATION_UNAVAILABLE = "operation_unavailable"
    FEATURE_DISABLED = "feature_disabled"
    SOURCE_NOT_READY = "source_not_ready"
    NOT_AUTHORIZED = "not_authorized"
    UNSAFE = "unsafe"
    UNDERSPECIFIED = "underspecified"
    CONTRADICTORY = "contradictory"
    UNIDENTIFIABLE = "unidentifiable"
    INTRACTABLE = "intractable"
    NOT_COMPUTABLE = "not_computable"
    EXTERNAL_DEPENDENCY = "external_dependency"
    UNKNOWN = "unknown"
    VALIDATION_FAILED = "validation_failed"
    UNAUTHORIZED = "unauthorized"
    FORBIDDEN = "forbidden"
    CONFLICT = "conflict"
    BUSY = "busy"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"
    DEGRADED = "degraded"
    INDEX_REQUIRED = "index_required"
    SEED_PATH_OUTSIDE_REPO = "seed_path_outside_repo"
    SEED_SCOPE_EMPTY = "seed_scope_empty"
    SEED_UNSUPPORTED = "seed_unsupported"
    SEED_PATH_MISSING = "seed_path_missing"
    SEED_EXPANSION_LIMIT = "seed_expansion_limit"
    PACK_UNUSABLE = "pack_unusable"
    SOURCE_INDEX_INVALID = "source_index_invalid"
    DATABASE_UNAVAILABLE = "database_unavailable"
    DATABASE_CORRUPT = "database_corrupt"
    STORAGE_NOT_INITIALIZED = "storage_not_initialized"
    SQLITE_RUNTIME_UNSUPPORTED = "sqlite_runtime_unsupported"
    LEGACY_DATA_PRESENT = "legacy_data_present"
    EMPTY_LEGACY_SHELL_PRESENT = "empty_legacy_shell_present"
    CATALOG_RECOVERY_AMBIGUOUS = "catalog_recovery_ambiguous"
    AUTHORITY_ROUTING_INCOMPLETE = "authority_routing_incomplete"
    VERIFICATION_FAILED = "verification_failed"
    VERIFICATION_INCOMPLETE = "verification_incomplete"
    RELEASE_GATE_FAILED = "release_gate_failed"
    INTERNAL_ERROR = "internal_error"


class CliExitCode(IntEnum):
    SUCCESS = 0
    VALIDATION = 2
    DEGRADED = 3
    CONFLICT = 4
    TIMEOUT = 4
    USER_ACTION = 5
    INDEX_REQUIRED = 6
    DATABASE = 7
    VERIFICATION = 7
    AUTHORIZATION = 8
    UNSAFE = 9
    INTERNAL = 10


_EXIT_BY_STATUS = {
    InterfaceStatus.UNSUPPORTED_OPERATION: CliExitCode.USER_ACTION,
    InterfaceStatus.OPERATION_UNAVAILABLE: CliExitCode.USER_ACTION,
    InterfaceStatus.FEATURE_DISABLED: CliExitCode.USER_ACTION,
    InterfaceStatus.SOURCE_NOT_READY: CliExitCode.INDEX_REQUIRED,
    InterfaceStatus.NOT_AUTHORIZED: CliExitCode.AUTHORIZATION,
    InterfaceStatus.UNSAFE: CliExitCode.UNSAFE,
    InterfaceStatus.UNDERSPECIFIED: CliExitCode.VALIDATION,
    InterfaceStatus.CONTRADICTORY: CliExitCode.CONFLICT,
    InterfaceStatus.UNIDENTIFIABLE: CliExitCode.VALIDATION,
    InterfaceStatus.INTRACTABLE: CliExitCode.DEGRADED,
    InterfaceStatus.NOT_COMPUTABLE: CliExitCode.VALIDATION,
    InterfaceStatus.EXTERNAL_DEPENDENCY: CliExitCode.DEGRADED,
    InterfaceStatus.UNKNOWN: CliExitCode.DEGRADED,
    InterfaceStatus.VALIDATION_FAILED: CliExitCode.VALIDATION,
    InterfaceStatus.UNAUTHORIZED: CliExitCode.AUTHORIZATION,
    InterfaceStatus.FORBIDDEN: CliExitCode.AUTHORIZATION,
    InterfaceStatus.CONFLICT: CliExitCode.CONFLICT,
    InterfaceStatus.BUSY: CliExitCode.CONFLICT,
    InterfaceStatus.TIMEOUT: CliExitCode.TIMEOUT,
    InterfaceStatus.CANCELLED: CliExitCode.TIMEOUT,
    InterfaceStatus.DEGRADED: CliExitCode.DEGRADED,
    InterfaceStatus.INDEX_REQUIRED: CliExitCode.INDEX_REQUIRED,
    InterfaceStatus.SEED_PATH_OUTSIDE_REPO: CliExitCode.VALIDATION,
    InterfaceStatus.SEED_SCOPE_EMPTY: CliExitCode.VALIDATION,
    InterfaceStatus.SEED_UNSUPPORTED: CliExitCode.VALIDATION,
    InterfaceStatus.SEED_PATH_MISSING: CliExitCode.VALIDATION,
    InterfaceStatus.SEED_EXPANSION_LIMIT: CliExitCode.VALIDATION,
    InterfaceStatus.PACK_UNUSABLE: CliExitCode.VALIDATION,
    InterfaceStatus.SOURCE_INDEX_INVALID: CliExitCode.VALIDATION,
    InterfaceStatus.DATABASE_UNAVAILABLE: CliExitCode.DEGRADED,
    InterfaceStatus.DATABASE_CORRUPT: CliExitCode.DATABASE,
    InterfaceStatus.STORAGE_NOT_INITIALIZED: CliExitCode.USER_ACTION,
    InterfaceStatus.SQLITE_RUNTIME_UNSUPPORTED: CliExitCode.INDEX_REQUIRED,
    InterfaceStatus.LEGACY_DATA_PRESENT: CliExitCode.USER_ACTION,
    InterfaceStatus.EMPTY_LEGACY_SHELL_PRESENT: CliExitCode.USER_ACTION,
    InterfaceStatus.CATALOG_RECOVERY_AMBIGUOUS: CliExitCode.UNSAFE,
    InterfaceStatus.AUTHORITY_ROUTING_INCOMPLETE: CliExitCode.INDEX_REQUIRED,
    InterfaceStatus.VERIFICATION_FAILED: CliExitCode.VERIFICATION,
    InterfaceStatus.VERIFICATION_INCOMPLETE: CliExitCode.VERIFICATION,
    InterfaceStatus.RELEASE_GATE_FAILED: CliExitCode.DEGRADED,
    InterfaceStatus.INTERNAL_ERROR: CliExitCode.INTERNAL,
}


def finalize_result(
    value: Mapping[str, Any] | None,
    *,
    operation: str,
    correlation_id: str | None = None,
    failed_stage: str | None = None,
) -> dict[str, Any]:
    """Add the stable public envelope without nesting or dropping legacy fields."""
    result = dict(value or {})
    reported_status = str(result.get("status") or "").strip().casefold()
    ok = bool(
        result.get(
            "ok",
            reported_status not in {"fail", "error", "release_gate_failed", "verification_failed"},
        )
    )
    raw_status = str(result.get("status") or ("ok" if ok else _inferred_failure_status(result)))
    status = normalize_status(raw_status, ok=ok)
    failure_identity = (
        "" if ok else _failure_correlation(result, operation=operation, status=status)
    )
    correlation = correlation_id or str(
        result.get("correlation_id")
        or result.get("task_session_id")
        or result.get("pack_id")
        or failure_identity
    )
    operation_id = str(
        result.get("operation_id")
        or stable_id("interface_operation", operation, correlation, status, failure_identity)
    )
    public_status = (
        raw_status if ok and raw_status not in {"ok", "pass", "ready", "complete"} else status
    )
    result.update(
        {
            "ok": ok,
            "status": public_status,
            "interface_status": status,
            "interface_schema_version": RESULT_SCHEMA_VERSION,
            "operation_id": operation_id,
            "correlation_id": correlation or operation_id,
            "failed_stage": result.get("failed_stage") or failed_stage,
            "retryable": bool(
                result.get(
                    "retryable",
                    status in {"busy", "timeout", "external_dependency", "source_not_ready"},
                )
            ),
            "remediation": result.get("remediation"),
            "details": _safe_details(result.get("details")),
        }
    )
    reporting_refs = {
        key: result.get(key)
        for key in (
            "operation_id",
            "correlation_id",
            "task_session_id",
            "agent_session_id",
            "pack_id",
            "snapshot_id",
            "generation_id",
        )
        if result.get(key)
    }
    if reporting_refs:
        result.setdefault("reporting_refs", reporting_refs)
        feedback_reference = reporting_refs.get("operation_id") or reporting_refs.get("pack_id")
        if feedback_reference:
            result.setdefault(
                "feedback_hint",
                f"persistmind --repo . feedback {feedback_reference} --rating 1..5 --reason <category>",
            )
    from persistmind.release_identity import maturity_warning, public_release_identity

    result.setdefault("release_identity", public_release_identity())
    warning = maturity_warning()
    if warning:
        result.setdefault("maturity_warning", warning)
    return publicize_value(result)


def normalize_status(status: str, *, ok: bool = False) -> str:
    normalized = status.strip().casefold().replace("-", "_")
    aliases = {
        "pass": "ok",
        "ready": "ok",
        "complete": "ok",
        "fail": "release_gate_failed",
        "error": "internal_error",
        "command_failed": "verification_failed",
        "database_locked": "busy",
        "database_busy": "busy",
        "database_malformed": "database_corrupt",
        "database_locator_invalid": "database_unavailable",
        "permission_denied": "forbidden",
        "not_authorised": "not_authorized",
        "unauthorised": "not_authorized",
        "uninitialized": "storage_not_initialized",
    }
    normalized = aliases.get(normalized, normalized)
    if ok:
        return "ok"
    allowed = {item.value for item in InterfaceStatus if item is not InterfaceStatus.OK}
    return normalized if normalized in allowed else "internal_error"


def exit_code_for_result(value: Mapping[str, Any] | None) -> int:
    if value is None or bool(value.get("ok", True)):
        return int(CliExitCode.SUCCESS)
    status = normalize_status(
        str(value.get("interface_status") or value.get("status") or "internal_error")
    )
    try:
        typed = InterfaceStatus(status)
    except ValueError:
        typed = InterfaceStatus.INTERNAL_ERROR
    return int(_EXIT_BY_STATUS.get(typed, CliExitCode.INTERNAL))


def exception_result(
    exc: BaseException,
    *,
    operation: str,
    expose_error: bool = True,
    failed_stage: str = "dispatch",
) -> dict[str, Any]:
    """Normalize transport exceptions through the same semantic result path."""
    status = getattr(exc, "status", None)
    if not status:
        status = (
            "validation_failed"
            if isinstance(exc, (ValueError, KeyError))
            else "not_authorized"
            if isinstance(exc, PermissionError)
            else "timeout"
            if isinstance(exc, TimeoutError)
            else "external_dependency"
            if isinstance(exc, (ConnectionError, OSError))
            else "internal_error"
        )
    public_error = (
        str(exc) if expose_error or status != "internal_error" else "internal server error"
    )
    return finalize_result(
        {
            "ok": False,
            "status": status,
            "error": public_error,
            "error_type": type(exc).__name__,
            "remediation": getattr(exc, "remediation", None),
        },
        operation=operation,
        failed_stage=failed_stage,
    )


def http_status_for_result(value: Mapping[str, Any]) -> int:
    status = normalize_status(
        str(value.get("interface_status") or value.get("status") or "internal_error")
    )
    if bool(value.get("ok", False)):
        return 200
    if status in {"not_authorized", "forbidden"}:
        return 403
    if status == "unauthorized":
        return 401
    if status in {"unsupported_operation"}:
        return 404
    if status in {
        "operation_unavailable",
        "feature_disabled",
        "source_not_ready",
        "conflict",
        "busy",
        "storage_not_initialized",
    }:
        return 409
    if status in {"timeout", "external_dependency"}:
        return 503
    if status in {"unsafe"}:
        return 422
    if status in {
        "validation_failed",
        "underspecified",
        "contradictory",
        "unidentifiable",
        "intractable",
        "not_computable",
        "unknown",
    }:
        return 400
    return 500


def _inferred_failure_status(value: Mapping[str, Any]) -> str:
    """Classify expected negative results that predate the public envelope.

    Several service methods return ``ok=false`` for validation or lookup
    outcomes without raising an exception.  Treating those as internal errors
    creates false high-severity incident reports.
    """

    error = str(value.get("error") or "").strip().casefold()
    if (
        "validation" in value
        or "schema_errors" in value
        or "violations" in value
        or error.endswith("not found")
        or " not found:" in error
    ):
        return "validation_failed"
    return "internal_error"


def _failure_correlation(
    value: Mapping[str, Any],
    *,
    operation: str,
    status: str,
) -> str:
    """Return a deterministic diagnostic identity for otherwise unbound failures.

    Operation/status alone is too coarse: it caused unrelated plan failures to
    share one feedback and incident reference. Keep retries of the same failure
    stable while separating failures with different actionable diagnostics.
    """

    identity = {
        key: value.get(key)
        for key in (
            "error_type",
            "error_code",
            "error",
            "path",
            "failed_stage",
            "schema_errors",
            "diagnostics",
        )
        if value.get(key) not in (None, "", [], {})
    }
    validation = value.get("validation")
    if isinstance(validation, Mapping):
        nested = {
            key: validation.get(key)
            for key in ("error_code", "schema_errors", "diagnostics")
            if validation.get(key) not in (None, "", [], {})
        }
        if nested:
            identity["validation"] = nested
    return stable_id("interface_failure", operation, status, canonical_json(identity))


def _safe_details(value: Any) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        return {}
    blocked = {"token", "secret", "password", "authorization", "api_key"}
    return {
        str(key): item
        for key, item in value.items()
        if not any(part in str(key).casefold() for part in blocked)
    }


def publicize_value(value: Any) -> Any:
    """Remove compatibility-era product names from public interface values.

    Persisted schemas and Python package namespaces remain backward-compatible
    internally. CLI and MCP-facing envelopes must expose only the PersistMind
    product name.
    """

    if isinstance(value, Mapping):
        return {_public_brand_text(str(key)): publicize_value(item) for key, item in value.items()}
    if isinstance(value, list):
        return [publicize_value(item) for item in value]
    if isinstance(value, tuple):
        return tuple(publicize_value(item) for item in value)
    if isinstance(value, str):
        return _public_brand_text(value)
    return value


def _public_brand_text(value: str) -> str:
    return value
