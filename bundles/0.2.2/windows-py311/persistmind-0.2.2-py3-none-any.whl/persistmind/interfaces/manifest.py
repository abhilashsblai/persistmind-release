from __future__ import annotations

import json
import hashlib
import re
import subprocess
import tomllib
from pathlib import Path
from typing import Any

from packaging.version import InvalidVersion, Version

from persistmind.http.routes import ROUTES
from persistmind.interfaces.contracts import InterfaceStatus
from persistmind.utils import canonical_json, sha256_text


MANIFEST_SCHEMA_VERSION = "persistmind.interface_manifest.v2"


def _normalized_text_sha256(path: Path) -> str:
    """Hash tracked text independently of the checkout's newline convention."""

    normalized = path.read_text(encoding="utf-8").replace("\r\n", "\n").replace("\r", "\n")
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def generate_interface_manifest(repo_root: Path) -> dict[str, Any]:
    from persistmind.application.registry import operation_catalog_document
    from persistmind.release.readiness import generate_source_surface_inventory
    from persistmind.security.actions import cli_operation_action, http_route_action
    from persistmind.server.mcp_server import MCP_TOOL_ACTIONS

    inventory = generate_source_surface_inventory(repo_root)
    catalog = operation_catalog_document()
    operations: list[dict[str, Any]] = []
    for item in inventory["public_operations"]:
        if item["surface"] == "http":
            continue
        surface = str(item["surface"])
        operation = str(item["operation"])
        operations.append(
            _operation(
                operation_id=f"{surface}:{operation}",
                surface=surface,
                operation=operation,
                mutation="read_only" if surface == "mcp" else "command_dependent",
                auth=(
                    "stdio_local_unauthenticated_read_only"
                    if surface == "mcp"
                    else "local_os_repository_principal"
                ),
                maturity=str(item.get("maturity") or "stable"),
                actions=(
                    {"call": MCP_TOOL_ACTIONS.get(operation)}
                    if surface == "mcp"
                    else {"call": cli_operation_action(operation)}
                ),
            )
        )
    for route in sorted(set(ROUTES)):
        operations.append(
            _operation(
                operation_id=f"http:{route}",
                surface="http",
                operation=route,
                mutation="method_dependent",
                auth=("public" if route == "/v1/health" else "transport_principal"),
                maturity="preview",
                actions={
                    "GET": http_route_action("GET", route) or "unsupported",
                    "MUTATION": http_route_action("POST", route) or "unsupported",
                },
            )
        )
    operations.sort(key=lambda item: item["id"])
    payload = {
        "schema_version": MANIFEST_SCHEMA_VERSION,
        "generated_for_commit": inventory["generated_for_commit"],
        "generator": {"name": "persistmind.interfaces.manifest", "version": 2},
        "inputs": {
            "operation_catalog_sha256": sha256_text(canonical_json(catalog)),
            "route_registry_sha256": sha256_text(canonical_json(sorted(set(ROUTES)))),
            "surface_inventory_sha256": sha256_text(
                canonical_json(
                    {
                        key: value
                        for key, value in inventory.items()
                        if key != "generated_for_commit"
                    }
                )
            ),
        },
        "result_schema": "persistmind.interface_result.v1",
        "operations": operations,
    }
    payload["operation_count"] = len(operations)
    payload["manifest_hash"] = sha256_text(canonical_json(payload))
    return payload


def write_interface_artifacts(repo_root: Path) -> dict[str, Any]:
    payload = generate_interface_manifest(repo_root)
    manifest_path = repo_root / "plan" / "interface-manifest.json"
    docs_path = repo_root / "docs" / "generated" / "interface-reference.md"
    compatibility_path = repo_root / "plan" / "interface-compatibility.json"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    docs_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        previous = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        previous = {}
    previous_commit = str(previous.get("generated_for_commit") or "")
    previous_semantic = {
        key: value
        for key, value in previous.items()
        if key not in {"generated_for_commit", "manifest_hash"}
    }
    current_semantic = {
        key: value
        for key, value in payload.items()
        if key not in {"generated_for_commit", "manifest_hash"}
    }
    if (
        previous_commit
        and previous_semantic == current_semantic
        and _git_is_ancestor(repo_root, previous_commit)
    ):
        payload["generated_for_commit"] = previous_commit
        payload.pop("manifest_hash", None)
        payload["manifest_hash"] = sha256_text(canonical_json(payload))
    manifest_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    docs_path.write_text(_render_docs(payload), encoding="utf-8")
    compatibility = generate_compatibility_registry(repo_root)
    compatibility_path.write_text(
        json.dumps(compatibility, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return {
        "ok": True,
        "schema_version": "persistmind.interface_artifacts.v1",
        "manifest": str(manifest_path),
        "docs": str(docs_path),
        "compatibility": str(compatibility_path),
        "manifest_hash": payload["manifest_hash"],
    }


def validate_interface_artifacts(repo_root: Path) -> dict[str, Any]:
    schema_root = repo_root / "src" / "persistmind" / "storage" / "resources" / "schemas"
    if not schema_root.is_dir() or not any(schema_root.rglob("*.sql")):
        from persistmind.application.registry import operation_catalog

        catalog = operation_catalog()
        active = [
            descriptor
            for descriptor in catalog.values()
            if descriptor.availability.value == "active"
        ]
        return {
            "ok": True,
            "status": "installed_contract_verified",
            "schema_version": "persistmind.interface_artifact_validation.v1",
            "violations": [],
            "operation_count": sum(
                len(names)
                for descriptor in active
                for names in descriptor.transport_bindings.values()
            ),
            "validation_scope": "installed_runtime",
        }
    expected = generate_interface_manifest(repo_root)
    path = repo_root / "plan" / "interface-manifest.json"
    try:
        actual = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        actual = {}
    violations = []
    actual_commit = str(actual.get("generated_for_commit") or "")
    if actual_commit and _git_is_ancestor(repo_root, actual_commit):
        expected["generated_for_commit"] = actual_commit
        expected.pop("manifest_hash", None)
        expected["manifest_hash"] = sha256_text(canonical_json(expected))
    if actual != expected:
        violations.append("manifest_drift")
    docs = repo_root / "docs" / "generated" / "interface-reference.md"
    if not docs.exists() or docs.read_text(encoding="utf-8") != _render_docs(expected):
        violations.append("generated_docs_drift")
    compatibility_path = repo_root / "plan" / "interface-compatibility.json"
    try:
        compatibility = json.loads(compatibility_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        compatibility = {}
    if compatibility != generate_compatibility_registry(repo_root):
        violations.append("compatibility_registry_drift")
    return {
        "ok": not violations,
        "schema_version": "persistmind.interface_artifact_validation.v1",
        "violations": violations,
        "operation_count": expected["operation_count"],
    }


def generate_compatibility_registry(
    repo_root: Path, *, include_local_dist: bool = False
) -> dict[str, Any]:
    current = _project_version(repo_root)
    artifacts_by_identity: dict[tuple[str, str], dict[str, Any]] = {}

    # The tracked registry is the durable compatibility ledger. Release wheels
    # are deliberately not committed to the source repository, so a clean
    # checkout must retain already-qualified historical entries even when its
    # local ``dist`` directory is empty.
    registry_path = repo_root / "plan" / "interface-compatibility.json"
    try:
        previous = json.loads(registry_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        previous = {}
    previous_documents = [previous]
    tracked = subprocess.run(
        ["git", "-C", str(repo_root), "show", "HEAD:plan/interface-compatibility.json"],
        capture_output=True,
        text=True,
        check=False,
    )
    if tracked.returncode == 0:
        try:
            tracked_document = json.loads(tracked.stdout)
        except json.JSONDecodeError:
            tracked_document = {}
        previous_documents.append(tracked_document)
    for document in previous_documents:
        for item in document.get("retained_artifacts", []):
            if not isinstance(item, dict):
                continue
            version = str(item.get("version") or "")
            path = str(item.get("path") or "")
            digest = str(item.get("sha256") or "")
            if (
                not version
                or not path
                or not re.fullmatch(r"[0-9a-f]{64}", digest)
                or item.get("artifact_kind") == "source_candidate"
            ):
                continue
            artifacts_by_identity[(version, path)] = dict(item)

    # Tracked source artifacts must be reproducible in clean and post-build
    # checkouts. Local ``dist`` is therefore opt-in for the release-promotion
    # command and never influences ordinary generation or validation.
    if include_local_dist:
        wheel_paths = {
            *repo_root.glob("dist/*.whl"),
            *repo_root.glob("dist/persistmind/*.whl"),
            *repo_root.glob("dist/persistmind/*.whl"),
        }
        for wheel_path in sorted(wheel_paths):
            match = re.search(r"(?:persistmind|persistmind)-(?P<version>[^-]+)-", wheel_path.name)
            if not match:
                continue
            item = {
                "version": match.group("version"),
                "path": wheel_path.relative_to(repo_root).as_posix(),
                "sha256": hashlib.sha256(wheel_path.read_bytes()).hexdigest(),
                "database_upgrade_supported": True,
                "artifact_kind": "release_wheel",
            }
            artifacts_by_identity[(item["version"], item["path"])] = item

    artifacts = sorted(
        artifacts_by_identity.values(),
        key=lambda item: (_version_sort_key(str(item["version"])), str(item["path"])),
    )
    retained = {str(item["version"]) for item in artifacts}
    if current not in retained:
        source_marker = repo_root / "pyproject.toml"
        artifacts.append(
            {
                "version": current,
                "path": source_marker.relative_to(repo_root).as_posix(),
                "sha256": _normalized_text_sha256(source_marker),
                "database_upgrade_supported": True,
                "artifact_kind": "source_candidate",
            }
        )
        retained.add(current)
    historical = sorted(
        (version for version in retained if version != current),
        key=_version_sort_key,
    )
    interface_window = [*historical[-2:], current]
    return {
        "schema_version": "persistmind.interface_compatibility.v1",
        "result_schema": "persistmind.interface_result.v1",
        "current_preview": current,
        "interface_window": interface_window,
        "interface_window_present": len(interface_window) == 3
        and all(version in retained for version in interface_window),
        "retained_artifacts": artifacts,
        "deprecation_minimum_preview_cycles": 1,
        "incompatible_change_requires_negotiation": True,
    }


def _project_version(repo_root: Path) -> str:
    metadata = tomllib.loads((repo_root / "pyproject.toml").read_text(encoding="utf-8"))
    return str(metadata["project"]["version"])


def _version_sort_key(value: str) -> tuple[int, Version | str]:
    try:
        return (0, Version(value))
    except InvalidVersion:
        return (1, value)


def _operation(
    *,
    operation_id: str,
    surface: str,
    operation: str,
    mutation: str,
    auth: str,
    maturity: str,
    actions: dict[str, str | None],
) -> dict[str, Any]:
    return {
        "id": operation_id,
        "surface": surface,
        "operation": operation,
        "parameters": [],
        "defaults": {},
        "mutation_class": mutation,
        "auth_requirement": auth,
        "actions": actions,
        "input_schema": None,
        "result_schema": "persistmind.interface_result.v1",
        "failure_statuses": sorted(
            status.value for status in InterfaceStatus if status is not InterfaceStatus.OK
        ),
        "timeout_seconds": None,
        "maturity": maturity,
        "deprecated_in": None,
    }


def _render_docs(payload: dict[str, Any]) -> str:
    lines = [
        "# Generated Interface Reference",
        "",
        f"Schema: `{payload['schema_version']}`",
        f"Source commit: `{payload['generated_for_commit']}`",
        f"Generator: `{payload['generator']['name']}@{payload['generator']['version']}`",
        f"Manifest hash: `{payload['manifest_hash']}`",
        "",
        "| Surface | Operation | Mutation | Authentication | Maturity |",
        "|---|---|---|---|---|",
    ]
    for item in payload["operations"]:
        lines.append(
            f"| {item['surface']} | `{item['operation']}` | {item['mutation_class']} "
            f"| {item['auth_requirement']} | {item['maturity']} |"
        )
    return "\n".join(lines) + "\n"


def _git_is_ancestor(repo_root: Path, candidate: str) -> bool:
    try:
        result = subprocess.run(
            ["git", "merge-base", "--is-ancestor", candidate, "HEAD"],
            cwd=repo_root,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=5,
        )
    except (FileNotFoundError, subprocess.SubprocessError):
        return False
    return result.returncode == 0
