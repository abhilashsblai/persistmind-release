"""CLI surface helpers for the token-accounting operations.

Kept out of ``cli.py`` so the transport file stays inside its growth ratchet:
``cli.py`` holds only the parser registration call and the two
``service.token_usage_*`` dispatch calls the architecture contract binds to.
"""

from __future__ import annotations

import argparse
from typing import Any


def configure_token_parser(tokens: Any) -> argparse.ArgumentParser:
    """Populate the ``tokens`` subparser.

    ``cli.py`` keeps the literal ``sub.add_parser("tokens")`` call so the
    release-surface inventory still discovers the command by AST scan.
    """

    tokens.add_argument("tokens_command", choices=["report", "record"])
    tokens.add_argument("--task-session-id")
    tokens.add_argument("--activity", default="agent_turn")
    tokens.add_argument("--leg", choices=["agent", "served"], default="agent")
    tokens.add_argument("--measurement", choices=["measured", "estimated"], default="measured")
    tokens.add_argument("--source", default="reported")
    tokens.add_argument("--transcript", help="Host transcript to read measured usage from")
    tokens.add_argument("--input-tokens", type=int, default=0)
    tokens.add_argument("--cache-read-tokens", type=int, default=0)
    tokens.add_argument("--cache-write-tokens", type=int, default=0)
    tokens.add_argument("--output-tokens", type=int, default=0)
    tokens.add_argument("--limit", type=int, default=1000)
    tokens.add_argument("--summary", action="store_true", help="Print the rendered summary only")
    return tokens


def token_record_request(args: argparse.Namespace) -> dict[str, Any]:
    """Shape a ``token_usage_record`` request from parsed CLI arguments."""

    return {
        "activity": args.activity,
        "leg": args.leg,
        "tokens": {
            "input": args.input_tokens,
            "cache_read": args.cache_read_tokens,
            "cache_write": args.cache_write_tokens,
            "output": args.output_tokens,
        },
        "task_session_id": args.task_session_id,
        "measurement": args.measurement,
        "source": args.source,
        "transcript_path": args.transcript,
    }
