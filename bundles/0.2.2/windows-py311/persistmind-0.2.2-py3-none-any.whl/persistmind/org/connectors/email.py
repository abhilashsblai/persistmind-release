from __future__ import annotations

from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any

from persistmind.org.connector import ConnectorItem, load_json_items, load_text_files


class EmailExportConnector:
    kind = "email"

    def is_local_first(self) -> bool:
        return True

    def fetch(self, *, since: str | None, config: Mapping[str, Any]) -> Iterable[ConnectorItem]:
        _ = since
        path = Path(str(config.get("path") or config.get("file") or "email.json"))
        if path.suffix.lower() == ".json":
            return load_json_items(path, text_keys=("body", "text", "message"))
        return load_text_files(path, suffixes=(".eml", ".mbox", ".txt", ".md"))
