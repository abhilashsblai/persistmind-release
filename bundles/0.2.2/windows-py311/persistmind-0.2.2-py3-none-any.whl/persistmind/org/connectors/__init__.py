from __future__ import annotations

from persistmind.org.connector import Connector
from persistmind.org.connectors.crm import CrmExportConnector
from persistmind.org.connectors.email import EmailExportConnector
from persistmind.org.connectors.slack import SlackExportConnector
from persistmind.org.connectors.transcript import TranscriptConnector

CONNECTORS: dict[str, type[Connector]] = {
    "transcript": TranscriptConnector,
    "slack": SlackExportConnector,
    "email": EmailExportConnector,
    "crm": CrmExportConnector,
}

__all__ = [
    "CONNECTORS",
    "CrmExportConnector",
    "EmailExportConnector",
    "SlackExportConnector",
    "TranscriptConnector",
]
