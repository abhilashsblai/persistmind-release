from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping, Protocol


MAX_INGEST_FILES = 500
MAX_INGEST_ITEMS = 500
MAX_INGEST_BYTES = 16 * 1024 * 1024
MAX_INGEST_DEPTH = 12
MAX_INGEST_SECONDS = 10.0


@dataclass(frozen=True)
class ConnectorItem:
    source_ref: str
    raw_text: str
    authored_at: str | None = None
    author: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class Connector(Protocol):
    kind: str

    def is_local_first(self) -> bool: ...

    def fetch(self, *, since: str | None, config: Mapping[str, Any]) -> Iterable[ConnectorItem]: ...


def load_json_items(path: Path, *, text_keys: tuple[str, ...]) -> list[ConnectorItem]:
    _require_file_budget(path)
    data = json.loads(path.read_text(encoding="utf-8"))
    if _json_depth(data) > MAX_INGEST_DEPTH:
        raise ValueError("organization ingestion nesting budget exceeded")
    rows = data if isinstance(data, list) else data.get("items") or data.get("messages") or []
    items: list[ConnectorItem] = []
    if len(rows) > MAX_INGEST_ITEMS:
        raise ValueError("organization ingestion item budget exceeded")
    for idx, row in enumerate(rows):
        if not isinstance(row, dict):
            continue
        raw = ""
        for key in text_keys:
            if row.get(key):
                raw = str(row[key])
                break
        if not raw:
            continue
        items.append(
            ConnectorItem(
                source_ref=str(
                    row.get("source_ref")
                    or row.get("permalink")
                    or row.get("id")
                    or f"{path}:{idx}"
                ),
                raw_text=raw,
                authored_at=row.get("authored_at") or row.get("ts") or row.get("created_at"),
                author=row.get("author") or row.get("user") or row.get("from"),
                metadata={key: value for key, value in row.items() if key not in set(text_keys)},
            )
        )
    return items


def load_text_files(folder: Path, *, suffixes: tuple[str, ...]) -> list[ConnectorItem]:
    paths = [folder] if folder.is_file() else folder.rglob("*")
    items: list[ConnectorItem] = []
    started = time.monotonic()
    total_bytes = 0
    file_count = 0
    for path in paths:
        if time.monotonic() - started > MAX_INGEST_SECONDS:
            raise TimeoutError("organization ingestion time budget exceeded")
        depth = len(path.relative_to(folder if folder.is_dir() else folder.parent).parts)
        if depth > MAX_INGEST_DEPTH:
            raise ValueError("organization ingestion depth budget exceeded")
        if not path.is_file() or path.suffix.lower() not in suffixes:
            continue
        file_count += 1
        if file_count > MAX_INGEST_FILES:
            raise ValueError("organization ingestion file budget exceeded")
        total_bytes += path.stat().st_size
        if total_bytes > MAX_INGEST_BYTES:
            raise ValueError("organization ingestion byte budget exceeded")
        text = path.read_text(encoding="utf-8", errors="replace")
        if not text.strip():
            continue
        items.append(
            ConnectorItem(
                source_ref=path.as_posix(),
                raw_text=text,
                authored_at=None,
                author=None,
                metadata={"path": path.as_posix()},
            )
        )
        if len(items) > MAX_INGEST_ITEMS:
            raise ValueError("organization ingestion item budget exceeded")
    return items


def _require_file_budget(path: Path) -> None:
    if not path.is_file():
        raise ValueError("organization ingestion input must be a file")
    if path.stat().st_size > MAX_INGEST_BYTES:
        raise ValueError("organization ingestion byte budget exceeded")


def _json_depth(value: Any, depth: int = 0) -> int:
    if depth > MAX_INGEST_DEPTH:
        return depth
    if isinstance(value, dict):
        return max([depth, *(_json_depth(item, depth + 1) for item in value.values())])
    if isinstance(value, list):
        return max([depth, *(_json_depth(item, depth + 1) for item in value)])
    return depth
