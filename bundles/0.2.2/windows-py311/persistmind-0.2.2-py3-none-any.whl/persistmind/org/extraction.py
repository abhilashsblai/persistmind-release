from __future__ import annotations

from dataclasses import dataclass

from persistmind.org.connector import ConnectorItem


@dataclass(frozen=True)
class ExtractionResult:
    extracted_type: str
    confidence: float
    subject_key: str


def classify(item: ConnectorItem) -> ExtractionResult:
    text = " ".join(item.raw_text.lower().split())
    if any(
        token in text for token in ("objected", "objection", "concern", "concerned", "pushback")
    ):
        extracted_type = "objection"
        confidence = 0.55
    elif any(
        token in text for token in ("must not", "must", "required", "cannot", "blocker", "policy")
    ):
        extracted_type = "constraint"
        confidence = 0.55
    elif any(token in text for token in ("decided", "decision", "we will", "approved", "agreed")):
        extracted_type = "decision"
        confidence = 0.6
    elif any(token in text for token in ("because", "rationale", "reason", "so that")):
        extracted_type = "rationale"
        confidence = 0.5
    else:
        extracted_type = "rationale"
        confidence = 0.3
    words = [word.strip(".,:;()[]{}").lower() for word in text.split()]
    subject = " ".join(sorted({word for word in words if len(word) > 4})[:8])
    return ExtractionResult(
        extracted_type=extracted_type, confidence=confidence, subject_key=subject
    )
