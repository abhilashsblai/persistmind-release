from __future__ import annotations

from datetime import datetime, timedelta, timezone

from persistmind.utils import utc_now


def compute_decay_at(captured_at: str | None, *, days: int = 45) -> str:
    base = _parse_time(captured_at) or datetime.now(timezone.utc)
    return (base + timedelta(days=days)).isoformat(timespec="seconds")


def staleness_state(decay_at: str | None) -> str:
    if not decay_at:
        return "fresh"
    decay = _parse_time(decay_at)
    if not decay:
        return "fresh"
    now = datetime.fromisoformat(utc_now().replace("Z", "+00:00"))
    remaining = (decay - now).total_seconds()
    if remaining <= 0:
        return "expired"
    if remaining < 7 * 24 * 3600:
        return "stale"
    if remaining < 21 * 24 * 3600:
        return "aging"
    return "fresh"


def _parse_time(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed
