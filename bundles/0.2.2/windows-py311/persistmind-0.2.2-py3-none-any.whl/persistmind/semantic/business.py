from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from persistmind.semantic.schema import BUSINESS_METADATA_SCHEMAS, BUSINESS_NODE_TYPES
from persistmind.utils import utc_now


@dataclass(frozen=True)
class BusinessNodeCandidate:
    node_type: str
    name: str
    attrs: dict[str, Any] = field(default_factory=dict)
    source_type: str = "connector"
    source_ref: str = ""
    confidence: float = 0.7
    proposed_by: str = "connector"


class BusinessGraph:
    def __init__(self, repo_root: Path, store: Any):
        self.repo_root = repo_root
        self.store = store

    def add_entity(
        self,
        *,
        repo_id: str,
        node_type: str,
        name: str,
        attrs: dict[str, Any] | None = None,
        origin: str = "manual",
        source_type: str | None = None,
        source_ref: str | None = None,
        proposed_by: str = "user",
        confidence: float = 0.9,
    ) -> dict[str, Any]:
        clean_type = node_type.strip().lower()
        if clean_type not in BUSINESS_NODE_TYPES:
            raise ValueError(f"unsupported business node type: {node_type}")
        clean_attrs = _validated_attrs(clean_type, attrs or {})
        origin = origin.strip().lower() or "manual"
        trust_tier = "high" if origin == "manual" else "low"
        provenance = {
            "origin": origin,
            "source_type": source_type or ("manual_entry" if origin == "manual" else "connector"),
            "source_ref": source_ref or "manual",
            "proposed_by": proposed_by,
            "captured_at": utc_now(),
            "ingested_at": utc_now(),
        }
        row = self.store.upsert_business_node(
            repo_id=repo_id,
            node_type=clean_type,
            name=name,
            metadata=clean_attrs,
            provenance=provenance,
            confidence=confidence,
            trust_tier=trust_tier,
            status="candidate",
        )
        self.store.append_audit(
            pack_id=f"business-node:{row['node_id']}",
            payload={
                "event": "business_node_candidate_created",
                "repo_id": repo_id,
                "node_id": row["node_id"],
                "node_type": clean_type,
                "origin": origin,
                "trust_tier": trust_tier,
                "status": "candidate",
            },
        )
        return {"ok": True, "entity": _node_dict(row)}

    def add_connector_candidate(
        self, *, repo_id: str, candidate: BusinessNodeCandidate
    ) -> dict[str, Any]:
        return self.add_entity(
            repo_id=repo_id,
            node_type=candidate.node_type,
            name=candidate.name,
            attrs=candidate.attrs,
            origin="connector",
            source_type=candidate.source_type,
            source_ref=candidate.source_ref,
            proposed_by=candidate.proposed_by,
            confidence=candidate.confidence,
        )

    def bulk_add_file(
        self,
        *,
        repo_id: str,
        file: str | Path,
        origin: str = "manual",
        proposed_by: str = "user",
    ) -> dict[str, Any]:
        path = Path(file)
        if not path.is_absolute():
            path = self.repo_root / path
        data = json.loads(path.read_text(encoding="utf-8"))
        items = data if isinstance(data, list) else data.get("entities", [])
        created = []
        for item in items:
            created.append(
                self.add_entity(
                    repo_id=repo_id,
                    node_type=str(item["type"]),
                    name=str(item["name"]),
                    attrs=dict(item.get("attrs") or item.get("metadata") or {}),
                    origin=origin,
                    source_type=str(item.get("source_type") or origin),
                    source_ref=str(item.get("source_ref") or path),
                    proposed_by=proposed_by,
                    confidence=float(item.get("confidence", 0.9)),
                )["entity"]
            )
        return {"ok": True, "entities": created, "count": len(created)}

    def approve(self, node_id: str, *, approver: str, notes: str = "") -> dict[str, Any]:
        return {
            "ok": True,
            "entity": _node_dict(
                self.store.approve_business_node(
                    node_id, decision="approve", approver=approver, notes=notes
                )
            ),
        }

    def reject(self, node_id: str, *, approver: str, reason: str = "") -> dict[str, Any]:
        return {
            "ok": True,
            "entity": _node_dict(
                self.store.approve_business_node(
                    node_id, decision="reject", approver=approver, notes=reason
                )
            ),
        }

    def list(
        self,
        *,
        repo_id: str,
        status: str | None = None,
        node_type: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        rows = self.store.business_nodes(repo_id, status=status, node_type=node_type, limit=limit)
        return {
            "ok": True,
            "entities": [_node_dict(row) for row in rows],
            "count": len(rows),
        }

    def link(
        self,
        *,
        repo_id: str,
        src_node_id: str,
        dst_node_id: str,
        kind: str,
        source_ref: str = "manual",
        source_type: str = "manual_entry",
        proposed_by: str = "user",
        confidence: float | None = None,
    ) -> dict[str, Any]:
        provenance = {
            "origin": "manual" if source_type == "manual_entry" else "connector",
            "source_type": source_type,
            "source_ref": source_ref,
            "proposed_by": proposed_by,
            "captured_at": utc_now(),
            "ingested_at": utc_now(),
        }
        row = self.store.link_business_edge(
            repo_id=repo_id,
            src_node_id=src_node_id,
            dst_node_id=dst_node_id,
            kind=kind,
            provenance=provenance,
            confidence=confidence,
        )
        self.store.append_audit(
            pack_id=f"business-edge:{row['edge_id']}",
            payload={
                "event": "business_edge_linked",
                "repo_id": repo_id,
                "edge_id": row["edge_id"],
                "src_node_id": src_node_id,
                "dst_node_id": dst_node_id,
                "kind": kind,
            },
        )
        return {"ok": True, "edge": _edge_dict(row)}


def _validated_attrs(node_type: str, attrs: dict[str, Any]) -> dict[str, Any]:
    allowed = BUSINESS_METADATA_SCHEMAS.get(node_type, frozenset())
    clean = {str(key): value for key, value in attrs.items() if str(key) in allowed}
    extras = sorted(str(key) for key in attrs if str(key) not in allowed)
    if extras:
        clean["_ignored_attrs"] = extras
    return clean


def _node_dict(row: Any) -> dict[str, Any]:
    return {
        "node_id": row["node_id"],
        "repo_id": row["repo_id"],
        "node_type": row["node_type"],
        "name": row["name"],
        "stable_key": row["stable_key"],
        "confidence": float(row["confidence"] or 0.0),
        "source": row["source"],
        "metadata": json.loads(row["metadata_json"] or "{}"),
        "trust_tier": row["trust_tier"],
        "status": row["status"],
        "provenance": json.loads(row["provenance_json"] or "{}"),
    }


def _edge_dict(row: Any) -> dict[str, Any]:
    metadata = json.loads(row["metadata_json"] or "{}")
    return {
        "edge_id": row["edge_id"],
        "src_node_id": row["src_node_id"],
        "dst_node_id": row["dst_node_id"],
        "kind": row["kind"],
        "confidence": float(row["confidence"] or 0.0),
        "evidence": json.loads(row["evidence_json"] or "[]"),
        "metadata": metadata,
        "trust_tier": metadata.get("trust_tier"),
        "status": metadata.get("status", "active"),
        "src_type": row["src_type"],
        "src_name": row["src_name"],
        "dst_type": row["dst_type"],
        "dst_name": row["dst_name"],
        "provenance": (
            metadata.get("provenance") if isinstance(metadata.get("provenance"), dict) else {}
        ),
    }
