from __future__ import annotations

import ctypes
import hashlib
import json
import os
import subprocess
import unicodedata
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any


SCHEMA_VERSION = "persistmind.repo_identity.v1"


class RepoIdentityError(RuntimeError):
    """Raised when a stable repository identity cannot be established."""


@dataclass(frozen=True)
class RepoIdentity:
    document: dict[str, Any]
    canonical_json: bytes
    sha256: str


def canonical_repo_identity(repo: Path) -> RepoIdentity:
    """Return the closed, filesystem-backed identity for a Git worktree."""

    requested = Path(repo)
    if not requested.exists():
        raise RepoIdentityError(f"repository path does not exist: {requested}")
    try:
        cache_key = str(requested.resolve(strict=True))
    except OSError as exc:
        raise RepoIdentityError(f"repository path does not exist: {requested}") from exc
    return _canonical_repo_identity_cached(cache_key)


@lru_cache(maxsize=256)
def _canonical_repo_identity_cached(cache_key: str) -> RepoIdentity:
    requested = Path(cache_key)
    root = _git_path(requested, "--show-toplevel")
    common = _git_path(root, "--git-common-dir")
    git_dir = _git_path(root, "--git-dir")
    document: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "platform": "windows" if os.name == "nt" else "posix",
        "worktree": _path_identity(root),
        "git_common_dir": _path_identity(common),
        "git_worktree_dir": _path_identity(git_dir),
    }
    payload = json.dumps(
        document,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    digest = hashlib.sha256(SCHEMA_VERSION.encode("ascii") + b"\0" + payload).hexdigest()
    return RepoIdentity(document=document, canonical_json=payload, sha256=digest)


def canonical_repo_hash(repo: Path) -> str:
    return canonical_repo_identity(repo).sha256


def canonical_path_identity(path: Path) -> dict[str, Any]:
    """Expose the same canonical filesystem identity used by repo identity."""

    return _path_identity(Path(path))


def _git_path(repo: Path, flag: str) -> Path:
    try:
        result = subprocess.run(
            ["git", "-C", str(repo), "rev-parse", "--path-format=absolute", flag],
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="strict",
            timeout=10,
        )
    except (OSError, subprocess.SubprocessError, UnicodeError) as exc:
        raise RepoIdentityError(f"cannot resolve Git repository identity: {exc}") from exc
    if result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip() or flag
        raise RepoIdentityError(f"cannot resolve Git repository identity: {detail}")
    value = result.stdout.strip()
    if not value or "\x00" in value:
        raise RepoIdentityError(f"Git returned an invalid path for {flag}")
    path = Path(value)
    if not path.is_absolute():
        path = repo / path
    try:
        return path.resolve(strict=True)
    except OSError as exc:
        raise RepoIdentityError(f"Git identity path is unavailable: {path}") from exc


def _path_identity(path: Path) -> dict[str, Any]:
    if os.name == "nt":
        return _windows_path_identity(path)
    try:
        resolved = path.resolve(strict=True)
        stat = resolved.stat()
    except OSError as exc:
        raise RepoIdentityError(f"cannot stat identity path: {path}") from exc
    return {
        "canonical_path": unicodedata.normalize("NFC", os.fsdecode(os.fsencode(resolved))),
        "case_sensitive": True,
        "device": int(stat.st_dev),
        "inode": int(stat.st_ino),
    }


if os.name == "nt":
    from ctypes import wintypes

    _FILE_FLAG_BACKUP_SEMANTICS = 0x02000000
    _FILE_SHARE_ALL = 0x00000001 | 0x00000002 | 0x00000004
    _OPEN_EXISTING = 3
    _FILE_READ_ATTRIBUTES = 0x0080
    _INVALID_HANDLE_VALUE = wintypes.HANDLE(-1).value
    _FILE_CASE_SENSITIVE_INFO_CLASS = 23
    _FILE_CS_FLAG_CASE_SENSITIVE_DIR = 0x00000001

    class _BY_HANDLE_FILE_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("dwFileAttributes", wintypes.DWORD),
            ("ftCreationTime", wintypes.FILETIME),
            ("ftLastAccessTime", wintypes.FILETIME),
            ("ftLastWriteTime", wintypes.FILETIME),
            ("dwVolumeSerialNumber", wintypes.DWORD),
            ("nFileSizeHigh", wintypes.DWORD),
            ("nFileSizeLow", wintypes.DWORD),
            ("nNumberOfLinks", wintypes.DWORD),
            ("nFileIndexHigh", wintypes.DWORD),
            ("nFileIndexLow", wintypes.DWORD),
        ]

    class _FILE_CASE_SENSITIVE_INFO(ctypes.Structure):
        _fields_ = [("Flags", wintypes.ULONG)]


def _windows_path_identity(path: Path) -> dict[str, Any]:
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    create_file = kernel32.CreateFileW
    create_file.argtypes = [
        wintypes.LPCWSTR,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.LPVOID,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.HANDLE,
    ]
    create_file.restype = wintypes.HANDLE
    handle = create_file(
        str(path),
        _FILE_READ_ATTRIBUTES,
        _FILE_SHARE_ALL,
        None,
        _OPEN_EXISTING,
        _FILE_FLAG_BACKUP_SEMANTICS,
        None,
    )
    if handle == _INVALID_HANDLE_VALUE:
        raise RepoIdentityError(f"cannot open identity path: {path} ({ctypes.get_last_error()})")
    try:
        info = _BY_HANDLE_FILE_INFORMATION()
        if not kernel32.GetFileInformationByHandle(handle, ctypes.byref(info)):
            raise RepoIdentityError(
                f"cannot read filesystem identity: {path} ({ctypes.get_last_error()})"
            )
        required = kernel32.GetFinalPathNameByHandleW(handle, None, 0, 0)
        if not required:
            raise RepoIdentityError(
                f"cannot resolve final path: {path} ({ctypes.get_last_error()})"
            )
        buffer = ctypes.create_unicode_buffer(required + 1)
        if not kernel32.GetFinalPathNameByHandleW(handle, buffer, len(buffer), 0):
            raise RepoIdentityError(
                f"cannot resolve final path: {path} ({ctypes.get_last_error()})"
            )
        case_info = _FILE_CASE_SENSITIVE_INFO()
        case_sensitive = False
        get_extended = getattr(kernel32, "GetFileInformationByHandleEx", None)
        if get_extended is not None:
            case_sensitive = bool(
                get_extended(
                    handle,
                    _FILE_CASE_SENSITIVE_INFO_CLASS,
                    ctypes.byref(case_info),
                    ctypes.sizeof(case_info),
                )
                and case_info.Flags & _FILE_CS_FLAG_CASE_SENSITIVE_DIR
            )
        canonical = _normalize_windows_final_path(buffer.value, case_sensitive=case_sensitive)
        file_id = (int(info.nFileIndexHigh) << 32) | int(info.nFileIndexLow)
        return {
            "canonical_path": canonical,
            "case_sensitive": case_sensitive,
            "volume_serial": f"{int(info.dwVolumeSerialNumber):08x}",
            "file_id": f"{file_id:016x}",
        }
    finally:
        kernel32.CloseHandle(handle)


def _normalize_windows_final_path(value: str, *, case_sensitive: bool) -> str:
    normalized = value
    if normalized.startswith("\\\\?\\UNC\\"):
        normalized = "\\\\" + normalized[8:]
    elif normalized.startswith("\\\\?\\"):
        normalized = normalized[4:]
    normalized = unicodedata.normalize("NFC", normalized.replace("/", "\\"))
    return normalized if case_sensitive else normalized.casefold()


__all__ = [
    "RepoIdentity",
    "RepoIdentityError",
    "SCHEMA_VERSION",
    "canonical_path_identity",
    "canonical_repo_hash",
    "canonical_repo_identity",
]
