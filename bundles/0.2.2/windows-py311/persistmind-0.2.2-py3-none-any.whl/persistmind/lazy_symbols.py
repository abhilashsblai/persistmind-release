from __future__ import annotations

from importlib import import_module
from pathlib import Path
from typing import Any


SERVICE_SYMBOL_NAMES = """BudgetedProvider BusinessGraph BusinessNodeCandidate EnrichmentBudget
ImpactEngine IntentEngine LoopVerifier MemoryReflector MetacognitiveController ReflectiveOptimizer
SelfModEngine SemanticGraphIndexer SemanticRepairQueue SkillEvolutionEngine SkillLibrary SnapshotInfo
SnapshotResolver TokenBudgetedProvider VerificationRunner apply_parameters archive_rows
build_agent_provider current_parameters default_evaluator init_git_repo is_git_repo is_real_provider
parse_run_json provider_readiness provider_status setup_readiness""".split()


def bind_service_symbols(namespace: dict[str, Any]) -> None:
    namespace.update({name: globals()[name] for name in SERVICE_SYMBOL_NAMES})


def _symbol(module: str, symbol_name: str) -> Any:
    return getattr(import_module(module), symbol_name)


def _construct(module: str, symbol_name: str, *args: Any, **kwargs: Any) -> Any:
    return _symbol(module, symbol_name)(*args, **kwargs)


def ReflectiveOptimizer(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.learning.optimizer", "ReflectiveOptimizer", *args, **kwargs)


def apply_parameters(*args: Any, **kwargs: Any) -> Any:
    return _symbol("persistmind.learning.optimizer", "apply_parameters")(*args, **kwargs)


def archive_rows(*args: Any, **kwargs: Any) -> Any:
    return _symbol("persistmind.learning.optimizer", "archive_rows")(*args, **kwargs)


def current_parameters(*args: Any, **kwargs: Any) -> Any:
    return _symbol("persistmind.learning.optimizer", "current_parameters")(*args, **kwargs)


def default_evaluator(*args: Any, **kwargs: Any) -> Any:
    return _symbol("persistmind.learning.optimizer", "default_evaluator")(*args, **kwargs)


def parse_run_json(*args: Any, **kwargs: Any) -> Any:
    return _symbol("persistmind.learning.optimizer", "parse_run_json")(*args, **kwargs)


def BudgetedProvider(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.learning.provider", "BudgetedProvider", *args, **kwargs)


def EnrichmentBudget(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.learning.provider", "EnrichmentBudget", *args, **kwargs)


def TokenBudgetedProvider(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.learning.provider", "TokenBudgetedProvider", *args, **kwargs)


def build_agent_provider(*args: Any, **kwargs: Any) -> Any:
    return _symbol("persistmind.learning.provider", "build_agent_provider")(*args, **kwargs)


def is_real_provider(*args: Any, **kwargs: Any) -> Any:
    return _symbol("persistmind.learning.provider", "is_real_provider")(*args, **kwargs)


def provider_readiness(*args: Any, **kwargs: Any) -> Any:
    return _symbol("persistmind.learning.provider", "provider_readiness")(*args, **kwargs)


def provider_status(*args: Any, **kwargs: Any) -> Any:
    return _symbol("persistmind.learning.provider", "provider_status")(*args, **kwargs)


def LoopVerifier(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.learning.loop_verify", "LoopVerifier", *args, **kwargs)


def MemoryReflector(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.learning.reflection", "MemoryReflector", *args, **kwargs)


def SelfModEngine(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.learning.selfmod", "SelfModEngine", *args, **kwargs)


def SkillEvolutionEngine(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct(
        "persistmind.learning.skill_evolution", "SkillEvolutionEngine", *args, **kwargs
    )


def SkillLibrary(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.learning.skills", "SkillLibrary", *args, **kwargs)


def MetacognitiveController(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.metacognition", "MetacognitiveController", *args, **kwargs)


def BusinessGraph(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.semantic", "BusinessGraph", *args, **kwargs)


def BusinessNodeCandidate(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.semantic", "BusinessNodeCandidate", *args, **kwargs)


def SemanticGraphIndexer(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.semantic", "SemanticGraphIndexer", *args, **kwargs)


def SemanticRepairQueue(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.semantic.repair", "SemanticRepairQueue", *args, **kwargs)


def SnapshotInfo(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.snapshot", "SnapshotInfo", *args, **kwargs)


def SnapshotResolver(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.snapshot", "SnapshotResolver", *args, **kwargs)


def VerificationRunner(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.verification", "VerificationRunner", *args, **kwargs)


def ImpactEngine(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.impact", "ImpactEngine", *args, **kwargs)


def IntentEngine(*args: Any, **kwargs: Any) -> Any:  # noqa: N802
    return _construct("persistmind.intent", "IntentEngine", *args, **kwargs)


def init_git_repo(repo_root: Path) -> dict[str, Any]:
    return _symbol("persistmind.setup", "init_git_repo")(repo_root)


def is_git_repo(repo_root: Path) -> bool:
    return bool(_symbol("persistmind.setup", "is_git_repo")(repo_root))


def setup_readiness(
    repo_root: Path,
    agent_names: list[str] | None = None,
    *,
    probe_mcp: bool = True,
    live_probes: bool = True,
) -> dict[str, Any]:
    return _symbol("persistmind.setup", "setup_readiness")(
        repo_root,
        agent_names,
        probe_mcp=probe_mcp,
        live_probes=live_probes,
    )
