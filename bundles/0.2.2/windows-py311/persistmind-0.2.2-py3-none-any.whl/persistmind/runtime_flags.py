from __future__ import annotations

import os


def learning_off() -> bool:
    """Return the canonical CIE kill switch, retaining the legacy spelling."""

    value = os.environ.get("PERSISTMIND_LEARNING_OFF")
    if value is None:
        value = os.environ.get("PERSISTMIND_LEARNING_OFF", "")
    return value.strip().casefold() in {"1", "true", "yes", "on"}
