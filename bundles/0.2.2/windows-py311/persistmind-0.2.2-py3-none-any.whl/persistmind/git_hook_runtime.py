from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time
import uuid
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, cast

from persistmind.branding import resolve_project_state
from persistmind.repo_identity import canonical_repo_identity
from persistmind.runtime_invocation import load_project_runtime_invocation

LOG_SCHEMA = "persistmind.git_hook_event.v1"
MAX_ACTIVE_BYTES = 1024 * 1024
MAX_ROTATED_FILES = 5
MAX_ROTATED_AGE = timedelta(days=30)
_SECRET_RE = re.compile(
    r"(?i)\b(authorization|password|passwd|secret|token|api[_-]?key)\b"
    r"(\s*[:=]\s*)([^\s,;]+)"
)


def run_post_commit(repo: Path, *, timeout_seconds: float = 300.0) -> dict[str, Any]:
    root = repo.expanduser().resolve()
    started = time.monotonic()
    status = "error"
    exit_code: int | None = None
    error_code: str | None = None
    message = "PersistMind post-commit indexing failed"
    stderr_digest = hashlib.sha256(b"").hexdigest()
    stderr_preview = ""
    invocation_hash: str | None = None
    try:
        invocation = load_project_runtime_invocation(root)
        if invocation is None:
            raise RuntimeError("runtime_invocation_missing")
        invocation_hash = invocation.invocation_sha256
        with tempfile.TemporaryFile() as stderr_file:
            try:
                completed = subprocess.run(
                    invocation.argv("--repo", str(root), "index"),
                    cwd=root,
                    env={
                        **os.environ,
                        "PYTHONIOENCODING": "utf-8",
                        "PYTHONUTF8": "1",
                    },
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=stderr_file,
                    timeout=timeout_seconds,
                    check=False,
                )
                exit_code = int(completed.returncode)
                status = "success" if exit_code == 0 else "error"
                error_code = None if exit_code == 0 else "indexing_failed"
                message = (
                    "PersistMind post-commit indexing completed"
                    if exit_code == 0
                    else "PersistMind post-commit indexing failed"
                )
            except subprocess.TimeoutExpired:
                status = "timeout"
                error_code = "indexing_timeout"
                message = "PersistMind post-commit indexing timed out"
            stderr_digest, stderr_preview = _stderr_evidence(stderr_file, root)
    except Exception as exc:  # noqa: BLE001 - the Git hook must remain non-blocking
        error_code = _safe_error_code(exc)
        message = "PersistMind post-commit runtime was unavailable"

    record: dict[str, Any] = {
        "schema_version": LOG_SCHEMA,
        "event_id": str(uuid.uuid4()),
        "occurred_at": datetime.now(UTC).isoformat(),
        "hook": "post_commit",
        "repo_hash": canonical_repo_identity(root).sha256,
        "status": status,
        "duration_ms": max(0, int((time.monotonic() - started) * 1000)),
        "message": _bounded(_redact(message, root), 512),
        "stderr_sha256": stderr_digest,
        "stderr_preview": _bounded(stderr_preview, 1024),
        "remediation_code": "persistmind_doctor_hooks",
    }
    if exit_code is not None:
        record["exit_code"] = exit_code
    if error_code:
        record["error_code"] = error_code
    if invocation_hash:
        record["runtime_invocation_hash"] = invocation_hash
    install_id = _installation_id(root)
    if install_id:
        record["installation_transaction_id"] = install_id
    _append_record(root, record)
    return record


def _stderr_evidence(handle: Any, repo: Path) -> tuple[str, str]:
    handle.flush()
    handle.seek(0)
    digest = hashlib.sha256()
    preview = bytearray()
    while True:
        block = handle.read(64 * 1024)
        if not block:
            break
        digest.update(block)
        if len(preview) < 4096:
            preview.extend(block[: 4096 - len(preview)])
    text = bytes(preview).decode("utf-8", errors="replace")
    return digest.hexdigest(), _bounded(_redact(text, repo), 1024)


def _installation_id(repo: Path) -> str | None:
    path = resolve_project_state(repo) / "installation.json"
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    candidate = value.get("install_id") if isinstance(value, dict) else None
    return str(candidate) if candidate else None


def _safe_error_code(exc: Exception) -> str:
    text = str(exc)
    if text in {"runtime_invocation_missing", "runtime_invocation_record_invalid"}:
        return text
    return f"hook_runtime_error_{type(exc).__name__.casefold()}"


def _redact(value: str, repo: Path) -> str:
    text = value.replace(str(repo), "<repo>").replace(str(Path.home()), "<home>")
    return _SECRET_RE.sub(lambda match: match.group(1) + match.group(2) + "<redacted>", text)


def _bounded(value: str, byte_limit: int) -> str:
    encoded = value.encode("utf-8", errors="replace")
    if len(encoded) <= byte_limit:
        return value
    return encoded[:byte_limit].decode("utf-8", errors="ignore")


def _append_record(repo: Path, record: dict[str, Any]) -> None:
    log_root = resolve_project_state(repo) / "logs"
    log_root.mkdir(parents=True, exist_ok=True)
    active = log_root / "git-hooks.jsonl"
    lock_path = log_root / "git-hooks.lock"
    with _exclusive_lock(lock_path):
        _rotate(active)
        encoded = (
            json.dumps(record, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n"
        ).encode("utf-8")
        with active.open("ab") as handle:
            handle.write(encoded)
            handle.flush()
            os.fsync(handle.fileno())


def _rotate(active: Path) -> None:
    now = datetime.now(UTC)
    if active.is_file() and active.stat().st_size >= MAX_ACTIVE_BYTES:
        stamp = now.strftime("%Y%m%dT%H%M%S%fZ")
        os.replace(active, active.with_name(f"git-hooks.{stamp}.{uuid.uuid4().hex}.jsonl"))
    rotated = sorted(
        active.parent.glob("git-hooks.*.*.jsonl"),
        key=lambda item: item.stat().st_mtime_ns,
        reverse=True,
    )
    for index, path in enumerate(rotated):
        modified = datetime.fromtimestamp(path.stat().st_mtime, UTC)
        if index >= MAX_ROTATED_FILES or now - modified > MAX_ROTATED_AGE:
            path.unlink(missing_ok=True)


@contextmanager
def _exclusive_lock(path: Path) -> Iterator[None]:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a+b") as handle:
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(b"\0")
            handle.flush()
        handle.seek(0)
        if os.name == "nt":
            import msvcrt

            msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl

            fcntl_module = cast(Any, fcntl)
            fcntl_module.flock(handle.fileno(), fcntl_module.LOCK_EX)
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl_module = cast(Any, fcntl)
                fcntl_module.flock(handle.fileno(), fcntl_module.LOCK_UN)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--repo", required=True)
    parser.add_argument("--hook", choices=("post_commit",), required=True)
    parser.add_argument("--timeout-seconds", type=float, default=300.0)
    args = parser.parse_args(argv)
    try:
        record = run_post_commit(Path(args.repo), timeout_seconds=max(1.0, args.timeout_seconds))
        if record["status"] != "success":
            print(
                "PersistMind post-commit indexing did not complete; run persistmind doctor hooks",
                file=sys.stderr,
            )
    except Exception:  # noqa: BLE001 - observability loss must not block Git
        print(
            "PersistMind post-commit logging failed; run persistmind doctor hooks",
            file=sys.stderr,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = ["LOG_SCHEMA", "main", "run_post_commit"]
