from __future__ import annotations

import ast
import hashlib
import re
from pathlib import Path
from typing import Any

from persistmind.parsing.extractors import language_for, parse_file


NEXTGEN_CAPABILITIES: dict[str, list[str]] = {
    "P1": [
        "jit_retrieval",
        "stale_state_guard",
        "regrounding_capsule",
        "context_compaction",
        "progressive_skills",
        "budget_accounting",
    ],
    "P2": [
        "inline_verification_gates",
        "error_quarantine",
        "replan_on_surprise",
        "checkpoint_restore",
        "autonomy_budget",
    ],
    "P3": [
        "failure_memory_capture",
        "negative_constraints_served",
        "verified_rerank",
        "episodic_semantic_consolidation",
        "skill_curation_status",
    ],
    "P4": [
        "pack_signature_grounding",
        "signature_grounding",
        "dependency_grounding",
        "dependency_supervision_gate",
        "file_provenance",
    ],
    "P5": [
        "phase_b_surface",
        "oracle_protection",
        "reward_hack_detection",
        "world_model_prediction",
    ],
    "P6": [
        "ownership_reasoning",
        "boundary_reasoning",
        "dependency_direction",
        "minimal_change_set",
        "semantic_retrieval_honesty",
    ],
    "P7": ["rationale_memory", "spec_code_link", "spec_code_drift_detection"],
    "P8": [
        "untrusted_content_scan",
        "defend_all_served",
        "blast_radius_policy",
        "served_context_provenance",
    ],
    "P9": ["semantic_conflict_detection", "merge_gate", "snapshot_staleness"],
    "P10": [
        "scorecard_metrics",
        "ab_delta_metrics",
        "trajectory_reliability",
        "cost_accounting",
    ],
    "META": ["provider_honesty", "provider_reflection", "deterministic_fallback"],
}

NEXTGEN_PILLARS: list[dict[str, Any]] = [
    {
        "id": "P1",
        "name": "In-session context runtime",
        "limitation": "context_rot",
        "surfaces": ["nextgen_retrieve", "nextgen_expand", "nextgen_neighbors"],
        "capabilities": NEXTGEN_CAPABILITIES["P1"],
    },
    {
        "id": "P2",
        "name": "Long-horizon execution supervision",
        "limitation": "error_compounding",
        "surfaces": ["nextgen_supervise"],
        "capabilities": NEXTGEN_CAPABILITIES["P2"],
    },
    {
        "id": "P3",
        "name": "Closed learning loop",
        "limitation": "stateless_repeated_mistakes",
        "surfaces": ["nextgen_learn_failure", "memory_propose"],
        "capabilities": NEXTGEN_CAPABILITIES["P3"],
    },
    {
        "id": "P4",
        "name": "Grounding and anti-hallucination",
        "limitation": "package_api_hallucination",
        "surfaces": ["nextgen_ground", "nextgen_expand"],
        "capabilities": NEXTGEN_CAPABILITIES["P4"],
    },
    {
        "id": "P5",
        "name": "Trustworthy verification and local world model",
        "limitation": "verification_gap",
        "surfaces": ["nextgen_supervise", "verify"],
        "capabilities": NEXTGEN_CAPABILITIES["P5"],
    },
    {
        "id": "P6",
        "name": "Structural systems reasoning",
        "limitation": "large_codebase_comprehension",
        "surfaces": ["nextgen_neighbors", "semantic_graph"],
        "capabilities": NEXTGEN_CAPABILITIES["P6"],
    },
    {
        "id": "P7",
        "name": "Decision and rationale memory",
        "limitation": "organizational_why_gap",
        "surfaces": ["nextgen_rationale", "decision"],
        "capabilities": NEXTGEN_CAPABILITIES["P7"],
    },
    {
        "id": "P8",
        "name": "Agent security and governance runtime",
        "limitation": "untrusted_content_and_scope",
        "surfaces": ["nextgen_security_scan", "codex_hook_event"],
        "capabilities": NEXTGEN_CAPABILITIES["P8"],
    },
    {
        "id": "P9",
        "name": "Multi-agent coordination fabric",
        "limitation": "semantic_conflicts",
        "surfaces": ["nextgen_coordinate", "session_conflicts"],
        "capabilities": NEXTGEN_CAPABILITIES["P9"],
    },
    {
        "id": "P10",
        "name": "Efficacy, reliability, and economics",
        "limitation": "unproven_roi",
        "surfaces": ["nextgen_scorecard", "eval"],
        "capabilities": NEXTGEN_CAPABILITIES["P10"],
    },
    {
        "id": "META",
        "name": "First-class reasoning provider",
        "limitation": "inert_intelligence",
        "surfaces": ["nextgen_status", "provider_status"],
        "capabilities": NEXTGEN_CAPABILITIES["META"],
    },
]

NEXTGEN_PILLAR_IDS = tuple(item["id"] for item in NEXTGEN_PILLARS)
_EXPECTED_PILLARS = {
    "P1",
    "P2",
    "P3",
    "P4",
    "P5",
    "P6",
    "P7",
    "P8",
    "P9",
    "P10",
    "META",
}

_INJECTION_PATTERNS = [
    (
        "ignore_instructions",
        re.compile(r"ignore (all )?(previous|prior) instructions", re.I),
    ),
    (
        "system_prompt_exfiltration",
        re.compile(r"(reveal|print|dump).{0,40}(system|developer) prompt", re.I),
    ),
    (
        "tool_override",
        re.compile(r"(disable|bypass).{0,40}(safety|guardrail|policy)", re.I),
    ),
    (
        "secret_exfiltration",
        re.compile(r"(exfiltrate|upload|send).{0,40}(secret|token|key)", re.I),
    ),
]

_ASSERTION_LINE_RE = re.compile(
    r"^-\s*(assert\b|expect\(|self\.assert|pytest\.|raise AssertionError)", re.I
)
_TEST_PATH_RE = re.compile(r"(^|/)(tests?|specs?)/|(^|/)test_[^/]+\.py$|_test\.", re.I)
_PROTECTED_ORACLE_RE = re.compile(
    r"(^|/)(tests?|specs?)/|(^|/)test_[^/]+\.py$|_test\.|golden|snapshot", re.I
)
_SCORER_RE = re.compile(r"(monkeypatch|pytest\.skip|xfail|score|grader|oracle)", re.I)
_IMPORT_RE = re.compile(r"^\+\s*(?:import|from)\s+([A-Za-z_][A-Za-z0-9_.-]*)", re.M)
_DEF_RE = re.compile(r"^[+-]\s*def\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(", re.M)
_CALL_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(")


def _as_signal_map(
    capability_signals: dict[str, Any] | None,
) -> dict[str, dict[str, Any]]:
    normalized: dict[str, dict[str, Any]] = {}
    for key, value in (capability_signals or {}).items():
        if isinstance(value, dict):
            normalized[key] = {"available": bool(value.get("available")), **value}
        else:
            normalized[key] = {"available": bool(value)}
    return normalized


def nextgen_status_report(
    *,
    repo_id: str,
    snapshot_id: str,
    provider_status: dict[str, Any],
    capability_signals: dict[str, Any] | None = None,
) -> dict[str, Any]:
    ids = {item["id"] for item in NEXTGEN_PILLARS}
    missing = sorted(_EXPECTED_PILLARS - ids)
    extra = sorted(ids - _EXPECTED_PILLARS)
    signals = _as_signal_map(capability_signals)
    provider_usable = provider_status.get("state") == "usable" or bool(
        provider_status.get("configured")
    )
    pillars = []
    unmet_capabilities: list[str] = []
    for item in NEXTGEN_PILLARS:
        capability_names = list(item.get("capabilities") or [])
        capability_status = {
            name: signals.get(name, {"available": False, "reason": "not_wired"})
            for name in capability_names
        }
        unavailable = [
            name for name, status in capability_status.items() if not status["available"]
        ]
        unmet_capabilities.extend(f"{item['id']}:{name}" for name in unavailable)
        status = "available" if not unavailable else "partial"
        if item["id"] == "META" and not provider_usable and not unavailable:
            status = "inactive"
        pillars.append(
            {
                **item,
                "status": status,
                "capability_status": capability_status,
                "honesty": (
                    "reasoning provider unavailable; deterministic spine remains active"
                    if item["id"] == "META" and not provider_usable
                    else "behavioral capability signals are checked"
                ),
            }
        )
    return {
        "ok": not missing and not unmet_capabilities,
        "schema_version": "persistmind.nextgen_status.v1",
        "repo_id": repo_id,
        "snapshot_id": snapshot_id,
        "coverage": {
            "expected": sorted(_EXPECTED_PILLARS),
            "implemented": list(NEXTGEN_PILLAR_IDS),
            "missing": missing,
            "extra": extra,
            "unmet_capabilities": sorted(unmet_capabilities),
            "complete": not missing and not unmet_capabilities,
        },
        "provider_status": provider_status,
        "pillars": pillars,
    }


def file_provenance(repo_root: Path, path: str) -> dict[str, Any]:
    rel = path.replace("\\", "/")
    target = (repo_root / rel).resolve()
    repo = repo_root.resolve()
    try:
        inside_repo = target.is_relative_to(repo)
    except ValueError:
        inside_repo = False
    if not inside_repo or not target.exists() or not target.is_file():
        return {
            "path": rel,
            "exists": False,
            "trust": "unavailable",
            "reason": "file_not_found_or_outside_repo",
        }
    data = target.read_bytes()
    return {
        "path": rel,
        "exists": True,
        "trust": "snapshot_bound",
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
    }


def stale_state_report(repo_root: Path, served: list[dict[str, Any]]) -> dict[str, Any]:
    stale: list[dict[str, Any]] = []
    for item in served:
        path = str(item.get("path") or "")
        if not path:
            continue
        current = file_provenance(repo_root, path)
        expected_hash = item.get("sha256")
        if not current.get("exists"):
            stale.append({"path": path, "reason": "served_file_missing"})
            continue
        if expected_hash and expected_hash != current.get("sha256"):
            stale.append(
                {
                    "path": path,
                    "reason": "served_hash_mismatch",
                    "served_sha256": expected_hash,
                    "current_sha256": current.get("sha256"),
                }
            )
    return {
        "ok": not stale,
        "schema_version": "persistmind.nextgen_stale_state.v1",
        "checked": len(served),
        "stale": stale,
        "reground_required": bool(stale),
    }


def regrounding_capsule(
    *,
    pack_id: str | None,
    snapshot_id: str,
    progress: str | None = None,
    stale: dict[str, Any] | None = None,
    last_good_checkpoint: str | None = None,
    failed_step: str | None = None,
) -> dict[str, Any]:
    return {
        "schema_version": "persistmind.nextgen_regrounding_capsule.v1",
        "pack_id": pack_id,
        "snapshot_id": snapshot_id,
        "progress": progress or "",
        "last_good_checkpoint": last_good_checkpoint,
        "stale_state": stale or {"ok": True, "stale": []},
        "failed_step": failed_step,
        "restart_anchor": {
            "pack_manifest": pack_id,
            "snapshot_id": snapshot_id,
            "git_checkpoint": last_good_checkpoint,
        },
    }


def dependency_grounding_report(repo_root: Path, package: str) -> dict[str, Any]:
    package = package.strip()
    if not package:
        return {"ok": False, "reason": "package_required"}
    evidence = []
    lockfiles = [
        "requirements.txt",
        "requirements-dev.txt",
        "pyproject.toml",
        "package.json",
        "package-lock.json",
        "pnpm-lock.yaml",
        "yarn.lock",
        "go.mod",
        "go.sum",
        "pom.xml",
        "build.gradle",
        "build.gradle.kts",
        "Cargo.toml",
        "Cargo.lock",
        "Gemfile",
        "Gemfile.lock",
    ]
    pattern = re.compile(rf"(^|[^A-Za-z0-9_.-]){re.escape(package)}([^A-Za-z0-9_.-]|$)", re.I)
    for name in lockfiles:
        path = repo_root / name
        if not path.exists() or not path.is_file():
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if pattern.search(text):
            evidence.append({"path": name, "match": package})
    return {
        "ok": True,
        "package": package,
        "exists_in_project_metadata": bool(evidence),
        "evidence": evidence,
        "approval_required": not bool(evidence),
        "reason": None if evidence else "dependency_not_found_in_project_metadata",
    }


def extract_python_signatures(repo_root: Path, symbol: str) -> list[dict[str, Any]]:
    return extract_signatures(repo_root, symbol, lang="python")


def extract_signatures(
    repo_root: Path, symbol: str, lang: str | None = None
) -> list[dict[str, Any]]:
    wanted = symbol.strip()
    if not wanted:
        return []
    requested_lang = lang.lower() if lang else None
    signatures: list[dict[str, Any]] = []
    for path in repo_root.rglob("*"):
        if any(
            part in {".git", ".persistmind", ".persistmind", "__pycache__"} for part in path.parts
        ):
            continue
        if not path.is_file():
            continue
        detected = language_for(path)
        if detected is None:
            continue
        if requested_lang and detected != requested_lang:
            continue
        rel = path.relative_to(repo_root).as_posix()
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if detected == "python":
            signatures.extend(_extract_python_signatures_from_text(rel, text, wanted))
            continue
        extracted = parse_file(rel, text)
        for item in extracted.symbols:
            if item.qualname.rsplit(".", 1)[-1] != wanted:
                continue
            signatures.append(
                {
                    "path": rel,
                    "line": item.start_line,
                    "kind": item.kind,
                    "lang": detected,
                    "signature": item.signature,
                }
            )
    return signatures


def _extract_python_signatures_from_text(rel: str, text: str, symbol: str) -> list[dict[str, Any]]:
    signatures: list[dict[str, Any]] = []
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return signatures
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == symbol:
            signatures.append(
                {
                    "path": rel,
                    "line": node.lineno,
                    "kind": "function",
                    "lang": "python",
                    "signature": _signature_from_function(node),
                }
            )
        elif isinstance(node, ast.ClassDef) and node.name == symbol:
            signatures.append(
                {
                    "path": rel,
                    "line": node.lineno,
                    "kind": "class",
                    "lang": "python",
                    "signature": f"class {node.name}",
                }
            )
    return signatures


def _signature_from_function(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    args = []
    for arg in [*node.args.posonlyargs, *node.args.args]:
        rendered = arg.arg
        if arg.annotation is not None:
            rendered += f": {ast.unparse(arg.annotation)}"
        args.append(rendered)
    if node.args.vararg:
        args.append("*" + node.args.vararg.arg)
    args.extend(arg.arg for arg in node.args.kwonlyargs)
    if node.args.kwarg:
        args.append("**" + node.args.kwarg.arg)
    prefix = "async def" if isinstance(node, ast.AsyncFunctionDef) else "def"
    result = f"{prefix} {node.name}({', '.join(args)})"
    if node.returns is not None:
        result += f" -> {ast.unparse(node.returns)}"
    return result


def diff_paths(diff: str | None) -> list[str]:
    paths: list[str] = []
    for line in (diff or "").splitlines():
        if line.startswith("+++ b/"):
            paths.append(line[6:].strip())
    return sorted(set(paths))


def imported_packages_from_diff(diff: str | None) -> list[str]:
    packages = []
    for match in _IMPORT_RE.finditer(diff or ""):
        root = match.group(1).split(".", 1)[0]
        if root not in {"app", "src", "tests", "test"}:
            packages.append(root)
    return sorted(set(packages))


def oracle_and_reward_report(
    *,
    paths: list[str],
    diff: str | None = None,
) -> dict[str, Any]:
    findings: list[dict[str, Any]] = []
    all_paths = sorted({path.replace("\\", "/") for path in [*paths, *diff_paths(diff)]})
    for path in all_paths:
        if _PROTECTED_ORACLE_RE.search(path):
            findings.append(
                {
                    "kind": "protected_oracle_edit",
                    "severity": "high",
                    "path": path,
                    "reason": "test_or_oracle_path_changed",
                }
            )
    for line in (diff or "").splitlines():
        if _ASSERTION_LINE_RE.search(line):
            findings.append(
                {
                    "kind": "assertion_removed",
                    "severity": "critical",
                    "line": line[:160],
                    "reason": "diff_removes_assertion_or_oracle_check",
                }
            )
        elif line.startswith(("+", "-")) and _SCORER_RE.search(line):
            findings.append(
                {
                    "kind": "reward_hack_pattern",
                    "severity": "medium",
                    "line": line[:160],
                    "reason": "diff_touches_scorer_or_test_control_pattern",
                }
            )
    return {
        "ok": not findings,
        "status": "ok" if not findings else "verification_failed",
        "schema_version": "persistmind.nextgen_oracle_protection.v1",
        "findings": findings,
        "approval_required": bool(findings),
    }


def semantic_merge_conflict_report(diff_a: str | None, diff_b: str | None) -> dict[str, Any]:
    removed = {
        match.group(1) for match in _DEF_RE.finditer(diff_a or "") if match.group(0).startswith("-")
    }
    added = {
        match.group(1) for match in _DEF_RE.finditer(diff_a or "") if match.group(0).startswith("+")
    }
    calls_b = set(_CALL_RE.findall(diff_b or ""))
    conflicts = []
    for symbol in sorted(removed & calls_b):
        conflicts.append(
            {
                "kind": "rename_or_removed_symbol_still_referenced",
                "symbol": symbol,
                "replacement_candidates": sorted(added),
                "severity": "high",
            }
        )
    return {
        "ok": not conflicts,
        "schema_version": "persistmind.nextgen_merge_check.v1",
        "safe": not conflicts,
        "conflicts": conflicts,
    }


def changed_code_symbols(diff: str | None) -> set[str]:
    return {match.group(1) for match in _DEF_RE.finditer(diff or "")}


def autonomy_budget_report(
    *,
    step_count: int,
    changed_paths: list[str],
    risk: str = "medium",
    max_steps: int = 4,
    max_paths: int = 12,
) -> dict[str, Any]:
    reasons = []
    if step_count > max_steps:
        reasons.append("step_budget_exceeded")
    if len(set(changed_paths)) > max_paths:
        reasons.append("path_budget_exceeded")
    if risk in {"high", "critical"} and step_count > 2:
        reasons.append("high_risk_requires_human_review")
    return {
        "ok": not reasons,
        "schema_version": "persistmind.nextgen_autonomy_budget.v1",
        "step_count": step_count,
        "path_count": len(set(changed_paths)),
        "risk": risk,
        "reasons": reasons,
        "escalate": bool(reasons),
    }


def supervision_decision(
    *,
    paths: list[str],
    check_diff: dict[str, Any],
    impact: dict[str, Any],
    selected_tests: dict[str, Any],
    diff: str | None = None,
    step_count: int = 1,
    risk: str = "medium",
    surprise: dict[str, Any] | None = None,
) -> dict[str, Any]:
    oracle = oracle_and_reward_report(paths=paths, diff=diff)
    budget = autonomy_budget_report(
        step_count=step_count, changed_paths=paths or diff_paths(diff), risk=risk
    )
    gates = {
        "check_diff": check_diff,
        "impact": impact,
        "selected_tests": selected_tests,
        "oracle_protection": oracle,
        "autonomy_budget": budget,
    }
    failed = [
        name for name, gate in gates.items() if isinstance(gate, dict) and gate.get("ok") is False
    ]
    surprise_replan = bool((surprise or {}).get("high_surprise"))
    replan_required = bool(failed or surprise_replan)
    quarantine = None
    if replan_required:
        quarantine = {
            "active": True,
            "reason": "failed_gates_or_surprise",
            "failed_gates": failed,
            "negative_constraint": (
                "Do not condition the next attempt on failed edits; restart from "
                "the last good checkpoint and apply only the distilled lesson."
            ),
        }
    return {
        "ok": not replan_required,
        "schema_version": "persistmind.nextgen_supervision_decision.v1",
        "status": "pass" if not replan_required else "needs_attention",
        "inline_gates": gates,
        "failed_gates": failed,
        "error_quarantine": quarantine,
        "replan_required": replan_required,
        "surprise": surprise or {"high_surprise": False},
    }


def graph_reasoning_report(
    *,
    path: str,
    graph: dict[str, Any],
    tests: dict[str, Any] | None = None,
) -> dict[str, Any]:
    rel = path.replace("\\", "/")
    nodes = graph.get("nodes") or graph.get("neighbors") or []
    edges = graph.get("edges") or []
    touched = {rel}
    for edge in edges:
        for key in ("source_path", "target_path", "from", "to", "path"):
            value = edge.get(key) if isinstance(edge, dict) else None
            if isinstance(value, str) and value:
                touched.add(value.replace("\\", "/"))
    for node in nodes:
        if isinstance(node, dict) and node.get("path"):
            touched.add(str(node["path"]).replace("\\", "/"))
    boundaries = sorted({_top_level(item) for item in touched if item})
    dependency_direction = [
        {
            "from": (edge.get("from") or edge.get("source_path") or rel),
            "to": (edge.get("to") or edge.get("target_path") or edge.get("path")),
            "kind": edge.get("kind", "related"),
        }
        for edge in edges
        if isinstance(edge, dict)
    ]
    return {
        "ok": True,
        "schema_version": "persistmind.nextgen_graph_reasoning.v1",
        "path": rel,
        "boundaries_crossed": boundaries,
        "dependency_direction": dependency_direction,
        "minimal_safe_change_set": sorted(touched),
        "test_paths": _test_paths_from_report(tests or {}),
    }


def ownership_report(repo_root: Path, paths: list[str]) -> dict[str, Any]:
    codeowners = repo_root / "CODEOWNERS"
    rules: list[tuple[str, str]] = []
    if codeowners.exists():
        for raw in codeowners.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                rules.append((parts[0].lstrip("/"), " ".join(parts[1:])))
    owners = []
    for path in paths:
        rel = path.replace("\\", "/")
        matched = [
            owner
            for pattern, owner in rules
            if rel == pattern or rel.startswith(pattern.rstrip("*").rstrip("/") + "/")
        ]
        owners.append({"path": rel, "owners": matched})
    return {
        "ok": True,
        "schema_version": "persistmind.nextgen_ownership.v1",
        "owners": owners,
    }


def _top_level(path: str) -> str:
    return path.split("/", 1)[0] if "/" in path else "."


def _test_paths_from_report(report: dict[str, Any]) -> list[str]:
    tests: list[str] = []
    for key in ("tests", "selected_tests", "candidates"):
        for item in report.get(key) or []:
            if isinstance(item, dict) and item.get("path"):
                tests.append(str(item["path"]).replace("\\", "/"))
            elif isinstance(item, str):
                tests.append(item.replace("\\", "/"))
    return sorted(set(tests))


def spec_code_drift_report(
    repo_root: Path, specs: list[str], code_paths: list[str]
) -> dict[str, Any]:
    findings: list[dict[str, Any]] = []
    for spec in specs:
        spec_path = repo_root / spec
        spec_exists = spec_path.exists()
        spec_text = spec_path.read_text(encoding="utf-8", errors="ignore") if spec_exists else ""
        for code in code_paths:
            code_path = repo_root / code
            if not spec_exists:
                findings.append(
                    {
                        "kind": "missing_spec",
                        "spec": spec,
                        "code": code,
                        "severity": "medium",
                    }
                )
            elif not code_path.exists():
                findings.append(
                    {
                        "kind": "missing_code",
                        "spec": spec,
                        "code": code,
                        "severity": "high",
                    }
                )
            elif code_path.name not in spec_text and code not in spec_text:
                findings.append(
                    {
                        "kind": "unlinked_spec_code",
                        "spec": spec,
                        "code": code,
                        "severity": "medium",
                    }
                )
    return {
        "ok": not findings,
        "status": "ok" if not findings else "verification_failed",
        "schema_version": "persistmind.nextgen_spec_code_drift.v1",
        "findings": findings,
    }


def semantic_conflict_report(paths: list[str], neighbors: list[dict[str, Any]]) -> dict[str, Any]:
    normalized = sorted({path.replace("\\", "/") for path in paths if path})
    conflict_pairs = []
    for path in normalized:
        for neighbor in neighbors:
            graph = neighbor.get("graph", neighbor)
            for edge_path in _paths_from_graph(graph):
                if edge_path != path and edge_path in normalized:
                    conflict_pairs.append(
                        {
                            "paths": sorted([path, edge_path]),
                            "reason": "paths_are_semantically_adjacent_in_graph",
                            "severity": "medium",
                        }
                    )
    unique = []
    seen = set()
    for pair in conflict_pairs:
        key = tuple(pair["paths"])
        if key not in seen:
            seen.add(key)
            unique.append(pair)
    return {
        "ok": not unique,
        "schema_version": "persistmind.nextgen_semantic_conflicts.v1",
        "conflicts": unique,
    }


def _paths_from_graph(graph: dict[str, Any]) -> set[str]:
    paths: set[str] = set()
    for key in ("nodes", "neighbors", "edges"):
        for item in graph.get(key) or []:
            if isinstance(item, dict):
                for path_key in ("path", "from", "to", "source_path", "target_path"):
                    value = item.get(path_key)
                    if isinstance(value, str):
                        paths.add(value.replace("\\", "/"))
    return paths


def scan_untrusted_text(text: str, *, source: str = "context") -> dict[str, Any]:
    findings = []
    for kind, pattern in _INJECTION_PATTERNS:
        match = pattern.search(text or "")
        if match:
            findings.append(
                {
                    "kind": kind,
                    "source": source,
                    "snippet": match.group(0)[:120],
                    "severity": "high",
                }
            )
    return {
        "ok": not findings,
        "status": "ok" if not findings else "verification_failed",
        "schema_version": "persistmind.nextgen_security_scan.v1",
        "source": source,
        "findings": findings,
        "quarantine_recommended": bool(findings),
    }


def defend_served_items(items: list[dict[str, Any]]) -> dict[str, Any]:
    served = []
    quarantined = []
    for item in items:
        text = "\n".join(
            str(value)
            for value in (
                item.get("text"),
                item.get("content"),
                item.get("body"),
            )
            if value
        )
        source = str(item.get("path") or item.get("source") or "served_item")
        scan = scan_untrusted_text(text, source=source)
        if scan["ok"]:
            served.append(item)
        else:
            quarantined.append(
                {
                    "path": item.get("path"),
                    "source": source,
                    "findings": scan["findings"],
                    "reason": "untrusted_served_content",
                }
            )
    return {
        "ok": not quarantined,
        "schema_version": "persistmind.nextgen_defend_served.v1",
        "served": served,
        "quarantined": quarantined,
    }


def context_budget_report(items: list[dict[str, Any]]) -> dict[str, Any]:
    token_count = sum(int(item.get("token_count") or 0) for item in items)
    stable_prefix_items = sum(1 for item in items if item.get("path"))
    return {
        "ok": True,
        "schema_version": "persistmind.nextgen_context_budget.v1",
        "estimated_tokens": token_count,
        "stable_prefix_items": stable_prefix_items,
        "cache_friendly": stable_prefix_items > 0,
    }


def economics_report(
    baseline_tokens: int,
    served_items: list[dict[str, Any]],
    changed_paths: list[str] | None = None,
) -> dict[str, Any]:
    changed = {path.replace("\\", "/") for path in changed_paths or []}
    reusable_tokens = 0
    for item in served_items:
        path = str(item.get("path") or "").replace("\\", "/")
        tokens = int(item.get("token_count") or 0)
        if path and path not in changed:
            reusable_tokens += tokens
    savings = (reusable_tokens / baseline_tokens) if baseline_tokens else 0.0
    return {
        "ok": True,
        "schema_version": "persistmind.nextgen_economics.v1",
        "baseline_tokens": baseline_tokens,
        "reusable_tokens": reusable_tokens,
        "estimated_cache_savings_ratio": round(min(1.0, savings), 6),
    }
