from __future__ import annotations

import base64
import binascii
import json
import os
import platform
import hashlib
import sys
from importlib import resources
from pathlib import Path
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from packaging.version import InvalidVersion, Version

from persistmind import __version__


INTERNAL_PREVIEW_PROFILE = "windows-internal-preview"
INTERNAL_PREVIEW_RELEASE_TYPE = "Internal Windows Preview"
INTERNAL_PREVIEW_WARNING = (
    "PersistMind is running as an Internal Windows Preview.\n"
    "Use only with non-critical local repositories.\n"
    "This build is not production-qualified and is not part of the trusted public update channel."
)
UNPROMOTED_CANDIDATE_WARNING = (
    "PersistMind is running as an unpromoted Windows Release Candidate.\n"
    "Use only with non-critical local repositories; manual human review remains required.\n"
    "This build is not production-qualified or active in the trusted public update channel."
)
_IDENTITY_FILE = "release-identity.json"
RELEASE_IDENTITY_SCHEMA = "persistmind.release_identity.v4"
RELEASE_MATURITIES = frozenset(
    {"development", "internal_preview", "release_candidate", "public_beta", "production"}
)
TRUSTED_MANIFEST_NAME = "trusted-release-manifest.v4.json"
TRUSTED_MANIFEST_SIGNATURE_NAME = f"{TRUSTED_MANIFEST_NAME}.sig"
MANIFEST_SELF_VERIFICATION_ID = "signed-manifest:self:ed25519:v4"
UPDATE_ROOT_KEYS = (
    "2zTxhUn/x3MO0ju5mXYuEmbJfAGWj6BE9nWkgBb43do=",
    "kuh85P8eq5Qp1S4kIUJ2LoUfxZX+TbEstEaKgJtlV4A=",
)


def build_release_identity(
    *,
    version: str,
    channel: str,
    source_commit: str,
    build_timestamp: str | None,
    release_type: str,
    runtime_profile: str,
    compatible_os: list[str],
    compatible_python: list[str],
    qualified_os: list[str] | None = None,
    qualified_python: list[str] | None = None,
    qualification_evidence_ids: list[str] | None = None,
    observed_environments: list[dict[str, Any]] | None = None,
    wheel_sha256: str | None = None,
    installer_sha256: str | None = None,
    operation_catalog_sha256: str | None = None,
    schema_heads: dict[str, int] | None = None,
    profile_locked: bool = False,
    maturity: str,
    officially_signed: bool = False,
    signing_status: str = "unsigned",
    known_limitations: list[str] | None = None,
    supported_agent_evidence_ids: list[str] | None = None,
    signed_manifest_verification_id: str | None = None,
    independent_approval_id: str | None = None,
) -> dict[str, Any]:
    """Build the sole canonical identity shared by packaging and promotion."""

    identity = {
        "schema_version": RELEASE_IDENTITY_SCHEMA,
        "product": "PersistMind",
        "version": version,
        "release_type": release_type,
        "channel": channel,
        "source_commit": source_commit,
        "build_timestamp": build_timestamp,
        "compatible_os": sorted(set(compatible_os)),
        "compatible_python": sorted(set(compatible_python)),
        "qualified_os": sorted(set(qualified_os or [])),
        "qualified_python": sorted(set(qualified_python or [])),
        "qualification_evidence_ids": sorted(set(qualification_evidence_ids or [])),
        "observed_environments": list(observed_environments or []),
        "artifact_hashes": {
            "wheel_sha256": wheel_sha256,
            "installer_sha256": installer_sha256,
        },
        "operation_catalog_sha256": operation_catalog_sha256,
        "schema_heads": dict(sorted((schema_heads or {}).items())),
        "officially_signed": officially_signed,
        "signing_status": signing_status,
        "maturity": maturity,
        "production": maturity == "production",
        "public_beta": maturity == "public_beta",
        "runtime_profile": runtime_profile,
        "profile_locked": profile_locked,
        "known_limitations": list(known_limitations or []),
        "promotion": {
            "supported_agent_evidence_ids": sorted(set(supported_agent_evidence_ids or [])),
            "signed_manifest_verification_id": signed_manifest_verification_id,
            "independent_approval_id": independent_approval_id,
        },
    }
    identity["identity_hash"] = hashlib.sha256(
        json.dumps(identity, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    validate_release_identity(identity)
    return identity


def validate_release_identity(identity: dict[str, Any]) -> None:
    if identity.get("schema_version") != RELEASE_IDENTITY_SCHEMA:
        raise ValueError("unsupported release identity schema")
    supplied_hash = identity.get("identity_hash")
    payload = {key: value for key, value in identity.items() if key != "identity_hash"}
    expected_hash = hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    if supplied_hash != expected_hash:
        raise ValueError("release identity hash does not match its canonical content")
    maturity = str(identity.get("maturity") or "")
    if maturity not in RELEASE_MATURITIES:
        raise ValueError(f"unsupported release maturity: {maturity!r}")
    if bool(identity.get("production")) != (maturity == "production"):
        raise ValueError("production flag must be derived from release maturity")
    if bool(identity.get("public_beta")) != (maturity == "public_beta"):
        raise ValueError("public_beta flag must be derived from release maturity")
    compatible_os = {str(item) for item in identity.get("compatible_os", [])}
    compatible_python = {str(item) for item in identity.get("compatible_python", [])}
    qualified_os = {str(item) for item in identity.get("qualified_os", [])}
    qualified_python = {str(item) for item in identity.get("qualified_python", [])}
    if not qualified_os <= compatible_os or not qualified_python <= compatible_python:
        raise ValueError("release qualification exceeds the compatible environment matrix")
    if (qualified_os or qualified_python) and not identity.get("qualification_evidence_ids"):
        raise ValueError("qualified environments require qualification evidence")
    hashes = identity.get("artifact_hashes")
    if not isinstance(hashes, dict):
        raise ValueError("release identity artifact hashes are absent")
    for name in ("wheel_sha256", "installer_sha256"):
        value = hashes.get(name)
        if value is not None and (
            not isinstance(value, str)
            or len(value) != 64
            or any(character not in "0123456789abcdef" for character in value)
        ):
            raise ValueError(f"release identity {name} is invalid")
    promotion = identity.get("promotion")
    if not isinstance(promotion, dict):
        raise ValueError("release identity promotion inputs are absent")
    if (
        identity.get("release_type") == INTERNAL_PREVIEW_RELEASE_TYPE
        or maturity == "internal_preview"
    ):
        if maturity != "internal_preview":
            raise ValueError("Internal Windows Preview must use internal_preview maturity")
        if (
            identity.get("officially_signed")
            or identity.get("production")
            or identity.get("public_beta")
        ):
            raise ValueError("Internal Windows Preview cannot claim signed beta or production")
        if any(
            promotion.get(key)
            for key in (
                "supported_agent_evidence_ids",
                "signed_manifest_verification_id",
                "independent_approval_id",
            )
        ):
            raise ValueError("Internal Windows Preview cannot carry promotion inputs")
    if maturity in {"public_beta", "production"}:
        try:
            parsed_version = Version(str(identity.get("version") or ""))
        except InvalidVersion as exc:
            raise ValueError("beta and production identities require a valid version") from exc
        if maturity == "production" and parsed_version.is_prerelease:
            raise ValueError("production identity cannot use a prerelease version")
        if maturity == "public_beta" and not parsed_version.is_prerelease:
            raise ValueError("public beta identity requires a prerelease version")
        if not identity.get("officially_signed"):
            raise ValueError("beta and production identities must be officially signed")
        if identity.get("signing_status") != "signed-trusted-update":
            raise ValueError("beta and production identities require trusted update signing")
        if not qualified_os or not qualified_python:
            raise ValueError("beta and production identities require qualified environments")
        if not hashes.get("wheel_sha256"):
            raise ValueError("beta and production identities require the exact wheel digest")
        if not promotion.get("supported_agent_evidence_ids"):
            raise ValueError("beta and production identities require supported-agent evidence")
        if not promotion.get("signed_manifest_verification_id"):
            raise ValueError("beta and production identities require signed-manifest verification")
        if not promotion.get("independent_approval_id"):
            raise ValueError("beta and production identities require independent approval")
        if identity.get("runtime_profile") != "windows-stable" or not identity.get(
            "profile_locked"
        ):
            raise ValueError("beta and production identities must lock the windows-stable profile")


def migrate_release_identity(value: dict[str, Any]) -> dict[str, Any]:
    """Read older identities without treating compatibility as qualification."""

    if value.get("schema_version") == RELEASE_IDENTITY_SCHEMA:
        return dict(value)
    migrated = dict(value)
    migrated["schema_version"] = RELEASE_IDENTITY_SCHEMA
    migrated["compatible_os"] = list(value.get("compatible_os") or value.get("supported_os") or [])
    migrated["compatible_python"] = list(
        value.get("compatible_python") or value.get("supported_python") or []
    )
    migrated.setdefault("qualified_os", [])
    migrated.setdefault("qualified_python", [])
    migrated.setdefault("qualification_evidence_ids", [])
    migrated.setdefault("observed_environments", [])
    migrated.setdefault("artifact_hashes", {"wheel_sha256": None, "installer_sha256": None})
    migrated.setdefault("operation_catalog_sha256", None)
    migrated.setdefault("schema_heads", {})
    migrated["maturity"] = (
        "production"
        if value.get("production")
        else "public_beta"
        if value.get("public_beta")
        else "internal_preview"
        if value.get("release_type") == INTERNAL_PREVIEW_RELEASE_TYPE
        else "development"
    )
    migrated.setdefault(
        "promotion",
        {
            "supported_agent_evidence_ids": [],
            "signed_manifest_verification_id": None,
            "independent_approval_id": None,
        },
    )
    migrated.pop("identity_hash", None)
    migrated["identity_hash"] = hashlib.sha256(
        json.dumps(migrated, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    return migrated


def release_identity() -> dict[str, Any]:
    """Return immutable packaged identity, or an explicit source-tree fallback."""

    packaged = _packaged_identity()
    if packaged is not None:
        activated = _activated_identity(packaged)
        return activated if activated is not None else packaged
    internal = ".dev" in __version__
    return build_release_identity(
        version=__version__,
        channel=INTERNAL_PREVIEW_PROFILE if internal else "source-development",
        source_commit=os.environ.get("PERSISTMIND_SOURCE_COMMIT", "UNBUILT_SOURCE"),
        build_timestamp=None,
        release_type=INTERNAL_PREVIEW_RELEASE_TYPE if internal else "Development checkout",
        runtime_profile=INTERNAL_PREVIEW_PROFILE if internal else "core-local",
        compatible_os=["Windows 10", "Windows 11"] if internal else [],
        compatible_python=["3.11", "3.12", "3.13"],
        maturity="internal_preview" if internal else "development",
        signing_status="unsigned-internal-preview" if internal else "source-checkout",
        known_limitations=_internal_limitations() if internal else [],
    )


def public_release_identity() -> dict[str, Any]:
    identity = release_identity()
    return {
        key: identity.get(key)
        for key in (
            "schema_version",
            "product",
            "version",
            "release_type",
            "channel",
            "source_commit",
            "build_timestamp",
            "compatible_os",
            "compatible_python",
            "qualified_os",
            "qualified_python",
            "qualification_evidence_ids",
            "observed_environments",
            "artifact_hashes",
            "operation_catalog_sha256",
            "schema_heads",
            "identity_hash",
            "officially_signed",
            "signing_status",
            "maturity",
            "production",
            "public_beta",
            "runtime_profile",
            "profile_locked",
            "known_limitations",
            "promotion",
        )
    }


def default_runtime_profile() -> str:
    return str(release_identity()["runtime_profile"])


def maturity_warning() -> str | None:
    identity = release_identity()
    if identity.get("release_type") == INTERNAL_PREVIEW_RELEASE_TYPE:
        return INTERNAL_PREVIEW_WARNING
    if identity.get("maturity") == "release_candidate":
        return UNPROMOTED_CANDIDATE_WARNING
    return None


def version_banner(product_name: str = "PersistMind") -> str:
    identity = release_identity()
    lines = [f"{product_name} {identity['version']}"]
    warning = maturity_warning()
    if warning:
        lines.extend(
            [
                str(identity.get("release_type") or "Unpromoted build"),
                f"Source commit: {identity['source_commit']}",
                warning,
            ]
        )
    return "\n".join(lines)


def validate_runtime_settings(settings: Any) -> None:
    """Fail closed when an installed internal preview attempts a broader profile."""

    identity = release_identity()
    active = str(settings.profile.name)
    required_profile = str(identity.get("runtime_profile") or "")
    if identity.get("profile_locked") and active != required_profile:
        raise ValueError(f"this installed release is locked to profile.name={required_profile!r}")
    if active != INTERNAL_PREVIEW_PROFILE:
        return
    if list(settings.deferred.enabled):
        raise ValueError("windows-internal-preview requires deferred.enabled to remain empty")
    if str(settings.server.mode) != "local":
        raise ValueError("windows-internal-preview refuses remote team/server operation")
    if str(settings.metacognition.judgment_mode) == "autonomous":
        raise ValueError("windows-internal-preview refuses autonomous judgment mode")


def validate_internal_preview_server_binding(profile: str, host: str) -> None:
    if profile != INTERNAL_PREVIEW_PROFILE:
        return
    normalized = host.strip().casefold().strip("[]")
    if normalized not in {"127.0.0.1", "::1", "localhost"}:
        raise PermissionError(
            "windows-internal-preview permits HTTP binding only to the local loopback interface"
        )


def _packaged_identity() -> dict[str, Any] | None:
    try:
        path = resources.files("persistmind").joinpath(_IDENTITY_FILE)
        if not path.is_file():
            return None
        value = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, OSError, UnicodeDecodeError, json.JSONDecodeError):
        return None
    if not isinstance(value, dict) or value.get("version") != __version__:
        raise RuntimeError("packaged release identity does not match the running package version")
    identity = migrate_release_identity(value)
    validate_release_identity(identity)
    return identity


def _activated_identity(packaged: dict[str, Any]) -> dict[str, Any] | None:
    override = os.environ.get("PERSISTMIND_TRUSTED_RELEASE_ACTIVATION")
    root = (
        Path(override).expanduser().resolve()
        if override
        else Path(sys.prefix).resolve() / "share" / "persistmind"
    )
    manifest_path = root / TRUSTED_MANIFEST_NAME
    signature_path = root / TRUSTED_MANIFEST_SIGNATURE_NAME
    if not manifest_path.exists() and not signature_path.exists():
        return None
    if not manifest_path.is_file() or not signature_path.is_file():
        raise RuntimeError("trusted release activation is incomplete")
    try:
        document = manifest_path.read_bytes()
        signature = base64.b64decode(signature_path.read_bytes().strip(), validate=True)
    except (OSError, binascii.Error, ValueError) as exc:
        raise RuntimeError("trusted release activation is unreadable") from exc
    for encoded_key in UPDATE_ROOT_KEYS:
        try:
            key = Ed25519PublicKey.from_public_bytes(base64.b64decode(encoded_key, validate=True))
            key.verify(signature, document)
            break
        except (binascii.Error, ValueError, InvalidSignature):
            continue
    else:
        raise RuntimeError("trusted release activation signature is not trusted")
    try:
        manifest = json.loads(document)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError("trusted release activation manifest is invalid JSON") from exc
    identity = manifest.get("release_identity") if isinstance(manifest, dict) else None
    if (
        not isinstance(identity, dict)
        or manifest.get("schema_version") != "persistmind.update_manifest.v4"
        or manifest.get("promotion_status") != "promoted"
    ):
        raise RuntimeError("trusted release activation lacks a promoted v4 identity")
    identity = migrate_release_identity(identity)
    try:
        validate_release_identity(identity)
    except ValueError as exc:
        raise RuntimeError("trusted release activation identity is invalid") from exc
    if identity.get("maturity") not in {"public_beta", "production"}:
        raise RuntimeError("trusted release activation maturity is not promotable")
    if (
        identity.get("promotion", {}).get("signed_manifest_verification_id")
        != MANIFEST_SELF_VERIFICATION_ID
    ):
        raise RuntimeError("trusted release activation is not bound to its signed manifest")
    if (
        identity.get("version") != __version__
        or manifest.get("version") != __version__
        or identity.get("source_commit") != manifest.get("commit_sha")
        or identity.get("source_commit") != packaged.get("source_commit")
    ):
        raise RuntimeError("trusted release activation does not match the installed build")
    expected_channel = "stable" if identity.get("maturity") == "production" else "preview"
    if identity.get("channel") != expected_channel or manifest.get("channel") != expected_channel:
        raise RuntimeError("trusted release activation channel disagrees with its maturity")
    root_wheels = [
        item
        for item in manifest.get("artifacts", [])
        if isinstance(item, dict)
        and item.get("role") == "root"
        and str(item.get("filename") or "").endswith(".whl")
    ]
    if len(root_wheels) != 1 or root_wheels[0].get("sha256") != identity.get(
        "artifact_hashes", {}
    ).get("wheel_sha256"):
        raise RuntimeError("trusted release activation does not bind the installed wheel")
    return identity


def _internal_limitations() -> list[str]:
    return [
        "Private internal testing only",
        "Windows 10/11 only; Linux and macOS are not qualified",
        "Non-critical local repositories only",
        "Manual human review is required",
        "Read-only MCP only",
        "No remote writable service or mutation broker",
        "No autonomous source-changing behavior",
        "Not part of the trusted public update channel",
        f"Runtime host observed as {platform.system() or 'unknown'}",
    ]


__all__ = [
    "INTERNAL_PREVIEW_PROFILE",
    "INTERNAL_PREVIEW_RELEASE_TYPE",
    "INTERNAL_PREVIEW_WARNING",
    "UNPROMOTED_CANDIDATE_WARNING",
    "RELEASE_MATURITIES",
    "RELEASE_IDENTITY_SCHEMA",
    "TRUSTED_MANIFEST_NAME",
    "TRUSTED_MANIFEST_SIGNATURE_NAME",
    "build_release_identity",
    "default_runtime_profile",
    "maturity_warning",
    "migrate_release_identity",
    "public_release_identity",
    "release_identity",
    "validate_internal_preview_server_binding",
    "validate_release_identity",
    "validate_runtime_settings",
    "version_banner",
]
