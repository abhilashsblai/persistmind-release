from __future__ import annotations

import asyncio
import importlib.util
import subprocess
from collections.abc import Callable, Mapping, Sequence
from pathlib import Path
from threading import Event, Thread
from typing import Any


class OfficialSDKACPTransport:
    """Synchronous adapter over the pinned official ACP Python SDK stdio client."""

    def __init__(
        self,
        agent_command: Sequence[str],
        *,
        cwd: Path,
        environment: Mapping[str, str] | None = None,
        update_handler: Callable[[Mapping[str, Any]], None] | None = None,
        permission_handler: Callable[[Mapping[str, Any]], str | None] | None = None,
        startup_timeout_seconds: int = 10,
    ) -> None:
        if importlib.util.find_spec("acp") is None:
            raise RuntimeError(
                "official ACP SDK is unavailable; install PersistMind with the 'acp' extra"
            )
        command = tuple(str(item) for item in agent_command)
        if not command or not command[0].strip():
            raise ValueError("ACP agent command is required")
        self.command = command
        self.cwd = Path(cwd).resolve()
        self.environment = dict(environment or {})
        self.update_handler = update_handler
        self.permission_handler = permission_handler
        self._ready = Event()
        self._thread = Thread(target=self._thread_main, daemon=True, name="persistmind-acp-sdk")
        self._loop: asyncio.AbstractEventLoop | None = None
        self._connection: Any = None
        self._process: Any = None
        self._close_event: asyncio.Event | None = None
        self._error: BaseException | None = None
        self._thread.start()
        if not self._ready.wait(max(1, min(int(startup_timeout_seconds), 60))):
            raise TimeoutError("ACP SDK transport did not start before its deadline")
        if self._error is not None:
            raise RuntimeError(f"ACP SDK transport failed to start: {self._error}") from self._error

    def request(
        self, method: str, params: Mapping[str, Any], *, timeout_seconds: int
    ) -> Mapping[str, Any]:
        future = asyncio.run_coroutine_threadsafe(
            self._request(method, dict(params)), self._require_loop()
        )
        value = future.result(timeout=max(1, min(int(timeout_seconds), 3600)))
        return _document(value)

    def notify(self, method: str, params: Mapping[str, Any]) -> None:
        future = asyncio.run_coroutine_threadsafe(
            self._notify(method, dict(params)), self._require_loop()
        )
        future.result(timeout=10)

    def close(self) -> None:
        loop = self._loop
        event = self._close_event
        if loop is not None and event is not None and not loop.is_closed():
            loop.call_soon_threadsafe(event.set)
        self._thread.join(timeout=10)

    @property
    def process_id(self) -> int | None:
        process = self._process
        value = getattr(process, "pid", None)
        return int(value) if isinstance(value, int) and value > 0 else None

    def _thread_main(self) -> None:
        try:
            asyncio.run(self._serve())
        except BaseException as exc:  # noqa: BLE001 - propagated through the ready fence.
            self._error = exc
            self._ready.set()

    async def _serve(self) -> None:
        import acp  # type: ignore[import-not-found]

        self._loop = asyncio.get_running_loop()
        self._close_event = asyncio.Event()
        client = _SDKClient(self)
        environment = dict(self.environment)
        async with acp.spawn_agent_process(
            client,
            self.command[0],
            *self.command[1:],
            cwd=self.cwd,
            env=environment,
            transport_kwargs={"stderr": subprocess.DEVNULL, "limit": 1024 * 1024},
        ) as (connection, process):
            self._connection = connection
            self._process = process
            self._ready.set()
            await self._close_event.wait()

    async def _request(self, method: str, params: Mapping[str, Any]) -> Any:
        connection = self._connection
        if connection is None:
            raise RuntimeError("ACP SDK connection is unavailable")
        if method == "initialize":
            return await connection.initialize(
                protocol_version=int(params.get("protocolVersion", 1)),
                client_capabilities=None,
                client_info=None,
            )
        if method == "session/new":
            return await connection.new_session(
                cwd=str(params["cwd"]), mcp_servers=list(params.get("mcpServers") or [])
            )
        if method == "session/resume":
            return await connection.resume_session(
                cwd=str(params["cwd"]),
                session_id=str(params["sessionId"]),
                mcp_servers=list(params.get("mcpServers") or []),
            )
        if method == "session/prompt":
            import acp  # type: ignore[import-not-found]

            blocks = []
            for item in params.get("prompt") or []:
                if isinstance(item, Mapping) and item.get("type") == "text":
                    blocks.append(acp.text_block(str(item.get("text") or "")))
            return await connection.prompt(session_id=str(params["sessionId"]), prompt=blocks)
        return await connection.ext_method(method, dict(params))

    async def _notify(self, method: str, params: Mapping[str, Any]) -> None:
        connection = self._connection
        if connection is None:
            raise RuntimeError("ACP SDK connection is unavailable")
        if method == "session/cancel":
            await connection.cancel(session_id=str(params["sessionId"]))
            return
        await connection.ext_notification(method, dict(params))

    def _require_loop(self) -> asyncio.AbstractEventLoop:
        if self._error is not None:
            raise RuntimeError(f"ACP SDK transport failed: {self._error}") from self._error
        if self._loop is None or self._loop.is_closed():
            raise RuntimeError("ACP SDK transport is not active")
        return self._loop


class _SDKClient:
    def __init__(self, transport: OfficialSDKACPTransport) -> None:
        self.transport = transport

    def on_connect(self, connection: Any) -> None:
        return None

    async def request_permission(
        self, options: list[Any], session_id: str, tool_call: Any, **_: Any
    ) -> Any:
        from acp.schema import (  # type: ignore[import-not-found]
            AllowedOutcome,
            DeniedOutcome,
            RequestPermissionResponse,
        )

        request = {
            "sessionId": session_id,
            "options": [_document(item) for item in options],
            "toolCall": _document(tool_call),
        }
        selected = (
            self.transport.permission_handler(request)
            if self.transport.permission_handler is not None
            else None
        )
        outcome = (
            AllowedOutcome(outcome="selected", option_id=str(selected))
            if selected is not None
            else DeniedOutcome(outcome="cancelled")
        )
        return RequestPermissionResponse(outcome=outcome)

    async def session_update(self, session_id: str, update: Any, **_: Any) -> None:
        if self.transport.update_handler is not None:
            self.transport.update_handler({"sessionId": session_id, "update": _document(update)})

    async def ext_method(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        raise RuntimeError(f"unsupported ACP client extension request: {method}")

    async def ext_notification(self, method: str, params: dict[str, Any]) -> None:
        return None

    async def __getattr_request(self, *_: Any, **__: Any) -> Any:
        raise RuntimeError("ACP client filesystem and terminal callbacks are parent-controlled")

    read_text_file = __getattr_request
    write_text_file = __getattr_request
    create_terminal = __getattr_request
    terminal_output = __getattr_request
    release_terminal = __getattr_request
    wait_for_terminal_exit = __getattr_request
    kill_terminal = __getattr_request


def _document(value: Any) -> dict[str, Any]:
    if hasattr(value, "model_dump"):
        dumped = value.model_dump(by_alias=True, exclude_none=True)
        return dict(dumped) if isinstance(dumped, Mapping) else {}
    return dict(value) if isinstance(value, Mapping) else {}


__all__ = ["OfficialSDKACPTransport"]
