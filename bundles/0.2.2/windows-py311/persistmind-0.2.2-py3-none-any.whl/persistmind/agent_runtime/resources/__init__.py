"""Versioned agent-runtime contract resources."""
