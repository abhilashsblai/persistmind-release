from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
from typing import Any


def refresh_fast_policy_snapshot(args: argparse.Namespace, result: dict[str, Any]) -> None:
    """Publish hook policy state after authoritative workflow transitions."""

    command = str(getattr(args, "command", "") or "")
    subcommand = str(
        getattr(args, "codex_command", None)
        or getattr(args, "workflow_command", None)
        or getattr(args, "plan_command", None)
        or getattr(args, "task_command", None)
        or getattr(args, "policy_command", None)
        or getattr(args, "constitution_command", None)
        or ""
    )
    authoritative_preflight = command == "codex" and subcommand == "preflight"
    invalidating_transition = _invalidates_policy_snapshot(command, subcommand)
    if not authoritative_preflight and not invalidating_transition:
        return
    explicit = _find_boolean(result, "preflight_ready") if authoritative_preflight else None
    if authoritative_preflight and explicit is None:
        return
    ready = bool(explicit) if authoritative_preflight else False
    authorization_mode = "none"
    try:
        from persistmind.agent_runtime.hooks import read_policy_snapshot, write_policy_snapshot
        from persistmind.agent_runtime.protocol import active_project_protocol
        from persistmind.branding import resolve_project_state
        from persistmind.utils import canonical_json

        repo = Path(args.repo).resolve()
        state = resolve_project_state(repo)
        task_session_id = _find_string(result, "task_session_id") or str(
            getattr(args, "task_session_id", "") or ""
        )
        pack_id = _find_string(result, "pack_id") or str(getattr(args, "pack_id", "") or "")
        plan_id = _find_string(result, "plan_id") or str(getattr(args, "plan_arg", "") or "")
        if authoritative_preflight:
            authorization_mode = str(
                result.get("mode") or getattr(args, "mode", "write") or "write"
            ).casefold()
        else:
            previous = read_policy_snapshot(repo)
            if _preserves_policy_snapshot(
                args,
                result,
                previous,
                task_session_id=task_session_id,
                pack_id=pack_id,
            ):
                ready = True
                authorization_mode = str(previous.get("authorization_mode") or "none")
                task_session_id = task_session_id or str(previous.get("task_session_id") or "")
                pack_id = pack_id or str(previous.get("pack_id") or "")
                plan_id = plan_id or str(previous.get("plan_id") or "")
        revision_material = {
            "command": command,
            "subcommand": subcommand,
            "preflight_ready": ready,
            "pack_id": pack_id or None,
            "task_session_id": task_session_id or None,
            "constitution_hash": result.get("constitution_hash"),
            "authorization_mode": authorization_mode,
        }
        revision = hashlib.sha256(canonical_json(revision_material).encode("utf-8")).hexdigest()
        write_policy_snapshot(
            repo,
            revision=revision,
            preflight_ready=ready,
            runtime_epoch=max(1, active_project_protocol(state)),
            task_session_id=task_session_id or None,
            pack_id=pack_id or None,
            plan_id=plan_id or None,
            authorization_mode=authorization_mode,
        )
    except Exception:
        # A derived fast cache can never downgrade the authoritative command result.
        return


def _find_boolean(value: Any, key: str) -> bool | None:
    if isinstance(value, dict):
        candidate = value.get(key)
        if isinstance(candidate, bool):
            return candidate
        for child in value.values():
            found = _find_boolean(child, key)
            if found is not None:
                return found
    elif isinstance(value, list):
        for child in value:
            found = _find_boolean(child, key)
            if found is not None:
                return found
    return None


def _invalidates_policy_snapshot(command: str, subcommand: str) -> bool:
    """Identify commands that can change preflight authorization inputs.

    Read-only members of a mutating command family (for example ``task show``
    and ``plan show``) must not clear a valid snapshot.  Only an explicit
    preflight may replace authorization; successful workflow mutations either
    preserve the matching authorization below or invalidate it fail-closed.
    """

    if command in {"install", "pack", "setup"}:
        return True
    return subcommand in {
        "constitution": {"build"},
        "plan": {"create", "amend", "checkpoint"},
        "policy": {"approve-business-rule"},
        "task": {"start", "transition"},
        "workflow": {"rebind", "start"},
    }.get(command, set())


def _find_string(value: Any, key: str) -> str | None:
    if isinstance(value, dict):
        candidate = value.get(key)
        if isinstance(candidate, str) and candidate:
            return candidate
        for child in value.values():
            found = _find_string(child, key)
            if found:
                return found
    elif isinstance(value, list):
        for child in value:
            found = _find_string(child, key)
            if found:
                return found
    return None


def _preserves_policy_snapshot(
    args: argparse.Namespace,
    result: dict[str, Any],
    previous: dict[str, Any],
    *,
    task_session_id: str,
    pack_id: str,
) -> bool:
    if not result.get("ok") or not (previous.get("current") and previous.get("preflight_ready")):
        return False
    command = str(getattr(args, "command", "") or "")
    plan_transition = command == "plan" and str(getattr(args, "plan_command", "") or "") in {
        "create",
        "amend",
        "checkpoint",
    }
    pack_transition = command == "pack"
    task_transition = (
        command == "task" and str(getattr(args, "task_command", "") or "") == "transition"
    )
    if task_transition and str(result.get("to_state") or "") not in {
        "PLAN",
        "EXECUTE",
        "PREFLIGHT",
    }:
        return False
    if not plan_transition and not task_transition and not pack_transition:
        return False
    previous_task = str(previous.get("task_session_id") or "")
    previous_pack = str(previous.get("pack_id") or "")
    if not previous_task or task_session_id != previous_task:
        return False
    return not pack_id or not previous_pack or pack_id == previous_pack


__all__ = ["refresh_fast_policy_snapshot"]
