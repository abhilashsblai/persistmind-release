from __future__ import annotations

import hashlib
import hmac
import json
from datetime import datetime, timedelta, timezone
from enum import StrEnum
from pathlib import Path
from typing import Any, Mapping

from persistmind.application.agent_runtime_ports import (
    AgentRuntimeActivityPort,
    AgentRuntimeAuditPort,
)
from persistmind.utils import stable_id

from .identity import RepositoryContext


EVENT_SCHEMA = "persistmind.agent_event.v1"
MAX_EVENT_BYTES = 128 * 1024


class AgentEventType(StrEnum):
    SESSION_STARTED = "session.started"
    SESSION_ENDED = "session.ended"
    PROMPT_RECEIVED = "prompt.received"
    AGENT_BEFORE = "agent.before"
    AGENT_AFTER = "agent.after"
    TOOL_BEFORE = "tool.before"
    TOOL_AFTER = "tool.after"
    TOOL_FAILED = "tool.failed"
    PERMISSION_DENIED = "permission.denied"
    SUBAGENT_STARTED = "subagent.started"
    SUBAGENT_ENDED = "subagent.ended"
    COMPACTION_BEFORE = "context.compaction.before"
    COMPACTION_AFTER = "context.compaction.after"


ALIASES: dict[str, AgentEventType] = {
    "sessionstart": AgentEventType.SESSION_STARTED,
    "session_start": AgentEventType.SESSION_STARTED,
    "sessionend": AgentEventType.SESSION_ENDED,
    "stop": AgentEventType.SESSION_ENDED,
    "userpromptsubmit": AgentEventType.PROMPT_RECEIVED,
    "prompt": AgentEventType.PROMPT_RECEIVED,
    "beforeagent": AgentEventType.AGENT_BEFORE,
    "afteragent": AgentEventType.AGENT_AFTER,
    "pretooluse": AgentEventType.TOOL_BEFORE,
    "beforetool": AgentEventType.TOOL_BEFORE,
    "before_tool": AgentEventType.TOOL_BEFORE,
    "posttooluse": AgentEventType.TOOL_AFTER,
    "aftertool": AgentEventType.TOOL_AFTER,
    "after_tool": AgentEventType.TOOL_AFTER,
    "posttoolusefailure": AgentEventType.TOOL_FAILED,
    "tool_failed": AgentEventType.TOOL_FAILED,
    "permissiondenied": AgentEventType.PERMISSION_DENIED,
    "subagentstart": AgentEventType.SUBAGENT_STARTED,
    "subagentstop": AgentEventType.SUBAGENT_ENDED,
    "precompact": AgentEventType.COMPACTION_BEFORE,
    "precompress": AgentEventType.COMPACTION_BEFORE,
    "postcompact": AgentEventType.COMPACTION_AFTER,
}
_SECRET_KEYS = ("authorization", "cookie", "credential", "password", "secret", "token")
_CONTENT_KEYS = frozenset(
    {
        "content",
        "message",
        "output",
        "prompt",
        "response",
        "result",
        "stderr",
        "stdout",
        "text",
        "tool_result",
        "toolresult",
    }
)
SECURITY_AUDIT_EVENT_TYPES = frozenset(
    {
        AgentEventType.PERMISSION_DENIED.value,
        AgentEventType.TOOL_FAILED.value,
    }
)


def handle_host_hook_event(
    repo: Path,
    event: str,
    payload: Mapping[str, Any] | object,
) -> dict[str, Any]:
    """Evaluate one host hook through the shared, bounded runtime path.

    Generated hook scripts, CLI calls, and HTTP calls use this function so a
    catalog cutover cannot silently disable host attachment or policy gates.
    """

    root = Path(repo).resolve()
    body = dict(payload) if isinstance(payload, Mapping) else {"payload": payload}
    base: dict[str, Any] = {
        "ok": True,
        "event": event,
        "repo": str(root),
        "mode": "enforcing" if _is_before_tool(event) else "audit",
    }
    if body.get("_persistmind_hook_self_test"):
        return {
            **base,
            "ok": False,
            "decision": "block",
            "reason": "PersistMind hook self-test block",
            "record_only": True,
        }
    if body.get("_persistmind_invalid_json") and _is_before_tool(event):
        return {
            **base,
            "ok": False,
            "decision": "block",
            "reason": "Codex hook input was not valid JSON",
            "record_only": True,
        }
    if event == "SessionStart":
        from .activation import record_host_attachment

        base["host_activation"] = record_host_attachment(root, body)

    from .hooks import evaluate_fast_hook, write_policy_snapshot

    result = evaluate_fast_hook(root, event, body)
    if event in {"SessionStart", "UserPromptSubmit", "BeforeAgent"}:
        material = "\0".join(
            (
                event,
                str(body.get("session_id") or ""),
                str(body.get("hook_event_id") or ""),
                datetime.now(timezone.utc).isoformat(),
            )
        )
        write_policy_snapshot(
            root,
            revision=hashlib.sha256(material.encode("utf-8")).hexdigest(),
            preflight_ready=False,
            authorization_mode="none",
        )
        result = {
            **result,
            "record_only": True,
            "additional_context": (
                "PersistMind-first context is mandatory. Before repository discovery, "
                "run persistmind --repo . codex preflight --task <current-user-task> "
                "--mode read (or --mode write for edits), use its pack and memory, "
                "and avoid root-wide recursive scans."
            ),
        }
    return {**base, **result}


def _is_before_tool(event: str) -> bool:
    return _alias(event) in {"pretooluse", "beforetool", "before_tool"}


_POLICY_FIELDS = frozenset(
    {
        "tool_name",
        "tool_input",
        "command",
        "path",
        "paths",
        "permission",
        "decision",
        "reason",
        "exit_code",
        "status",
    }
)


class AgentEventJournal:
    def __init__(
        self,
        activity: AgentRuntimeActivityPort,
        context: RepositoryContext,
        *,
        redaction_key: bytes,
        redaction_revision: str = "v1",
    ) -> None:
        if len(redaction_key) < 16:
            raise ValueError("agent event redaction key must contain at least 16 bytes")
        self.activity = activity
        self.context = context
        self.redaction_key = redaction_key
        self.redaction_revision = redaction_revision

    def normalize(
        self,
        host: str,
        event_name: str,
        payload: Mapping[str, Any],
        *,
        session_id: str | None = None,
        parent_event_id: str | None = None,
        host_event_id: str | None = None,
        occurred_at: str | None = None,
    ) -> dict[str, Any]:
        event_type = ALIASES.get(_alias(event_name))
        if event_type is None:
            raise ValueError(f"unsupported agent event: {host}/{event_name}")
        original_bytes = len(
            json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
        )
        redacted = _redact(dict(payload), self.redaction_key)
        bounded = _bounded_payload(redacted, original_bytes=original_bytes)
        digest = hmac.new(
            self.redaction_key,
            json.dumps(bounded, sort_keys=True, separators=(",", ":")).encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        session = session_id or str(payload.get("session_id") or "") or None
        identity = host_event_id or stable_id(
            host,
            event_type.value,
            session,
            parent_event_id,
            digest,
        )
        return {
            "schema_version": EVENT_SCHEMA,
            "event_id": "ae_" + stable_id(EVENT_SCHEMA, identity)[:40],
            "stream_id": stable_id(
                self.context.repository_id,
                self.context.workspace_id,
                session or "unbound",
            ),
            "event_type": event_type.value,
            "host": host.casefold(),
            "repository_id": self.context.repository_id,
            "workspace_id": self.context.workspace_id,
            "source_view_id": self.context.source_view_id,
            "session_id": session,
            "parent_event_id": parent_event_id,
            "payload": bounded,
            "payload_digest": digest,
            "redaction_revision": self.redaction_revision,
            "occurred_at": occurred_at or _now(),
        }

    def append(self, *args: Any, **kwargs: Any) -> Mapping[str, Any]:
        return self.activity.append_agent_event(self.normalize(*args, **kwargs))


class AgentEventProjector:
    """Project the security-minimum event subset to Audit and settle delivery state."""

    def __init__(
        self,
        activity: AgentRuntimeActivityPort,
        audit: AgentRuntimeAuditPort,
        *,
        worker_id: str = "persistmind-agent-event-projector",
    ) -> None:
        self.activity = activity
        self.audit = audit
        self.worker_id = worker_id

    def drain(self, *, limit: int = 100) -> dict[str, Any]:
        claimed = self.activity.claim_agent_events(
            worker_id=self.worker_id,
            limit=max(1, min(int(limit), 1000)),
            lease_ms=30_000,
        )
        projected: list[str] = []
        completed: list[str] = []
        failed: list[str] = []
        for event in claimed:
            event_id = str(event["event_id"])
            try:
                if _requires_security_audit(event):
                    self.audit.append_agent_security_projection(
                        {
                            "audit_id": "audit_" + stable_id("agent-event", event_id)[:32],
                            "correlation_id": event_id,
                            "kind": "agent_security_event",
                            "principal": "agent-runtime",
                            "event_type": event["event_type"],
                            "stream_id": event["stream_id"],
                            "sequence": event["sequence"],
                            "payload_digest": event["payload_digest"],
                            "redaction_revision": event["redaction_revision"],
                            "occurred_at": event["occurred_at"],
                        },
                        idempotency_key=f"agent-security-event:{event_id}",
                    )
                    projected.append(event_id)
                if not self.activity.complete_agent_event(event_id, worker_id=self.worker_id):
                    raise RuntimeError("agent event delivery completion fence rejected")
                completed.append(event_id)
            except Exception as exc:  # noqa: BLE001 - durable retry/dead-letter boundary.
                attempts = int(event.get("attempt_count") or 1)
                dead_letter = attempts >= 5
                retry_at = None
                if not dead_letter:
                    retry_at = (
                        (datetime.now(timezone.utc) + timedelta(seconds=min(300, 2**attempts)))
                        .isoformat()
                        .replace("+00:00", "Z")
                    )
                self.activity.fail_agent_event(
                    event_id,
                    worker_id=self.worker_id,
                    error=str(exc),
                    retry_at=retry_at,
                    dead_letter=dead_letter,
                )
                failed.append(event_id)
        return {
            "ok": not failed,
            "schema_version": "persistmind.agent_event_projection.v1",
            "claimed": len(claimed),
            "projected": projected,
            "completed": completed,
            "failed": failed,
        }


def _requires_security_audit(event: Mapping[str, Any]) -> bool:
    event_type = str(event.get("event_type") or "")
    if event_type in SECURITY_AUDIT_EVENT_TYPES:
        return True
    if event_type != AgentEventType.TOOL_BEFORE.value:
        return False
    payload = event.get("payload")
    return isinstance(payload, Mapping) and str(payload.get("decision") or "") == "block"


def _alias(value: str) -> str:
    return "".join(
        character for character in value.casefold() if character.isalnum() or character == "_"
    )


def _redact(value: Any, key: bytes, path: str = "$") -> Any:
    if isinstance(value, Mapping):
        result: dict[str, Any] = {}
        for raw_key, child in value.items():
            name = str(raw_key)
            if any(token in name.casefold() for token in _SECRET_KEYS):
                result[name] = _redacted_value(child, key, category="secret")
            elif name.casefold().replace("-", "_") in _CONTENT_KEYS:
                result[name] = _redacted_value(child, key, category="content")
            else:
                result[name] = _redact(child, key, f"{path}.{name}")
        return result
    if isinstance(value, (list, tuple)):
        return [_redact(child, key, f"{path}[]") for child in value]
    return value


def _redacted_value(value: Any, key: bytes, *, category: str) -> dict[str, Any]:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return {
        "redacted": True,
        "category": category,
        "bytes": len(raw),
        "keyed_digest": hmac.new(key, raw, hashlib.sha256).hexdigest(),
    }


def _bounded_payload(payload: dict[str, Any], *, original_bytes: int) -> dict[str, Any]:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode(
        "utf-8"
    )
    if original_bytes > MAX_EVENT_BYTES and len(encoded) <= MAX_EVENT_BYTES:
        return {**payload, "truncated": True, "original_bytes": original_bytes}
    if len(encoded) <= MAX_EVENT_BYTES:
        return payload
    original_digest = hashlib.sha256(encoded).hexdigest()
    projected = {key: payload[key] for key in sorted(_POLICY_FIELDS & payload.keys())}
    projected["truncated"] = True
    projected["original_bytes"] = len(encoded)
    projected["original_sha256"] = original_digest
    projected["retained_fields"] = sorted(projected.keys() - {"retained_fields"})
    encoded = json.dumps(projected, sort_keys=True, separators=(",", ":")).encode("utf-8")
    if len(encoded) > MAX_EVENT_BYTES:
        raise ValueError("typed agent event projection exceeds 128 KiB")
    return projected


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


__all__ = [
    "ALIASES",
    "AgentEventJournal",
    "AgentEventProjector",
    "AgentEventType",
    "EVENT_SCHEMA",
    "MAX_EVENT_BYTES",
    "SECURITY_AUDIT_EVENT_TYPES",
]
