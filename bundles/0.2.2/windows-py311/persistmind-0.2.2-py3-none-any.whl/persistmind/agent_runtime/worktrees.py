from __future__ import annotations

import hashlib
import os
import secrets
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Literal

from persistmind.application.agent_runtime_ports import AgentRuntimeTaskPort
from persistmind.branding import resolve_project_state
from persistmind.security.context import require_current_principal
from persistmind.utils import stable_id, utc_now

from .identity import RepositoryContext, repository_context


WorktreeMode = Literal["clean_tracked", "preserve_dirty", "clean_all"]
WORKTREE_SCHEMA = "persistmind.worktree.v1"
_CREDENTIAL_NAMES = frozenset({".env", ".npmrc", ".pypirc", "credentials", "id_rsa", "id_ed25519"})


@dataclass(frozen=True, slots=True)
class WorktreeLease:
    lease_id: str
    task_id: str
    path: Path
    state_root: Path
    pinned_oid: str
    source_view_id: str
    mode: WorktreeMode
    dirty_patch_digest: str
    created_at: str
    expires_at: str
    owner_token: str
    fencing_token: int
    schema_version: str = WORKTREE_SCHEMA


class WorktreeTransaction:
    def __init__(
        self,
        context: RepositoryContext,
        *,
        root: Path | None = None,
        task: AgentRuntimeTaskPort | None = None,
    ) -> None:
        self.context = context
        self.task = task
        base = root or Path(tempfile.gettempdir()) / "persistmind-worktrees"
        self.root = Path(base).resolve() / context.repository_id[:24]

    def prepare(self, task_id: str, *, mode: WorktreeMode = "clean_tracked") -> WorktreeLease:
        if mode not in {"clean_tracked", "preserve_dirty", "clean_all"}:
            raise ValueError(f"unsupported worktree mode: {mode}")
        oid = _git(self.context.repository_root, "rev-parse", "HEAD").strip()
        patch = b""
        if mode == "preserve_dirty":
            patch = subprocess.run(
                ["git", "-C", str(self.context.repository_root), "diff", "--binary", "HEAD", "--"],
                check=True,
                capture_output=True,
            ).stdout
        patch_digest = hashlib.sha256(patch).hexdigest()
        owner_token = secrets.token_urlsafe(32)
        fencing_token = int(datetime.now(timezone.utc).timestamp() * 1_000_000_000)
        lease_id = (
            "wt_" + stable_id(task_id, oid, mode, self.context.source_view_id, owner_token)[:32]
        )
        target = (self.root / lease_id).resolve()
        if not target.is_relative_to(self.root):
            raise ValueError("worktree target escaped configured root")
        if target.exists():
            actual = _git(target, "rev-parse", "HEAD").strip()
            if actual != oid:
                raise RuntimeError("existing worktree lease points at a different commit")
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            subprocess.run(
                [
                    "git",
                    "-C",
                    str(self.context.repository_root),
                    "worktree",
                    "add",
                    "--detach",
                    str(target),
                    oid,
                ],
                check=True,
                capture_output=True,
            )
        _scrub_owned_worktree(target)
        if patch:
            subprocess.run(
                ["git", "-C", str(target), "apply", "--binary", "--whitespace=nowarn", "-"],
                input=patch,
                check=True,
                capture_output=True,
            )
            self._project_untracked(target)
        child_context = repository_context(target)
        expires_at = (
            (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat().replace("+00:00", "Z")
        )
        lease = WorktreeLease(
            lease_id=lease_id,
            task_id=task_id,
            path=target,
            state_root=resolve_project_state(self.context.repository_root),
            pinned_oid=oid,
            source_view_id=child_context.source_view_id,
            mode=mode,
            dirty_patch_digest=patch_digest,
            created_at=utc_now(),
            expires_at=expires_at,
            owner_token=owner_token,
            fencing_token=fencing_token,
        )
        if self.task is not None:
            epoch = int(self.task.runtime_epoch()["epoch"])
            self.task.put_worktree_lease(
                {
                    "lease_id": lease.lease_id,
                    "repository_id": self.context.repository_id,
                    "workspace_id": self.context.workspace_id,
                    "source_view_id": lease.source_view_id,
                    "owner_session_id": task_id,
                    "pinned_oid": lease.pinned_oid,
                    "mode": lease.mode,
                    "state": "active",
                    "runtime_epoch": epoch,
                    "expires_at": lease.expires_at,
                    "metadata": {
                        "path": str(lease.path),
                        "state_root": str(lease.state_root),
                        "dirty_patch_digest": lease.dirty_patch_digest,
                        "owner_token_hash": _token_hash(lease.owner_token),
                        "fencing_token": lease.fencing_token,
                    },
                    "created_at": lease.created_at,
                }
            )
        return lease

    def renew(self, lease: WorktreeLease, *, ttl_seconds: int = 3600) -> WorktreeLease:
        if self.task is None:
            return lease
        expires_at = (
            (
                datetime.now(timezone.utc)
                + timedelta(seconds=max(30, min(int(ttl_seconds), 24 * 60 * 60)))
            )
            .isoformat()
            .replace("+00:00", "Z")
        )
        self.task.renew_worktree_lease(
            lease.lease_id,
            owner_token_hash=_token_hash(lease.owner_token),
            fencing_token=lease.fencing_token,
            expires_at=expires_at,
        )
        return WorktreeLease(
            lease_id=lease.lease_id,
            task_id=lease.task_id,
            path=lease.path,
            state_root=lease.state_root,
            pinned_oid=lease.pinned_oid,
            source_view_id=lease.source_view_id,
            mode=lease.mode,
            dirty_patch_digest=lease.dirty_patch_digest,
            created_at=lease.created_at,
            expires_at=expires_at,
            owner_token=lease.owner_token,
            fencing_token=lease.fencing_token,
        )

    def bind_task(self, task: AgentRuntimeTaskPort) -> "WorktreeTransaction":
        self.task = task
        return self

    def release(self, lease: WorktreeLease, *, force: bool = False) -> dict[str, Any]:
        if not lease.path.resolve().is_relative_to(self.root):
            raise ValueError("worktree lease escaped configured root")
        command = [
            "git",
            "-C",
            str(self.context.repository_root),
            "worktree",
            "remove",
            *(["--force"] if force else []),
            str(lease.path),
        ]
        completed = subprocess.run(command, check=False, capture_output=True, text=True)
        if completed.returncode != 0 and lease.path.exists():
            raise RuntimeError(completed.stderr.strip() or "worktree release failed")
        subprocess.run(
            ["git", "-C", str(self.context.repository_root), "worktree", "prune"],
            check=False,
            capture_output=True,
        )
        if self.task is not None:
            self.task.update_worktree_lease(
                lease.lease_id,
                state="released",
                owner_token_hash=_token_hash(lease.owner_token),
                fencing_token=lease.fencing_token,
            )
        return {
            "ok": True,
            "schema_version": WORKTREE_SCHEMA,
            "lease_id": lease.lease_id,
            "released": True,
        }

    def _project_untracked(self, target: Path) -> None:
        completed = subprocess.run(
            [
                "git",
                "-C",
                str(self.context.repository_root),
                "ls-files",
                "--others",
                "--exclude-standard",
                "-z",
            ],
            check=True,
            capture_output=True,
        )
        for raw in completed.stdout.split(b"\0"):
            if not raw:
                continue
            relative = raw.decode("utf-8").replace("\\", "/")
            source = (self.context.repository_root / relative).resolve(strict=True)
            destination = (target / relative).resolve()
            if not source.is_relative_to(
                self.context.repository_root
            ) or not destination.is_relative_to(target):
                raise ValueError("dirty projection escaped repository scope")
            if source.is_symlink() or not source.is_file():
                continue
            if source.name.casefold() in _CREDENTIAL_NAMES or relative.startswith(
                (".persistmind/", ".git/")
            ):
                continue
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)


class MergeTransaction:
    def __init__(self, context: RepositoryContext) -> None:
        self.context = context

    def integrate(
        self, commit_oid: str, *, strategy: Literal["cherry-pick", "merge"] = "cherry-pick"
    ) -> dict[str, Any]:
        principal = require_current_principal(
            roles=frozenset({"admin"}), action="worktree.parent_merge"
        )
        if principal.auth_source != "os-local" or not principal.permits_repo(
            self.context.repository_root
        ):
            raise PermissionError("parent integration requires the scoped local OS principal")
        verified = _git(
            self.context.repository_root, "rev-parse", f"{commit_oid}^{{commit}}"
        ).strip()
        before = _git(self.context.repository_root, "rev-parse", "HEAD").strip()
        command = ["git", "-C", str(self.context.repository_root)]
        if strategy == "cherry-pick":
            command.extend(["cherry-pick", verified])
        elif strategy == "merge":
            command.extend(["merge", "--no-ff", "--no-edit", verified])
        else:
            raise ValueError(f"unsupported integration strategy: {strategy}")
        completed = subprocess.run(command, check=False, capture_output=True, text=True)
        if completed.returncode != 0:
            abort = "cherry-pick" if strategy == "cherry-pick" else "merge"
            subprocess.run(
                ["git", "-C", str(self.context.repository_root), abort, "--abort"],
                check=False,
                capture_output=True,
            )
            restored = _git(self.context.repository_root, "rev-parse", "HEAD").strip() == before
            if not restored:
                subprocess.run(
                    ["git", "-C", str(self.context.repository_root), "reset", "--merge", before],
                    check=True,
                    capture_output=True,
                )
            for marker_name in ("CHERRY_PICK_HEAD", "MERGE_HEAD", "REBASE_HEAD"):
                marker_value = subprocess.run(
                    [
                        "git",
                        "-C",
                        str(self.context.repository_root),
                        "rev-parse",
                        "--git-path",
                        marker_name,
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                ).stdout.strip()
                marker_path = Path(marker_value)
                if not marker_path.is_absolute():
                    marker_path = self.context.repository_root / marker_path
                if marker_path.exists():
                    raise RuntimeError(
                        "worktree integration rollback left an in-progress Git operation"
                    )
            raise RuntimeError(completed.stderr.strip() or "worktree integration conflict")
        after = _git(self.context.repository_root, "rev-parse", "HEAD").strip()
        return {
            "ok": True,
            "schema_version": "persistmind.merge_transaction.v1",
            "strategy": strategy,
            "commit_oid": verified,
            "before_oid": before,
            "after_oid": after,
            "principal": principal.subject,
        }


def confinement_status() -> dict[str, Any]:
    return {
        "schema_version": "persistmind.host_confinement.v1",
        "platform": os.name,
        "filesystem": "worktree-path-and-command-policy",
        "network": "not-enforced-by-worktree",
        "credentials": "known-untracked-credential-files-excluded",
        "strong_sandbox": False,
    }


def _scrub_owned_worktree(target: Path) -> None:
    """Remove residue from a reusable worktree before any dirty projection."""

    for arguments in (("clean", "-ffd"), ("clean", "-ffdX")):
        completed = subprocess.run(
            ["git", "-C", str(target), *arguments],
            check=False,
            capture_output=True,
            text=True,
        )
        if completed.returncode != 0:
            raise RuntimeError(completed.stderr.strip() or "worktree scrub failed")


def _git(repo: Path, *arguments: str) -> str:
    completed = subprocess.run(
        ["git", "-C", str(repo), *arguments],
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="strict",
    )
    if completed.returncode != 0:
        raise RuntimeError(completed.stderr.strip() or "git worktree command failed")
    return completed.stdout


def _token_hash(value: str) -> str:
    return hashlib.sha256(("persistmind-worktree-owner-v1\0" + value).encode("utf-8")).hexdigest()


__all__ = [
    "MergeTransaction",
    "WORKTREE_SCHEMA",
    "WorktreeLease",
    "WorktreeTransaction",
    "confinement_status",
]
