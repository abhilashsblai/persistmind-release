from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import sys
import time
from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from persistmind.branding import resolve_project_state
from persistmind.storage.hook_read_counter import (
    current_path_read_count,
    record_path_reads,
)

from .contracts import load_runtime_contract
from .events import AgentEventJournal
from .identity import repository_context
from .tool_capability import classify_tool, mcp_input_digest

SNAPSHOT_SCHEMA = "persistmind.hook_policy_snapshot.v1"
SNAPSHOT_MAX_BYTES = 1024 * 1024
SNAPSHOT_MAX_AGE_SECONDS = 3600
_SETTINGS_CACHE: dict[tuple[str, int, int], Any] = {}

def evaluate_fast_hook(repo: Path, event: str, payload: Mapping[str, Any]) -> dict[str, Any]:
    started = time.perf_counter_ns()
    normalized = _normalize_input(event, payload, repo=repo)
    normalization_ms = round((time.perf_counter_ns() - started) / 1_000_000, 3)
    if normalized["canonical_event"] == "session.started":
        record_hook_heartbeat(
            repo,
            agent=str(payload.get("agent") or payload.get("agent_name") or "unknown"),
            session_id=str(payload.get("session_id") or payload.get("transcript_path") or ""),
            host_pid=_heartbeat_host_pid(payload),
        )
    snapshot = read_policy_snapshot(repo)
    if normalized["canonical_event"] == "tool.before" and (
        not normalized["read_only"] or normalized["repository_context_read"]
    ):
        snapshot = _authoritative_snapshot(repo, snapshot)
    decision, enforcement = _decision(normalized, snapshot, repo=repo)
    banner = _governance_banner(enforcement["mode"])
    degraded = _hook_runtime_degraded(repo, normalized)
    result = {
        "ok": decision != "block",
        "event": event,
        "decision": decision,
        "reason": _reason(normalized, snapshot, enforcement["base_decision"]),
        "mode": "enforcing" if normalized["canonical_event"] == "tool.before" else "audit",
        "enforcement_mode": enforcement["mode"],
        **({"would_have_blocked": True} if enforcement["would_have_blocked"] else {}),
        **({"record_only": True} if enforcement["record_only"] else {}),
        **(
            {"additional_context": _reason(normalized, snapshot, enforcement["base_decision"])}
            if decision == "warn"
            else {}
        ),
        "policy_snapshot_revision": snapshot.get("revision"),
        "policy_snapshot_current": bool(snapshot.get("current", False)),
        "task_session_id": snapshot.get("task_session_id"),
        "pack_id": snapshot.get("pack_id"),
        "hook_runtime": "fast-v2",
        "normalization_ms": normalization_ms,
        **({"banner": banner} if banner else {}),
        **({"hook_runtime_degraded": degraded} if degraded else {}),
    }
    if os.environ.get("PERSISTMIND_AGENT_EVENTS", "1") != "0" and not payload.get(
        "_persistmind_hook_self_test"
    ):
        record_successful_hook_run(repo, normalized["canonical_event"])
        _queue_observation(repo, event, payload, normalized, decision)
    return result


def record_hook_heartbeat(
    repo: Path,
    *,
    agent: str,
    session_id: str,
    host_pid: int | None = None,
) -> dict[str, Any]:
    workspace = resolve_project_state(Path(repo).resolve())
    heartbeat = {
        "schema_version": "persistmind.hook_coverage.v1",
        "agent": agent or "unknown",
        "session_id": session_id or None,
        "last_seen": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
        "pid": host_pid if host_pid and host_pid > 0 else os.getppid(),
        "hook_pid": os.getpid(),
    }
    target = workspace / "runtime" / "hook-coverage.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(heartbeat, sort_keys=True, separators=(",", ":")), encoding="utf-8")
    os.replace(temporary, target)
    return heartbeat


def record_successful_hook_run(repo: Path, canonical_event: str) -> dict[str, Any]:
    workspace = resolve_project_state(Path(repo).resolve())
    target = workspace / "runtime" / "hook-coverage.json"
    payload: dict[str, Any] = {}
    try:
        payload = json.loads(target.read_text(encoding="utf-8")) if target.is_file() else {}
    except (OSError, json.JSONDecodeError):
        payload = {}
    payload.setdefault("schema_version", "persistmind.hook_coverage.v1")
    payload["last_successful_hook_run"] = datetime.now(UTC).isoformat().replace(
        "+00:00", "Z"
    )
    if canonical_event == "tool.before":
        payload["last_successful_pretool_run"] = payload["last_successful_hook_run"]
        try:
            payload["pre_tool_use_count"] = int(payload.get("pre_tool_use_count") or 0) + 1
        except (TypeError, ValueError):
            payload["pre_tool_use_count"] = 1
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(payload, sort_keys=True, separators=(",", ":")), encoding="utf-8")
    os.replace(temporary, target)
    return payload


def _heartbeat_host_pid(payload: Mapping[str, Any]) -> int | None:
    for key in ("host_pid", "parent_pid", "ppid"):
        try:
            value = int(payload.get(key) or 0)
        except (TypeError, ValueError):
            continue
        if value > 0:
            return value
    return None


def hook_coverage_status(repo: Path, *, max_age_seconds: int = 3600) -> dict[str, Any]:
    path = resolve_project_state(Path(repo).resolve()) / "runtime" / "hook-coverage.json"
    if not path.is_file():
        return {
            "ok": True,
            "schema_version": "persistmind.hook_coverage_status.v1",
            "covered": False,
            "reason": "no_hook_heartbeat",
            "path": str(path),
        }
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return {
            "ok": False,
            "schema_version": "persistmind.hook_coverage_status.v1",
            "covered": False,
            "reason": "hook_heartbeat_unreadable",
            "error": type(exc).__name__,
            "path": str(path),
        }
    last_seen = _parse_instant(str(payload.get("last_seen") or ""))
    age_seconds = (
        None
        if last_seen is None
        else (datetime.now(UTC) - last_seen).total_seconds()
    )
    pid_alive = _pid_alive(payload.get("pid"))
    recent = age_seconds is not None and age_seconds <= max(1, int(max_age_seconds))
    return {
        "ok": True,
        "schema_version": "persistmind.hook_coverage_status.v1",
        "covered": bool(pid_alive and recent),
        "reason": "covered" if pid_alive and recent else "stale_or_inactive_hook_session",
        "agent": payload.get("agent"),
        "session_id": payload.get("session_id"),
        "pid": payload.get("pid"),
        "pid_alive": pid_alive,
        "last_seen": payload.get("last_seen"),
        "last_successful_hook_run": payload.get("last_successful_hook_run"),
        "last_successful_pretool_run": payload.get("last_successful_pretool_run"),
        "pre_tool_use_count": payload.get("pre_tool_use_count", 0),
        "age_seconds": age_seconds,
        "max_age_seconds": max_age_seconds,
        "path": str(path),
    }


def write_policy_snapshot(
    repo: Path,
    *,
    revision: str,
    preflight_ready: bool,
    allowed_tools: list[str] | None = None,
    denied_tools: list[str] | None = None,
    runtime_epoch: int = 1,
    source_generation: str | None = None,
    write_scope_revision: str | None = None,
    trust_revision: str | None = None,
    task_session_id: str | None = None,
    pack_id: str | None = None,
    plan_id: str | None = None,
    pack_path_count: int | None = None,
    authorization_mode: str = "write",
    max_age_seconds: int = SNAPSHOT_MAX_AGE_SECONDS,
) -> dict[str, Any]:
    normalized_mode = authorization_mode.strip().casefold()
    if normalized_mode not in {"none", "read", "write"}:
        raise ValueError(f"unsupported hook authorization mode: {authorization_mode}")
    tokens = _revision_tokens(
        repo,
        task_session_id=task_session_id,
        pack_id=pack_id,
        plan_id=plan_id,
    )
    source = source_generation or tokens["source_generation"]
    write_scope = write_scope_revision or tokens["write_scope_revision"]
    trust = trust_revision or tokens["trust_revision"]
    document = {
        "schema_version": SNAPSHOT_SCHEMA,
        "revision": revision,
        "preflight_ready": bool(preflight_ready),
        "allowed_tools": sorted(set(allowed_tools or [])),
        "denied_tools": sorted(set(denied_tools or [])),
        "runtime_epoch": max(1, int(runtime_epoch)),
        "created_at": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
        "max_age_seconds": max(1, min(int(max_age_seconds), 3600)),
        "source_generation": source,
        "write_scope_revision": write_scope,
        "trust_revision": trust,
        "task_session_id": task_session_id,
        "pack_id": pack_id,
        "plan_id": plan_id,
        "pack_path_count": max(0, int(pack_path_count)) if pack_path_count else 0,
        "authorization_mode": normalized_mode,
        "authoritative_revision": _revision_digest(source, write_scope, trust),
        "current": True,
    }
    path = _snapshot_path(repo)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(
        json.dumps(document, sort_keys=True, separators=(",", ":")), encoding="utf-8"
    )
    os.replace(temporary, path)
    return document


def read_policy_snapshot(repo: Path) -> dict[str, Any]:
    path = _snapshot_path(repo)
    try:
        raw = path.read_bytes()
    except OSError:
        return {
            "schema_version": SNAPSHOT_SCHEMA,
            "revision": "missing",
            "preflight_ready": False,
            "allowed_tools": [],
            "denied_tools": [],
            "runtime_epoch": 1,
        }
    if len(raw) > SNAPSHOT_MAX_BYTES:
        return {"schema_version": SNAPSHOT_SCHEMA, "revision": "oversize", "preflight_ready": False}
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {"schema_version": SNAPSHOT_SCHEMA, "revision": "invalid", "preflight_ready": False}
    if not isinstance(value, dict) or value.get("schema_version") != SNAPSHOT_SCHEMA:
        return {
            "schema_version": SNAPSHOT_SCHEMA,
            "revision": "unsupported",
            "preflight_ready": False,
        }
    created_at = _parse_instant(str(value.get("created_at") or ""))
    max_age = max(1, min(int(value.get("max_age_seconds") or SNAPSHOT_MAX_AGE_SECONDS), 3600))
    value["expired"] = (
        created_at is None or (datetime.now(UTC) - created_at).total_seconds() > max_age
    )
    value["current"] = not value["expired"]
    if value.get("authorization_mode") not in {"none", "read", "write"}:
        value["authorization_mode"] = "none"
    return value


def authoritative_policy_snapshot(repo: Path) -> dict[str, Any]:
    """Return the same current policy view used by write-capable hook gates."""

    root = Path(repo).resolve()
    return _authoritative_snapshot(root, read_policy_snapshot(root))


def _normalize_input(
    event: str, payload: Mapping[str, Any], *, repo: Path | None = None
) -> dict[str, Any]:
    aliases = {
        "pretooluse": "tool.before",
        "beforetool": "tool.before",
        "posttooluse": "tool.after",
        "aftertool": "tool.after",
        "posttoolusefailure": "tool.failed",
        "sessionstart": "session.started",
        "sessionend": "session.ended",
        "stop": "session.ended",
        "userpromptsubmit": "prompt.received",
        "beforeagent": "agent.before",
        "afteragent": "agent.after",
        "subagentstart": "subagent.started",
        "subagentstop": "subagent.ended",
        "precompact": "context.compaction.before",
        "precompress": "context.compaction.before",
        "postcompact": "context.compaction.after",
    }
    key = "".join(character for character in event.casefold() if character.isalnum())
    canonical = aliases.get(key, "unknown")
    tool = str(payload.get("tool_name") or payload.get("tool") or "")
    raw_tool_input = payload.get("tool_input")
    tool_input: Mapping[str, Any] = raw_tool_input if isinstance(raw_tool_input, dict) else {}
    command = str(tool_input.get("command") or payload.get("command") or "")
    capability = classify_tool(tool, command, tool_input, repo=repo)
    broad_scan = capability.kind == "scan" and capability.scope == "broad"
    read_paths = _read_target_paths(tool, command, tool_input, repo=repo, targets=capability.targets)
    return {
        "canonical_event": canonical,
        "tool": tool,
        "command": command,
        "tool_kind": capability.kind,
        "tool_scope": capability.scope,
        "read_only": capability.read_only,
        "governance_bootstrap": capability.governance_bootstrap,
        "broad_repository_scan": broad_scan,
        "broad_repository_scan_reason": capability.reason,
        "scan_allow_keys": capability.scan_allow_keys,
        "repository_context_read": capability.repository_context_read,
        "read_paths": read_paths,
        "invalid_json": bool(payload.get("_persistmind_invalid_json")),
    }


def _read_only(tool: str, command: str, tool_input: Mapping[str, Any]) -> bool:
    return classify_tool(tool, command, tool_input).read_only


def _governance_bootstrap(tool: str, command: str, tool_input: Mapping[str, Any]) -> bool:
    return classify_tool(tool, command, tool_input).governance_bootstrap


def _broad_repository_scan(
    tool: str,
    command: str,
    tool_input: Mapping[str, Any],
    *,
    repo: Path | None,
) -> bool:
    capability = classify_tool(tool, command, tool_input, repo=repo)
    return capability.kind == "scan" and capability.scope == "broad"


def _repository_context_read(tool: str, command: str, read_only: bool) -> bool:
    del read_only
    return classify_tool(tool, command, {}).repository_context_read


def _is_repository_root(value: object, repo: Path | None) -> bool:
    text = str(value or "").strip()
    if text in {"", ".", "./", ".\\"}:
        return True
    if repo is None:
        return False
    try:
        candidate = Path(text).expanduser()
        if not candidate.is_absolute():
            candidate = repo / candidate
        return candidate.resolve() == repo.resolve()
    except OSError:
        return False


def _read_target_paths(
    tool: str,
    command: str,
    tool_input: Mapping[str, Any],
    *,
    repo: Path | None,
    targets: tuple[str, ...] | None = None,
) -> list[str]:
    raw_values: list[object] = []
    if targets is not None:
        raw_values.extend(targets)
    else:
        for name in ("path", "file_path", "directory", "root", "cwd", "search_path"):
            value = tool_input.get(name)
            if value is None or value == "":
                continue
            if isinstance(value, list):
                raw_values.extend(value)
            else:
                raw_values.append(value)
    root = repo.resolve() if repo is not None else None
    paths: list[str] = []
    for value in raw_values:
        text = str(value or "").strip().strip("'\"")
        if not text:
            continue
        try:
            candidate = Path(text).expanduser()
            if root is not None and not candidate.is_absolute():
                candidate = root / candidate
            resolved = candidate.resolve()
            if root is not None:
                try:
                    paths.append(resolved.relative_to(root).as_posix())
                    continue
                except ValueError:
                    pass
            paths.append(str(resolved))
        except OSError:
            paths.append(text.replace("\\", "/"))
    if not paths and command and classify_tool(tool, command, tool_input, repo=repo).repository_context_read:
        digest = hashlib.sha256(command.encode("utf-8", errors="replace")).hexdigest()[:12]
        paths.append(f"<shell-read:{digest}>")
    if not paths and tool.casefold().startswith("mcp"):
        capability = classify_tool(tool, command, tool_input, repo=repo)
        if capability.repository_context_read:
            paths.append(f"<mcp-read:{mcp_input_digest(tool, tool_input)}>")
    return sorted(set(paths))


def _decision(
    event: Mapping[str, Any], snapshot: Mapping[str, Any], *, repo: Path
) -> tuple[str, dict[str, Any]]:
    if event["canonical_event"] != "tool.before":
        return "allow", _enforcement_record("allow", _enforcement_mode(repo), immutable=False)
    if event["invalid_json"]:
        return "block", _enforcement_record("block", "block", immutable=True)
    if event.get("broad_repository_scan") and not _scan_allowed(event, repo):
        return _apply_enforcement_mode("block", repo, immutable=False)
    tool = str(event["tool"])
    if tool in set(snapshot.get("denied_tools") or []):
        return _apply_enforcement_mode("block", repo, immutable=False)
    if event.get("governance_bootstrap"):
        return "allow", _enforcement_record("allow", _enforcement_mode(repo), immutable=False)
    if event.get("repository_context_read") and not (
        snapshot.get("current") and snapshot.get("preflight_ready")
    ):
        immutable = bool(snapshot.get("authoritative_mismatch"))
        return _apply_enforcement_mode("block", repo, immutable=immutable)
    if event.get("repository_context_read"):
        budget_key = _read_budget_key(snapshot)
        count = record_path_reads(
            repo,
            task_session_id=budget_key,
            paths=[str(path) for path in event.get("read_paths") or []],
        )
        threshold = _scan_threshold(snapshot, repo=repo)
        if count > int(threshold * 1.5):
            return _apply_enforcement_mode("block", repo, immutable=False)
        if count > threshold:
            return "warn", _enforcement_record("block", _enforcement_mode(repo), immutable=False)
    if not event["read_only"] and not snapshot.get("current"):
        immutable = bool(snapshot.get("authoritative_mismatch"))
        return _apply_enforcement_mode("block", repo, immutable=immutable)
    if event["read_only"]:
        return "allow", _enforcement_record("allow", _enforcement_mode(repo), immutable=False)
    if snapshot.get("authorization_mode") != "write":
        return _apply_enforcement_mode("block", repo, immutable=False)
    if tool in set(snapshot.get("allowed_tools") or []) and snapshot.get("preflight_ready"):
        return "allow", _enforcement_record("allow", _enforcement_mode(repo), immutable=False)
    base = "allow" if snapshot.get("preflight_ready") else "block"
    return _apply_enforcement_mode(base, repo, immutable=False)


def _apply_enforcement_mode(
    base_decision: str, repo: Path, *, immutable: bool
) -> tuple[str, dict[str, Any]]:
    mode = "block" if immutable else _enforcement_mode(repo)
    if base_decision != "block":
        return base_decision, _enforcement_record(base_decision, mode, immutable=immutable)
    if mode == "warn":
        return "warn", _enforcement_record(base_decision, mode, immutable=immutable)
    if mode == "audit":
        return "allow", _enforcement_record(base_decision, mode, immutable=immutable, record_only=True)
    if mode == "off":
        return "allow", _enforcement_record(base_decision, mode, immutable=immutable, record_only=True)
    return "block", _enforcement_record(base_decision, mode, immutable=immutable)


def _enforcement_record(
    base_decision: str, mode: str, *, immutable: bool, record_only: bool = False
) -> dict[str, Any]:
    return {
        "base_decision": base_decision,
        "mode": mode,
        "immutable": immutable,
        "record_only": record_only,
        "would_have_blocked": base_decision == "block" and mode in {"warn", "audit", "off"},
    }


def _enforcement_mode(repo: Path) -> str:
    try:
        settings = _cached_settings(repo)
        if settings is None:
            return "block"
        return settings.governance.enforcement_mode
    except Exception:
        return "block"


def _scan_allowed(event: Mapping[str, Any], repo: Path) -> bool:
    try:
        from persistmind.agent_runtime.shell_intent import analyze_shell_command

        settings = _cached_settings(repo)
        if settings is None:
            return False
        allowed = {
            str(item).strip().casefold()
            for item in settings.governance.scan_allow
            if str(item).strip()
        }
        if not allowed:
            return False
        keys = {
            str(item).strip().casefold()
            for item in event.get("scan_allow_keys") or ()
            if str(item).strip()
        }
        command = str(event.get("command") or "")
        if keys:
            return bool(keys & allowed)
        if command:
            analysis = analyze_shell_command(command, repo=repo)
            keys.update(intent.executable for intent in analysis.intents if intent.enumerates_repo)
        return bool(keys) and keys <= allowed
    except Exception:
        return False


def _reason(event: Mapping[str, Any], snapshot: Mapping[str, Any], decision: str) -> str:
    if decision != "block":
        return "fast policy snapshot allowed the event"
    if event["invalid_json"]:
        return "hook input was not valid JSON"
    if event.get("broad_repository_scan"):
        if event.get("broad_repository_scan_reason"):
            return str(event["broad_repository_scan_reason"])
        return (
            "broad repository scanning is prohibited; request PersistMind context "
            "with codex preflight, pack, search, memory recall, or impact, then read "
            "only the smallest relevant paths"
        )
    if str(event["tool"]) in set(snapshot.get("denied_tools") or []):
        return "tool is denied by the current policy snapshot"
    if event.get("repository_context_read") and not snapshot.get("preflight_ready"):
        return (
            "repository reads require fresh PersistMind-first context; run codex "
            "preflight for the current task and use its pack, memory, search, and "
            "impact results before reading targeted files"
        )
    if event.get("repository_context_read") and snapshot.get("task_session_id"):
        return (
            "cumulative repository reads exceed the active pack scope; re-consult "
            "PersistMind pack or impact before continuing"
        )
    if snapshot.get("expired"):
        return "write-capable tool requires an unexpired policy snapshot"
    if snapshot.get("authorization_mode") != "write":
        return "write-capable tool requires a current write-mode preflight policy snapshot"
    if snapshot.get("authoritative_mismatch"):
        return (
            "preflight policy snapshot requires current source, write-scope, "
            "and trust revisions for write-capable tools"
        )
    return "write-capable tool requires a current preflight policy snapshot"


def _scan_threshold(snapshot: Mapping[str, Any], *, repo: Path | None = None) -> int:
    try:
        pack_path_count = int(snapshot.get("pack_path_count") or 0)
    except (TypeError, ValueError):
        pack_path_count = 0
    floor = 25
    multiplier = 3
    if repo is not None:
        try:
            settings = _cached_settings(repo)
            if settings is None:
                return max(floor, pack_path_count * multiplier)
            governance = settings.governance
            floor = int(getattr(governance, "read_budget_floor", floor))
            multiplier = int(getattr(governance, "read_budget_multiplier", multiplier))
        except Exception:
            pass
    return max(floor, pack_path_count * multiplier)


def _cached_settings(repo: Path) -> Any | None:
    config = repo / "persistmind.toml"
    if not config.is_file():
        return None
    stat = config.stat()
    key = (str(repo.resolve()), int(stat.st_mtime_ns), int(stat.st_size))
    cached = _SETTINGS_CACHE.get(key)
    if cached is not None:
        return cached
    from persistmind.config import load_settings

    settings = load_settings(repo)
    _SETTINGS_CACHE.clear()
    _SETTINGS_CACHE[key] = settings
    return settings


def _read_budget_key(snapshot: Mapping[str, Any]) -> str:
    revision = str(snapshot.get("revision") or "missing")
    task_session_id = str(snapshot.get("task_session_id") or "") or "unbound"
    return f"{task_session_id}:{revision}"


def _governance_banner(mode: str) -> str:
    if mode == "off":
        return (
            "PersistMind governance enforcement is OFF for this repository; "
            "policy blocks are being recorded only and will not stop tool use."
        )
    if mode == "audit":
        return (
            "PersistMind governance enforcement is in AUDIT mode; policy blocks "
            "are recorded without stopping tool use."
        )
    return ""


def _hook_runtime_degraded(repo: Path, event: Mapping[str, Any]) -> dict[str, Any] | None:
    canonical = str(event.get("canonical_event") or "")
    if canonical not in {"tool.before", "prompt.received", "agent.before", "session.ended"}:
        return None
    status = hook_coverage_status(repo)
    if not status.get("covered"):
        return {
            "reason": str(status.get("reason") or "hook_coverage_not_current"),
            "covered": False,
            "age_seconds": status.get("age_seconds"),
        }
    last_seen = _parse_instant(str(status.get("last_seen") or ""))
    last_pretool = _parse_instant(str(status.get("last_successful_pretool_run") or ""))
    try:
        pre_tool_count = int(status.get("pre_tool_use_count") or 0)
    except (TypeError, ValueError):
        pre_tool_count = 0
    if canonical == "tool.before":
        return None
    if last_seen is None:
        return {"reason": "hook_heartbeat_missing_timestamp", "covered": True}
    age_seconds = (datetime.now(UTC) - last_seen).total_seconds()
    if last_pretool is None and pre_tool_count == 0 and age_seconds > 60:
        return {
            "reason": "no_successful_pretool_hook_after_session_start",
            "covered": True,
            "age_seconds": age_seconds,
            "pre_tool_use_count": pre_tool_count,
        }
    if last_pretool is not None and last_pretool < last_seen and age_seconds > 60:
        return {
            "reason": "successful_pretool_run_older_than_current_session",
            "covered": True,
            "age_seconds": age_seconds,
            "last_successful_pretool_run": status.get("last_successful_pretool_run"),
        }
    return None


def _authoritative_snapshot(repo: Path, snapshot: Mapping[str, Any]) -> dict[str, Any]:
    value = dict(snapshot)
    tokens = _revision_tokens(
        repo,
        task_session_id=str(value.get("task_session_id") or "") or None,
        pack_id=str(value.get("pack_id") or "") or None,
        plan_id=str(value.get("plan_id") or "") or None,
    )
    current = _revision_digest(
        tokens["source_generation"],
        tokens["write_scope_revision"],
        tokens["trust_revision"],
    )
    expected = str(value.get("authoritative_revision") or "")
    mismatch = bool(expected) and expected != current
    value["authoritative_mismatch"] = mismatch
    value["current"] = bool(value.get("current")) and not mismatch
    return value


def _revision_tokens(
    repo: Path,
    *,
    task_session_id: str | None = None,
    pack_id: str | None = None,
    plan_id: str | None = None,
) -> dict[str, str]:
    workspace = resolve_project_state(Path(repo).resolve())
    source_db = _active_catalog_store(
        workspace,
        "source_manifest",
        "stores/source/default/manifest.db",
    )
    task_db = _active_catalog_store(
        workspace,
        "task_state",
        "stores/task/task-state.db",
    )
    policy_db = _active_catalog_store(
        workspace,
        "policy",
        "stores/knowledge/policy.db",
    )
    return {
        "source_generation": _source_generation_revision(source_db),
        "write_scope_revision": _write_scope_revision(
            task_db,
            task_session_id=task_session_id,
            expected_pack_id=pack_id,
            expected_plan_id=plan_id,
        ),
        "trust_revision": _domain_revision(policy_db),
    }


def _active_catalog_store(workspace: Path, role: str, legacy_location: str) -> Path:
    """Resolve an authoritative writable role from the committed catalog pointer."""

    current_path = workspace / "catalog" / "current.json"
    if not current_path.is_file():
        return workspace / Path(legacy_location)
    invalid = workspace / "runtime" / f"invalid-catalog-{role}.db"
    try:
        pointer_raw = current_path.read_bytes()
        if len(pointer_raw) > 64 * 1024:
            return invalid
        pointer = json.loads(pointer_raw.decode("utf-8"))
        generation = pointer.get("generation") if isinstance(pointer, dict) else None
        expected_hash = (
            str(pointer.get("manifest_sha256") or "") if isinstance(pointer, dict) else ""
        )
        if (
            not isinstance(generation, int)
            or generation < 1
            or not expected_hash
            or pointer.get("schema_version") != "persistmind.catalog_pointer.v1"
        ):
            return invalid
        manifest_path = workspace / "catalog" / "generations" / f"{generation:020d}.json"
        manifest_raw = manifest_path.read_bytes()
        if len(manifest_raw) > 4 * 1024 * 1024:
            return invalid
        manifest = json.loads(manifest_raw.decode("utf-8"))
        if not isinstance(manifest, dict):
            return invalid
        canonical = json.dumps(
            manifest,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        ).encode("utf-8")
        if hashlib.sha256(canonical).hexdigest() != expected_hash:
            return invalid
        matches = [
            item
            for item in manifest.get("stores", [])
            if isinstance(item, dict)
            and item.get("store_role") == role
            and item.get("state") == "active"
            and not item.get("read_only")
            and item.get("shard_key", "default") == "default"
        ]
        if len(matches) != 1:
            return invalid
        location = str(matches[0].get("location") or "")
        if (
            not location
            or "\\" in location
            or ":" in location
            or location.startswith("/")
            or any(part in {"", ".", ".."} for part in location.split("/"))
        ):
            return invalid
        resolved = (workspace / Path(*location.split("/"))).resolve()
        if not resolved.is_relative_to(workspace.resolve()):
            return invalid
        return resolved
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError, TypeError):
        return invalid


def _source_generation_revision(path: Path) -> str:
    row = _read_row(
        path,
        "SELECT current_generation_id FROM source_views ORDER BY updated_at DESC LIMIT 1",
    )
    return str(row[0]) if row else _file_revision(path)


def _write_scope_revision(
    path: Path,
    *,
    task_session_id: str | None,
    expected_pack_id: str | None,
    expected_plan_id: str | None,
) -> str:
    # Legacy snapshots did not carry a task binding. Retain their fail-closed
    # image token until the next authoritative preflight publishes a bound one.
    if not task_session_id:
        return _file_revision(path)
    workflow = _read_row(
        path,
        "SELECT pack_id,plan_id FROM task_workflow_snapshots WHERE task_session_id=?",
        (task_session_id,),
    )
    live_pack = str(workflow[0] or "") if workflow else ""
    live_plan = str(workflow[1] or "") if workflow else ""
    session = _read_row(
        path,
        "SELECT payload_json FROM task_sessions WHERE task_session_id=?",
        (task_session_id,),
    )
    if not live_pack and session:
        try:
            payload = json.loads(str(session[0] or "{}"))
        except json.JSONDecodeError:
            payload = {}
        if isinstance(payload, dict):
            live_pack = str(payload.get("pack_id") or "")
    if expected_plan_id and not live_plan:
        latest_plan = _read_row(
            path,
            "SELECT plan_id FROM task_plans WHERE task_session_id=? "
            "ORDER BY CASE WHEN status='active' THEN 0 ELSE 1 END,"
            "updated_at DESC,plan_id DESC LIMIT 1",
            (task_session_id,),
        )
        live_plan = str(latest_plan[0] or "") if latest_plan else ""
    live_pack = live_pack or "missing"
    if expected_plan_id:
        live_plan = live_plan or "missing"
        plan = _read_row(
            path,
            "SELECT status,current_revision FROM task_plans WHERE plan_id=? AND task_session_id=?",
            (live_plan, task_session_id),
        )
        plan_status = str(plan[0] or "") if plan else "missing"
        plan_revision = int(plan[1]) if plan else 0
    else:
        # A write preflight normally precedes plan creation. Until a concrete
        # plan is rebound into the snapshot, authorization is deliberately
        # scoped to the Task session and pack; creating the first plan and
        # recording verification linkage must not masquerade as scope drift.
        live_plan = "unbound"
        plan_status = "unbound"
        plan_revision = 0
    material = {
        "task_session_id": task_session_id,
        "expected_pack_id": expected_pack_id or "",
        "expected_plan_id": expected_plan_id or "",
        "live_pack_id": live_pack,
        "live_plan_id": live_plan,
        "plan_status": plan_status,
        "plan_revision": plan_revision,
    }
    return hashlib.sha256(
        json.dumps(material, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def _domain_revision(path: Path) -> str:
    row = _read_row(path, "SELECT revision FROM domain_metadata WHERE singleton=1")
    return str(row[0]) if row else _file_revision(path)


def _read_row(path: Path, query: str, parameters: tuple[Any, ...] = ()) -> tuple[Any, ...] | None:
    if not path.is_file():
        return None
    connection: sqlite3.Connection | None = None
    try:
        connection = sqlite3.connect(
            f"file:{path.as_posix()}?mode=ro",
            uri=True,
            timeout=0.1,
        )
        row = connection.execute(query, parameters).fetchone()
        return tuple(row) if row is not None else None
    except sqlite3.Error:
        return None
    finally:
        if connection is not None:
            connection.close()


def _file_revision(path: Path) -> str:
    revisions = []
    for candidate in (path, Path(f"{path}-wal")):
        try:
            stat = candidate.stat()
        except OSError:
            continue
        revisions.append(f"{candidate.name}:{stat.st_size}:{stat.st_mtime_ns}")
    if not revisions:
        return "absent"
    return hashlib.sha256("\0".join(revisions).encode("utf-8")).hexdigest()


def _revision_digest(source: str, write_scope: str, trust: str) -> str:
    return hashlib.sha256(f"{source}\0{write_scope}\0{trust}".encode()).hexdigest()


def _parse_instant(value: str) -> datetime | None:
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if result.tzinfo is None:
        result = result.replace(tzinfo=UTC)
    return result.astimezone(UTC)


def _pid_alive(value: object) -> bool:
    try:
        pid = int(value)
    except (TypeError, ValueError):
        return False
    if pid <= 0:
        return False
    if sys.platform == "win32":
        return _pid_alive_windows(pid)
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False


def _pid_alive_windows(pid: int) -> bool:
    # os.kill(pid, 0) is not a valid liveness probe on Windows: signal 0 isn't
    # supported by TerminateProcess-based os.kill for a PID other than the
    # caller's own, and raises OSError (WinError 87) regardless of whether the
    # target process is actually alive.
    import ctypes

    process_query_limited_information = 0x1000
    still_active = 259
    kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
    handle = kernel32.OpenProcess(process_query_limited_information, False, pid)
    if not handle:
        return False
    try:
        exit_code = ctypes.c_ulong()
        if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
            return False
        return exit_code.value == still_active
    finally:
        kernel32.CloseHandle(handle)


def _queue_observation(
    repo: Path,
    event: str,
    payload: Mapping[str, Any],
    normalized: Mapping[str, Any],
    decision: str,
) -> None:
    workspace = resolve_project_state(Path(repo).resolve())
    if not (workspace / "catalog" / "current.json").is_file():
        return
    try:
        command = str(normalized.get("command") or "")
        record = {
            "schema_version": "persistmind.hook_observation_queue.v1",
            "event": event,
            "session_id": str(payload.get("session_id") or "") or None,
            "host_event_id": str(payload.get("hook_event_id") or "") or None,
            "occurred_at": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
            "payload": {
                "tool_name": str(normalized.get("tool") or "")[:256],
                "command_digest": hashlib.sha256(command.encode("utf-8")).hexdigest(),
                "command_bytes": len(command.encode("utf-8")),
                "read_only": bool(normalized.get("read_only")),
                "broad_repository_scan": bool(normalized.get("broad_repository_scan")),
                "scan_allow_applied": bool(
                    normalized.get("broad_repository_scan") and _scan_allowed(normalized, repo)
                ),
                "repository_context_read": bool(normalized.get("repository_context_read")),
                "decision": decision,
                "invalid_json": bool(normalized.get("invalid_json")),
            },
        }
        raw = (json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
        if len(raw) > 16 * 1024:
            return
        queue = workspace / "runtime" / "hook-observations"
        queue.mkdir(parents=True, exist_ok=True)
        path = queue / f"{os.getpid()}.jsonl"
        descriptor = os.open(path, os.O_APPEND | os.O_CREAT | os.O_WRONLY, 0o600)
        try:
            os.write(descriptor, raw)
        finally:
            os.close(descriptor)
    except Exception:
        # Hooks never fail because observation persistence is unavailable.
        return


def drain_hook_observations(
    repo: Path, *, limit: int = 1000, ports: Any | None = None
) -> dict[str, Any]:
    """Move bounded hook spool records into Activity outside the gating process."""

    root = Path(repo).resolve()
    workspace = resolve_project_state(root)
    queue = workspace / "runtime" / "hook-observations"
    if not queue.is_dir():
        return {
            "ok": True,
            "schema_version": "persistmind.hook_observation_drain.v1",
            "drained": 0,
            "failed": 0,
        }
    from persistmind.storage.agent_runtime_ports import AgentRuntimePorts

    context = repository_context(root)
    key = hashlib.sha256(
        (context.repository_id + os.environ.get("USERNAME", "local")).encode("utf-8")
    ).digest()
    drained = 0
    failed = 0
    owned_ports = ports is None
    active_ports = ports or AgentRuntimePorts(root)
    try:
        journal = AgentEventJournal(active_ports.activity, context, redaction_key=key)
        for path in sorted(queue.glob("*.jsonl")):
            if drained >= limit:
                break
            processing = path.with_suffix(f".{os.getpid()}.processing")
            try:
                os.replace(path, processing)
            except OSError:
                continue
            retry: list[bytes] = []
            try:
                for raw in processing.read_bytes().splitlines():
                    if drained >= limit:
                        retry.append(raw)
                        continue
                    try:
                        item = json.loads(raw.decode("utf-8"))
                        journal.append(
                            "hook",
                            str(item["event"]),
                            dict(item["payload"]),
                            session_id=item.get("session_id"),
                            host_event_id=item.get("host_event_id"),
                            occurred_at=item.get("occurred_at"),
                        )
                        drained += 1
                    except Exception:
                        failed += 1
                        retry.append(raw)
            finally:
                processing.unlink(missing_ok=True)
            if retry:
                retry_path = queue / f"retry-{os.getpid()}-{time.time_ns()}.jsonl"
                retry_path.write_bytes(b"\n".join(retry) + b"\n")
    finally:
        if owned_ports:
            active_ports.close()
    return {
        "ok": failed == 0,
        "schema_version": "persistmind.hook_observation_drain.v1",
        "drained": drained,
        "failed": failed,
    }


def _snapshot_path(repo: Path) -> Path:
    return resolve_project_state(Path(repo).resolve()) / "runtime" / "policy-snapshot.json"


def hook_budget() -> Mapping[str, Any]:
    return load_runtime_contract()["performance_budgets"]


__all__ = [
    "SNAPSHOT_SCHEMA",
    "current_path_read_count",
    "drain_hook_observations",
    "evaluate_fast_hook",
    "hook_budget",
    "hook_coverage_status",
    "read_policy_snapshot",
    "record_hook_heartbeat",
    "record_successful_hook_run",
    "write_policy_snapshot",
]
