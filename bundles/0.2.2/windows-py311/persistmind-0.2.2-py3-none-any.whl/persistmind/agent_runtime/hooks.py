from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from persistmind.branding import resolve_project_state

from .contracts import load_runtime_contract
from .events import AgentEventJournal
from .identity import repository_context


SNAPSHOT_SCHEMA = "persistmind.hook_policy_snapshot.v1"
SNAPSHOT_MAX_BYTES = 1024 * 1024
SNAPSHOT_MAX_AGE_SECONDS = 3600

_BROAD_SHELL_SCAN = re.compile(
    r"""(?ix)
    (?:
        \brg(?:\.exe)?\s+--files\b|
        \bgit\s+ls-files\b|
        \bget-childitem\b[^\r\n]*\s-recurse\b|
        (?:^|[;&|]\s*)find(?:\.exe)?\s+\.\s|
        (?:^|[;&|]\s*)tree(?:\.com|\.exe)?(?:\s|$)|
        (?:^|[;&|]\s*)(?:ls|dir)\b[^\r\n]*(?:\s-R\b|\s/s\b)|
        \bgrep\b[^\r\n]*\s-(?:[^\s]*r[^\s]*|[^\s]*R[^\s]*)\b[^\r\n]*\s\.\s*(?:$|[;&|])
    )
    """
)

_NON_REPOSITORY_SHELL_READ = re.compile(
    r"""(?ix)
    ^\s*(?:
        get-(?:command|location|process|variable|nettcpconnection|netudpendpoint)|
        test-netconnection|netstat(?:\.exe)?|tasklist(?:\.exe)?
    )\b
    """
)


def evaluate_fast_hook(repo: Path, event: str, payload: Mapping[str, Any]) -> dict[str, Any]:
    started = time.perf_counter_ns()
    normalized = _normalize_input(event, payload, repo=repo)
    snapshot = read_policy_snapshot(repo)
    if normalized["canonical_event"] == "tool.before" and (
        not normalized["read_only"] or normalized["repository_context_read"]
    ):
        snapshot = _authoritative_snapshot(repo, snapshot)
    decision = _decision(normalized, snapshot)
    result = {
        "ok": decision != "block",
        "event": event,
        "decision": decision,
        "reason": _reason(normalized, snapshot, decision),
        "mode": "enforcing" if normalized["canonical_event"] == "tool.before" else "audit",
        "policy_snapshot_revision": snapshot.get("revision"),
        "policy_snapshot_current": bool(snapshot.get("current", False)),
        "task_session_id": snapshot.get("task_session_id"),
        "pack_id": snapshot.get("pack_id"),
        "hook_runtime": "fast-v2",
        "normalization_ms": round((time.perf_counter_ns() - started) / 1_000_000, 3),
    }
    if os.environ.get("PERSISTMIND_AGENT_EVENTS", "1") != "0" and not payload.get(
        "_persistmind_hook_self_test"
    ):
        _queue_observation(repo, event, payload, normalized, decision)
    return result


def write_policy_snapshot(
    repo: Path,
    *,
    revision: str,
    preflight_ready: bool,
    allowed_tools: list[str] | None = None,
    denied_tools: list[str] | None = None,
    runtime_epoch: int = 1,
    source_generation: str | None = None,
    write_scope_revision: str | None = None,
    trust_revision: str | None = None,
    task_session_id: str | None = None,
    pack_id: str | None = None,
    plan_id: str | None = None,
    authorization_mode: str = "write",
    max_age_seconds: int = SNAPSHOT_MAX_AGE_SECONDS,
) -> dict[str, Any]:
    normalized_mode = authorization_mode.strip().casefold()
    if normalized_mode not in {"none", "read", "write"}:
        raise ValueError(f"unsupported hook authorization mode: {authorization_mode}")
    tokens = _revision_tokens(
        repo,
        task_session_id=task_session_id,
        pack_id=pack_id,
        plan_id=plan_id,
    )
    source = source_generation or tokens["source_generation"]
    write_scope = write_scope_revision or tokens["write_scope_revision"]
    trust = trust_revision or tokens["trust_revision"]
    document = {
        "schema_version": SNAPSHOT_SCHEMA,
        "revision": revision,
        "preflight_ready": bool(preflight_ready),
        "allowed_tools": sorted(set(allowed_tools or [])),
        "denied_tools": sorted(set(denied_tools or [])),
        "runtime_epoch": max(1, int(runtime_epoch)),
        "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "max_age_seconds": max(1, min(int(max_age_seconds), 3600)),
        "source_generation": source,
        "write_scope_revision": write_scope,
        "trust_revision": trust,
        "task_session_id": task_session_id,
        "pack_id": pack_id,
        "plan_id": plan_id,
        "authorization_mode": normalized_mode,
        "authoritative_revision": _revision_digest(source, write_scope, trust),
        "current": True,
    }
    path = _snapshot_path(repo)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(
        json.dumps(document, sort_keys=True, separators=(",", ":")), encoding="utf-8"
    )
    os.replace(temporary, path)
    return document


def read_policy_snapshot(repo: Path) -> dict[str, Any]:
    path = _snapshot_path(repo)
    try:
        raw = path.read_bytes()
    except OSError:
        return {
            "schema_version": SNAPSHOT_SCHEMA,
            "revision": "missing",
            "preflight_ready": False,
            "allowed_tools": [],
            "denied_tools": [],
            "runtime_epoch": 1,
        }
    if len(raw) > SNAPSHOT_MAX_BYTES:
        return {"schema_version": SNAPSHOT_SCHEMA, "revision": "oversize", "preflight_ready": False}
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {"schema_version": SNAPSHOT_SCHEMA, "revision": "invalid", "preflight_ready": False}
    if not isinstance(value, dict) or value.get("schema_version") != SNAPSHOT_SCHEMA:
        return {
            "schema_version": SNAPSHOT_SCHEMA,
            "revision": "unsupported",
            "preflight_ready": False,
        }
    created_at = _parse_instant(str(value.get("created_at") or ""))
    max_age = max(1, min(int(value.get("max_age_seconds") or SNAPSHOT_MAX_AGE_SECONDS), 3600))
    value["expired"] = (
        created_at is None or (datetime.now(timezone.utc) - created_at).total_seconds() > max_age
    )
    value["current"] = not value["expired"]
    if value.get("authorization_mode") not in {"none", "read", "write"}:
        value["authorization_mode"] = "none"
    return value


def authoritative_policy_snapshot(repo: Path) -> dict[str, Any]:
    """Return the same current policy view used by write-capable hook gates."""

    root = Path(repo).resolve()
    return _authoritative_snapshot(root, read_policy_snapshot(root))


def _normalize_input(
    event: str, payload: Mapping[str, Any], *, repo: Path | None = None
) -> dict[str, Any]:
    aliases = {
        "pretooluse": "tool.before",
        "beforetool": "tool.before",
        "posttooluse": "tool.after",
        "aftertool": "tool.after",
        "posttoolusefailure": "tool.failed",
        "sessionstart": "session.started",
        "sessionend": "session.ended",
        "stop": "session.ended",
        "userpromptsubmit": "prompt.received",
        "beforeagent": "agent.before",
        "afteragent": "agent.after",
        "subagentstart": "subagent.started",
        "subagentstop": "subagent.ended",
        "precompact": "context.compaction.before",
        "precompress": "context.compaction.before",
        "postcompact": "context.compaction.after",
    }
    key = "".join(character for character in event.casefold() if character.isalnum())
    canonical = aliases.get(key, "unknown")
    tool = str(payload.get("tool_name") or payload.get("tool") or "")
    raw_tool_input = payload.get("tool_input")
    tool_input: Mapping[str, Any] = raw_tool_input if isinstance(raw_tool_input, dict) else {}
    command = str(tool_input.get("command") or payload.get("command") or "")
    read_only = _read_only(tool, command, tool_input)
    governance_bootstrap = _governance_bootstrap(tool, command, tool_input)
    broad_scan = _broad_repository_scan(tool, command, tool_input, repo=repo)
    repository_context_read = _repository_context_read(tool, command, read_only)
    return {
        "canonical_event": canonical,
        "tool": tool,
        "command": command,
        "read_only": read_only,
        "governance_bootstrap": governance_bootstrap,
        "broad_repository_scan": broad_scan,
        "repository_context_read": repository_context_read,
        "invalid_json": bool(payload.get("_persistmind_invalid_json")),
    }


def _read_only(tool: str, command: str, tool_input: Mapping[str, Any]) -> bool:
    from persistmind.codex import infer_hook_read_only

    normalized = "".join(character for character in tool.casefold() if character.isalnum())
    if normalized in {
        "read",
        "view",
        "glob",
        "grep",
        "search",
        "find",
        "list",
        "ls",
        "websearch",
        "webfetch",
    }:
        return True
    return infer_hook_read_only(
        {
            "tool_name": tool,
            "tool_input": {**dict(tool_input), "command": command},
        }
    )


def _governance_bootstrap(tool: str, command: str, tool_input: Mapping[str, Any]) -> bool:
    from persistmind.codex import infer_hook_governance_bootstrap

    return infer_hook_governance_bootstrap(
        {
            "tool_name": tool,
            "tool_input": {**dict(tool_input), "command": command},
        }
    )


def _broad_repository_scan(
    tool: str,
    command: str,
    tool_input: Mapping[str, Any],
    *,
    repo: Path | None,
) -> bool:
    normalized = "".join(character for character in tool.casefold() if character.isalnum())
    if any(name in normalized for name in ("bash", "shell", "terminal")):
        return bool(_BROAD_SHELL_SCAN.search(command))
    if normalized not in {"glob", "grep", "find", "list", "ls"}:
        return False
    raw_path = next(
        (
            tool_input.get(name)
            for name in ("path", "directory", "root", "cwd", "search_path")
            if tool_input.get(name) not in {None, ""}
        ),
        None,
    )
    if raw_path is None:
        return True
    if isinstance(raw_path, list):
        return not raw_path or any(_is_repository_root(value, repo) for value in raw_path)
    return _is_repository_root(raw_path, repo)


def _repository_context_read(tool: str, command: str, read_only: bool) -> bool:
    normalized = "".join(character for character in tool.casefold() if character.isalnum())
    if normalized in {"read", "view", "glob", "grep", "search", "find", "list", "ls"}:
        return True
    if not read_only or not any(name in normalized for name in ("bash", "shell", "terminal")):
        return False
    if _NON_REPOSITORY_SHELL_READ.search(command):
        return False
    try:
        from persistmind.codex import (
            _safe_ctx_governance_command,
            _safe_ctx_read_only_command,
        )

        return not (_safe_ctx_governance_command(command) or _safe_ctx_read_only_command(command))
    except Exception:
        return True


def _is_repository_root(value: object, repo: Path | None) -> bool:
    text = str(value or "").strip()
    if text in {"", ".", "./", ".\\"}:
        return True
    if repo is None:
        return False
    try:
        candidate = Path(text).expanduser()
        if not candidate.is_absolute():
            candidate = repo / candidate
        return candidate.resolve() == repo.resolve()
    except OSError:
        return False


def _decision(event: Mapping[str, Any], snapshot: Mapping[str, Any]) -> str:
    if event["canonical_event"] != "tool.before":
        return "allow"
    if event["invalid_json"]:
        return "block"
    if event.get("broad_repository_scan"):
        return "block"
    tool = str(event["tool"])
    if tool in set(snapshot.get("denied_tools") or []):
        return "block"
    if event.get("governance_bootstrap"):
        return "allow"
    if event.get("repository_context_read") and not (
        snapshot.get("current") and snapshot.get("preflight_ready")
    ):
        return "block"
    if not event["read_only"] and not snapshot.get("current"):
        return "block"
    if event["read_only"]:
        return "allow"
    if snapshot.get("authorization_mode") != "write":
        return "block"
    if tool in set(snapshot.get("allowed_tools") or []) and snapshot.get("preflight_ready"):
        return "allow"
    return "allow" if snapshot.get("preflight_ready") else "block"


def _reason(event: Mapping[str, Any], snapshot: Mapping[str, Any], decision: str) -> str:
    if decision != "block":
        return "fast policy snapshot allowed the event"
    if event["invalid_json"]:
        return "hook input was not valid JSON"
    if event.get("broad_repository_scan"):
        return (
            "broad repository scanning is prohibited; request PersistMind context "
            "with codex preflight, pack, search, memory recall, or impact, then read "
            "only the smallest relevant paths"
        )
    if event.get("repository_context_read") and not snapshot.get("preflight_ready"):
        return (
            "repository reads require fresh PersistMind-first context; run codex "
            "preflight for the current task and use its pack, memory, search, and "
            "impact results before reading targeted files"
        )
    if str(event["tool"]) in set(snapshot.get("denied_tools") or []):
        return "tool is denied by the current policy snapshot"
    if snapshot.get("expired"):
        return "write-capable tool requires an unexpired policy snapshot"
    if snapshot.get("authorization_mode") != "write":
        return "write-capable tool requires a current write-mode preflight policy snapshot"
    if snapshot.get("authoritative_mismatch"):
        return (
            "preflight policy snapshot requires current source, write-scope, "
            "and trust revisions for write-capable tools"
        )
    return "write-capable tool requires a current preflight policy snapshot"


def _authoritative_snapshot(repo: Path, snapshot: Mapping[str, Any]) -> dict[str, Any]:
    value = dict(snapshot)
    tokens = _revision_tokens(
        repo,
        task_session_id=str(value.get("task_session_id") or "") or None,
        pack_id=str(value.get("pack_id") or "") or None,
        plan_id=str(value.get("plan_id") or "") or None,
    )
    current = _revision_digest(
        tokens["source_generation"],
        tokens["write_scope_revision"],
        tokens["trust_revision"],
    )
    mismatch = str(value.get("authoritative_revision") or "") != current
    value["authoritative_mismatch"] = mismatch
    value["current"] = bool(value.get("current")) and not mismatch
    return value


def _revision_tokens(
    repo: Path,
    *,
    task_session_id: str | None = None,
    pack_id: str | None = None,
    plan_id: str | None = None,
) -> dict[str, str]:
    workspace = resolve_project_state(Path(repo).resolve())
    source_db = _active_catalog_store(
        workspace,
        "source_manifest",
        "stores/source/default/manifest.db",
    )
    task_db = _active_catalog_store(
        workspace,
        "task_state",
        "stores/task/task-state.db",
    )
    policy_db = _active_catalog_store(
        workspace,
        "policy",
        "stores/knowledge/policy.db",
    )
    return {
        "source_generation": _source_generation_revision(source_db),
        "write_scope_revision": _write_scope_revision(
            task_db,
            task_session_id=task_session_id,
            expected_pack_id=pack_id,
            expected_plan_id=plan_id,
        ),
        "trust_revision": _domain_revision(policy_db),
    }


def _active_catalog_store(workspace: Path, role: str, legacy_location: str) -> Path:
    """Resolve an authoritative writable role from the committed catalog pointer."""

    current_path = workspace / "catalog" / "current.json"
    if not current_path.is_file():
        return workspace / Path(legacy_location)
    invalid = workspace / "runtime" / f"invalid-catalog-{role}.db"
    try:
        pointer_raw = current_path.read_bytes()
        if len(pointer_raw) > 64 * 1024:
            return invalid
        pointer = json.loads(pointer_raw.decode("utf-8"))
        generation = pointer.get("generation") if isinstance(pointer, dict) else None
        expected_hash = (
            str(pointer.get("manifest_sha256") or "") if isinstance(pointer, dict) else ""
        )
        if (
            not isinstance(generation, int)
            or generation < 1
            or not expected_hash
            or pointer.get("schema_version") != "persistmind.catalog_pointer.v1"
        ):
            return invalid
        manifest_path = workspace / "catalog" / "generations" / f"{generation:020d}.json"
        manifest_raw = manifest_path.read_bytes()
        if len(manifest_raw) > 4 * 1024 * 1024:
            return invalid
        manifest = json.loads(manifest_raw.decode("utf-8"))
        if not isinstance(manifest, dict):
            return invalid
        canonical = json.dumps(
            manifest,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        ).encode("utf-8")
        if hashlib.sha256(canonical).hexdigest() != expected_hash:
            return invalid
        matches = [
            item
            for item in manifest.get("stores", [])
            if isinstance(item, dict)
            and item.get("store_role") == role
            and item.get("state") == "active"
            and not item.get("read_only")
            and item.get("shard_key", "default") == "default"
        ]
        if len(matches) != 1:
            return invalid
        location = str(matches[0].get("location") or "")
        if (
            not location
            or "\\" in location
            or ":" in location
            or location.startswith("/")
            or any(part in {"", ".", ".."} for part in location.split("/"))
        ):
            return invalid
        resolved = (workspace / Path(*location.split("/"))).resolve()
        if not resolved.is_relative_to(workspace.resolve()):
            return invalid
        return resolved
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError, TypeError):
        return invalid


def _source_generation_revision(path: Path) -> str:
    row = _read_row(
        path,
        "SELECT current_generation_id FROM source_views ORDER BY updated_at DESC LIMIT 1",
    )
    return str(row[0]) if row else _file_revision(path)


def _write_scope_revision(
    path: Path,
    *,
    task_session_id: str | None,
    expected_pack_id: str | None,
    expected_plan_id: str | None,
) -> str:
    # Legacy snapshots did not carry a task binding. Retain their fail-closed
    # image token until the next authoritative preflight publishes a bound one.
    if not task_session_id:
        return _file_revision(path)
    workflow = _read_row(
        path,
        "SELECT pack_id,plan_id FROM task_workflow_snapshots WHERE task_session_id=?",
        (task_session_id,),
    )
    live_pack = str(workflow[0] or "") if workflow else ""
    live_plan = str(workflow[1] or "") if workflow else ""
    session = _read_row(
        path,
        "SELECT payload_json FROM task_sessions WHERE task_session_id=?",
        (task_session_id,),
    )
    if not live_pack and session:
        try:
            payload = json.loads(str(session[0] or "{}"))
        except json.JSONDecodeError:
            payload = {}
        if isinstance(payload, dict):
            live_pack = str(payload.get("pack_id") or "")
    if expected_plan_id and not live_plan:
        latest_plan = _read_row(
            path,
            "SELECT plan_id FROM task_plans WHERE task_session_id=? "
            "ORDER BY CASE WHEN status='active' THEN 0 ELSE 1 END,"
            "updated_at DESC,plan_id DESC LIMIT 1",
            (task_session_id,),
        )
        live_plan = str(latest_plan[0] or "") if latest_plan else ""
    live_pack = live_pack or "missing"
    if expected_plan_id:
        live_plan = live_plan or "missing"
        plan = _read_row(
            path,
            "SELECT status,current_revision FROM task_plans WHERE plan_id=? AND task_session_id=?",
            (live_plan, task_session_id),
        )
        plan_status = str(plan[0] or "") if plan else "missing"
        plan_revision = int(plan[1]) if plan else 0
    else:
        # A write preflight normally precedes plan creation. Until a concrete
        # plan is rebound into the snapshot, authorization is deliberately
        # scoped to the Task session and pack; creating the first plan and
        # recording verification linkage must not masquerade as scope drift.
        live_plan = "unbound"
        plan_status = "unbound"
        plan_revision = 0
    material = {
        "task_session_id": task_session_id,
        "expected_pack_id": expected_pack_id or "",
        "expected_plan_id": expected_plan_id or "",
        "live_pack_id": live_pack,
        "live_plan_id": live_plan,
        "plan_status": plan_status,
        "plan_revision": plan_revision,
    }
    return hashlib.sha256(
        json.dumps(material, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def _domain_revision(path: Path) -> str:
    row = _read_row(path, "SELECT revision FROM domain_metadata WHERE singleton=1")
    return str(row[0]) if row else _file_revision(path)


def _read_row(path: Path, query: str, parameters: tuple[Any, ...] = ()) -> tuple[Any, ...] | None:
    if not path.is_file():
        return None
    connection: sqlite3.Connection | None = None
    try:
        connection = sqlite3.connect(
            f"file:{path.as_posix()}?mode=ro",
            uri=True,
            timeout=0.1,
        )
        row = connection.execute(query, parameters).fetchone()
        return tuple(row) if row is not None else None
    except sqlite3.Error:
        return None
    finally:
        if connection is not None:
            connection.close()


def _file_revision(path: Path) -> str:
    revisions = []
    for candidate in (path, Path(f"{path}-wal")):
        try:
            stat = candidate.stat()
        except OSError:
            continue
        revisions.append(f"{candidate.name}:{stat.st_size}:{stat.st_mtime_ns}")
    if not revisions:
        return "absent"
    return hashlib.sha256("\0".join(revisions).encode("utf-8")).hexdigest()


def _revision_digest(source: str, write_scope: str, trust: str) -> str:
    return hashlib.sha256(f"{source}\0{write_scope}\0{trust}".encode("utf-8")).hexdigest()


def _parse_instant(value: str) -> datetime | None:
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if result.tzinfo is None:
        result = result.replace(tzinfo=timezone.utc)
    return result.astimezone(timezone.utc)


def _queue_observation(
    repo: Path,
    event: str,
    payload: Mapping[str, Any],
    normalized: Mapping[str, Any],
    decision: str,
) -> None:
    workspace = resolve_project_state(Path(repo).resolve())
    if not (workspace / "catalog" / "current.json").is_file():
        return
    try:
        command = str(normalized.get("command") or "")
        record = {
            "schema_version": "persistmind.hook_observation_queue.v1",
            "event": event,
            "session_id": str(payload.get("session_id") or "") or None,
            "host_event_id": str(payload.get("hook_event_id") or "") or None,
            "occurred_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "payload": {
                "tool_name": str(normalized.get("tool") or "")[:256],
                "command_digest": hashlib.sha256(command.encode("utf-8")).hexdigest(),
                "command_bytes": len(command.encode("utf-8")),
                "read_only": bool(normalized.get("read_only")),
                "broad_repository_scan": bool(normalized.get("broad_repository_scan")),
                "repository_context_read": bool(normalized.get("repository_context_read")),
                "decision": decision,
                "invalid_json": bool(normalized.get("invalid_json")),
            },
        }
        raw = (json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
        if len(raw) > 16 * 1024:
            return
        queue = workspace / "runtime" / "hook-observations"
        queue.mkdir(parents=True, exist_ok=True)
        path = queue / f"{os.getpid()}.jsonl"
        descriptor = os.open(path, os.O_APPEND | os.O_CREAT | os.O_WRONLY, 0o600)
        try:
            os.write(descriptor, raw)
        finally:
            os.close(descriptor)
    except Exception:
        # Hooks never fail because observation persistence is unavailable.
        return


def drain_hook_observations(
    repo: Path, *, limit: int = 1000, ports: Any | None = None
) -> dict[str, Any]:
    """Move bounded hook spool records into Activity outside the gating process."""

    root = Path(repo).resolve()
    workspace = resolve_project_state(root)
    queue = workspace / "runtime" / "hook-observations"
    if not queue.is_dir():
        return {
            "ok": True,
            "schema_version": "persistmind.hook_observation_drain.v1",
            "drained": 0,
            "failed": 0,
        }
    from persistmind.storage.agent_runtime_ports import AgentRuntimePorts

    context = repository_context(root)
    key = hashlib.sha256(
        (context.repository_id + os.environ.get("USERNAME", "local")).encode("utf-8")
    ).digest()
    drained = 0
    failed = 0
    owned_ports = ports is None
    active_ports = ports or AgentRuntimePorts(root)
    try:
        journal = AgentEventJournal(active_ports.activity, context, redaction_key=key)
        for path in sorted(queue.glob("*.jsonl")):
            if drained >= limit:
                break
            processing = path.with_suffix(f".{os.getpid()}.processing")
            try:
                os.replace(path, processing)
            except OSError:
                continue
            retry: list[bytes] = []
            try:
                for raw in processing.read_bytes().splitlines():
                    if drained >= limit:
                        retry.append(raw)
                        continue
                    try:
                        item = json.loads(raw.decode("utf-8"))
                        journal.append(
                            "hook",
                            str(item["event"]),
                            dict(item["payload"]),
                            session_id=item.get("session_id"),
                            host_event_id=item.get("host_event_id"),
                            occurred_at=item.get("occurred_at"),
                        )
                        drained += 1
                    except Exception:
                        failed += 1
                        retry.append(raw)
            finally:
                processing.unlink(missing_ok=True)
            if retry:
                retry_path = queue / f"retry-{os.getpid()}-{time.time_ns()}.jsonl"
                retry_path.write_bytes(b"\n".join(retry) + b"\n")
    finally:
        if owned_ports:
            active_ports.close()
    return {
        "ok": failed == 0,
        "schema_version": "persistmind.hook_observation_drain.v1",
        "drained": drained,
        "failed": failed,
    }


def _snapshot_path(repo: Path) -> Path:
    return resolve_project_state(Path(repo).resolve()) / "runtime" / "policy-snapshot.json"


def hook_budget() -> Mapping[str, Any]:
    return load_runtime_contract()["performance_budgets"]


__all__ = [
    "SNAPSHOT_SCHEMA",
    "drain_hook_observations",
    "evaluate_fast_hook",
    "hook_budget",
    "read_policy_snapshot",
    "write_policy_snapshot",
]
