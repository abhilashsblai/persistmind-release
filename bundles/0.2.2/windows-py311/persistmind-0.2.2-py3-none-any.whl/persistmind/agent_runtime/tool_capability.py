from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from .shell_intent import analyze_shell_command

ToolKind = Literal["read", "write", "scan", "network", "control", "unknown"]
ToolScope = Literal["narrow", "broad", "unknown"]

_MCP_READ_VERBS = {
    "fetch",
    "find",
    "get",
    "health",
    "inspect",
    "list",
    "lookup",
    "query",
    "read",
    "search",
    "show",
    "status",
    "view",
}
_MCP_WRITE_VERBS = {
    "add",
    "archive",
    "cancel",
    "copy",
    "create",
    "delete",
    "execute",
    "forward",
    "label",
    "move",
    "patch",
    "post",
    "put",
    "remove",
    "rename",
    "reply",
    "run",
    "send",
    "set",
    "share",
    "update",
    "upload",
    "write",
}
_MCP_SCAN_VERBS = {
    "all",
    "directory",
    "enumerate",
    "find",
    "glob",
    "grep",
    "index",
    "list",
    "search",
    "tree",
    "walk",
}
_PERSISTMIND_CONTEXT_MCP_TOOLS = {
    "codex_enforcement_status",
    "get_impact_report",
    "get_pack_manifest",
    "impact_of",
    "mcp_capabilities",
    "memory_recall",
    "plan_show",
    "search_code",
    "search_repo",
    "session_explain",
    "storage_roles",
    "storage_status",
    "storage_verify",
    "task_show",
    "workflow_brief",
}
_PERSISTMIND_BOOTSTRAP_MCP_TOOLS = {
    "codex_preflight",
    "get_context_pack",
    "task_start",
}
_WRITE_TOOLS = {
    "applypatch",
    "edit",
    "multiedit",
    "notebookedit",
    "strreplaceeditor",
    "write",
}
_READ_TOOLS = {"read", "view", "glob", "grep", "search", "find", "list", "ls"}
_NETWORK_TOOLS = {"websearch", "webfetch"}
_CONTROL_TOOLS = {"task", "agent", "slashcommand"}
_PATH_TARGET_KEYS = {
    "path",
    "file_path",
    "relative_path",
    "root_path",
    "directory",
    "root",
    "cwd",
    "search_path",
    "dir",
    "folder",
    "file",
    "filename",
}


@dataclass(frozen=True)
class ToolCapability:
    kind: ToolKind
    targets: tuple[str, ...] = ()
    scope: ToolScope = "unknown"
    read_only: bool = False
    repository_context_read: bool = False
    governance_bootstrap: bool = False
    non_repository_read: bool = False
    reason: str = ""
    scan_allow_keys: tuple[str, ...] = ()


def classify_tool(
    tool: str,
    command: str,
    tool_input: Mapping[str, Any],
    *,
    repo: Path | None = None,
) -> ToolCapability:
    normalized = _normalized_tool(tool)
    if _is_shell_tool(normalized):
        return _classify_shell(command, repo=repo)
    if normalized.startswith("mcp"):
        return _classify_mcp(tool, tool_input, repo=repo)
    targets = tuple(_tool_targets(tool_input))
    broad = _tool_scope_broad(targets, repo=repo)
    if normalized in _READ_TOOLS:
        kind: ToolKind = "scan" if normalized in {"glob", "grep", "search", "find", "list", "ls"} else "read"
        return ToolCapability(
            kind=kind,
            targets=targets,
            scope="broad" if broad or (kind == "scan" and not targets) else "narrow",
            read_only=True,
            repository_context_read=True,
        )
    if normalized in _NETWORK_TOOLS:
        return ToolCapability(kind="network", read_only=True, repository_context_read=False)
    if normalized in _CONTROL_TOOLS:
        return ToolCapability(kind="control", read_only=True, repository_context_read=False)
    if normalized in _WRITE_TOOLS:
        return ToolCapability(kind="write", targets=targets, scope="narrow", read_only=False)
    return ToolCapability(kind="unknown", targets=targets, repository_context_read=True)


def persistmind_mcp_bootstrap_name(tool: str) -> bool:
    normalized = tool.casefold()
    prefix = "mcp__persistmind__"
    return normalized.startswith(prefix) and normalized[len(prefix) :] in _PERSISTMIND_BOOTSTRAP_MCP_TOOLS


def persistmind_mcp_context_name(tool: str) -> bool:
    normalized = tool.casefold()
    prefix = "mcp__persistmind__"
    return normalized.startswith(prefix) and normalized[len(prefix) :] in _PERSISTMIND_CONTEXT_MCP_TOOLS


def _classify_shell(command: str, *, repo: Path | None) -> ToolCapability:
    analysis = analyze_shell_command(command, repo=repo)
    if analysis.non_repository_read:
        return ToolCapability(
            kind="read",
            targets=tuple(analysis.read_targets),
            scope="narrow",
            read_only=True,
            repository_context_read=False,
            non_repository_read=True,
        )
    if analysis.broad_scan:
        return ToolCapability(
            kind="scan",
            targets=tuple(analysis.read_targets),
            scope="broad",
            read_only=True,
            repository_context_read=True,
            reason=analysis.broad_scan_reason,
        )
    if analysis.repository_read:
        return ToolCapability(
            kind="read",
            targets=tuple(analysis.read_targets),
            scope="narrow" if analysis.read_targets else "unknown",
            read_only=True,
            repository_context_read=True,
        )
    from persistmind.codex import _safe_ctx_governance_command, _safe_ctx_read_only_command

    if _safe_ctx_governance_command(command):
        return ToolCapability(kind="control", read_only=False, governance_bootstrap=True)
    if _safe_ctx_read_only_command(command):
        return ToolCapability(kind="control", read_only=True, repository_context_read=False)
    from persistmind.codex import _SHELL_WRITE_SIGNAL

    if _SHELL_WRITE_SIGNAL.search(command):
        return ToolCapability(kind="write", read_only=False)
    return ToolCapability(kind="unknown", repository_context_read=True)


def _classify_mcp(
    tool: str,
    tool_input: Mapping[str, Any],
    *,
    repo: Path | None,
) -> ToolCapability:
    if persistmind_mcp_bootstrap_name(tool):
        return ToolCapability(kind="control", read_only=False, governance_bootstrap=True)
    if persistmind_mcp_context_name(tool):
        return ToolCapability(kind="read", read_only=True, repository_context_read=False)
    tokens = set(_mcp_tokens(tool))
    targets = tuple(_tool_targets(tool_input))
    broad = _tool_scope_broad(targets, repo=repo)
    if tokens & _MCP_WRITE_VERBS:
        return ToolCapability(kind="write", targets=targets, read_only=False)
    if tokens & _MCP_SCAN_VERBS:
        return ToolCapability(
            kind="scan",
            targets=targets,
            scope="broad" if broad or not targets else "narrow",
            read_only=True,
            repository_context_read=True,
            scan_allow_keys=tuple(_mcp_scan_allow_keys(tool)),
        )
    if tokens & _MCP_READ_VERBS:
        return ToolCapability(
            kind="read",
            targets=targets,
            scope="narrow" if targets else "unknown",
            read_only=True,
            repository_context_read=True,
        )
    return ToolCapability(kind="unknown", targets=targets, repository_context_read=True)


def _tool_targets(tool_input: Mapping[str, Any]) -> list[str]:
    raw: list[object] = []
    for name, value in _iter_tool_input_items(tool_input):
        if value is None or value == "":
            continue
        normalized = name.casefold()
        is_path_key = normalized in _PATH_TARGET_KEYS or normalized.endswith("_file")
        if not is_path_key:
            continue
        raw.extend(value if isinstance(value, list) else [value])
    return [str(value).strip().strip("'\"") for value in raw if str(value).strip()]


def _iter_tool_input_items(value: Mapping[str, Any], prefix: str = "") -> list[tuple[str, Any]]:
    items: list[tuple[str, Any]] = []
    for key, item in value.items():
        name = f"{prefix}_{key}" if prefix else str(key)
        if isinstance(item, Mapping):
            items.extend(_iter_tool_input_items(item, name))
        else:
            items.append((name, item))
    return items


def _tool_scope_broad(targets: tuple[str, ...] | list[str], *, repo: Path | None) -> bool:
    if not targets:
        return False
    return any(_is_repository_root_or_ancestor(value, repo) for value in targets)


def _is_repository_root_or_ancestor(value: object, repo: Path | None) -> bool:
    text = str(value or "").strip()
    if text in {"", ".", "./", ".\\"}:
        return True
    if repo is None:
        return False
    try:
        candidate = Path(text).expanduser()
        if not candidate.is_absolute():
            candidate = repo / candidate
        resolved = candidate.resolve()
        root = repo.resolve()
        return resolved == root or root.is_relative_to(resolved)
    except (OSError, ValueError):
        return False


def _mcp_tokens(tool: str) -> list[str]:
    return [token for token in re.split(r"[^a-z0-9]+", tool.casefold()) if token and token != "mcp"]


def _mcp_scan_allow_keys(tool: str) -> list[str]:
    normalized = tool.casefold()
    parts = [part for part in normalized.split("__") if part and part != "mcp"]
    keys = {normalized}
    if parts:
        keys.add(parts[-1])
    if len(parts) >= 2:
        keys.add("__".join(parts[-2:]))
        keys.add(".".join(parts[-2:]))
    return sorted(keys)


def mcp_input_digest(tool: str, tool_input: Mapping[str, Any]) -> str:
    material = {
        "tool": tool,
        "tool_input": tool_input,
    }
    encoded = json.dumps(material, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8", errors="replace")).hexdigest()[:12]


def _normalized_tool(tool: str) -> str:
    return "".join(character for character in tool.casefold() if character.isalnum())


def _is_shell_tool(normalized: str) -> bool:
    return any(name in normalized for name in ("bash", "shell", "terminal"))


__all__ = [
    "ToolCapability",
    "classify_tool",
    "mcp_input_digest",
    "persistmind_mcp_bootstrap_name",
    "persistmind_mcp_context_name",
]
