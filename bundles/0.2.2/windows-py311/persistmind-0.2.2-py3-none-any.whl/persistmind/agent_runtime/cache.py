from __future__ import annotations

import hashlib
import json
import os
import shutil
import time
from collections.abc import Callable, Iterator, Mapping
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from persistmind.agent_runtime.identity import repository_context
from persistmind.utils import canonical_json

CACHE_SCHEMA = "persistmind.runtime_cache.v1"
CACHE_NAMESPACES = frozenset({"candidate", "search", "impact", "pack", "public_surface"})


@dataclass(frozen=True, slots=True)
class CacheKey:
    contract_version: str
    repository_id: str
    tenant: str
    source_view_id: str
    source_generation: str
    dirty_diff_digest: str
    request_digest: str
    limits_digest: str
    algorithm_version: str
    configuration_digest: str
    model_digest: str
    policy_revision: str
    memory_revision: str
    plugin_closure_digest: str
    redaction_revision: str

    @property
    def digest(self) -> str:
        return hashlib.sha256(canonical_json(asdict(self)).encode("utf-8")).hexdigest()


class RuntimeCache:
    def __init__(
        self,
        workspace_root: Path,
        *,
        max_bytes: int = 2 * 1024 * 1024 * 1024,
        max_entry_bytes: int = 16 * 1024 * 1024,
        max_age_seconds: int = 24 * 60 * 60,
        read_only: bool = False,
    ) -> None:
        self.root = Path(workspace_root) / "runtime" / "cache"
        self.max_bytes = max(1024 * 1024, min(int(max_bytes), 2 * 1024 * 1024 * 1024))
        self.max_entry_bytes = max(1024, min(int(max_entry_bytes), 16 * 1024 * 1024))
        self.max_age_seconds = max(1, min(int(max_age_seconds), 30 * 24 * 60 * 60))
        self.read_only = bool(read_only)

    def get(
        self,
        namespace: str,
        key: CacheKey,
        *,
        authorize: Callable[[Mapping[str, Any]], bool],
    ) -> Mapping[str, Any] | None:
        started = time.perf_counter_ns()
        path = self._path(namespace, key)
        try:
            raw = path.read_bytes()
        except OSError:
            self._metric("misses", latency_ns=time.perf_counter_ns() - started)
            return None
        if len(raw) > self.max_entry_bytes:
            if not self.read_only:
                path.unlink(missing_ok=True)
            self._metric("stale", latency_ns=time.perf_counter_ns() - started)
            return None
        try:
            document = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            if not self.read_only:
                path.unlink(missing_ok=True)
            self._metric("stale", latency_ns=time.perf_counter_ns() - started)
            return None
        created_at = float(document.get("created_at_epoch", 0)) if isinstance(document, dict) else 0
        if created_at <= 0 or time.time() - created_at > self.max_age_seconds:
            if not self.read_only:
                path.unlink(missing_ok=True)
            self._metric("stale", latency_ns=time.perf_counter_ns() - started)
            return None
        if (
            not isinstance(document, dict)
            or document.get("schema_version") != CACHE_SCHEMA
            or document.get("key_digest") != key.digest
            or not isinstance(document.get("value"), dict)
            or not authorize(document["value"])
        ):
            self._metric("misses", latency_ns=time.perf_counter_ns() - started)
            self._metric("bypasses")
            return None
        self._metric("hits", latency_ns=time.perf_counter_ns() - started)
        if not self.read_only:
            try:
                os.utime(path, None)
            except OSError:
                pass
        return dict(document["value"])

    def put(self, namespace: str, key: CacheKey, value: Mapping[str, Any]) -> Path:
        path = self._path(namespace, key)
        if self.read_only:
            return path
        path.parent.mkdir(parents=True, exist_ok=True)
        with _exclusive_lock(path.with_suffix(".lock")):
            if path.exists():
                existing = json.loads(path.read_text(encoding="utf-8"))
                if existing.get("key_digest") != key.digest or existing.get("value") != dict(value):
                    raise RuntimeError("immutable runtime cache key collision")
                return path
            document = {
                "schema_version": CACHE_SCHEMA,
                "key": asdict(key),
                "key_digest": key.digest,
                "created_at_epoch": time.time(),
                "value": dict(value),
            }
            raw = (
                json.dumps(document, sort_keys=True, separators=(",", ":"), default=str) + "\n"
            ).encode("utf-8")
            if len(raw) > self.max_entry_bytes:
                self._metric("bypasses")
                raise ValueError("runtime cache entry exceeds the configured byte ceiling")
            temporary = path.with_suffix(f".{os.getpid()}.tmp")
            try:
                with temporary.open("xb") as handle:
                    handle.write(raw)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temporary, path)
            finally:
                temporary.unlink(missing_ok=True)
        self._metric("writes")
        self.gc()
        return path

    def bypass(self) -> None:
        """Record a deliberate correctness-preserving cache bypass."""

        self._metric("bypasses")

    def drop(self, namespace: str | None = None) -> dict[str, Any]:
        if self.read_only:
            raise RuntimeError("read-only runtime cache cannot drop entries")
        roots = (
            [self.root / namespace]
            if namespace
            else [self.root / item for item in CACHE_NAMESPACES]
        )
        deleted = 0
        for root in roots:
            if not root.is_relative_to(self.root):
                raise ValueError("runtime cache drop escaped its root")
            if not root.exists():
                continue
            for path in root.glob("*.json"):
                path.unlink(missing_ok=True)
                deleted += 1
        if deleted:
            self._metric("evictions", amount=deleted)
        return {"ok": True, "schema_version": CACHE_SCHEMA, "deleted": deleted}

    def gc(self) -> dict[str, Any]:
        if self.read_only:
            raise RuntimeError("read-only runtime cache cannot collect entries")
        stale_cutoff = time.time() - self.max_age_seconds
        stale_deleted = 0
        for path in self.root.glob("*/*.json"):
            if path.is_file() and path.stat().st_mtime < stale_cutoff:
                path.unlink(missing_ok=True)
                stale_deleted += 1
        files = sorted(
            (path for path in self.root.glob("*/*.json") if path.is_file()),
            key=lambda path: (path.stat().st_mtime_ns, path.as_posix()),
        )
        total = sum(path.stat().st_size for path in files)
        deleted = []
        while files and total > self.max_bytes:
            path = files.pop(0)
            size = path.stat().st_size
            path.unlink(missing_ok=True)
            total -= size
            deleted.append(path.name)
        evicted = stale_deleted + len(deleted)
        if evicted:
            self._metric("evictions", amount=evicted)
        return {
            "ok": True,
            "schema_version": CACHE_SCHEMA,
            "bytes": total,
            "deleted": deleted,
            "stale_deleted": stale_deleted,
        }

    def status(self) -> dict[str, Any]:
        counts = {}
        total = 0
        for namespace in sorted(CACHE_NAMESPACES):
            files = list((self.root / namespace).glob("*.json"))
            counts[namespace] = len(files)
            total += sum(path.stat().st_size for path in files if path.is_file())
        metrics = self._metrics()
        requests = int(metrics.get("hits", 0)) + int(metrics.get("misses", 0))
        return {
            "ok": True,
            "schema_version": CACHE_SCHEMA,
            "root": str(self.root),
            "entries": counts,
            "bytes": total,
            **metrics,
            "requests": requests,
            "average_get_latency_ms": round(
                float(metrics.get("get_latency_ns", 0)) / max(1, requests) / 1_000_000, 4
            ),
            "max_bytes": self.max_bytes,
            "max_age_seconds": self.max_age_seconds,
            "backup_eligible": False,
            "authoritative": False,
        }

    def _path(self, namespace: str, key: CacheKey) -> Path:
        if namespace not in CACHE_NAMESPACES:
            raise ValueError(f"unknown runtime cache namespace: {namespace}")
        return self.root / namespace / f"{key.digest}.json"

    def _metric(self, name: str, *, amount: int = 1, latency_ns: int = 0) -> None:
        if self.read_only:
            return
        self.root.mkdir(parents=True, exist_ok=True)
        with _exclusive_lock(self.root / ".telemetry.lock"):
            metrics = self._metrics()
            metrics[name] = int(metrics.get(name, 0)) + max(0, int(amount))
            metrics["get_latency_ns"] = int(metrics.get("get_latency_ns", 0)) + max(
                0, int(latency_ns)
            )
            temporary = self.root / f".telemetry.{os.getpid()}.tmp"
            temporary.write_text(
                json.dumps(metrics, sort_keys=True, separators=(",", ":")) + "\n",
                encoding="utf-8",
            )
            os.replace(temporary, self.root / "telemetry.json")

    def _metrics(self) -> dict[str, int]:
        try:
            value = json.loads((self.root / "telemetry.json").read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            value = {}
        names = ("hits", "misses", "bypasses", "stale", "writes", "evictions", "get_latency_ns")
        return {name: max(0, int(value.get(name, 0))) for name in names}


def build_cache_key(
    repo_root: Path,
    workspace_root: Path,
    *,
    source_generation: str,
    request: Mapping[str, Any],
    limits: Mapping[str, Any],
    algorithm_version: str,
    model_digest: str = "deterministic",
    plugin_closure_digest: str = "none",
    redaction_revision: str = "v1",
) -> CacheKey:
    """Build the full revision-bound key used by production read services."""

    repo = Path(repo_root).resolve()
    workspace = Path(workspace_root).resolve()
    context = repository_context(repo)
    configuration = []
    for name in ("persistmind.toml",):
        path = repo / name
        if path.is_file():
            configuration.append((name, hashlib.sha256(path.read_bytes()).hexdigest()))
    return CacheKey(
        contract_version=CACHE_SCHEMA,
        repository_id=context.repository_id,
        tenant="local",
        source_view_id=context.source_view_id,
        source_generation=str(source_generation or "unpublished"),
        dirty_diff_digest=context.dirty_digest,
        request_digest=_digest(request),
        limits_digest=_digest(limits),
        algorithm_version=algorithm_version,
        configuration_digest=_digest(configuration),
        model_digest=model_digest,
        policy_revision=_file_revision(workspace / "stores" / "knowledge" / "policy.db"),
        memory_revision=_file_revision(workspace / "stores" / "knowledge" / "knowledge.db"),
        plugin_closure_digest=plugin_closure_digest,
        redaction_revision=redaction_revision,
    )


def cache_scope(key: CacheKey) -> dict[str, str]:
    return {
        "repository_id": key.repository_id,
        "tenant": key.tenant,
        "source_view_id": key.source_view_id,
        "source_generation": key.source_generation,
        "policy_revision": key.policy_revision,
        "memory_revision": key.memory_revision,
        "plugin_closure_digest": key.plugin_closure_digest,
        "redaction_revision": key.redaction_revision,
    }


def cache_scope_matches(value: Mapping[str, Any], key: CacheKey) -> bool:
    scope = value.get("scope")
    return isinstance(scope, Mapping) and dict(scope) == cache_scope(key)


def _file_revision(path: Path) -> str:
    revisions = []
    for candidate in (path, Path(f"{path}-wal")):
        try:
            stat = candidate.stat()
        except OSError:
            continue
        revisions.append(
            {"path": candidate.name, "bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns}
        )
    if not revisions:
        return "absent"
    return _digest(revisions)


def _digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


@contextmanager
def _exclusive_lock(path: Path, *, timeout_seconds: float = 10.0) -> Iterator[None]:
    deadline = time.monotonic() + timeout_seconds
    while True:
        try:
            path.mkdir(parents=False)
            break
        except FileExistsError:
            try:
                if time.time() - path.stat().st_mtime > 30:
                    shutil.rmtree(path)
                    continue
            except OSError:
                pass
            if time.monotonic() >= deadline:
                raise TimeoutError(f"runtime cache lock timed out: {path}")
            time.sleep(0.01)
    try:
        yield
    finally:
        shutil.rmtree(path, ignore_errors=True)


__all__ = [
    "CACHE_NAMESPACES",
    "CACHE_SCHEMA",
    "CacheKey",
    "RuntimeCache",
    "build_cache_key",
    "cache_scope",
    "cache_scope_matches",
]
