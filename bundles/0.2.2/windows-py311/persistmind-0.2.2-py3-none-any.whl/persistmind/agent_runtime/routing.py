from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime
from importlib.resources import files
from typing import Any

from persistmind.application.agent_runtime_ports import AgentRuntimeTaskPort
from persistmind.utils import canonical_json, stable_id

ROUTE_SCHEMA = "persistmind.model_route.v1"


class ModelRouter:
    def __init__(
        self,
        catalog: Mapping[str, Any] | None = None,
        *,
        task: AgentRuntimeTaskPort | None = None,
    ) -> None:
        self.catalog = dict(catalog or _catalog())
        self.task = task
        if self.catalog.get("schema_version") != "persistmind.model_catalog.v1":
            raise ValueError("unsupported model catalog")

    def route(
        self,
        *,
        role: str,
        task_class: str,
        risk: str = "normal",
        sensitive: bool = False,
        requested_model: str | None = None,
        policy_models: Sequence[str] = (),
        available_providers: Sequence[str] | None = None,
        orchestration_id: str | None = None,
        policy_revision: str = "default",
        adapter_id: str | None = None,
        required_capabilities: Sequence[str] = (),
        required_context_tokens: int = 0,
        max_cost_usd: float | None = None,
        max_turns: int | None = None,
        usage: Mapping[str, Any] | None = None,
        adapter_enforces_model: bool = True,
    ) -> dict[str, Any]:
        role = {
            "architecture": "review",
            "implementation": "implement",
            "implementer": "implement",
            "reviewer": "review",
            "repair": "implement",
            "summarization": "review",
            "memory-extraction": "review",
            "sensitive-local": "implement",
        }.get(role.casefold(), role.casefold())
        valid_until = _instant(str(self.catalog.get("valid_until") or ""))
        if valid_until <= datetime.now(UTC):
            raise RuntimeError("model catalog or pricing evidence is stale")
        models = [dict(item) for item in self.catalog["models"]]
        available = set(available_providers or [item["provider"] for item in models])
        by_id = {str(item["id"]): item for item in models}
        candidates: list[tuple[str, str]] = []
        if requested_model:
            candidates.append((requested_model, "explicit_request"))
        candidates.extend((model, "policy") for model in policy_models)
        candidates.extend(
            (str(item["id"]), "role_default")
            for item in sorted(
                models, key=lambda item: (int(item.get("priority", 1000)), str(item["id"]))
            )
            if role in item.get("roles", [])
        )
        candidates.append(("local-default", "deterministic_fallback"))
        selected = None
        reason = ""
        rejected: list[dict[str, Any]] = []
        usage_snapshot = {
            "turns": max(0, int((usage or {}).get("turns", 0))),
            "input_tokens": max(0, int((usage or {}).get("input_tokens", 0))),
            "output_tokens": max(0, int((usage or {}).get("output_tokens", 0))),
            "spent_usd": max(0.0, float((usage or {}).get("spent_usd", 0.0))),
        }
        required = set(str(item) for item in required_capabilities if item)
        for model_id, source in candidates:
            item = by_id.get(model_id)
            if item is None:
                rejected.append({"model": model_id, "reason": "unknown"})
                continue
            provider = str(item["provider"])
            if adapter_id and str(item.get("adapter") or "") != adapter_id:
                rejected.append({"model": model_id, "reason": "adapter_mismatch"})
                continue
            if role not in set(item.get("roles") or []):
                rejected.append({"model": model_id, "reason": "role_unsupported"})
                continue
            if provider not in available:
                rejected.append({"model": model_id, "reason": "provider_unavailable"})
                continue
            if sensitive and not item.get("local"):
                rejected.append({"model": model_id, "reason": "sensitive_requires_local"})
                continue
            missing_capabilities = sorted(required - set(item.get("capabilities") or []))
            if missing_capabilities:
                rejected.append(
                    {
                        "model": model_id,
                        "reason": "capability_missing",
                        "capabilities": missing_capabilities,
                    }
                )
                continue
            if required_context_tokens > int(item.get("context_limit") or 0):
                rejected.append({"model": model_id, "reason": "context_limit"})
                continue
            credential_env = str(item.get("credential_env") or "")
            if credential_env and not os.environ.get(credential_env):
                rejected.append({"model": model_id, "reason": "credential_unavailable"})
                continue
            if requested_model and model_id == requested_model and not adapter_enforces_model:
                rejected.append({"model": model_id, "reason": "model_selection_unenforceable"})
                continue
            estimated_cost = (
                usage_snapshot["spent_usd"]
                + (
                    usage_snapshot["input_tokens"] * float(item.get("input_per_million") or 0)
                    + usage_snapshot["output_tokens"] * float(item.get("output_per_million") or 0)
                )
                / 1_000_000
            )
            if max_turns is not None and usage_snapshot["turns"] >= max(0, int(max_turns)):
                rejected.append({"model": model_id, "reason": "turn_budget_exhausted"})
                continue
            if max_cost_usd is not None and estimated_cost >= max(0.0, float(max_cost_usd)):
                rejected.append({"model": model_id, "reason": "cost_budget_exhausted"})
                continue
            selected, reason = item, source
            break
        if selected is None:
            raise RuntimeError("no permitted model route is available")
        credential_env = str(selected.get("credential_env") or "")
        estimated_cost = (
            usage_snapshot["spent_usd"]
            + (
                usage_snapshot["input_tokens"] * float(selected.get("input_per_million") or 0)
                + usage_snapshot["output_tokens"] * float(selected.get("output_per_million") or 0)
            )
            / 1_000_000
        )
        evidence = {
            "role": role,
            "task_class": task_class,
            "risk": risk,
            "sensitive": sensitive,
            "selected_model": selected["id"],
            "provider": selected["provider"],
            "local": bool(selected.get("local")),
            "adapter": selected.get("adapter"),
            "adapter_model": selected.get("adapter_model"),
            "capabilities": sorted(selected.get("capabilities") or []),
            "context_limit": int(selected.get("context_limit") or 0),
            "selection_source": reason,
            "credential_present": bool(credential_env and os.environ.get(credential_env)),
            "credential_name": credential_env or None,
            "rejected": rejected,
            "catalog_version": self.catalog["version"],
            "pricing_version": self.catalog["pricing_version"],
            "catalog_valid_until": self.catalog["valid_until"],
            "usage": usage_snapshot,
            "estimated_cost_usd": round(estimated_cost, 8),
            "max_cost_usd": max_cost_usd,
            "max_turns": max_turns,
            "required_capabilities": sorted(required),
        }
        digest = hashlib.sha256(canonical_json(evidence).encode("utf-8")).hexdigest()
        result = {
            "ok": True,
            "schema_version": ROUTE_SCHEMA,
            "route_id": "route_" + stable_id(digest)[:32],
            **evidence,
            "evidence_digest": digest,
        }
        if self.task is not None:
            if not orchestration_id:
                raise ValueError("durable model-route evidence requires an orchestration identity")
            self.task.put_model_route_evidence(
                {
                    "route_evidence_id": result["route_id"],
                    "orchestration_id": orchestration_id,
                    "catalog_version": self.catalog["version"],
                    "policy_revision": policy_revision,
                    "candidate_digest": hashlib.sha256(
                        canonical_json(candidates).encode("utf-8")
                    ).hexdigest(),
                    "selected_route_id": result["route_id"],
                    "fallback_reason": reason if reason != "explicit_request" else None,
                    "evidence": result,
                }
            )
        return result


def _catalog() -> dict[str, Any]:
    resource = files("persistmind.agent_runtime.resources").joinpath("model-catalog.v1.json")
    return json.loads(resource.read_text(encoding="utf-8"))


def _instant(value: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError("model catalog requires a valid_until timestamp") from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


__all__ = ["ROUTE_SCHEMA", "ModelRouter"]
