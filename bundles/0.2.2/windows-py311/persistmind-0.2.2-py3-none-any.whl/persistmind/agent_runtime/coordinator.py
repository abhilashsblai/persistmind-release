from __future__ import annotations

import hmac
import json
import secrets
import time
from collections.abc import Callable, Mapping
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

from .jobs import DurableJobService


class RepositoryCoordinator:
    def __init__(
        self,
        jobs: DurableJobService,
        handlers: Mapping[str, Callable[[Mapping[str, Any]], Mapping[str, Any]]],
        *,
        worker_id: str = "persistmind-coordinator",
    ) -> None:
        self.jobs = jobs
        self.handlers = dict(handlers)
        self.worker_id = worker_id

    def status(self) -> dict[str, Any]:
        rows = self.jobs.task.jobs(limit=1000)
        counts: dict[str, int] = {}
        for row in rows:
            state = str(row["state"])
            counts[state] = counts.get(state, 0) + 1
        return {
            "ok": True,
            "schema_version": "persistmind.repository_coordinator.v1",
            "worker_id": self.worker_id,
            "registered_job_kinds": sorted(self.handlers),
            "job_counts": dict(sorted(counts.items())),
        }

    def drain(self, *, max_jobs: int = 4, max_seconds: float = 2.0) -> dict[str, Any]:
        maximum = max(1, min(int(max_jobs), 64))
        deadline = time.monotonic() + max(0.05, min(float(max_seconds), 30.0))
        completed: list[str] = []
        failed: list[str] = []
        while len(completed) + len(failed) < maximum and time.monotonic() < deadline:
            result = self.jobs.drain(
                self.worker_id,
                self.handlers,
                limit=min(4, maximum - len(completed) - len(failed)),
            )
            completed.extend(result["completed"])
            failed.extend(result["failed"])
            if not result["completed"] and not result["failed"]:
                break
        return {
            "ok": not failed,
            "schema_version": "persistmind.repository_coordinator_drain.v1",
            "completed": completed,
            "failed": failed,
            "bounded_by": {"max_jobs": maximum, "max_seconds": max_seconds},
        }


def new_coordinator_token() -> str:
    return secrets.token_urlsafe(32)


def serve_loopback(
    coordinator: RepositoryCoordinator,
    *,
    token: str,
    host: str = "127.0.0.1",
    port: int = 0,
) -> ThreadingHTTPServer:
    if host not in {"127.0.0.1", "::1", "localhost"}:
        raise ValueError("repository coordinator may bind only to loopback")
    if len(token) < 32:
        raise ValueError("repository coordinator bearer token is too short")

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            if not self._authorized():
                return
            if self.path != "/v1/status":
                self.send_error(404)
                return
            self._reply(200, coordinator.status())

        def do_POST(self) -> None:
            if not self._authorized():
                return
            if self.path != "/v1/drain":
                self.send_error(404)
                return
            length = min(int(self.headers.get("Content-Length", "0") or 0), 4096)
            try:
                body = json.loads(self.rfile.read(length) or b"{}")
            except json.JSONDecodeError:
                self._reply(400, {"ok": False, "status": "invalid_json"})
                return
            self._reply(
                200,
                coordinator.drain(
                    max_jobs=int(body.get("max_jobs", 4)),
                    max_seconds=float(body.get("max_seconds", 2.0)),
                ),
            )

        def log_message(self, *_: Any) -> None:
            return

        def _authorized(self) -> bool:
            supplied = self.headers.get("Authorization", "").removeprefix("Bearer ")
            if not hmac.compare_digest(supplied, token):
                self._reply(401, {"ok": False, "status": "authentication_required"})
                return False
            return True

        def _reply(self, status: int, value: Mapping[str, Any]) -> None:
            payload = json.dumps(dict(value), sort_keys=True).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

    return ThreadingHTTPServer((host, port), Handler)


__all__ = ["RepositoryCoordinator", "new_coordinator_token", "serve_loopback"]
