from __future__ import annotations

import hashlib
import os
import shutil
from collections.abc import Callable
from pathlib import Path
from typing import Any

from persistmind.updater.atomic import read_json, write_json
from persistmind.utils import canonical_json, utc_now

PROTOCOL_SCHEMA = "persistmind.project_state_protocol.v2"


class ProjectProtocolMigration:
    """Staged, resumable protocol activation backed by a verified full-state copy."""

    def __init__(self, state_root: Path, backup_root: Path) -> None:
        self.state_root = state_root.resolve()
        self.backup_root = backup_root.resolve()
        if self.backup_root == self.state_root or self.backup_root.is_relative_to(self.state_root):
            raise ValueError("protocol backup root must be outside live project state")

    def prepare(
        self,
        migration_id: str,
        *,
        from_version: int,
        to_version: int,
        engine_version: str,
    ) -> dict[str, Any]:
        if from_version != 1 or to_version != 2:
            raise ValueError("only the explicit project protocol v1-to-v2 edge is supported")
        operation = self._operation(migration_id)
        existing = read_json(operation)
        if existing and existing.get("state") in {"prepared", "activated", "complete"}:
            self._verify_backup(existing)
            return existing
        backup = self.backup_root / migration_id / "project-state-v1"
        if backup.exists():
            shutil.rmtree(backup)
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(self.state_root, backup, symlinks=True)
        manifest = _tree_manifest(backup)
        stage = self.backup_root / migration_id / "stage"
        stage.mkdir(parents=True, exist_ok=True)
        protocol = {
            "schema_version": PROTOCOL_SCHEMA,
            "protocol_version": to_version,
            "engine_version": engine_version,
            "migration_id": migration_id,
            "activated_at": None,
        }
        write_json(stage / "protocol.json", protocol)
        document = {
            "schema_version": "persistmind.project_protocol_migration.v1",
            "migration_id": migration_id,
            "from_version": from_version,
            "to_version": to_version,
            "engine_version": engine_version,
            "state": "prepared",
            "backup": str(backup),
            "backup_manifest": manifest,
            "stage": str(stage / "protocol.json"),
            "plan_digest": hashlib.sha256(canonical_json(protocol).encode("utf-8")).hexdigest(),
            "updated_at": utc_now(),
        }
        write_json(operation, document)
        return document

    def activate(
        self,
        migration_id: str,
        *,
        activate_epoch: Callable[[int, str], Any] | None = None,
    ) -> dict[str, Any]:
        operation = self._operation(migration_id)
        document = read_json(operation)
        if not document:
            raise ValueError("protocol migration is not prepared")
        self._verify_backup(document)
        target = self.state_root / "protocol.json"
        if document.get("state") not in {"activated", "complete"}:
            staged = Path(str(document["stage"]))
            value = read_json(staged)
            if not value or int(value.get("protocol_version", 0)) != int(document["to_version"]):
                raise ValueError("staged project protocol marker is invalid")
            value["activated_at"] = utc_now()
            write_json(staged, value)
            target.parent.mkdir(parents=True, exist_ok=True)
            os.replace(staged, target)
            if activate_epoch is not None:
                activate_epoch(int(document["to_version"]), str(document["engine_version"]))
            document["state"] = "activated"
            document["activated_at"] = utc_now()
            document["updated_at"] = utc_now()
            write_json(operation, document)
        active = read_json(target)
        if not active or int(active.get("protocol_version", 0)) != int(document["to_version"]):
            raise ValueError("active project protocol marker does not verify")
        document["state"] = "complete"
        document["completed_at"] = utc_now()
        document["updated_at"] = utc_now()
        write_json(operation, document)
        return document

    def rollback(self, migration_id: str) -> dict[str, Any]:
        operation = self._operation(migration_id)
        document = read_json(operation)
        if not document:
            raise ValueError("protocol migration is unknown")
        backup = self._verify_backup(document)
        parent = self.state_root.parent
        restore = parent / f".{self.state_root.name}.restore-{migration_id}"
        failed = self.backup_root / migration_id / "failed-v2-state"
        if restore.exists():
            shutil.rmtree(restore)
        shutil.copytree(backup, restore, symlinks=True)
        if _tree_manifest(restore)["sha256"] != document["backup_manifest"]["sha256"]:
            shutil.rmtree(restore)
            raise ValueError("staged protocol rollback copy does not verify")
        if failed.exists():
            shutil.rmtree(failed)
        os.replace(self.state_root, failed)
        try:
            os.replace(restore, self.state_root)
        except Exception:
            os.replace(failed, self.state_root)
            raise
        document["state"] = "rolled_back"
        document["rolled_back_at"] = utc_now()
        document["updated_at"] = utc_now()
        write_json(self._operation(migration_id), document)
        return document

    def _operation(self, migration_id: str) -> Path:
        if not migration_id or any(
            char not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
            for char in migration_id
        ):
            raise ValueError("invalid protocol migration identity")
        path = self.state_root / "migration" / f"protocol-{migration_id}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    @staticmethod
    def _verify_backup(document: dict[str, Any]) -> Path:
        backup = Path(str(document.get("backup") or ""))
        expected = document.get("backup_manifest")
        if not backup.is_dir() or not isinstance(expected, dict):
            raise ValueError("project protocol backup is unavailable")
        if _tree_manifest(backup)["sha256"] != expected.get("sha256"):
            raise ValueError("project protocol backup is corrupt")
        return backup


def active_project_protocol(state_root: Path) -> int:
    value = read_json(Path(state_root) / "protocol.json")
    return int(value.get("protocol_version", 1)) if value else 1


def require_nextgen_protocol_v2(state_root: Path) -> None:
    root = Path(state_root)
    if not (root / "catalog" / "current.json").is_file() or active_project_protocol(root) < 2:
        error = RuntimeError(
            "architecture_upgrade_required: this feature requires an explicit project protocol v2 upgrade"
        )
        error.status = "architecture_upgrade_required"
        raise error


def _tree_manifest(root: Path) -> dict[str, Any]:
    entries: list[dict[str, Any]] = []
    for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix()):
        if path.is_symlink():
            entries.append(
                {"path": path.relative_to(root).as_posix(), "symlink": os.readlink(path)}
            )
        elif path.is_file():
            entries.append(
                {
                    "path": path.relative_to(root).as_posix(),
                    "size": path.stat().st_size,
                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                }
            )
    return {
        "schema_version": "persistmind.project_state_backup.v1",
        "entries": entries,
        "sha256": hashlib.sha256(canonical_json(entries).encode("utf-8")).hexdigest(),
    }


__all__ = [
    "PROTOCOL_SCHEMA",
    "ProjectProtocolMigration",
    "active_project_protocol",
    "require_nextgen_protocol_v2",
]
