from __future__ import annotations

import hashlib
import json
import re
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Literal, overload

from persistmind.repo_identity import canonical_repo_identity


IDENTITY_SCHEMA = "persistmind.repository_context.v1"


class RepositoryContextError(RuntimeError):
    """A repository, workspace, or source-view identity could not be proven."""


@dataclass(frozen=True, slots=True)
class RepositoryContext:
    repository_id: str
    workspace_id: str
    source_view_id: str
    repository_root: Path
    git_common_dir: Path
    git_worktree_dir: Path
    head_oid: str
    dirty_digest: str
    provenance_digest: str
    schema_version: str = IDENTITY_SCHEMA

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        for key in ("repository_root", "git_common_dir", "git_worktree_dir"):
            value[key] = str(value[key])
        return value


def repository_context(repo: Path) -> RepositoryContext:
    root = _git(repo, "rev-parse", "--show-toplevel", path=True)
    common = _git(root, "rev-parse", "--git-common-dir", path=True)
    worktree_dir = _git(root, "rev-parse", "--git-dir", path=True)
    existing = canonical_repo_identity(root).document
    common_identity = existing["git_common_dir"]
    worktree_identity = existing["worktree"]
    provenance = _provenance(root)
    repository_id = _digest(
        {
            "schema": IDENTITY_SCHEMA,
            "git_common_dir": common_identity,
            "provenance": provenance,
        }
    )
    workspace_id = _digest(
        {
            "schema": IDENTITY_SCHEMA,
            "repository_id": repository_id,
            "worktree": worktree_identity,
            "git_worktree_dir": existing["git_worktree_dir"],
        }
    )
    head_candidate = _git(root, "rev-parse", "HEAD", check=False)
    head_oid = (
        head_candidate
        if isinstance(head_candidate, str) and re.fullmatch(r"[0-9a-f]{40,64}", head_candidate)
        else "0" * 40
    )
    dirty_digest = _dirty_digest(root, unborn=head_oid == "0" * 40)
    source_view_id = _digest(
        {
            "schema": IDENTITY_SCHEMA,
            "workspace_id": workspace_id,
            "head_oid": head_oid,
            "dirty_digest": dirty_digest,
        }
    )
    return RepositoryContext(
        repository_id=repository_id,
        workspace_id=workspace_id,
        source_view_id=source_view_id,
        repository_root=root,
        git_common_dir=common,
        git_worktree_dir=worktree_dir,
        head_oid=head_oid,
        dirty_digest=dirty_digest,
        provenance_digest=_digest(provenance),
    )


def _provenance(repo: Path) -> dict[str, Any]:
    raw = _git(repo, "remote", "-v", check=False)
    remotes: list[tuple[str, str, str]] = []
    for line in raw.splitlines():
        parts = line.split()
        if len(parts) >= 3:
            remotes.append((parts[0], _normalize_remote(parts[1]), parts[2]))
    return {"remotes": sorted(set(remotes))}


def _normalize_remote(value: str) -> str:
    # Strip URL credentials while retaining stable repository provenance.
    if "://" in value:
        scheme, remainder = value.split("://", 1)
        if "@" in remainder:
            remainder = remainder.split("@", 1)[1]
        value = f"{scheme.lower()}://{remainder}"
    return value.rstrip("/").removesuffix(".git").casefold()


def _dirty_digest(repo: Path, *, unborn: bool = False) -> str:
    if unborn:
        tracked = _git_bytes(repo, "diff", "--binary", "--no-ext-diff", "--cached", "--")
        tracked += _git_bytes(repo, "diff", "--binary", "--no-ext-diff", "--")
    else:
        tracked = _git_bytes(repo, "diff", "--binary", "--no-ext-diff", "HEAD", "--")
    untracked = _git(
        repo,
        "ls-files",
        "--others",
        "--exclude-standard",
        "-z",
        check=False,
    )
    untracked_rows: list[dict[str, str | int]] = []
    for raw in untracked.split("\0"):
        if not raw:
            continue
        normalized = raw.replace("\\", "/")
        if normalized in {".persistmind"} or normalized.startswith((".persistmind/",)):
            continue
        path = repo / raw
        if not path.is_file():
            continue
        digest = hashlib.sha256()
        size = 0
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                size += len(block)
                digest.update(block)
        untracked_rows.append({"path": normalized, "bytes": size, "sha256": digest.hexdigest()})
    try:
        tracked_identity: str | dict[str, int | str] = tracked.decode("utf-8")
    except UnicodeDecodeError:
        tracked_identity = {
            "bytes": len(tracked),
            "sha256": hashlib.sha256(tracked).hexdigest(),
        }
    return _digest(
        {
            "tracked_patch": tracked_identity,
            "untracked": sorted(untracked_rows, key=lambda row: str(row["path"])),
        }
    )


def _git_bytes(repo: Path, *arguments: str, check: bool = True) -> bytes:
    """Return byte-oriented Git output without assuming patch content encoding."""

    completed = subprocess.run(
        ["git", "-C", str(repo), *arguments],
        check=False,
        capture_output=True,
        timeout=30,
    )
    if check and completed.returncode != 0:
        detail = completed.stderr.decode("utf-8", errors="replace").strip()
        raise RepositoryContextError(detail or "git repository identity unavailable")
    return completed.stdout


@overload
def _git(
    repo: Path,
    *arguments: str,
    path: Literal[True],
    check: bool = True,
) -> Path: ...


@overload
def _git(
    repo: Path,
    *arguments: str,
    path: Literal[False] = False,
    check: bool = True,
) -> str: ...


def _git(
    repo: Path,
    *arguments: str,
    path: bool = False,
    check: bool = True,
) -> str | Path:
    completed = subprocess.run(
        ["git", "-C", str(repo), *arguments],
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="strict",
        timeout=30,
    )
    if check and completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip()
        raise RepositoryContextError(detail or "git repository identity unavailable")
    value = completed.stdout.strip()
    if not path:
        return value
    candidate = Path(value)
    if not candidate.is_absolute():
        candidate = repo / candidate
    try:
        return candidate.resolve(strict=True)
    except OSError as exc:
        raise RepositoryContextError(f"repository identity path unavailable: {candidate}") from exc


def _digest(value: Any) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


__all__ = [
    "IDENTITY_SCHEMA",
    "RepositoryContext",
    "RepositoryContextError",
    "repository_context",
]
