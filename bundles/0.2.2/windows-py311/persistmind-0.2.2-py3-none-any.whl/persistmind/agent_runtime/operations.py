from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from collections.abc import Mapping
from dataclasses import asdict
from pathlib import Path
from typing import Any, Literal, cast

from persistmind.branding import resolve_project_state

OPERATIONS = (
    "contract-show",
    "contract-verify",
    "status",
    "health",
    "drain",
    "leases",
    "grant-issue",
    "grant-revoke",
    "events",
    "dead-letters",
    "retry",
    "refresh",
    "source-status",
    "source-gc",
    "cache-status",
    "cache-drop",
    "cache-gc",
    "plugin-list",
    "plugin-trust",
    "plugin-revoke",
    "plugin-validate",
    "plugin-install",
    "plugin-disable",
    "plugin-enable",
    "plugin-uninstall",
    "plugin-repair",
    "plugin-diff",
    "plugin-inventory",
    "plugin-precedence",
    "setup-grok",
    "grok-readiness",
    "launch",
    "resume",
    "cancel",
    "agent-status",
    "acp-start",
    "acp-resume",
    "acp-cancel",
    "acp-status",
    "prepare",
    "merge",
    "release",
    "worktree-gc",
    "route",
    "route-explain",
    "catalog-status",
    "artifact-resolve",
    "artifact-fetch",
    "artifact-verify",
    "migrate",
    "verify",
    "rollback",
    "reconcile",
    "qualify",
    "qualification-status",
)


def run_agent_runtime_operation(
    repo: Path, operation: str, request: Mapping[str, Any]
) -> dict[str, Any]:
    root = Path(repo).resolve()
    payload = dict(request)
    if operation not in OPERATIONS:
        raise ValueError(f"unsupported agent-runtime operation: {operation}")
    if operation in {"contract-show", "contract-verify"}:
        from .contracts import contract_digest, load_runtime_contract

        contract = load_runtime_contract()
        return {
            "ok": True,
            "schema_version": "persistmind.agent_runtime_contract_status.v1",
            "contract_digest": contract_digest(contract),
            **({"contract": contract} if operation == "contract-show" else {}),
        }
    if operation in {"cache-status", "cache-drop", "cache-gc"}:
        from .cache import RuntimeCache

        cache = RuntimeCache(resolve_project_state(root))
        if operation == "cache-status":
            return dict(cache.status())
        if operation == "cache-drop":
            return dict(cache.drop(str(payload.get("namespace") or "") or None))
        return dict(cache.gc())
    if operation in {"refresh", "source-status", "source-gc"}:
        from persistmind.storage.source_service import SourceService

        with SourceService(root) as source:
            if operation == "refresh":
                return source.build()
            if operation == "source-status":
                return source.status()
            return source.prune_generations(
                keep=int(payload.get("keep", 3)),
                pinned=[str(item) for item in payload.get("pinned", [])],
                dry_run=bool(payload.get("dry_run", True)),
            )
    if operation.startswith("plugin-"):
        return _plugin_operation(root, operation, payload)
    if operation in {"grok-readiness", "setup-grok"}:
        if operation == "grok-readiness":
            from persistmind.agents.adapters.grok import GrokAdapter
            from persistmind.storage.agent_runtime_ports import AgentRuntimePorts

            with AgentRuntimePorts(root) as ports:
                return dict(GrokAdapter().readiness(root, trust=ports.plugin_trust))
        from persistmind.composition.registry import OperationClient

        with OperationClient(root) as service:
            return service.setup(
                ["grok"],
                mcp_command=str(payload.get("mcp_command") or "persistmind"),
                install_hooks=True,
                configure_mcp=True,
                absolute_mcp_repo=True,
                skip_index=True,
            )
    if operation in {"artifact-resolve", "artifact-fetch", "artifact-verify"}:
        return _artifact_operation(root, operation, payload)
    if operation in {"migrate", "verify", "rollback", "reconcile"}:
        return _protocol_operation(root, operation, payload)
    if operation in {"qualify", "qualification-status"}:
        return _qualification_operation(root, operation, payload)

    from persistmind.storage.agent_runtime_ports import AgentRuntimePorts

    with AgentRuntimePorts(root) as ports:
        return _runtime_port_operation(root, operation, payload, ports)


def _runtime_port_operation(
    root: Path, operation: str, payload: dict[str, Any], ports: Any
) -> dict[str, Any]:
    from .events import AgentEventJournal, AgentEventProjector
    from .grants import ExecutionGrantService
    from .hooks import drain_hook_observations
    from .identity import repository_context
    from .worktrees import MergeTransaction, WorktreeTransaction

    context = repository_context(root)
    grants = ExecutionGrantService(ports.task, context)
    if operation in {"status", "health"}:
        return {
            "ok": True,
            "schema_version": "persistmind.agent_runtime_status.v1",
            "protocol": ports.task.runtime_epoch(),
            "jobs": list(ports.task.jobs(limit=int(payload.get("limit", 100)))),
            "unsettled_agent_events": ports.activity.unsettled_agent_event_count(),
            "external_runs": list(ports.task.external_runs(limit=20)),
            "acp_sessions": list(ports.task.acp_sessions(limit=20)),
            "worktree_leases": list(ports.task.worktree_leases(limit=20)),
        }
    if operation == "leases":
        return {
            "ok": True,
            "schema_version": "persistmind.worktree_lease_list.v1",
            "leases": list(ports.task.worktree_leases(limit=int(payload.get("limit", 100)))),
        }
    if operation == "grant-issue":
        issued = grants.issue(
            workflow_id=_required(payload, "workflow_id"),
            actions=[str(item) for item in payload.get("actions", ["process.launch"])],
            path_scopes=[str(item) for item in payload.get("path_scopes", [])],
            process_scopes=[str(item) for item in payload.get("process_scopes", [])],
            network_scopes=[str(item) for item in payload.get("network_scopes", [])],
            ttl_seconds=int(payload.get("ttl_seconds", 900)),
            max_uses=int(payload.get("max_uses", 1)),
        )
        return {
            "ok": True,
            "schema_version": issued.schema_version,
            "grant_id": issued.grant_id,
            "grant_token": issued.token,
            "expires_at": issued.expires_at,
        }
    if operation == "grant-revoke":
        return {
            "ok": grants.revoke(_required(payload, "grant_id")),
            "schema_version": "persistmind.execution_grant_revocation.v1",
        }
    if operation == "events":
        return {
            "ok": True,
            "schema_version": "persistmind.agent_event_list.v1",
            "events": list(
                ports.activity.agent_events(
                    stream_id=str(payload.get("stream_id") or "") or None,
                    state=str(payload.get("state") or "") or None,
                    limit=int(payload.get("limit", 100)),
                )
            ),
        }
    if operation == "dead-letters":
        return {
            "ok": True,
            "schema_version": "persistmind.agent_event_dead_letter_list.v1",
            "dead_letters": list(ports.activity.dead_letters(limit=int(payload.get("limit", 100)))),
        }
    if operation in {"drain", "retry"}:
        requeued: list[str] = []
        if operation == "retry":
            requeued = list(
                ports.activity.requeue_dead_letters(
                    event_ids=[str(item) for item in payload.get("event_ids", [])],
                    limit=int(payload.get("limit", 1000)),
                )
            )
        hook = drain_hook_observations(root, limit=int(payload.get("limit", 1000)), ports=ports)
        projection = AgentEventProjector(ports.activity, ports.audit).drain(
            limit=int(payload.get("limit", 1000))
        )
        return {
            "ok": bool(hook["ok"] and projection["ok"]),
            "schema_version": "persistmind.agent_runtime_drain.v1",
            "hook_observations": hook,
            "projection": projection,
            "requeued_dead_letters": requeued,
        }
    if operation in {"route", "route-explain", "catalog-status"}:
        from .routing import ModelRouter

        router = ModelRouter(task=ports.task)
        if operation == "catalog-status":
            return {
                "ok": True,
                "schema_version": "persistmind.model_catalog_status.v1",
                "catalog": router.catalog,
            }
        return router.route(
            role=str(payload.get("role") or "implement"),
            task_class=str(payload.get("task_class") or "coding"),
            risk=str(payload.get("risk") or "normal"),
            sensitive=bool(payload.get("sensitive", False)),
            requested_model=str(payload.get("requested_model") or "") or None,
            policy_models=[str(item) for item in payload.get("policy_models", [])],
            available_providers=[str(item) for item in payload.get("available_providers", [])]
            or None,
            orchestration_id=_required(payload, "orchestration_id"),
            policy_revision=str(payload.get("policy_revision") or "default"),
            adapter_id=str(payload.get("adapter") or "") or None,
            required_capabilities=[str(item) for item in payload.get("required_capabilities", [])],
            required_context_tokens=int(payload.get("required_context_tokens", 0)),
            max_cost_usd=(
                float(payload["max_cost_usd"]) if payload.get("max_cost_usd") is not None else None
            ),
            max_turns=(int(payload["max_turns"]) if payload.get("max_turns") is not None else None),
            usage=dict(payload.get("usage") or {}),
            adapter_enforces_model=bool(payload.get("adapter_enforces_model", True)),
        )
    worktrees = WorktreeTransaction(context, task=ports.task)
    if operation == "prepare":
        return _lease_document(
            worktrees.prepare(
                _required(payload, "task_id"),
                mode=_worktree_mode(payload.get("mode")),
            ),
            include_owner_token=True,
        )
    if operation == "release":
        lease = _stored_lease(
            ports.task,
            _required(payload, "lease_id"),
            owner_token=_lease_token(payload),
        )
        return worktrees.release(lease, force=bool(payload.get("force", False)))
    if operation == "worktree-gc":
        released = []
        for row in ports.task.worktree_leases(limit=int(payload.get("limit", 100))):
            if str(row.get("state")) != "active":
                continue
            lease = _stored_lease(ports.task, str(row["lease_id"]), owner_token="recovery")
            if not lease.path.exists():
                ports.task.update_worktree_lease(lease.lease_id, state="orphaned")
                released.append(lease.lease_id)
        return {"ok": True, "schema_version": "persistmind.worktree_gc.v1", "orphaned": released}
    if operation == "merge":
        return MergeTransaction(context).integrate(
            _required(payload, "commit_oid"),
            strategy=_merge_strategy(payload.get("strategy")),
        )
    redaction_key = hashlib.sha256(
        (context.repository_id + os.environ.get("USERNAME", "local")).encode()
    ).digest()
    journal = AgentEventJournal(ports.activity, context, redaction_key=redaction_key)
    if operation in {"launch", "resume", "cancel", "agent-status"}:
        from .external import ExternalAgentOrchestrator, adapter_registry

        external_orchestrator = ExternalAgentOrchestrator(
            ports.task, journal, context, grants, worktrees
        )
        if operation == "agent-status":
            return {
                "ok": True,
                "schema_version": "persistmind.external_agent_status.v1",
                "runs": list(ports.task.external_runs(limit=int(payload.get("limit", 100)))),
            }
        if operation == "cancel":
            return external_orchestrator.cancel(_required(payload, "run_id"))
        adapter_id = str(payload.get("adapter") or "codex")
        adapter = adapter_registry().get(adapter_id)
        if adapter is None:
            raise ValueError(f"unknown external agent adapter: {adapter_id}")
        return external_orchestrator.launch(
            orchestration_id=_required(payload, "orchestration_id"),
            adapter=adapter,
            prompt=_required(payload, "prompt"),
            grant_token=_grant_token(payload),
            workflow_id=_required(payload, "workflow_id"),
            model=str(payload.get("model") or "") or None,
            model_route_id=str(payload.get("model_route_id") or "") or None,
            session_reference=(
                _required(payload, "session_reference") if operation == "resume" else None
            ),
            timeout_seconds=int(payload.get("timeout_seconds", 900)),
            idempotency_key=str(payload.get("idempotency_key") or "") or None,
            role=str(payload.get("role") or "implement"),
            task_class=str(payload.get("task_class") or "coding"),
            risk=str(payload.get("risk") or "normal"),
            sensitive=bool(payload.get("sensitive", False)),
            policy_models=[str(item) for item in payload.get("policy_models", [])],
            required_context_tokens=int(payload.get("required_context_tokens", 0)),
            max_cost_usd=(
                float(payload["max_cost_usd"]) if payload.get("max_cost_usd") is not None else None
            ),
            max_turns=(int(payload["max_turns"]) if payload.get("max_turns") is not None else None),
            usage=dict(payload.get("usage") or {}),
            policy_revision=str(payload.get("policy_revision") or "default"),
        )
    if operation in {"acp-start", "acp-resume", "acp-cancel", "acp-status"}:
        from .acp import ACPClientOrchestrator

        if operation == "acp-status":
            return {
                "ok": True,
                "schema_version": "persistmind.acp_status.v1",
                "sessions": list(ports.task.acp_sessions(limit=int(payload.get("limit", 100)))),
            }
        if operation == "acp-cancel":
            from .external import terminate_process_id

            session = ports.task.acp_session(_required(payload, "connection_id"))
            if session is None:
                raise KeyError("unknown ACP connection")
            process = ports.task.runtime_process("acp", str(session["connection_id"]))
            process_id = int((process or {}).get("process_id") or 0)
            signalled = terminate_process_id(process_id) if process_id > 0 else False
            ports.task.clear_runtime_process("acp", str(session["connection_id"]))
            updated = ports.task.update_acp_session(
                str(session["connection_id"]), state="cancelled", values={}
            )
            return {
                "ok": True,
                "schema_version": "persistmind.acp_cancel.v1",
                "session": updated,
                "process_signal": "persisted_process_id" if signalled else "not_running",
                "signalled": signalled,
            }
        acp_orchestrator = ACPClientOrchestrator(
            ports.task,
            journal,
            context,
            grants,
            worktrees,
            permission_decider=_acp_permission_decider(root),
        )
        prompt = str(payload.get("prompt") or "").strip()
        if not prompt:
            raise ValueError("ACP start/resume requires a prompt for its active CLI lifetime")
        connection = acp_orchestrator.start(
            orchestration_id=_required(payload, "orchestration_id"),
            agent_command=[str(item) for item in payload.get("agent_command", [])],
            grant_token=_grant_token(payload),
            workflow_id=_required(payload, "workflow_id"),
            mcp_servers=list(payload.get("mcp_servers", [])),
            session_reference=(
                _required(payload, "session_reference") if operation == "acp-resume" else None
            ),
        )
        prompt_result = acp_orchestrator.prompt(
            connection,
            None,
            prompt,
            timeout_seconds=int(payload.get("timeout_seconds", 900)),
        )
        suspended = acp_orchestrator.suspend(connection)
        return {
            "ok": True,
            "schema_version": "persistmind.acp_operation.v1",
            "connection": _acp_connection_document(connection),
            "prompt": prompt_result,
            "session": suspended,
        }
    raise ValueError(f"operation is not wired: {operation}")


def _plugin_operation(root: Path, operation: str, payload: dict[str, Any]) -> dict[str, Any]:
    from persistmind.storage.agent_runtime_ports import AgentRuntimePorts

    from .plugins import PLUGIN_PRECEDENCE, PluginRegistry, descriptor_document

    roots = [Path(str(item)).expanduser().resolve() for item in payload.get("roots", [])]
    if payload.get("root"):
        roots.append(Path(str(payload["root"])).expanduser().resolve())
    with AgentRuntimePorts(root) as ports:
        registry = PluginRegistry(ports.plugin_trust)
        if operation == "plugin-precedence":
            return {
                "ok": True,
                "schema_version": "persistmind.plugin_precedence.v1",
                "precedence": list(PLUGIN_PRECEDENCE),
            }
        if operation in {"plugin-install", "plugin-repair"}:
            source = Path(_required(payload, "source")).expanduser().resolve(strict=True)
            target = Path(_required(payload, "target")).expanduser().resolve()
            descriptor = (
                registry.install_transaction(source, target)
                if operation == "plugin-install"
                else registry.repair(
                    source,
                    target,
                    recover_modified=bool(payload.get("recover_modified", False)),
                )
            )
            return {
                "ok": True,
                "schema_version": "persistmind.plugin_operation.v1",
                "plugins": [descriptor_document(descriptor)],
            }
        if operation == "plugin-list":
            descriptors = registry.discover(roots)
        else:
            if len(roots) != 1:
                raise ValueError(f"{operation} requires exactly one plugin root")
            descriptor = registry.inspect(roots[0])
            if operation == "plugin-trust":
                approval = payload.get("approval")
                if not isinstance(approval, Mapping):
                    raise PermissionError("plugin trust requires a signed Policy approval")
                descriptor = registry.trust_plugin(descriptor, approval=approval)
            elif operation == "plugin-revoke":
                approval = payload.get("approval")
                if not isinstance(approval, Mapping):
                    raise PermissionError("plugin revocation requires a signed Policy approval")
                descriptor = registry.revoke(
                    descriptor,
                    reason=str(payload.get("reason") or "operator revoked"),
                    approval=approval,
                )
            elif operation == "plugin-disable":
                descriptor = registry.disable(
                    roots[0], reason=str(payload.get("reason") or "operator disabled")
                )
            elif operation == "plugin-enable":
                descriptor = registry.enable(roots[0])
            elif operation == "plugin-uninstall":
                return registry.uninstall(
                    roots[0], recover_modified=bool(payload.get("recover_modified", False))
                )
            elif operation == "plugin-diff":
                return {"ok": True, **registry.diff(roots[0])}
            elif operation == "plugin-inventory":
                return {"ok": True, **registry.inventory(roots[0])}
            descriptors = [descriptor]
        return {
            "ok": True,
            "schema_version": "persistmind.plugin_operation.v1",
            "plugins": [descriptor_document(item) for item in descriptors],
        }


def _artifact_operation(root: Path, operation: str, payload: dict[str, Any]) -> dict[str, Any]:
    from persistmind.updater.artifacts import ArtifactReference, ArtifactResolver

    artifact = payload.get("artifact")
    if not isinstance(artifact, Mapping):
        raise ValueError("artifact operation requires a manifest artifact object")
    reference = ArtifactReference.from_manifest(artifact)
    if operation == "artifact-resolve":
        return {
            "ok": True,
            "schema_version": "persistmind.artifact_resolution.v1",
            "reference": asdict(reference),
        }
    destination = Path(str(payload.get("destination") or reference.filename))
    if not destination.is_absolute():
        destination = (root / destination).resolve()
    if operation == "artifact-fetch":
        fetched = ArtifactResolver().fetch(artifact, destination)
    else:
        fetched = destination
        if (
            not fetched.is_file()
            or fetched.stat().st_size != reference.size
            or _sha256(fetched) != reference.sha256
        ):
            raise ValueError("local artifact does not match the signed manifest binding")
    return {
        "ok": True,
        "schema_version": "persistmind.artifact_verification.v1",
        "path": str(fetched),
        "sha256": reference.sha256,
        "size": reference.size,
    }


def _protocol_operation(root: Path, operation: str, payload: dict[str, Any]) -> dict[str, Any]:
    if operation == "migrate":
        from persistmind.update.project_upgrade import apply_upgrade

        return apply_upgrade(root, _required(payload, "transaction_id"))
    if operation in {"verify", "reconcile"}:
        from persistmind.update.project_upgrade import verify_upgrade

        return verify_upgrade(root, _required(payload, "transaction_id"))
    from .protocol import ProjectProtocolMigration

    backup_root = Path(
        str(payload.get("backup_root") or (root.parent / ".persistmind-protocol-backups"))
    )
    return ProjectProtocolMigration(resolve_project_state(root), backup_root).rollback(
        _required(payload, "transaction_id")
    )


def _qualification_operation(root: Path, operation: str, payload: dict[str, Any]) -> dict[str, Any]:
    evidence = root / "docs" / "generated" / "agent-runtime-qualification.v1.json"
    if operation == "qualification-status":
        if not evidence.is_file():
            return {
                "ok": False,
                "status": "unavailable",
                "schema_version": "persistmind.agent_runtime_qualification_status.v1",
            }
        return json.loads(evidence.read_text(encoding="utf-8"))
    script = root / "scripts" / "run_agent_runtime_qualification.py"
    if not script.is_file():
        raise FileNotFoundError(
            "agent-runtime qualification script is unavailable in this installation"
        )
    command = [sys.executable, str(script)]
    if payload.get("require_promotion"):
        command.append("--require-promotion")
    completed = subprocess.run(
        command,
        cwd=root,
        check=False,
        capture_output=True,
        text=True,
        timeout=int(payload.get("timeout_seconds", 3600)),
    )
    if completed.returncode != 0:
        raise RuntimeError(
            completed.stderr.strip()
            or completed.stdout.strip()
            or "agent-runtime qualification failed"
        )
    return json.loads(evidence.read_text(encoding="utf-8"))


def _stored_lease(task: Any, lease_id: str, *, owner_token: str) -> Any:
    from .worktrees import WorktreeLease

    row = task.worktree_lease(lease_id)
    if row is None:
        raise KeyError(f"unknown worktree lease: {lease_id}")
    metadata = dict(row.get("metadata") or {})
    return WorktreeLease(
        lease_id=str(row["lease_id"]),
        task_id=str(row["owner_session_id"]),
        path=Path(str(metadata["path"])),
        state_root=Path(str(metadata.get("state_root") or "")),
        pinned_oid=str(row["pinned_oid"]),
        source_view_id=str(row["source_view_id"]),
        mode=_worktree_mode(row["mode"]),
        dirty_patch_digest=str(metadata.get("dirty_patch_digest") or ""),
        created_at=str(row["created_at"]),
        expires_at=str(row["expires_at"]),
        owner_token=owner_token,
        fencing_token=int(metadata.get("fencing_token") or 0),
    )


def _lease_document(lease: Any, *, include_owner_token: bool = False) -> dict[str, Any]:
    result = {
        "ok": True,
        "schema_version": lease.schema_version,
        "lease_id": lease.lease_id,
        "task_id": lease.task_id,
        "path": str(lease.path),
        "state_root": str(lease.state_root),
        "pinned_oid": lease.pinned_oid,
        "source_view_id": lease.source_view_id,
        "mode": lease.mode,
        "dirty_patch_digest": lease.dirty_patch_digest,
        "created_at": lease.created_at,
        "expires_at": lease.expires_at,
        "fencing_token": lease.fencing_token,
    }
    if include_owner_token:
        result["lease_token"] = lease.owner_token
    return result


def _acp_connection_document(connection: Any) -> dict[str, Any]:
    return {
        "connection_id": connection.connection_id,
        "session_id": connection.session_id,
        "protocol_version": connection.protocol_version,
        "capabilities": dict(connection.capabilities),
        "worktree": _lease_document(connection.worktree),
    }


def _grant_token(payload: Mapping[str, Any]) -> str:
    env_name = str(payload.get("grant_token_env") or "PERSISTMIND_EXECUTION_GRANT")
    token = os.environ.get(env_name)
    if not token:
        raise PermissionError(
            f"execution grant token is absent from environment variable {env_name}"
        )
    return token


def _lease_token(payload: Mapping[str, Any]) -> str:
    direct = str(payload.get("lease_token") or "")
    env_name = str(payload.get("lease_token_env") or "PERSISTMIND_WORKTREE_LEASE_TOKEN")
    token = direct or os.environ.get(env_name, "")
    if not token:
        raise PermissionError("worktree lease owner token is required")
    return token


def _acp_permission_decider(root: Path) -> Any:
    from .hooks import evaluate_fast_hook

    def decide(request: Mapping[str, Any]) -> str | None:
        tool_call = request.get("toolCall")
        call = dict(tool_call) if isinstance(tool_call, Mapping) else {}
        result = evaluate_fast_hook(
            root,
            "PreToolUse",
            {
                "tool_name": str(call.get("title") or call.get("kind") or "ACPTool"),
                "tool_input": dict(call.get("content") or {})
                if isinstance(call.get("content"), Mapping)
                else {},
                "session_id": request.get("sessionId"),
            },
        )
        if result.get("decision") != "allow":
            return None
        options = request.get("options")
        if not isinstance(options, list):
            return None
        candidates = []
        for option in options:
            if not isinstance(option, Mapping):
                continue
            option_id = str(option.get("optionId") or option.get("option_id") or "")
            kind = str(option.get("kind") or option.get("name") or option_id).casefold()
            if option_id and "allow" in kind:
                candidates.append(("once" not in kind, option_id))
        return sorted(candidates)[0][1] if candidates else None

    return decide


def _required(payload: Mapping[str, Any], key: str) -> str:
    value = str(payload.get(key) or "").strip()
    if not value:
        raise ValueError(f"agent-runtime request requires {key}")
    return value


def _worktree_mode(value: Any) -> Literal["clean_tracked", "preserve_dirty", "clean_all"]:
    mode = str(value or "clean_tracked")
    if mode == "clean_tracked" or mode == "preserve_dirty" or mode == "clean_all":
        return cast(Literal["clean_tracked", "preserve_dirty", "clean_all"], mode)
    raise ValueError(f"unsupported worktree mode: {mode}")


def _merge_strategy(value: Any) -> Literal["cherry-pick", "merge"]:
    strategy = str(value or "cherry-pick")
    if strategy == "cherry-pick" or strategy == "merge":
        return cast(Literal["cherry-pick", "merge"], strategy)
    raise ValueError(f"unsupported merge strategy: {strategy}")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


__all__ = ["OPERATIONS", "run_agent_runtime_operation"]
