from __future__ import annotations

import hashlib
import json
import secrets
from dataclasses import dataclass
from typing import Any, Callable, Mapping

from persistmind.application.agent_runtime_ports import AgentRuntimeTaskPort
from persistmind.utils import stable_id

from .identity import RepositoryContext


@dataclass(frozen=True, slots=True)
class JobLease:
    job: Mapping[str, Any]
    worker_id: str
    claim_secret: str

    @property
    def fencing_token(self) -> int:
        return int(self.job["fencing_token"])


class DurableJobService:
    def __init__(self, task: AgentRuntimeTaskPort, context: RepositoryContext) -> None:
        self.task = task
        self.context = context

    def enqueue(
        self,
        kind: str,
        payload: Mapping[str, Any],
        *,
        idempotency_key: str | None = None,
        priority: int = 0,
        max_attempts: int = 3,
    ) -> Mapping[str, Any]:
        normalized = json.dumps(dict(payload), sort_keys=True, separators=(",", ":"), default=str)
        digest = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
        identity = idempotency_key or digest
        return self.task.enqueue_job(
            {
                "job_id": "job_" + stable_id(kind, self.context.repository_id, identity)[:40],
                "job_kind": kind,
                "repository_id": self.context.repository_id,
                "workspace_id": self.context.workspace_id,
                "source_view_id": self.context.source_view_id,
                "payload": dict(payload),
                "payload_digest": digest,
                "priority": max(-100, min(int(priority), 100)),
                "max_attempts": max(1, min(int(max_attempts), 20)),
            }
        )

    def claim(self, worker_id: str, *, limit: int = 1, lease_ms: int = 30000) -> list[JobLease]:
        secret = secrets.token_urlsafe(32)
        digest = _secret_hash(secret)
        return [
            JobLease(job=job, worker_id=worker_id, claim_secret=secret)
            for job in self.task.claim_jobs(
                worker_id=worker_id,
                claim_token_hash=digest,
                limit=max(1, min(limit, 4)),
                lease_ms=lease_ms,
            )
        ]

    def renew(self, lease: JobLease, *, lease_ms: int = 30000) -> Mapping[str, Any]:
        return self.task.renew_job(
            str(lease.job["job_id"]),
            worker_id=lease.worker_id,
            claim_token_hash=_secret_hash(lease.claim_secret),
            fencing_token=lease.fencing_token,
            lease_ms=lease_ms,
        )

    def complete(self, lease: JobLease, result: Mapping[str, Any]) -> Mapping[str, Any]:
        return self._finish(lease, state="completed", result=result)

    def fail(self, lease: JobLease, error: str, *, retry: bool = False) -> Mapping[str, Any]:
        state = (
            "pending"
            if retry and int(lease.job["attempt_count"]) < int(lease.job["max_attempts"])
            else "failed"
        )
        return self._finish(lease, state=state, error=error)

    def cancel(self, job_id: str) -> Mapping[str, Any]:
        return self.task.cancel_job(job_id)

    def drain(
        self,
        worker_id: str,
        handlers: Mapping[str, Callable[[Mapping[str, Any]], Mapping[str, Any]]],
        *,
        limit: int = 4,
    ) -> dict[str, Any]:
        completed, failed = [], []
        for lease in self.claim(worker_id, limit=limit):
            kind = str(lease.job["job_kind"])
            handler = handlers.get(kind)
            if handler is None:
                self.fail(lease, f"no handler registered for {kind}")
                failed.append(str(lease.job["job_id"]))
                continue
            try:
                result = handler(dict(lease.job["payload"]))
                self.complete(lease, result)
                completed.append(str(lease.job["job_id"]))
            except Exception as exc:  # noqa: BLE001 - durable worker records bounded failure text.
                self.fail(lease, str(exc), retry=True)
                failed.append(str(lease.job["job_id"]))
        return {
            "ok": not failed,
            "schema_version": "persistmind.agent_runtime_drain.v1",
            "completed": completed,
            "failed": failed,
        }

    def _finish(
        self,
        lease: JobLease,
        *,
        state: str,
        result: Mapping[str, Any] | None = None,
        error: str | None = None,
    ) -> Mapping[str, Any]:
        return self.task.finish_job(
            str(lease.job["job_id"]),
            worker_id=lease.worker_id,
            claim_token_hash=_secret_hash(lease.claim_secret),
            fencing_token=lease.fencing_token,
            state=state,
            result=result,
            error=error,
        )


def _secret_hash(secret: str) -> str:
    return hashlib.sha256(("persistmind-job-v1\0" + secret).encode("utf-8")).hexdigest()


__all__ = ["DurableJobService", "JobLease"]
