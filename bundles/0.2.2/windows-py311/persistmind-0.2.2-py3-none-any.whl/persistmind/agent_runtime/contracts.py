from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from importlib.resources import files
from pathlib import Path
from typing import Any

CONTRACT_SCHEMA = "persistmind.agent_runtime_registry.v1"
PACKAGE_IDS = tuple(["ARP-00", "ARP-00A", "ARP-00B", *[f"ARP-{n:02d}" for n in range(1, 13)]])
REQUIRED_PACKAGE_FIELDS = frozenset(
    {
        "owner",
        "profile",
        "schema",
        "authority",
        "stores",
        "events",
        "budgets",
        "fallback",
        "disable",
        "operations",
        "qualification",
    }
)


def load_runtime_contract() -> dict[str, Any]:
    resource = files("persistmind.agent_runtime.resources").joinpath(
        "implementation-registry.v1.json"
    )
    document = json.loads(resource.read_text(encoding="utf-8"))
    validate_runtime_contract(document)
    return document


def validate_runtime_contract(document: Mapping[str, Any]) -> None:
    if document.get("schema_version") != CONTRACT_SCHEMA:
        raise ValueError("unsupported agent-runtime registry schema")
    packages = document.get("work_packages")
    if not isinstance(packages, dict) or tuple(packages) != PACKAGE_IDS:
        raise ValueError("agent-runtime registry work-package order is incomplete")
    for package_id, package in packages.items():
        if not isinstance(package, dict):
            raise ValueError(f"invalid work-package registry row: {package_id}")
        missing = REQUIRED_PACKAGE_FIELDS - package.keys()
        if missing:
            raise ValueError(f"work-package {package_id} is missing {sorted(missing)}")
        if not package["budgets"] or not package["qualification"]:
            raise ValueError(f"work-package {package_id} has undefined bounds")
    for registry in (
        "performance_budgets",
        "resource_limits",
        "tool_risk_matrix",
        "external_compatibility",
        "surface_compatibility",
        "identity_fixtures",
        "cache_keys",
        "operator_surfaces",
        "machine_interface",
        "qualification_matrix",
    ):
        if not document.get(registry):
            raise ValueError(f"agent-runtime registry is missing {registry}")
    expected = str(document.get("contract_digest") or "")
    actual = contract_digest(document)
    if expected != actual:
        raise ValueError("agent-runtime registry digest mismatch")


def contract_digest(document: Mapping[str, Any]) -> str:
    payload = dict(document)
    payload.pop("contract_digest", None)
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def write_reader_contract(repo_root: Path) -> dict[str, Any]:
    document = load_runtime_contract()
    output = repo_root / "docs" / "generated" / "agent-runtime-contract.md"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(render_reader_contract(document), encoding="utf-8")
    return {
        "ok": True,
        "schema_version": "persistmind.agent_runtime_contract_generation.v1",
        "path": str(output),
        "contract_digest": document["contract_digest"],
    }


def render_reader_contract(document: Mapping[str, Any]) -> str:
    lines = [
        "# Agent Runtime Architecture and Performance Contract",
        "",
        f"Registry schema: `{document['schema_version']}`  ",
        f"Contract digest: `{document['contract_digest']}`",
        "",
        "## Work packages",
        "",
        "| Package | Owner | Profile | Authority | Stores | Disable |",
        "|---|---|---|---|---|---|",
    ]
    for package_id, package in document["work_packages"].items():
        lines.append(
            f"| {package_id} | {package['owner']} | {package['profile']} | "
            f"{package['authority']} | {', '.join(package['stores']) or 'none'} | "
            f"{package['disable']} |"
        )
    lines.extend(["", "## Performance budgets", ""])
    for name, value in document["performance_budgets"].items():
        lines.append(f"- `{name}`: {json.dumps(value, sort_keys=True)}")
    lines.extend(["", "## Resource ceilings", ""])
    for name, value in document["resource_limits"].items():
        lines.append(f"- `{name}`: {value}")
    lines.extend(["", "## Compatibility", ""])
    for name, value in document["external_compatibility"].items():
        lines.append(
            f"- `{name}`: `{value['source']}@{value['version']}` ({value['qualification_fixture']})"
        )
    lines.extend(["", "## Machine interface", ""])
    for key, value in document["machine_interface"].items():
        lines.append(f"- `{key}`: {json.dumps(value, sort_keys=True)}")
    return "\n".join(lines) + "\n"


__all__ = [
    "CONTRACT_SCHEMA",
    "PACKAGE_IDS",
    "contract_digest",
    "load_runtime_contract",
    "render_reader_contract",
    "validate_runtime_contract",
    "write_reader_contract",
]
