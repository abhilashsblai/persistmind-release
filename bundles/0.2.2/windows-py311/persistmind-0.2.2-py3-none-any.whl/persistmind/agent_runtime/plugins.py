from __future__ import annotations

import hashlib
import json
import os
import shutil
from collections.abc import Iterable, Mapping
from dataclasses import asdict, dataclass
from pathlib import Path, PurePosixPath
from typing import Any

from persistmind.application.plugin_ports import PluginTrustPort
from persistmind.security.context import require_current_principal
from persistmind.utils import canonical_json, stable_id, utc_now

PLUGIN_SCHEMA = "persistmind.plugin.v1"
MANIFEST_LOCATIONS = (
    Path("plugin.json"),
    Path(".grok-plugin/plugin.json"),
    Path(".claude-plugin/plugin.json"),
    Path(".codex-plugin/plugin.json"),
)
ASSET_DIRECTORIES = ("skills", "agents", "commands", "hooks", "mcp", "lsp")
MAX_MANIFEST_BYTES = 1024 * 1024
MAX_PLUGIN_FILES = 10000
OWNERSHIP_FILE = ".persistmind-plugin-ownership.json"
DISABLED_FILE = ".persistmind-plugin-disabled"
PLUGIN_PRECEDENCE = ("project", "explicit", "user", "marketplace", "grok", "claude", "managed")


@dataclass(frozen=True, slots=True)
class PluginDescriptor:
    plugin_id: str
    name: str
    version: str
    root: str
    manifest_path: str
    manifest_digest: str
    signer: str | None
    capabilities: tuple[str, ...]
    assets: Mapping[str, tuple[str, ...]]
    execution_closure_digest: str
    trusted: bool = False
    executable: bool = False
    disabled: bool = False
    owned_files_valid: bool = False
    schema_version: str = PLUGIN_SCHEMA


class PluginRegistry:
    def __init__(self, trust: PluginTrustPort | None = None) -> None:
        self.trust = trust

    def discover(self, roots: Iterable[Path]) -> list[PluginDescriptor]:
        found: dict[str, PluginDescriptor] = {}
        for candidate in roots:
            root = Path(candidate).resolve()
            manifest = next(
                (root / item for item in MANIFEST_LOCATIONS if (root / item).is_file()), None
            )
            if manifest is None:
                continue
            descriptor = self.inspect(root, manifest)
            existing = found.get(descriptor.plugin_id)
            if (
                existing
                and existing.execution_closure_digest != descriptor.execution_closure_digest
            ):
                raise ValueError(f"plugin identity collision: {descriptor.plugin_id}")
            if existing is None:
                found[descriptor.plugin_id] = descriptor
        return sorted(
            found.values(), key=lambda item: (item.name.casefold(), item.version, item.root)
        )

    def inspect(self, root: Path, manifest: Path | None = None) -> PluginDescriptor:
        root = Path(root).resolve(strict=True)
        manifest = manifest or next(
            (root / item for item in MANIFEST_LOCATIONS if (root / item).is_file()), None
        )
        if manifest is None:
            raise FileNotFoundError(f"plugin manifest not found: {root}")
        manifest = manifest.resolve(strict=True)
        _confined(root, manifest)
        raw = manifest.read_bytes()
        if len(raw) > MAX_MANIFEST_BYTES:
            raise ValueError("plugin manifest exceeds 1 MiB")
        try:
            document = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("plugin manifest is not valid UTF-8 JSON") from exc
        if not isinstance(document, dict):
            raise ValueError("plugin manifest must be a JSON object")
        name = str(document.get("name") or "").strip()
        version = str(document.get("version") or "").strip()
        if not name or not version or len(name) > 128 or len(version) > 64:
            raise ValueError("plugin manifest requires bounded name and version")
        assets, closure = _execution_closure(root)
        manifest_digest = hashlib.sha256(raw).hexdigest()
        capabilities = tuple(
            sorted(set(str(item) for item in document.get("capabilities", []) if item))
        )
        plugin_id = str(document.get("id") or "plugin_" + stable_id(name.casefold(), version)[:32])
        closure_digest = hashlib.sha256(canonical_json(closure).encode("utf-8")).hexdigest()
        trusted = False
        if self.trust is not None:
            record = self.trust.get("plugin-trust-" + plugin_id)
            trusted = bool(
                record
                and record.get("status") == "trusted"
                and record.get("root") == str(root)
                and record.get("manifest_digest") == manifest_digest
                and record.get("version") == version
                and record.get("execution_closure_digest") == closure_digest
                and sorted(record.get("capabilities") or []) == list(capabilities)
            )
        disabled = (root / DISABLED_FILE).is_file()
        owned_valid = self.diff(root)["clean"] if (root / OWNERSHIP_FILE).is_file() else False
        return PluginDescriptor(
            plugin_id=plugin_id,
            name=name,
            version=version,
            root=str(root),
            manifest_path=str(manifest.relative_to(root).as_posix()),
            manifest_digest=manifest_digest,
            signer=str(document.get("signer")) if document.get("signer") else None,
            capabilities=capabilities,
            assets=assets,
            execution_closure_digest=closure_digest,
            trusted=trusted,
            executable=trusted
            and not disabled
            and owned_valid
            and bool(set(assets) & {"hooks", "mcp", "lsp", "commands"}),
            disabled=disabled,
            owned_files_valid=owned_valid,
        )

    def trust_plugin(
        self, descriptor: PluginDescriptor, *, approval: Mapping[str, Any]
    ) -> PluginDescriptor:
        if self.trust is None:
            raise RuntimeError("plugin trust authority is unavailable")
        principal = require_current_principal(roles=frozenset({"admin"}), action="plugin.trust")
        if principal.auth_source != "os-local":
            raise PermissionError("plugin trust requires the local OS principal")
        self.trust.put(
            {
                "record_id": "plugin-trust-" + descriptor.plugin_id,
                "kind": "plugin_trust",
                "scope": descriptor.plugin_id,
                "status": "trusted",
                "root": descriptor.root,
                "manifest_digest": descriptor.manifest_digest,
                "version": descriptor.version,
                "signer": descriptor.signer,
                "capabilities": list(descriptor.capabilities),
                "execution_closure_digest": descriptor.execution_closure_digest,
                "principal": principal.subject,
                "updated_at": utc_now(),
                "reason": str(approval.get("reason") or "verified plugin trust activation"),
                "_approval": dict(approval),
            },
            idempotency_key="plugin-trust:"
            + descriptor.plugin_id
            + ":"
            + descriptor.execution_closure_digest,
        )
        return self.inspect(Path(descriptor.root))

    def revoke(
        self,
        descriptor: PluginDescriptor,
        *,
        reason: str,
        approval: Mapping[str, Any],
    ) -> PluginDescriptor:
        if self.trust is None:
            raise RuntimeError("plugin trust authority is unavailable")
        principal = require_current_principal(roles=frozenset({"admin"}), action="plugin.revoke")
        self.trust.put(
            {
                "record_id": "plugin-trust-" + descriptor.plugin_id,
                "kind": "plugin_trust",
                "scope": descriptor.plugin_id,
                "status": "revoked",
                "root": descriptor.root,
                "manifest_digest": descriptor.manifest_digest,
                "version": descriptor.version,
                "capabilities": list(descriptor.capabilities),
                "execution_closure_digest": descriptor.execution_closure_digest,
                "principal": principal.subject,
                "reason": reason[:1000],
                "updated_at": utc_now(),
                "_approval": dict(approval),
            }
        )
        return self.inspect(Path(descriptor.root))

    def install_transaction(self, source: Path, target: Path) -> PluginDescriptor:
        source_descriptor = self.inspect(source)
        target = Path(target).resolve()
        if target.exists():
            existing = self.inspect(target)
            if existing.execution_closure_digest == source_descriptor.execution_closure_digest:
                if not (target / OWNERSHIP_FILE).is_file():
                    (target / OWNERSHIP_FILE).write_text(
                        json.dumps(
                            {
                                "schema_version": "persistmind.plugin_ownership.v1",
                                "plugin_id": source_descriptor.plugin_id,
                                "execution_closure_digest": source_descriptor.execution_closure_digest,
                                "files": _owned_files(target),
                            },
                            indent=2,
                            sort_keys=True,
                        )
                        + "\n",
                        encoding="utf-8",
                    )
                return self.inspect(target)
            raise FileExistsError(f"plugin target already contains a different plugin: {target}")
        target.parent.mkdir(parents=True, exist_ok=True)
        stage = target.with_name(f".{target.name}.{os.getpid()}.stage")
        if stage.exists():
            raise FileExistsError(f"plugin transaction stage already exists: {stage}")
        try:
            shutil.copytree(source, stage, symlinks=False)
            staged = self.inspect(stage)
            if staged.execution_closure_digest != source_descriptor.execution_closure_digest:
                raise RuntimeError("plugin transaction closure changed during staging")
            (stage / OWNERSHIP_FILE).write_text(
                json.dumps(
                    {
                        "schema_version": "persistmind.plugin_ownership.v1",
                        "plugin_id": source_descriptor.plugin_id,
                        "execution_closure_digest": source_descriptor.execution_closure_digest,
                        "files": _owned_files(stage),
                    },
                    indent=2,
                    sort_keys=True,
                )
                + "\n",
                encoding="utf-8",
            )
            os.replace(stage, target)
        finally:
            if stage.exists():
                shutil.rmtree(stage)
        return self.inspect(target)

    def inventory(self, root: Path) -> dict[str, Any]:
        root = Path(root).resolve(strict=True)
        ownership = _ownership(root)
        current = _owned_files(root)
        return {
            "schema_version": "persistmind.plugin_inventory.v1",
            "root": str(root),
            "owned": ownership.get("files", []),
            "current": current,
        }

    def diff(self, root: Path) -> dict[str, Any]:
        root = Path(root).resolve(strict=True)
        ownership = _ownership(root)
        expected = {str(item["path"]): item for item in ownership.get("files", [])}
        current = {str(item["path"]): item for item in _owned_files(root)}
        missing = sorted(set(expected) - set(current))
        unowned = sorted(set(current) - set(expected))
        modified = sorted(
            path
            for path in set(expected) & set(current)
            if expected[path].get("sha256") != current[path].get("sha256")
        )
        return {
            "schema_version": "persistmind.plugin_diff.v1",
            "root": str(root),
            "clean": not (missing or unowned or modified),
            "missing": missing,
            "unowned": unowned,
            "modified": modified,
        }

    def disable(self, root: Path, *, reason: str) -> PluginDescriptor:
        root = Path(root).resolve(strict=True)
        (root / DISABLED_FILE).write_text(reason[:1000] + "\n", encoding="utf-8")
        return self.inspect(root)

    def enable(self, root: Path) -> PluginDescriptor:
        root = Path(root).resolve(strict=True)
        (root / DISABLED_FILE).unlink(missing_ok=True)
        return self.inspect(root)

    def uninstall(self, root: Path, *, recover_modified: bool = False) -> dict[str, Any]:
        root = Path(root).resolve(strict=True)
        diff = self.diff(root)
        if not diff["clean"] and not recover_modified:
            raise RuntimeError(
                "plugin contains modified, missing, or unowned files; recovery required"
            )
        plugin_id = self.inspect(root).plugin_id
        shutil.rmtree(root)
        return {
            "ok": True,
            "schema_version": "persistmind.plugin_uninstall.v1",
            "plugin_id": plugin_id,
            "removed": str(root),
            "recovered_modified": bool(recover_modified),
        }

    def repair(
        self, source: Path, target: Path, *, recover_modified: bool = False
    ) -> PluginDescriptor:
        target = Path(target).resolve(strict=True)
        diff = self.diff(target)
        if not diff["clean"] and not recover_modified:
            raise RuntimeError("plugin repair requires an explicit modified-file recovery decision")
        backup = target.with_name(f".{target.name}.{os.getpid()}.repair-backup")
        if backup.exists():
            raise FileExistsError(f"plugin repair backup exists: {backup}")
        os.replace(target, backup)
        try:
            installed = self.install_transaction(source, target)
        except BaseException:
            if target.exists():
                shutil.rmtree(target)
            os.replace(backup, target)
            raise
        shutil.rmtree(backup)
        return installed


def descriptor_document(descriptor: PluginDescriptor) -> dict[str, Any]:
    value = asdict(descriptor)
    value["assets"] = {key: list(paths) for key, paths in descriptor.assets.items()}
    return value


def _execution_closure(root: Path) -> tuple[dict[str, tuple[str, ...]], list[dict[str, Any]]]:
    assets: dict[str, tuple[str, ...]] = {}
    closure: list[dict[str, Any]] = []
    count = 0
    for kind in ASSET_DIRECTORIES:
        directory = root / kind
        if not directory.exists():
            continue
        _confined(root, directory.resolve(strict=True))
        paths = []
        for path in sorted(directory.rglob("*")):
            if path.is_symlink():
                _confined(root, path.resolve(strict=True))
                raise ValueError(f"plugin execution closure may not contain symlinks: {path}")
            if not path.is_file():
                continue
            count += 1
            if count > MAX_PLUGIN_FILES:
                raise ValueError("plugin execution closure exceeds file limit")
            resolved = path.resolve(strict=True)
            _confined(root, resolved)
            relative = resolved.relative_to(root).as_posix()
            paths.append(relative)
            closure.append(
                {
                    "path": relative,
                    "bytes": resolved.stat().st_size,
                    "sha256": hashlib.sha256(resolved.read_bytes()).hexdigest(),
                }
            )
        assets[kind] = tuple(paths)
    return assets, closure


def _confined(root: Path, target: Path) -> None:
    if not target.is_relative_to(root):
        raise ValueError(f"plugin path escapes root: {target}")
    relative = target.relative_to(root).as_posix()
    parts = PurePosixPath(relative).parts
    if any(part in {"", ".", ".."} for part in parts):
        raise ValueError(f"plugin path is not canonical: {relative}")


def _ownership(root: Path) -> dict[str, Any]:
    path = root / OWNERSHIP_FILE
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError("plugin ownership inventory is absent or invalid") from exc
    if (
        not isinstance(value, dict)
        or value.get("schema_version") != "persistmind.plugin_ownership.v1"
    ):
        raise RuntimeError("plugin ownership inventory schema is unsupported")
    return value


def _owned_files(root: Path) -> list[dict[str, Any]]:
    files = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.name in {OWNERSHIP_FILE, DISABLED_FILE}:
            continue
        resolved = path.resolve(strict=True)
        _confined(root, resolved)
        files.append(
            {
                "path": resolved.relative_to(root).as_posix(),
                "bytes": resolved.stat().st_size,
                "sha256": hashlib.sha256(resolved.read_bytes()).hexdigest(),
            }
        )
    return files


__all__ = [
    "ASSET_DIRECTORIES",
    "MANIFEST_LOCATIONS",
    "PLUGIN_PRECEDENCE",
    "PLUGIN_SCHEMA",
    "PluginDescriptor",
    "PluginRegistry",
    "descriptor_document",
]
