from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from persistmind import __version__
from persistmind.branding import resolve_project_state


ACTIVATION_SCHEMA = "persistmind.host_activation.v1"
_MAX_BYTES = 32 * 1024


def record_host_attachment(repo: Path, payload: Mapping[str, Any]) -> dict[str, Any]:
    """Record that the installed hook actually ran inside a host session."""

    session_id = str(payload.get("session_id") or "").strip()
    document = {
        "schema_version": ACTIVATION_SCHEMA,
        "engine_version": __version__,
        "host": "codex",
        "session_id_sha256": (
            hashlib.sha256(session_id.encode("utf-8")).hexdigest() if session_id else None
        ),
        "observed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "hook_event": "SessionStart",
    }
    path = _activation_path(repo)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(document, sort_keys=True, separators=(",", ":")), encoding="utf-8"
    )
    os.replace(temporary, path)
    return activation_status(repo, expected_version=__version__)


def activation_status(repo: Path, *, expected_version: str) -> dict[str, Any]:
    document = _read_activation(repo)
    version_matches = bool(document) and str(document.get("engine_version")) == expected_version
    session_identified = bool(document.get("session_id_sha256")) if document else False
    attached = version_matches and session_identified
    return {
        "schema_version": ACTIVATION_SCHEMA,
        "status": "attached_session_observed" if attached else "configured_restart_required",
        "direct_probe_status": "host_hook_observed" if attached else "callable_not_host_attached",
        "current_session_attached": attached,
        "restart_required": not attached,
        "attached_engine_version": document.get("engine_version") if document else None,
        "expected_engine_version": expected_version,
        "observed_at": document.get("observed_at") if document else None,
        "session_identity_recorded": session_identified,
        "project_trust": "user_review_required_if_prompted",
        "command_hook_review": "user_review_required_if_changed",
        "trust_store_mutated": False,
    }


def _read_activation(repo: Path) -> dict[str, Any]:
    path = _activation_path(repo)
    try:
        raw = path.read_bytes()
    except OSError:
        return {}
    if len(raw) > _MAX_BYTES:
        return {}
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {}
    if not isinstance(value, dict) or value.get("schema_version") != ACTIVATION_SCHEMA:
        return {}
    return value


def _activation_path(repo: Path) -> Path:
    return resolve_project_state(Path(repo).resolve()) / "runtime" / "host-activation.json"


__all__ = ["ACTIVATION_SCHEMA", "activation_status", "record_host_attachment"]
