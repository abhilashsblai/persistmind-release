from __future__ import annotations

import hashlib
import json
import os
import queue
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from threading import RLock, Thread
from typing import Any, Mapping, Protocol, Sequence

from persistmind.application.agent_runtime_ports import AgentRuntimeTaskPort
from persistmind.utils import canonical_json, stable_id

from .events import AgentEventJournal
from .grants import ExecutionGrantService
from .identity import RepositoryContext
from .worktrees import WorktreeLease, WorktreeTransaction


EXTERNAL_SCHEMA = "persistmind.external_agent.v1"
MAX_OUTPUT_BYTES = 1024 * 1024


@dataclass(frozen=True, slots=True)
class AgentCapabilities:
    resume: bool
    streaming: bool
    permissions: bool
    cancellation: bool
    model_selection: bool
    output_formats: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class LaunchSpec:
    argv: tuple[str, ...]
    stdin: str | None
    output_format: str
    credential_env: tuple[str, ...] = ()


class ExternalAgentAdapter(Protocol):
    adapter_id: str
    version: str
    capabilities: AgentCapabilities

    def launch_spec(
        self,
        *,
        prompt: str,
        worktree: Path,
        model: str | None,
        session_reference: str | None,
    ) -> LaunchSpec: ...

    def parse(self, stdout: str, stderr: str, exit_code: int) -> Mapping[str, Any]: ...


class FakeAgentAdapter:
    adapter_id = "fake"
    version = "1"
    capabilities = AgentCapabilities(True, True, True, True, False, ("jsonl",))

    def launch_spec(
        self,
        *,
        prompt: str,
        worktree: Path,
        model: str | None,
        session_reference: str | None,
    ) -> LaunchSpec:
        script = (
            "import json,sys; p=sys.stdin.read(); "
            "print(json.dumps({'type':'session','session_id':'fake-session'})); "
            "print(json.dumps({'type':'result','text':p,'cwd':sys.argv[1]}))"
        )
        return LaunchSpec(
            argv=(sys.executable, "-I", "-c", script, str(worktree)),
            stdin=prompt,
            output_format="jsonl",
        )

    def parse(self, stdout: str, stderr: str, exit_code: int) -> Mapping[str, Any]:
        updates = []
        for line in stdout.splitlines():
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                value = {"type": "text", "text": line}
            if isinstance(value, dict):
                updates.append(value)
        session = next((item.get("session_id") for item in updates if item.get("session_id")), None)
        return {
            "exit_code": exit_code,
            "updates": updates,
            "session_reference": session,
            "stderr": stderr,
        }


class CodexHeadlessAdapter:
    adapter_id = "codex"
    version = "cli-json-v1"
    capabilities = AgentCapabilities(True, True, True, True, True, ("jsonl",))

    def launch_spec(
        self, *, prompt: str, worktree: Path, model: str | None, session_reference: str | None
    ) -> LaunchSpec:
        argv = ["codex", "exec", "--json", "--sandbox", "workspace-write", "-C", str(worktree)]
        if model:
            argv.extend(["--model", model])
        if session_reference:
            argv.extend(["resume", session_reference])
        argv.append(prompt)
        return LaunchSpec(tuple(argv), None, "jsonl", ("OPENAI_API_KEY", "CODEX_API_KEY"))

    def parse(self, stdout: str, stderr: str, exit_code: int) -> Mapping[str, Any]:
        return _parse_json_lines(stdout, stderr, exit_code)


class ClaudeHeadlessAdapter:
    adapter_id = "claude"
    version = "print-stream-json-v1"
    capabilities = AgentCapabilities(True, True, True, True, True, ("jsonl", "json"))

    def launch_spec(
        self, *, prompt: str, worktree: Path, model: str | None, session_reference: str | None
    ) -> LaunchSpec:
        argv = [
            "claude",
            "-p",
            prompt,
            "--output-format",
            "stream-json",
            "--include-partial-messages",
        ]
        if model:
            argv.extend(["--model", model])
        if session_reference:
            argv.extend(["--resume", session_reference])
        return LaunchSpec(tuple(argv), None, "jsonl", ("ANTHROPIC_API_KEY",))

    def parse(self, stdout: str, stderr: str, exit_code: int) -> Mapping[str, Any]:
        return _parse_json_lines(stdout, stderr, exit_code)


class GrokHeadlessAdapter:
    adapter_id = "grok"
    version = "streaming-json-v1"
    capabilities = AgentCapabilities(True, True, True, True, True, ("jsonl", "json", "plain"))

    def launch_spec(
        self, *, prompt: str, worktree: Path, model: str | None, session_reference: str | None
    ) -> LaunchSpec:
        argv = [
            "grok",
            "--no-auto-update",
            "-p",
            prompt,
            "--output-format",
            "streaming-json",
            "--cwd",
            str(worktree),
        ]
        if model:
            argv.extend(["--model", model])
        if session_reference:
            argv.extend(["--resume", session_reference])
        return LaunchSpec(tuple(argv), None, "jsonl", ("XAI_API_KEY",))

    def parse(self, stdout: str, stderr: str, exit_code: int) -> Mapping[str, Any]:
        return _parse_json_lines(stdout, stderr, exit_code)


class ExternalAgentOrchestrator:
    def __init__(
        self,
        task: AgentRuntimeTaskPort,
        journal: AgentEventJournal,
        context: RepositoryContext,
        grants: ExecutionGrantService,
        worktrees: WorktreeTransaction,
        router: Any | None = None,
    ) -> None:
        self.task = task
        self.journal = journal
        self.context = context
        self.grants = grants
        self.worktrees = worktrees.bind_task(task)
        if router is None:
            from .routing import ModelRouter

            router = ModelRouter(task=task)
        self.router = router
        self._processes: dict[str, subprocess.Popen[str]] = {}
        self._lock = RLock()

    def launch(
        self,
        *,
        orchestration_id: str,
        adapter: ExternalAgentAdapter,
        prompt: str,
        grant_token: str,
        workflow_id: str,
        model: str | None = None,
        model_route_id: str | None = None,
        session_reference: str | None = None,
        timeout_seconds: int = 900,
        idempotency_key: str | None = None,
        role: str = "implement",
        task_class: str = "coding",
        risk: str = "normal",
        sensitive: bool = False,
        policy_models: Sequence[str] = (),
        required_context_tokens: int = 0,
        max_cost_usd: float | None = None,
        max_turns: int | None = None,
        usage: Mapping[str, Any] | None = None,
        policy_revision: str = "default",
    ) -> dict[str, Any]:
        run_id = (
            "agent_run_"
            + stable_id(
                orchestration_id, adapter.adapter_id, idempotency_key or prompt, session_reference
            )[:36]
        )
        existing = self.task.external_run(run_id)
        if existing and existing.get("state") == "completed":
            return {
                "ok": True,
                "schema_version": EXTERNAL_SCHEMA,
                "replayed": True,
                "run": existing,
            }
        required_capabilities = ["streaming"]
        if session_reference:
            required_capabilities.append("resume")
        route = self.router.route(
            role=role,
            task_class=task_class,
            risk=risk,
            sensitive=sensitive,
            requested_model=model,
            policy_models=policy_models,
            available_providers=[_adapter_provider(adapter.adapter_id)],
            orchestration_id=orchestration_id,
            policy_revision=policy_revision,
            adapter_id=adapter.adapter_id,
            required_capabilities=required_capabilities,
            required_context_tokens=required_context_tokens,
            max_cost_usd=max_cost_usd,
            max_turns=max_turns,
            usage=usage,
            adapter_enforces_model=adapter.capabilities.model_selection,
        )
        if model_route_id and model_route_id != route["route_id"]:
            raise PermissionError("caller-supplied model route does not match enforced routing")
        grant = self.grants.authorize(
            grant_token,
            workflow_id=workflow_id,
            action="process.launch",
            process=adapter.adapter_id,
        )
        worktree = self.worktrees.prepare(run_id, mode="clean_tracked")
        spec = adapter.launch_spec(
            prompt=prompt,
            worktree=worktree.path,
            model=str(route.get("adapter_model") or "") or None,
            session_reference=session_reference,
        )
        executable = _resolve_executable(spec.argv[0])
        argv = (str(executable), *spec.argv[1:])
        self.task.put_external_run(
            {
                "run_id": run_id,
                "orchestration_id": orchestration_id,
                "adapter_id": adapter.adapter_id,
                "adapter_version": adapter.version,
                "worktree_lease_id": worktree.lease_id,
                "execution_grant_id": grant["grant_id"],
                "model_route_id": route["route_id"],
                "state": "starting",
                "session_reference": session_reference,
            }
        )
        environment = _environment(
            spec.credential_env,
            state_root=worktree.state_root,
            canonical_repo=self.context.repository_root,
        )
        process = subprocess.Popen(
            list(argv),
            cwd=worktree.path,
            env=environment,
            stdin=subprocess.PIPE if spec.stdin is not None else subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            shell=False,
            creationflags=int(getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
            if os.name == "nt"
            else 0,
            start_new_session=os.name != "nt",
        )
        with self._lock:
            self._processes[run_id] = process
        self.task.update_external_run(
            run_id,
            state="running",
            values={"process_id": process.pid},
        )
        self.task.put_runtime_process(
            {
                "owner_kind": "external",
                "owner_id": run_id,
                "process_id": process.pid,
                "started_at": _now(),
                "state": "running",
            }
        )
        lease_box = [worktree]
        try:
            stdout, stderr, timed_out = _stream_process(
                process,
                stdin=spec.stdin,
                timeout_seconds=max(1, min(int(timeout_seconds), 3600)),
                on_update=lambda cursor, update: self.journal.append(
                    adapter.adapter_id,
                    "PostToolUse",
                    {"status": "stream_update", "cursor": cursor, "update": update},
                    session_id=run_id,
                    host_event_id=f"{run_id}:update:{cursor}",
                ),
                on_heartbeat=lambda: lease_box.__setitem__(
                    0, self.worktrees.renew(lease_box[0], ttl_seconds=3600)
                ),
            )
        except BaseException:
            _terminate_tree(process)
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                pass
            self.task.update_external_run(
                run_id,
                state="failed",
                values={"process_id": None},
            )
            raise
        finally:
            with self._lock:
                self._processes.pop(run_id, None)
            self.task.clear_runtime_process("external", run_id)
        if timed_out:
            process.wait(timeout=30)
            self.task.update_external_run(run_id, state="timed_out", values={"process_id": None})
            return {
                "ok": False,
                "schema_version": EXTERNAL_SCHEMA,
                "status": "timeout",
                "run_id": run_id,
                "worktree": _worktree_document(worktree),
            }
        stdout = _bounded(stdout)
        stderr = _bounded(stderr)
        parsed = dict(adapter.parse(stdout, stderr, process.returncode))
        digest = hashlib.sha256(canonical_json(parsed).encode("utf-8")).hexdigest()
        current = self.task.external_run(run_id)
        state = (
            "cancelled"
            if current is not None and current.get("state") in {"cancelling", "cancelled"}
            else "completed"
            if process.returncode == 0
            else "failed"
        )
        run = self.task.update_external_run(
            run_id,
            state=state,
            values={
                "process_id": None,
                "session_reference": parsed.get("session_reference"),
                "replay_cursor": len(parsed.get("updates") or []),
                "result_digest": digest,
            },
        )
        self.journal.append(
            adapter.adapter_id,
            "SessionEnd",
            {"status": state, "exit_code": process.returncode, "result_digest": digest},
            session_id=run_id,
            host_event_id=run_id + ":end",
        )
        return {
            "ok": state == "completed",
            "schema_version": EXTERNAL_SCHEMA,
            "replayed": False,
            "run": run,
            "worktree": _worktree_document(worktree),
            "result": parsed,
            "route": route,
        }

    def cancel(self, run_id: str) -> dict[str, Any]:
        stored = self.task.external_run(run_id)
        if stored is None:
            raise KeyError(f"unknown external agent run: {run_id}")
        if stored.get("state") in {"completed", "failed", "cancelled", "timed_out"}:
            return {
                "ok": True,
                "schema_version": EXTERNAL_SCHEMA,
                "run": stored,
                "signalled": False,
            }
        self.task.update_external_run(run_id, state="cancelling", values={})
        with self._lock:
            process = self._processes.get(run_id)
        if process is not None:
            _terminate_tree(process)
            signalled = True
        else:
            process_record = self.task.runtime_process("external", run_id)
            process_id = int(
                (process_record or {}).get("process_id") or stored.get("process_id") or 0
            )
            signalled = terminate_process_id(process_id) if process_id > 0 else False
        self.task.clear_runtime_process("external", run_id)
        run = self.task.update_external_run(run_id, state="cancelled", values={"process_id": None})
        return {
            "ok": True,
            "schema_version": EXTERNAL_SCHEMA,
            "run": run,
            "signalled": signalled,
            "signal_scope": "in_process" if process is not None else "persisted_process_id",
        }


def adapter_registry() -> dict[str, ExternalAgentAdapter]:
    adapters: Sequence[ExternalAgentAdapter] = (
        FakeAgentAdapter(),
        CodexHeadlessAdapter(),
        ClaudeHeadlessAdapter(),
        GrokHeadlessAdapter(),
    )
    return {adapter.adapter_id: adapter for adapter in adapters}


def _adapter_provider(adapter_id: str) -> str:
    return {
        "fake": "local",
        "codex": "openai",
        "claude": "anthropic",
        "grok": "xai",
    }.get(adapter_id, adapter_id)


def _parse_json_lines(stdout: str, stderr: str, exit_code: int) -> Mapping[str, Any]:
    updates = []
    session = None
    for line in stdout.splitlines():
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            value = {"type": "text", "text": line}
        if isinstance(value, dict):
            updates.append(value)
            session = session or value.get("session_id") or value.get("sessionId")
    return {
        "exit_code": exit_code,
        "updates": updates,
        "session_reference": session,
        "stderr": stderr,
    }


def _resolve_executable(value: str) -> Path:
    candidate = Path(value)
    if candidate.is_absolute() and candidate.is_file():
        return candidate.resolve()
    found = shutil.which(value)
    if not found:
        raise FileNotFoundError(f"external agent executable is unavailable: {value}")
    return Path(found).resolve()


def _environment(
    credential_names: Sequence[str],
    *,
    state_root: Path,
    canonical_repo: Path,
) -> dict[str, str]:
    allowed = {
        "APPDATA",
        "HOME",
        "LANG",
        "LOCALAPPDATA",
        "PATH",
        "PATHEXT",
        "SYSTEMROOT",
        "TEMP",
        "TMP",
        "USERPROFILE",
        "WINDIR",
    }
    allowed.update(credential_names)
    environment = {key: value for key, value in os.environ.items() if key in allowed}
    environment["PERSISTMIND_PROJECT_STATE"] = str(state_root)
    environment["PERSISTMIND_CANONICAL_REPO"] = str(canonical_repo)
    return environment


def _stream_process(
    process: subprocess.Popen[str],
    *,
    stdin: str | None,
    timeout_seconds: int,
    on_update: Any,
    on_heartbeat: Any | None = None,
) -> tuple[str, str, bool]:
    """Drain process pipes incrementally with bounded memory and update delivery."""

    messages: queue.Queue[tuple[str, str | None]] = queue.Queue(maxsize=2048)
    stdout_buffer = _BoundedTextBuffer(MAX_OUTPUT_BYTES)
    stderr_buffer = _BoundedTextBuffer(MAX_OUTPUT_BYTES)

    def pump(kind: str, stream: Any) -> None:
        try:
            for line in iter(stream.readline, ""):
                messages.put((kind, line))
        finally:
            messages.put((kind, None))

    threads = [
        Thread(target=pump, args=("stdout", process.stdout), daemon=True),
        Thread(target=pump, args=("stderr", process.stderr), daemon=True),
    ]
    for thread in threads:
        thread.start()
    if process.stdin is not None:
        if stdin is not None:
            process.stdin.write(stdin)
            process.stdin.flush()
        process.stdin.close()
    deadline = time.monotonic() + timeout_seconds
    ended: set[str] = set()
    cursor = 0
    timed_out = False
    next_heartbeat = time.monotonic() + 10
    while len(ended) < 2:
        if on_heartbeat is not None and time.monotonic() >= next_heartbeat:
            on_heartbeat()
            next_heartbeat = time.monotonic() + 10
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            timed_out = True
            break
        try:
            kind, line = messages.get(timeout=min(0.1, remaining))
        except queue.Empty:
            continue
        if line is None:
            ended.add(kind)
            continue
        target = stdout_buffer if kind == "stdout" else stderr_buffer
        target.append(line)
        if kind == "stdout":
            try:
                update = json.loads(line)
            except json.JSONDecodeError:
                update = {"type": "text", "text": line.rstrip("\r\n")}
            if isinstance(update, dict):
                cursor += 1
                on_update(cursor, update)
    if timed_out:
        _terminate_tree(process)
    for thread in threads:
        thread.join(timeout=5)
    if not timed_out:
        process.wait(timeout=30)
    return stdout_buffer.value(), stderr_buffer.value(), timed_out


class _BoundedTextBuffer:
    def __init__(self, limit: int) -> None:
        self.limit = limit
        self.parts: list[bytes] = []
        self.bytes = 0
        self.truncated = False

    def append(self, value: str) -> None:
        raw = value.encode("utf-8")
        remaining = self.limit - self.bytes
        if remaining <= 0:
            self.truncated = True
            return
        selected = raw[:remaining]
        self.parts.append(selected)
        self.bytes += len(selected)
        self.truncated = self.truncated or len(selected) != len(raw)

    def value(self) -> str:
        result = b"".join(self.parts).decode("utf-8", errors="ignore")
        return result + ("\n...[truncated]" if self.truncated else "")


def _terminate_tree(process: subprocess.Popen[str]) -> None:
    if process.poll() is not None:
        return
    if os.name == "nt":
        subprocess.run(
            ["taskkill", "/PID", str(process.pid), "/T", "/F"], check=False, capture_output=True
        )
    else:
        getattr(os, "killpg")(process.pid, 15)


def terminate_process_id(process_id: int) -> bool:
    if process_id <= 0:
        return False
    try:
        if os.name == "nt":
            completed = subprocess.run(
                ["taskkill", "/PID", str(process_id), "/T", "/F"],
                check=False,
                capture_output=True,
            )
            return completed.returncode == 0
        # ``killpg`` is POSIX-only and is intentionally absent from Windows
        # type stubs even though this branch is unreachable there.
        getattr(os, "killpg")(process_id, 15)
        return True
    except (OSError, subprocess.SubprocessError):
        return False


def _now() -> str:
    from persistmind.utils import utc_now

    return utc_now()


def _bounded(value: str) -> str:
    raw = value.encode("utf-8")
    if len(raw) <= MAX_OUTPUT_BYTES:
        return value
    return raw[:MAX_OUTPUT_BYTES].decode("utf-8", errors="ignore") + "\n...[truncated]"


def _worktree_document(lease: WorktreeLease) -> dict[str, Any]:
    return {
        "lease_id": lease.lease_id,
        "path": str(lease.path),
        "state_root": str(lease.state_root),
        "pinned_oid": lease.pinned_oid,
        "source_view_id": lease.source_view_id,
        "mode": lease.mode,
        "dirty_patch_digest": lease.dirty_patch_digest,
    }


__all__ = [
    "AgentCapabilities",
    "ClaudeHeadlessAdapter",
    "CodexHeadlessAdapter",
    "EXTERNAL_SCHEMA",
    "ExternalAgentAdapter",
    "ExternalAgentOrchestrator",
    "FakeAgentAdapter",
    "GrokHeadlessAdapter",
    "LaunchSpec",
    "adapter_registry",
    "terminate_process_id",
]
