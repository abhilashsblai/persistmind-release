from __future__ import annotations

import fnmatch
import hashlib
import hmac
import secrets
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Mapping, Sequence

from persistmind.application.agent_runtime_ports import AgentRuntimeTaskPort
from persistmind.security.context import require_current_principal
from persistmind.utils import stable_id

from .identity import RepositoryContext


GRANT_SCHEMA = "persistmind.execution_grant.v1"
NON_DELEGABLE_ACTIONS = frozenset(
    {
        "admin.mutate",
        "credential.export",
        "execution_grant.issue",
        "execution_grant.revoke",
        "policy.approve",
        "release.sign",
        "worktree.parent_merge",
    }
)


@dataclass(frozen=True, slots=True)
class IssuedGrant:
    grant_id: str
    secret: str
    expires_at: str
    schema_version: str = GRANT_SCHEMA

    @property
    def token(self) -> str:
        return f"{self.grant_id}.{self.secret}"


class ExecutionGrantService:
    def __init__(self, task: AgentRuntimeTaskPort, context: RepositoryContext) -> None:
        self.task = task
        self.context = context

    def issue(
        self,
        *,
        workflow_id: str,
        actions: Sequence[str],
        path_scopes: Sequence[str] = (),
        process_scopes: Sequence[str] = (),
        network_scopes: Sequence[str] = (),
        ttl_seconds: int = 900,
        max_uses: int = 1,
    ) -> IssuedGrant:
        principal = require_current_principal(
            roles=frozenset({"operator", "admin"}), action="execution_grant.issue"
        )
        if principal.auth_source != "os-local" or not principal.permits_repo(
            self.context.repository_root
        ):
            raise PermissionError("execution grants require the scoped local OS principal")
        normalized_actions = tuple(sorted(set(str(item) for item in actions if item)))
        if not normalized_actions:
            raise ValueError("execution grant requires at least one action")
        excluded = NON_DELEGABLE_ACTIONS & set(normalized_actions)
        if excluded:
            raise PermissionError(f"actions cannot be delegated: {', '.join(sorted(excluded))}")
        paths = tuple(sorted(set(_normalize_scope(item) for item in path_scopes)))
        secret = secrets.token_urlsafe(32)
        grant_id = (
            "grant_"
            + stable_id(
                self.context.repository_id,
                self.context.workspace_id,
                workflow_id,
                principal.subject,
                secret,
            )[:40]
        )
        now = datetime.now(timezone.utc)
        expires = now + timedelta(seconds=max(1, min(int(ttl_seconds), 86400)))
        epoch = int(self.task.runtime_epoch()["epoch"])
        self.task.put_grant(
            {
                "grant_id": grant_id,
                "secret_hash": _secret_hash(secret),
                "repository_id": self.context.repository_id,
                "workspace_id": self.context.workspace_id,
                "source_view_id": self.context.source_view_id,
                "workflow_id": workflow_id,
                "principal_id": principal.subject,
                "actions": normalized_actions,
                "path_scopes": paths,
                "process_scopes": tuple(sorted(set(process_scopes))),
                "network_scopes": tuple(sorted(set(network_scopes))),
                "max_uses": max(1, min(int(max_uses), 1000)),
                "not_before": _instant(now),
                "expires_at": _instant(expires),
                "runtime_epoch": epoch,
                "created_at": _instant(now),
            }
        )
        return IssuedGrant(grant_id=grant_id, secret=secret, expires_at=_instant(expires))

    def authorize(
        self,
        token: str,
        *,
        workflow_id: str,
        action: str,
        path: str | None = None,
        process: str | None = None,
        network: str | None = None,
        consume: bool = True,
    ) -> Mapping[str, Any]:
        grant_id, secret = _nextgen_token(token)
        grant = self.task.grant(grant_id)
        if grant is None or not hmac.compare_digest(
            str(grant["secret_hash"]), _secret_hash(secret)
        ):
            raise PermissionError("execution grant is invalid")
        now = datetime.now(timezone.utc)
        if (
            grant["status"] != "active"
            or now < _parse(grant["not_before"])
            or now >= _parse(grant["expires_at"])
        ):
            raise PermissionError("execution grant is inactive or expired")
        epoch = int(self.task.runtime_epoch()["epoch"])
        expected = {
            "repository_id": self.context.repository_id,
            "workspace_id": self.context.workspace_id,
            "source_view_id": self.context.source_view_id,
            "workflow_id": workflow_id,
            "runtime_epoch": epoch,
        }
        if any(str(grant[key]) != str(value) for key, value in expected.items()):
            raise PermissionError("execution grant scope or epoch mismatch")
        if action not in set(grant["actions"]) or action in NON_DELEGABLE_ACTIONS:
            raise PermissionError("execution grant does not allow this action")
        _require_match(path, grant["path_scopes"], "path")
        _require_match(process, grant["process_scopes"], "process")
        _require_match(network, grant["network_scopes"], "network")
        if consume and not self.task.consume_grant(grant_id, expected_uses=int(grant["use_count"])):
            raise PermissionError("execution grant use fence rejected")
        return {**grant, "secret_hash": "[redacted]"}

    def revoke(self, grant_id: str) -> bool:
        require_current_principal(
            roles=frozenset({"operator", "admin"}), action="execution_grant.revoke"
        )
        return self.task.revoke_grant(grant_id)


def _normalize_scope(value: str) -> str:
    normalized = str(value).replace("\\", "/").strip().lstrip("./")
    if not normalized or normalized.startswith("../") or "/../" in normalized:
        raise ValueError(f"invalid execution grant path scope: {value!r}")
    return normalized


def _require_match(value: str | None, scopes: Sequence[str], label: str) -> None:
    if value is None:
        return
    normalized = _normalize_scope(value) if label == "path" else str(value)
    if not scopes or not any(fnmatch.fnmatchcase(normalized, str(scope)) for scope in scopes):
        raise PermissionError(f"execution grant {label} scope mismatch")


def _secret_hash(secret: str) -> str:
    return hashlib.sha256(("persistmind-grant-v1\0" + secret).encode("utf-8")).hexdigest()


def _nextgen_token(token: str) -> tuple[str, str]:
    grant_id, separator, secret = token.partition(".")
    if not separator or not grant_id or not secret:
        raise PermissionError("execution grant token is malformed")
    return grant_id, secret


def _instant(value: datetime) -> str:
    return value.isoformat().replace("+00:00", "Z")


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(str(value).replace("Z", "+00:00"))


__all__ = ["ExecutionGrantService", "GRANT_SCHEMA", "IssuedGrant", "NON_DELEGABLE_ACTIONS"]
