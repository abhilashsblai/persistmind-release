from __future__ import annotations

import hashlib
import os
import subprocess
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from threading import RLock
from typing import Any, Protocol

from persistmind.application.agent_runtime_ports import AgentRuntimeTaskPort
from persistmind.utils import canonical_json, stable_id

from .events import AgentEventJournal
from .grants import ExecutionGrantService
from .identity import RepositoryContext
from .worktrees import WorktreeLease, WorktreeTransaction

ACP_SCHEMA = "persistmind.acp_client.v1"
ACP_PROTOCOL_VERSION = 1
ACP_SCHEMA_RELEASE = "v0.13.3"
INITIALIZE_DEADLINE_SECONDS = 10
MAX_UPDATE_BYTES = 128 * 1024


class ACPTransport(Protocol):
    def request(
        self, method: str, params: Mapping[str, Any], *, timeout_seconds: int
    ) -> Mapping[str, Any]: ...

    def notify(self, method: str, params: Mapping[str, Any]) -> None: ...

    def close(self) -> None: ...


@dataclass(frozen=True, slots=True)
class ACPConnection:
    connection_id: str
    session_id: str
    worktree: WorktreeLease
    protocol_version: int
    capabilities: Mapping[str, Any]


class FakeACPTransport:
    """Deterministic ACP v1 transport used by qualification and downstream tests."""

    def __init__(self, *, protocol_version: int = ACP_PROTOCOL_VERSION) -> None:
        self.protocol_version = protocol_version
        self.requests: list[tuple[str, Mapping[str, Any]]] = []
        self.notifications: list[tuple[str, Mapping[str, Any]]] = []
        self.sessions: set[str] = set()
        self.permission_handler: Callable[[Mapping[str, Any]], str | None] | None = None

    def request(
        self, method: str, params: Mapping[str, Any], *, timeout_seconds: int
    ) -> Mapping[str, Any]:
        if timeout_seconds <= 0:
            raise TimeoutError("ACP request deadline elapsed")
        self.requests.append((method, dict(params)))
        if method == "initialize":
            return {
                "protocolVersion": self.protocol_version,
                "agentCapabilities": {
                    "loadSession": True,
                    "sessionCapabilities": {"resume": {}, "close": {}},
                    "mcpCapabilities": {"http": False, "sse": False},
                },
                "agentInfo": {"name": "persistmind-fake-acp", "version": "1"},
            }
        if method == "session/new":
            session_id = "fake-session-" + stable_id(params.get("cwd"))[:12]
            self.sessions.add(session_id)
            return {"sessionId": session_id}
        if method == "session/resume":
            session_id = str(params["sessionId"])
            self.sessions.add(session_id)
            return {}
        if method == "session/prompt":
            if str(params.get("sessionId")) not in self.sessions:
                raise ValueError("unknown fake ACP session")
            return {"stopReason": "end_turn"}
        raise ValueError(f"unsupported fake ACP method: {method}")

    def notify(self, method: str, params: Mapping[str, Any]) -> None:
        self.notifications.append((method, dict(params)))

    def close(self) -> None:
        return None


class ACPClientOrchestrator:
    def __init__(
        self,
        task: AgentRuntimeTaskPort,
        journal: AgentEventJournal,
        context: RepositoryContext,
        grants: ExecutionGrantService,
        worktrees: WorktreeTransaction,
        permission_decider: Callable[[Mapping[str, Any]], str | None] | None = None,
    ) -> None:
        self.task = task
        self.journal = journal
        self.context = context
        self.grants = grants
        self.worktrees = worktrees.bind_task(task)
        self.permission_decider = permission_decider
        self._transports: dict[str, ACPTransport] = {}
        self._transport_lock = RLock()

    def start(
        self,
        *,
        orchestration_id: str,
        agent_command: Sequence[str],
        grant_token: str,
        workflow_id: str,
        transport: ACPTransport | None = None,
        mcp_servers: Sequence[Mapping[str, Any]] = (),
        session_reference: str | None = None,
    ) -> ACPConnection:
        if not agent_command or not str(agent_command[0]).strip():
            raise ValueError("ACP agent command is required")
        grant = self.grants.authorize(
            grant_token,
            workflow_id=workflow_id,
            action="process.launch",
            process="acp",
        )
        worktree = self.worktrees.prepare(orchestration_id, mode="clean_tracked")
        owned_transport = transport is None
        if transport is None:
            from .acp_transport import OfficialSDKACPTransport

            environment = {
                key: value
                for key, value in os.environ.items()
                if key
                in {
                    "APPDATA",
                    "HOME",
                    "LOCALAPPDATA",
                    "PATH",
                    "PATHEXT",
                    "SYSTEMROOT",
                    "TEMP",
                    "TMP",
                    "USERPROFILE",
                    "WINDIR",
                }
            }
            environment["PERSISTMIND_PROJECT_STATE"] = str(worktree.state_root)
            environment["PERSISTMIND_CANONICAL_REPO"] = str(self.context.repository_root)
            transport = OfficialSDKACPTransport(
                agent_command,
                cwd=worktree.path,
                environment=environment,
            )
        connection_id = "acp_" + stable_id(orchestration_id, worktree.lease_id, agent_command)[:36]
        try:
            initialized = dict(
                transport.request(
                    "initialize",
                    {
                        "protocolVersion": ACP_PROTOCOL_VERSION,
                        "clientCapabilities": {
                            "fs": {"readTextFile": False, "writeTextFile": False},
                            "terminal": True,
                        },
                        "clientInfo": {"name": "PersistMind", "version": "0.2"},
                    },
                    timeout_seconds=INITIALIZE_DEADLINE_SECONDS,
                )
            )
        except BaseException:
            if owned_transport:
                transport.close()
            raise
        negotiated = int(initialized.get("protocolVersion", -1))
        if negotiated != ACP_PROTOCOL_VERSION:
            if owned_transport:
                transport.close()
            raise RuntimeError(
                f"unsupported ACP protocol version: agent={negotiated}, client={ACP_PROTOCOL_VERSION}"
            )
        capabilities = _bounded_mapping(initialized.get("agentCapabilities"))
        servers = [_readonly_mcp_server(item) for item in mcp_servers]
        try:
            if session_reference:
                session_capabilities = capabilities.get("sessionCapabilities") or {}
                if (
                    not isinstance(session_capabilities, Mapping)
                    or "resume" not in session_capabilities
                ):
                    raise RuntimeError("ACP agent does not advertise session resume")
                transport.request(
                    "session/resume",
                    {
                        "sessionId": session_reference,
                        "cwd": str(worktree.path),
                        "mcpServers": servers,
                    },
                    timeout_seconds=INITIALIZE_DEADLINE_SECONDS,
                )
                session_id = session_reference
            else:
                created = transport.request(
                    "session/new",
                    {"cwd": str(worktree.path), "mcpServers": servers},
                    timeout_seconds=INITIALIZE_DEADLINE_SECONDS,
                )
                session_id = str(created.get("sessionId") or "")
                if not session_id:
                    raise RuntimeError("ACP agent returned no session identity")
        except BaseException:
            if owned_transport:
                transport.close()
            raise
        self.task.put_acp_session(
            {
                "connection_id": connection_id,
                "orchestration_id": orchestration_id,
                "worktree_lease_id": worktree.lease_id,
                "execution_grant_id": grant["grant_id"],
                "agent_command_digest": _digest(tuple(agent_command)),
                "protocol_version": str(negotiated),
                "capabilities": capabilities,
                "state": "ready",
                "session_reference": session_id,
            }
        )
        self.task.update_acp_session(
            connection_id,
            state="ready",
            values={"session_reference": session_id, "protocol_version": str(negotiated)},
        )
        self.journal.append(
            "acp",
            "SessionStart",
            {"protocol_version": negotiated, "schema_release": ACP_SCHEMA_RELEASE},
            session_id=session_id,
            host_event_id=connection_id + ":start",
        )
        connection = ACPConnection(connection_id, session_id, worktree, negotiated, capabilities)
        if hasattr(transport, "permission_handler"):
            transport.permission_handler = lambda request: self._resolve_transport_permission(connection, request)
        if owned_transport:
            with self._transport_lock:
                self._transports[connection_id] = transport
            if hasattr(transport, "update_handler"):
                persisted = self.task.acp_session(connection_id)
                if persisted is None:
                    raise RuntimeError("ACP session disappeared after creation")
                cursor = {"value": int(persisted["replay_cursor"])}

                def ingest(params: Mapping[str, Any]) -> None:
                    cursor["value"] += 1
                    self.ingest_update(connection, params, cursor=cursor["value"])

                transport.update_handler = ingest
            process_id = getattr(transport, "process_id", None)
            if isinstance(process_id, int) and process_id > 0:
                self.task.put_runtime_process(
                    {
                        "owner_kind": "acp",
                        "owner_id": connection_id,
                        "process_id": process_id,
                        "state": "running",
                    }
                )
        return connection

    def prompt(
        self,
        connection: ACPConnection,
        transport: ACPTransport | None,
        text: str,
        *,
        timeout_seconds: int = 900,
    ) -> Mapping[str, Any]:
        self._require_connection(connection)
        transport = transport or self._owned_transport(connection.connection_id)
        self.journal.append(
            "acp",
            "UserPromptSubmit",
            {"content_digest": _digest(text), "content_bytes": len(text.encode("utf-8"))},
            session_id=connection.session_id,
            host_event_id=connection.connection_id + ":prompt:" + _digest(text)[:16],
        )
        result = _bounded_mapping(
            transport.request(
                "session/prompt",
                {
                    "sessionId": connection.session_id,
                    "prompt": [{"type": "text", "text": text}],
                },
                timeout_seconds=max(1, min(int(timeout_seconds), 3600)),
            )
        )
        digest = _digest(result)
        self.task.update_acp_session(
            connection.connection_id,
            state="ready",
            values={"result_digest": digest},
        )
        return {"schema_version": ACP_SCHEMA, "result": result, "result_digest": digest}

    def ingest_update(
        self, connection: ACPConnection, params: Mapping[str, Any], *, cursor: int
    ) -> Mapping[str, Any]:
        self._require_connection(connection)
        if str(params.get("sessionId")) != connection.session_id:
            raise PermissionError("ACP update session identity mismatch")
        update = _bounded_mapping(params.get("update"))
        event = self.journal.append(
            "acp",
            "PostToolUse",
            {"status": "update", "update": update, "cursor": cursor},
            session_id=connection.session_id,
            host_event_id=f"{connection.connection_id}:update:{cursor}",
        )
        self.task.update_acp_session(
            connection.connection_id,
            state="ready",
            values={"replay_cursor": max(0, int(cursor))},
        )
        return event

    def cancel(
        self, connection: ACPConnection, transport: ACPTransport | None = None
    ) -> Mapping[str, Any]:
        self._require_connection(connection)
        transport = transport or self._owned_transport(connection.connection_id)
        transport.notify("session/cancel", {"sessionId": connection.session_id})
        result = self.task.update_acp_session(
            connection.connection_id, state="cancelled", values={}
        )
        with self._transport_lock:
            owned = self._transports.pop(connection.connection_id, None)
        if owned is not None:
            owned.close()
        self.task.clear_runtime_process("acp", connection.connection_id)
        return result

    def suspend(self, connection: ACPConnection) -> Mapping[str, Any]:
        """Close an owned process transport while retaining resumable session metadata."""

        self._require_connection(connection)
        result = self.task.update_acp_session(
            connection.connection_id, state="suspended", values={}
        )
        with self._transport_lock:
            owned = self._transports.pop(connection.connection_id, None)
        if owned is not None:
            owned.close()
        self.task.clear_runtime_process("acp", connection.connection_id)
        return result

    def _resolve_transport_permission(
        self, connection: ACPConnection, request: Mapping[str, Any]
    ) -> str | None:
        result = self.resolve_permission(
            connection,
            request,
            self.permission_decider or (lambda _request: None),
        )
        outcome = result.get("outcome")
        if not isinstance(outcome, Mapping) or outcome.get("outcome") != "selected":
            return None
        return str(outcome.get("optionId") or "") or None

    def resolve_permission(
        self,
        connection: ACPConnection,
        request: Mapping[str, Any],
        decide: Callable[[Mapping[str, Any]], str | None],
    ) -> Mapping[str, Any]:
        """Resolve an inbound ACP permission request through parent-owned policy."""
        self._require_connection(connection)
        if str(request.get("sessionId")) != connection.session_id:
            raise PermissionError("ACP permission session identity mismatch")
        options = request.get("options")
        if not isinstance(options, Sequence) or isinstance(options, (str, bytes)):
            raise ValueError("ACP permission request has no bounded option set")
        bounded = [dict(item) for item in options[:32] if isinstance(item, Mapping)]
        option_ids = {
            str(item.get("optionId") or item.get("option_id"))
            for item in bounded
            if item.get("optionId") or item.get("option_id")
        }
        selected = decide(_bounded_mapping({**dict(request), "options": bounded}))
        if selected is None:
            self.journal.append(
                "acp",
                "PermissionDenied",
                {"request_digest": _digest(request)},
                session_id=connection.session_id,
                host_event_id=connection.connection_id + ":permission:" + _digest(request)[:16],
            )
            return {"outcome": {"outcome": "cancelled"}}
        if str(selected) not in option_ids:
            raise PermissionError("parent policy selected an unadvertised ACP permission option")
        return {"outcome": {"outcome": "selected", "optionId": str(selected)}}

    def run_terminal(
        self,
        connection: ACPConnection,
        command: Sequence[str],
        *,
        grant_token: str,
        workflow_id: str,
        timeout_seconds: int = 120,
        max_output_bytes: int = 1024 * 1024,
    ) -> Mapping[str, Any]:
        """Run one shell-free ACP terminal command inside the bound leased worktree."""
        self._require_connection(connection)
        argv = tuple(str(item) for item in command)
        if not argv or not argv[0].strip():
            raise ValueError("ACP terminal command is required")
        grant = self.grants.authorize(
            grant_token,
            workflow_id=workflow_id,
            action="process.launch",
            process="acp-terminal",
        )
        command_digest = _digest(argv)
        terminal_id = "acpt_" + stable_id(connection.connection_id, command_digest)[:36]
        self.task.put_acp_terminal(
            {
                "terminal_id": terminal_id,
                "connection_id": connection.connection_id,
                "command_digest": command_digest,
                "worktree_lease_id": connection.worktree.lease_id,
                "execution_grant_id": grant["grant_id"],
                "state": "running",
            }
        )
        limit = max(1, min(int(max_output_bytes), 1024 * 1024))
        try:
            completed = subprocess.run(
                argv,
                cwd=connection.worktree.path,
                capture_output=True,
                check=False,
                timeout=max(1, min(int(timeout_seconds), 900)),
            )
        except subprocess.TimeoutExpired as exc:
            output = (exc.stdout or b"") + (exc.stderr or b"")
            self.task.update_acp_terminal(
                terminal_id, state="timed_out", output_bytes=min(len(output), limit)
            )
            raise TimeoutError("ACP terminal command exceeded its deadline") from exc
        output = (completed.stdout + completed.stderr)[:limit]
        state = "exited" if completed.returncode == 0 else "failed"
        self.task.update_acp_terminal(terminal_id, state=state, output_bytes=len(output))
        self.journal.append(
            "acp",
            "PostToolUse" if completed.returncode == 0 else "PostToolUseFailure",
            {
                "terminal_id": terminal_id,
                "command_digest": command_digest,
                "returncode": completed.returncode,
                "output_digest": hashlib.sha256(output).hexdigest(),
                "output_bytes": len(output),
                "truncated": len(completed.stdout) + len(completed.stderr) > len(output),
            },
            session_id=connection.session_id,
            host_event_id=terminal_id + ":exit",
        )
        return {
            "schema_version": ACP_SCHEMA,
            "terminal_id": terminal_id,
            "returncode": completed.returncode,
            "output": output.decode("utf-8", errors="replace"),
            "truncated": len(completed.stdout) + len(completed.stderr) > len(output),
        }

    def _require_connection(self, connection: ACPConnection) -> Mapping[str, Any]:
        stored = self.task.acp_session(connection.connection_id)
        if (
            stored is None
            or str(stored.get("session_reference")) != connection.session_id
            or str(stored.get("worktree_lease_id")) != connection.worktree.lease_id
        ):
            raise PermissionError("ACP connection, session, or worktree identity mismatch")
        if stored.get("state") not in {"ready", "running"}:
            raise RuntimeError(f"ACP connection is not active: {stored.get('state')}")
        return stored

    def _owned_transport(self, connection_id: str) -> ACPTransport:
        with self._transport_lock:
            transport = self._transports.get(connection_id)
        if transport is None:
            raise RuntimeError("ACP connection has no active process transport")
        return transport


def _readonly_mcp_server(value: Mapping[str, Any]) -> Mapping[str, Any]:
    item = dict(value)
    metadata = item.get("_meta")
    if not isinstance(metadata, Mapping) or metadata.get("persistmindAccess") != "read-only":
        raise ValueError("ACP MCP endpoints must explicitly declare read-only PersistMind access")
    return _bounded_mapping(item)


def _bounded_mapping(value: Any) -> dict[str, Any]:
    result = dict(value) if isinstance(value, Mapping) else {}
    encoded = canonical_json(result).encode("utf-8")
    if len(encoded) > MAX_UPDATE_BYTES:
        return {
            "truncated": True,
            "original_bytes": len(encoded),
            "original_digest": hashlib.sha256(encoded).hexdigest(),
        }
    return result


def _digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


__all__ = [
    "ACP_PROTOCOL_VERSION",
    "ACP_SCHEMA",
    "ACP_SCHEMA_RELEASE",
    "ACPClientOrchestrator",
    "ACPConnection",
    "ACPTransport",
    "FakeACPTransport",
]
