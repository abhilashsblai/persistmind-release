from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from cryptography.hazmat.primitives.keywrap import aes_key_unwrap, aes_key_wrap

from persistmind.branding import KEYRING_SERVICE


class KeyProviderUnavailable(RuntimeError):
    """No approved external KEK provider is available."""


class EnvelopeAuthenticationFailed(RuntimeError):
    """An encrypted payload or its authenticated metadata was modified."""


_SERVICE = KEYRING_SERVICE
_BAD_BACKENDS = ("fail", "null", "plaintext", "chainer")


@dataclass(frozen=True, slots=True)
class WrappedDataKey:
    key_id: str
    wrapped_dek: str


class WorkspaceKeyProvider:
    """Workspace KEKs backed by an approved OS keyring.

    The file provider is deliberately reachable only through the explicit test/development
    switch. It keeps source-tree tests deterministic without weakening installed-product paths.
    """

    def __init__(self, workspace_root: Path, *, allow_test_provider: bool = False) -> None:
        self.workspace_root = workspace_root.resolve()
        self.allow_test_provider = allow_test_provider
        self.workspace_fingerprint = hashlib.sha256(
            str(self.workspace_root).encode("utf-8")
        ).hexdigest()

    def current_key_id(self) -> str:
        pointer = self.workspace_root / "keys" / "current.json"
        try:
            value = json.loads(pointer.read_text(encoding="utf-8"))
            key_id = str(value["key_id"])
        except (OSError, KeyError, json.JSONDecodeError):
            key_id = "workspace-kek-v1-" + self.workspace_fingerprint[:16]
        return key_id

    def create_generation(self) -> str:
        key_id = (
            "workspace-kek-"
            + datetime.now(UTC).strftime("%Y%m%d%H%M%S")
            + "-"
            + secrets.token_hex(4)
        )
        self.get_or_create(key_id)
        return key_id

    def set_current(self, key_id: str) -> None:
        self.get_or_create(key_id)
        path = self.workspace_root / "keys" / "current.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(".tmp")
        temporary.write_text(
            json.dumps(
                {
                    "schema_version": "persistmind.current_kek.v1",
                    "key_id": key_id,
                    "updated_at": datetime.now(UTC).isoformat(),
                },
                sort_keys=True,
                separators=(",", ":"),
            ),
            encoding="utf-8",
        )
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)

    def get_or_create(self, key_id: str | None = None) -> bytes:
        key_id = key_id or self.current_key_id()
        try:
            import keyring

            backend = (
                type(keyring.get_keyring()).__module__ + "." + type(keyring.get_keyring()).__name__
            )
            if any(token in backend.casefold() for token in _BAD_BACKENDS):
                raise KeyProviderUnavailable(f"unapproved keyring backend: {backend}")
            account = self._account(key_id)
            encoded = keyring.get_password(_SERVICE, account)
            if encoded is None:
                encoded = base64.b64encode(secrets.token_bytes(32)).decode("ascii")
                keyring.set_password(_SERVICE, account, encoded)
            key = base64.b64decode(encoded, validate=True)
            if len(key) != 32:
                raise KeyProviderUnavailable("workspace KEK has an invalid length")
            return key
        except Exception as exc:  # keyring backends fail in several environment-specific ways.
            if not self.allow_test_provider:
                if isinstance(exc, KeyProviderUnavailable):
                    raise
                raise KeyProviderUnavailable("approved OS keyring is unavailable") from exc
            return self._test_key(key_id)

    def wrap_new_dek(self) -> tuple[bytes, WrappedDataKey]:
        key_id = self.current_key_id()
        dek = secrets.token_bytes(32)
        wrapped = aes_key_wrap(self.get_or_create(key_id), dek)
        return dek, WrappedDataKey(
            key_id=key_id,
            wrapped_dek=base64.b64encode(wrapped).decode("ascii"),
        )

    def unwrap_dek(self, wrapped: WrappedDataKey) -> bytes:
        try:
            value = aes_key_unwrap(
                self.get_or_create(wrapped.key_id),
                base64.b64decode(wrapped.wrapped_dek, validate=True),
            )
        except Exception as exc:
            raise EnvelopeAuthenticationFailed("data key unwrap failed") from exc
        if len(value) != 32:
            raise EnvelopeAuthenticationFailed("unwrapped data key has an invalid length")
        return value

    def rewrap_dek(self, wrapped: WrappedDataKey, new_key_id: str) -> WrappedDataKey:
        dek = self.unwrap_dek(wrapped)
        value = aes_key_wrap(self.get_or_create(new_key_id), dek)
        return WrappedDataKey(
            key_id=new_key_id,
            wrapped_dek=base64.b64encode(value).decode("ascii"),
        )

    def _account(self, key_id: str) -> str:
        return f"{self.workspace_fingerprint}:{key_id}"

    def _test_key(self, key_id: str) -> bytes:
        path = self.workspace_root / "keys" / ".development-keks.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            values = json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            values = {}
        if not isinstance(values, dict):
            raise KeyProviderUnavailable("development KEK file is malformed")
        encoded = values.get(key_id)
        if not isinstance(encoded, str):
            encoded = base64.b64encode(secrets.token_bytes(32)).decode("ascii")
            values[key_id] = encoded
            temporary = path.with_suffix(".tmp")
            temporary.write_text(
                json.dumps(values, sort_keys=True, separators=(",", ":")),
                encoding="utf-8",
            )
            os.chmod(temporary, 0o600)
            os.replace(temporary, path)
        return base64.b64decode(encoded, validate=True)


def encrypt_chunk(
    plaintext: bytes,
    *,
    dek: bytes,
    aad_fields: dict[str, Any],
) -> tuple[bytes, dict[str, Any]]:
    nonce = secrets.token_bytes(12)
    aad = _canonical(aad_fields)
    ciphertext = AESGCM(dek).encrypt(nonce, plaintext, aad)
    return ciphertext, {
        "nonce": base64.b64encode(nonce).decode("ascii"),
        "aad_sha256": hashlib.sha256(aad).hexdigest(),
        "ciphertext_sha256": hashlib.sha256(ciphertext).hexdigest(),
        "ciphertext_bytes": len(ciphertext),
    }


def decrypt_chunk(
    ciphertext: bytes,
    *,
    dek: bytes,
    nonce: str,
    aad_fields: dict[str, Any],
    expected_aad_sha256: str,
    expected_ciphertext_sha256: str,
) -> bytes:
    aad = _canonical(aad_fields)
    if not secrets.compare_digest(hashlib.sha256(aad).hexdigest(), expected_aad_sha256):
        raise EnvelopeAuthenticationFailed("authenticated metadata mismatch")
    if not secrets.compare_digest(
        hashlib.sha256(ciphertext).hexdigest(), expected_ciphertext_sha256
    ):
        raise EnvelopeAuthenticationFailed("ciphertext hash mismatch")
    try:
        return AESGCM(dek).decrypt(base64.b64decode(nonce, validate=True), ciphertext, aad)
    except Exception as exc:
        raise EnvelopeAuthenticationFailed("AES-GCM authentication failed") from exc


def _canonical(value: dict[str, Any]) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode(
        "utf-8"
    )


def create_recovery_kit(
    workspace_root: Path,
    output: Path,
    *,
    allow_test_provider: bool = False,
    _scrypt_n: int = 2**18,
) -> tuple[dict[str, Any], str]:
    if _scrypt_n < 2**12 or _scrypt_n > 2**20 or _scrypt_n & (_scrypt_n - 1):
        raise ValueError("recovery kit scrypt cost must be a power of two from 2^12 to 2^20")
    root = workspace_root.resolve()
    target = output.resolve()
    if target.is_relative_to(root):
        raise ValueError("recovery kit must be written outside the workspace")
    if target.exists():
        raise FileExistsError(target)
    keys = WorkspaceKeyProvider(root, allow_test_provider=allow_test_provider)
    workspace_key_id = keys.current_key_id()
    audit_key_id = "audit-anchor-v1-" + keys.workspace_fingerprint[:16]
    secret = base64.b32encode(secrets.token_bytes(20)).decode("ascii").rstrip("=")
    salt = secrets.token_bytes(16)
    derived = Scrypt(salt=salt, length=32, n=_scrypt_n, r=8, p=1).derive(secret.encode("ascii"))
    nonce = secrets.token_bytes(12)
    aad = _canonical(
        {
            "schema_version": "persistmind-recovery-kit-v1",
            "workspace_fingerprint": keys.workspace_fingerprint,
        }
    )
    plaintext = _canonical(
        {
            "workspace_key_id": workspace_key_id,
            "workspace_kek": base64.b64encode(keys.get_or_create(workspace_key_id)).decode("ascii"),
            "audit_key_id": audit_key_id,
            "audit_anchor_key": base64.b64encode(keys.get_or_create(audit_key_id)).decode("ascii"),
        }
    )
    ciphertext = AESGCM(derived).encrypt(nonce, plaintext, aad)
    document = {
        "schema_version": "persistmind-recovery-kit-v1",
        "workspace_fingerprint": keys.workspace_fingerprint,
        "created_at": datetime.now(UTC).isoformat(),
        "workspace_key_id": workspace_key_id,
        "audit_key_id": audit_key_id,
        "kdf": {
            "algorithm": "scrypt",
            "salt": base64.b64encode(salt).decode("ascii"),
            "n": _scrypt_n,
            "r": 8,
            "p": 1,
            "length": 32,
        },
        "encryption": {
            "algorithm": "AES-256-GCM",
            "nonce": base64.b64encode(nonce).decode("ascii"),
            "ciphertext": base64.b64encode(ciphertext).decode("ascii"),
            "aad_sha256": hashlib.sha256(aad).hexdigest(),
        },
    }
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(document, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.chmod(target, 0o600)
    result = {
        "ok": True,
        "status": "created",
        "schema_version": "persistmind.recovery_kit_result.v1",
        "path": str(target),
        "fingerprint": hashlib.sha256(target.read_bytes()).hexdigest(),
        "workspace_key_id": workspace_key_id,
    }
    return result, secret


def verify_recovery_kit(path: Path, passphrase: str) -> dict[str, Any]:
    try:
        source = path.resolve()
        if source.stat().st_size > 65_536:
            raise ValueError("recovery kit exceeds 64 KiB")
        document = json.loads(source.read_text(encoding="utf-8"))
        if document.get("schema_version") != "persistmind-recovery-kit-v1":
            raise ValueError("unsupported recovery kit")
        kdf = document["kdf"]
        encryption = document["encryption"]
        if (
            kdf.get("algorithm") != "scrypt"
            or int(kdf["n"]) < 2**12
            or int(kdf["n"]) > 2**20
            or int(kdf["n"]) & (int(kdf["n"]) - 1)
            or int(kdf["r"]) != 8
            or int(kdf["p"]) != 1
            or int(kdf["length"]) != 32
        ):
            raise ValueError("recovery kit KDF parameters are outside policy")
        salt = base64.b64decode(kdf["salt"], validate=True)
        nonce = base64.b64decode(encryption["nonce"], validate=True)
        ciphertext = base64.b64decode(encryption["ciphertext"], validate=True)
        if len(salt) != 16 or len(nonce) != 12 or len(ciphertext) > 16_384:
            raise ValueError("recovery kit cryptographic fields are outside policy")
        aad = _canonical(
            {
                "schema_version": "persistmind-recovery-kit-v1",
                "workspace_fingerprint": document["workspace_fingerprint"],
            }
        )
        if hashlib.sha256(aad).hexdigest() != encryption["aad_sha256"]:
            raise ValueError("recovery kit metadata authentication mismatch")
        derived = Scrypt(
            salt=salt,
            length=int(kdf["length"]),
            n=int(kdf["n"]),
            r=int(kdf["r"]),
            p=int(kdf["p"]),
        ).derive(passphrase.strip().encode("ascii"))
        plaintext = AESGCM(derived).decrypt(
            nonce,
            ciphertext,
            aad,
        )
        keys = json.loads(plaintext)
    except Exception as exc:
        raise EnvelopeAuthenticationFailed("recovery kit verification failed") from exc
    return {
        "ok": True,
        "status": "verified",
        "schema_version": "persistmind.recovery_kit_verification.v1",
        "workspace_fingerprint": document["workspace_fingerprint"],
        "workspace_key_id": keys["workspace_key_id"],
        "audit_key_id": keys["audit_key_id"],
    }
