from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar

from persistmind.security.principals import Principal

_CURRENT_PRINCIPAL: ContextVar[Principal | None] = ContextVar(
    "persistmind_transport_principal", default=None
)


@contextmanager
def principal_scope(principal: Principal | None) -> Iterator[None]:
    token = _CURRENT_PRINCIPAL.set(principal)
    try:
        yield
    finally:
        _CURRENT_PRINCIPAL.reset(token)


def current_principal() -> Principal | None:
    return _CURRENT_PRINCIPAL.get()


def require_current_principal(*, roles: frozenset[str], action: str) -> Principal:
    principal = current_principal()
    if principal is None:
        raise PermissionError(f"{action} requires a transport-bound principal")
    if principal.is_expired():
        raise PermissionError("principal has expired")
    if not (principal.roles & roles):
        raise PermissionError(f"principal lacks required role for {action}")
    return principal
