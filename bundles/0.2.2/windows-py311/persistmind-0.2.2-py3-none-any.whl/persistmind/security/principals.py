from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path


@dataclass(frozen=True)
class Principal:
    subject: str
    roles: frozenset[str]
    repo_scopes: frozenset[str]
    workspace_scopes: frozenset[str]
    auth_source: str
    credential_id: str
    expires_at: str | None = None
    policy_version: str = "persistmind.rbac.v1"
    tenant_id: str | None = None

    def is_expired(self, now: datetime | None = None) -> bool:
        if not self.expires_at:
            return False
        instant = now or datetime.now(UTC)
        expiry = datetime.fromisoformat(self.expires_at.replace("Z", "+00:00"))
        return instant >= expiry

    def permits_repo(self, repo: str | Path) -> bool:
        expected = str(Path(repo).resolve()).casefold()
        return expected in {str(Path(item).resolve()).casefold() for item in self.repo_scopes}

    def permits_workspace(self, workspace: str | Path) -> bool:
        expected = str(Path(workspace).resolve()).casefold()
        return expected in {str(Path(item).resolve()).casefold() for item in self.workspace_scopes}


def anonymous_principal(repo: str | Path) -> Principal:
    scope = str(Path(repo).resolve())
    return Principal(
        subject="anonymous",
        roles=frozenset({"reader"}),
        repo_scopes=frozenset({scope}),
        workspace_scopes=frozenset({scope}),
        auth_source="none",
        credential_id="anonymous",
    )
