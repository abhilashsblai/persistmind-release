from __future__ import annotations

import getpass
import os
import socket
from dataclasses import dataclass
from pathlib import Path

from persistmind.security.principals import Principal
from persistmind.utils import stable_id


@dataclass(frozen=True, slots=True)
class RouteAction:
    prefix: str
    read_action: str = "http.read"
    mutation_action: str = "http.mutate"


HTTP_ROUTE_ACTIONS = (
    RouteAction("/v1/activity"),
    RouteAction("/v1/architecture"),
    RouteAction("/v1/audit", "sensitive.read"),
    RouteAction("/v1/business", "sensitive.read"),
    RouteAction("/v1/capabilities"),
    RouteAction("/v1/check-diff"),
    RouteAction("/v1/cie", "sensitive.read"),
    RouteAction("/v1/clarifications", "sensitive.read"),
    RouteAction("/v1/collector", "sensitive.read"),
    RouteAction("/v1/context-pack", "sensitive.read"),
    RouteAction("/v1/continuations", "sensitive.read"),
    RouteAction("/v1/codex", "sensitive.read"),
    RouteAction("/v1/dashboard", "sensitive.read"),
    RouteAction("/v1/db", "sensitive.read"),
    RouteAction("/v1/decision", "sensitive.read"),
    RouteAction("/v1/decisions", "sensitive.read"),
    RouteAction("/v1/eval"),
    RouteAction("/v1/goals", "sensitive.read"),
    RouteAction("/v1/governance", "sensitive.read"),
    RouteAction("/v1/guardrail", "sensitive.read"),
    RouteAction("/v1/health"),
    RouteAction("/v1/impact-report"),
    RouteAction("/v1/incidents", "sensitive.read"),
    RouteAction("/v1/feedback", "sensitive.read"),
    RouteAction("/v1/intent", "sensitive.read"),
    RouteAction("/v1/judgment", "sensitive.read"),
    RouteAction("/v1/learning", "sensitive.read"),
    RouteAction("/v1/memory", "sensitive.read"),
    RouteAction("/v1/metacognition", "sensitive.read"),
    RouteAction("/v1/metrics", "sensitive.read"),
    RouteAction("/v1/narrative", "sensitive.read"),
    RouteAction("/v1/org", "sensitive.read"),
    RouteAction("/v1/outcomes", "sensitive.read"),
    RouteAction("/v1/packs", "sensitive.read"),
    RouteAction("/v1/plans", "sensitive.read"),
    RouteAction("/v1/policies", "sensitive.read"),
    RouteAction("/v1/security", "sensitive.read"),
    RouteAction("/v1/selfmod", "sensitive.read"),
    RouteAction("/v1/semantic"),
    RouteAction("/v1/sessions", "sensitive.read"),
    RouteAction("/v1/skills", "sensitive.read"),
    RouteAction("/v1/snapshot"),
    RouteAction("/v1/source"),
    RouteAction("/v1/storage", "sensitive.read"),
    RouteAction("/v1/tasks", "sensitive.read"),
    RouteAction("/v1/teacher", "sensitive.read"),
)


_CLI_READ_OPERATIONS = frozenset(
    {
        "architecture",
        "behavior",
        "bench",
        "capability",
        "catalog",
        "check-diff",
        "constitution",
        "dashboard",
        "db-stats",
        "doctor",
        "graph",
        "holds",
        "impact",
        "internal",
        "inventory",
        "list",
        "manifest",
        "mcp",
        "memory-kinds",
        "models",
        "operations",
        "reconstruct-pack",
        "resolve-snapshot",
        "resources",
        "roles",
        "rollup",
        "schema",
        "search",
        "status",
        "storage-report",
        "topology",
        "version",
    }
)
_CLI_OPERATOR_OPERATIONS = frozenset(
    {
        "activity",
        "agent",
        "agent-runtime",
        "anticipate",
        "business",
        "ci",
        "cie",
        "clarify",
        "codex",
        "coordinator",
        "continuation",
        "create",
        "critique",
        "curriculum",
        "decision",
        "eval",
        "experience",
        "feedback",
        "flywheel",
        "foresight",
        "goal",
        "governance",
        "guardrail",
        "hook",
        "index",
        "intent",
        "judgment",
        "lesson",
        "loop",
        "metacog",
        "narrative",
        "nextgen",
        "npx",
        "orchestrator",
        "org",
        "outcome",
        "pack",
        "plan",
        "provider",
        "report",
        "reasoning",
        "registry",
        "runtime",
        "semantic",
        "serve",
        "session",
        "skill",
        "snapshot",
        "student",
        "task",
        "teach",
        "teacher-bench",
        "teacher-review",
        "tokens",
        "verify",
        "workflow",
        "working-memory",
        "workspace",
    }
)
_CLI_ADMIN_OPERATIONS = frozenset(
    {
        "apply",
        "audit",
        "backup",
        "bootstrap",
        "config",
        "db",
        "delete",
        "export",
        "erase",
        "finalize",
        "gc",
        "init",
        "import-legacy",
        "install",
        "incident",
        "keys",
        "learning",
        "maintenance",
        "memory",
        "migrate",
        "partitions",
        "policy",
        "project-upgrade",
        "reconcile",
        "recover",
        "release",
        "repair",
        "restore",
        "retention",
        "rollback",
        "security",
        "selfimprove",
        "setup",
        "quickstart",
        "storage",
        "stage",
        "submit",
        "update",
        "collector",
    }
)
CLI_COMMAND_ACTIONS = {
    **{operation: "http.read" for operation in _CLI_READ_OPERATIONS},
    **{operation: "http.mutate" for operation in _CLI_OPERATOR_OPERATIONS},
    **{operation: "admin.mutate" for operation in _CLI_ADMIN_OPERATIONS},
}


def cli_operation_action(operation: str) -> str | None:
    return CLI_COMMAND_ACTIONS.get(operation)


def http_route_action(method: str, path: str) -> str | None:
    normalized = path.rstrip("/") or "/"
    if normalized in {"/", "/dashboard"}:
        return "sensitive.read" if method.upper() == "GET" else None
    matches = [
        item
        for item in HTTP_ROUTE_ACTIONS
        if normalized == item.prefix or normalized.startswith(item.prefix + "/")
    ]
    if not matches:
        return None
    selected = max(matches, key=lambda item: len(item.prefix))
    if method.upper() == "GET":
        return selected.read_action
    if normalized.startswith("/v1/storage/keys"):
        return "storage.keys.rotate"
    if "/restore" in normalized and normalized.startswith("/v1/storage/backups"):
        return "storage.backup.restore"
    if normalized.startswith("/v1/storage/export"):
        return "storage.export"
    administrative_segments = {
        "adopt",
        "approve",
        "delete",
        "gating-baseline",
        "gc",
        "promote",
        "reconcile",
        "reject",
        "repair",
        "resolve",
        "restore",
        "rollback",
        "rotate",
    }
    if administrative_segments & set(normalized.split("/")):
        return "admin.mutate"
    return selected.mutation_action


def local_cli_principal(repo: str | Path) -> Principal:
    scope = str(Path(repo).expanduser().resolve())
    user = getpass.getuser() or "local-user"
    host = socket.gethostname() or "local-host"
    process_owner = str(getattr(os, "getuid", lambda: user)())
    credential_id = stable_id("local-cli", host, user, process_owner)[:24]
    return Principal(
        subject=f"local-cli:{user}",
        roles=frozenset({"reader", "operator", "admin"}),
        repo_scopes=frozenset({scope}),
        workspace_scopes=frozenset({scope}),
        auth_source="os-local",
        credential_id=credential_id,
    )
