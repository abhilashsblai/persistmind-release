from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from persistmind.security.principals import Principal

POLICY_VERSION = "persistmind.rbac.v1"


@dataclass(frozen=True)
class PolicyRule:
    action: str
    roles: frozenset[str]
    mutation: bool


RULES = {
    "http.read": PolicyRule("http.read", frozenset({"reader", "operator", "admin"}), False),
    "http.mutate": PolicyRule("http.mutate", frozenset({"operator", "admin"}), True),
    "mcp.read": PolicyRule("mcp.read", frozenset({"reader", "operator", "admin"}), False),
    "admin.mutate": PolicyRule("admin.mutate", frozenset({"admin"}), True),
    "sensitive.read": PolicyRule("sensitive.read", frozenset({"operator", "admin"}), False),
    "hook.ingest": PolicyRule("hook.ingest", frozenset({"hook", "admin"}), True),
    "policy.approve": PolicyRule("policy.approve", frozenset({"admin"}), True),
    "audit.gating_baseline": PolicyRule("audit.gating_baseline", frozenset({"admin"}), True),
    "learning.promote": PolicyRule("learning.promote", frozenset({"admin"}), True),
    "storage.partition.rotate": PolicyRule("storage.partition.rotate", frozenset({"admin"}), True),
    "storage.repair": PolicyRule("storage.repair", frozenset({"admin"}), True),
    "storage.backup.restore": PolicyRule("storage.backup.restore", frozenset({"admin"}), True),
    "storage.export": PolicyRule("storage.export", frozenset({"admin"}), False),
    "storage.retention.apply": PolicyRule("storage.retention.apply", frozenset({"admin"}), True),
    "storage.delete": PolicyRule("storage.delete", frozenset({"admin"}), True),
    "storage.keys.rotate": PolicyRule("storage.keys.rotate", frozenset({"admin"}), True),
}


def require_authorized(principal: Principal, action: str, repo: str | Path) -> None:
    rule = RULES.get(action)
    if rule is None:
        raise PermissionError(f"unknown RBAC action denied: {action}")
    if principal.policy_version != POLICY_VERSION:
        raise PermissionError("principal policy version is stale")
    if principal.is_expired():
        raise PermissionError("principal has expired")
    if not principal.permits_repo(repo):
        raise PermissionError("principal repository scope mismatch")
    if not principal.permits_workspace(repo):
        raise PermissionError("principal workspace scope mismatch")
    if not (principal.roles & rule.roles):
        raise PermissionError(f"principal lacks required role for {action}")
