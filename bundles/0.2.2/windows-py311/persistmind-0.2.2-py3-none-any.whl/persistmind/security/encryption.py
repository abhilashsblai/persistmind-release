from __future__ import annotations

import os
import platform
import subprocess
from pathlib import Path


def encryption_status(db_path: Path, enabled: bool) -> dict[str, object]:
    volume = volume_encryption_status(db_path)
    return {
        "enabled": bool(enabled and volume["verified"]),
        "db_path": str(db_path),
        "mode": "verified-encrypted-volume" if volume["verified"] else "acl-only",
        "volume": volume,
        "confidential_persistence_allowed": bool(volume["verified"]),
    }


def volume_encryption_status(path: Path) -> dict[str, object]:
    """Prove host-volume encryption without treating configuration as evidence."""

    target = path.resolve()
    system = platform.system().lower()
    try:
        if system == "windows":
            drive = target.drive or os.path.splitdrive(str(target))[0]
            completed = subprocess.run(
                ["manage-bde", "-status", drive],
                check=False,
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = completed.stdout.casefold()
            verified = (
                completed.returncode == 0
                and "protection status" in output
                and "protection on" in output
            )
            return {
                "verified": verified,
                "provider": "bitlocker",
                "target": drive,
                "reason": None
                if verified
                else "BitLocker protection could not be positively verified",
            }
        if system == "darwin":
            completed = subprocess.run(
                ["diskutil", "info", str(target)],
                check=False,
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = completed.stdout.casefold()
            verified = completed.returncode == 0 and (
                "filevault: yes" in output or "encrypted: yes" in output
            )
            return {
                "verified": verified,
                "provider": "filevault",
                "target": str(target),
                "reason": None
                if verified
                else "FileVault encryption could not be positively verified",
            }
        completed = subprocess.run(
            ["findmnt", "-no", "source", "--target", str(target)],
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )
        source = completed.stdout.strip()
        crypt = (
            subprocess.run(
                ["lsblk", "-no", "type", source],
                check=False,
                capture_output=True,
                text=True,
                timeout=10,
            )
            if source
            else None
        )
        verified = bool(crypt and crypt.returncode == 0 and "crypt" in crypt.stdout.casefold())
        return {
            "verified": verified,
            "provider": "dm-crypt",
            "target": source or str(target),
            "reason": None
            if verified
            else "dm-crypt/LUKS encryption could not be positively verified",
        }
    except (OSError, subprocess.SubprocessError) as exc:
        return {
            "verified": False,
            "provider": system or "unknown",
            "target": str(target),
            "reason": f"volume encryption probe failed: {type(exc).__name__}",
        }
