from __future__ import annotations

import base64
import hashlib
from pathlib import Path
from typing import Any, Mapping

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

from persistmind.utils import canonical_json

from .envelope import WorkspaceKeyProvider


class WorkspaceApprovalSigner:
    """Keyring-backed Ed25519 signatures for local governed approvals."""

    def __init__(
        self,
        workspace_root: Path,
        *,
        principal: str,
        allow_test_provider: bool = False,
    ) -> None:
        self.principal = principal.strip()
        if not self.principal:
            raise ValueError("approval signer requires an authorized principal")
        self.keys = WorkspaceKeyProvider(workspace_root, allow_test_provider=allow_test_provider)
        principal_hash = hashlib.sha256(self.principal.encode("utf-8")).hexdigest()[:16]
        self.key_id = (
            "approval-ed25519-v2-" + self.keys.workspace_fingerprint[:16] + "-" + principal_hash
        )

    def identity(self) -> dict[str, str]:
        private = Ed25519PrivateKey.from_private_bytes(self.keys.get_or_create(self.key_id))
        public_bytes = private.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
        return {
            "principal": self.principal,
            "key_id": self.key_id,
            "public_key_fingerprint": hashlib.sha256(public_bytes).hexdigest(),
            "public_key": base64.b64encode(public_bytes).decode("ascii"),
        }

    def sign(self, document: Mapping[str, Any]) -> str:
        key = Ed25519PrivateKey.from_private_bytes(self.keys.get_or_create(self.key_id))
        signature = key.sign(canonical_json(dict(document)).encode("utf-8"))
        identity = self.identity()
        encoded_principal = base64.urlsafe_b64encode(self.principal.encode("utf-8")).decode("ascii")
        return ":".join(
            (
                "ed25519-v2",
                self.key_id,
                encoded_principal,
                identity["public_key_fingerprint"],
                base64.b64encode(signature).decode("ascii"),
            )
        )

    def verify(self, signature: str, document: Mapping[str, Any]) -> bool:
        try:
            algorithm, key_id, encoded_principal, fingerprint, encoded = signature.split(":", 4)
            principal = base64.urlsafe_b64decode(encoded_principal).decode("utf-8")
            if (
                algorithm != "ed25519-v2"
                or key_id != self.key_id
                or principal != self.principal
                or fingerprint != self.identity()["public_key_fingerprint"]
            ):
                return False
            private = Ed25519PrivateKey.from_private_bytes(self.keys.get_or_create(key_id))
            private.public_key().verify(
                base64.b64decode(encoded, validate=True),
                canonical_json(dict(document)).encode("utf-8"),
            )
        except (ValueError, UnicodeDecodeError, InvalidSignature):
            return False
        return True


def require_approval_signature(
    workspace_root: Path,
    signature: str,
    document: Mapping[str, Any],
    *,
    expected_principal: str,
    allow_test_provider: bool,
) -> dict[str, str]:
    signer = WorkspaceApprovalSigner(
        workspace_root,
        principal=expected_principal,
        allow_test_provider=allow_test_provider,
    )
    if not signer.verify(signature, document):
        raise PermissionError("approval signature is not valid for this workspace and action")
    return signer.identity()


def require_approval_quorum(
    workspace_root: Path,
    approvals: list[Mapping[str, str]],
    document: Mapping[str, Any],
    *,
    quorum: int,
    allow_test_provider: bool = False,
) -> list[dict[str, str]]:
    if quorum < 1:
        raise ValueError("approval quorum must be positive")
    identities = [
        require_approval_signature(
            workspace_root,
            str(approval.get("signature") or ""),
            document,
            expected_principal=str(approval.get("principal") or ""),
            allow_test_provider=allow_test_provider,
        )
        for approval in approvals
    ]
    principals = {item["principal"] for item in identities}
    fingerprints = {item["public_key_fingerprint"] for item in identities}
    if len(identities) < quorum or len(principals) < quorum or len(fingerprints) < quorum:
        raise PermissionError(
            "approval quorum requires distinct authorized principals and Ed25519 keys"
        )
    return identities
