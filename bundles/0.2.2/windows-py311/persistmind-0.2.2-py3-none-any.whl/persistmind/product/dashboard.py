from __future__ import annotations

import html
import json
import sqlite3
from pathlib import Path
from typing import Any

from persistmind.http.routes import ROUTES
from persistmind.release import validate_gap_register
from persistmind.utils import stable_id


class Dashboard:
    def __init__(self, store: Any, *, repo_root: Path | None = None):
        self.store = store
        self.repo_root = repo_root.resolve() if repo_root else None

    def data(self) -> dict[str, Any]:
        candidates = [dict(row) for row in self.store.business_rule_candidates("candidate")]
        active = [dict(row) for row in self.store.business_rules("active")]
        stale = []
        for rule in active:
            evidence = [dict(row) for row in self.store.rule_evidence(rule["rule_id"])]
            if not evidence:
                stale.append({"rule_id": rule["rule_id"], "reason": "no evidence"})
        ci = [
            dict(row)
            for row in self.store.conn.execute(
                "SELECT * FROM ci_reports ORDER BY created_at DESC LIMIT 20"
            ).fetchall()
        ]
        learning_events = []
        for row in self.store.learning_events(limit=20):
            event = dict(row)
            try:
                event["payload"] = json.loads(event.pop("payload_json") or "{}")
            except json.JSONDecodeError:
                event["payload"] = {}
            learning_events.append(event)
        recent_learning = [
            _task_learning_row(row) for row in self.store.task_learning_summaries(limit=20)
        ]
        skills = [dict(row) for row in self.store.skills(limit=20)]
        optimization_runs = []
        for row in self.store.learning_runs(limit=20):
            item = dict(row)
            for key in [
                "before_json",
                "after_json",
                "train_metrics_json",
                "holdout_metrics_json",
            ]:
                try:
                    item[key.removesuffix("_json")] = json.loads(item.pop(key) or "{}")
                except json.JSONDecodeError:
                    item[key.removesuffix("_json")] = {}
            item["gate_pass"] = bool(item["gate_pass"])
            item["archived"] = bool(item["archived"])
            item["promoted"] = bool(item["promoted"])
            optimization_runs.append(item)
        selfmod_runs = [item for item in optimization_runs if item.get("kind") == "selfmod_variant"]
        benchmark_trends = [
            _benchmark_row(row) for row in self.store.agent_benchmark_runs(limit=30)
        ]
        efficacy_scorecards = [
            _efficacy_scorecard_row(row) for row in self.store.efficacy_scorecards(limit=20)
        ]
        intents = _intent_views(self.store)
        goals = _goal_views(self.store)
        decisions = _decision_views(self.store)
        extraction_quality = _extraction_quality_views(self.store)
        latest_efficacy = efficacy_scorecards[0] if efficacy_scorecards else None
        audit = self.store.verify_audit_chain()
        concurrency = self.store.concurrency_stats()
        graph = self.store.graph_stats()
        semantic_quality = _semantic_quality_views(graph)
        business_graph = graph.get("business_graph") or {}
        org_ingestion = graph.get("org_ingestion") or {}
        h4_security = _h4_security_views(learning_events)
        cie = _cie_views(self.store)
        guardrails = _guardrail_views(self.store)
        flywheel = _flywheel_views(self.store, repo_root=self.repo_root)
        projects = self._projects()
        lifecycle = _lifecycle_views(self.store)
        gap_register = validate_gap_register(self.repo_root) if self.repo_root else {"ok": False}
        release_views = _release_views(
            gap_register=gap_register,
            benchmark_trends=benchmark_trends,
            efficacy_scorecard=latest_efficacy,
        )
        interface_parity = _interface_parity_matrix()
        codex_parallel = _codex_parallel_summary(self.store)
        teacher = _teacher_views(self.store)
        db_stats = self.store.db_stats()
        storage_report = self.store.storage_report(limit=20)
        functionality = _functionality_status(
            candidates=candidates,
            active=active,
            stale=stale,
            ci=ci,
            graph=graph,
            learning_events=learning_events,
            optimization_runs=optimization_runs,
            skills=skills,
            benchmark_trends=benchmark_trends,
            efficacy_scorecard=latest_efficacy,
            audit=audit,
            projects=projects,
            lifecycle=lifecycle,
            release_views=release_views,
            interface_parity=interface_parity,
            codex_parallel=codex_parallel,
            concurrency=concurrency,
            h4_security=h4_security,
            decisions=decisions,
        )
        issues = _issues(
            candidates=candidates,
            stale=stale,
            ci=ci,
            audit=audit,
            projects=projects,
            functionality=functionality,
            gap_register=gap_register,
        )
        overview = _overview(
            candidates=candidates,
            active=active,
            stale=stale,
            ci=ci,
            graph=graph,
            learning_events=learning_events,
            optimization_runs=optimization_runs,
            skills=skills,
            efficacy_scorecard=latest_efficacy,
            audit=audit,
            projects=projects,
            issues=issues,
            lifecycle=lifecycle,
            release_views=release_views,
            interface_parity=interface_parity,
            codex_parallel=codex_parallel,
            concurrency=concurrency,
            h4_security=h4_security,
            decisions=decisions,
        )
        return {
            "overview": overview,
            "functionality": functionality,
            "projects": projects,
            "issues": issues,
            "rules_awaiting_approval": candidates,
            "active_rules": active,
            "stale_rules": stale,
            "recent_ci_reports": ci,
            "cross_repo_edges": self.store.logical_edges("src_repo_id != dst_repo_id")[:100],
            "graph": graph,
            "semantic_quality": semantic_quality,
            "business_graph": business_graph,
            "org_ingestion": org_ingestion,
            "learning_events": learning_events,
            "recent_learning": recent_learning,
            "optimization_runs": optimization_runs,
            "selfmod_runs": selfmod_runs,
            "benchmark_trends": benchmark_trends,
            "benchmark_trend_summary": _benchmark_summary(benchmark_trends),
            "efficacy_scorecard": latest_efficacy or {},
            "efficacy_scorecards": efficacy_scorecards,
            "efficacy_summary": _efficacy_summary(efficacy_scorecards),
            "intents": intents,
            "intent_summary": _intent_summary(intents),
            "goals": goals,
            "goal_summary": _goal_summary(goals),
            "decisions": decisions,
            "decision_summary": _decision_summary(decisions),
            "extraction_quality": extraction_quality,
            "extraction_quality_summary": _extraction_quality_summary(extraction_quality),
            "semantic_quality_summary": _semantic_quality_summary(semantic_quality),
            "skills": skills,
            "lifecycle_views": lifecycle,
            "interface_parity": interface_parity,
            "release_views": release_views,
            "codex_parallel": codex_parallel,
            "teacher": teacher,
            "db_stats": db_stats,
            "storage_report": storage_report,
            "concurrency": concurrency,
            "h4_security": h4_security,
            "cie": cie,
            "guardrails": guardrails,
            "flywheel": flywheel,
            "gap_register": gap_register,
            "audit": audit,
        }

    def render_html(self, output: Path) -> dict[str, Any]:
        data = self.data()
        body = render_dashboard_html(data)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(body, encoding="utf-8")
        return {"ok": True, "output": str(output)}

    def _projects(self) -> list[dict[str, Any]]:
        workspace_root = str(self.repo_root or Path.cwd())
        rows = [dict(row) for row in self.store.workspace_repos(workspace_root)]
        if self.repo_root and not any(
            Path(row["root_path"]).resolve() == self.repo_root for row in rows
        ):
            rows.insert(
                0,
                {
                    "workspace_repo_id": stable_id(workspace_root, "current", str(self.repo_root)),
                    "workspace_root": workspace_root,
                    "repo_id": stable_id(str(self.repo_root))[:16],
                    "name": self.repo_root.name or "current",
                    "root_path": str(self.repo_root),
                },
            )
        projects = []
        for row in rows:
            projects.append(_project_from_row(row))
        return projects


def render_dashboard_html(data: dict[str, Any]) -> str:
    payload = html.escape(json.dumps(_public_payload(data), sort_keys=True), quote=False)
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PersistMind Control Surface</title>
<style>
:root {{
  --ink: #151515;
  --muted: #66615a;
  --paper: #f7f2e8;
  --panel: #fffaf0;
  --line: #28231d;
  --good: #1f7a4d;
  --warn: #a55c12;
  --bad: #ad2e2e;
  --blue: #28638a;
  --steel: #5b6470;
}}
* {{ box-sizing: border-box; }}
body {{
  margin: 0;
  color: var(--ink);
  background:
    linear-gradient(90deg, rgba(21,21,21,.045) 1px, transparent 1px),
    linear-gradient(0deg, rgba(21,21,21,.035) 1px, transparent 1px),
    var(--paper);
  background-size: 32px 32px;
  font-family: Georgia, "Times New Roman", serif;
}}
button, code, .mono, table {{
  font-family: "Cascadia Mono", "SFMono-Regular", Consolas, monospace;
}}
.shell {{
  max-width: 1420px;
  margin: 0 auto;
  padding: 28px;
}}
.masthead {{
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 24px;
  align-items: end;
  border-bottom: 3px solid var(--line);
  padding-bottom: 18px;
}}
h1 {{
  margin: 0;
  font-size: clamp(2rem, 4vw, 4.8rem);
  line-height: .95;
  letter-spacing: 0;
}}
.subtitle {{
  margin: 12px 0 0;
  color: var(--muted);
  max-width: 860px;
  font-size: 1.02rem;
  line-height: 1.55;
}}
.stamp {{
  border: 2px solid var(--line);
  background: var(--panel);
  padding: 12px 14px;
  min-width: 230px;
  box-shadow: 6px 6px 0 rgba(21,21,21,.16);
}}
.stamp strong {{ display: block; font-size: 1.7rem; }}
.stamp span {{ color: var(--muted); }}
.tabs {{
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  margin: 22px 0;
}}
.tab {{
  border: 2px solid var(--line);
  background: var(--panel);
  color: var(--ink);
  padding: 10px 14px;
  cursor: pointer;
  min-height: 42px;
}}
.tab[aria-selected="true"] {{
  background: var(--line);
  color: var(--paper);
}}
.tab-panel {{ display: none; }}
.tab-panel.active {{ display: block; }}
.grid {{
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 14px;
}}
.card {{
  border: 2px solid var(--line);
  background: rgba(255,250,240,.92);
  padding: 16px;
  min-height: 128px;
}}
.metric {{
  font-size: 2.2rem;
  line-height: 1;
  margin-top: 8px;
}}
.label, .kicker {{
  color: var(--muted);
  text-transform: uppercase;
  font-size: .78rem;
}}
.status {{
  display: inline-flex;
  align-items: center;
  gap: 7px;
  border: 1px solid var(--line);
  padding: 5px 8px;
  background: #fff;
  white-space: nowrap;
}}
.dot {{ width: 10px; height: 10px; border-radius: 50%; display: inline-block; }}
.ok .dot {{ background: var(--good); }}
.warning .dot {{ background: var(--warn); }}
.issue .dot, .missing .dot {{ background: var(--bad); }}
.idle .dot {{ background: var(--steel); }}
.section {{
  margin-top: 18px;
}}
.section h2 {{
  margin: 0 0 10px;
  font-size: 1.55rem;
}}
.feature-grid {{
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
}}
.feature-card {{
  border: 2px solid var(--line);
  background: var(--panel);
  padding: 14px;
  min-height: 150px;
}}
.feature-card h3 {{
  margin: 10px 0 8px;
  font-size: 1.08rem;
}}
.feature-card p {{
  margin: 0;
  color: var(--muted);
  line-height: 1.45;
}}
.project-table, .issue-table {{
  width: 100%;
  border-collapse: collapse;
  background: var(--panel);
  border: 2px solid var(--line);
}}
th, td {{
  text-align: left;
  vertical-align: top;
  border-bottom: 1px solid rgba(21,21,21,.22);
  padding: 12px;
}}
th {{
  background: rgba(21,21,21,.08);
  font-size: .82rem;
  text-transform: uppercase;
}}
tr.issue-row {{
  background: rgba(173,46,46,.08);
}}
.progress {{
  height: 11px;
  border: 1px solid var(--line);
  background: #e4ddd0;
  overflow: hidden;
  width: min(190px, 100%);
}}
.progress > span {{
  display: block;
  height: 100%;
  background: linear-gradient(90deg, var(--good), var(--blue));
}}
.pill-list {{
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 8px;
}}
.pill {{
  border: 1px solid rgba(21,21,21,.45);
  padding: 3px 7px;
  background: #fff;
  font-size: .82rem;
}}
pre {{
  overflow: auto;
  border: 2px solid var(--line);
  background: #fff;
  padding: 14px;
  max-height: 420px;
}}
svg {{
  max-width: 100%;
  background: #fffaf0;
  border: 2px solid var(--line);
}}
@media (max-width: 980px) {{
  .masthead, .grid, .feature-grid {{ grid-template-columns: 1fr; }}
  .shell {{ padding: 18px; }}
  table, thead, tbody, th, td, tr {{ display: block; }}
  th {{ display: none; }}
  td {{ border-bottom: 0; padding: 8px 12px; }}
  td::before {{
    content: attr(data-label);
    display: block;
    color: var(--muted);
    text-transform: uppercase;
    font-size: .72rem;
    margin-bottom: 3px;
  }}
  tr {{ border-bottom: 1px solid rgba(21,21,21,.25); }}
}}
</style>
</head>
<body>
<main class="shell">
  <header class="masthead">
    <div>
      <p class="kicker">Local-first agent control plane</p>
      <h1>PersistMind Control Surface</h1>
      <p class="subtitle">Operational dashboard for context packs, graph coverage, memory, learning gates, audit health, and installed project progress.</p>
    </div>
    <div class="stamp">
      <span>Overall state</span>
      <strong>{html.escape(str(data["overview"]["health"]).upper())}</strong>
      <span>{len(data["issues"])} open issue(s)</span>
    </div>
  </header>

  <nav class="tabs" aria-label="Dashboard sections">
    <button class="tab" data-tab="overview" aria-selected="true">Overview</button>
    <button class="tab" data-tab="functions" aria-selected="false">Functionality</button>
    <button class="tab" data-tab="flywheel" aria-selected="false">Flywheel</button>
    <button class="tab" data-tab="memory" aria-selected="false">Memory OS</button>
    <button class="tab" data-tab="continuations" aria-selected="false">Continuations</button>
    <button class="tab" data-tab="skills" aria-selected="false">Skills</button>
    <button class="tab" data-tab="security" aria-selected="false">Security Reviews</button>
    <button class="tab" data-tab="selfmod" aria-selected="false">Self-Mod Archive</button>
    <button class="tab" data-tab="codex" aria-selected="false">Codex Parallel</button>
    <button class="tab" data-tab="teacher" aria-selected="false">Teacher</button>
    <button class="tab" data-tab="storage" aria-selected="false">Storage</button>
    <button class="tab" data-tab="release" aria-selected="false">Release Gates</button>
    <button class="tab" data-tab="projects" aria-selected="false">Projects</button>
    <button class="tab" data-tab="issues" aria-selected="false">Issues</button>
    <button class="tab" data-tab="raw" aria-selected="false">Raw data</button>
  </nav>

  <section id="overview" class="tab-panel active">
    {_overview_html(data)}
  </section>
  <section id="functions" class="tab-panel">
    {_functionality_html(data["functionality"])}
  </section>
  <section id="flywheel" class="tab-panel">
    {_flywheel_html(data["flywheel"])}
  </section>
  <section id="memory" class="tab-panel">
    {_json_section_html("Memory OS lifecycle", data["lifecycle_views"]["memory"])}
    {_json_section_html("Guardrails", data["guardrails"])}
  </section>
  <section id="continuations" class="tab-panel">
    {_json_section_html("Continuation lifecycle", data["lifecycle_views"]["continuations"])}
  </section>
  <section id="skills" class="tab-panel">
    {_json_section_html("Skill lifecycle", data["lifecycle_views"]["skills"])}
  </section>
  <section id="security" class="tab-panel">
    {_json_section_html("Security review workflow", data["lifecycle_views"]["security_reviews"])}
  </section>
  <section id="selfmod" class="tab-panel">
    {_json_section_html("Self-mod and optimizer archive", data["lifecycle_views"]["selfmod"])}
  </section>
  <section id="codex" class="tab-panel">
    {_json_section_html("Codex parallel-agent runs", data["codex_parallel"])}
  </section>
  <section id="teacher" class="tab-panel">
    {_json_section_html("Teacher runtime, reviews, graph, orchestration, and benchmarks", data["teacher"])}
  </section>
  <section id="storage" class="tab-panel">
    {_storage_html(data["storage_report"])}
  </section>
  <section id="release" class="tab-panel">
    {_release_html(data)}
  </section>
  <section id="projects" class="tab-panel">
    {_projects_html(data["projects"])}
  </section>
  <section id="issues" class="tab-panel">
    {_issues_html(data["issues"])}
  </section>
  <section id="raw" class="tab-panel">
    <pre id="dashboard-json">{payload}</pre>
  </section>
</main>
<script>
const buttons = document.querySelectorAll(".tab");
const panels = document.querySelectorAll(".tab-panel");
buttons.forEach((button) => {{
  button.addEventListener("click", () => {{
    const target = button.dataset.tab;
    buttons.forEach((item) => item.setAttribute("aria-selected", String(item === button)));
    panels.forEach((panel) => panel.classList.toggle("active", panel.id === target));
  }});
}});
</script>
</body>
</html>
"""


def _overview_html(data: dict[str, Any]) -> str:
    overview = data["overview"]
    cards = [
        (
            "Projects",
            overview["projects_total"],
            f"{overview['projects_attention']} need attention",
        ),
        (
            "Functions active",
            overview["functions_active"],
            f"{overview['functions_total']} tracked",
        ),
        ("Open issues", overview["issues_total"], "warnings and blockers"),
        ("Audit", "OK" if overview["audit_ok"] else "Check", "hash-chain verification"),
        ("Graph files", overview["graph_files"], "indexed file count"),
        (
            "Rules",
            overview["active_rules"],
            f"{overview['pending_rules']} pending approval",
        ),
        (
            "Learning runs",
            overview["learning_runs"],
            f"{overview['learning_promoted']} promoted",
        ),
        ("Recent CI", overview["ci_reports"], "stored reports"),
        (
            "Efficacy gate",
            overview["efficacy_gate"],
            f"{overview['efficacy_runs']} scorecard run(s)",
        ),
    ]
    return f"""
    <div class="grid">{"".join(_metric_card(*card) for card in cards)}</div>
    <div class="section">
      <h2>Release gates</h2>
      <pre>{html.escape(json.dumps(data["release_views"], indent=2, sort_keys=True))}</pre>
    </div>
    <div class="section">
      <h2>Efficacy scorecard</h2>
      <pre>{html.escape(json.dumps(data["efficacy_summary"], indent=2, sort_keys=True))}</pre>
      {_efficacy_trend_html(data["efficacy_scorecards"])}
    </div>
    <div class="section">
      <h2>Benchmark lift</h2>
      <pre>{html.escape(json.dumps(data["benchmark_trend_summary"], indent=2, sort_keys=True))}</pre>
      {_benchmark_trend_html(data["benchmark_trends"])}
    </div>
    <div class="section">
      <h2>Audit health</h2>
      <pre>{html.escape(json.dumps(data["audit"], indent=2, sort_keys=True))}</pre>
    </div>
"""


def _metric_card(title: str, value: Any, detail: str) -> str:
    return f"""
    <article class="card">
      <div class="label">{html.escape(title)}</div>
      <div class="metric">{html.escape(str(value))}</div>
      <p>{html.escape(detail)}</p>
    </article>
"""


def _functionality_html(items: list[dict[str, Any]]) -> str:
    cards = []
    for item in items:
        status = str(item["status"])
        cards.append(
            f"""
      <article class="feature-card {html.escape(status)}">
        {_status_badge(status)}
        <h3>{html.escape(item["name"])}</h3>
        <p>{html.escape(item["summary"])}</p>
        <div class="pill-list">
          {"".join(f'<span class="pill">{html.escape(str(metric))}</span>' for metric in item.get("metrics", []))}
        </div>
      </article>
"""
        )
    return f"""
    <div class="feature-grid">{"".join(cards)}</div>
"""


def _storage_html(report: dict[str, Any]) -> str:
    db = report.get("db", {})
    pinning = report.get("pinning", {})
    redundant = report.get("redundant_vectors", {})
    chunk_vector_bytes = redundant.get("redundant_chunk_vector_json_bytes")
    memory_vector_bytes = redundant.get("redundant_memory_vector_json_bytes")
    vector_json_bytes = (
        "check gc"
        if chunk_vector_bytes is None or memory_vector_bytes is None
        else int(chunk_vector_bytes) + int(memory_vector_bytes)
    )
    cards = [
        ("DB bytes", db.get("db_bytes", 0), f"WAL {db.get('wal_bytes', 0)}"),
        (
            "Pinned snapshots",
            pinning.get("pinned_snapshot_count", 0),
            f"budget {pinning.get('max_pinned_snapshots', 0)}",
        ),
        (
            "Dirty pins",
            pinning.get("dirty_pinned_snapshot_count", 0),
            f"{pinning.get('releasable_pack_pin_count', 0)} releasable",
        ),
        (
            "Vector JSON bytes",
            vector_json_bytes,
            "redundant when sqlite-vec rows exist",
        ),
    ]
    return f"""
    <div class="grid">{"".join(_metric_card(*card) for card in cards)}</div>
    <div class="section">
      <h2>Storage report</h2>
      <pre>{html.escape(json.dumps(report, indent=2, sort_keys=True))}</pre>
    </div>
"""


def _flywheel_html(flywheel: dict[str, Any]) -> str:
    summary = flywheel.get("summary", {})
    cards = [
        (
            "Flywheel",
            summary.get("status", "incomplete"),
            f"{summary.get('passing_components', 0)} of {summary.get('component_count', 0)} components passing",
        ),
        (
            "Reasoning cycles",
            summary.get("reasoning_cycles", 0),
            f"{summary.get('active_working_memory_notes', 0)} active working-memory notes",
        ),
        (
            "Narrative",
            "Present" if summary.get("narrative_present") else "Missing",
            "latest agent narrative",
        ),
        (
            "World model",
            "Present" if summary.get("world_model_present") else "Missing",
            "latest version and eval telemetry",
        ),
    ]
    return f"""
    <div class="grid">{"".join(_metric_card(*card) for card in cards)}</div>
    {_json_section_html("Narrative and world model", flywheel)}
"""


def _projects_html(projects: list[dict[str, Any]]) -> str:
    if not projects:
        return "<p>No projects are registered in this workspace yet.</p>"
    rows = []
    for project in projects:
        issues = project.get("issues", [])
        row_class = "issue-row" if issues else ""
        progress = int(project.get("progress", 0))
        rows.append(
            f"""
      <tr class="{row_class}">
        <td data-label="Project"><strong>{html.escape(project["name"])}</strong><br><span class="mono">{html.escape(project["project_id"])}</span></td>
        <td data-label="Status">{_status_badge(project["status"])}<div class="pill-list">{"".join(f'<span class="pill">{html.escape(flag)}</span>' for flag in project.get("flags", []))}</div></td>
        <td data-label="Progress"><div class="progress" aria-label="{progress} percent"><span style="width:{progress}%"></span></div><span>{progress}%</span></td>
        <td data-label="Activity">{html.escape(project.get("activity", "No activity"))}</td>
        <td data-label="Issues">{html.escape("; ".join(issues) if issues else "None")}</td>
      </tr>
"""
        )
    return f"""
    <table class="project-table">
      <thead><tr><th>Project</th><th>Status</th><th>Progress</th><th>Activity</th><th>Issues</th></tr></thead>
      <tbody>{"".join(rows)}</tbody>
    </table>
"""


def _issues_html(issues: list[dict[str, Any]]) -> str:
    if not issues:
        return "<p>No open dashboard issues.</p>"
    rows = []
    for issue in issues:
        rows.append(
            f"""
      <tr class="issue-row">
        <td data-label="Severity">{_status_badge(issue["severity"])}</td>
        <td data-label="Area">{html.escape(issue["area"])}</td>
        <td data-label="Issue">{html.escape(issue["message"])}</td>
      </tr>
"""
        )
    return f"""
    <table class="issue-table">
      <thead><tr><th>Severity</th><th>Area</th><th>Issue</th></tr></thead>
      <tbody>{"".join(rows)}</tbody>
    </table>
"""


def _json_section_html(title: str, payload: dict[str, Any]) -> str:
    return f"""
    <div class="section">
      <h2>{html.escape(title)}</h2>
      <pre>{html.escape(json.dumps(payload, indent=2, sort_keys=True))}</pre>
    </div>
"""


def _release_html(data: dict[str, Any]) -> str:
    return f"""
    {_json_section_html("Interface parity matrix", data["interface_parity"])}
    {_json_section_html("Efficacy scorecard", data["efficacy_summary"])}
    {_json_section_html("Gap audit register", data["gap_register"])}
    {_json_section_html("Release gate status", data["release_views"])}
"""


def _lifecycle_views(store: Any) -> dict[str, Any]:
    memory_rows = [_project_memory_row(row) for row in store.memory_records()]
    continuation_rows = [row for row in memory_rows if row.get("type") == "continuation"]
    skill_rows = [dict(row) for row in store.skills(limit=100)]
    skill_metric_rows = [dict(row) for row in store.skill_metrics(limit=100)]
    improvement_rows = [dict(row) for row in store.skill_improvements(limit=100)]
    closure_rows = [dict(row) for row in store.skill_closure_probes(limit=100)]
    promotion_rows = [dict(row) for row in store.skill_promotions(limit=100)]
    review_rows = [dict(row) for row in store.memory_review_queue(None)]
    learning_rows = [_learning_run_row(row) for row in store.learning_runs(limit=100)]
    selfmod_rows = [row for row in learning_rows if row.get("kind") == "selfmod_variant"]
    return {
        "memory": {
            "total": len(memory_rows),
            "by_type": _count_by(memory_rows, "type"),
            "by_status": _count_by(memory_rows, "status"),
            "by_trust": _count_by(memory_rows, "trust"),
            "needs_attention": [
                row
                for row in memory_rows
                if row.get("status") in {"candidate", "needs_review", "quarantined", "expired"}
            ][:20],
        },
        "continuations": {
            "total": len(continuation_rows),
            "active": sum(1 for row in continuation_rows if row.get("status") == "active"),
            "by_state": _count_by(continuation_rows, "current_state"),
            "recent": continuation_rows[:20],
        },
        "skills": {
            "total": len(skill_rows),
            "by_status": _count_by(skill_rows, "status"),
            "by_trust": _count_by(skill_rows, "trust"),
            "recent": skill_rows[:20],
            "evolution": {
                "metrics": skill_metric_rows[:20],
                "improvements_by_status": _count_by(improvement_rows, "status"),
                "closure_by_status": _count_by(closure_rows, "status"),
                "promotions_by_status": _count_by(promotion_rows, "status"),
                "recent_improvements": improvement_rows[:20],
            },
        },
        "security_reviews": {
            "total": len(review_rows),
            "open": sum(1 for row in review_rows if row.get("status") == "open"),
            "by_status": _count_by(review_rows, "status"),
            "by_severity": _count_by(review_rows, "severity"),
            "recent": review_rows[:20],
        },
        "selfmod": {
            "optimizer_runs": len(learning_rows),
            "selfmod_runs": len(selfmod_rows),
            "by_kind": _count_by(learning_rows, "kind"),
            "by_gate": _count_bool(learning_rows, "gate_pass"),
            "recent": selfmod_rows[:20],
        },
    }


def _flywheel_views(store: Any, *, repo_root: Path | None) -> dict[str, Any]:
    repo_id = stable_id(str(repo_root))[:16] if repo_root else None
    if not repo_id:
        return {
            "repo_id": None,
            "summary": {
                "status": "unavailable",
                "ready": False,
                "component_count": 0,
                "passing_components": 0,
                "reasoning_cycles": 0,
                "active_working_memory_notes": 0,
                "narrative_present": False,
                "world_model_present": False,
            },
            "latest_health": None,
            "latest_narrative": None,
            "latest_world_model": None,
            "latest_world_model_eval": None,
            "experience_strategies": [],
        }

    reasoning_cycles = int(
        store.conn.execute(
            """
            SELECT COUNT(*) AS count
            FROM reasoning_cycles
            WHERE repo_id = ?
            """,
            (repo_id,),
        ).fetchone()["count"]
        or 0
    )
    active_working_memory = int(
        store.conn.execute(
            """
            SELECT COUNT(*) AS count
            FROM working_memory_notes
            WHERE superseded_by IS NULL
              AND (expires_at IS NULL OR expires_at > datetime('now'))
            """
        ).fetchone()["count"]
        or 0
    )
    latest_health = store.flywheel_health(repo_id=repo_id, limit=1)
    latest_narrative = store.latest_agent_narrative(repo_id)
    latest_world_model = store.latest_world_model_version(repo_id)
    latest_world_eval = store.latest_world_model_eval_run(repo_id=repo_id)
    health = _flywheel_health_row(latest_health[0]) if latest_health else None
    components = (health or {}).get("components", {}).get("components", [])
    passing_components = sum(1 for item in components if item.get("status") in {"pass", "disabled"})
    return {
        "repo_id": repo_id,
        "summary": {
            "status": (health or {}).get("status") or "incomplete",
            "ready": bool((health or {}).get("components", {}).get("ready")),
            "component_count": len(components),
            "passing_components": passing_components,
            "reasoning_cycles": reasoning_cycles,
            "active_working_memory_notes": active_working_memory,
            "narrative_present": latest_narrative is not None,
            "world_model_present": latest_world_model is not None,
        },
        "latest_health": health,
        "latest_narrative": _agent_narrative_row(latest_narrative) if latest_narrative else None,
        "latest_world_model": _world_model_row(latest_world_model) if latest_world_model else None,
        "latest_world_model_eval": _world_model_eval_row(latest_world_eval)
        if latest_world_eval
        else None,
        "experience_strategies": [
            _experience_strategy_row(row)
            for row in store.experience_strategies(repo_id=repo_id, limit=10)
        ],
    }


def _flywheel_health_row(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["components"] = _json_dict(item.pop("components_json", "{}"))
    item["warnings"] = _json_list(item.pop("warnings_json", "[]"))
    return item


def _agent_narrative_row(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["posture"] = _json_dict(item.pop("posture_json", "{}"))
    item["evidence_refs"] = _json_list(item.pop("evidence_refs_json", "[]"))
    return item


def _world_model_row(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["enforce_enabled"] = bool(item.get("enforce_enabled"))
    item["metadata"] = _json_dict(item.pop("metadata_json", "{}"))
    return item


def _world_model_eval_row(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["passed"] = bool(item.get("passed"))
    item["report"] = _json_dict(item.pop("report_json", "{}"))
    return item


def _experience_strategy_row(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["evidence"] = _json_list(item.pop("evidence_json", "[]"))
    return item


def _guardrail_views(store: Any) -> dict[str, Any]:
    directives = [dict(row) for row in store.memory_enforcements()]
    events = [
        dict(row)
        for row in store.learning_events(limit=200)
        if row["kind"]
        in {
            "guardrail_decision",
            "guardrail_override",
            "guardrail_degraded",
            "directive_suspended",
        }
    ]
    return {
        "directives_total": len(directives),
        "by_status": _count_by(directives, "status"),
        "by_level": _count_by(directives, "enforcement_level"),
        "by_severity": _count_by(directives, "severity"),
        "events_by_kind": _count_by(events, "kind"),
    }


def _project_memory_row(row: Any) -> dict[str, Any]:
    item = dict(row)
    metadata = _json_dict(item.pop("metadata_json", "{}"))
    provenance = _json_dict(item.pop("provenance_json", "{}"))
    projected = {
        "record_id": item.get("record_id"),
        "type": item.get("type"),
        "title": item.get("title"),
        "assertion": item.get("assertion"),
        "status": item.get("status"),
        "trust": item.get("trust"),
        "confidence": item.get("confidence"),
        "importance": item.get("importance"),
        "source_kind": item.get("source_kind"),
        "last_validated_at": item.get("last_validated_at"),
        "expires_at": item.get("expires_at"),
        "current_state": metadata.get("current_state"),
        "next_action": metadata.get("next_action"),
        "blockers": metadata.get("blockers", []),
        "provenance": provenance,
    }
    return projected


def _learning_run_row(row: Any) -> dict[str, Any]:
    item = dict(row)
    before = _json_dict(item.get("before_json", "{}"))
    after = _json_dict(item.get("after_json", "{}"))
    lifecycle_status = "archived"
    if item.get("kind") == "selfmod_variant":
        if after.get("rejected_at"):
            lifecycle_status = "rejected"
        elif item.get("promoted"):
            lifecycle_status = "approved"
        elif item.get("gate_pass"):
            lifecycle_status = "awaiting_approval"
        else:
            lifecycle_status = "failed_gate"
    return {
        "run_id": item.get("run_id"),
        "target": item.get("target"),
        "kind": item.get("kind"),
        "gate_pass": bool(item.get("gate_pass")),
        "archived": bool(item.get("archived")),
        "promoted": bool(item.get("promoted")),
        "created_at": item.get("created_at"),
        "lifecycle_status": lifecycle_status,
        "ancestor_run_id": before.get("ancestor_run_id"),
        "rationale": after.get("rationale"),
        "touched_path": after.get("touched_path"),
        "diff": after.get("diff"),
        "validation": after.get("validation"),
        "adopted_by": after.get("adopted_by"),
        "adopted_at": after.get("adopted_at"),
        "rejected_by": after.get("rejected_by"),
        "rejected_at": after.get("rejected_at"),
        "rejection_reason": after.get("rejection_reason"),
    }


def _task_learning_row(row: Any) -> dict[str, Any]:
    item = dict(row)
    for source, target in [
        ("session_ids_json", "session_ids"),
        ("counts_json", "counts"),
        ("record_refs_json", "record_refs"),
    ]:
        fallback = "[]" if source == "session_ids_json" else "{}"
        try:
            item[target] = json.loads(item.pop(source) or fallback)
        except json.JSONDecodeError:
            item[target] = [] if source == "session_ids_json" else {}
    return item


def _interface_parity_matrix() -> dict[str, Any]:
    route_set = set(ROUTES)
    required = [
        {
            "surface": "phase0_eval",
            "http": [
                "/v1/eval/run",
                "/v1/eval/scorecard",
                "/v1/eval/scorecard/public",
                "/v1/eval/loop-verify",
            ],
            "dashboard_tab": "Release Gates",
        },
        {
            "surface": "memory",
            "http": [
                "/v1/memory",
                "/v1/memory/{id}",
                "/v1/memory/{id}/approve",
                "/v1/memory/{id}/quarantine",
                "/v1/memory/{id}/expire",
                "/v1/memory/{id}/diff",
                "/v1/memory/{id}/promote",
                "/v1/memory/recall",
                "/v1/memory/maintain",
                "/v1/memory/enforcements",
                "/v1/memory/review",
                "/v1/memory/utilization/{pack_id}",
                "/v1/guardrail/override",
            ],
            "dashboard_tab": "Memory OS",
        },
        {
            "surface": "continuations",
            "http": [
                "/v1/continuations",
                "/v1/continuations/{id}",
                "/v1/continuations/resume",
                "/v1/continuations/{id}/abandon",
            ],
            "dashboard_tab": "Continuations",
        },
        {
            "surface": "skills",
            "http": [
                "/v1/skills",
                "/v1/skills/{id}",
                "/v1/skills/{id}/replay",
                "/v1/skills/{id}/approve",
                "/v1/skills/{id}/reject",
            ],
            "dashboard_tab": "Skills",
        },
        {
            "surface": "learning",
            "http": [
                "/v1/learning/runs",
                "/v1/learning/runs/{id}",
                "/v1/learning/runs/{id}/adopt",
                "/v1/learning/runs/{id}/promote",
                "/v1/learning/runs/{id}/revert",
                "/v1/learning/rollback",
            ],
            "dashboard_tab": "Self-Mod Archive",
        },
        {
            "surface": "selfmod",
            "http": [
                "/v1/selfmod/runs",
                "/v1/selfmod/runs/propose",
                "/v1/selfmod/runs/{id}",
                "/v1/selfmod/runs/{id}/adopt",
                "/v1/selfmod/runs/{id}/approve",
                "/v1/selfmod/runs/{id}/reject",
                "/v1/selfmod/runs/{id}/revert",
                "/v1/selfmod/runs/{id}/rollback",
            ],
            "dashboard_tab": "Self-Mod Archive",
        },
        {
            "surface": "security",
            "http": ["/v1/security/reviews"],
            "dashboard_tab": "Security Reviews",
        },
        {
            "surface": "codex",
            "http": [
                "/v1/codex/preflight",
                "/v1/codex/enforcement-status",
                "/v1/codex/parallel-plan",
                "/v1/codex/subagents/start",
                "/v1/codex/subagents/stop",
                "/v1/codex/subagents/pack",
                "/v1/codex/parallel-results/merge",
            ],
            "dashboard_tab": "Codex Parallel",
        },
    ]
    rows = []
    missing: list[str] = []
    for item in required:
        route_missing = [route for route in item["http"] if route not in route_set]
        missing.extend(f"{item['surface']}:{route}" for route in route_missing)
        rows.append({**item, "http_ok": not route_missing, "missing_http": route_missing})
    return {
        "ok": not missing,
        "covered_surfaces": len(rows),
        "missing": missing,
        "rows": rows,
    }


def _release_views(
    *,
    gap_register: dict[str, Any],
    benchmark_trends: list[dict[str, Any]],
    efficacy_scorecard: dict[str, Any] | None,
) -> dict[str, Any]:
    unresolved = gap_register.get("unresolved") or []
    violations = gap_register.get("violations") or []
    phase0_gate_met = bool(
        efficacy_scorecard
        and efficacy_scorecard.get("gate_status") == "pass"
        and efficacy_scorecard.get("deterministic") is True
    )
    return {
        "gap_register_ok": bool(gap_register.get("ok")),
        "unresolved_gap_count": len(unresolved),
        "unresolved_gap_ids": [item.get("id") for item in unresolved],
        "violation_names": [item.get("name") for item in violations],
        "benchmark_trend_runs": len(benchmark_trends),
        "benchmark_trend_gate_ok": len(benchmark_trends) >= 3,
        "g6_phase0_efficacy_gate_met": phase0_gate_met,
        "latest_efficacy_gate_status": (
            efficacy_scorecard.get("gate_status") if efficacy_scorecard else None
        ),
    }


def _codex_parallel_summary(store: Any) -> dict[str, Any]:
    runs: dict[str, dict[str, Any]] = {}
    for session in store.agent_sessions(limit=200):
        for event in store.agent_session_events(session["session_id"]):
            if event["event_type"] not in {"codex_child_start", "codex_child_stop"}:
                continue
            payload = _json_dict(event["payload_json"])
            run_id = payload.get("parallel_run_id")
            child_id = payload.get("child_agent_session_id")
            if not run_id or not child_id:
                continue
            run = runs.setdefault(
                str(run_id),
                {
                    "parallel_run_id": str(run_id),
                    "parent_task_session_id": payload.get("parent_task_session_id"),
                    "children": {},
                },
            )
            child = run["children"].setdefault(
                str(child_id),
                {
                    "child_agent_session_id": str(child_id),
                    "role": payload.get("child_role"),
                    "write_scope": payload.get("write_scope", []),
                    "read_scope": payload.get("read_scope", []),
                    "status": "active",
                    "summary": None,
                    "blockers": [],
                    "changed_files": [],
                    "tests_run": [],
                },
            )
            if event["event_type"] == "codex_child_stop":
                child.update(
                    {
                        "status": payload.get("status", "completed"),
                        "summary": payload.get("summary"),
                        "blockers": payload.get("blockers", []),
                        "changed_files": payload.get("changed_files", []),
                        "tests_run": payload.get("tests_run", []),
                    }
                )
    projected = []
    for run in runs.values():
        children = list(run["children"].values())
        projected.append(
            {
                "parallel_run_id": run["parallel_run_id"],
                "parent_task_session_id": run["parent_task_session_id"],
                "child_count": len(children),
                "completed_child_count": sum(
                    1
                    for child in children
                    if child.get("status") in {"completed", "pass", "success"}
                ),
                "blocked_child_count": sum(1 for child in children if child.get("blockers")),
                "children": children,
            }
        )
    return {
        "runs": len(projected),
        "children": sum(run["child_count"] for run in projected),
        "completed_children": sum(run["completed_child_count"] for run in projected),
        "blocked_children": sum(run["blocked_child_count"] for run in projected),
        "recent": projected[:20],
    }


def _count_by(rows: list[dict[str, Any]], key: str) -> dict[str, int]:
    counts: dict[str, int] = {}
    for row in rows:
        value = str(row.get(key) or "unknown")
        counts[value] = counts.get(value, 0) + 1
    return dict(sorted(counts.items()))


def _count_bool(rows: list[dict[str, Any]], key: str) -> dict[str, int]:
    return {
        "true": sum(1 for row in rows if bool(row.get(key))),
        "false": sum(1 for row in rows if not bool(row.get(key))),
    }


def _status_badge(status: str) -> str:
    label = {
        "ok": "Active",
        "warning": "Attention",
        "issue": "Issue",
        "missing": "Missing",
        "idle": "Idle",
    }.get(status, status)
    return f'<span class="status {html.escape(status)}"><span class="dot"></span>{html.escape(label)}</span>'


def _public_payload(data: dict[str, Any]) -> dict[str, Any]:
    return {
        "overview": data["overview"],
        "functionality": data["functionality"],
        "projects": data["projects"],
        "issues": data["issues"],
        "benchmark_trend_summary": data["benchmark_trend_summary"],
        "efficacy_summary": data["efficacy_summary"],
        "lifecycle_views": data["lifecycle_views"],
        "interface_parity": data["interface_parity"],
        "release_views": data["release_views"],
        "codex_parallel": data["codex_parallel"],
        "teacher": data["teacher"],
        "flywheel": data["flywheel"],
        "storage_report": data["storage_report"],
        "gap_register": data["gap_register"],
        "audit": data["audit"],
        "graph": data["graph"],
    }


def _teacher_views(store: Any) -> dict[str, Any]:
    def rows(sql: str) -> list[dict[str, Any]]:
        return [dict(row) for row in store.conn.execute(sql).fetchall()]

    return {
        "schema_version": "persistmind.teacher_dashboard.v1",
        "runtime_runs": rows("SELECT * FROM codex_runtime_runs ORDER BY updated_at DESC LIMIT 20"),
        "pending_reviews": rows(
            "SELECT * FROM professional_teacher_reviews WHERE status='pending' ORDER BY created_at LIMIT 50"
        ),
        "lessons": rows("SELECT * FROM lessons ORDER BY updated_at DESC LIMIT 50"),
        "graph_versions": rows("SELECT * FROM graph_versions ORDER BY created_at DESC LIMIT 20"),
        "orchestration_runs": rows(
            "SELECT * FROM orchestration_runs ORDER BY updated_at DESC LIMIT 20"
        ),
        "benchmark_runs": rows(
            "SELECT * FROM teacher_benchmark_runs ORDER BY started_at DESC LIMIT 20"
        ),
        "claims": rows("SELECT * FROM teacher_claim_evidence ORDER BY created_at DESC LIMIT 20"),
    }


def _overview(
    *,
    candidates: list[dict[str, Any]],
    active: list[dict[str, Any]],
    stale: list[dict[str, Any]],
    ci: list[dict[str, Any]],
    graph: dict[str, Any],
    learning_events: list[dict[str, Any]],
    optimization_runs: list[dict[str, Any]],
    skills: list[dict[str, Any]],
    efficacy_scorecard: dict[str, Any] | None,
    audit: dict[str, Any],
    projects: list[dict[str, Any]],
    issues: list[dict[str, Any]],
    lifecycle: dict[str, Any],
    release_views: dict[str, Any],
    interface_parity: dict[str, Any],
    codex_parallel: dict[str, Any],
    concurrency: dict[str, Any],
    h4_security: dict[str, Any],
    decisions: list[dict[str, Any]],
) -> dict[str, Any]:
    functions = _functionality_status(
        candidates=candidates,
        active=active,
        stale=stale,
        ci=ci,
        graph=graph,
        learning_events=learning_events,
        optimization_runs=optimization_runs,
        skills=skills,
        benchmark_trends=[],
        efficacy_scorecard=efficacy_scorecard,
        audit=audit,
        projects=projects,
        lifecycle=lifecycle,
        release_views=release_views,
        interface_parity=interface_parity,
        codex_parallel=codex_parallel,
        concurrency=concurrency,
        h4_security=h4_security,
        decisions=decisions,
    )
    active_functions = sum(1 for item in functions if item["status"] == "ok")
    attention = sum(
        1 for project in projects if project["status"] in {"warning", "issue", "missing"}
    )
    health = "ok"
    if any(issue["severity"] == "issue" for issue in issues):
        health = "issue"
    elif issues:
        health = "warning"
    return {
        "health": health,
        "projects_total": len(projects),
        "projects_attention": attention,
        "functions_total": len(functions),
        "functions_active": active_functions,
        "issues_total": len(issues),
        "audit_ok": bool(audit.get("ok")),
        "graph_files": int(graph.get("files", 0) or 0),
        "active_rules": len(active),
        "pending_rules": len(candidates),
        "learning_runs": len(optimization_runs),
        "learning_promoted": sum(1 for run in optimization_runs if run.get("promoted")),
        "ci_reports": len(ci),
        "efficacy_runs": 1 if efficacy_scorecard else 0,
        "efficacy_gate": (
            efficacy_scorecard.get("gate_status", "none") if efficacy_scorecard else "none"
        ),
        "active_leases": int(concurrency.get("active_leases", 0) or 0),
        "open_conflicts": int(concurrency.get("open_conflicts", 0) or 0),
        "loop_closure_closed": h4_security.get("loop_closure", {}).get("closed", False),
        "redteam_ok": h4_security.get("redteam", {}).get("ok", False),
        "decisions_total": len(decisions),
        "decisions_decided": sum(1 for item in decisions if item.get("status") == "decided"),
    }


def _functionality_status(
    *,
    candidates: list[dict[str, Any]],
    active: list[dict[str, Any]],
    stale: list[dict[str, Any]],
    ci: list[dict[str, Any]],
    graph: dict[str, Any],
    learning_events: list[dict[str, Any]],
    optimization_runs: list[dict[str, Any]],
    skills: list[dict[str, Any]],
    benchmark_trends: list[dict[str, Any]],
    efficacy_scorecard: dict[str, Any] | None,
    audit: dict[str, Any],
    projects: list[dict[str, Any]],
    lifecycle: dict[str, Any],
    release_views: dict[str, Any],
    interface_parity: dict[str, Any],
    codex_parallel: dict[str, Any],
    concurrency: dict[str, Any],
    h4_security: dict[str, Any],
    decisions: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    graph_files = int(graph.get("files", 0) or 0)
    graph_symbols = int(graph.get("symbols", 0) or 0)
    logical_edges = sum(int(value or 0) for value in (graph.get("logical_edges") or {}).values())
    business_graph = graph.get("business_graph") or {}
    org_ingestion = graph.get("org_ingestion") or {}
    active_business = sum(
        int(value or 0) for value in (business_graph.get("active_nodes_by_type") or {}).values()
    )
    pending_business = int((business_graph.get("nodes_by_status") or {}).get("candidate", 0) or 0)
    promoted = sum(1 for run in optimization_runs if run.get("promoted"))
    efficacy_status = str((efficacy_scorecard or {}).get("gate_status") or "idle")
    decision_summary = _decision_summary(decisions)
    return [
        {
            "name": "Repository graph",
            "status": "ok" if graph_files else "idle",
            "summary": "Indexed files, symbols, imports, calls, test links, and semantic graph shape.",
            "metrics": [
                f"{graph_files} files",
                f"{graph_symbols} symbols",
                f"{logical_edges} edges",
            ],
        },
        {
            "name": "Context and diff safety",
            "status": "ok" if audit.get("ok") else "issue",
            "summary": "Context packs, audit chain, impact reports, and check-diff preflight.",
            "metrics": ["audit ok" if audit.get("ok") else "audit issue"],
        },
        {
            "name": "Multi-agent concurrency",
            "status": ("issue" if int(concurrency.get("open_conflicts", 0) or 0) else "ok"),
            "summary": "Snapshot-bound session leases, declared impacts, conflict surfacing, and audit chain serialization.",
            "metrics": [
                f"{int(concurrency.get('active_leases', 0) or 0)} active leases",
                f"{int(concurrency.get('open_conflicts', 0) or 0)} open conflicts",
                f"{int((concurrency.get('audit') or {}).get('height', 0) or 0)} audit rows",
            ],
        },
        {
            "name": "Loop and ingestion security",
            "status": (
                "ok"
                if h4_security.get("loop_closure", {}).get("closed")
                and h4_security.get("redteam", {}).get("ok")
                else "idle"
            ),
            "summary": "Feedback-loop closure, bounded rerank safety, external ingest defense, and red-team gate status.",
            "metrics": [
                f"loop closed: {bool(h4_security.get('loop_closure', {}).get('closed'))}",
                f"redteam ok: {bool(h4_security.get('redteam', {}).get('ok'))}",
                f"served authoritative attacks: {int(h4_security.get('redteam', {}).get('served_authoritative_count', 0) or 0)}",
            ],
        },
        {
            "name": "Business graph",
            "status": ("ok" if active_business else ("warning" if pending_business else "idle")),
            "summary": "Approval-gated business entities, technical-business links, and impact exposure coverage.",
            "metrics": [
                f"{active_business} active business nodes",
                f"{pending_business} pending candidates",
                f"{int(business_graph.get('active_business_edges', 0) or 0)} active links",
            ],
        },
        {
            "name": "Org ingestion",
            "status": (
                "warning"
                if int((org_ingestion.get("candidates_by_status") or {}).get("quarantined", 0) or 0)
                else ("ok" if int(org_ingestion.get("items_seen", 0) or 0) else "idle")
            ),
            "summary": "Read-only organizational connectors, redaction, defense, quarantine, and review telemetry.",
            "metrics": [
                f"{int(org_ingestion.get('items_seen', 0) or 0)} seen",
                f"{int(org_ingestion.get('items_quarantined', 0) or 0)} quarantined",
                f"{int(org_ingestion.get('redactions', 0) or 0)} redactions",
            ],
        },
        {
            "name": "Decision briefings",
            "status": (
                "ok"
                if int(decision_summary.get("decided", 0) or 0)
                else ("warning" if int(decision_summary.get("analyzed", 0) or 0) else "idle")
            ),
            "summary": "Audit-chained advisory briefings, explicit unknowns, recommendations, and human decision capture.",
            "metrics": [
                f"{int(decision_summary.get('total', 0) or 0)} total",
                f"{int(decision_summary.get('analyzed', 0) or 0)} analyzed",
                f"{int(decision_summary.get('decided', 0) or 0)} decided",
            ],
        },
        {
            "name": "Project memory",
            "status": ("warning" if candidates or stale else ("ok" if active else "idle")),
            "summary": "Approved rules, candidate rules, stale-rule signals, and memory lifecycle.",
            "metrics": [
                f"{len(active)} active",
                f"{len(candidates)} pending",
                f"{len(stale)} stale",
            ],
        },
        {
            "name": "Learning gates",
            "status": "ok" if optimization_runs or learning_events else "idle",
            "summary": "Optimizer variants, self-modification gates, judge checks, and promotion state.",
            "metrics": [f"{len(optimization_runs)} runs", f"{promoted} promoted"],
        },
        {
            "name": "Verification",
            "status": "ok",
            "summary": "Repair-pack verification, reproduction-first checks, mutation and differential helpers.",
            "metrics": ["runner available", "repair packs"],
        },
        {
            "name": "Workspace projects",
            "status": (
                "warning"
                if any(p["status"] != "ok" for p in projects)
                else ("ok" if projects else "idle")
            ),
            "summary": "Registered project installs, per-project rollups, and cross-repo contract readiness.",
            "metrics": [f"{len(projects)} projects"],
        },
        {
            "name": "Skills",
            "status": "ok" if skills else "idle",
            "summary": "Approved and candidate reusable project skills.",
            "metrics": [f"{len(skills)} recent"],
        },
        {
            "name": "CI and runtime signals",
            "status": "warning" if _ci_has_issue(ci) else ("ok" if ci else "idle"),
            "summary": "Stored CI reports, runtime evidence, incidents, and rule-aware policy output.",
            "metrics": [f"{len(ci)} reports"],
        },
        {
            "name": "Benchmark honesty",
            "status": "ok" if benchmark_trends or efficacy_scorecard else "idle",
            "summary": "Agent benchmark lift, efficacy scorecard, pack determinism, and gate trend.",
            "metrics": [
                f"{len(benchmark_trends)} benchmark runs",
                f"efficacy {efficacy_status}",
            ],
        },
        {
            "name": "Lifecycle dashboard",
            "status": "ok" if interface_parity["ok"] else "warning",
            "summary": "Dedicated Memory OS, continuation, skill, security, self-mod, Codex, and release views.",
            "metrics": [
                f"{interface_parity['covered_surfaces']} surfaces",
                f"{release_views['unresolved_gap_count']} gaps",
            ],
        },
        {
            "name": "Codex parallel agents",
            "status": "ok" if codex_parallel["runs"] else "idle",
            "summary": "Parent-child Codex run visibility, child status, scopes, summaries, and merge readiness.",
            "metrics": [
                f"{codex_parallel['runs']} runs",
                f"{codex_parallel['children']} children",
                f"{codex_parallel['completed_children']} completed",
            ],
        },
        {
            "name": "Security reviews",
            "status": "warning" if lifecycle["security_reviews"]["open"] else "ok",
            "summary": "Memory quarantine and review queue visibility.",
            "metrics": [
                f"{lifecycle['security_reviews']['open']} open",
                f"{lifecycle['security_reviews']['total']} total",
            ],
        },
    ]


def _issues(
    *,
    candidates: list[dict[str, Any]],
    stale: list[dict[str, Any]],
    ci: list[dict[str, Any]],
    audit: dict[str, Any],
    projects: list[dict[str, Any]],
    functionality: list[dict[str, Any]],
    gap_register: dict[str, Any],
) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    if not audit.get("ok"):
        issues.append(
            {
                "severity": "issue",
                "area": "Audit",
                "message": "Audit chain verification is not passing.",
            }
        )
    if candidates:
        issues.append(
            {
                "severity": "warning",
                "area": "Memory",
                "message": f"{len(candidates)} rule candidate(s) await approval.",
            }
        )
    if stale:
        issues.append(
            {
                "severity": "warning",
                "area": "Memory",
                "message": f"{len(stale)} active rule(s) have stale or missing evidence.",
            }
        )
    if _ci_has_issue(ci):
        issues.append(
            {
                "severity": "warning",
                "area": "CI",
                "message": "At least one recent CI report is not passing.",
            }
        )
    for project in projects:
        for message in project.get("issues", []):
            severity = "issue" if project["status"] in {"issue", "missing"} else "warning"
            issues.append(
                {
                    "severity": severity,
                    "area": f"Project: {project['name']}",
                    "message": message,
                }
            )
    for item in functionality:
        if item["status"] == "issue":
            issues.append({"severity": "issue", "area": item["name"], "message": item["summary"]})
    unresolved = gap_register.get("unresolved") or []
    if unresolved:
        issues.append(
            {
                "severity": "warning",
                "area": "Release gaps",
                "message": f"{len(unresolved)} required plan workstream(s) remain unresolved.",
            }
        )
    return issues


def _ci_has_issue(rows: list[dict[str, Any]]) -> bool:
    for row in rows:
        status = str(row.get("status") or "").lower()
        if status and status not in {"pass", "passed", "ok", "success"}:
            return True
    return False


def _project_from_row(row: dict[str, Any]) -> dict[str, Any]:
    root = Path(str(row.get("root_path") or ""))
    issues: list[str] = []
    flags: list[str] = []
    progress = 0
    activity = "No PersistMind data"
    metrics = {"authority_count": 0, "database_bytes": 0}
    if not root.exists():
        issues.append("Project path is missing.")
        status = "missing"
    else:
        progress += 20
        from persistmind.branding import resolve_project_state

        state_dir = resolve_project_state(root)
        catalog = state_dir / "catalog" / "current.json"
        if not state_dir.is_dir():
            issues.append(".persistmind directory is missing.")
            status = "missing"
        elif not catalog.is_file():
            issues.append("PersistMind authority catalog is missing.")
            status = "issue"
            progress += 20
            flags.append("installed")
        else:
            progress += 40
            flags.append("installed")
            authority_files = list((state_dir / "stores").rglob("*.db"))
            metrics = {
                "authority_count": len(authority_files),
                "database_bytes": sum(
                    path.stat().st_size for path in authority_files if path.is_file()
                ),
            }
            progress += 20 if len(authority_files) >= 8 else 0
            activity = f"{len(authority_files)} authority databases active"
            if len(authority_files) < 8:
                issues.append("The active authority set is incomplete.")
            status = "warning" if issues else "ok"
    progress = min(100, progress)
    return {
        "workspace_repo_id": row.get("workspace_repo_id"),
        "project_id": row.get("repo_id") or stable_id(str(root.resolve()))[:16],
        "name": str(row.get("name") or root.name or "project"),
        "root_path": str(root),
        "status": status,
        "progress": progress,
        "activity": activity,
        "issues": issues,
        "flags": sorted(set(flags)),
        "metrics": metrics,
    }


def _project_db_metrics(db_path: Path) -> dict[str, Any]:
    metrics: dict[str, Any] = {"issues": [], "flags": [], "progress_bonus": 0}
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro&immutable=1", uri=True)
        conn.row_factory = sqlite3.Row
    except sqlite3.Error as exc:
        metrics["issues"].append(f"Cannot open workspace database: {exc}")
        return metrics
    try:
        outcomes = _single_row(
            conn,
            "SELECT COUNT(*) AS total, SUM(result LIKE 'pass%') AS passed FROM outcomes",
        )
        packs = _single_row(
            conn,
            "SELECT COUNT(*) AS total, MAX(created_at) AS latest FROM context_packs",
        )
        sessions = _single_row(conn, "SELECT COUNT(*) AS total FROM agent_sessions")
        learning = _single_row(
            conn,
            "SELECT COUNT(*) AS total, SUM(gate_pass) AS gate_pass FROM learning_run",
        )
        memory = _rows(conn, "SELECT status, COUNT(*) AS count FROM memory_records GROUP BY status")
    except sqlite3.Error as exc:
        metrics["issues"].append(f"Database schema is not readable: {exc}")
        conn.close()
        return metrics
    conn.close()

    outcome_total = int(outcomes.get("total") or 0)
    passed = int(outcomes.get("passed") or 0)
    success_rate = round(passed / outcome_total, 4) if outcome_total else None
    pack_total = int(packs.get("total") or 0)
    learning_total = int(learning.get("total") or 0)
    gate_pass = int(learning.get("gate_pass") or 0)
    memory_total = sum(int(row["count"] or 0) for row in memory)

    if pack_total:
        metrics["progress_bonus"] += 15
        metrics["flags"].append(f"{pack_total} packs")
    if outcome_total:
        metrics["progress_bonus"] += 15
        metrics["flags"].append(f"{outcome_total} outcomes")
    if learning_total:
        metrics["progress_bonus"] += 5
        metrics["flags"].append(f"{learning_total} learning runs")
    if memory_total:
        metrics["progress_bonus"] += 5
        metrics["flags"].append(f"{memory_total} memories")
    if success_rate is not None and success_rate < 1.0:
        metrics["issues"].append(f"Outcome success rate is {success_rate:.0%}.")
    if learning_total and gate_pass < learning_total:
        metrics["issues"].append("Some learning runs failed their gate.")
    metrics["packs"] = pack_total
    metrics["outcomes"] = outcome_total
    metrics["success_rate"] = success_rate
    metrics["sessions"] = int(sessions.get("total") or 0)
    metrics["learning_runs"] = learning_total
    metrics["memory_records"] = memory_total
    metrics["latest_pack"] = packs.get("latest")
    return metrics


def _single_row(conn: sqlite3.Connection, sql: str) -> dict[str, Any]:
    row = conn.execute(sql).fetchone()
    return dict(row) if row else {}


def _rows(conn: sqlite3.Connection, sql: str) -> list[sqlite3.Row]:
    return list(conn.execute(sql).fetchall())


def _project_activity(metrics: dict[str, Any]) -> str:
    parts = [
        f"{metrics.get('packs', 0)} packs",
        f"{metrics.get('outcomes', 0)} outcomes",
        f"{metrics.get('learning_runs', 0)} learning",
        f"{metrics.get('memory_records', 0)} memories",
    ]
    if metrics.get("success_rate") is not None:
        parts.append(f"{float(metrics['success_rate']):.0%} success")
    return ", ".join(parts)


def _benchmark_row(row: Any) -> dict[str, Any]:
    lift_attribution = _json_dict(row["lift_attribution_json"])
    roadmap_pruning = _json_dict(row["roadmap_pruning_json"])
    return {
        "benchmark_run_id": row["benchmark_run_id"],
        "repo_id": row["repo_id"],
        "cases": int(row["cases"] or 0),
        "success_rate_delta": float(row["success_rate_delta"] or 0.0),
        "tests_pass_rate_delta": float(row["tests_pass_rate_delta"] or 0.0),
        "wrong_files_touched_reduction": float(row["wrong_files_touched_reduction"] or 0.0),
        "missing_files_reduction": float(row["missing_files_reduction"] or 0.0),
        "memory_score": float(row["memory_score"] or 0.0),
        "context_retrieval_score": float(row["context_retrieval_score"] or 0.0),
        "gate_ok": None if row["gate_ok"] is None else bool(row["gate_ok"]),
        "gate_status": row["gate_status"],
        "lift_attribution": lift_attribution,
        "roadmap_pruning": roadmap_pruning,
        "created_at": row["created_at"],
    }


def _benchmark_summary(rows: list[dict[str, Any]]) -> dict[str, Any]:
    if not rows:
        return {"count": 0}
    latest = rows[0]
    oldest = rows[-1]
    return {
        "count": len(rows),
        "latest_success_rate_delta": latest["success_rate_delta"],
        "success_rate_delta_change": round(
            latest["success_rate_delta"] - oldest["success_rate_delta"], 6
        ),
        "latest_context_retrieval_score": latest["context_retrieval_score"],
        "latest_memory_score": latest["memory_score"],
        "latest_cut_or_defer_candidates": latest["roadmap_pruning"].get(
            "cut_or_defer_candidates", []
        ),
    }


def _benchmark_trend_html(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return "<p>No benchmark runs recorded.</p>"
    metrics = [
        ("success_rate_delta", "success-rate-delta", "#28638a"),
        ("context_retrieval_score", "context-retrieval-score", "#1f7a4d"),
        ("memory_score", "memory-score", "#ad2e2e"),
    ]
    oldest_first = list(reversed(rows))
    values = [float(row[key]) for row in oldest_first for key, _label, _color in metrics]
    min_value = min(values)
    max_value = max(values)
    if min_value == max_value:
        min_value -= 1.0
        max_value += 1.0
    width = 760
    height = 210
    pad = 28

    def point(index: int, value: float) -> tuple[float, float]:
        divisor = max(1, len(oldest_first) - 1)
        x = pad + ((width - (pad * 2)) * index / divisor)
        y = pad + ((height - (pad * 2)) * (max_value - value) / (max_value - min_value))
        return (round(x, 2), round(y, 2))

    polylines = []
    for key, label, color in metrics:
        points = " ".join(
            f"{x},{y}"
            for index, row in enumerate(oldest_first)
            for x, y in [point(index, float(row[key]))]
        )
        circles = ""
        if len(oldest_first) == 1:
            x, y = point(0, float(oldest_first[0][key]))
            circles = f'<circle cx="{x}" cy="{y}" r="4" fill="{color}"></circle>'
        polylines.append(
            f'<polyline data-metric="{label}" points="{points}" fill="none" stroke="{color}" stroke-width="3"></polyline>{circles}'
        )
    legend = " ".join(
        f'<span class="pill"><span style="color:{color}">*</span> {html.escape(label)}</span>'
        for _key, label, color in metrics
    )
    table_rows = []
    for row in rows[:10]:
        table_rows.append(
            "<tr>"
            f'<td data-label="Created">{html.escape(str(row["created_at"]))}</td>'
            f'<td data-label="Cases">{int(row["cases"])}</td>'
            f'<td data-label="Success delta">{row["success_rate_delta"]:.3f}</td>'
            f'<td data-label="Context">{row["context_retrieval_score"]:.3f}</td>'
            f'<td data-label="Memory">{row["memory_score"]:.3f}</td>'
            f'<td data-label="Gate">{html.escape(str(row["gate_status"] or row["gate_ok"]))}</td>'
            "</tr>"
        )
    return f"""
  <svg width="{width}" height="{height}" viewBox="0 0 {width} {height}" role="img" aria-label="Benchmark lift trend">
    <line x1="{pad}" y1="{height - pad}" x2="{width - pad}" y2="{height - pad}" stroke="#28231d"></line>
    <line x1="{pad}" y1="{pad}" x2="{pad}" y2="{height - pad}" stroke="#28231d"></line>
    {"".join(polylines)}
  </svg>
  <p>{legend}</p>
  <table>
    <thead>
      <tr><th>Created</th><th>Cases</th><th>Success delta</th><th>Context</th><th>Memory</th><th>Gate</th></tr>
    </thead>
    <tbody>{"".join(table_rows)}</tbody>
  </table>
"""


def _efficacy_scorecard_row(row: Any) -> dict[str, Any]:
    report = _json_dict(row["report_json"])
    delta = _dict(report.get("delta"))
    pack_quality = _dict(report.get("pack_quality"))
    impact = _dict(pack_quality.get("impact_prediction"))
    determinism = _dict(pack_quality.get("determinism"))
    latency = _dict(pack_quality.get("latency"))
    loop = _dict(report.get("loop_closure"))
    gate = _dict(report.get("gate"))
    reproduction = _dict(report.get("reproduction"))
    benchmark = _dict(report.get("benchmark"))
    return {
        "scorecard_id": row["scorecard_id"],
        "eval_run_id": row["eval_run_id"],
        "schema_version": row["schema_version"],
        "gate_status": row["gate_status"] or gate.get("status"),
        "audit_hash": row["audit_hash"],
        "created_at": row["created_at"],
        "cases": int(benchmark.get("cases") or 0),
        "context_recall": _float(pack_quality.get("context_recall")),
        "impact_prediction_f1": _float(impact.get("f1")),
        "test_selection_precision": _float(pack_quality.get("test_selection_precision")),
        "out_of_scope_edit_rate_delta": _float(delta.get("out_of_scope_edit_rate_delta")),
        "hallucination_incident_delta": _float(delta.get("hallucination_incident_delta")),
        "deterministic": bool(determinism.get("verified")),
        "loop_verified": bool(loop.get("verified")),
        "latency_p95_ms": _float(latency.get("p95_ms")),
        "baseline": reproduction.get("baseline"),
        "candidate": reproduction.get("candidate"),
    }


def _efficacy_summary(rows: list[dict[str, Any]]) -> dict[str, Any]:
    if not rows:
        return {
            "count": 0,
            "latest_gate_status": None,
            "g6_phase0_efficacy_gate_met": False,
        }
    latest = rows[0]
    return {
        "count": len(rows),
        "latest_gate_status": latest.get("gate_status"),
        "g6_phase0_efficacy_gate_met": latest.get("gate_status") == "pass"
        and latest.get("deterministic") is True,
        "latest_context_recall": latest.get("context_recall", 0.0),
        "latest_impact_prediction_f1": latest.get("impact_prediction_f1", 0.0),
        "latest_out_of_scope_edit_rate_delta": latest.get("out_of_scope_edit_rate_delta", 0.0),
        "latest_hallucination_incident_delta": latest.get("hallucination_incident_delta", 0.0),
        "latest_loop_verified": bool(latest.get("loop_verified")),
        "latest_latency_p95_ms": latest.get("latency_p95_ms", 0.0),
    }


def _efficacy_trend_html(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return "<p>No efficacy scorecards recorded.</p>"
    table_rows = []
    for row in rows[:10]:
        table_rows.append(
            "<tr>"
            f'<td data-label="Created">{html.escape(str(row["created_at"]))}</td>'
            f'<td data-label="Gate">{html.escape(str(row.get("gate_status")))}</td>'
            f'<td data-label="Cases">{int(row.get("cases") or 0)}</td>'
            f'<td data-label="Scope delta">{float(row.get("out_of_scope_edit_rate_delta") or 0.0):.3f}</td>'
            f'<td data-label="Recall">{float(row.get("context_recall") or 0.0):.3f}</td>'
            f'<td data-label="Deterministic">{html.escape(str(bool(row.get("deterministic"))))}</td>'
            f'<td data-label="Loop">{html.escape(str(bool(row.get("loop_verified"))))}</td>'
            "</tr>"
        )
    return f"""
  <table>
    <thead>
      <tr><th>Created</th><th>Gate</th><th>Cases</th><th>Scope delta</th><th>Recall</th><th>Deterministic</th><th>Loop</th></tr>
    </thead>
    <tbody>{"".join(table_rows)}</tbody>
  </table>
"""


def _intent_views(store: Any) -> list[dict[str, Any]]:
    rows = store.list_intents(limit=20)
    views: list[dict[str, Any]] = []
    for row in rows:
        goals = [dict(goal) for goal in store.intent_candidate_goals(row["intent_id"])]
        questions = [dict(question) for question in store.intent_open_questions(row["intent_id"])]
        nodes = [dict(node) for node in store.intent_nodes(row["intent_id"])]
        views.append(
            {
                "intent_id": row["intent_id"],
                "snapshot_id": row["snapshot_id"],
                "status": row["status"],
                "problem_statement": row["problem_statement"],
                "selected_goal_id": row["selected_goal_id"],
                "skeleton_hash": row["skeleton_hash"],
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
                "candidate_goals": len(goals),
                "open_questions": len(questions),
                "node_count": len(nodes),
                "unverified_nodes": sum(1 for node in nodes if node.get("status") == "unverified"),
                "llm_proposed_nodes": sum(
                    1 for node in nodes if node.get("origin") == "llm_proposed"
                ),
            }
        )
    return views


def _intent_summary(rows: list[dict[str, Any]]) -> dict[str, Any]:
    total = len(rows)
    selected = sum(1 for row in rows if row.get("selected_goal_id"))
    questions = sum(int(row.get("open_questions") or 0) for row in rows)
    unverified = sum(int(row.get("unverified_nodes") or 0) for row in rows)
    nodes = sum(int(row.get("node_count") or 0) for row in rows)
    return {
        "count": total,
        "selected_goals": selected,
        "open_questions": questions,
        "open_question_rate": round(questions / total, 6) if total else 0.0,
        "unverified_node_rate": round(unverified / nodes, 6) if nodes else 0.0,
    }


def _goal_views(store: Any) -> list[dict[str, Any]]:
    rows = store.list_goals(limit=20)
    views: list[dict[str, Any]] = []
    for row in rows:
        alternatives = [dict(alt) for alt in store.goal_alternatives(row["goal_id"])]
        decisions = [dict(decision) for decision in store.goal_decisions(row["goal_id"])]
        views.append(
            {
                "goal_id": row["goal_id"],
                "intent_id": row["intent_id"],
                "snapshot_id": row["snapshot_id"],
                "statement": row["statement"],
                "success_metric": row["success_metric"],
                "status": row["status"],
                "challenge_state": row["challenge_state"],
                "permission_mode": row["permission_mode"],
                "confidence": float(row["confidence"] or 0.0),
                "alternatives": len(alternatives),
                "decisions": len(decisions),
                "accepted_alternatives": sum(
                    1 for alt in alternatives if alt.get("status") == "accepted"
                ),
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
            }
        )
    return views


def _goal_summary(rows: list[dict[str, Any]]) -> dict[str, Any]:
    total = len(rows)
    challenged = sum(
        1 for row in rows if row.get("challenge_state") in {"warned", "challenged", "redirected"}
    )
    accepted = sum(int(row.get("accepted_alternatives") or 0) for row in rows)
    return {
        "count": total,
        "challenged": challenged,
        "redirected": sum(1 for row in rows if row.get("status") == "redirected"),
        "accepted_alternatives": accepted,
        "challenge_rate": round(challenged / total, 6) if total else 0.0,
    }


def _decision_views(store: Any) -> list[dict[str, Any]]:
    views: list[dict[str, Any]] = []
    for row in store.list_decisions(limit=50):
        briefing = _json_dict(row["briefing_json"])
        human = _json_dict(row["human_decision_json"]) if row["human_decision_json"] else {}
        recommendation = briefing.get("recommendation") or {}
        options = briefing.get("options") or []
        views.append(
            {
                "decision_id": row["decision_id"],
                "question": row["question"],
                "status": row["status"],
                "snapshot_id": row["snapshot_id"],
                "recommended_option_id": recommendation.get("option_id"),
                "recommendation_confidence": _float(recommendation.get("confidence")),
                "recommendation_presented_as": recommendation.get("presented_as"),
                "chosen_option_id": human.get("chosen_option_id"),
                "agreed_with_recommendation": bool(human.get("agreed_with_recommendation")),
                "decided_by": human.get("decided_by"),
                "decided_at": human.get("decided_at"),
                "option_count": len(options),
                "unknown_count": sum(len(option.get("unknowns") or []) for option in options),
                "low_trust_input_count": len(recommendation.get("low_trust_inputs") or []),
                "gap_count": len(recommendation.get("gaps") or []),
                "audit_hash": row["audit_hash"],
                "prev_audit_hash": row["prev_audit_hash"],
            }
        )
    return views


def _decision_summary(rows: list[dict[str, Any]]) -> dict[str, Any]:
    by_status: dict[str, int] = {}
    agreed = 0
    for row in rows:
        status = str(row.get("status") or "unknown")
        by_status[status] = by_status.get(status, 0) + 1
        if row.get("agreed_with_recommendation"):
            agreed += 1
    return {
        "total": len(rows),
        "open": by_status.get("open", 0),
        "analyzed": by_status.get("analyzed", 0),
        "decided": by_status.get("decided", 0),
        "abandoned": by_status.get("abandoned", 0),
        "by_status": by_status,
        "agreed_with_recommendation": agreed,
    }


def _extraction_quality_views(store: Any) -> list[dict[str, Any]]:
    latest_by_source: dict[str, dict[str, Any]] = {}
    for row in store.extraction_eval_results(limit=200):
        source = str(row["source_type"])
        if source in latest_by_source:
            continue
        latest_by_source[source] = {
            "source_type": source,
            "corpus_version": row["corpus_version"],
            "precision": float(row["precision"] or 0.0),
            "recall": float(row["recall"] or 0.0),
            "f1": float(row["f1"] or 0.0),
            "true_positive": int(row["true_positive"] or 0),
            "false_positive": int(row["false_positive"] or 0),
            "false_negative": int(row["false_negative"] or 0),
            "run_created_at": row["run_created_at"],
        }
    calibration: dict[str, dict[str, Any]] = {}
    for row in store.conn.execute(
        "SELECT * FROM trust_calibration ORDER BY computed_at DESC"
    ).fetchall():
        calibration.setdefault(row["source_type"], dict(row))
    sources = sorted(set(latest_by_source) | set(calibration))
    views: list[dict[str, Any]] = []
    for source in sources:
        item = dict(latest_by_source.get(source) or {"source_type": source})
        cal = calibration.get(source) or {}
        item.update(
            {
                "default_tier": cal.get("default_tier"),
                "approval_rate": float(cal.get("approval_rate") or 0.0),
                "sample_size": int(cal.get("sample_size") or 0),
                "confidence_floor": float(cal.get("confidence_floor") or 0.0),
                "method": cal.get("method"),
            }
        )
        views.append(item)
    return views


def _extraction_quality_summary(rows: list[dict[str, Any]]) -> dict[str, Any]:
    if not rows:
        return {"count": 0}
    lowest_precision = min(rows, key=lambda row: float(row.get("precision") or 0.0))
    low_sample = [
        row["source_type"]
        for row in rows
        if row.get("method") == "prior_fallback" or int(row.get("sample_size") or 0) < 5
    ]
    return {
        "count": len(rows),
        "lowest_precision_source": lowest_precision.get("source_type"),
        "lowest_precision": float(lowest_precision.get("precision") or 0.0),
        "low_sample_sources": low_sample,
    }


def _semantic_quality_views(graph: dict[str, Any]) -> dict[str, Any]:
    return {
        "accuracy_latest": graph.get("semantic_accuracy_latest") or {},
        "drift_findings": graph.get("semantic_drift_findings") or {},
        "confidence_distribution": graph.get("semantic_confidence_distribution") or {},
    }


def _h4_security_views(events: list[dict[str, Any]]) -> dict[str, Any]:
    loop_events = [
        event
        for event in events
        if event.get("phase") == "phase_h4" and event.get("kind") == "loop_verify_run"
    ]
    redteam_events = [
        event
        for event in events
        if event.get("phase") == "phase_h4" and event.get("kind") == "redteam_run"
    ]
    latest_loop = loop_events[0].get("payload", {}) if loop_events else {}
    latest_redteam = redteam_events[0].get("payload", {}) if redteam_events else {}
    return {
        "loop_closure": {
            "closed": bool(latest_loop.get("gate_closed") or latest_loop.get("attributable")),
            "latest": latest_loop,
            "runs": len(loop_events),
        },
        "redteam": {
            "ok": bool(latest_redteam.get("ok")),
            "attacks": int(latest_redteam.get("attacks", 0) or 0),
            "served_authoritative_count": int(
                latest_redteam.get("served_authoritative_count", 0) or 0
            ),
            "false_quarantine_rate": float(latest_redteam.get("false_quarantine_rate", 0.0) or 0.0),
            "latest": latest_redteam,
            "runs": len(redteam_events),
        },
    }


def _cie_views(store: Any) -> dict[str, Any]:
    runs = []
    for row in store.learning_runs(kind="cie_cycle", limit=20):
        after = _json_dict(row["after_json"])
        score_value = after.get("score")
        score: dict[str, Any] = score_value if isinstance(score_value, dict) else {}
        snapshot_value = after.get("cognitive_state_snapshot")
        snapshot: dict[str, Any] = snapshot_value if isinstance(snapshot_value, dict) else {}
        runs.append(
            {
                "run_id": row["run_id"],
                "target": row["target"],
                "created_at": row["created_at"],
                "gate_pass": bool(row["gate_pass"]),
                "diagnoses": len(after.get("diagnoses") or []),
                "proposed_interventions": len(after.get("proposed_interventions") or []),
                "blocked_actions": len(after.get("blocked_actions") or []),
                "score": score.get("score"),
                "snapshot_id": snapshot.get("snapshot_id"),
            }
        )
    latest = runs[0] if runs else None
    return {
        "status": "ok" if runs else "idle",
        "run_count": len(runs),
        "latest": latest or {},
        "runs": runs,
        "empty_state": not runs,
    }


def _semantic_quality_summary(view: dict[str, Any]) -> dict[str, Any]:
    accuracy = view.get("accuracy_latest") or {}
    distribution = view.get("confidence_distribution") or {}
    nodes = distribution.get("nodes") or {}
    edges = distribution.get("edges") or {}
    low = int(nodes.get("low") or 0) + int(edges.get("low") or 0)
    total = sum(int(value or 0) for value in nodes.values()) + sum(
        int(value or 0) for value in edges.values()
    )
    return {
        "status": "pass" if accuracy.get("passed") else "no_passing_run",
        "latest_accuracy_passed": bool(accuracy.get("passed")) if accuracy else False,
        "open_drift_findings": int((view.get("drift_findings") or {}).get("open") or 0),
        "low_confidence_share": round(low / total, 6) if total else 0.0,
    }


def _json_dict(value: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _json_list(value: str) -> list[Any]:
    try:
        parsed = json.loads(value or "[]")
    except json.JSONDecodeError:
        return []
    return parsed if isinstance(parsed, list) else []


def _dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _float(value: Any) -> float:
    try:
        return round(float(value or 0.0), 6)
    except (TypeError, ValueError):
        return 0.0
