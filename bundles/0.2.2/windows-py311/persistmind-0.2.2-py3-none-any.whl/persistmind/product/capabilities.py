from __future__ import annotations

import json
import subprocess
from importlib import resources
from pathlib import Path
from typing import Any

from persistmind.storage.descriptors import LATEST_AUTHORITY_SCHEMA_REVISION
from persistmind.release.readiness import validate_production_readiness_artifacts


def capability_matrix(repo_root: Path, *, output_format: str = "json") -> dict[str, Any]:
    registry = json.loads(
        resources.files("persistmind.product")
        .joinpath("teacher_capabilities.json")
        .read_text(encoding="utf-8")
    )
    capabilities = registry["capabilities"]
    commit = _git_commit(repo_root)
    worktree_state = _git_worktree_state(repo_root)
    production_readiness = validate_production_readiness_artifacts(repo_root, require_verified=True)
    payload = {
        "ok": True,
        "schema_version": registry["schema_version"],
        "verified_commit": commit,
        "worktree_state": worktree_state,
        "verified_revision": (commit if worktree_state == "clean" else f"{commit}+working-tree"),
        "migration_head": LATEST_AUTHORITY_SCHEMA_REVISION,
        "release_claims_ready": bool(production_readiness["ok"] and worktree_state == "clean"),
        "production_readiness": production_readiness,
        "capabilities": capabilities,
        "counts": {
            status: sum(1 for item in capabilities if item["status"] == status)
            for status in ("shipped", "partial", "advisory", "planned", "missing")
        },
    }
    if output_format == "markdown":
        payload["rendered"] = _markdown(payload)
    elif output_format != "json":
        raise ValueError("capability matrix format must be json or markdown")
    return payload


def check_capability_claims(repo_root: Path, claim: str | None = None) -> dict[str, Any]:
    matrix = capability_matrix(repo_root)
    source_root = Path(__file__).resolve().parents[3]
    errors: list[str] = []
    allowed_statuses = {"shipped", "partial", "advisory", "planned", "missing"}
    for item in matrix["capabilities"]:
        if item["status"] not in allowed_statuses:
            errors.append(f"{item['id']}: unknown status {item['status']}")
        if item["status"] == "shipped" and not item.get("evidence"):
            errors.append(f"{item['id']}: shipped capability lacks evidence")
        for evidence in item.get("evidence") or []:
            path = str(evidence).split("::", 1)[0]
            if not (repo_root / path).exists() and not (source_root / path).exists():
                errors.append(f"{item['id']}: missing evidence {path}")
    violations = []
    if claim:
        normalized = claim.casefold()
        if not matrix["release_claims_ready"] and any(
            phrase in normalized
            for phrase in ("production-ready", "production ready", "seamless", "fully stable")
        ):
            violations.append(
                {
                    "capability_id": "release_profile",
                    "forbidden_claim": "stable release claim without closed readiness evidence",
                }
            )
        for item in matrix["capabilities"]:
            for forbidden in item.get("claims_forbidden") or []:
                if str(forbidden).casefold() in normalized:
                    violations.append({"capability_id": item["id"], "forbidden_claim": forbidden})
    return {
        "ok": not errors and not violations,
        "schema_version": "persistmind.capability_claim_check.v1",
        "verified_commit": matrix["verified_commit"],
        "release_claims_ready": matrix["release_claims_ready"],
        "production_readiness": matrix["production_readiness"],
        "errors": errors,
        "claim": claim,
        "violations": violations,
    }


def _git_commit(repo_root: Path) -> str:
    try:
        return subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_root,
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=5,
        ).stdout.strip()
    except (FileNotFoundError, subprocess.SubprocessError):
        return "NO_GIT"


def _git_worktree_state(repo_root: Path) -> str:
    try:
        output = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=repo_root,
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=5,
        ).stdout
        return "dirty" if output.strip() else "clean"
    except (FileNotFoundError, subprocess.SubprocessError):
        return "unknown"


def _markdown(matrix: dict[str, Any]) -> str:
    lines = [
        "# Live Teacher Capability Matrix",
        "",
        f"Verified commit: `{matrix['verified_commit']}`  ",
        f"Worktree state: `{matrix['worktree_state']}`  ",
        f"Migration head: `{matrix['migration_head']}`",
        "",
        "| Capability | Status | Evidence | Allowed claim |",
        "| --- | --- | --- | --- |",
    ]
    for item in matrix["capabilities"]:
        lines.append(
            "| {id} | {status} | {evidence} | {claim} |".format(
                id=item["id"],
                status=item["status"],
                evidence="<br>".join(f"`{value}`" for value in item["evidence"]),
                claim="; ".join(item.get("claims_allowed") or []),
            )
        )
    return "\n".join(lines) + "\n"
