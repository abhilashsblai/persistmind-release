from __future__ import annotations

from pathlib import Path
from typing import Any
from urllib.parse import urlparse


CAPABILITY_STATUS_SCHEMA_VERSION = "persistmind.capability_status.v1"
CAPABILITY_STATES = frozenset(
    {
        "authoritative",
        "complete-but-unstructured",
        "degraded",
        "incomplete",
        "experimental",
        "disabled",
        "unavailable",
    }
)

_EXPERIMENTAL_HTTP_PREFIXES: tuple[tuple[str, str, str], ...] = (
    ("/v1/org", "organization_knowledge", "DF-08"),
    ("/v1/cie", "cognitive_improvement", "DF-04"),
    ("/v1/teacher", "teacher_runtime", "DF-04"),
    ("/v1/self-improve", "self_improvement", "DF-06"),
    ("/v1/selfimprove", "self_improvement", "DF-06"),
    ("/v1/selfmod", "self_improvement", "DF-06"),
)


def capability_status_document(
    settings: Any, repo_root: str | Path | None = None
) -> dict[str, Any]:
    """Return the effective, machine-readable capability posture.

    This is deliberately derived from effective settings instead of generated
    release claims.  Callers can therefore use it before opening storage or
    constructing an experimental service.
    """

    profile = str(settings.profile.name)
    enabled = set(settings.deferred.enabled)

    def deferred_status(capability_id: str, required_profile: str) -> str:
        if profile != required_profile:
            return "unavailable" if required_profile == "team-preview" else "disabled"
        return "experimental" if capability_id in enabled else "disabled"

    labs_status = deferred_status("DF-04", "labs")
    team_status = deferred_status("DF-10", "team-preview")
    capabilities = {
        "core_workflow": _capability(
            "authoritative",
            "Local index, pack, task, plan, impact, diff, verification and outcome loop.",
        ),
        "python_source": _capability("authoritative", "Python AST structural source support."),
        "fallback_source": _capability(
            "complete-but-unstructured",
            "Non-Python fallback is text coverage with supplemental hints.",
        ),
        "semantic_retrieval": _capability(
            deferred_status("DF-02", "labs"),
            "Advisory semantic order-only ranking with a deterministic lexical fallback.",
        ),
        "release_qualification": _capability(
            "incomplete",
            "Release qualification requires exact-artifact and observed evidence gates.",
        ),
        "organization_knowledge": _capability(
            deferred_status("DF-08", "team-preview"),
            "Tenant-scoped quarantined organization knowledge and advisory decisions.",
        ),
        "cognitive_improvement": _capability(
            labs_status, "CIE adoption and workflow-changing interventions."
        ),
        "teacher_runtime": _capability(
            labs_status, "Teacher, curriculum and autonomy-changing surfaces."
        ),
        "self_improvement": _capability(
            deferred_status("DF-06", "labs"),
            "Unapplied, sandbox-confined patch proposals; automatic application is unavailable.",
        ),
        "writable_mcp": _capability(
            team_status,
            "Stdio MCP remains read-only; team-preview may use the separate host capability broker.",
        ),
        "polyglot_structural_indexing": _capability(
            deferred_status("DF-01", "labs"),
            "Version-reported tree-sitter adapters with complete lexical fallback.",
        ),
        "analysis_repair_routing": _capability(
            deferred_status("DF-03", "labs"),
            "Source-view-bound nonblocking architecture, repair, and routing advice.",
        ),
        "anticipation": _capability(
            deferred_status("DF-05", "labs"),
            "Task-bound explainable prediction in shadow or warning mode.",
        ),
        "cross_repository_intelligence": _capability(
            deferred_status("DF-07", "labs"),
            "Versioned technical contract edges within one authorized workspace.",
        ),
        "team_read_only_server": _capability(
            deferred_status("DF-09", "team-preview"),
            "OIDC-authenticated tenant-scoped read-only service behind a TLS proxy.",
        ),
        "operational_connectors": _capability(
            deferred_status("DF-11", "team-preview"),
            "Least-privilege read-only connectors with idempotent cursors and quarantine.",
        ),
    }
    assert all(item["status"] in CAPABILITY_STATES for item in capabilities.values())
    document = {
        "ok": True,
        "schema_version": CAPABILITY_STATUS_SCHEMA_VERSION,
        "evidence": {
            "classification": "declarative",
            "runtime_availability_verified": False,
            "storage_readiness_verified": False,
            "release_qualifying": False,
        },
        "profile": profile,
        "capabilities": capabilities,
    }
    from persistmind.release_identity import maturity_warning, public_release_identity

    document["release_identity"] = public_release_identity()
    document["maturity_warning"] = maturity_warning()
    from persistmind.deferred.contracts import capability_registry_document

    document["deferred_registry"] = capability_registry_document()
    if repo_root is not None:
        from persistmind.branding import CAPABILITIES_FILE, resolve_capabilities

        active = resolve_capabilities(Path(repo_root).resolve())
        document["governance"] = {
            "capabilities_file": str(active),
            "canonical": active.name == CAPABILITIES_FILE,
        }
    return document


def http_feature_denial(settings: Any, method: str, path: str) -> dict[str, Any] | None:
    """Return a fail-closed profile denial before HTTP dispatch opens services."""

    del method  # Both reads and writes are disabled for modules absent from core-local.
    route = urlparse(path).path.rstrip("/") or "/"
    # Raw remote command selection is not a labs capability.  It is disabled in
    # every profile until a structured, registered CommandSpec transport exists.
    if route == "/v1/eval/run":
        return {
            "ok": False,
            "status": "feature_disabled",
            "feature": "remote_command_evaluation",
            "profile": str(settings.profile.name),
            "error": "remote_command_evaluation is disabled by the active profile",
        }
    enabled = set(settings.deferred.enabled)
    from persistmind.deferred.contracts import CAPABILITY_REGISTRY

    for prefix, feature, capability_id in _EXPERIMENTAL_HTTP_PREFIXES:
        if route == prefix or route.startswith(f"{prefix}/"):
            descriptor = CAPABILITY_REGISTRY[capability_id]
            if settings.profile.name == descriptor.profile and capability_id in enabled:
                return None
            return {
                "ok": False,
                "status": "experimental_disabled",
                "feature": feature,
                "profile": str(settings.profile.name),
                "error": f"{feature} is disabled by the active profile or explicit feature gate",
            }
    return None


def _capability(status: str, detail: str) -> dict[str, str]:
    return {"status": status, "detail": detail}
