from __future__ import annotations

import json
import re
from typing import Any

_PATH_RE = re.compile(r"\b[\w.-]+(?:/[\w.-]+)+\b")
_POLICY_OVERRIDE_TERMS = (
    "bypass policy",
    "bypass guardrail",
    "circumvent policy",
    "circumvent guardrail",
    "disregard policy",
    "disregard guardrail",
    "ignore policy",
    "ignore guardrail",
    "override policy",
    "override guardrail",
    "skip approval",
    "sidestep policy",
    "sidestep guardrail",
    "work around policy",
    "work around guardrail",
    "disable guardrail",
)
_POLICY_OVERRIDE_VERBS = (
    "bypass",
    "circumvent",
    "disregard",
    "ignore",
    "override",
    "sidestep",
    "disable",
)
_POLICY_OVERRIDE_TARGETS = (
    "approval",
    "approvals",
    "guardrail",
    "guardrails",
    "policy",
    "policies",
)


def applicable_judgment(
    *,
    heuristics: list[Any],
    task: str,
    paths: list[str],
    mode: str,
) -> dict[str, Any]:
    normalized_paths = {path.replace("\\", "/") for path in paths}
    applied = []
    advisory = []
    rejected = []
    for row in heuristics:
        item = _row_dict(row)
        scope = str(item.get("scope") or "")
        assertion = str(item.get("assertion") or "")
        referenced_paths = {
            match.group(0).replace("\\", "/") for match in _PATH_RE.finditer(assertion)
        }
        unpooled_paths = sorted(referenced_paths - normalized_paths)
        if _policy_override_intent(assertion):
            rejected.append(
                _rejection(
                    item,
                    reason="policy_override_intent",
                    detail="Judgment heuristics may not override policy or guardrails.",
                )
            )
            continue
        if unpooled_paths:
            rejected.append(
                _rejection(
                    item,
                    reason="unpooled_path_reference",
                    detail=(
                        "Judgment heuristics may only bias paths already in the "
                        f"deterministic pool: {', '.join(unpooled_paths[:5])}."
                    ),
                )
            )
            continue
        matched = scope == "global" or scope in normalized_paths or scope in task
        if not matched:
            if _looks_like_path(scope):
                rejected.append(
                    _rejection(
                        item,
                        reason="unpooled_scope",
                        detail=(
                            f"Judgment heuristic scope is outside the deterministic pool: {scope}."
                        ),
                    )
                )
            continue
        entry = {
            "heuristic_id": item.get("heuristic_id"),
            "scope": scope,
            "assertion": assertion,
            "basis": _json_dict(item.get("basis_json")),
            "support": int(item.get("support") or 0),
            "lift": float(item.get("lift") or 0.0),
            "applied": mode == "bias_within_pool",
            "guard": "bias_within_pool_only",
        }
        if entry["applied"]:
            applied.append(entry)
        else:
            advisory.append(entry)
    return {
        "ok": True,
        "schema_version": "persistmind.judgment.v1",
        "mode": mode,
        "applied": applied,
        "advisory": advisory,
        "rejected": rejected,
    }


def _row_dict(row: Any) -> dict[str, Any]:
    return dict(row) if not isinstance(row, dict) else row


def _json_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    try:
        parsed = json.loads(value or "{}")
    except (TypeError, json.JSONDecodeError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _policy_override_intent(assertion: str) -> bool:
    normalized = assertion.casefold()
    if any(term in normalized for term in _POLICY_OVERRIDE_TERMS):
        return True
    tokens = set(re.findall(r"[a-z]+", normalized))
    return bool(tokens & set(_POLICY_OVERRIDE_VERBS)) and bool(
        tokens & set(_POLICY_OVERRIDE_TARGETS)
    )


def _looks_like_path(value: str) -> bool:
    return bool(_PATH_RE.search(value.replace("\\", "/")))


def _rejection(item: dict[str, Any], *, reason: str, detail: str) -> dict[str, Any]:
    return {
        "heuristic_id": item.get("heuristic_id"),
        "scope": item.get("scope"),
        "assertion": item.get("assertion"),
        "reason": reason,
        "detail": detail,
        "guard": "bias_within_pool_only",
    }
