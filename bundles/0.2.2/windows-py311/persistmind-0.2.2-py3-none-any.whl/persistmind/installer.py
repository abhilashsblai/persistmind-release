from __future__ import annotations

import hashlib
import os
import shutil
import stat
import uuid
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from persistmind import __version__
from persistmind.agents.adapters import resolve
from persistmind.agents.adapters.codex import default_codex_config_path
from persistmind.branding import (
    CAPABILITIES_FILE,
    INSTALLATION_SCHEMA,
    migrate_user_home,
)
from persistmind.repo_identity import canonical_repo_identity
from persistmind.runtime_invocation import RuntimeInvocation, runtime_invocation
from persistmind.setup import init_git_repo, is_git_repo, setup_readiness
from persistmind.storage.control import StorageControlPlane
from persistmind.updater.atomic import read_json, write_json
from persistmind.updater.paths import update_home
from persistmind.utils import utc_now
from persistmind.workspace_path_policy import validate_workspace_path
from persistmind.workspace_transaction import WorkspaceTransaction


@dataclass(frozen=True)
class InstallOptions:
    agents: tuple[str, ...]
    mcp_command: str = "persistmind"
    runtime_invocation: RuntimeInvocation | None = None
    install_hooks: bool = True
    configure_mcp: bool = True
    init_git: bool = False
    absolute_mcp_repo: bool = True
    codex_config: str | None = None
    skip_index: bool = False


@dataclass(frozen=True)
class _FileSnapshot:
    path: Path
    existed: bool
    sha256: str | None
    backup: Path | None
    mode: int | None


def install_project(repo: Path, options: InstallOptions) -> dict[str, Any]:
    """Install persistmind-nextgen-v1 and native agent surfaces as one transaction.

    Storage activation deliberately happens before agent-surface configuration.
    """

    repo = repo.expanduser().resolve()
    if not repo.is_dir():
        raise ValueError(f"project directory does not exist: {repo}")
    invocation = _install_runtime(options)
    runtime_probe = invocation.validate(repo=repo)
    if not runtime_probe.ok:
        raise RuntimeError(
            "PersistMind runtime invocation is not executable: "
            + str(runtime_probe.error or "probe_failed")
        )
    user_home = migrate_user_home()
    adapters = resolve(options.agents)
    if not adapters:
        raise ValueError("install requires at least one supported coding agent")
    agent_names = tuple(adapter.name for adapter in adapters)

    git_created = False
    if not is_git_repo(repo):
        if not options.init_git:
            raise ValueError("target is not a git repository; rerun with --init-git")
        result = init_git_repo(repo)
        if not result.get("ok"):
            raise RuntimeError(str(result.get("stderr") or "git init failed"))
        git_created = True

    repo_identity = canonical_repo_identity(repo)

    control = StorageControlPlane(repo)
    workspace = control.workspace_root.resolve()
    from persistmind.config import load_settings

    workspace_policy = validate_workspace_path(repo, load_settings(repo).toolchain.workspace_dir)
    if workspace_policy.workspace != workspace:
        raise RuntimeError("storage control workspace disagrees with validated workspace")
    existing_installation = read_json(workspace / "installation.json") or {}
    project_uuid = str(existing_installation.get("project_uuid") or uuid.uuid4().hex)
    install_id = uuid.uuid4().hex
    backup_root = update_home() / "install-backups" / install_id
    candidates = _surface_paths(
        repo,
        workspace,
        agent_names,
        configure_mcp=options.configure_mcp,
        codex_config=options.codex_config,
    )
    candidates = sorted(
        {
            *candidates,
            *_legacy_cursor_surface_paths(repo, existing_installation),
        }
    )
    snapshots: list[_FileSnapshot] = []
    workspace_transaction: WorkspaceTransaction | None = None
    try:
        # The external ownership journal is durable before either workspace or
        # installation-surface snapshots begin.
        workspace_transaction = WorkspaceTransaction.begin(
            workspace_policy,
            update_home() / "install-transactions",
            install_id,
        )
        snapshots = _snapshot_files(candidates, backup_root)
        cursor_migration = _migrate_owned_cursor_surfaces(
            repo,
            existing_installation,
            snapshots,
        )
        previous_installation = next(
            (
                snapshot
                for snapshot in snapshots
                if snapshot.path == workspace / "installation.json"
            ),
            None,
        )
        storage = control.bootstrap()
        workspace_transaction.record_phase("storage_bootstrap")
        schema_plan = control.schema_plan()
        schema_upgrade = control.schema_upgrade_document(schema_plan)
        workspace_transaction.record_phase("schema_upgrade")
        from persistmind.application.setup_service import SetupService

        try:
            service = SetupService(repo)
            workspace_transaction.record_phase("service_open")
            setup = service.setup(
                list(agent_names),
                mcp_command=options.mcp_command,
                install_hooks=options.install_hooks,
                configure_mcp=options.configure_mcp,
                init_git=False,
                absolute_mcp_repo=options.absolute_mcp_repo,
                codex_config=options.codex_config,
                skip_index=True,
                runtime=invocation,
            )
            workspace_transaction.record_phase("agent_setup")
            if not setup.get("ok"):
                raise RuntimeError(
                    "agent setup did not reach readiness: "
                    + ", ".join(setup.get("readiness", {}).get("missing", []))
                )
            if options.skip_index:
                index = None
            else:
                # Claim deterministic product paths before the failure-prone phase.
                operations_dir = workspace / "operations"
                operations_dir.mkdir(exist_ok=True)
                (operations_dir / "workspace-long.lock").touch(exist_ok=True)
                workspace_transaction.record_phase("source_index_prepare")
                from persistmind.storage.source_service import SourceService

                with SourceService(repo) as source:
                    index = source.build()
            workspace_transaction.record_phase("source_index")
            live_readiness = setup_readiness(
                repo,
                list(agent_names),
                probe_mcp=True,
                live_probes=True,
            )
            setup = {
                **setup,
                "ok": bool(live_readiness["ok"]),
                "status": "ready" if live_readiness["ok"] else "incomplete",
                "readiness": live_readiness,
            }
            if not setup["ok"]:
                raise RuntimeError(
                    "agent setup did not pass live readiness: "
                    + ", ".join(live_readiness.get("missing", []))
                )
            workspace_transaction.record_phase("agent_readiness")
            doctor = control.doctor()
            reconciliation = doctor.get("reconciliation", {})
            if not reconciliation.get("ok"):
                reconciliation_attempt = control.reconcile(limit=1000)
                workspace_transaction.record_phase("reconciliation")
                doctor = control.doctor()
                doctor["installation_reconciliation"] = reconciliation_attempt
            if not doctor.get("ok"):
                raise RuntimeError(
                    "PersistMind doctor did not report a healthy installation: "
                    + str(doctor.get("status") or "degraded")
                )
            workspace_transaction.record_phase("doctor")
        except BaseException:
            # Connection close/checkpoint may change already-owned SQLite
            # bytes. Refresh only known entries; never claim a new path after
            # a failed phase.
            workspace_transaction.refresh_owned_entries("service_close_after_failure")
            raise
        workspace_transaction.refresh_owned_entries("service_close")

        verification = control.verify(full=True)
        workspace_transaction.record_phase("storage_verify")
        stores = control.topology().get("stores", [])
        topology_shape = _qualified_nextgen_topology(stores)
        if not verification.get("ok") or not topology_shape["ok"]:
            raise RuntimeError(
                "PersistMind next-generation storage verification failed: "
                f"status={verification.get('status')}, stores={len(stores)}, "
                f"missing_roles={topology_shape['missing_roles']}, "
                f"duplicate_roles={topology_shape['duplicate_roles']}"
            )
        if (workspace / "workspace.db").exists():
            raise RuntimeError("legacy workspace.db was created during authority installation")

        setup_profile = {
            "schema_version": "persistmind.setup_profile.v2",
            "updated_at": utc_now(),
            "engine_version": __version__,
            "agents": list(agent_names),
            "mcp_command": options.mcp_command,
            "install_hooks": bool(options.install_hooks),
            "configure_mcp": bool(options.configure_mcp),
            "absolute_mcp_repo": bool(options.absolute_mcp_repo),
            "codex_config": options.codex_config,
            "skip_index": bool(options.skip_index),
            "runtime_invocation": invocation.to_dict(),
            "runtime_invocation_sha256": invocation.invocation_sha256,
        }
        setup_profile_path = workspace / "setup-profile.json"
        write_json(setup_profile_path, setup_profile)
        workspace_transaction.record_phase("setup_profile")

        current_ownership = [
            record
            for record in _ownership_records(snapshots)
            if record["path"] != str(workspace / "installation.json")
            and record["path"] not in set(cursor_migration["removed_paths"])
        ]
        ownership = _merge_reinstall_ownership(
            _without_migrated_ownership(
                existing_installation.get("owned_surfaces"),
                set(cursor_migration["removed_paths"]),
            ),
            current_ownership,
        )
        rendered_mcp_probe = setup.get("readiness", {}).get("semantic", {}).get("project_mcp_probe")
        agent_activation = {
            "schema_version": "persistmind.agent_activation.v1",
            "configured": bool(options.configure_mcp),
            "rendered_mcp_probe": rendered_mcp_probe,
            # A child-process handshake proves the rendered server. It cannot
            # mutate the registry of a coding-agent process that is already
            # running, so installation must never claim current attachment.
            "current_session_attached": False,
            "restart_required": bool(options.configure_mcp),
            "direct_probe_status": "callable_not_host_attached",
            "project_trust": "user_review_required_if_prompted",
            "command_hook_review": "user_review_required_if_changed",
            "trust_store_mutated": False,
            "status": (
                "configured_restart_required" if options.configure_mcp else "not_configured"
            ),
            "message": (
                "Start a new coding-agent session to load the registered "
                "PersistMind MCP server and hooks."
                if options.configure_mcp
                else "MCP registration was not requested."
            ),
        }
        current_workspace_ownership = {
            "schema_version": "persistmind.workspace_owner_binding.v1",
            "transaction_id": workspace_transaction.transaction_id,
            "nonce": workspace_transaction.nonce,
            "journal": str(workspace_transaction.journal_path),
            "marker": str(workspace / ".persistmind-install-owner.json"),
            "created_root": workspace_transaction.created_root,
        }
        retained_workspace_ownership = existing_installation.get("workspace_ownership")
        workspace_owner_binding = (
            retained_workspace_ownership
            if not workspace_transaction.created_root
            and isinstance(retained_workspace_ownership, dict)
            and retained_workspace_ownership.get("created_root") is True
            else current_workspace_ownership
        )
        manifest = {
            "schema_version": INSTALLATION_SCHEMA,
            "install_id": install_id,
            "installed_at": utc_now(),
            "repo": str(repo),
            "project_uuid": project_uuid,
            "canonical_repo_hash": repo_identity.sha256,
            "repo_identity": repo_identity.document,
            "engine_version": __version__,
            "storage_profile": "persistmind-nextgen-v1",
            "storage_store_count": len(stores),
            "workspace": str(workspace),
            "agents": list(agent_names),
            "options": {
                "mcp_command": options.mcp_command,
                "runtime_invocation": invocation.to_dict(),
                "install_hooks": options.install_hooks,
                "configure_mcp": options.configure_mcp,
                "absolute_mcp_repo": options.absolute_mcp_repo,
                "skip_index": options.skip_index,
            },
            "backup_root": str(backup_root),
            "workspace_ownership": workspace_owner_binding,
            "previous_installation_backup": (
                str(previous_installation.backup)
                if previous_installation and previous_installation.backup
                else None
            ),
            "owned_surfaces": ownership,
            "runtime_invocation": invocation.to_dict(),
            "runtime_invocation_sha256": invocation.invocation_sha256,
            "runtime_probe": runtime_probe.to_dict(),
            "setup_profile": str(setup_profile_path),
            "setup_profile_sha256": _sha256(setup_profile_path),
            "agent_activation": agent_activation,
            "migrations": {"legacy_cursor": cursor_migration},
        }
        write_json(workspace / "installation.json", manifest)
        workspace_transaction.record_phase("installation_manifest")
        workspace_ownership = workspace_transaction.commit()
        return {
            "ok": True,
            "status": "installed",
            "schema_version": "persistmind.install_result.v1",
            "repo": str(repo),
            "project_uuid": project_uuid,
            "canonical_repo_hash": repo_identity.sha256,
            "engine_version": __version__,
            "agents": list(agent_names),
            "storage": storage,
            "storage_schema_upgrade": schema_upgrade,
            "storage_verification": verification,
            "storage_store_count": len(stores),
            "workspace_db_created": False,
            "setup": setup,
            "index": index,
            "doctor": doctor,
            "installation_manifest": str(workspace / "installation.json"),
            "backup_root": str(backup_root),
            "workspace_ownership": workspace_ownership,
            "git_created": git_created,
            "user_home": user_home,
            "runtime_invocation": invocation.to_dict(),
            "runtime_probe": runtime_probe.to_dict(),
            "setup_profile": str(setup_profile_path),
            "setup_profile_sha256": _sha256(setup_profile_path),
            "agent_activation": agent_activation,
        }
    except Exception as exc:
        restore_failures = _restore_files(snapshots)
        rollback = (
            workspace_transaction.rollback()
            if workspace_transaction is not None
            else {
                "ok": True,
                "status": "transaction_not_started",
                "journal": None,
            }
        )
        backup_cleanup_failures = (
            _cleanup_snapshot_backups(snapshots, backup_root)
            if not restore_failures and rollback.get("ok")
            else []
        )
        if restore_failures or backup_cleanup_failures or not rollback.get("ok"):
            detail = {
                "primary_error": str(exc),
                "surface_restore_failures": restore_failures,
                "backup_cleanup_failures": backup_cleanup_failures,
                "workspace_rollback": rollback,
                "backup_root": str(backup_root),
            }
            raise RuntimeError(
                "installation failed and rollback requires recovery: " + str(detail)
            ) from exc
        raise


_REQUIRED_SPLIT_ROLES = frozenset(
    {
        "control",
        "source_manifest",
        "task_state",
        "activity_active",
        "audit_active",
        "knowledge",
        "policy",
        "learning",
    }
)


def _qualified_nextgen_topology(stores: list[dict[str, Any]]) -> dict[str, Any]:
    """Validate the eight writable authorities while allowing sealed Source segments."""

    counts = {
        role: sum(1 for store in stores if str(store.get("store_role")) == role)
        for role in _REQUIRED_SPLIT_ROLES
    }
    missing = sorted(role for role, count in counts.items() if count == 0)
    duplicates = sorted(role for role, count in counts.items() if count > 1)
    return {
        "ok": not missing and not duplicates,
        "missing_roles": missing,
        "duplicate_roles": duplicates,
        "base_store_count": sum(counts.values()),
        "additional_store_count": max(0, len(stores) - sum(counts.values())),
    }


def _surface_paths(
    repo: Path,
    workspace: Path,
    agents: Iterable[str],
    *,
    configure_mcp: bool,
    codex_config: str | None,
) -> list[Path]:
    selected = set(agents)
    paths = {
        repo / ".gitignore",
        repo / CAPABILITIES_FILE,
        repo / "tools" / "verify-production-assets.mjs",
        workspace / "mcp" / "README.md",
        workspace / "setup-profile.json",
        workspace / "installation.json",
    }
    if "codex" in selected:
        paths.update(
            {
                repo / "AGENTS.md",
                repo / ".codex" / "config.toml",
                repo / ".codex" / "hooks.json",
                workspace / "mcp" / "codex.config.toml",
                workspace / "codex" / "hooks" / "persistmind-hook.ps1",
                workspace / "codex" / "hooks" / "persistmind_hook.py",
                workspace / "codex" / "setup-proof.json",
                workspace / "codex" / "setup-modes.md",
            }
        )
        for name in (
            "persistmind-explorer",
            "persistmind-worker",
            "persistmind-reviewer",
            "persistmind-verifier",
        ):
            paths.add(repo / ".codex" / "agents" / f"{name}.toml")
        if configure_mcp:
            paths.add(
                Path(codex_config).expanduser().resolve()
                if codex_config
                else default_codex_config_path().resolve()
            )
    if "claude" in selected:
        paths.update(
            {
                repo / "CLAUDE.md",
                repo / ".mcp.json",
                repo / ".claude" / "settings.json",
                repo / ".claude" / "skills" / "persistmind-loop" / "SKILL.md",
                workspace / "mcp" / "claude-code.ps1",
                workspace / "claude" / "hooks" / "persistmind_hook.py",
            }
        )
        for name in (
            "persistmind-explorer",
            "persistmind-worker",
            "persistmind-reviewer",
            "persistmind-verifier",
        ):
            paths.add(repo / ".claude" / "agents" / f"{name}.md")
    if "gemini" in selected:
        paths.update(
            {
                repo / "GEMINI.md",
                repo / ".gemini" / "settings.json",
                workspace / "gemini" / "hooks" / "persistmind_hook.py",
            }
        )
    if "grok" in selected:
        plugin = repo / ".grok" / "plugins" / "persistmind"
        paths.update(
            {
                repo / "AGENTS.md",
                repo / ".grok" / "config.toml",
                plugin / ".grok-plugin" / "plugin.json",
                plugin / ".claude-plugin" / "plugin.json",
                plugin / "agents" / "persistmind-reviewer.md",
                plugin / "hooks" / "hooks.json",
                plugin / "hooks" / "persistmind_hook.py",
                plugin / "mcp" / "persistmind.json",
                plugin / ".persistmind-plugin-ownership.json",
            }
        )
        for name in (
            "persistmind-context",
            "persistmind-impact",
            "persistmind-memory",
            "persistmind-resume",
            "persistmind-outcome",
        ):
            paths.add(plugin / "skills" / name / "SKILL.md")
    paths.add(repo / ".git" / "hooks" / "pre-commit")
    paths.add(repo / ".git" / "hooks" / "post-commit")
    return sorted(path.resolve() for path in paths)


def _legacy_cursor_surface_paths(
    repo: Path,
    installation: dict[str, Any],
) -> list[Path]:
    allowed = {
        (repo / ".cursor" / "rules" / "persistmind.mdc").resolve(),
        (repo / ".cursor" / "mcp.json").resolve(),
    }
    return sorted(
        {
            Path(str(record["path"])).expanduser().resolve()
            for record in installation.get("owned_surfaces", [])
            if isinstance(record, dict)
            and record.get("path")
            and Path(str(record["path"])).expanduser().resolve() in allowed
        }
    )


def _migrate_owned_cursor_surfaces(
    repo: Path,
    installation: dict[str, Any],
    snapshots: list[_FileSnapshot],
) -> dict[str, Any]:
    """Remove or restore only unchanged Cursor files owned by an earlier install."""

    records = {
        str(Path(str(record["path"])).expanduser().resolve()): record
        for record in installation.get("owned_surfaces", [])
        if isinstance(record, dict) and record.get("path")
    }
    snapshots_by_path = {str(snapshot.path.resolve()): snapshot for snapshot in snapshots}
    removed: list[str] = []
    preserved: list[dict[str, str]] = []
    for path in _legacy_cursor_surface_paths(repo, installation):
        record = records[str(path)]
        snapshot = snapshots_by_path.get(str(path))
        current_hash = _sha256(path) if path.is_file() else None
        expected_hash = str(record.get("after_sha256") or "") or None
        if current_hash is None:
            continue
        if not expected_hash or current_hash != expected_hash:
            preserved.append({"path": str(path), "reason": "user_modified_or_unverifiable"})
            continue
        if snapshot is None:
            raise RuntimeError(f"legacy Cursor migration was not snapshotted: {path}")
        if bool(record.get("created")):
            path.unlink()
        elif bool(record.get("modified")) and record.get("backup"):
            original = Path(str(record["backup"])).expanduser().resolve()
            allowed_root = (update_home() / "install-backups").resolve()
            try:
                original.relative_to(allowed_root)
            except ValueError as exc:
                raise RuntimeError("legacy Cursor backup escaped the install backup root") from exc
            if not original.is_file():
                preserved.append({"path": str(path), "reason": "original_backup_unavailable"})
                continue
            shutil.copy2(original, path)
        else:
            preserved.append({"path": str(path), "reason": "ownership_action_ambiguous"})
            continue
        removed.append(str(path))
    return {
        "schema_version": "persistmind.legacy_cursor_migration.v1",
        "removed_paths": sorted(removed),
        "preserved": preserved,
    }


def _without_migrated_ownership(previous: Any, removed_paths: set[str]) -> list[dict[str, Any]]:
    return [
        dict(record)
        for record in previous or []
        if isinstance(record, dict) and str(record.get("path") or "") not in removed_paths
    ]


def _snapshot_files(paths: Iterable[Path], backup_root: Path) -> list[_FileSnapshot]:
    snapshots: list[_FileSnapshot] = []
    try:
        for index, path in enumerate(paths):
            if path.is_symlink():
                raise RuntimeError(f"refusing to replace symlinked installation surface: {path}")
            if not path.is_file():
                snapshots.append(_FileSnapshot(path, False, None, None, None))
                continue
            backup = backup_root / "files" / f"{index:04d}.backup"
            snapshot = _FileSnapshot(
                path=path,
                existed=True,
                sha256=_sha256(path),
                backup=backup,
                mode=stat.S_IMODE(path.stat().st_mode),
            )
            # Register the exact backup path before the copy so a partial copy
            # is still cleaned item-by-item if snapshotting fails.
            snapshots.append(snapshot)
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, backup)
            try:
                os.chmod(backup, stat.S_IRUSR | stat.S_IWUSR)
            except OSError:
                pass
    except Exception as exc:
        restore_failures = _restore_files(snapshots)
        cleanup_failures = _cleanup_snapshot_backups(snapshots, backup_root)
        if restore_failures or cleanup_failures:
            raise RuntimeError(
                "installation surface snapshot failed and requires recovery: "
                + str(
                    {
                        "primary_error": str(exc),
                        "restore_failures": restore_failures,
                        "cleanup_failures": cleanup_failures,
                    }
                )
            ) from exc
        raise
    return snapshots


def _ownership_records(snapshots: Iterable[_FileSnapshot]) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for snapshot in snapshots:
        after = _sha256(snapshot.path) if snapshot.path.is_file() else None
        if not snapshot.existed and after is None:
            continue
        records.append(
            {
                "path": str(snapshot.path),
                "created": not snapshot.existed and after is not None,
                "modified": snapshot.existed and after != snapshot.sha256,
                "before_sha256": snapshot.sha256,
                "after_sha256": after,
                "backup": str(snapshot.backup) if snapshot.backup else None,
                "mode": snapshot.mode,
            }
        )
    return records


def _merge_reinstall_ownership(
    previous: Any,
    current: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Keep the original restore baseline across any number of reinstalls."""

    previous_by_path = {
        str(item["path"]): dict(item)
        for item in previous or []
        if isinstance(item, dict) and isinstance(item.get("path"), str)
    }
    current_by_path = {str(item["path"]): dict(item) for item in current}
    merged: list[dict[str, Any]] = []
    for path in sorted(set(previous_by_path) | set(current_by_path)):
        prior = previous_by_path.get(path)
        latest = current_by_path.get(path)
        if prior is None:
            assert latest is not None
            merged.append(latest)
            continue
        record = dict(prior)
        if latest is not None:
            record["after_sha256"] = latest.get("after_sha256")
            record["modified"] = bool(record.get("before_sha256") != record.get("after_sha256"))
        merged.append(record)
    return merged


def _restore_files(snapshots: Iterable[_FileSnapshot]) -> list[str]:
    failures: list[str] = []
    for snapshot in snapshots:
        try:
            if snapshot.existed and snapshot.backup is not None:
                snapshot.path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(snapshot.backup, snapshot.path)
                if snapshot.mode is not None:
                    os.chmod(snapshot.path, snapshot.mode)
            elif snapshot.path.exists() and snapshot.path.is_file():
                snapshot.path.unlink()
        except OSError as exc:
            failures.append(f"{snapshot.path}: {exc}")
    return failures


def _cleanup_snapshot_backups(snapshots: Iterable[_FileSnapshot], backup_root: Path) -> list[str]:
    """Delete only transaction-recorded backup files, then empty directories."""

    failures: list[str] = []
    root = backup_root.resolve()
    for snapshot in snapshots:
        if snapshot.backup is None:
            continue
        backup = snapshot.backup.resolve()
        try:
            backup.relative_to(root)
        except ValueError:
            failures.append(f"backup escaped transaction root: {backup}")
            continue
        try:
            backup.unlink(missing_ok=True)
        except OSError as exc:
            failures.append(f"{backup}: {exc}")
    if failures:
        return failures
    if root.exists():
        directories = sorted(
            (path for path in root.rglob("*") if path.is_dir()),
            key=lambda path: len(path.parts),
            reverse=True,
        )
        for directory in [*directories, root]:
            try:
                directory.rmdir()
            except OSError as exc:
                failures.append(f"{directory}: {exc}")
    return failures


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _install_runtime(options: InstallOptions) -> RuntimeInvocation:
    if options.runtime_invocation is not None:
        return runtime_invocation(options.runtime_invocation)
    command = options.mcp_command.strip()
    if command in {"persistmind"}:
        return runtime_invocation()
    path = Path(command).expanduser()
    if command != options.mcp_command or any(char.isspace() for char in command):
        raise ValueError("legacy MCP command strings cannot combine an executable and arguments")
    if not path.is_absolute():
        raise ValueError("managed MCP command must be an absolute Python executable")
    return runtime_invocation(executable=str(path), prefix_args=("-I", "-m", "persistmind"))
