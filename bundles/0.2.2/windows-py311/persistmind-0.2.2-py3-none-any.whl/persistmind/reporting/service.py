from __future__ import annotations

import json
import os
import shutil
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from persistmind.config import load_settings

from .contracts import (
    Impact,
    IncidentOccurrence,
    OccurrenceKind,
    OccurrenceSource,
    Reproducibility,
    Severity,
)
from .diagnostics import DiagnosticCollector
from .export import export_occurrence
from .recorder import IncidentRecorder
from .references import resolve_reporting_references
from .schema import validation_result
from .storage import SQLiteReportingIndex
from .taxonomy import CATEGORIES
from .workspace import IncidentWorkspace, ensure_reporting_layout

_FEEDBACK_CATEGORIES = {
    "incorrect": "incorrect_context",
    "incorrect_context": "incorrect_context",
    "irrelevant": "irrelevant_context",
    "irrelevant_context": "irrelevant_context",
    "outdated": "stale_context",
    "stale_context": "stale_context",
    "incomplete": "missing_context",
    "missing_context": "missing_context",
}


class ReportingService:
    def __init__(self, repo_root: Path, *, create: bool = False) -> None:
        self.repo_root = repo_root.resolve()
        self.settings = load_settings(self.repo_root)
        self.workspace = IncidentWorkspace(self.repo_root, create=create)
        self.index = SQLiteReportingIndex.open(self.repo_root, create=create)
        if create and self.index is None:
            raise RuntimeError("reporting index could not be opened")

    @staticmethod
    def initialize(repo_root: Path) -> dict[str, Any]:
        directories = ensure_reporting_layout(repo_root)
        return {
            "ok": True,
            "schema_version": "persistmind.reporting_layout.v1",
            "directories": directories,
        }

    def close(self) -> None:
        if self.index is not None:
            self.index.close()

    def __enter__(self) -> ReportingService:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def create_incident(self, **request: Any) -> dict[str, Any]:
        if self.index is None:
            raise RuntimeError("reporting index is unavailable")
        explicit_refs = {
            key: request.pop(key, None)
            for key in (
                "operation_id",
                "correlation_id",
                "task_session_id",
                "agent_session_id",
                "pack_id",
                "snapshot_id",
                "generation_id",
                "verification_id",
                "outcome_id",
                "surface",
                "agent",
                "model",
                "operation_type",
            )
        }
        reference = request.pop("reference", None)
        refs = resolve_reporting_references(
            self.repo_root, reference=reference, explicit=explicit_refs
        )
        impact_data = request.pop("impact", None) or {}
        occurrence = IncidentRecorder(
            self.repo_root,
            workspace=self.workspace,
            index=self.index,
            settings=self.settings,
        ).create(
            kind=OccurrenceKind(request.pop("kind", "incident")),
            category=str(request.pop("category")),
            severity=Severity(request.pop("severity", "medium")),
            summary=str(request.pop("summary")),
            source=OccurrenceSource(request.pop("source", "user_reported")),
            expected_behavior=request.pop("expected_behavior", request.pop("expected", None)),
            actual_behavior=request.pop("actual_behavior", request.pop("actual", None)),
            references=refs,
            reproducibility=Reproducibility(request.pop("reproducibility", "unknown")),
            steps=_list(request.pop("steps", [])),
            affected_files=_list(request.pop("affected_files", [])),
            affected_symbols=_list(request.pop("affected_symbols", [])),
            exception_type=request.pop("exception_type", None),
            exception_message=request.pop("exception_message", None),
            stack_trace=request.pop("stack_trace", None),
            impact=Impact.model_validate(impact_data),
            suspected_cause=request.pop("suspected_cause", None),
            workaround=request.pop("workaround", None),
            labels=_list(request.pop("labels", [])),
            automatic_trigger=request.pop("automatic_trigger", None),
        )
        return _occurrence_result(occurrence, "created")

    def create_from_file(self, path: Path) -> dict[str, Any]:
        if path.stat().st_size > self.settings.reporting.max_report_bytes:
            raise ValueError("report input exceeds reporting.max_report_bytes")
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("report input must be a JSON object")
        return self.create_incident(**value)

    def feedback(
        self,
        reference: str,
        *,
        rating: int,
        reason: str,
        summary: str | None = None,
    ) -> dict[str, Any]:
        if self.index is None:
            raise RuntimeError("reporting index is unavailable")
        normalized = reason.strip().lower().replace("-", "_")
        category = _FEEDBACK_CATEGORIES.get(normalized, normalized)
        if category not in CATEGORIES:
            raise ValueError("feedback reason must be a controlled reporting category")
        refs = resolve_reporting_references(self.repo_root, reference=reference)
        occurrence = IncidentRecorder(
            self.repo_root,
            workspace=self.workspace,
            index=self.index,
            settings=self.settings,
        ).create(
            kind=OccurrenceKind.FEEDBACK,
            category=category,
            severity=_feedback_severity(rating),
            summary=summary or f"Feedback for {reference}: {normalized}",
            source=OccurrenceSource.USER_REPORTED,
            references=refs,
            reproducibility=Reproducibility.NOT_APPLICABLE,
            rating=rating,
            feedback_reason=normalized,
        )
        return _occurrence_result(occurrence, "created")

    def list(
        self,
        *,
        kind: str | None = None,
        status: str | None = None,
        severity: str | None = None,
        category: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        if self.index is not None:
            rows = self.index.list_occurrences(
                kind=kind,
                status=status,
                severity=severity,
                category=category,
                limit=limit,
            )
        else:
            items = self.workspace.list(kind=OccurrenceKind(kind) if kind else None)
            rows = [
                {
                    "occurrence_id": item.occurrence.occurrence_id,
                    "kind": item.occurrence.kind.value,
                    "status": item.occurrence.status.value,
                    "severity": item.occurrence.classification.severity.value,
                    "category": item.occurrence.classification.category,
                    "created_at": item.occurrence.created_at_utc.isoformat(),
                    "relative_path": item.relative_path,
                    "content_digest": item.digest,
                }
                for item in items[:limit]
            ]
            rows = [
                row
                for row in rows
                if (not status or row["status"] == status)
                and (not severity or row["severity"] == severity)
                and (not category or row["category"] == category)
            ]
        return {
            "ok": True,
            "schema_version": "persistmind.incident_list.v1",
            "occurrences": rows,
            "count": len(rows),
        }

    def show(self, occurrence_id: str) -> dict[str, Any]:
        occurrence = self.workspace.load(occurrence_id).occurrence
        return {
            "ok": True,
            "status": "found",
            "occurrence": occurrence.model_dump(mode="json", exclude_none=True),
        }

    def validate(self, occurrence_id: str) -> dict[str, Any]:
        try:
            published = self.workspace.load(occurrence_id)
        except (FileNotFoundError, ValueError, json.JSONDecodeError) as exc:
            return {"ok": False, "status": "validation_failed", "errors": [str(exc)]}
        result = validation_result(published.occurrence.model_dump(mode="json", exclude_none=True))
        result.update(
            {
                "occurrence_id": occurrence_id,
                "content_digest": published.digest,
                "content_size": published.size,
            }
        )
        return result

    def export(
        self,
        occurrence_id: str,
        *,
        reviewer: str,
        include_diagnostics: bool = False,
        acknowledge_warnings: bool = False,
    ) -> dict[str, Any]:
        if self.index is None:
            raise RuntimeError("reporting index is unavailable")
        occurrence = self.workspace.load(occurrence_id).occurrence
        indexed = self.index.occurrence_row(occurrence_id)
        published = self.workspace.load(occurrence_id)
        if indexed is None or str(indexed["content_digest"]) != published.digest:
            raise ValueError("occurrence index is missing or divergent; run incident reconcile")
        diagnostics = None
        if include_diagnostics or self.settings.reporting.include_diagnostics_by_default:
            diagnostics = DiagnosticCollector(
                self.repo_root, self.workspace, self.settings.reporting
            ).collect(occurrence)
        return export_occurrence(
            occurrence,
            workspace=self.workspace,
            index=self.index,
            config=self.settings.reporting,
            reviewer=reviewer,
            diagnostics=diagnostics,
            acknowledge_warnings=acknowledge_warnings,
        )

    def reconcile(self, *, apply: bool = False) -> dict[str, Any]:
        published = self.workspace.list()
        if self.index is None:
            if apply:
                raise RuntimeError("reporting index is unavailable")
            result = {"missing_index_rows": len(published), "divergent": 0}
        else:
            result = self.index.check_reconciliation(published)
        quarantined: list[str] = []
        if apply and self.index is not None:
            for item in published:
                row = self.index.occurrence_row(item.occurrence.occurrence_id)
                if row is not None and str(row["content_digest"]) != item.digest:
                    quarantined.append(self._quarantine_divergence(item.path, item.digest))
            applied = self.index.reconcile(published)
        else:
            applied = {"inserted": 0, "divergent": result["divergent"]}
        return {
            "ok": result["divergent"] == 0,
            "status": "reconciled" if apply else "checked",
            "schema_version": "persistmind.reporting_reconciliation.v1",
            "before": result,
            "applied": applied,
            "quarantined": quarantined,
        }

    def _quarantine_divergence(self, path: Path, digest: str) -> str:
        directory = self.workspace.state_dir / "diagnostics" / "quarantine"
        directory.mkdir(parents=True, exist_ok=True)
        target = directory / f"{path.stem}-sha256-{digest}.json"
        if not target.exists():
            temporary = target.with_name(f".{target.name}.{os.getpid()}.tmp")
            shutil.copyfile(path, temporary)
            os.replace(temporary, target)
        return str(target)

    def import_legacy(self, path: Path) -> dict[str, Any]:
        if path.stat().st_size > 128 * 1024:
            raise ValueError("legacy incident exceeds 128 KiB")
        text = path.read_text(encoding="utf-8", errors="replace")
        summary = next(
            (line.lstrip("# ").strip() for line in text.splitlines() if line.strip()),
            "Imported legacy incident",
        )[:4000]
        return self.create_incident(
            category="tool_execution_failure",
            severity="medium",
            summary=summary,
            source="imported",
            actual_behavior="Legacy Markdown imported as untrusted summary-only evidence.",
            labels=["legacy-import", "untrusted-content"],
        )

    def erase(self, occurrence_id: str, *, confirm: bool) -> dict[str, Any]:
        if not confirm:
            raise PermissionError("privacy erasure requires explicit confirmation")
        if self.index is None:
            raise RuntimeError("reporting index is unavailable")
        published = self.workspace.load(occurrence_id)
        export_paths = self.index.erase_occurrence(occurrence_id)
        removed: list[str] = []
        for path in [published.path, *(Path(item) for item in export_paths)]:
            if path.exists():
                path.unlink()
                removed.append(str(path))
        diagnostics = self.workspace.state_dir / "diagnostics" / f"{occurrence_id}-diagnostics.json"
        if diagnostics.exists():
            diagnostics.unlink()
            removed.append(str(diagnostics))
        return {
            "ok": True,
            "status": "erased",
            "occurrence_id": occurrence_id,
            "removed": removed,
            "recoverable": False,
        }

    def doctor(self) -> dict[str, Any]:
        workspace_result = self.workspace.reconcile()
        index_result = {"missing_index_rows": 0, "divergent": 0}
        if self.index is not None:
            index_result = self.index.check_reconciliation(self.workspace.list())
        directories = {
            name: (self.workspace.state_dir / name).is_dir()
            for name in ("incidents", "feedback", "diagnostics", "exports")
        }
        return {
            "ok": all(directories.values())
            and workspace_result["ok"]
            and not index_result["divergent"],
            "schema_version": "persistmind.reporting_doctor.v1",
            "directories": directories,
            "workspace": workspace_result,
            "index": index_result,
            "submission_enabled": bool(
                self.settings.reporting.submission_enabled and self.settings.reporting.collector_url
            ),
        }

    def retention(self, *, apply: bool = False, confirm: bool = False) -> dict[str, Any]:
        cutoff = datetime.now(UTC) - timedelta(days=self.settings.reporting.retention_days)
        eligible = [
            item.occurrence.occurrence_id
            for item in self.workspace.list()
            if item.occurrence.status.value == "closed" and item.occurrence.created_at_utc < cutoff
        ]
        if apply and not confirm:
            raise PermissionError("retention deletion requires explicit --confirm")
        removed: list[str] = []
        if apply:
            for occurrence_id in eligible:
                removed.extend(self.erase(occurrence_id, confirm=True)["removed"])
        return {
            "ok": True,
            "status": "applied" if apply else "preview",
            "schema_version": "persistmind.reporting_retention.v1",
            "retention_days": self.settings.reporting.retention_days,
            "cutoff": cutoff.isoformat(),
            "eligible_occurrences": eligible,
            "removed": removed,
        }

    def summary(self) -> dict[str, Any]:
        return (
            self.index.summary()
            if self.index
            else {"total": len(self.workspace.list()), "groups": []}
        )


def _feedback_severity(rating: int) -> Severity:
    if rating not in {1, 2, 3, 4, 5}:
        raise ValueError("rating must be between 1 and 5")
    return {
        1: Severity.HIGH,
        2: Severity.MEDIUM,
        3: Severity.LOW,
        4: Severity.INFORMATIONAL,
        5: Severity.INFORMATIONAL,
    }[rating]


def _list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if not isinstance(value, list):
        raise ValueError("reporting list fields must be arrays")
    return [str(item) for item in value]


def _occurrence_result(occurrence: IncidentOccurrence, status: str) -> dict[str, Any]:
    return {
        "ok": True,
        "status": status,
        "schema_version": occurrence.schema_version,
        "occurrence_id": occurrence.occurrence_id,
        "kind": occurrence.kind.value,
        "category": occurrence.classification.category,
        "severity": occurrence.classification.severity.value,
        "reporting_refs": occurrence.references.model_dump(mode="json", exclude_none=True),
        "network_used": False,
    }


__all__ = ["ReportingService"]
