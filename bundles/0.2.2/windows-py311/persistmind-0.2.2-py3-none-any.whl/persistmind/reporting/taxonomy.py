from __future__ import annotations

from types import MappingProxyType

_GROUPS: dict[str, tuple[str, ...]] = {
    "system_health": (
        "indexing_failed",
        "incremental_index_missed_change",
        "stale_index",
        "duplicate_chunks",
        "missing_file",
        "unsupported_file_type",
        "symbol_extraction_failed",
        "dependency_graph_incomplete",
        "slow_indexing",
        "slow_retrieval",
        "high_memory_usage",
        "high_disk_usage",
        "database_lock",
        "timeout",
        "excessive_token_usage",
    ),
    "context_selection": (
        "incorrect_context",
        "irrelevant_context",
        "missing_context",
        "stale_context",
        "wrong_branch_context",
        "wrong_repository_context",
        "context_pack_too_large",
        "context_pack_too_small",
        "contradictory_context",
        "incorrect_code_generated",
        "hallucinated_symbol",
        "hallucinated_file",
    ),
    "memory_quality": (
        "incorrect_memory",
        "stale_memory",
        "memory_not_retrieved",
        "memory_written_incorrectly",
        "duplicate_memory",
        "conflicting_memory",
        "temporary_information_persisted",
        "important_information_not_persisted",
    ),
    "surface_parity": (
        "agent_ignored_context",
        "context_not_injected",
        "malformed_context_pack",
        "unsupported_agent",
    ),
    "execution_discipline": (
        "agent_instruction_conflict",
        "tool_execution_failure",
        "session_handoff_failure",
    ),
    "impact_prediction": (
        "incorrect_impact_analysis",
        "missed_dependency",
        "incorrect_file_selection",
    ),
    "verification_gap": ("incorrect_test_recommendation",),
    "security": (
        "secret_exposed",
        "sensitive_file_indexed",
        "access_control_failure",
        "cross_project_data_leak",
        "unsafe_context_injection",
        "untrusted_content_executed",
    ),
}

CATEGORY_TO_CIE = MappingProxyType(
    {category: domain for domain, categories in _GROUPS.items() for category in categories}
)
CATEGORIES = tuple(sorted(CATEGORY_TO_CIE))
CIE_DOMAINS = tuple(sorted(_GROUPS))


def cie_domain_for(category: str) -> str:
    try:
        return CATEGORY_TO_CIE[category]
    except KeyError as exc:
        raise ValueError(f"unknown incident category: {category}") from exc


__all__ = ["CATEGORIES", "CATEGORY_TO_CIE", "CIE_DOMAINS", "cie_domain_for"]
