from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any

from .central_storage import CentralTriageStore
from .export import inspect_package
from .sanitization import scan_export_document


class CollectorIngestionService:
    def __init__(self, repo_root: Path) -> None:
        self.repo_root = repo_root.resolve()
        self.state_dir = self.repo_root / ".persistmind"

    def ingest(
        self, package: Path, *, source: str = "cli", dry_run: bool = False
    ) -> dict[str, Any]:
        inspected = inspect_package(package)
        occurrence = inspected["occurrence"]
        digest = str(inspected["package_digest"])
        verdict, findings = scan_export_document(
            occurrence.model_dump(mode="json", exclude_none=True)
        )
        if dry_run:
            return {
                "ok": verdict == "pass",
                "status": "valid" if verdict == "pass" else "quarantined",
                "dry_run": True,
                "occurrence_id": occurrence.occurrence_id,
                "package_digest": digest,
                "privacy_findings": list(findings),
            }
        with CentralTriageStore.open(self.repo_root) as store:
            ingest_id, duplicate = store.begin_ingest(digest, source)
            if duplicate:
                return {
                    "ok": True,
                    "status": "duplicate",
                    "ingest_run_id": ingest_id,
                    "package_digest": digest,
                }
            state = "accepted" if verdict == "pass" else "quarantined"
            artifact = self._store_package(package, digest, state)
            if state == "quarantined":
                store.finish_ingest(
                    ingest_id,
                    state=state,
                    occurrence_id=occurrence.occurrence_id,
                    artifact_ref=artifact,
                    reason=",".join(findings),
                    counts={"privacy_findings": len(findings)},
                )
                return {
                    "ok": False,
                    "status": "quarantined",
                    "ingest_run_id": ingest_id,
                    "occurrence_id": occurrence.occurrence_id,
                    "privacy_findings": list(findings),
                }
            proposal = store.propose_issue(occurrence)
            try:
                diagnostics = json.loads(inspected["entries"]["diagnostics.json"])
            except (KeyError, TypeError, json.JSONDecodeError):
                diagnostics = {}
            platform_data = diagnostics.get("collectors", {}).get("platform", {})
            store.finish_ingest(
                ingest_id,
                state="accepted",
                occurrence_id=occurrence.occurrence_id,
                artifact_ref=artifact,
                counts={
                    "entries": len(inspected["entries"]),
                    "bytes": inspected["package_size"],
                    "version": occurrence.persistmind.version or "unknown",
                    "component": proposal.get("component") or occurrence.classification.cie_domain,
                    "platform": platform_data.get("system") or "unknown",
                    "severity": occurrence.classification.severity.value,
                    "incorrect_code": occurrence.impact.incorrect_code_generated,
                    "rework_minutes": occurrence.impact.estimated_rework_minutes,
                },
            )
            return {
                "ok": True,
                "status": "accepted",
                "ingest_run_id": ingest_id,
                "occurrence_id": occurrence.occurrence_id,
                "package_digest": digest,
                "artifact_ref": artifact,
                "deduplication": proposal,
            }

    def _store_package(self, source: Path, digest: str, state: str) -> str:
        directory = self.state_dir / "diagnostics" / "collector" / state
        directory.mkdir(parents=True, exist_ok=True)
        target = directory / f"sha256-{digest}.zip"
        if not target.exists():
            temporary = target.with_name(f".{target.name}.{os.getpid()}.tmp")
            shutil.copyfile(source, temporary)
            os.replace(temporary, target)
        return f"sha256:{digest}"


__all__ = ["CollectorIngestionService"]
