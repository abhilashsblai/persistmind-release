"""Packaged reporting resources."""
