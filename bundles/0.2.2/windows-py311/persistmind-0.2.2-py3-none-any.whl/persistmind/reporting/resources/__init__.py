"""Packaged reporting resources."""
