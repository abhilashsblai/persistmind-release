"""Versioned reporting JSON Schemas."""
