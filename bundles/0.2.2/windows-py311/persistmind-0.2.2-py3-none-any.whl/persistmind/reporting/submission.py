from __future__ import annotations

import json
import urllib.error
import urllib.request
from datetime import UTC, datetime
from pathlib import Path
from typing import Literal, cast
from urllib.parse import urlparse

from persistmind.config import ReportingConfig
from persistmind.utils import stable_id

from .contracts import SubmissionReceipt
from .export import inspect_package
from .storage import SQLiteReportingIndex


def submit_export(
    *,
    occurrence_id: str,
    export_id: str | None,
    index: SQLiteReportingIndex,
    config: ReportingConfig,
    confirm: bool,
) -> dict[str, object]:
    if not confirm:
        raise PermissionError("submission requires explicit --confirm")
    if not config.submission_enabled or not config.collector_url:
        raise PermissionError("reporting submission is not configured and enabled")
    parsed = urlparse(config.collector_url)
    if parsed.scheme != "https":
        raise ValueError("collector_url must use HTTPS")
    row = index.export(export_id, occurrence_id)
    if row is None:
        raise FileNotFoundError("reviewed export not found")
    path = Path(str(row["package_path"]))
    inspected = inspect_package(path, max_bytes=config.max_package_bytes)
    digest = str(inspected["package_digest"])
    if digest != str(row["package_digest"]):
        raise ValueError("immutable export digest has changed")
    token = _collector_token(config.collector_token_key)
    idempotency_key = stable_id("reporting-submit", str(row["export_id"]), digest)
    request = urllib.request.Request(
        config.collector_url.rstrip("/") + "/v1/collector/incidents",
        data=path.read_bytes(),
        method="POST",
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/zip",
            "X-PersistMind-Package-SHA256": digest,
            "Idempotency-Key": idempotency_key,
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            payload = json.loads(response.read(64 * 1024))
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"collector rejected submission with HTTP {exc.code}") from exc
    except (urllib.error.URLError, TimeoutError) as exc:
        raise RuntimeError(
            "collector submission failed; the reviewed export remains local"
        ) from exc
    now = datetime.now(UTC)
    status = str(payload.get("status") or "accepted")
    if status not in {"accepted", "duplicate", "rejected"}:
        raise ValueError("collector returned an invalid receipt status")
    receipt = SubmissionReceipt(
        receipt_id=str(payload.get("receipt_id") or "PM-RCP-" + stable_id(idempotency_key)[:24]),
        export_id=str(row["export_id"]),
        package_digest=digest,
        collector=config.collector_url,
        submitted_at=now,
        status=cast(Literal["accepted", "duplicate", "rejected"], status),
        remote_occurrence_id=payload.get("occurrence_id"),
    )
    index.record_receipt(receipt, idempotency_key)
    return {
        "ok": status != "rejected",
        "status": status,
        "receipt": receipt.model_dump(mode="json"),
    }


def _collector_token(key_name: str) -> str:
    import keyring

    token = keyring.get_password("persistmind.reporting", key_name)
    if not token:
        raise PermissionError("collector credential is unavailable from the configured keyring")
    return token


__all__ = ["submit_export"]
