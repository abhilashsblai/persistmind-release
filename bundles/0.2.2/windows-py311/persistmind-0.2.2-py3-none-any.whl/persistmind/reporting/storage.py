from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any, Mapping, Protocol

from persistmind.branding import resolve_project_state
from persistmind.storage.descriptors import StoreRole
from persistmind.utils import canonical_json
from persistmind.utils import stable_id, utc_now

from .contracts import ExportManifest, SubmissionReceipt
from .workspace import PublishedOccurrence


class IncidentActivityPort(Protocol):
    def find_automatic(
        self, operation_id: str, trigger: str, fingerprint: str
    ) -> Mapping[str, Any] | None: ...

    def index_occurrence(self, published: PublishedOccurrence) -> Mapping[str, Any]: ...

    def increment_automatic(self, operation_id: str, trigger: str, fingerprint: str) -> int: ...

    def record_export(
        self, manifest: ExportManifest, path: Path, digest: str, size: int
    ) -> None: ...

    def record_receipt(self, receipt: SubmissionReceipt, idempotency_key: str) -> None: ...


class SQLiteReportingIndex:
    def __init__(self, connection: Any, *, close_callback: Any = None) -> None:
        self.connection = connection
        self._close_callback = close_callback

    @classmethod
    def open(cls, repo_root: Path, *, create: bool) -> "SQLiteReportingIndex | None":
        state = resolve_project_state(repo_root, require_existing=not create)
        catalog = state / "catalog" / "current.json"
        if catalog.exists():
            from persistmind.storage.adapters.sqlite_activity import SQLiteActivityStore
            from persistmind.storage.runtime import (
                StorageOpenIntent,
                StorageRuntime,
                resolve_runtime_store,
            )

            runtime = StorageRuntime.open(
                state,
                intent=StorageOpenIntent.REQUIRE_INITIALIZED,
                read_only=not create,
                required_roles=frozenset({StoreRole.ACTIVITY_ACTIVE}),
            )
            store = resolve_runtime_store(runtime, StoreRole.ACTIVITY_ACTIVE, read_only=not create)
            if not isinstance(store, SQLiteActivityStore):
                runtime.close()
                raise RuntimeError("activity reporting route is not SQLite")
            if not create and not _table_exists(store.connection, "incident_occurrences"):
                runtime.close()
                return None
            return cls(store.connection, close_callback=runtime.close)
        return None

    def close(self) -> None:
        if self._close_callback is not None:
            callback, self._close_callback = self._close_callback, None
            callback()

    def __enter__(self) -> "SQLiteReportingIndex":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def find_automatic(
        self, operation_id: str, trigger: str, fingerprint: str
    ) -> Mapping[str, Any] | None:
        row = self.connection.execute(
            "SELECT * FROM incident_occurrences WHERE operation_id=? "
            "AND automatic_trigger=? AND error_fingerprint=? ORDER BY created_at LIMIT 1",
            (operation_id, trigger, fingerprint),
        ).fetchone()
        return self._with_occurrence_count(dict(row)) if row else None

    def increment_automatic(self, operation_id: str, trigger: str, fingerprint: str) -> int:
        record_id = _automatic_count_id(operation_id, trigger, fingerprint)
        now = utc_now()
        payload = canonical_json(
            {
                "kind": "automatic_incident_count",
                "operation_id": operation_id,
                "automatic_trigger": trigger,
                "error_fingerprint": fingerprint,
            }
        )
        digest = stable_id(payload)
        with self.connection:
            self.connection.execute(
                "INSERT INTO domain_records("
                "record_id,kind,scope,payload_json,content_hash,revision,created_at,updated_at,idempotency_key"
                ") VALUES(?,?,?,?,?,1,?,?,?) ON CONFLICT(record_id) DO UPDATE SET "
                "revision=domain_records.revision+1,updated_at=excluded.updated_at",
                (
                    record_id,
                    "automatic_incident_count",
                    operation_id,
                    payload,
                    digest,
                    now,
                    now,
                    "automatic-incident-count:" + record_id,
                ),
            )
        row = self.connection.execute(
            "SELECT revision FROM domain_records WHERE record_id=?", (record_id,)
        ).fetchone()
        return int(row[0]) if row else 1

    def index_occurrence(self, published: PublishedOccurrence) -> Mapping[str, Any]:
        occurrence = published.occurrence
        refs = occurrence.references
        values = (
            occurrence.occurrence_id,
            occurrence.kind.value,
            occurrence.status.value,
            occurrence.classification.severity.value,
            occurrence.classification.category,
            occurrence.classification.cie_domain,
            occurrence.source.value,
            occurrence.created_at_utc.isoformat(),
            published.relative_path,
            published.digest,
            published.size,
            occurrence.project.repo_id,
            occurrence.project.workspace_id,
            refs.operation_id,
            refs.correlation_id,
            refs.pack_id,
            refs.snapshot_id,
            refs.generation_id,
            occurrence.automatic_trigger,
            occurrence.evidence.error_fingerprint,
        )
        try:
            with self.connection:
                self.connection.execute(
                    "INSERT INTO incident_occurrences("
                    "occurrence_id,kind,status,severity,category,cie_domain,source,created_at,"
                    "relative_path,content_digest,content_size,repo_id,workspace_id,operation_id,"
                    "correlation_id,pack_id,snapshot_id,generation_id,automatic_trigger,error_fingerprint"
                    ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    values,
                )
        except sqlite3.IntegrityError:
            existing = self.connection.execute(
                "SELECT * FROM incident_occurrences WHERE occurrence_id=?",
                (occurrence.occurrence_id,),
            ).fetchone()
            if existing is None:
                raise
            if (
                str(existing["content_digest"]) != published.digest
                or str(existing["relative_path"]) != published.relative_path
            ):
                raise ValueError("indexed occurrence digest divergence")
            return dict(existing)
        row = self.connection.execute(
            "SELECT * FROM incident_occurrences WHERE occurrence_id=?",
            (occurrence.occurrence_id,),
        ).fetchone()
        return dict(row)

    def list_occurrences(
        self,
        *,
        kind: str | None = None,
        status: str | None = None,
        severity: str | None = None,
        category: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        clauses: list[str] = []
        values: list[Any] = []
        for column, value in (
            ("kind", kind),
            ("status", status),
            ("severity", severity),
            ("category", category),
        ):
            if value:
                clauses.append(f"{column}=?")
                values.append(value)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        values.append(max(1, min(int(limit), 1000)))
        rows = self.connection.execute(
            "SELECT * FROM incident_occurrences" + where + " ORDER BY created_at DESC LIMIT ?",
            tuple(values),
        ).fetchall()
        return [self._with_occurrence_count(dict(row)) for row in rows]

    def occurrence_row(self, occurrence_id: str) -> dict[str, Any] | None:
        row = self.connection.execute(
            "SELECT * FROM incident_occurrences WHERE occurrence_id=?", (occurrence_id,)
        ).fetchone()
        return self._with_occurrence_count(dict(row)) if row else None

    def record_export(self, manifest: ExportManifest, path: Path, digest: str, size: int) -> None:
        with self.connection:
            self.connection.execute(
                "INSERT OR IGNORE INTO incident_exports VALUES(?,?,?,?,?,?,?,?,?,?)",
                (
                    manifest.export_id,
                    manifest.occurrence_id,
                    str(path),
                    digest,
                    size,
                    manifest.sanitizer_version,
                    manifest.privacy_verdict,
                    manifest.reviewer,
                    int(manifest.warnings_acknowledged),
                    manifest.created_at.isoformat(),
                ),
            )
            self.connection.execute(
                "UPDATE incident_occurrences SET status='exported',exported_at=? "
                "WHERE occurrence_id=?",
                (manifest.created_at.isoformat(), manifest.occurrence_id),
            )

    def export(self, export_id: str | None, occurrence_id: str) -> dict[str, Any] | None:
        if export_id:
            row = self.connection.execute(
                "SELECT * FROM incident_exports WHERE export_id=? AND occurrence_id=?",
                (export_id, occurrence_id),
            ).fetchone()
        else:
            row = self.connection.execute(
                "SELECT * FROM incident_exports WHERE occurrence_id=? ORDER BY created_at DESC LIMIT 1",
                (occurrence_id,),
            ).fetchone()
        return dict(row) if row else None

    def record_receipt(self, receipt: SubmissionReceipt, idempotency_key: str) -> None:
        payload = canonical_json(receipt.model_dump(mode="json", exclude_none=True))
        with self.connection:
            self.connection.execute(
                "INSERT OR IGNORE INTO incident_submission_receipts VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    receipt.receipt_id,
                    receipt.export_id,
                    receipt.collector,
                    idempotency_key,
                    receipt.package_digest,
                    receipt.status,
                    receipt.remote_occurrence_id,
                    payload,
                    receipt.submitted_at.isoformat(),
                ),
            )
            self.connection.execute(
                "UPDATE incident_occurrences SET status='submitted',submitted_at=? "
                "WHERE occurrence_id=(SELECT occurrence_id FROM incident_exports WHERE export_id=?)",
                (receipt.submitted_at.isoformat(), receipt.export_id),
            )

    def reconcile(self, published: list[PublishedOccurrence]) -> dict[str, int]:
        inserted = divergent = 0
        for item in published:
            row = self.connection.execute(
                "SELECT content_digest FROM incident_occurrences WHERE occurrence_id=?",
                (item.occurrence.occurrence_id,),
            ).fetchone()
            if row is None:
                self.index_occurrence(item)
                inserted += 1
            elif str(row[0]) != item.digest:
                divergent += 1
        return {"inserted": inserted, "divergent": divergent}

    def check_reconciliation(self, published: list[PublishedOccurrence]) -> dict[str, int]:
        missing = divergent = 0
        for item in published:
            row = self.connection.execute(
                "SELECT content_digest FROM incident_occurrences WHERE occurrence_id=?",
                (item.occurrence.occurrence_id,),
            ).fetchone()
            if row is None:
                missing += 1
            elif str(row[0]) != item.digest:
                divergent += 1
        return {"missing_index_rows": missing, "divergent": divergent}

    def summary(self) -> dict[str, Any]:
        rows = self.connection.execute(
            "SELECT kind,status,severity,category,COUNT(*) count FROM incident_occurrences "
            "GROUP BY kind,status,severity,category ORDER BY count DESC"
        ).fetchall()
        canonical = sum(int(row["count"]) for row in rows)
        observed_row = self.connection.execute(
            "SELECT COALESCE(SUM(revision),0) FROM domain_records "
            "WHERE kind='automatic_incident_count'"
        ).fetchone()
        automatic_observations = int(observed_row[0]) if observed_row else 0
        automatic_canonical = int(
            self.connection.execute(
                "SELECT COUNT(*) FROM incident_occurrences WHERE source='automatic'"
            ).fetchone()[0]
        )
        return {
            "total": canonical,
            "observed_total": canonical - automatic_canonical + automatic_observations,
            "groups": [dict(row) for row in rows],
        }

    def _with_occurrence_count(self, row: dict[str, Any]) -> dict[str, Any]:
        if str(row.get("source") or "") != "automatic":
            row["occurrence_count"] = 1
            return row
        record_id = _automatic_count_id(
            str(row.get("operation_id") or ""),
            str(row.get("automatic_trigger") or ""),
            str(row.get("error_fingerprint") or ""),
        )
        count = self.connection.execute(
            "SELECT revision FROM domain_records WHERE record_id=?", (record_id,)
        ).fetchone()
        row["occurrence_count"] = int(count[0]) if count else 1
        return row

    def erase_occurrence(self, occurrence_id: str) -> list[str]:
        exports = self.connection.execute(
            "SELECT package_path FROM incident_exports WHERE occurrence_id=?", (occurrence_id,)
        ).fetchall()
        with self.connection:
            self.connection.execute(
                "DELETE FROM incident_submission_receipts WHERE export_id IN "
                "(SELECT export_id FROM incident_exports WHERE occurrence_id=?)",
                (occurrence_id,),
            )
            self.connection.execute(
                "DELETE FROM incident_exports WHERE occurrence_id=?", (occurrence_id,)
            )
            self.connection.execute(
                "DELETE FROM incident_occurrences WHERE occurrence_id=?", (occurrence_id,)
            )
        return [str(row["package_path"]) for row in exports]


def _table_exists(connection: Any, name: str) -> bool:
    row = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)
    ).fetchone()
    return row is not None


def _automatic_count_id(operation_id: str, trigger: str, fingerprint: str) -> str:
    return "reporting_count_" + stable_id(operation_id, trigger, fingerprint)[:32]


__all__ = ["IncidentActivityPort", "SQLiteReportingIndex"]
