from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any

from persistmind.storage.control import StorageControlPlane
from persistmind.utils import canonical_repo_path

from .service import ReportingService


class ReportingProjectionService:
    """Authority-aware dashboard and rollup projections.

    The projection reads topology from Control and incident aggregates from the
    Activity-owned reporting index. It never queries retired generic feature
    compatibility tables.
    """

    def __init__(self, repo_root: Path, *, read_only: bool = False) -> None:
        self.repo_root = repo_root.resolve()
        self.read_only = read_only

    def dashboard_data(self) -> dict[str, Any]:
        topology = StorageControlPlane(self.repo_root).status()
        stores = [dict(item) for item in topology.get("stores", []) if isinstance(item, dict)]
        roles: dict[str, int] = {}
        for store in stores:
            role = str(store.get("store_role") or "unknown")
            roles[role] = roles.get(role, 0) + 1
        with ReportingService(self.repo_root, create=False) as reporting:
            incidents = reporting.summary()
        dashboard = {
            "overview": {
                "storage_status": topology.get("status"),
                "topology_generation": topology.get("generation"),
                "authority_count": len(stores),
                "sealed_source_partitions": sum(
                    role == "source_segment" and bool(store.get("read_only"))
                    for store in stores
                    for role in [str(store.get("store_role") or "")]
                ),
                "canonical_incidents": int(incidents.get("total") or 0),
                "incident_occurrences": int(
                    incidents.get("observed_total", incidents.get("total")) or 0
                ),
            },
            "authorities": {
                "roles": dict(sorted(roles.items())),
                "stores": stores,
            },
            "reporting": incidents,
        }
        return {
            "ok": topology.get("status") == "ready",
            "status": topology.get("status"),
            "schema_version": "persistmind.authority_dashboard.v1",
            "dashboard": dashboard,
            "nextgen_v1": True,
        }

    def dashboard_render(self, output: str | Path) -> dict[str, Any]:
        relative = canonical_repo_path(str(output), self.repo_root, reject_outside=True)
        target = self.repo_root / relative
        data = self.dashboard_data()
        payload = html.escape(
            json.dumps(data["dashboard"], sort_keys=True, ensure_ascii=False), quote=False
        )
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            '<!doctype html><html lang="en"><head><meta charset="utf-8">'
            "<title>PersistMind authority dashboard</title></head><body>"
            "<h1>PersistMind authority dashboard</h1><pre>" + payload + "</pre></body></html>\n",
            encoding="utf-8",
        )
        return {
            "ok": bool(data["ok"]),
            "status": data.get("status"),
            "schema_version": "persistmind.authority_dashboard_render.v1",
            "output": relative,
            "bytes": target.stat().st_size,
            "nextgen_v1": True,
        }

    def metrics_rollup(
        self,
        *,
        label: str | None = None,
        limit: int = 30,
        output: str | Path | None = None,
    ) -> dict[str, Any]:
        data = self.dashboard_data()
        reporting = dict(data["dashboard"]["reporting"])
        groups = list(reporting.get("groups", []))[: max(1, min(int(limit), 100))]
        result = {
            "ok": bool(data["ok"]),
            "status": data.get("status"),
            "schema_version": "persistmind.authority_metrics_rollup.v1",
            "label": label,
            "topology_generation": data["dashboard"]["overview"]["topology_generation"],
            "authority_count": data["dashboard"]["overview"]["authority_count"],
            "incident_occurrences": reporting.get("observed_total", reporting.get("total", 0)),
            "incident_groups": groups,
            "bounded": True,
            "nextgen_v1": True,
        }
        if output:
            relative = canonical_repo_path(str(output), self.repo_root, reject_outside=True)
            target = self.repo_root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            result["output"] = relative
        return result


__all__ = ["ReportingProjectionService"]
