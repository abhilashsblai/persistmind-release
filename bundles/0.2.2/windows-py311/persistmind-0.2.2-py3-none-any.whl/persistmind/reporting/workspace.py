from __future__ import annotations

import hashlib
import json
import os
import secrets
import stat
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from persistmind.branding import resolve_project_state

from .contracts import IncidentOccurrence, OccurrenceKind
from .schema import validate_document

REPORTING_DIRECTORIES = ("incidents", "feedback", "diagnostics", "exports")
MAX_OCCURRENCE_FILES = 1_000
MAX_OCCURRENCE_BYTES = 256 * 1024 * 1024
MAX_OCCURRENCES_PER_HOUR = 100


def canonical_json_bytes(value: Any) -> bytes:
    if hasattr(value, "model_dump"):
        value = value.model_dump(mode="json", exclude_none=True)
    return (
        json.dumps(
            value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
        )
        + "\n"
    ).encode("utf-8")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def ensure_reporting_layout(repo_root: Path) -> dict[str, str]:
    state = resolve_project_state(repo_root.resolve())
    state.mkdir(parents=True, exist_ok=True)
    created: dict[str, str] = {}
    for name in REPORTING_DIRECTORIES:
        target = state / name
        _reject_link(target, allow_missing=True)
        target.mkdir(exist_ok=True)
        created[name] = str(target)
    return created


@dataclass(frozen=True)
class PublishedOccurrence:
    occurrence: IncidentOccurrence
    path: Path
    relative_path: str
    digest: str
    size: int


class IncidentWorkspace:
    def __init__(self, repo_root: Path, *, create: bool = False) -> None:
        self.repo_root = repo_root.resolve()
        self.state_dir = resolve_project_state(self.repo_root, require_existing=not create)
        if create:
            ensure_reporting_layout(self.repo_root)
        self._validate_root()

    def publish(self, occurrence: IncidentOccurrence) -> PublishedOccurrence:
        directory = self._directory(occurrence.kind, require=True)
        target = directory / f"{occurrence.occurrence_id}.json"
        _reject_link(target, allow_missing=True)
        payload = canonical_json_bytes(occurrence)
        _enforce_occurrence_quota(directory, len(payload))
        validate_document(json.loads(payload))
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=f".{occurrence.occurrence_id}.", suffix=".tmp", dir=directory
        )
        temporary = Path(temporary_name)
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            try:
                os.link(temporary, target)
            except FileExistsError as exc:
                raise FileExistsError(
                    f"occurrence already exists: {occurrence.occurrence_id}"
                ) from exc
            except OSError:
                # Windows may deny hard links in restricted environments.  The
                # reservation file preserves create-exclusive semantics.
                reservation = target.with_suffix(".reserve")
                flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
                reserved = os.open(reservation, flags, 0o600)
                os.close(reserved)
                try:
                    os.replace(temporary, target)
                finally:
                    reservation.unlink(missing_ok=True)
            _fsync_directory(directory)
        finally:
            temporary.unlink(missing_ok=True)
        relative = target.relative_to(self.state_dir).as_posix()
        return PublishedOccurrence(
            occurrence=occurrence,
            path=target,
            relative_path=relative,
            digest=sha256_bytes(payload),
            size=len(payload),
        )

    def load(self, occurrence_id: str) -> PublishedOccurrence:
        path = self.find_path(occurrence_id)
        payload = path.read_bytes()
        if len(payload) > 512 * 1024:
            raise ValueError("occurrence exceeds the local report size limit")
        document = json.loads(payload)
        occurrence = validate_document(document)
        if not isinstance(occurrence, IncidentOccurrence):
            raise ValueError("document is not an incident occurrence")
        if occurrence.occurrence_id != occurrence_id:
            raise ValueError("occurrence identity does not match filename")
        return PublishedOccurrence(
            occurrence=occurrence,
            path=path,
            relative_path=path.relative_to(self.state_dir).as_posix(),
            digest=sha256_bytes(payload),
            size=len(payload),
        )

    def list(self, *, kind: OccurrenceKind | None = None) -> list[PublishedOccurrence]:
        names = (
            ("feedback",)
            if kind is OccurrenceKind.FEEDBACK
            else ("incidents",)
            if kind is OccurrenceKind.INCIDENT
            else ("incidents", "feedback")
        )
        rows: list[PublishedOccurrence] = []
        for name in names:
            directory = self.state_dir / name
            if not directory.exists():
                continue
            _reject_link(directory)
            for path in sorted(directory.glob("PM-*.json")):
                if _is_link_or_reparse(path):
                    continue
                try:
                    rows.append(self.load(path.stem))
                except (OSError, ValueError, json.JSONDecodeError):
                    continue
        return sorted(rows, key=lambda item: item.occurrence.created_at_utc, reverse=True)

    def find_path(self, occurrence_id: str) -> Path:
        _validate_occurrence_id(occurrence_id)
        for name in ("incidents", "feedback"):
            candidate = self.state_dir / name / f"{occurrence_id}.json"
            if candidate.exists():
                _reject_link(candidate)
                return candidate
        raise FileNotFoundError(f"occurrence not found: {occurrence_id}")

    def output_path(self, directory: str, filename: str) -> Path:
        if directory not in REPORTING_DIRECTORIES:
            raise ValueError(f"unsupported reporting directory: {directory}")
        if Path(filename).name != filename or filename in {"", ".", ".."}:
            raise ValueError("reporting filename must be a simple relative name")
        target_dir = self.state_dir / directory
        if not target_dir.exists():
            raise FileNotFoundError(f"reporting directory is not initialized: {target_dir}")
        _reject_link(target_dir)
        return target_dir / filename

    def reconcile(self) -> dict[str, Any]:
        valid = self.list()
        all_files = sum(
            1
            for name in ("incidents", "feedback")
            if (self.state_dir / name).exists()
            for _ in (self.state_dir / name).glob("*.json")
        )
        return {
            "ok": len(valid) == all_files,
            "valid": len(valid),
            "invalid": max(0, all_files - len(valid)),
        }

    def _directory(self, kind: OccurrenceKind, *, require: bool) -> Path:
        name = "feedback" if kind is OccurrenceKind.FEEDBACK else "incidents"
        path = self.state_dir / name
        if require and not path.exists():
            raise FileNotFoundError(f"reporting layout is not initialized: {path}")
        _reject_link(path, allow_missing=not require)
        return path

    def _validate_root(self) -> None:
        if not self.state_dir.is_relative_to(self.repo_root):
            raise ValueError("project state directory escapes repository root")
        _reject_link(self.state_dir, allow_missing=True)


def new_occurrence_id(kind: OccurrenceKind, created_at_utc: Any) -> str:
    prefix = "PM-FBK" if kind is OccurrenceKind.FEEDBACK else "PM-INC"
    timestamp = created_at_utc.strftime("%Y%m%d-%H%M%S")
    return f"{prefix}-{timestamp}-{secrets.token_hex(4)}"


def _validate_occurrence_id(value: str) -> None:
    if (
        len(value) != 31
        or not value.startswith(("PM-INC-", "PM-FBK-"))
        or any(
            character not in "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-abcdef" for character in value
        )
    ):
        raise ValueError("invalid occurrence ID")


def _reject_link(path: Path, *, allow_missing: bool = False) -> None:
    if not path.exists():
        if allow_missing:
            return
        raise FileNotFoundError(path)
    if _is_link_or_reparse(path):
        raise ValueError(f"reporting path must not be a link or reparse point: {path}")


def _is_link_or_reparse(path: Path) -> bool:
    if path.is_symlink():
        return True
    try:
        attributes = os.lstat(path).st_file_attributes
    except (AttributeError, OSError):
        return False
    return bool(attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT)


def _fsync_directory(path: Path) -> None:
    if os.name == "nt":
        return
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _enforce_occurrence_quota(directory: Path, incoming_bytes: int) -> None:
    files = [path for path in directory.glob("PM-*.json") if path.is_file()]
    if len(files) >= MAX_OCCURRENCE_FILES:
        raise OverflowError("reporting occurrence count quota exceeded")
    total = sum(path.stat().st_size for path in files)
    if total + incoming_bytes > MAX_OCCURRENCE_BYTES:
        raise OverflowError("reporting occurrence byte quota exceeded")
    cutoff = datetime_now_epoch() - 3600
    recent = sum(1 for path in files if path.stat().st_mtime >= cutoff)
    if recent >= MAX_OCCURRENCES_PER_HOUR:
        raise OverflowError("reporting occurrence rate quota exceeded")


def datetime_now_epoch() -> float:
    import time

    return time.time()


__all__ = [
    "IncidentWorkspace",
    "PublishedOccurrence",
    "REPORTING_DIRECTORIES",
    "canonical_json_bytes",
    "ensure_reporting_layout",
    "new_occurrence_id",
    "sha256_bytes",
]
