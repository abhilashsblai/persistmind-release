from __future__ import annotations

from pathlib import Path
from typing import Any

from .storage import SQLiteReportingIndex
from .workspace import IncidentWorkspace


def reviewed_cie_signal_rows(repo_root: Path, *, limit: int = 20) -> list[dict[str, Any]]:
    """Project reviewed occurrences into CIE as untrusted evidence.

    Only controlled labels and a bounded summary cross this boundary.  No raw
    stack, reproduction, prompt, query, or attachment content is projected.
    """

    index = SQLiteReportingIndex.open(repo_root, create=False)
    if index is None:
        return []
    try:
        rows: list[dict[str, Any]] = []
        workspace = IncidentWorkspace(repo_root)
        for status in ("submitted", "exported", "reviewed", "closed"):
            for metadata in index.list_occurrences(status=status, limit=limit):
                if len(rows) >= limit:
                    break
                occurrence = workspace.load(str(metadata["occurrence_id"])).occurrence
                rows.append(
                    {
                        "event_id": occurrence.occurrence_id,
                        "kind": "reporting_occurrence",
                        "phase": "reviewed_incident_evidence",
                        "source": "reporting_occurrence",
                        "ok": False,
                        "payload": {
                            "status": status,
                            "error": " ".join(occurrence.summary.split())[:180],
                            "occurrence_id": occurrence.occurrence_id,
                            "detailed_category": occurrence.classification.category,
                            "cie_domain": occurrence.classification.cie_domain,
                        },
                    }
                )
        return rows[:limit]
    finally:
        index.close()


__all__ = ["reviewed_cie_signal_rows"]
