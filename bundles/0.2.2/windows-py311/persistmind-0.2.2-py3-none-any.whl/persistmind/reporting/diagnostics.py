from __future__ import annotations

import importlib.metadata
import os
import platform
import subprocess
import time
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from persistmind.config import ReportingConfig
from persistmind.release_identity import public_release_identity
from persistmind.utils import stable_id

from .contracts import DiagnosticBundle, IncidentOccurrence
from .workspace import IncidentWorkspace, canonical_json_bytes


class DiagnosticCollector:
    """Runs only a small allowlist of metadata collectors.

    Collector output deliberately excludes environment variables, directory
    listings, log files, database pages, prompts, and source content.
    """

    def __init__(
        self,
        repo_root: Path,
        workspace: IncidentWorkspace,
        config: ReportingConfig,
    ) -> None:
        self.repo_root = repo_root.resolve()
        self.workspace = workspace
        self.config = config

    def collect(self, occurrence: IncidentOccurrence) -> DiagnosticBundle:
        collectors: dict[str, Any] = {}
        failures: dict[str, str] = {}
        for name, function in self._collectors().items():
            started = time.monotonic()
            try:
                value = function()
                if time.monotonic() - started > self.config.diagnostic_timeout_seconds:
                    raise TimeoutError("collector exceeded its time budget")
                encoded = canonical_json_bytes(value)
                if len(encoded) > 64 * 1024:
                    raise ValueError("collector exceeded its 64 KiB output limit")
                collectors[name] = value
            except Exception as exc:  # diagnostics are best-effort and bounded
                failures[name] = type(exc).__name__
        created = datetime.now(UTC)
        bundle = DiagnosticBundle(
            diagnostic_id="PM-DIAG-"
            + stable_id(occurrence.occurrence_id, created.isoformat())[:24],
            occurrence_id=occurrence.occurrence_id,
            created_at=created,
            collectors=collectors,
            failures=failures,
        )
        payload = canonical_json_bytes(bundle)
        if len(payload) > self.config.max_diagnostics_bytes:
            raise ValueError("diagnostics bundle exceeds reporting.max_diagnostics_bytes")
        target = self.workspace.output_path(
            "diagnostics", f"{occurrence.occurrence_id}-diagnostics.json"
        )
        temporary = target.with_name(f".{target.name}.{os.getpid()}.tmp")
        temporary.write_bytes(payload)
        os.replace(temporary, target)
        return bundle

    def _collectors(self) -> dict[str, Callable[[], Any]]:
        return {
            "release": public_release_identity,
            "platform": lambda: {
                "system": platform.system(),
                "release": platform.release(),
                "machine": platform.machine(),
                "python": platform.python_version(),
                "implementation": platform.python_implementation(),
            },
            "git": self._git,
            "storage": self._storage,
            "dependencies": self._dependencies,
        }

    def _git(self) -> dict[str, Any]:
        values: dict[str, Any] = {}
        for key, arguments in {
            "version": ("--version",),
            "branch": ("rev-parse", "--abbrev-ref", "HEAD"),
            "commit": ("rev-parse", "HEAD"),
            "dirty": ("status", "--porcelain", "--untracked-files=no"),
        }.items():
            result = subprocess.run(
                ["git", "-C", str(self.repo_root), *arguments],
                check=False,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=self.config.diagnostic_timeout_seconds,
            )
            if key == "dirty":
                values["dirty"] = bool(result.stdout.strip())
            else:
                values[key] = result.stdout.strip()[:512] if result.returncode == 0 else None
        return values

    def _storage(self) -> dict[str, Any]:
        state = self.workspace.state_dir
        databases = (
            "stores/control/control.db",
            "stores/activity/active.db",
            "stores/task/task-state.db",
            "stores/source/default/manifest.db",
            "stores/audit/active.db",
            "stores/knowledge/knowledge.db",
            "stores/policy/policy.db",
            "stores/learning/learning.db",
        )
        return {
            "profile": "persistmind-nextgen-v1"
            if (state / "catalog" / "current.json").exists()
            else "uninitialized",
            "databases": {
                name: {"present": (state / name).exists(), "bytes": (state / name).stat().st_size}
                if (state / name).exists()
                else {"present": False, "bytes": 0}
                for name in databases
            },
        }

    @staticmethod
    def _dependencies() -> dict[str, str | None]:
        names = ("persistmind", "pydantic", "apsw", "cryptography", "keyring", "mcp")
        versions: dict[str, str | None] = {}
        for name in names:
            try:
                versions[name] = importlib.metadata.version(name)
            except importlib.metadata.PackageNotFoundError:
                versions[name] = None
        return versions


__all__ = ["DiagnosticCollector"]
