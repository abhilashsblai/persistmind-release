from __future__ import annotations

from persistmind.utils import stable_id

from .contracts import IncidentOccurrence

FINGERPRINT_VERSION = "persistmind.canonical_fingerprint.v1"


def canonical_fingerprint(occurrence: IncidentOccurrence) -> str:
    evidence = occurrence.evidence
    normalized_exception = " ".join((evidence.exception_type or "").casefold().split())
    structural = evidence.error_fingerprint or ""
    value = stable_id(
        FINGERPRINT_VERSION,
        occurrence.classification.category,
        occurrence.classification.cie_domain,
        occurrence.references.operation_type or "",
        normalized_exception,
        structural,
        occurrence.persistmind.runtime_profile or "",
    )
    return f"pmcanon-v1:{value}"


def component_for(occurrence: IncidentOccurrence) -> str:
    category = occurrence.classification.category
    if "index" in category or category in {"duplicate_chunks", "symbol_extraction_failed"}:
        return "indexing"
    if "memory" in category:
        return "memory"
    if category.startswith("agent_") or category in {"context_not_injected", "unsupported_agent"}:
        return "agent_integration"
    if occurrence.classification.cie_domain == "security":
        return "security"
    if occurrence.classification.cie_domain == "impact_prediction":
        return "impact_analysis"
    return occurrence.classification.cie_domain


__all__ = ["FINGERPRINT_VERSION", "canonical_fingerprint", "component_for"]
