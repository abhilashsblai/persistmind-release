from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any, Mapping

from persistmind.branding import resolve_project_state
from persistmind.config import load_settings
from persistmind.utils import stable_id

from .service import ReportingService

_STATE = threading.local()
_TRIGGER_MAP = {
    "database_corrupt": ("database_lock", "critical"),
    "database_lock": ("database_lock", "high"),
    "catalog_recovery_ambiguous": ("wrong_repository_context", "critical"),
    "storage_not_initialized": ("indexing_failed", "high"),
    "index_publication_failed": ("indexing_failed", "high"),
    "hash_mismatch": ("stale_index", "high"),
    "malformed_context_pack": ("malformed_context_pack", "high"),
    "missing_snapshot": ("stale_index", "high"),
    "timeout": ("timeout", "medium"),
    "memory_write_failed": ("memory_written_incorrectly", "high"),
    "cross_repository_mismatch": ("cross_project_data_leak", "critical"),
    "agent_integration_failed": ("tool_execution_failure", "high"),
    "internal_error": ("tool_execution_failure", "high"),
}


def maybe_capture_result(
    repo_root: Path,
    result: Mapping[str, Any],
    *,
    operation: str,
    surface: str,
) -> dict[str, Any] | None:
    if bool(getattr(_STATE, "active", False)):
        return None
    try:
        settings = load_settings(repo_root)
        if not settings.reporting.enabled or not settings.reporting.automatic_capture:
            return None
        state = resolve_project_state(repo_root, require_existing=True)
        if not all(
            (state / name).is_dir() for name in ("incidents", "feedback", "diagnostics", "exports")
        ):
            return None
        trigger = classify_failure_trigger(result, operation=operation)
        if trigger is None or trigger not in settings.reporting.automatic_triggers:
            _counter(state, "skipped")
            return None
        category, severity = _TRIGGER_MAP[trigger]
        operation_id = str(result.get("operation_id") or "")
        if not operation_id:
            return None
        nested_refs = result.get("reporting_refs")
        reporting_refs = nested_refs if isinstance(nested_refs, Mapping) else {}

        def reference(name: str) -> str | None:
            value = result.get(name) or reporting_refs.get(name)
            return str(value) if value else None

        _STATE.active = True
        _counter(state, "attempted")
        with ReportingService(repo_root, create=True) as service:
            created = service.create_incident(
                category=category,
                severity=severity,
                summary=f"PersistMind {operation} failed with {trigger.replace('_', ' ')}.",
                source="automatic",
                operation_id=operation_id,
                correlation_id=str(result.get("correlation_id") or "") or None,
                task_session_id=reference("task_session_id"),
                agent_session_id=reference("agent_session_id"),
                pack_id=reference("pack_id"),
                snapshot_id=reference("snapshot_id"),
                generation_id=reference("generation_id"),
                surface=surface,
                operation_type=operation,
                exception_type=str(result.get("error_type") or "") or None,
                exception_message=str(result.get("error") or result.get("status") or "")[:4000],
                automatic_trigger=trigger,
            )
        _counter(state, "succeeded")
        return created
    except Exception:
        try:
            state = resolve_project_state(repo_root, require_existing=True)
            _counter(state, "failed")
        except Exception:
            pass
        return None
    finally:
        _STATE.active = False


def maybe_capture_hook_failure(
    repo_root: Path,
    result: Mapping[str, Any],
    *,
    event: str,
    host_event_id: str | None = None,
) -> dict[str, Any] | None:
    """Capture a denied or failed hook after its policy decision is complete."""

    decision = str(result.get("decision") or "").strip().lower()
    if decision != "block" and result.get("ok") is not False:
        return None
    reason = str(result.get("reason") or "PersistMind hook failed")[:4000]
    # A missing, expired, or stale write-policy snapshot is an intentional
    # governance denial.  It is not the source/index snapshot failure covered
    # by the automatic ``missing_snapshot`` incident trigger.
    expected_governance_denial = any(
        marker in reason.casefold()
        for marker in (
            "policy snapshot",
            "broad repository scanning is prohibited",
            "repository reads require fresh persistmind-first context",
        )
    )
    if decision == "block" and expected_governance_denial:
        return None
    trigger = "agent_integration_failed"
    operation_id = stable_id(
        "hook_failure",
        str(repo_root.resolve()),
        event,
        host_event_id or "",
        reason,
    )
    return maybe_capture_result(
        repo_root,
        {
            "ok": False,
            "status": "internal_error",
            "operation_id": operation_id,
            "correlation_id": host_event_id or operation_id,
            "error": reason,
            "error_type": "HookPolicyBlock" if decision == "block" else "HookFailure",
            "incident_trigger": trigger,
            "task_session_id": result.get("task_session_id"),
            "pack_id": result.get("pack_id"),
        },
        operation=f"hook:{event}",
        surface="hook",
    )


def classify_failure_trigger(result: Mapping[str, Any], *, operation: str = "") -> str | None:
    explicit = str(result.get("incident_trigger") or "").strip()
    if explicit in _TRIGGER_MAP:
        return explicit
    status = str(result.get("interface_status") or result.get("status") or "").strip().lower()
    aliases = {
        "database_corrupt": "database_corrupt",
        "catalog_recovery_ambiguous": "catalog_recovery_ambiguous",
        "storage_not_initialized": "storage_not_initialized",
        "timeout": "timeout",
    }
    aliased = aliases.get(status)
    if aliased:
        return aliased
    error = str(result.get("error") or "").strip().lower()
    if status in {"busy", "database_locked", "database_busy"} and any(
        token in error for token in ("database is locked", "database is busy")
    ):
        return "database_lock"
    if "not utf-8" in error and operation in {"index", "pack", "install"}:
        return "index_publication_failed"
    if status == "internal_error":
        return "internal_error"
    return None


def _counter(state: Path, name: str) -> None:
    path = state / "diagnostics" / "capture-health.json"
    data: dict[str, int] = {}
    if path.exists():
        try:
            parsed = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(parsed, dict):
                data = {str(key): int(value) for key, value in parsed.items()}
        except (OSError, ValueError, json.JSONDecodeError):
            data = {}
    data[name] = data.get(name, 0) + 1
    path.write_text(
        json.dumps(data, sort_keys=True, separators=(",", ":")) + "\n", encoding="utf-8"
    )


__all__ = [
    "classify_failure_trigger",
    "maybe_capture_hook_failure",
    "maybe_capture_result",
]
