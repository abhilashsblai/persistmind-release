from __future__ import annotations

import json
import urllib.request
from pathlib import Path
from typing import Any

from persistmind.config import ReportingConfig
from persistmind.utils import canonical_json, utc_now

from .central_storage import CentralTriageStore


def github_issue_draft(store: CentralTriageStore, issue_id: str) -> dict[str, Any]:
    row = store.connection.execute(
        "SELECT i.*,COUNT(CASE WHEN l.decision='accepted' AND l.active=1 THEN 1 END) "
        "accepted_occurrences FROM canonical_issues i LEFT JOIN canonical_issue_occurrences l "
        "ON l.canonical_issue_id=i.canonical_issue_id WHERE i.canonical_issue_id=? "
        "GROUP BY i.canonical_issue_id",
        (issue_id,),
    ).fetchone()
    if row is None:
        raise KeyError("canonical issue not found")
    if str(row["status"]) not in {"confirmed", "investigating", "regressed"}:
        raise PermissionError("GitHub drafting requires a confirmed canonical issue")
    title = f"[{row['component']}] {issue_id} ({row['severity']})"
    body = "\n".join(
        [
            "## PersistMind canonical issue",
            "",
            f"- ID: `{issue_id}`",
            f"- Component: `{row['component']}`",
            f"- Severity: `{row['severity']}`",
            f"- Status: `{row['status']}`",
            f"- Accepted occurrences: {int(row['accepted_occurrences'])}",
            f"- First seen release: `{row['first_seen_release'] or 'unknown'}`",
            f"- Last seen release: `{row['last_seen_release'] or 'unknown'}`",
            "",
            "This draft contains aggregate, reviewed metadata only. Inspect linked internal "
            "evidence before publishing remediation details.",
        ]
    )
    return {
        "schema_version": "persistmind.github_issue_draft.v1",
        "canonical_issue_id": issue_id,
        "title": title,
        "body": body,
        "labels": ["persistmind", str(row["component"]), str(row["severity"])],
        "advisory_only": True,
    }


def create_github_issue(
    repo_root: Path,
    *,
    issue_id: str,
    reviewer: str,
    config: ReportingConfig,
    confirm: bool,
) -> dict[str, Any]:
    if not confirm:
        raise PermissionError("GitHub issue creation requires explicit --confirm")
    if not reviewer.strip():
        raise ValueError("maintainer reviewer identity is required")
    if not config.github_enabled or not config.github_repository:
        raise PermissionError("GitHub issue creation is disabled by reporting configuration")
    repository = config.github_repository.strip().strip("/")
    if repository.count("/") != 1:
        raise ValueError("reporting.github_repository must be owner/repository")
    with CentralTriageStore.open(repo_root) as store:
        draft = github_issue_draft(store, issue_id)
        token = _github_token(config.github_token_key)
        request = urllib.request.Request(
            f"https://api.github.com/repos/{repository}/issues",
            data=json.dumps(
                {
                    "title": draft["title"],
                    "body": draft["body"],
                    "labels": draft["labels"],
                }
            ).encode("utf-8"),
            headers={
                "Accept": "application/vnd.github+json",
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
                "User-Agent": "PersistMind-incident-triage",
                "X-GitHub-Api-Version": "2022-11-28",
            },
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=15) as response:
            result = json.loads(response.read(256 * 1024))
        identity = {
            "number": int(result["number"]),
            "url": str(result["html_url"]),
            "repository": repository,
            "approved_by": reviewer,
            "created_at": utc_now(),
        }
        row = store.connection.execute(
            "SELECT resolution_json FROM canonical_issues WHERE canonical_issue_id=?",
            (issue_id,),
        ).fetchone()
        resolution = json.loads(str(row["resolution_json"] or "{}")) if row else {}
        resolution["github_issue"] = identity
        with store.connection:
            store.connection.execute(
                "UPDATE canonical_issues SET resolution_json=?,updated_at=? "
                "WHERE canonical_issue_id=?",
                (canonical_json(resolution), utc_now(), issue_id),
            )
        return {"ok": True, "status": "created", "github_issue": identity, **draft}


def _github_token(key: str) -> str:
    try:
        import keyring
    except ImportError as exc:
        raise RuntimeError("keyring is required for GitHub issue creation") from exc
    token = keyring.get_password(key, "token")
    if not token:
        raise PermissionError(f"GitHub token is not available in keyring service {key!r}")
    return token


__all__ = ["create_github_issue", "github_issue_draft"]
