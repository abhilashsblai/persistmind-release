from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

from persistmind.branding import resolve_project_state
from persistmind.utils import stable_id

from .contracts import ReportingReferences

_MAX_PACK_REFERENCE_BYTES = 64 * 1024 * 1024


def resolve_reporting_references(
    repo_root: Path,
    *,
    reference: str | None = None,
    explicit: dict[str, str | None] | None = None,
) -> ReportingReferences:
    explicit_operation_id = bool((explicit or {}).get("operation_id"))
    values: dict[str, Any] = {key: value for key, value in (explicit or {}).items() if value}
    if reference:
        values.setdefault("operation_id", reference)
    connections = _candidate_connections(repo_root)
    try:
        pack_reference = values.get("pack_id") or reference
        if pack_reference:
            pack = _query_first(
                connections,
                "SELECT pack_id,snapshot_id,repo_id,manifest_json,source_generation_id "
                "FROM context_packs WHERE pack_id=?",
                (pack_reference,),
            )
            if pack:
                _require_local_repo(repo_root, pack["repo_id"], "context pack")
                values["pack_id"] = str(pack["pack_id"])
                values["snapshot_id"] = str(pack["snapshot_id"] or "") or None
                values["generation_id"] = str(pack["source_generation_id"] or "") or None
                try:
                    manifest = json.loads(str(pack["manifest_json"]))
                except (json.JSONDecodeError, TypeError):
                    manifest = {}
                values["generation_id"] = values.get("generation_id") or manifest.get(
                    "source_generation_id"
                )
                values["task_session_id"] = values.get("task_session_id") or manifest.get(
                    "task_session_id"
                )
                if not explicit_operation_id:
                    values.pop("operation_id", None)
            elif manifest := _nextgen_pack_manifest(repo_root, connections, str(pack_reference)):
                values["pack_id"] = str(manifest.get("pack_id") or pack_reference)
                values["snapshot_id"] = str(manifest.get("snapshot_id") or "") or None
                values["generation_id"] = str(manifest.get("source_generation_id") or "") or None
                values["task_session_id"] = values.get("task_session_id") or manifest.get(
                    "task_session_id"
                )
                if not explicit_operation_id:
                    values.pop("operation_id", None)
            elif values.get("pack_id"):
                raise ValueError(f"context pack not found: {pack_reference}")
        task_reference = values.get("task_session_id") or reference
        if task_reference:
            task = _query_first(
                connections,
                "SELECT * FROM task_sessions WHERE task_session_id=?",
                (task_reference,),
            )
            if task:
                task_values = dict(task)
                payload = _json_object(task_values.get("payload_json"))
                _require_local_repo(
                    repo_root,
                    task_values.get("repo_id") or payload.get("repo_id"),
                    "task session",
                )
                values["task_session_id"] = str(task["task_session_id"])
                task_pack = task_values.get("pack_id") or payload.get("pack_id")
                values["pack_id"] = str(task_pack or "") or values.get("pack_id")
                if not explicit_operation_id:
                    values.pop("operation_id", None)
            elif values.get("task_session_id"):
                raise ValueError(f"task session not found: {task_reference}")
        agent_reference = values.get("agent_session_id") or reference
        if agent_reference:
            agent = _query_first(
                connections,
                "SELECT session_id,repo_id FROM agent_sessions WHERE session_id=?",
                (agent_reference,),
            )
            if agent:
                _require_local_repo(repo_root, agent["repo_id"], "agent session")
                values["agent_session_id"] = str(agent["session_id"])
                if not explicit_operation_id:
                    values.pop("operation_id", None)
            elif values.get("agent_session_id"):
                raise ValueError(f"agent session not found: {agent_reference}")
    finally:
        for connection in connections:
            connection.close()
    return ReportingReferences.model_validate(values)


def _candidate_connections(repo_root: Path) -> list[sqlite3.Connection]:
    state = resolve_project_state(repo_root, require_existing=True)
    paths: list[Path] = []
    for relative in (
        "stores/task/task-state.db",
        "stores/source/default/manifest.db",
        "stores/activity/active.db",
        "stores/audit/active.db",
        "stores/knowledge/knowledge.db",
        "stores/policy/policy.db",
        "stores/learning/learning.db",
    ):
        candidate = state / relative
        if candidate.exists():
            paths.append(candidate)
    result: list[sqlite3.Connection] = []
    for path in paths:
        uri = f"file:{path.resolve().as_posix()}?mode=ro"
        connection = sqlite3.connect(uri, uri=True, timeout=1.0)
        connection.row_factory = sqlite3.Row
        result.append(connection)
    return result


def _json_object(value: Any) -> dict[str, Any]:
    try:
        parsed = json.loads(str(value or "{}"))
    except (json.JSONDecodeError, TypeError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _nextgen_pack_manifest(
    repo_root: Path,
    connections: list[sqlite3.Connection],
    pack_id: str,
) -> dict[str, Any] | None:
    event = _query_first(
        connections,
        "SELECT payload_json FROM activity_events "
        "WHERE event_id=? AND event_type='context_pack.finalized'",
        (pack_id,),
    )
    if event is None:
        return None
    envelope = _json_object(event["payload_json"])
    persisted = envelope.get("payload")
    if not isinstance(persisted, dict):
        return None
    manifest = persisted.get("manifest")
    if isinstance(manifest, dict):
        return manifest
    reference = str(persisted.get("object_ref") or "")
    if not reference:
        return None
    try:
        from persistmind.storage.artifacts import ContentAddressedArtifacts

        raw = ContentAddressedArtifacts(
            resolve_project_state(repo_root, require_existing=True) / "objects",
            max_in_memory_bytes=_MAX_PACK_REFERENCE_BYTES,
        ).get(reference)
        parsed = json.loads(raw.decode("utf-8"))
    except (OSError, UnicodeDecodeError, ValueError, RuntimeError):
        return None
    return parsed if isinstance(parsed, dict) else None


def _require_local_repo(repo_root: Path, repo_id: Any, reference_kind: str) -> None:
    if repo_id in (None, ""):
        return
    local = stable_id(str(repo_root.resolve()))[:16]
    if str(repo_id) != local:
        raise ValueError(f"{reference_kind} belongs to a different repository")


def _query_first(
    connections: list[sqlite3.Connection], sql: str, parameters: tuple[Any, ...]
) -> sqlite3.Row | None:
    for connection in connections:
        try:
            row = connection.execute(sql, parameters).fetchone()
        except sqlite3.Error:
            continue
        if row is not None:
            return row
    return None


__all__ = ["resolve_reporting_references"]
