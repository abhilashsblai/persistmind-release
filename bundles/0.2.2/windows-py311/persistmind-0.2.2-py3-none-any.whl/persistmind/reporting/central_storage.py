from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from persistmind.branding import resolve_project_state
from persistmind.storage.descriptors import StoreRole
from persistmind.utils import canonical_json, stable_id, utc_now

from .contracts import CanonicalIssue, IncidentOccurrence
from .dedupe import FINGERPRINT_VERSION, canonical_fingerprint, component_for


class CentralTriageStore:
    def __init__(self, connection: Any, *, close_callback: Any = None) -> None:
        self.connection = connection
        self._close_callback = close_callback

    @classmethod
    def open(cls, repo_root: Path) -> "CentralTriageStore":
        state = resolve_project_state(repo_root, require_existing=True)
        if (state / "catalog" / "current.json").exists():
            from persistmind.storage.adapters.sqlite_learning import SQLiteLearningStore
            from persistmind.storage.runtime import StorageOpenIntent, StorageRuntime

            runtime = StorageRuntime.open(
                state,
                intent=StorageOpenIntent.REQUIRE_INITIALIZED,
                read_only=False,
                required_roles=frozenset({StoreRole.LEARNING}),
            )
            store = runtime.router.resolve_write_store(StoreRole.LEARNING)
            if not isinstance(store, SQLiteLearningStore):
                runtime.close()
                raise RuntimeError("collector learning route is not SQLite")
            return cls(store.connection, close_callback=runtime.close)
        raise RuntimeError("PersistMind storage is not initialized for central triage")

    def close(self) -> None:
        if self._close_callback:
            callback, self._close_callback = self._close_callback, None
            callback()

    def __enter__(self) -> "CentralTriageStore":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def begin_ingest(self, digest: str, source: str) -> tuple[str, bool]:
        row = self.connection.execute(
            "SELECT ingest_run_id,state FROM feedback_ingest_runs WHERE package_digest=?", (digest,)
        ).fetchone()
        if row:
            return str(row["ingest_run_id"]), True
        ingest_id = "PM-ING-" + stable_id(digest, source)[:24]
        with self.connection:
            self.connection.execute(
                "INSERT INTO feedback_ingest_runs(ingest_run_id,source,package_digest,"
                "validator_version,state,created_at) VALUES(?,?,?,?,?,?)",
                (
                    ingest_id,
                    source,
                    digest,
                    "persistmind.collector_validator.v1",
                    "received",
                    utc_now(),
                ),
            )
        return ingest_id, False

    def finish_ingest(
        self,
        ingest_id: str,
        *,
        state: str,
        occurrence_id: str | None,
        artifact_ref: str | None,
        reason: str | None = None,
        counts: dict[str, Any] | None = None,
    ) -> None:
        with self.connection:
            self.connection.execute(
                "UPDATE feedback_ingest_runs SET state=?,occurrence_id=?,artifact_ref=?,"
                "reason=?,counts_json=?,completed_at=? WHERE ingest_run_id=?",
                (
                    state,
                    occurrence_id,
                    artifact_ref,
                    reason,
                    canonical_json(counts or {}),
                    utc_now(),
                    ingest_id,
                ),
            )

    def propose_issue(self, occurrence: IncidentOccurrence) -> dict[str, Any]:
        fingerprint = canonical_fingerprint(occurrence)
        row = self.connection.execute(
            "SELECT * FROM canonical_issues WHERE normalized_fingerprint=? AND fingerprint_version=?",
            (fingerprint, FINGERPRINT_VERSION),
        ).fetchone()
        now = utc_now()
        now_datetime = datetime.now(timezone.utc)
        created = row is None
        if created:
            issue_id = "PM-BUG-" + stable_id(fingerprint)[:16].upper()
            issue = CanonicalIssue(
                canonical_issue_id=issue_id,
                component=component_for(occurrence),
                normalized_fingerprint=fingerprint,
                fingerprint_version=FINGERPRINT_VERSION,
                severity=occurrence.classification.severity,
                first_seen_release=occurrence.persistmind.version,
                last_seen_release=occurrence.persistmind.version,
                created_at=now_datetime,
                updated_at=now_datetime,
            )
            with self.connection:
                self.connection.execute(
                    "INSERT INTO canonical_issues VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                    (
                        issue.canonical_issue_id,
                        issue.component,
                        issue.normalized_fingerprint,
                        issue.fingerprint_version,
                        issue.severity.value,
                        issue.status,
                        issue.first_seen_release,
                        issue.last_seen_release,
                        "{}",
                        "{}",
                        now,
                        now,
                    ),
                )
            row = self.connection.execute(
                "SELECT * FROM canonical_issues WHERE canonical_issue_id=?", (issue_id,)
            ).fetchone()
        issue_id = str(row["canonical_issue_id"])
        regression = _regression_candidate(dict(row), occurrence) if not created else None
        with self.connection:
            self.connection.execute(
                "INSERT OR IGNORE INTO canonical_issue_occurrences("
                "canonical_issue_id,occurrence_id,match_method,confidence,decision,active,audit_json"
                ") VALUES(?,?,?,?,?,?,?)",
                (issue_id, occurrence.occurrence_id, "exact_fingerprint", 1.0, "proposed", 1, "{}"),
            )
            self.connection.execute(
                "UPDATE canonical_issues SET last_seen_release=?,regression_json=?,updated_at=? "
                "WHERE canonical_issue_id=?",
                (
                    occurrence.persistmind.version,
                    canonical_json(regression or _json_object(row["regression_json"])),
                    now,
                    issue_id,
                ),
            )
        return {
            "canonical_issue_id": issue_id,
            "match_method": "exact_fingerprint",
            "decision": "proposed",
            "component": component_for(occurrence),
            "regression_candidate": regression,
            "advisory_candidates": [] if not created else self.advisory_candidates(occurrence),
        }

    def advisory_candidates(self, occurrence: IncidentOccurrence) -> list[dict[str, Any]]:
        component = component_for(occurrence)
        candidates: list[dict[str, Any]] = []
        for row in self.connection.execute(
            "SELECT canonical_issue_id,component,severity,status,normalized_fingerprint "
            "FROM canonical_issues ORDER BY updated_at DESC LIMIT 200"
        ).fetchall():
            if str(row["normalized_fingerprint"]) == canonical_fingerprint(occurrence):
                continue
            score = 0.0
            reasons: list[str] = []
            if str(row["component"]) == component:
                score += 0.7
                reasons.append("same_component")
            if str(row["severity"]) == occurrence.classification.severity.value:
                score += 0.1
                reasons.append("same_severity")
            if score >= 0.7:
                candidates.append(
                    {
                        "canonical_issue_id": str(row["canonical_issue_id"]),
                        "score": round(score, 3),
                        "reasons": reasons,
                        "advisory_only": True,
                    }
                )
        return sorted(candidates, key=lambda item: (-item["score"], item["canonical_issue_id"]))[:5]

    def decide_link(
        self, issue_id: str, occurrence_id: str, *, decision: str, reviewer: str
    ) -> dict[str, Any]:
        if decision not in {"accepted", "rejected", "split"}:
            raise ValueError("link decision must be accepted, rejected, or split")
        if not reviewer.strip():
            raise ValueError("reviewer is required")
        row = self.connection.execute(
            "SELECT * FROM canonical_issue_occurrences WHERE canonical_issue_id=? AND occurrence_id=?",
            (issue_id, occurrence_id),
        ).fetchone()
        if row is None:
            raise KeyError("canonical occurrence link not found")
        now = utc_now()
        with self.connection:
            self.connection.execute(
                "UPDATE canonical_issue_occurrences SET decision=?,reviewer=?,decided_at=?,active=?,"
                "audit_json=? WHERE canonical_issue_id=? AND occurrence_id=?",
                (
                    decision,
                    reviewer,
                    now,
                    int(decision == "accepted"),
                    canonical_json(
                        {"previous": dict(row), "decision": decision, "reviewer": reviewer}
                    ),
                    issue_id,
                    occurrence_id,
                ),
            )
            if decision == "accepted":
                issue = self.connection.execute(
                    "SELECT status,regression_json FROM canonical_issues WHERE canonical_issue_id=?",
                    (issue_id,),
                ).fetchone()
                regression = _json_object(issue["regression_json"]) if issue else {}
                is_regression = (
                    regression.get("state") == "candidate"
                    and regression.get("occurrence_id") == occurrence_id
                )
                if is_regression:
                    regression.update(
                        {"state": "accepted", "reviewer": reviewer, "reviewed_at": now}
                    )
                self.connection.execute(
                    "UPDATE canonical_issues SET status=CASE "
                    "WHEN ? THEN 'regressed' WHEN status='candidate' THEN 'confirmed' ELSE status END,"
                    "regression_json=?,updated_at=? WHERE canonical_issue_id=?",
                    (int(is_regression), canonical_json(regression), now, issue_id),
                )
        return {
            "canonical_issue_id": issue_id,
            "occurrence_id": occurrence_id,
            "decision": decision,
            "reviewer": reviewer,
            "reversible": True,
        }

    def analytics(self, *, filters: dict[str, str] | None = None) -> dict[str, Any]:
        selected = {key: value for key, value in (filters or {}).items() if value}
        states = [
            dict(row)
            for row in self.connection.execute(
                "SELECT state,COUNT(*) count FROM feedback_ingest_runs GROUP BY state ORDER BY state"
            ).fetchall()
        ]
        issues = [
            dict(row)
            for row in self.connection.execute(
                "SELECT i.canonical_issue_id,i.component,i.severity,i.status,"
                "COUNT(CASE WHEN l.decision='accepted' AND l.active=1 THEN 1 END) accepted_occurrences,"
                "COUNT(l.occurrence_id) total_candidates FROM canonical_issues i "
                "LEFT JOIN canonical_issue_occurrences l ON l.canonical_issue_id=i.canonical_issue_id "
                "GROUP BY i.canonical_issue_id ORDER BY accepted_occurrences DESC,i.canonical_issue_id"
            ).fetchall()
        ]
        total = sum(int(row["count"]) for row in states)
        metadata = [
            _json_object(row["counts_json"])
            for row in self.connection.execute(
                "SELECT counts_json FROM feedback_ingest_runs WHERE state='accepted'"
            ).fetchall()
        ]
        filtered = [
            item
            for item in metadata
            if all(str(item.get(key) or "unknown") == value for key, value in selected.items())
        ]
        return {
            "schema_version": "persistmind.reporting_analytics.v1",
            "submitted_packages": total,
            "ingest_states": states,
            "canonical_issues": issues,
            "filters": selected,
            "accepted_sample_size": len(filtered),
            "dimensions": {
                key: _dimension(filtered, key)
                for key in ("version", "component", "platform", "severity")
            },
            "impact": {
                "incorrect_code_true": sum(item.get("incorrect_code") is True for item in filtered),
                "incorrect_code_unknown": sum(
                    item.get("incorrect_code") is None for item in filtered
                ),
                "rework_minutes_total": sum(
                    int(item.get("rework_minutes") or 0) for item in filtered
                ),
                "rework_minutes_unknown": sum(
                    item.get("rework_minutes") is None for item in filtered
                ),
            },
            "regression_candidates": sum(
                _json_object(row["regression_json"]).get("state") == "candidate"
                for row in self.connection.execute(
                    "SELECT regression_json FROM canonical_issues"
                ).fetchall()
            ),
            "coverage_notice": "Metrics describe voluntarily submitted packages only.",
            "unknown_counts_included": True,
        }


def _regression_candidate(
    issue: dict[str, Any], occurrence: IncidentOccurrence
) -> dict[str, Any] | None:
    release = occurrence.persistmind.version
    if issue.get("status") not in {"resolved", "closed"}:
        return None
    if not release or release == issue.get("last_seen_release"):
        return None
    return {
        "state": "candidate",
        "occurrence_id": occurrence.occurrence_id,
        "release": release,
        "previous_status": issue["status"],
        "detected_at": utc_now(),
        "requires_review": True,
    }


def _json_object(value: Any) -> dict[str, Any]:
    try:
        parsed = json.loads(str(value or "{}"))
    except (json.JSONDecodeError, TypeError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _dimension(rows: list[dict[str, Any]], key: str) -> list[dict[str, Any]]:
    counts: dict[str, int] = {}
    for row in rows:
        value = str(row.get(key) or "unknown")
        counts[value] = counts.get(value, 0) + 1
    return [
        {"value": value, "count": count}
        for value, count in sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    ]


__all__ = ["CentralTriageStore"]
