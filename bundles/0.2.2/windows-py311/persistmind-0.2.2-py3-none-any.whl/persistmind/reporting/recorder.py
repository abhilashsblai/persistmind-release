from __future__ import annotations

import hashlib
import subprocess
import time
from contextlib import contextmanager
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from persistmind.config import Settings, load_settings
from persistmind.release_identity import public_release_identity
from persistmind.repo_identity import RepoIdentityError, canonical_repo_hash
from persistmind.storage.workspace_lock import WorkspaceBusy, WorkspaceRuntimeLock
from persistmind.utils import canonical_json, stable_id

from .contracts import (
    Classification,
    Evidence,
    Impact,
    IncidentOccurrence,
    OccurrenceKind,
    OccurrenceSource,
    PrivacyDeclaration,
    ProjectReference,
    ReleaseReference,
    ReportingReferences,
    Reproducibility,
    Reproduction,
    Severity,
)
from .storage import SQLiteReportingIndex
from .taxonomy import cie_domain_for
from .workspace import IncidentWorkspace, new_occurrence_id


class IncidentRecorder:
    def __init__(
        self,
        repo_root: Path,
        *,
        workspace: IncidentWorkspace,
        index: SQLiteReportingIndex,
        settings: Settings | None = None,
    ) -> None:
        self.repo_root = repo_root.resolve()
        self.workspace = workspace
        self.index = index
        self.settings = settings or load_settings(self.repo_root)

    def create(
        self,
        *,
        kind: OccurrenceKind = OccurrenceKind.INCIDENT,
        category: str,
        severity: Severity,
        summary: str,
        source: OccurrenceSource = OccurrenceSource.USER_REPORTED,
        expected_behavior: str | None = None,
        actual_behavior: str | None = None,
        references: ReportingReferences | None = None,
        reproducibility: Reproducibility = Reproducibility.UNKNOWN,
        steps: list[str] | None = None,
        affected_files: list[str] | None = None,
        affected_symbols: list[str] | None = None,
        exception_type: str | None = None,
        exception_message: str | None = None,
        stack_trace: str | None = None,
        impact: Impact | None = None,
        suspected_cause: str | None = None,
        workaround: str | None = None,
        rating: int | None = None,
        feedback_reason: str | None = None,
        labels: list[str] | None = None,
        automatic_trigger: str | None = None,
    ) -> IncidentOccurrence:
        config = self.settings.reporting
        if not config.enabled:
            raise PermissionError("reporting is disabled by configuration")
        if len(summary) > config.max_summary_chars:
            raise ValueError("summary exceeds reporting.max_summary_chars")
        now = datetime.now(UTC)
        refs = references or ReportingReferences()
        fingerprint = error_fingerprint(
            category=category,
            exception_type=exception_type,
            exception_message=exception_message,
            operation_type=refs.operation_type,
        )
        automatic_identity: tuple[str, str, str] | None = None
        if source is OccurrenceSource.AUTOMATIC:
            operation_id = refs.operation_id or ""
            if not operation_id or not automatic_trigger:
                raise ValueError("automatic reports require operation_id and automatic_trigger")
            automatic_identity = (operation_id, automatic_trigger, fingerprint)
        occurrence_values: dict[str, Any] = dict(
            kind=kind,
            created_at=now,
            created_at_utc=now,
            source=source,
            project=_project_reference(self.repo_root),
            persistmind=_release_reference(self.settings),
            classification=Classification(
                category=category,
                cie_domain=cie_domain_for(category),
                severity=severity,
                reproducibility=reproducibility,
            ),
            summary=summary,
            expected_behavior=expected_behavior,
            actual_behavior=actual_behavior,
            references=refs,
            evidence=Evidence(
                affected_files=affected_files or [],
                affected_symbols=affected_symbols or [],
                error_fingerprint=fingerprint,
                exception_type=exception_type,
                exception_message=exception_message,
                stack_trace=stack_trace,
            ),
            impact=impact or Impact(),
            reproduction=Reproduction(steps=steps or []),
            suspected_cause=suspected_cause,
            workaround=workaround,
            rating=rating,
            feedback_reason=feedback_reason,
            labels=labels or [],
            privacy=PrivacyDeclaration(),
            automatic_trigger=automatic_trigger,
        )
        if automatic_identity is not None:
            with _automatic_capture_lock(self.repo_root, automatic_identity):
                existing = self.index.find_automatic(*automatic_identity)
                if existing:
                    self.index.increment_automatic(*automatic_identity)
                    return self.workspace.load(str(existing["occurrence_id"])).occurrence
                occurrence = self._publish(kind, now, occurrence_values)
                self.index.increment_automatic(*automatic_identity)
                return occurrence
        return self._publish(kind, now, occurrence_values)

    def _publish(
        self,
        kind: OccurrenceKind,
        now: datetime,
        occurrence_values: dict[str, Any],
    ) -> IncidentOccurrence:
        for _attempt in range(8):
            occurrence = IncidentOccurrence(
                occurrence_id=new_occurrence_id(kind, now), **occurrence_values
            )
            try:
                published = self.workspace.publish(occurrence)
                break
            except FileExistsError:
                continue
        else:
            raise RuntimeError("could not allocate a unique occurrence ID")
        self.index.index_occurrence(published)
        return occurrence


@contextmanager
def _automatic_capture_lock(repo_root: Path, identity: tuple[str, str, str]) -> Any:
    lock_root = repo_root / ".persistmind" / "reporting-capture" / stable_id(*identity)
    lock = WorkspaceRuntimeLock(lock_root, exclusive=True)
    delays = (0.0, 0.01, 0.025, 0.05, 0.1, 0.2)
    for attempt, delay in enumerate(delays):
        if delay:
            time.sleep(delay)
        try:
            lock.acquire()
            break
        except WorkspaceBusy:
            if attempt == len(delays) - 1:
                raise RuntimeError("automatic incident capture is busy; retry the operation")
    try:
        yield
    finally:
        lock.close()


def error_fingerprint(
    *,
    category: str,
    exception_type: str | None,
    exception_message: str | None,
    operation_type: str | None,
) -> str:
    normalized_message = " ".join((exception_message or "").casefold().split())[:512]
    digest = stable_id(
        "persistmind.error_fingerprint.v1",
        category,
        exception_type or "",
        normalized_message,
        operation_type or "",
    )
    return f"pmfp-v1:{digest}"


def _project_reference(repo_root: Path) -> ProjectReference:
    try:
        repo_hash = canonical_repo_hash(repo_root)
    except RepoIdentityError:
        repo_hash = hashlib.sha256(str(repo_root).encode("utf-8")).hexdigest()
    branch = _git_value(repo_root, "rev-parse", "--abbrev-ref", "HEAD")
    commit = _git_value(repo_root, "rev-parse", "HEAD")
    return ProjectReference(
        repo_id=f"repo-{repo_hash[:32]}",
        workspace_id=f"workspace-{stable_id(repo_hash, str(repo_root))[:32]}",
        branch=branch,
        commit_sha=commit,
        repository_name=repo_root.name,
        repository_remote=_git_value(repo_root, "remote", "get-url", "origin"),
    )


def _release_reference(settings: Settings) -> ReleaseReference:
    identity = public_release_identity()
    config_payload = asdict(settings)
    reporting = config_payload.get("reporting") or {}
    reporting.pop("collector_url", None)
    reporting.pop("collector_token_key", None)
    return ReleaseReference(
        version=str(identity.get("version") or "unknown"),
        runtime_profile=str(identity.get("runtime_profile") or "unknown"),
        source_commit=str(identity.get("source_commit") or "") or None,
        build_timestamp=str(identity.get("build_timestamp") or "") or None,
        configuration_hash="sha256:"
        + hashlib.sha256(canonical_json(config_payload).encode("utf-8")).hexdigest(),
    )


def _git_value(repo_root: Path, *arguments: str) -> str | None:
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_root), *arguments],
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=3,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    value = result.stdout.strip()
    return value if result.returncode == 0 and value else None


__all__ = ["IncidentRecorder", "error_fingerprint"]
