from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .taxonomy import CATEGORIES, cie_domain_for

INCIDENT_SCHEMA = "persistmind.incident_occurrence.v1"
DIAGNOSTICS_SCHEMA = "persistmind.diagnostics_bundle.v1"
EXPORT_SCHEMA = "persistmind.incident_export_manifest.v1"
RECEIPT_SCHEMA = "persistmind.incident_submission_receipt.v1"
CANONICAL_ISSUE_SCHEMA = "persistmind.canonical_issue.v1"

BoundedText = Annotated[str, Field(min_length=1, max_length=16_000)]


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)


class OccurrenceKind(str, Enum):
    INCIDENT = "incident"
    FEEDBACK = "feedback"


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFORMATIONAL = "informational"


class OccurrenceSource(str, Enum):
    AUTOMATIC = "automatic"
    USER_REPORTED = "user_reported"
    AGENT_REPORTED = "agent_reported"
    IMPORTED = "imported"
    COLLECTOR = "collector"


class LocalStatus(str, Enum):
    NEW = "new"
    REVIEWED = "reviewed"
    EXPORTED = "exported"
    SUBMITTED = "submitted"
    CLOSED = "closed"


class Reproducibility(str, Enum):
    ALWAYS = "always"
    INTERMITTENT = "intermittent"
    ONCE = "once"
    UNKNOWN = "unknown"
    NOT_APPLICABLE = "not_applicable"


class ProjectReference(StrictModel):
    repo_id: str = Field(min_length=8, max_length=128)
    workspace_id: str = Field(min_length=8, max_length=128)
    branch: str | None = Field(default=None, max_length=512)
    commit_sha: str | None = Field(default=None, max_length=128)
    repository_name: str | None = Field(default=None, max_length=512)
    repository_remote: str | None = Field(default=None, max_length=2_048)


class ReleaseReference(StrictModel):
    version: str
    runtime_profile: str | None = None
    source_commit: str | None = None
    build_timestamp: str | None = None
    configuration_hash: str


class Classification(StrictModel):
    category: str
    cie_domain: str
    subcategory: str | None = Field(default=None, max_length=128)
    severity: Severity
    reproducibility: Reproducibility = Reproducibility.UNKNOWN

    @field_validator("category")
    @classmethod
    def category_is_controlled(cls, value: str) -> str:
        if value not in CATEGORIES:
            raise ValueError(f"unknown incident category: {value}")
        return value

    @model_validator(mode="after")
    def mapped_domain_matches(self) -> Classification:
        expected = cie_domain_for(self.category)
        if self.cie_domain != expected:
            raise ValueError(
                f"cie_domain {self.cie_domain!r} does not match {self.category!r}: {expected!r}"
            )
        return self


class ReportingReferences(StrictModel):
    operation_id: str | None = None
    correlation_id: str | None = None
    task_session_id: str | None = None
    agent_session_id: str | None = None
    pack_id: str | None = None
    snapshot_id: str | None = None
    generation_id: str | None = None
    verification_id: str | None = None
    outcome_id: str | None = None
    surface: str | None = None
    agent: str | None = None
    model: str | None = None
    operation_type: str | None = None
    query_digest: str | None = None


class Evidence(StrictModel):
    affected_files: list[str] = Field(default_factory=list, max_length=128)
    affected_symbols: list[str] = Field(default_factory=list, max_length=128)
    diagnostic_refs: list[str] = Field(default_factory=list, max_length=32)
    error_fingerprint: str | None = None
    fingerprint_version: str = "persistmind.error_fingerprint.v1"
    exception_type: str | None = None
    exception_message: str | None = Field(default=None, max_length=4_000)
    stack_trace: str | None = Field(default=None, max_length=16_000)


class Impact(StrictModel):
    task_blocked: bool | None = None
    incorrect_code_generated: bool | None = None
    manual_rework_required: bool | None = None
    estimated_rework_minutes: int | None = Field(default=None, ge=0, le=100_000)
    data_loss: bool | None = None
    security_impact: bool | None = None


class Reproduction(StrictModel):
    steps: list[str] = Field(default_factory=list, max_length=32)
    external_reference: str | None = Field(default=None, max_length=2_048)

    @field_validator("steps")
    @classmethod
    def bounded_steps(cls, values: list[str]) -> list[str]:
        if any(not value.strip() or len(value) > 2_000 for value in values):
            raise ValueError("reproduction steps must be non-empty and <= 2000 characters")
        return values


class PrivacyDeclaration(StrictModel):
    contains_source_code: bool = False
    contains_personal_data: bool = False
    contains_secrets: bool = False
    contains_paths: bool = False
    sanitised: bool = False
    export_blocked: bool = False
    findings: list[str] = Field(default_factory=list, max_length=64)
    scanner_version: str = "persistmind.privacy_scan.v1"


class IncidentOccurrence(StrictModel):
    schema_version: Literal["persistmind.incident_occurrence.v1"] = (
        "persistmind.incident_occurrence.v1"
    )
    occurrence_id: str = Field(pattern=r"^PM-(?:INC|FBK)-\d{8}-\d{6}-[0-9a-f]{8}$")
    kind: OccurrenceKind
    created_at: datetime
    created_at_utc: datetime
    revision: int = Field(default=1, ge=1)
    source: OccurrenceSource
    status: LocalStatus = LocalStatus.NEW
    project: ProjectReference
    persistmind: ReleaseReference
    classification: Classification
    summary: str = Field(min_length=1, max_length=4_000)
    expected_behavior: str | None = Field(default=None, max_length=16_000)
    actual_behavior: str | None = Field(default=None, max_length=16_000)
    references: ReportingReferences = Field(default_factory=ReportingReferences)
    evidence: Evidence = Field(default_factory=Evidence)
    impact: Impact = Field(default_factory=Impact)
    reproduction: Reproduction = Field(default_factory=Reproduction)
    suspected_cause: str | None = Field(default=None, max_length=8_000)
    workaround: str | None = Field(default=None, max_length=8_000)
    rating: int | None = Field(default=None, ge=1, le=5)
    feedback_reason: str | None = Field(default=None, max_length=128)
    labels: list[str] = Field(default_factory=list, max_length=32)
    privacy: PrivacyDeclaration = Field(default_factory=PrivacyDeclaration)
    automatic_trigger: str | None = None

    @model_validator(mode="after")
    def kind_constraints(self) -> IncidentOccurrence:
        prefix = "PM-FBK-" if self.kind is OccurrenceKind.FEEDBACK else "PM-INC-"
        if not self.occurrence_id.startswith(prefix):
            raise ValueError("occurrence ID prefix does not match kind")
        if self.kind is OccurrenceKind.FEEDBACK and self.rating is None:
            raise ValueError("feedback requires a rating")
        if self.kind is OccurrenceKind.INCIDENT and self.rating is not None:
            raise ValueError("incident cannot carry a feedback rating")
        return self


class DiagnosticBundle(StrictModel):
    schema_version: Literal["persistmind.diagnostics_bundle.v1"] = (
        "persistmind.diagnostics_bundle.v1"
    )
    diagnostic_id: str
    occurrence_id: str
    created_at: datetime
    collectors: dict[str, Any]
    failures: dict[str, str] = Field(default_factory=dict)
    classification: Literal["summary_only", "internal"] = "summary_only"


class ExportEntry(StrictModel):
    path: str
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    size: int = Field(ge=0)
    media_type: str
    classification: str


class ExportManifest(StrictModel):
    schema_version: Literal["persistmind.incident_export_manifest.v1"] = (
        "persistmind.incident_export_manifest.v1"
    )
    export_id: str
    occurrence_id: str
    created_at: datetime
    reviewer: str
    sanitizer_version: str
    source_digest: str
    sanitized_digest: str
    privacy_verdict: Literal["pass", "warning", "blocked"]
    warnings_acknowledged: bool = False
    entries: list[ExportEntry]


class SubmissionReceipt(StrictModel):
    schema_version: Literal["persistmind.incident_submission_receipt.v1"] = (
        "persistmind.incident_submission_receipt.v1"
    )
    receipt_id: str
    export_id: str
    package_digest: str
    collector: str
    submitted_at: datetime
    status: Literal["accepted", "duplicate", "rejected"]
    remote_occurrence_id: str | None = None


class CanonicalIssue(StrictModel):
    schema_version: Literal["persistmind.canonical_issue.v1"] = "persistmind.canonical_issue.v1"
    canonical_issue_id: str
    component: str
    normalized_fingerprint: str
    fingerprint_version: str
    severity: Severity
    status: Literal[
        "candidate", "confirmed", "investigating", "resolved", "regressed", "closed"
    ] = "candidate"
    first_seen_release: str | None = None
    last_seen_release: str | None = None
    created_at: datetime
    updated_at: datetime


__all__ = [
    "CANONICAL_ISSUE_SCHEMA",
    "DIAGNOSTICS_SCHEMA",
    "EXPORT_SCHEMA",
    "INCIDENT_SCHEMA",
    "RECEIPT_SCHEMA",
    "CanonicalIssue",
    "Classification",
    "DiagnosticBundle",
    "Evidence",
    "ExportEntry",
    "ExportManifest",
    "Impact",
    "IncidentOccurrence",
    "LocalStatus",
    "OccurrenceKind",
    "OccurrenceSource",
    "PrivacyDeclaration",
    "ProjectReference",
    "ReleaseReference",
    "ReportingReferences",
    "Reproducibility",
    "Reproduction",
    "Severity",
    "SubmissionReceipt",
]
