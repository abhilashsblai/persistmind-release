from __future__ import annotations

import copy
import hashlib
import re
from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Any

from persistmind.security.redaction import redact_with_summary

from .contracts import IncidentOccurrence, PrivacyDeclaration
from .workspace import canonical_json_bytes, sha256_bytes

SANITIZER_VERSION = "persistmind.reporting_sanitizer.v1"
_ABSOLUTE_WINDOWS = re.compile(r"^[A-Za-z]:[\\/]")
_PRIVATE_KEY = re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")
_SOURCE_LIKE = re.compile(
    r"(?:^|\n)\s*(?:def |class |function |import |from |const |let |var |#include|package )",
    re.MULTILINE,
)
_INJECTION = re.compile(
    r"(?:ignore (?:all |the )?previous instructions|system prompt|developer message)", re.IGNORECASE
)
_STRUCTURAL_KEYS = {
    "schema_version",
    "occurrence_id",
    "kind",
    "created_at",
    "created_at_utc",
    "source",
    "status",
    "repo_id",
    "workspace_id",
    "version",
    "runtime_profile",
    "source_commit",
    "build_timestamp",
    "configuration_hash",
    "category",
    "cie_domain",
    "severity",
    "reproducibility",
    "operation_id",
    "correlation_id",
    "task_session_id",
    "agent_session_id",
    "pack_id",
    "snapshot_id",
    "generation_id",
    "verification_id",
    "outcome_id",
    "query_digest",
    "error_fingerprint",
    "fingerprint_version",
    "scanner_version",
    "automatic_trigger",
}


@dataclass(frozen=True)
class SanitizationResult:
    occurrence: IncidentOccurrence
    source_digest: str
    sanitized_digest: str
    verdict: str
    findings: tuple[str, ...]
    counts: dict[str, int]


def sanitize_occurrence(occurrence: IncidentOccurrence) -> SanitizationResult:
    source_payload = canonical_json_bytes(occurrence)
    document = copy.deepcopy(occurrence.model_dump(mode="json", exclude_none=True))
    project = document["project"]
    salt = hashlib.sha256(occurrence.occurrence_id.encode("ascii")).hexdigest()
    project["repo_id"] = "repo-" + _pseudonym(salt, project["repo_id"])
    project["workspace_id"] = "workspace-" + _pseudonym(salt, project["workspace_id"])
    project.pop("repository_name", None)
    project.pop("repository_remote", None)
    project.pop("branch", None)
    findings: set[str] = set()
    counts = {"redacted": 0, "paths_hashed": 0, "source_like": 0, "injection": 0}
    document = _sanitize_value(document, salt=salt, findings=findings, counts=counts)
    evidence = document.get("evidence") or {}
    paths: list[str] = []
    for value in evidence.get("affected_files") or []:
        normalized = _safe_relative_path(str(value))
        if normalized is None:
            paths.append("path-sha256:" + _pseudonym(salt, str(value)))
            counts["paths_hashed"] += 1
            findings.add("path_pseudonymized")
        else:
            paths.append(normalized)
    evidence["affected_files"] = paths
    privacy = document.setdefault("privacy", {})
    privacy.update(
        PrivacyDeclaration(
            contains_source_code="source_like_content" in findings,
            contains_personal_data="pii_redacted" in findings,
            contains_secrets="secret_redacted" in findings or "private_key" in findings,
            contains_paths=bool(counts["paths_hashed"]),
            sanitised=True,
            export_blocked="private_key" in findings,
            findings=sorted(findings),
        ).model_dump(mode="json")
    )
    sanitized = IncidentOccurrence.model_validate(document)
    payload = canonical_json_bytes(sanitized)
    verdict = "blocked" if privacy["export_blocked"] else "warning" if findings else "pass"
    return SanitizationResult(
        occurrence=sanitized,
        source_digest=sha256_bytes(source_payload),
        sanitized_digest=sha256_bytes(payload),
        verdict=verdict,
        findings=tuple(sorted(findings)),
        counts=counts,
    )


def scan_export_document(document: dict[str, Any]) -> tuple[str, tuple[str, ...]]:
    findings: set[str] = set()
    for field_name, value in _string_fields(document):
        if field_name in _STRUCTURAL_KEYS:
            continue
        if _PRIVATE_KEY.search(value):
            findings.add("private_key")
        _, summary = redact_with_summary(value)
        if int(summary.get("secret_count", 0)):
            findings.add("secret")
        if int(summary.get("pii_count", 0)):
            findings.add("pii")
    return ("blocked" if findings else "pass", tuple(sorted(findings)))


def _string_fields(value: Any, field_name: str | None = None) -> list[tuple[str | None, str]]:
    if isinstance(value, dict):
        return [item for key, nested in value.items() for item in _string_fields(nested, str(key))]
    if isinstance(value, list):
        return [item for nested in value for item in _string_fields(nested, field_name)]
    return [(field_name, value)] if isinstance(value, str) else []


def _sanitize_value(
    value: Any,
    *,
    salt: str,
    findings: set[str],
    counts: dict[str, int],
    field_name: str | None = None,
) -> Any:
    if isinstance(value, dict):
        return {
            str(key): _sanitize_value(
                item,
                salt=salt,
                findings=findings,
                counts=counts,
                field_name=str(key),
            )
            for key, item in value.items()
            if str(key).casefold() not in {"query", "prompt", "model_response", "source_code"}
        }
    if isinstance(value, list):
        return [
            _sanitize_value(
                item,
                salt=salt,
                findings=findings,
                counts=counts,
                field_name=field_name,
            )
            for item in value
        ]
    if not isinstance(value, str):
        return value
    if field_name in _STRUCTURAL_KEYS:
        return value
    if _PRIVATE_KEY.search(value):
        findings.add("private_key")
    if _SOURCE_LIKE.search(value) and len(value) > 160:
        findings.add("source_like_content")
        counts["source_like"] += 1
        value = "[REDACTED_SOURCE_LIKE_CONTENT]"
    if _INJECTION.search(value):
        findings.add("instruction_like_content")
        counts["injection"] += 1
    redacted, summary = redact_with_summary(value)
    if int(summary.get("pii_count", 0)):
        findings.add("pii_redacted")
    if int(summary.get("secret_count", 0)):
        findings.add("secret_redacted")
    counts["redacted"] += int(summary.get("redacted_count", 0))
    return redacted


def _safe_relative_path(value: str) -> str | None:
    normalized = value.replace("\\", "/")
    path = PurePosixPath(normalized)
    if (
        not normalized
        or normalized.startswith("/")
        or _ABSOLUTE_WINDOWS.match(value)
        or ".." in path.parts
        or any(part in {"", "."} for part in path.parts)
    ):
        return None
    return path.as_posix()


def _pseudonym(salt: str, value: str) -> str:
    return hashlib.sha256(f"{salt}\0{value}".encode()).hexdigest()[:32]


__all__ = [
    "SANITIZER_VERSION",
    "SanitizationResult",
    "sanitize_occurrence",
    "scan_export_document",
]
