from __future__ import annotations

import json
from importlib import resources
from typing import Any

from pydantic import BaseModel, ValidationError

from .contracts import (
    CANONICAL_ISSUE_SCHEMA,
    DIAGNOSTICS_SCHEMA,
    EXPORT_SCHEMA,
    INCIDENT_SCHEMA,
    RECEIPT_SCHEMA,
    CanonicalIssue,
    DiagnosticBundle,
    ExportManifest,
    IncidentOccurrence,
    SubmissionReceipt,
)

_MODELS: dict[str, type[BaseModel]] = {
    INCIDENT_SCHEMA: IncidentOccurrence,
    DIAGNOSTICS_SCHEMA: DiagnosticBundle,
    EXPORT_SCHEMA: ExportManifest,
    RECEIPT_SCHEMA: SubmissionReceipt,
    CANONICAL_ISSUE_SCHEMA: CanonicalIssue,
}


def validate_document(document: dict[str, Any]) -> Any:
    schema_version = str(document.get("schema_version") or "")
    model = _MODELS.get(schema_version)
    if model is None:
        raise ValueError(f"unsupported reporting schema_version: {schema_version!r}")
    return model.model_validate(document)


def validation_result(document: dict[str, Any]) -> dict[str, Any]:
    try:
        validated = validate_document(document)
    except (ValidationError, ValueError) as exc:
        errors: list[dict[str, Any]] = (
            [dict(item) for item in exc.errors()]
            if isinstance(exc, ValidationError)
            else [{"msg": str(exc)}]
        )
        return {"ok": False, "status": "validation_failed", "errors": errors}
    return {
        "ok": True,
        "status": "valid",
        "schema_version": validated.schema_version,
    }


def schema_document(schema_version: str) -> dict[str, Any]:
    model = _MODELS.get(schema_version)
    if model is None:
        raise ValueError(f"unsupported reporting schema_version: {schema_version!r}")
    return model.model_json_schema()


def packaged_schema(schema_version: str) -> dict[str, Any]:
    name = schema_version.removeprefix("persistmind.").replace(".", "-") + ".json"
    content = (
        resources.files("persistmind.reporting.resources.schemas")
        .joinpath(name)
        .read_text(encoding="utf-8")
    )
    return json.loads(content)


__all__ = ["packaged_schema", "schema_document", "validate_document", "validation_result"]
