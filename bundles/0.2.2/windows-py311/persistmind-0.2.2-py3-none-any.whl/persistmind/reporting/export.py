from __future__ import annotations

import io
import os
import zipfile
from datetime import timezone
from pathlib import Path
from typing import Any, Literal, cast

from persistmind.config import ReportingConfig
from persistmind.utils import stable_id

from .contracts import DiagnosticBundle, ExportEntry, ExportManifest, IncidentOccurrence
from .sanitization import SANITIZER_VERSION, sanitize_occurrence
from .storage import SQLiteReportingIndex
from .workspace import IncidentWorkspace, canonical_json_bytes, sha256_bytes

_FIXED_ZIP_TIME = (1980, 1, 1, 0, 0, 0)


def export_occurrence(
    occurrence: IncidentOccurrence,
    *,
    workspace: IncidentWorkspace,
    index: SQLiteReportingIndex,
    config: ReportingConfig,
    reviewer: str,
    diagnostics: DiagnosticBundle | None = None,
    acknowledge_warnings: bool = False,
) -> dict[str, Any]:
    if not reviewer.strip() or len(reviewer) > 256:
        raise ValueError("a bounded reviewer identity is required")
    sanitized = sanitize_occurrence(occurrence)
    if sanitized.verdict == "blocked":
        raise PermissionError("export blocked by unresolved critical privacy findings")
    if sanitized.verdict == "warning" and not acknowledge_warnings:
        raise PermissionError("privacy warnings require --acknowledge-warnings")
    incident_bytes = canonical_json_bytes(sanitized.occurrence)
    summary_bytes = render_summary(sanitized.occurrence).encode("utf-8")
    reproduction_bytes = render_reproduction(sanitized.occurrence).encode("utf-8")
    diagnostics_bytes = canonical_json_bytes(
        diagnostics.model_dump(mode="json", exclude_none=True)
        if diagnostics
        else {
            "schema_version": "persistmind.diagnostics_bundle.v1",
            "diagnostic_id": "none",
            "occurrence_id": occurrence.occurrence_id,
            "created_at": occurrence.created_at_utc.isoformat(),
            "collectors": {},
            "failures": {},
            "classification": "summary_only",
        }
    )
    contents = {
        "incident.json": (incident_bytes, "application/json", "summary_only"),
        "summary.md": (summary_bytes, "text/markdown", "summary_only"),
        "diagnostics.json": (diagnostics_bytes, "application/json", "summary_only"),
        "reproduction.md": (reproduction_bytes, "text/markdown", "summary_only"),
    }
    entries = [
        ExportEntry(
            path=name,
            sha256=sha256_bytes(payload),
            size=len(payload),
            media_type=media_type,
            classification=classification,
        )
        for name, (payload, media_type, classification) in sorted(contents.items())
    ]
    export_id = (
        "PM-EXP-"
        + stable_id(
            occurrence.occurrence_id, sanitized.sanitized_digest, reviewer, SANITIZER_VERSION
        )[:24]
    )
    manifest = ExportManifest(
        export_id=export_id,
        occurrence_id=occurrence.occurrence_id,
        created_at=occurrence.created_at_utc.astimezone(timezone.utc),
        reviewer=reviewer,
        sanitizer_version=SANITIZER_VERSION,
        source_digest=sanitized.source_digest,
        sanitized_digest=sanitized.sanitized_digest,
        privacy_verdict=cast(Literal["pass", "warning", "blocked"], sanitized.verdict),
        warnings_acknowledged=acknowledge_warnings,
        entries=entries,
    )
    archive = _deterministic_zip(
        {"manifest.json": canonical_json_bytes(manifest), **{k: v[0] for k, v in contents.items()}}
    )
    if len(archive) > config.max_package_bytes:
        raise ValueError("export exceeds reporting.max_package_bytes")
    target = workspace.output_path("exports", f"{occurrence.occurrence_id}.zip")
    temporary = target.with_name(f".{target.name}.{os.getpid()}.tmp")
    temporary.write_bytes(archive)
    os.replace(temporary, target)
    digest = sha256_bytes(archive)
    index.record_export(manifest, target, digest, len(archive))
    return {
        "ok": True,
        "status": "exported",
        "export_id": export_id,
        "occurrence_id": occurrence.occurrence_id,
        "path": str(target),
        "package_digest": digest,
        "package_size": len(archive),
        "privacy_verdict": sanitized.verdict,
        "privacy_findings": list(sanitized.findings),
        "network_used": False,
    }


def inspect_package(path: Path, *, max_bytes: int = 8 * 1024 * 1024) -> dict[str, Any]:
    if not path.is_file() or path.stat().st_size > max_bytes:
        raise ValueError("package is missing or exceeds the configured size limit")
    raw = path.read_bytes()
    names: set[str] = set()
    contents: dict[str, bytes] = {}
    with zipfile.ZipFile(io.BytesIO(raw), "r") as archive:
        if len(archive.infolist()) > 64:
            raise ValueError("archive contains too many entries")
        total = 0
        for info in archive.infolist():
            normalized = info.filename.replace("\\", "/")
            parts = normalized.split("/")
            if (
                normalized.startswith("/")
                or ".." in parts
                or normalized in names
                or info.is_dir()
                or (info.external_attr >> 16) & 0o170000 == 0o120000
            ):
                raise ValueError("archive contains an unsafe or duplicate entry")
            names.add(normalized)
            total += info.file_size
            if info.file_size > max_bytes or total > max_bytes * 2:
                raise ValueError("archive expansion exceeds the configured limit")
            contents[normalized] = archive.read(info)
    required = {
        "manifest.json",
        "incident.json",
        "summary.md",
        "diagnostics.json",
        "reproduction.md",
    }
    if not required.issubset(contents):
        raise ValueError("archive is missing required entries")
    manifest = ExportManifest.model_validate_json(contents["manifest.json"])
    declared = {entry.path: entry for entry in manifest.entries}
    for name in required - {"manifest.json"}:
        entry = declared.get(name)
        if (
            entry is None
            or sha256_bytes(contents[name]) != entry.sha256
            or len(contents[name]) != entry.size
        ):
            raise ValueError(f"archive entry digest mismatch: {name}")
    occurrence = IncidentOccurrence.model_validate_json(contents["incident.json"])
    if occurrence.occurrence_id != manifest.occurrence_id:
        raise ValueError("manifest occurrence does not match incident")
    return {
        "manifest": manifest,
        "occurrence": occurrence,
        "package_digest": sha256_bytes(raw),
        "package_size": len(raw),
        "entries": contents,
    }


def render_summary(occurrence: IncidentOccurrence) -> str:
    lines = [
        "# PersistMind Incident Report",
        "",
        "## Incident",
        "",
        occurrence.occurrence_id,
        "",
        "## Summary",
        "",
        occurrence.summary,
        "",
        "## Severity",
        "",
        occurrence.classification.severity.value.title(),
        "",
        "## Expected Behaviour",
        "",
        occurrence.expected_behavior or "Not provided.",
        "",
        "## Actual Behaviour",
        "",
        occurrence.actual_behavior or "Not provided.",
        "",
        "## Privacy Review",
        "",
        "This projection was generated from the sanitised authoritative JSON occurrence.",
        "",
    ]
    return "\n".join(lines)


def render_reproduction(occurrence: IncidentOccurrence) -> str:
    lines = ["# Reproduction", ""]
    if not occurrence.reproduction.steps:
        lines.extend(["No reproduction steps were provided.", ""])
    else:
        lines.extend(
            f"{index}. {step}" for index, step in enumerate(occurrence.reproduction.steps, 1)
        )
        lines.append("")
    return "\n".join(lines)


def _deterministic_zip(contents: dict[str, bytes]) -> bytes:
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(contents):
            info = zipfile.ZipInfo(name, _FIXED_ZIP_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100600 << 16
            archive.writestr(info, contents[name])
    return output.getvalue()


__all__ = ["export_occurrence", "inspect_package", "render_reproduction", "render_summary"]
