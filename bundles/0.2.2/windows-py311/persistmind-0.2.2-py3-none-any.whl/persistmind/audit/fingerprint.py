from __future__ import annotations

from importlib import metadata
from pathlib import Path
from typing import Any

from persistmind.branding import CAPABILITIES_FILE
from persistmind.utils import canonical_json, sha256_text

# Files whose contents gate self-improvement promotion. A self-modifying agent
# must never be able to alter these to pass its own gates. This fingerprint is
# intentionally pure so every audit adapter can use it.
GATING_PATHS = (
    ".claude/settings.json",
    ".codex/config.toml",
    ".gemini/settings.json",
    ".persistmind/*/hooks/persistmind_hook.py",
    ".persistmind/*/hooks/persistmind-hook.ps1",
    "eval/agent_cases.json",
    "eval/canaries.json",
    "eval/persistmind_component_ground_truth.json",
    "src/persistmind/agent_runtime/hooks.py",
    "src/persistmind/learning/judge.py",
    "src/persistmind/audit/chain.py",
    CAPABILITIES_FILE,
)


def gating_fingerprint(repo_root: Path) -> dict[str, Any]:
    """Deterministic hash over the contents of all existing gating-path files."""

    files: dict[str, str] = {}
    for rel in GATING_PATHS:
        paths = sorted(repo_root.glob(rel)) if "*" in rel else [repo_root / rel]
        for path in paths:
            if path.is_file():
                key = path.relative_to(repo_root).as_posix()
                files[key] = sha256_text(path.read_text(encoding="utf-8", errors="replace"))
    files.update(_installed_engine_fingerprints())
    digest = sha256_text(canonical_json(files))
    return {"digest": digest, "files": files}


def _installed_engine_fingerprints() -> dict[str, str]:
    fingerprints: dict[str, str] = {}
    for name in ("persistmind", "advanced-persistmind"):
        try:
            distribution = metadata.distribution(name)
        except metadata.PackageNotFoundError:
            continue
        record = distribution.read_text("RECORD") or ""
        if record:
            fingerprints[f"<installed:{name}:RECORD>"] = sha256_text(record)
        try:
            version = distribution.version
        except Exception:
            version = ""
        if version:
            fingerprints[f"<installed:{name}:version>"] = sha256_text(version)
    return fingerprints
