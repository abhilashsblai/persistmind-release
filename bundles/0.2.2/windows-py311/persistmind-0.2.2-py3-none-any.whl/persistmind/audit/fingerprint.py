from __future__ import annotations

from pathlib import Path
from typing import Any

from persistmind.utils import canonical_json, sha256_text
from persistmind.branding import CAPABILITIES_FILE


# Files whose contents gate self-improvement promotion. A self-modifying agent
# must never be able to alter these to pass its own gates. This fingerprint is
# intentionally pure so every audit adapter can use it.
GATING_PATHS = (
    "eval/agent_cases.json",
    "eval/canaries.json",
    "eval/persistmind_component_ground_truth.json",
    "src/persistmind/learning/judge.py",
    "src/persistmind/audit/chain.py",
    CAPABILITIES_FILE,
)


def gating_fingerprint(repo_root: Path) -> dict[str, Any]:
    """Deterministic hash over the contents of all existing gating-path files."""

    files: dict[str, str] = {}
    for rel in GATING_PATHS:
        path = repo_root / rel
        if path.is_file():
            files[rel] = sha256_text(path.read_text(encoding="utf-8", errors="replace"))
    digest = sha256_text(canonical_json(files))
    return {"digest": digest, "files": files}
