from __future__ import annotations

from pathlib import Path
from typing import Any

from .fingerprint import gating_fingerprint


class AuditLog:
    def __init__(self, store: Any):
        self.store = store

    def record_pack(self, manifest: dict[str, Any]) -> dict[str, Any]:
        payload = {
            "kind": "context_pack_served",
            "pack_id": manifest["pack_id"],
            "snapshot_id": manifest["snapshot_id"],
            "task_text_hash": manifest["task_text_hash"],
            "manifest_hash": manifest_hash(manifest),
            "reconstructible": manifest["worktree_state"] == "clean",
        }
        return self.store.append_audit(pack_id=manifest["pack_id"], payload=payload)

    def record_intent(self, intent: dict[str, Any]) -> dict[str, Any]:
        payload = {
            "kind": "intent_artifact",
            "intent_id": intent["intent_id"],
            "snapshot_id": intent["snapshot_id"],
            "problem_text_hash": intent["problem_text_hash"],
            "skeleton_hash": intent["skeleton_hash"],
        }
        if intent.get("event"):
            payload["event"] = intent["event"]
        if intent.get("selected_goal_id"):
            payload["selected_goal_id"] = intent["selected_goal_id"]
        return self.store.append_audit(pack_id=intent["intent_id"], payload=payload)

    def record_goal(self, goal: dict[str, Any]) -> dict[str, Any]:
        payload = {
            "kind": goal["kind"],
            "goal_id": goal["goal_id"],
            "intent_id": goal.get("intent_id"),
            "snapshot_id": goal.get("snapshot_id"),
            "permission_mode": goal.get("permission_mode"),
        }
        if goal.get("alt_id"):
            payload["alt_id"] = goal["alt_id"]
        if goal.get("projected_metric_delta"):
            payload["projected_metric_delta"] = goal["projected_metric_delta"]
        if goal.get("challenge_state"):
            payload["challenge_state"] = goal["challenge_state"]
        return self.store.append_audit(pack_id=f"goal:{goal['goal_id']}", payload=payload)

    def verify(self) -> dict[str, Any]:
        return self.store.verify_audit_chain()

    def record_gating_baseline(self, repo_root: Path) -> dict[str, Any]:
        """Record the current gating-path fingerprint into the tamper-evident audit chain."""
        fingerprint = gating_fingerprint(repo_root)
        payload = {
            "kind": "gating_baseline",
            "fingerprint": fingerprint["digest"],
            "files": fingerprint["files"],
        }
        record = self.store.append_audit(pack_id="gating-baseline", payload=payload)
        return {"ok": True, "fingerprint": fingerprint["digest"], "audit": record}

    def verify_gating_integrity(self, repo_root: Path) -> dict[str, Any]:
        """Compare the current gating fingerprint against the last recorded baseline.

        Returns ok=False when the gating path changed since the baseline (possible tampering)
        or when no baseline exists yet. Self-mod preflight uses this as a tripwire.
        """
        import json

        current = gating_fingerprint(repo_root)
        row = self.store.audit_record(pack_id="gating-baseline")
        if row is None:
            return {
                "ok": False,
                "reason": "no_gating_baseline",
                "current": current["digest"],
            }
        try:
            baseline = json.loads(row["payload_json"])
        except (json.JSONDecodeError, KeyError, TypeError):
            baseline = {}
        recorded = str(baseline.get("fingerprint") or "")
        ok = recorded == current["digest"]
        return {
            "ok": ok,
            "reason": "gating_intact" if ok else "gating_fingerprint_mismatch",
            "current": current["digest"],
            "baseline": recorded,
        }


def manifest_hash(manifest: dict[str, Any]) -> str:
    from persistmind.utils import canonical_json, sha256_text

    return sha256_text(canonical_json(manifest))
