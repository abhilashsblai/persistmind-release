from __future__ import annotations

import base64
import re
from collections.abc import Iterable, Mapping
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from persistmind.utils import canonical_json, sha256_text, stable_id

_PATCH_PATH = re.compile(r"^\+\+\+\s+(?:b/)?(?P<path>[^\t\r\n]+)", re.MULTILINE)


@dataclass(frozen=True)
class SandboxPolicy:
    repository: Path
    sandbox: Path
    allowed_paths: tuple[str, ...]
    protected_paths: tuple[str, ...] = (
        ".github/",
        "eval/",
        "evidence/",
        "src/persistmind/security/",
        "src/persistmind/release/",
    )
    network_allowed: bool = False

    def __post_init__(self) -> None:
        repository = self.repository.resolve()
        sandbox = self.sandbox.resolve()
        if sandbox == repository or repository in sandbox.parents:
            raise ValueError("self-improvement sandbox must be outside the source checkout")
        for path in (*self.allowed_paths, *self.protected_paths):
            _normalize_relative(path)


@dataclass(frozen=True)
class PatchProposal:
    base_commit: str
    patch: str
    paths: tuple[str, ...]
    validations: tuple[str, ...]
    expires_at: str
    sandbox_id: str

    @property
    def patch_sha256(self) -> str:
        return sha256_text(self.patch)

    @property
    def proposal_id(self) -> str:
        return stable_id(self.base_commit, self.patch_sha256, self.expires_at, self.sandbox_id)

    def document(self) -> dict[str, Any]:
        return {
            "schema_version": "persistmind.patch_proposal.v1",
            **asdict(self),
            "patch_sha256": self.patch_sha256,
            "proposal_id": self.proposal_id,
            "applied": False,
            "auto_apply_available": False,
        }


def create_patch_proposal(
    *,
    policy: SandboxPolicy,
    base_commit: str,
    patch: str,
    validations: Iterable[str],
    expires_at: str,
) -> PatchProposal:
    paths = tuple(
        sorted({_normalize_relative(match.group("path")) for match in _PATCH_PATH.finditer(patch)})
    )
    if not paths:
        raise ValueError("patch proposal contains no target paths")
    allowed = tuple(_normalize_relative(path).rstrip("/") for path in policy.allowed_paths)
    protected = tuple(_normalize_relative(path).rstrip("/") for path in policy.protected_paths)
    for path in paths:
        if any(path == root or path.startswith(f"{root}/") for root in protected):
            raise ValueError(f"patch targets protected path: {path}")
        if not any(path == root or path.startswith(f"{root}/") for root in allowed):
            raise ValueError(f"patch target is outside the run allowlist: {path}")
    checks = tuple(sorted({str(item) for item in validations if str(item)}))
    if not checks:
        raise ValueError("patch proposal requires validation evidence")
    _parse_expiry(expires_at)
    return PatchProposal(
        base_commit=base_commit,
        patch=patch,
        paths=paths,
        validations=checks,
        expires_at=expires_at,
        sandbox_id=stable_id(str(policy.sandbox.resolve()), base_commit),
    )


def verify_patch_approval(
    proposal: PatchProposal,
    approval: Mapping[str, Any],
    *,
    current_commit: str,
    trusted_public_key: Any,
    now: datetime | None = None,
) -> dict[str, Any]:
    observed = now or datetime.now(UTC)
    reasons: list[str] = []
    if proposal.base_commit != current_commit:
        reasons.append("base_commit_mismatch")
    if _parse_expiry(proposal.expires_at) <= observed:
        reasons.append("approval_expired")
    if approval.get("role") not in {"codeowner", "admin"} or not approval.get("subject"):
        reasons.append("codeowner_approval_required")
    if approval.get("proposal_id") != proposal.proposal_id:
        reasons.append("proposal_identity_mismatch")
    if approval.get("patch_sha256") != proposal.patch_sha256:
        reasons.append("patch_digest_mismatch")
    signature = str(approval.get("signature") or "")
    try:
        trusted_public_key.verify(
            base64.b64decode(signature, validate=True),
            canonical_json(proposal.document()).encode("utf-8"),
        )
    except Exception:  # noqa: BLE001 - signature verification fails closed.
        reasons.append("proposal_signature_invalid")
    return {
        "ok": not reasons,
        "schema_version": "persistmind.patch_approval.v1",
        "status": "approved" if not reasons else "rejected",
        "reasons": reasons,
        "proposal_id": proposal.proposal_id,
        "applied": False,
    }


def sign_patch_proposal(proposal: PatchProposal, private_key: Any) -> str:
    signature = private_key.sign(canonical_json(proposal.document()).encode("utf-8"))
    return base64.b64encode(signature).decode("ascii")


def _normalize_relative(path: str) -> str:
    value = path.replace("\\", "/").strip()
    value = value.removeprefix("./")
    value = value.rstrip("/")
    parts = value.split("/")
    if (
        not value
        or value.startswith("/")
        or ":" in parts[0]
        or any(part in {"", ".", ".."} for part in parts)
    ):
        raise ValueError(f"unsafe relative path: {path!r}")
    return "/".join(parts)


def _parse_expiry(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("proposal expiry must be timezone-aware")
    return parsed.astimezone(UTC)
