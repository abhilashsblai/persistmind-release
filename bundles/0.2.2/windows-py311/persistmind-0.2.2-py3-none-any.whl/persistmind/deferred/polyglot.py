from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from persistmind.parsing import parse_file
from persistmind.utils import sha256_text


@dataclass(frozen=True)
class PolyglotCase:
    repository: str
    path: str
    text: str
    expected_symbols: tuple[str, ...]
    expected_imports: tuple[str, ...] = ()


def qualify_polyglot(cases: Iterable[PolyglotCase]) -> dict[str, object]:
    ordered = sorted(cases, key=lambda item: (item.repository, item.path))
    rows = []
    true_symbols = found_symbols = expected_symbols = 0
    true_imports = found_imports = expected_imports = 0
    for case in ordered:
        parsed = parse_file(case.path, case.text, backend="tree-sitter")
        actual_symbol_set = {item.qualname for item in parsed.symbols}
        actual_import_set = {item.module for item in parsed.imports}
        expected_symbol_set = set(case.expected_symbols)
        expected_import_set = set(case.expected_imports)
        true_symbols += len(actual_symbol_set & expected_symbol_set)
        found_symbols += len(actual_symbol_set)
        expected_symbols += len(expected_symbol_set)
        true_imports += len(actual_import_set & expected_import_set)
        found_imports += len(actual_import_set)
        expected_imports += len(expected_import_set)
        rows.append(
            {
                "repository": case.repository,
                "path": case.path,
                "language": parsed.lang,
                "backend": parsed.effective_backend,
                "support_tier": parsed.support_tier,
                "line_count": len(case.text.splitlines()),
                "source_sha256": sha256_text(case.text),
                "missing_symbols": sorted(expected_symbol_set - actual_symbol_set),
                "unexpected_symbols": sorted(actual_symbol_set - expected_symbol_set),
                "missing_imports": sorted(expected_import_set - actual_import_set),
                "unexpected_imports": sorted(actual_import_set - expected_import_set),
                "diagnostics": list(parsed.diagnostics),
            }
        )
    symbol_precision = _ratio(true_symbols, found_symbols)
    symbol_recall = _ratio(true_symbols, expected_symbols)
    symbol_f1 = _f1(symbol_precision, symbol_recall)
    import_precision = _ratio(true_imports, found_imports)
    import_recall = _ratio(true_imports, expected_imports)
    return {
        "ok": bool(rows)
        and symbol_f1 >= 0.98
        and import_precision >= 0.95
        and import_recall >= 0.95
        and all(not row["diagnostics"] for row in rows),
        "schema_version": "persistmind.polyglot_qualification.v1",
        "case_count": len(rows),
        "repositories": sorted({case.repository for case in ordered}),
        "symbol_precision": round(symbol_precision, 6),
        "symbol_recall": round(symbol_recall, 6),
        "symbol_f1": round(symbol_f1, 6),
        "import_precision": round(import_precision, 6),
        "import_recall": round(import_recall, 6),
        "rows": rows,
        "release_qualifying": False,
    }


def _ratio(numerator: int, denominator: int) -> float:
    return numerator / denominator if denominator else 1.0


def _f1(precision: float, recall: float) -> float:
    return 2 * precision * recall / (precision + recall) if precision + recall else 0.0
