from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import asdict, dataclass
from typing import Any

from persistmind.utils import canonical_json, sha256_text


@dataclass(frozen=True)
class EvidenceBinding:
    repository_id: str
    source_view_id: str
    graph_version_id: str
    evidence_ids: tuple[str, ...]

    def __post_init__(self) -> None:
        if not all((self.repository_id, self.source_view_id, self.graph_version_id)):
            raise ValueError(
                "advisory analysis requires repository, source-view, and graph identities"
            )


def advisory_report(
    *,
    capability: str,
    binding: EvidenceBinding,
    baseline: Mapping[str, Any],
    analyzer: Callable[[], Mapping[str, Any]],
    confidence: float,
    unknowns: tuple[str, ...] = (),
) -> dict[str, Any]:
    if not 0.0 <= confidence <= 1.0:
        raise ValueError("confidence must be between zero and one")
    recommendation = dict(analyzer())
    payload = {
        "schema_version": "persistmind.advisory_analysis.v1",
        "capability": capability,
        "trust_level": "advisory",
        "binding": asdict(binding),
        "baseline": dict(baseline),
        "recommendation": recommendation,
        "confidence": confidence,
        "unknowns": list(unknowns),
        "workflow_authority": False,
        "blocking": False,
    }
    payload["report_digest"] = sha256_text(canonical_json(payload))
    return payload
