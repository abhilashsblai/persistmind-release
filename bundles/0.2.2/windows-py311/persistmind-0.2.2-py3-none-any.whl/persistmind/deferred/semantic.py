from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import asdict, dataclass

from persistmind.utils import canonical_json, sha256_text


@dataclass(frozen=True)
class ModelArtifact:
    name: str
    version: str
    sha256: str
    license: str
    dimensions: int
    tokenizer: str
    offline: bool = True

    def __post_init__(self) -> None:
        if len(self.sha256) != 64 or any(char not in "0123456789abcdef" for char in self.sha256):
            raise ValueError("model artifact requires a lowercase SHA-256 digest")
        if self.dimensions <= 0:
            raise ValueError("model dimensions must be positive")

    @property
    def identity(self) -> str:
        return sha256_text(canonical_json(asdict(self)))


@dataclass(frozen=True)
class RetrievalCandidate:
    item_id: str
    lexical_score: float = 0.0
    semantic_score: float = 0.0
    required: bool = False


def advisory_rerank(
    *,
    lexical: Iterable[RetrievalCandidate],
    semantic_scores: Mapping[str, float],
    required_ids: Iterable[str] = (),
    limit: int = 20,
    model: ModelArtifact | None = None,
) -> dict[str, object]:
    if limit <= 0:
        raise ValueError("limit must be positive")
    required = {str(item) for item in required_ids}
    candidates: dict[str, RetrievalCandidate] = {}
    for item in lexical:
        candidates[item.item_id] = RetrievalCandidate(
            item.item_id,
            float(item.lexical_score),
            float(semantic_scores.get(item.item_id, item.semantic_score)),
            item.required or item.item_id in required,
        )
    for item_id, score in semantic_scores.items():
        if item_id not in candidates:
            candidates[item_id] = RetrievalCandidate(
                item_id,
                0.0,
                float(score),
                item_id in required,
            )
    missing_required = sorted(required - set(candidates))
    ordered = sorted(
        candidates.values(),
        key=lambda item: (
            not item.required,
            -(0.6 * item.lexical_score + 0.4 * item.semantic_score),
            item.item_id,
        ),
    )
    required_count = sum(item.required for item in ordered)
    effective_limit = max(limit, required_count)
    selected = ordered[:effective_limit]
    return {
        "ok": not missing_required,
        "schema_version": "persistmind.semantic_rerank.v1",
        "status": "ranked" if not missing_required else "required_context_missing",
        "trust_level": "advisory",
        "effective_backend": "semantic-order-only" if model else "lexical",
        "model": asdict(model) if model else None,
        "model_identity": model.identity if model else None,
        "candidate_count": len(candidates),
        "truncated": len(selected) < len(ordered),
        "missing_required": missing_required,
        "items": [asdict(item) for item in selected],
        "limitations": ["semantic ranking cannot remove required context"],
    }
