from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Iterable

from persistmind.utils import stable_id


@dataclass(frozen=True)
class RepositoryView:
    workspace_id: str
    repository_id: str
    source_view_id: str
    version: str

    def __post_init__(self) -> None:
        if not all(asdict(self).values()):
            raise ValueError("repository view identity must be complete")


@dataclass(frozen=True)
class ContractEdge:
    producer: RepositoryView
    consumer: RepositoryView
    contract_kind: str
    contract_name: str
    confidence: float
    evidence: tuple[str, ...]

    def __post_init__(self) -> None:
        if self.producer.workspace_id != self.consumer.workspace_id:
            raise ValueError("cross-repository edges cannot cross workspace authority")
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("confidence must be between zero and one")
        if not self.evidence:
            raise ValueError("contract edge requires evidence")

    @property
    def edge_id(self) -> str:
        return stable_id(
            self.producer.repository_id,
            self.producer.source_view_id,
            self.consumer.repository_id,
            self.consumer.source_view_id,
            self.contract_kind,
            self.contract_name,
        )


class CrossRepositoryCatalog:
    def __init__(self, workspace_id: str) -> None:
        self.workspace_id = workspace_id
        self._edges: dict[str, ContractEdge] = {}

    def replace(self, edges: Iterable[ContractEdge]) -> dict[str, Any]:
        replacement: dict[str, ContractEdge] = {}
        for edge in edges:
            if edge.producer.workspace_id != self.workspace_id:
                raise ValueError("edge is outside this workspace")
            replacement[edge.edge_id] = edge
        self._edges = replacement
        return {
            "ok": True,
            "generation": stable_id(*sorted(replacement)),
            "edges": len(replacement),
        }

    def disconnect(self, repository_id: str) -> dict[str, Any]:
        removed = [
            edge_id
            for edge_id, edge in self._edges.items()
            if repository_id in {edge.producer.repository_id, edge.consumer.repository_id}
        ]
        for edge_id in removed:
            del self._edges[edge_id]
        return {"ok": True, "removed": len(removed)}

    def impact(self, repository_id: str, current_views: dict[str, str]) -> dict[str, Any]:
        impacts = []
        for edge in self._edges.values():
            if edge.producer.repository_id != repository_id:
                continue
            stale = any(
                current_views.get(view.repository_id) != view.source_view_id
                for view in (edge.producer, edge.consumer)
            )
            impacts.append(
                {
                    "edge_id": edge.edge_id,
                    "consumer_repository_id": edge.consumer.repository_id,
                    "classification": "stale"
                    if stale
                    else "confirmed"
                    if edge.confidence >= 0.9
                    else "inferred",
                    "confidence": edge.confidence,
                    "producer_version": edge.producer.version,
                    "consumer_version": edge.consumer.version,
                }
            )
        return {
            "ok": True,
            "schema_version": "persistmind.cross_repository_impact.v1",
            "workspace_id": self.workspace_id,
            "impacts": sorted(impacts, key=lambda item: item["edge_id"]),
        }
