from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any, Protocol

from persistmind.utils import sha256_text, stable_id


@dataclass(frozen=True)
class ConnectorRecord:
    source_record_id: str
    updated_at: str
    content: str
    deleted: bool = False


@dataclass(frozen=True)
class ConnectorPage:
    records: tuple[ConnectorRecord, ...]
    next_cursor: str | None


class ReadOnlyConnector(Protocol):
    connector_id: str
    credential_reference: str

    def fetch(self, cursor: str | None, limit: int) -> ConnectorPage: ...


class FixtureIncidentConnector:
    connector_id = "fixture-incidents"
    credential_reference = "fixture:none"

    def __init__(self, records: Iterable[ConnectorRecord]) -> None:
        self.records = tuple(records)

    def fetch(self, cursor: str | None, limit: int) -> ConnectorPage:
        offset = int(cursor or 0)
        selected = self.records[offset : offset + limit]
        next_offset = offset + len(selected)
        next_cursor = str(next_offset) if next_offset < len(self.records) else None
        return ConnectorPage(tuple(selected), next_cursor)


class ConnectorProjection:
    def __init__(self) -> None:
        self._records: dict[tuple[str, str], dict[str, Any]] = {}
        self._cursors: dict[str, str | None] = {}
        self._revoked: set[str] = set()

    def ingest(self, connector: ReadOnlyConnector, *, limit: int = 100) -> dict[str, Any]:
        if connector.connector_id in self._revoked:
            return {"ok": False, "status": "connector_revoked", "core_blocked": False}
        if not connector.credential_reference or "=" in connector.credential_reference:
            return {
                "ok": False,
                "status": "secure_credential_reference_required",
                "core_blocked": False,
            }
        cursor = self._cursors.get(connector.connector_id)
        try:
            page = connector.fetch(cursor, limit)
        except Exception as exc:  # noqa: BLE001
            return {
                "ok": False,
                "status": "provider_unavailable",
                "error_type": type(exc).__name__,
                "core_blocked": False,
            }
        changed = 0
        for record in page.records:
            key = (connector.connector_id, record.source_record_id)
            if record.deleted:
                changed += int(self._records.pop(key, None) is not None)
                continue
            projected = {
                "record_id": stable_id(*key),
                "connector_id": connector.connector_id,
                "source_record_id": record.source_record_id,
                "updated_at": record.updated_at,
                "content": record.content,
                "content_sha256": sha256_text(record.content),
                "trust": "quarantined",
                "policy_authority": False,
                "memory_authority": False,
            }
            changed += int(self._records.get(key) != projected)
            self._records[key] = projected
        self._cursors[connector.connector_id] = page.next_cursor
        return {
            "ok": True,
            "status": "ingested",
            "changed": changed,
            "next_cursor": page.next_cursor,
            "active": sum(key[0] == connector.connector_id for key in self._records),
        }

    def revoke(self, connector_id: str) -> dict[str, Any]:
        self._revoked.add(connector_id)
        removed = [key for key in self._records if key[0] == connector_id]
        for key in removed:
            del self._records[key]
        self._cursors.pop(connector_id, None)
        return {"ok": True, "removed": len(removed)}

    def records(self, connector_id: str) -> list[Mapping[str, Any]]:
        return [self._records[key] for key in sorted(self._records) if key[0] == connector_id]
