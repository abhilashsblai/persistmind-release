from __future__ import annotations

import time
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from typing import Any

from persistmind.utils import canonical_json, sha256_text, stable_id


@dataclass(frozen=True)
class EvaluationCase:
    case_id: str
    input: Mapping[str, Any]
    expected: Mapping[str, Any]
    repository: str = "fixture"
    captured_at: str = "fixture"


Metric = Callable[[Mapping[str, Any], Mapping[str, Any]], float]
Runner = Callable[[Mapping[str, Any]], Mapping[str, Any]]


def evaluate_ablation(
    *,
    capability_id: str,
    cases: Iterable[EvaluationCase],
    baseline: Runner,
    candidate: Runner,
    metric: Metric,
    minimum_lift: float = 0.0,
) -> dict[str, Any]:
    ordered = sorted(cases, key=lambda item: item.case_id)
    if not ordered:
        return {
            "ok": False,
            "schema_version": "persistmind.deferred_evaluation.v1",
            "capability_id": capability_id,
            "status": "insufficient_evidence",
            "case_count": 0,
            "release_qualifying": False,
        }
    rows: list[dict[str, Any]] = []
    started = time.perf_counter()
    for case in ordered:
        before = baseline(case.input)
        after = candidate(case.input)
        baseline_score = float(metric(before, case.expected))
        candidate_score = float(metric(after, case.expected))
        rows.append(
            {
                "case_id": case.case_id,
                "repository": case.repository,
                "captured_at": case.captured_at,
                "baseline_score": baseline_score,
                "candidate_score": candidate_score,
                "lift": candidate_score - baseline_score,
                "baseline_digest": sha256_text(canonical_json(before)),
                "candidate_digest": sha256_text(canonical_json(after)),
            }
        )
    baseline_mean = sum(row["baseline_score"] for row in rows) / len(rows)
    candidate_mean = sum(row["candidate_score"] for row in rows) / len(rows)
    lift = candidate_mean - baseline_mean
    corpus = [
        {
            "case_id": case.case_id,
            "input": dict(case.input),
            "expected": dict(case.expected),
            "repository": case.repository,
            "captured_at": case.captured_at,
        }
        for case in ordered
    ]
    return {
        "ok": lift >= minimum_lift,
        "schema_version": "persistmind.deferred_evaluation.v1",
        "evaluation_id": stable_id(capability_id, canonical_json(corpus)),
        "capability_id": capability_id,
        "status": "qualified" if lift >= minimum_lift else "non_regression_failed",
        "case_count": len(rows),
        "corpus_digest": sha256_text(canonical_json(corpus)),
        "baseline_mean": baseline_mean,
        "candidate_mean": candidate_mean,
        "lift": lift,
        "minimum_lift": minimum_lift,
        "elapsed_ms": round((time.perf_counter() - started) * 1000, 3),
        "release_qualifying": False,
        "rows": rows,
    }
