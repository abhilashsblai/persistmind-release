from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import asdict, dataclass
from typing import cast

from persistmind.utils import canonical_json, sha256_text


@dataclass(frozen=True)
class PredictionBinding:
    task_session_id: str
    source_view_id: str
    pack_id: str
    scope_revision_id: str
    impact_report_id: str

    def __post_init__(self) -> None:
        if not all(asdict(self).values()):
            raise ValueError("predictions require complete immutable workflow identities")


def bind_prediction(
    *,
    binding: PredictionBinding,
    predicted_paths: Iterable[str],
    known_paths: Iterable[str],
    probability: float,
    rationale: str,
) -> dict[str, object]:
    if not 0.0 <= probability <= 1.0:
        raise ValueError("probability must be between zero and one")
    known = set(known_paths)
    paths = sorted(set(predicted_paths))
    hypothetical = sorted(path for path in paths if path not in known)
    payload: dict[str, object] = {
        "schema_version": "persistmind.anticipation_prediction.v1",
        "binding": asdict(binding),
        "predicted_paths": paths,
        "hypothetical_paths": hypothetical,
        "probability": probability,
        "rationale": rationale,
        "trust_level": "advisory",
        "dismissible": True,
        "blocking": False,
    }
    payload["prediction_digest"] = sha256_text(canonical_json(payload))
    return payload


def expected_calibration_error(pairs: Iterable[Mapping[str, object]], bins: int = 10) -> float:
    if bins <= 0:
        raise ValueError("bins must be positive")
    values = list(pairs)
    if not values:
        return 0.0
    total = len(values)
    error = 0.0
    for index in range(bins):
        low = index / bins
        high = (index + 1) / bins
        bucket = [
            item
            for item in values
            if low <= float(cast(float | int | str, item["probability"])) < high
            or (index == bins - 1 and float(cast(float | int | str, item["probability"])) == 1.0)
        ]
        if not bucket:
            continue
        confidence = sum(
            float(cast(float | int | str, item["probability"])) for item in bucket
        ) / len(bucket)
        accuracy = sum(1.0 if bool(item["occurred"]) else 0.0 for item in bucket) / len(bucket)
        error += (len(bucket) / total) * abs(confidence - accuracy)
    return round(error, 6)


def latency_budget_status(
    samples_ms: Iterable[float], *, budget_ms: float = 100.0
) -> dict[str, object]:
    values = sorted(float(item) for item in samples_ms)
    if not values:
        return {"ok": False, "status": "insufficient_latency_evidence", "p95_ms": None}
    index = min(len(values) - 1, max(0, int(0.95 * len(values) + 0.999999) - 1))
    p95 = values[index]
    return {
        "ok": p95 <= budget_ms,
        "status": "within_budget" if p95 <= budget_ms else "budget_exceeded",
        "p95_ms": p95,
        "budget_ms": budget_ms,
        "samples": len(values),
    }
