from __future__ import annotations

import os
from dataclasses import asdict, dataclass
from typing import Any, Mapping


DEFERRED_CONTRACT_SCHEMA = "persistmind.deferred_capability.v1"
DEFERRED_REGISTRY_SCHEMA = "persistmind.deferred_capability_registry.v1"
TRUST_LEVELS = frozenset({"untrusted", "candidate", "advisory", "authoritative"})
MATURITY_LEVELS = frozenset({"experimental", "preview", "production"})


@dataclass(frozen=True)
class ResourceBudget:
    latency_p95_ms: int
    memory_mb: int
    storage_mb: int
    network_requests: int = 0
    cost_units: int = 0

    def __post_init__(self) -> None:
        if (
            min(
                self.latency_p95_ms,
                self.memory_mb,
                self.storage_mb,
                self.network_requests,
                self.cost_units,
            )
            < 0
        ):
            raise ValueError("resource budgets must be non-negative")


@dataclass(frozen=True)
class CapabilityDescriptor:
    capability_id: str
    name: str
    owning_domain: str
    storage_owner: str
    profile: str
    maturity: str
    trust_level: str
    authority: str
    transaction_boundary: str
    events: tuple[str, ...]
    input_schema: str
    output_schema: str
    kill_switch: str
    budget: ResourceBudget
    network_default: str = "denied"
    background_work: bool = False

    def __post_init__(self) -> None:
        if self.profile not in {"labs", "team-preview"}:
            raise ValueError("deferred capabilities require labs or team-preview")
        if self.maturity not in MATURITY_LEVELS:
            raise ValueError(f"invalid maturity: {self.maturity}")
        if self.trust_level not in TRUST_LEVELS:
            raise ValueError(f"invalid trust level: {self.trust_level}")
        if self.network_default not in {"denied", "read-only"}:
            raise ValueError("network_default must be denied or read-only")

    def document(self) -> dict[str, Any]:
        payload = {
            "schema_version": DEFERRED_CONTRACT_SCHEMA,
            **asdict(self),
        }
        payload["events"] = list(self.events)
        return payload


@dataclass(frozen=True)
class CapabilityResult:
    capability_id: str
    ok: bool
    status: str
    trust_level: str
    effective_backend: str
    evidence: tuple[str, ...] = ()
    unknowns: tuple[str, ...] = ()
    limitations: tuple[str, ...] = ()
    payload: Mapping[str, Any] | None = None

    def document(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "schema_version": "persistmind.capability_result.v1",
            "capability_id": self.capability_id,
            "status": self.status,
            "trust_level": self.trust_level,
            "effective_backend": self.effective_backend,
            "evidence": list(self.evidence),
            "unknowns": list(self.unknowns),
            "limitations": list(self.limitations),
            "payload": dict(self.payload or {}),
        }


def _descriptor(
    capability_id: str,
    name: str,
    domain: str,
    storage: str,
    profile: str,
    authority: str,
    transaction: str,
    *,
    latency: int,
    memory: int,
    storage_mb: int,
    network: str = "denied",
) -> CapabilityDescriptor:
    slug = capability_id.lower().replace("-", "_")
    return CapabilityDescriptor(
        capability_id=capability_id,
        name=name,
        owning_domain=domain,
        storage_owner=storage,
        profile=profile,
        maturity="experimental" if profile == "labs" else "preview",
        trust_level="advisory",
        authority=authority,
        transaction_boundary=transaction,
        events=(f"{slug}.evaluated",),
        input_schema=f"persistmind.{slug}.input.v1",
        output_schema=f"persistmind.{slug}.result.v1",
        kill_switch=f"PERSISTMIND_{slug.upper()}_OFF",
        budget=ResourceBudget(latency, memory, storage_mb),
        network_default=network,
    )


CAPABILITY_REGISTRY: dict[str, CapabilityDescriptor] = {
    item.capability_id: item
    for item in (
        _descriptor(
            "DF-01",
            "production-polyglot-indexing",
            "source",
            "source manifests and snapshot indexes",
            "labs",
            "local repository read",
            "one immutable source generation",
            latency=5000,
            memory=1024,
            storage_mb=4096,
        ),
        _descriptor(
            "DF-02",
            "semantic-retrieval",
            "retrieval",
            "derived vector indexes",
            "labs",
            "local read",
            "one model-bound derived generation",
            latency=500,
            memory=2048,
            storage_mb=4096,
        ),
        _descriptor(
            "DF-03",
            "analysis-repair-routing",
            "analysis",
            "advisory analysis records",
            "labs",
            "advisory read",
            "one source-view-bound report",
            latency=3000,
            memory=1024,
            storage_mb=512,
        ),
        _descriptor(
            "DF-04",
            "cie-teacher-adaptive-governance",
            "learning",
            "versioned proposals and adoption artifacts",
            "labs",
            "proposal; scoped approval for canary",
            "immutable proposal plus atomic active-artifact pointer",
            latency=5000,
            memory=1024,
            storage_mb=2048,
        ),
        _descriptor(
            "DF-05",
            "anticipation",
            "prediction",
            "task-bound prediction/outcome pairs",
            "labs",
            "advisory warning",
            "one immutable task/source-view prediction",
            latency=100,
            memory=512,
            storage_mb=1024,
        ),
        _descriptor(
            "DF-06",
            "sandboxed-patch-proposals",
            "self-improvement",
            "signed unapplied patch proposals",
            "labs",
            "scoped codeowner approval",
            "one disposable sandbox and itemized cleanup",
            latency=600000,
            memory=4096,
            storage_mb=8192,
        ),
        _descriptor(
            "DF-07",
            "cross-repository-intelligence",
            "workspace-graph",
            "versioned cross-repository contract edges",
            "labs",
            "workspace read",
            "one workspace catalog generation",
            latency=10000,
            memory=2048,
            storage_mb=8192,
        ),
        _descriptor(
            "DF-08",
            "organization-decision-support",
            "organization",
            "tenant-scoped quarantined knowledge",
            "team-preview",
            "tenant-scoped advisory read",
            "one principal-intersected query/import",
            latency=1000,
            memory=2048,
            storage_mb=16384,
            network="read-only",
        ),
        _descriptor(
            "DF-09",
            "team-read-only-server",
            "team-transport",
            "tenant-scoped projections",
            "team-preview",
            "verified OIDC read",
            "one bounded authenticated request",
            latency=1000,
            memory=4096,
            storage_mb=16384,
        ),
        _descriptor(
            "DF-10",
            "writable-mcp-broker",
            "host-capability-broker",
            "idempotent task/outcome events",
            "team-preview",
            "host-issued scoped capability",
            "one authorized idempotent mutation",
            latency=2000,
            memory=1024,
            storage_mb=4096,
        ),
        _descriptor(
            "DF-11",
            "operational-provider-integrations",
            "connector-runtime",
            "source-attributed activity records and cursors",
            "team-preview",
            "least-privilege read-only connector",
            "one idempotent cursor page",
            latency=5000,
            memory=2048,
            storage_mb=16384,
            network="read-only",
        ),
    )
}


class CapabilityGuard:
    """Fail closed before constructing a deferred service."""

    def authorize(
        self,
        capability_id: str,
        *,
        profile: str,
        explicitly_enabled: bool,
        authority: Mapping[str, Any] | None = None,
    ) -> CapabilityResult:
        descriptor = CAPABILITY_REGISTRY.get(capability_id)
        if descriptor is None:
            return CapabilityResult(
                capability_id,
                False,
                "unknown_capability",
                "untrusted",
                "none",
            )
        if os.getenv(descriptor.kill_switch, "").strip().lower() in {"1", "true", "yes", "on"}:
            return self._denied(descriptor, "kill_switch_active")
        if profile != descriptor.profile:
            return self._denied(descriptor, "profile_disabled")
        if not explicitly_enabled:
            return self._denied(descriptor, "not_explicitly_enabled")
        if descriptor.profile == "team-preview" and not authority:
            return self._denied(descriptor, "verified_authority_required")
        return CapabilityResult(
            descriptor.capability_id,
            True,
            "enabled",
            descriptor.trust_level,
            "contract-ready",
            limitations=("promotion evidence is evaluated separately",),
            payload={"descriptor": descriptor.document()},
        )

    @staticmethod
    def _denied(descriptor: CapabilityDescriptor, reason: str) -> CapabilityResult:
        return CapabilityResult(
            descriptor.capability_id,
            False,
            reason,
            "untrusted",
            "none",
            unknowns=("service was not constructed",),
        )


def capability_registry_document() -> dict[str, Any]:
    return {
        "schema_version": DEFERRED_REGISTRY_SCHEMA,
        "capabilities": [
            CAPABILITY_REGISTRY[key].document() for key in sorted(CAPABILITY_REGISTRY)
        ],
    }
