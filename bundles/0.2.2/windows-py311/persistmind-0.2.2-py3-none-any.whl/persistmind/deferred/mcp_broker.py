from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
from dataclasses import dataclass
from typing import Any, Callable, Mapping

from persistmind.utils import canonical_json, stable_id


ALLOWED_MUTATIONS = frozenset({"task.record", "outcome.record"})


@dataclass(frozen=True)
class HostCapability:
    subject: str
    repository_id: str
    host_session_id: str
    operations: tuple[str, ...]
    consent_id: str
    expires_at: int
    nonce: str
    revocation_generation: int

    def __post_init__(self) -> None:
        if not all(
            (self.subject, self.repository_id, self.host_session_id, self.consent_id, self.nonce)
        ):
            raise ValueError("host capability identity is incomplete")
        if not self.operations or not set(self.operations) <= ALLOWED_MUTATIONS:
            raise ValueError("host capability requests an unavailable mutation class")
        object.__setattr__(self, "operations", tuple(sorted(set(self.operations))))


def issue_capability(capability: HostCapability, secret: bytes) -> str:
    payload = canonical_json(capability.__dict__).encode("utf-8")
    encoded = base64.urlsafe_b64encode(payload).rstrip(b"=")
    signature = hmac.new(secret, encoded, hashlib.sha256).digest()
    return f"{encoded.decode()}.{base64.urlsafe_b64encode(signature).rstrip(b'=').decode()}"


def verify_capability(
    token: str,
    secret: bytes,
    *,
    operation: str,
    repository_id: str,
    host_session_id: str,
    revocation_generation: int,
    now: int | None = None,
) -> HostCapability:
    try:
        encoded, signature_text = token.split(".", 1)
        expected = hmac.new(secret, encoded.encode(), hashlib.sha256).digest()
        signature = base64.urlsafe_b64decode(_pad(signature_text))
        if not hmac.compare_digest(expected, signature):
            raise ValueError("invalid capability signature")
        payload = json.loads(base64.urlsafe_b64decode(_pad(encoded)))
        capability = HostCapability(**payload)
    except (TypeError, KeyError, ValueError, json.JSONDecodeError) as exc:
        raise ValueError("invalid host capability") from exc
    observed = int(time.time()) if now is None else now
    if capability.expires_at <= observed:
        raise ValueError("host capability expired")
    if capability.revocation_generation != revocation_generation:
        raise ValueError("host capability revoked")
    if operation not in capability.operations:
        raise ValueError("operation is outside host capability")
    if capability.repository_id != repository_id or capability.host_session_id != host_session_id:
        raise ValueError("host capability scope mismatch")
    return capability


class MutationBroker:
    def __init__(
        self, secret: bytes, handler: Callable[[str, Mapping[str, Any]], Mapping[str, Any]]
    ):
        if len(secret) < 32:
            raise ValueError("broker secret must contain at least 32 bytes")
        self.secret = secret
        self.handler = handler
        self.revocation_generation = 0
        self._receipts: dict[str, dict[str, Any]] = {}

    def revoke_all(self) -> None:
        self.revocation_generation += 1

    def mutate(
        self,
        *,
        token: str,
        operation: str,
        repository_id: str,
        host_session_id: str,
        idempotency_key: str,
        payload: Mapping[str, Any],
        now: int | None = None,
    ) -> dict[str, Any]:
        capability = verify_capability(
            token,
            self.secret,
            operation=operation,
            repository_id=repository_id,
            host_session_id=host_session_id,
            revocation_generation=self.revocation_generation,
            now=now,
        )
        receipt_id = stable_id(repository_id, operation, idempotency_key)
        previous = self._receipts.get(receipt_id)
        if previous is not None:
            return {**previous, "replayed": True}
        trusted_payload = dict(payload)
        trusted_payload["principal"] = {
            "subject": capability.subject,
            "repository_id": capability.repository_id,
            "host_session_id": capability.host_session_id,
            "consent_id": capability.consent_id,
        }
        result = dict(self.handler(operation, trusted_payload))
        receipt = {
            "ok": bool(result.get("ok")),
            "schema_version": "persistmind.mcp_mutation_receipt.v1",
            "receipt_id": receipt_id,
            "operation": operation,
            "event_id": str(
                result.get("event_id") or stable_id(receipt_id, canonical_json(result))
            ),
            "result": result,
            "replayed": False,
        }
        self._receipts[receipt_id] = receipt
        return receipt


def _pad(value: str) -> bytes:
    return (value + "=" * (-len(value) % 4)).encode()
