from __future__ import annotations

from collections.abc import Mapping
from dataclasses import asdict, dataclass
from typing import Any

from persistmind.runtime_flags import learning_off
from persistmind.utils import canonical_json, sha256_text, stable_id

LEARNING_STAGES = ("offline", "shadow", "proposal-only", "canary")


@dataclass(frozen=True)
class LearningArtifact:
    kind: str
    evidence_snapshot_id: str
    content: Mapping[str, Any]
    stage: str = "proposal-only"

    def __post_init__(self) -> None:
        if self.stage not in LEARNING_STAGES:
            raise ValueError(f"invalid learning stage: {self.stage}")
        if not self.evidence_snapshot_id:
            raise ValueError("learning artifacts require an evidence snapshot")

    @property
    def artifact_id(self) -> str:
        return stable_id(self.kind, self.evidence_snapshot_id, canonical_json(dict(self.content)))

    def document(self) -> dict[str, Any]:
        payload = {**asdict(self), "artifact_id": self.artifact_id}
        payload["artifact_digest"] = sha256_text(canonical_json(payload))
        return payload


class AdoptionCatalog:
    """Small application-domain catalog with atomic pointer-style rollback."""

    def __init__(self) -> None:
        self._artifacts: dict[str, LearningArtifact] = {}
        self._active: dict[str, str] = {}
        self._history: dict[str, list[str]] = {}

    def propose(self, artifact: LearningArtifact) -> dict[str, Any]:
        self._artifacts.setdefault(artifact.artifact_id, artifact)
        return {"ok": True, "status": "proposed", **artifact.document()}

    def adopt(
        self,
        artifact_id: str,
        *,
        principal: Mapping[str, Any],
        sample_count: int,
        minimum_samples: int = 200,
    ) -> dict[str, Any]:
        if learning_off():
            return {"ok": False, "status": "learning_disabled"}
        artifact = self._artifacts.get(artifact_id)
        if artifact is None:
            return {"ok": False, "status": "artifact_not_found"}
        if sample_count < minimum_samples:
            return {
                "ok": False,
                "status": "insufficient_evidence",
                "sample_count": sample_count,
                "minimum_samples": minimum_samples,
            }
        if principal.get("role") not in {"admin", "codeowner"} or not principal.get("subject"):
            return {"ok": False, "status": "approval_required"}
        history = self._history.setdefault(artifact.kind, [])
        current = self._active.get(artifact.kind)
        if current:
            history.append(current)
        self._active[artifact.kind] = artifact_id
        return {"ok": True, "status": "adopted", "artifact_id": artifact_id}

    def rollback(self, kind: str) -> dict[str, Any]:
        history = self._history.get(kind, [])
        if not history:
            return {"ok": False, "status": "previous_artifact_unavailable"}
        previous = history.pop()
        self._active[kind] = previous
        return {"ok": True, "status": "rolled_back", "artifact_id": previous}

    def active(self, kind: str) -> str | None:
        return self._active.get(kind)
