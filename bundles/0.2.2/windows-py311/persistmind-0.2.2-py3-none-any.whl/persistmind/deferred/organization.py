from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from dataclasses import asdict, dataclass
from typing import Any

from persistmind.utils import sha256_text, stable_id

_SECRET = re.compile(r"(?i)(?:token|password|secret|api[_-]?key)\s*[:=]\s*\S+")


@dataclass(frozen=True)
class OrganizationRecord:
    tenant_id: str
    source_id: str
    source_record_id: str
    content: str
    scopes: tuple[str, ...]
    captured_at: str
    trust: str = "untrusted"
    status: str = "quarantined"
    legal_hold: bool = False

    @property
    def record_id(self) -> str:
        return stable_id(self.tenant_id, self.source_id, self.source_record_id)

    def document(self) -> dict[str, Any]:
        return {
            **asdict(self),
            "record_id": self.record_id,
            "content": _SECRET.sub("[REDACTED]", self.content),
            "content_sha256": sha256_text(self.content),
        }


class OrganizationQuarantine:
    def __init__(self) -> None:
        self._records: dict[str, OrganizationRecord] = {}
        self._cache: dict[tuple[str, tuple[str, ...]], list[str]] = {}

    def import_records(self, records: Iterable[OrganizationRecord]) -> dict[str, Any]:
        count = 0
        for record in records:
            self._records[record.record_id] = record
            count += 1
        self._cache.clear()
        return {"ok": True, "status": "quarantined", "imported": count}

    def query(self, principal: Mapping[str, Any], text: str = "") -> dict[str, Any]:
        tenant = str(principal.get("tenant_id") or "")
        scopes = tuple(sorted({str(item) for item in principal.get("scopes", [])}))
        if not tenant or not scopes:
            return {"ok": False, "status": "verified_scope_required", "items": [], "count": 0}
        key = (tenant, scopes)
        ids = self._cache.get(key)
        if ids is None:
            granted = set(scopes)
            ids = sorted(
                record.record_id
                for record in self._records.values()
                if record.tenant_id == tenant and granted.intersection(record.scopes)
            )
            self._cache[key] = ids
        needle = text.casefold()
        items = [
            self._records[record_id].document()
            for record_id in ids
            if not needle or needle in self._records[record_id].content.casefold()
        ]
        return {"ok": True, "status": "advisory", "items": items, "count": len(items)}

    def delete_source(self, tenant_id: str, source_id: str) -> dict[str, Any]:
        removed = [
            record_id
            for record_id, record in self._records.items()
            if record.tenant_id == tenant_id
            and record.source_id == source_id
            and not record.legal_hold
        ]
        for record_id in removed:
            del self._records[record_id]
        self._cache.clear()
        return {"ok": True, "removed": len(removed), "derived_cache_cleared": True}

    def apply_retention(self, tenant_id: str, *, before: str) -> dict[str, Any]:
        removed = [
            record_id
            for record_id, record in self._records.items()
            if record.tenant_id == tenant_id
            and record.captured_at < before
            and not record.legal_hold
        ]
        for record_id in removed:
            del self._records[record_id]
        self._cache.clear()
        return {"ok": True, "removed": len(removed), "legal_holds_preserved": True}

    def export(self, principal: Mapping[str, Any]) -> dict[str, Any]:
        result = self.query(principal)
        return {
            **result,
            "schema_version": "persistmind.organization_export.v1",
            "export_scope": {
                "tenant_id": principal.get("tenant_id"),
                "scopes": sorted(principal.get("scopes", [])),
            },
        }
