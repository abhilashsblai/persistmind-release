"""Bounded contracts for capabilities promoted beyond the core-local product."""

from persistmind.deferred.contracts import (
    CAPABILITY_REGISTRY,
    CapabilityDescriptor,
    CapabilityGuard,
    CapabilityResult,
    ResourceBudget,
    capability_registry_document,
)

__all__ = [
    "CAPABILITY_REGISTRY",
    "CapabilityDescriptor",
    "CapabilityGuard",
    "CapabilityResult",
    "ResourceBudget",
    "capability_registry_document",
]
