from __future__ import annotations

import ipaddress
import threading
import time
from dataclasses import dataclass
from typing import Any, Iterable


@dataclass(frozen=True)
class VerifiedTeamPrincipal:
    subject: str
    tenant_id: str
    repository_ids: tuple[str, ...]
    roles: tuple[str, ...]
    issuer: str
    audience: str


def verify_oidc_token(
    token: str,
    *,
    key: Any,
    issuer: str,
    audience: str,
    algorithms: Iterable[str] = ("RS256",),
) -> VerifiedTeamPrincipal:
    import jwt

    claims = jwt.decode(
        token,
        key=key,
        algorithms=list(algorithms),
        issuer=issuer,
        audience=audience,
        options={"require": ["exp", "iat", "iss", "aud", "sub", "tenant_id"]},
    )
    repositories = tuple(sorted({str(item) for item in claims.get("repository_ids", [])}))
    roles = tuple(sorted({str(item) for item in claims.get("roles", [])}))
    return VerifiedTeamPrincipal(
        subject=str(claims["sub"]),
        tenant_id=str(claims["tenant_id"]),
        repository_ids=repositories,
        roles=roles,
        issuer=issuer,
        audience=audience,
    )


def team_bind_policy(
    *,
    profile: str,
    auth: str,
    host: str,
    reverse_proxy_tls: bool,
    remote_bind_authorized: bool,
) -> dict[str, Any]:
    reasons: list[str] = []
    if profile != "team-preview":
        reasons.append("team_profile_required")
    if auth != "oidc":
        reasons.append("oidc_required")
    if not reverse_proxy_tls:
        reasons.append("tls_proxy_required")
    try:
        is_loopback = ipaddress.ip_address(host).is_loopback
    except ValueError:
        is_loopback = host.casefold() == "localhost"
    if not is_loopback and not remote_bind_authorized:
        reasons.append("remote_bind_authority_required")
    return {
        "ok": not reasons,
        "schema_version": "persistmind.team_bind_policy.v1",
        "status": "allowed" if not reasons else "refused",
        "reasons": reasons,
        "read_only": True,
    }


def authorize_team_read(
    principal: VerifiedTeamPrincipal, *, tenant_id: str, repository_id: str
) -> bool:
    return principal.tenant_id == tenant_id and repository_id in principal.repository_ids


class TeamRateLimiter:
    """Thread-safe fixed-window limiter scoped by verified tenant identity."""

    def __init__(self, requests: int = 120, window_seconds: float = 60.0) -> None:
        if requests <= 0 or window_seconds <= 0:
            raise ValueError("team rate limit budgets must be positive")
        self.requests = requests
        self.window_seconds = window_seconds
        self._lock = threading.Lock()
        self._windows: dict[str, tuple[float, int]] = {}

    def allow(self, tenant_id: str, *, now: float | None = None) -> bool:
        if not tenant_id:
            return False
        observed = time.monotonic() if now is None else now
        with self._lock:
            started, count = self._windows.get(tenant_id, (observed, 0))
            if observed - started >= self.window_seconds:
                started, count = observed, 0
            if count >= self.requests:
                self._windows[tenant_id] = (started, count)
                return False
            self._windows[tenant_id] = (started, count + 1)
            return True
