from __future__ import annotations

import builtins
import json
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any

from persistmind.branding import (
    NO_REGISTRY_ENV,
    canonical_user_home,
    resolve_project_state,
)
from persistmind.utils import utc_now

# Global, cross-project registry of where PersistMind is installed/updated.
#
# PersistMind's per-project state lives in each repo's `.persistmind/`, so the engine otherwise has
# no way to enumerate the projects it manages. This registry is the one piece of user-level
# (home-directory) state: a small JSON file recording every project that has been installed or
# updated, so `persistmind registry list` / the GUI can track them and rollups can be collected
# across deployments.
#
# Location precedence: $PERSISTMIND_HOME, else %APPDATA%\PersistMind (Windows),
# else ~/.persistmind.

SCHEMA_VERSION = "persistmind.project_registry.v2"
READABLE_SCHEMA_VERSIONS = {"persistmind.project_registry.v1", SCHEMA_VERSION}


class RegistryCorruptError(RuntimeError):
    status = "validation_failed"

    def __init__(self, path: Path, backup: Path, detail: str):
        super().__init__(f"project registry is corrupt: {detail}; original preserved at {backup}")
        self.path = path
        self.backup = backup


def registry_home() -> Path:
    return canonical_user_home()


def registry_disabled() -> bool:
    """Allow opting out of all registry writes (privacy / CI)."""
    return os.environ.get(NO_REGISTRY_ENV, "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _normalize(path: str | os.PathLike[str]) -> str:
    try:
        return str(Path(path).resolve())
    except OSError:
        return str(Path(path))


def is_temp_project_path(path: str | os.PathLike[str]) -> bool:
    """Return true for pytest/temp projects that should not clutter fleet views."""
    normalized = _normalize(path)
    lowered = normalized.lower()
    candidates = {
        tempfile.gettempdir(),
        os.environ.get("TMP", ""),
        os.environ.get("TEMP", ""),
    }
    local_appdata = os.environ.get("LOCALAPPDATA")
    if local_appdata:
        candidates.add(str(Path(local_appdata) / "Temp"))
    for candidate in candidates:
        if not candidate:
            continue
        root = _normalize(candidate).lower().rstrip("\\/")
        if lowered == root or lowered.startswith(root + os.sep.lower()):
            return True
    parts = {part.lower() for part in Path(normalized).parts}
    return any(part.startswith("pytest-") for part in parts) or "pytest-of-" in parts


def path_under_root(path: str | os.PathLike[str], root: str | os.PathLike[str] | None) -> bool:
    if not root:
        return True
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except (OSError, ValueError):
        return False


class ProjectRegistry:
    def __init__(self, home: Path | None = None):
        self.home = home or registry_home()
        self.path = self.home / "projects.json"

    # ----- persistence ----------------------------------------------------
    def _load(self) -> dict[str, Any]:
        if not self.path.is_file():
            return {"schema_version": SCHEMA_VERSION, "projects": {}}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError, OSError) as exc:
            raise self._quarantine(str(exc)) from exc
        if not isinstance(data, dict) or not isinstance(data.get("projects"), dict):
            raise self._quarantine("root must contain an object-valued projects field")
        schema_version = data.get("schema_version")
        if schema_version in READABLE_SCHEMA_VERSIONS:
            data = self._migrate(data)
        elif schema_version != SCHEMA_VERSION:
            raise self._quarantine("unsupported or missing schema_version")
        return data

    def _migrate(self, data: dict[str, Any]) -> dict[str, Any]:
        migrated: dict[str, Any] = {"schema_version": SCHEMA_VERSION, "projects": {}}
        for key, value in data.get("projects", {}).items():
            if not isinstance(value, dict):
                continue
            migrated["projects"][key] = {
                **value,
                "channel": value.get("channel"),
                "wheel_sha256": value.get("wheel_sha256"),
                "slot": value.get("slot"),
                "release_tag": value.get("release_tag"),
                "transaction_id": value.get("transaction_id"),
                "bootstrap_version": value.get("bootstrap_version"),
                "last_attempted_update": value.get("last_attempted_update"),
                "last_successful_update": value.get("last_successful_update"),
                "restart_required": value.get("restart_required", []),
            }
        self._save(migrated)
        return migrated

    def _quarantine(self, detail: str) -> RegistryCorruptError:
        quarantine = self.home / "quarantine"
        quarantine.mkdir(parents=True, exist_ok=True)
        stamp = utc_now().replace(":", "-")
        backup = quarantine / f"projects.{stamp}.corrupt.json"
        shutil.copy2(self.path, backup)
        return RegistryCorruptError(self.path, backup, detail)

    def _save(self, data: dict[str, Any]) -> None:
        self.home.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            previous = self.home / "projects.previous.json"
            shutil.copy2(self.path, previous)
        # Atomic write so a crash never leaves a half-written registry.
        fd, tmp = tempfile.mkstemp(prefix="projects-", suffix=".json", dir=str(self.home))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(data, handle, indent=2, sort_keys=True)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp, self.path)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)

    # ----- operations -----------------------------------------------------
    def register(
        self,
        path: str | os.PathLike[str],
        *,
        label: str | None = None,
        repo_id: str | None = None,
        engine_version: str | None = None,
        action: str = "install",
        now: str | None = None,
        channel: str | None = None,
        wheel_sha256: str | None = None,
        slot: str | None = None,
        release_tag: str | None = None,
        transaction_id: str | None = None,
        bootstrap_version: str | None = None,
        restart_required: list[str] | None = None,
    ) -> dict[str, Any]:
        """Upsert a project. Records first_seen once, then updates on every install/update."""
        key = _normalize(path)
        stamp = now or utc_now()
        data = self._load()
        projects = data["projects"]
        existing = projects.get(key, {})
        record = {
            "path": key,
            "label": label or existing.get("label") or Path(key).name,
            "repo_id": repo_id or existing.get("repo_id"),
            "engine_version": engine_version or existing.get("engine_version"),
            "first_seen": existing.get("first_seen", stamp),
            "last_action": action,
            "last_updated": stamp,
            "install_count": int(existing.get("install_count", 0))
            + (1 if action == "install" else 0),
            "update_count": int(existing.get("update_count", 0)) + (1 if action == "update" else 0),
            "channel": channel or existing.get("channel"),
            "wheel_sha256": wheel_sha256 or existing.get("wheel_sha256"),
            "slot": slot or existing.get("slot"),
            "release_tag": release_tag or existing.get("release_tag"),
            "transaction_id": transaction_id or existing.get("transaction_id"),
            "bootstrap_version": bootstrap_version or existing.get("bootstrap_version"),
            "last_attempted_update": stamp
            if action in {"update", "rollback"}
            else existing.get("last_attempted_update"),
            "last_successful_update": stamp
            if action == "update"
            else existing.get("last_successful_update"),
            "restart_required": restart_required
            if restart_required is not None
            else existing.get("restart_required", []),
        }
        projects[key] = record
        data["schema_version"] = SCHEMA_VERSION
        self._save(data)
        return record

    def list(self) -> list[dict[str, Any]]:
        data = self._load()
        return [data["projects"][key] for key in sorted(data["projects"])]

    def remove(self, path: str | os.PathLike[str]) -> bool:
        key = _normalize(path)
        data = self._load()
        if key in data["projects"]:
            del data["projects"][key]
            self._save(data)
            return True
        return False

    def record_for(self, path: str | os.PathLike[str]) -> dict[str, Any] | None:
        value = self._load()["projects"].get(_normalize(path))
        return dict(value) if isinstance(value, dict) else None

    def restore_record(self, path: str | os.PathLike[str], record: dict[str, Any] | None) -> None:
        """Restore an exact updater snapshot without incrementing counters."""
        key = _normalize(path)
        data = self._load()
        if record is None:
            data["projects"].pop(key, None)
        else:
            data["projects"][key] = dict(record)
        self._save(data)

    def prune(self) -> builtins.list[str]:
        """Drop entries whose project no longer has PersistMind state."""
        data = self._load()
        removed: list[str] = []
        for key in list(data["projects"]):
            if not resolve_project_state(Path(key)).is_dir():
                del data["projects"][key]
                removed.append(key)
        if removed:
            self._save(data)
        return removed
