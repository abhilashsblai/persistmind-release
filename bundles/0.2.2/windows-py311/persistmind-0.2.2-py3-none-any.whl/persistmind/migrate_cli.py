from __future__ import annotations

import argparse
import json
from pathlib import Path

from persistmind.storage.migration.program import OfflineWorkspaceMigrator, migrate_document


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="persistmind-migrate",
        description="Offline one-way migration to persistmind-nextgen-v1 storage.",
    )
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--target", required=True, type=Path)
    parser.add_argument("--migration-id", required=True)
    parser.add_argument("--development-driver", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    result = OfflineWorkspaceMigrator(args.source, args.target).migrate(
        migration_id=args.migration_id,
        allow_development_driver=bool(args.development_driver),
    )
    print(json.dumps(migrate_document(result), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
