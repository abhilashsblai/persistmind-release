from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Any

from persistmind.updater.atomic import read_json, write_json
from persistmind.branding import PROJECT_STATE_DIR, resolve_project_state
from persistmind.utils import utc_now


def _target_protocol() -> int:
    value = int(os.environ.get("PERSISTMIND_TARGET_PROJECT_PROTOCOL", "1"))
    if value not in {1, 2}:
        raise ValueError(f"unsupported target project protocol: {value}")
    return value


def plan_upgrade(repo: Path) -> dict[str, Any]:
    repo = repo.resolve()
    state = resolve_project_state(repo)
    if not state.is_dir():
        raise ValueError(f"project has no {PROJECT_STATE_DIR} installation")
    profile = read_json(state / "setup-profile.json") or {}
    legacy = state / "workspace.db"
    nextgen_active = (state / "catalog" / "current.json").is_file()
    from persistmind.agent_runtime.protocol import active_project_protocol

    current_protocol = active_project_protocol(state)
    target_protocol = _target_protocol()
    migration = legacy.is_file() and not nextgen_active
    database_bytes = sum(path.stat().st_size for path in state.rglob("*.db") if path.is_file())
    free = shutil.disk_usage(repo).free
    required = max(database_bytes * 2, 16 * 1024 * 1024)
    migration_plan: dict[str, Any] | None = None
    schema_upgrade_plan: dict[str, Any] | None = None
    mutation_roots = (
        "anchors",
        "backups",
        "catalog",
        "locks",
        "migration",
        "objects",
        "operations",
        "quarantine",
        "runtime",
        "stores",
        "updates",
    )
    if migration:
        from persistmind.storage.migration.program import OfflineWorkspaceMigrator

        program = OfflineWorkspaceMigrator(legacy, state)
        storage_plan = program.plan()
        required = max(legacy.stat().st_size * 5, storage_plan.required_free_bytes)
        migration_plan = {
            "from": "monolith-v1",
            "to": "persistmind-nextgen-v1",
            "authoritative_tables": sum(
                1 for unit in storage_plan.units if unit.disposition == "copy"
            ),
            "rebuildable_tables": sum(
                1 for unit in storage_plan.units if unit.disposition != "copy"
            ),
            "source_fingerprint": program.source_fingerprint(),
        }
    elif nextgen_active:
        from persistmind.storage.schema_upgrade import NextgenSchemaService

        candidate = NextgenSchemaService(state).plan()
        if candidate["steps"]:
            schema_upgrade_plan = candidate
    if free < required:
        raise OSError(f"insufficient disk space: need {required} bytes, have {free}")
    # Protocol v1 only permits candidate operations whose mutations stay in
    # project state and are covered by the updater's verified backup. Generated
    # agent surfaces remain unchanged until a later protocol declares them.
    return {
        "ok": True,
        "status": "plan_ready",
        "schema_version": "persistmind.project_upgrade_plan.v2",
        "repo": str(repo),
        "created_at": utc_now(),
        "database_migrations": [migration_plan] if migration_plan else [],
        "schema_upgrade": schema_upgrade_plan,
        "protocol_upgrade": {
            "from": current_protocol,
            "to": target_protocol,
            "required": target_protocol > current_protocol,
            "activation": "verified-backup-then-atomic-marker-and-runtime-epoch",
        },
        "generated_surface_changes": [],
        "index_required": migration,
        "required_disk_bytes": required,
        "processes_to_stop": [],
        "rollback": {"requires_verified_project_backup": True},
        "setup_profile_present": bool(profile),
        "created_roots": [name for name in mutation_roots if not (state / name).exists()],
    }


def apply_upgrade(
    repo: Path, transaction_id: str, *, allow_development_driver: bool = False
) -> dict[str, Any]:
    plan = plan_upgrade(repo)
    root = resolve_project_state(repo)
    before = {path.relative_to(root).as_posix() for path in root.rglob("*")}
    migration_result: dict[str, Any] | None = None
    schema_upgrade_result: dict[str, Any] | None = None
    index_result: dict[str, Any] | None = None
    protocol_result: dict[str, Any] | None = None
    protocol_migration = None
    protocol_prepared: dict[str, Any] | None = None
    if plan["protocol_upgrade"]["required"]:
        from persistmind import __version__
        from persistmind.agent_runtime.protocol import ProjectProtocolMigration

        backup_root_value = os.environ.get("PERSISTMIND_PROTOCOL_BACKUP_ROOT")
        if not backup_root_value:
            backup_root_value = str(repo.parent / ".persistmind-protocol-backups")
        protocol_migration = ProjectProtocolMigration(root, Path(backup_root_value))
        protocol_prepared = protocol_migration.prepare(
            transaction_id,
            from_version=int(plan["protocol_upgrade"]["from"]),
            to_version=int(plan["protocol_upgrade"]["to"]),
            engine_version=__version__,
        )
    if plan["database_migrations"]:
        from dataclasses import asdict

        from persistmind.storage.migration.program import OfflineWorkspaceMigrator

        legacy = root / "workspace.db"
        result = OfflineWorkspaceMigrator(legacy, root).migrate(
            migration_id=transaction_id,
            allow_development_driver=allow_development_driver,
        )
        migration_result = asdict(result)
        from persistmind.storage.source_service import SourceService

        with SourceService(
            repo.resolve(), allow_development_driver=allow_development_driver
        ) as source:
            try:
                index_result = source.build()
            except ValueError as exc:
                if not str(exc).startswith("source generation exceeds "):
                    raise
                index_result = {
                    "ok": True,
                    "status": "deferred",
                    "schema_version": "persistmind.source_rebuild_deferred.v1",
                    "reason": str(exc),
                    "remediation": (
                        "Review repository ignores or source-index budgets, then run "
                        "persistmind --repo . index. Durable migrated data is already active."
                    ),
                }
    if plan["schema_upgrade"]:
        from persistmind.storage.schema_upgrade import NextgenSchemaService

        schema_upgrade_result = NextgenSchemaService(root).apply(
            plan["schema_upgrade"],
            allow_development_driver=allow_development_driver,
        )
    if protocol_migration is not None:
        from persistmind.storage.agent_runtime_ports import AgentRuntimePorts

        with AgentRuntimePorts(
            repo,
            allow_development_driver=allow_development_driver,
            require_protocol_v2=False,
        ) as ports:
            if protocol_prepared is None:
                raise RuntimeError("protocol migration preparation evidence is absent")
            ports.task.put_protocol_migration(
                {
                    **protocol_prepared,
                    "backup_id": str(protocol_prepared["backup"]),
                    "from_epoch": 1,
                    "to_epoch": 2,
                    "started_at": protocol_prepared["updated_at"],
                }
            )
            protocol_result = protocol_migration.activate(
                transaction_id, activate_epoch=ports.task.activate_epoch
            )
            ports.task.update_protocol_migration(transaction_id, state="complete")
    marker = root / "updates" / f"{transaction_id}.json"
    write_json(
        marker,
        {
            "schema_version": "persistmind.project_upgrade_application.v2",
            "transaction_id": transaction_id,
            "applied_at": utc_now(),
            "plan": plan,
            "migration": migration_result,
            "schema_upgrade": schema_upgrade_result,
            "protocol": protocol_result,
            "index": index_result,
        },
    )
    after = {path.relative_to(root).as_posix() for path in root.rglob("*")}
    created_paths = sorted(after - before, key=lambda value: (value.count("/"), value))
    return {
        "ok": True,
        "status": "applied",
        "schema_version": "persistmind.project_upgrade_result.v2",
        "transaction_id": transaction_id,
        "created_paths": created_paths,
        "migration": migration_result,
        "schema_upgrade": schema_upgrade_result,
        "protocol": protocol_result,
        "index": index_result,
    }


def verify_upgrade(repo: Path, transaction_id: str) -> dict[str, Any]:
    root = resolve_project_state(repo)
    marker = root / "updates" / f"{transaction_id}.json"
    value = read_json(marker)
    if value is None or value.get("transaction_id") != transaction_id:
        raise ValueError("candidate project-upgrade marker is missing or invalid")
    migration = value.get("migration")
    protocol = value.get("protocol")
    schema_upgrade = value.get("schema_upgrade")
    applied_plan = value.get("plan") or {}
    planned_schema_upgrade = applied_plan.get("schema_upgrade")
    if planned_schema_upgrade and not schema_upgrade:
        raise ValueError("candidate project schema upgrade result is missing")
    if planned_schema_upgrade:
        assert schema_upgrade is not None
        if schema_upgrade.get("plan_hash") != planned_schema_upgrade.get("plan_hash"):
            raise ValueError("candidate project schema upgrade result does not match its plan")
    if migration or planned_schema_upgrade:
        from persistmind.storage.catalog import FileCatalog
        from persistmind.storage.bootstrap import validate_nextgen_manifest

        manifest = FileCatalog(root / "catalog").current()
        validate_nextgen_manifest(manifest)
        from persistmind.storage.schema_upgrade import NextgenSchemaService

        NextgenSchemaService(root).verify()
    if migration:
        from persistmind.storage.migration.program import OfflineWorkspaceMigrator

        if OfflineWorkspaceMigrator(
            root / "workspace.db", root
        ).source_fingerprint() != migration.get("source_fingerprint"):
            raise ValueError("legacy source fingerprint changed after migration")
    if applied_plan.get("protocol_upgrade", {}).get("required"):
        from persistmind.agent_runtime.protocol import active_project_protocol

        if not protocol or protocol.get("state") != "complete":
            raise ValueError("candidate project protocol activation result is missing")
        if active_project_protocol(root) != int(applied_plan["protocol_upgrade"]["to"]):
            raise ValueError("candidate project protocol activation does not verify")
    return {
        "ok": True,
        "status": "verified",
        "schema_version": "persistmind.project_upgrade_result.v2",
        "transaction_id": transaction_id,
    }
