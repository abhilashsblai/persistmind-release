from typing import Any

__all__ = ["VerificationRunner"]


def __getattr__(name: str) -> Any:
    if name == "VerificationRunner":
        from .runner import VerificationRunner

        return VerificationRunner
    raise AttributeError(name)
