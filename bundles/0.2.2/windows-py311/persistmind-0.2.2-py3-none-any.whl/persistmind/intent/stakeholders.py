from __future__ import annotations

from pathlib import Path
from typing import Any

from persistmind.linking import owners_for_path, parse_codeowners
from persistmind.utils import stable_id


def map_stakeholders(
    *,
    repo_root: Path,
    store: Any,
    repo_id: str,
    intent_id: str,
    evidence: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    ownership_rows = [dict(row) for row in store.ownership(repo_id)]
    if not ownership_rows:
        ownership_rows = parse_codeowners(repo_root)
    by_owner: dict[str, set[str]] = {}
    source_by_owner: dict[str, str] = {}
    for row in evidence:
        path = str(row.get("path") or row["ref"])
        owners = owners_for_path(path, ownership_rows)
        if not owners:
            owners = ["repo-owner"]
            source_by_owner.setdefault("repo-owner", "fallback")
        for owner in owners:
            by_owner.setdefault(owner, set()).add(path)
            source_by_owner.setdefault(owner, "codeowners")
    return [
        {
            "stakeholder_id": stable_id(
                "intent_stakeholder", intent_id, owner, ",".join(sorted(files))
            ),
            "intent_id": intent_id,
            "owner": owner,
            "files": sorted(files),
            "reason": (
                "owns impacted file"
                if source_by_owner.get(owner) != "fallback"
                else "fallback owner"
            ),
            "source": source_by_owner.get(owner, "codeowners"),
            "confidence": 1.0 if source_by_owner.get(owner) != "fallback" else 0.4,
        }
        for owner, files in sorted(by_owner.items())
    ]
