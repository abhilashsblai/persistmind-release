from __future__ import annotations

from typing import Any

from persistmind.impact import ImpactReporter
from persistmind.snapshot import SnapshotInfo
from persistmind.utils import stable_id, utc_now


def rank_hypotheses(
    *,
    store: Any,
    impact: ImpactReporter,
    snapshot: SnapshotInfo,
    intent_id: str,
    problem: str,
    evidence: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    paths = sorted({str(row["path"]) for row in evidence if row.get("path")})
    impact_report = impact.report(snapshot=snapshot, paths=paths) if paths else {}
    critical = set((impact_report.get("risk") or {}).get("critical_paths") or [])
    untested = set((impact_report.get("risk") or {}).get("untested_paths") or [])
    impacted = set(impact_report.get("impacted_paths") or [])
    rows: list[dict[str, Any]] = []
    for idx, row in enumerate(evidence[:5], start=1):
        path = str(row.get("path") or row["ref"])
        churn = store.churn_for_path(snapshot.repo_id, path)
        churn_commits = int(churn["commits"] or 0) if churn else 0
        confidence = 0.55 + min(0.2, churn_commits / 100.0)
        if path in critical:
            confidence += 0.1
        if path in untested:
            confidence += 0.05
        if path in impacted:
            confidence += 0.05
        rows.append(
            {
                "hypothesis_id": stable_id("intent_hypothesis", intent_id, path),
                "intent_id": intent_id,
                "statement": f"{path} is a likely root-cause area for: {problem}",
                "origin": "deterministic",
                "confidence": round(min(1.0, confidence), 4),
                "rank": idx,
                "verified": False,
                "evidence_refs": [row["evidence_id"]],
                "signals": {
                    "impact": {
                        "impacted": path in impacted,
                        "critical": path in critical,
                        "untested": path in untested,
                    },
                    "churn": {"commits": churn_commits},
                },
                "created_at": utc_now(),
            }
        )
    if not rows:
        rows.append(
            {
                "hypothesis_id": stable_id("intent_hypothesis", intent_id, "unverified"),
                "intent_id": intent_id,
                "statement": f"Insufficient local evidence to rank a root cause for: {problem}",
                "origin": "deterministic",
                "confidence": 0.25,
                "rank": 1,
                "verified": False,
                "evidence_refs": [],
                "signals": {"impact": {}, "churn": {}},
                "created_at": utc_now(),
            }
        )
    return rows
