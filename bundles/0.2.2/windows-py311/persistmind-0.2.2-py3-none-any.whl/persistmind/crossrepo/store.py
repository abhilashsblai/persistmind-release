from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


class WorkspaceContractStore:
    """Durable adapter for the cross-repo WorkspaceManager store protocol."""

    def __init__(self, workspace_root: Path) -> None:
        self.workspace_root = workspace_root.resolve()
        self.path = self.workspace_root / "crossrepo" / "workspace.json"

    def add_workspace_repo(
        self, *, workspace_root: str, repo_id: str, name: str, root_path: str
    ) -> str:
        state = self._read()
        row_id = "workspace-repo-" + repo_id
        repos = [
            repo
            for repo in state["repos"]
            if not (
                repo.get("workspace_root") == workspace_root
                and repo.get("repo_id") == repo_id
            )
        ]
        repos.append(
            {
                "workspace_repo_id": row_id,
                "workspace_root": workspace_root,
                "repo_id": repo_id,
                "name": name,
                "root_path": root_path,
            }
        )
        state["repos"] = sorted(repos, key=lambda item: str(item.get("repo_id") or ""))
        self._write(state)
        return row_id

    def workspace_repos(self, workspace_root: str) -> list[dict[str, Any]]:
        return [
            dict(repo)
            for repo in self._read()["repos"]
            if repo.get("workspace_root") == workspace_root
        ]

    def replace_contracts(self, *, repo_id: str, contracts: list[dict[str, Any]]) -> None:
        state = self._read()
        state["contracts"] = [
            contract for contract in state["contracts"] if contract.get("repo_id") != repo_id
        ] + [dict(contract) for contract in contracts]
        state["contracts"].sort(
            key=lambda item: (
                str(item.get("repo_id") or ""),
                str(item.get("kind") or ""),
                str(item.get("name") or ""),
                str(item.get("path") or ""),
            )
        )
        self._write(state)

    def contracts(self) -> list[dict[str, Any]]:
        return [dict(contract) for contract in self._read()["contracts"]]

    def put_edge(
        self,
        *,
        scope_snapshot_id: str | None,
        src_repo_id: str,
        src_node_type: str,
        src_node_id: str,
        dst_repo_id: str,
        dst_node_type: str,
        dst_node_id: str,
        kind: str,
        confidence: float,
        metadata: dict[str, Any],
    ) -> None:
        state = self._read()
        edge = {
            "scope_snapshot_id": scope_snapshot_id,
            "src_repo_id": src_repo_id,
            "src_node_type": src_node_type,
            "src_node_id": src_node_id,
            "dst_repo_id": dst_repo_id,
            "dst_node_type": dst_node_type,
            "dst_node_id": dst_node_id,
            "kind": kind,
            "confidence": float(confidence),
            "metadata": dict(metadata),
        }
        state["edges"] = [
            existing
            for existing in state["edges"]
            if _edge_key(existing) != _edge_key(edge)
        ] + [edge]
        state["edges"].sort(key=_edge_key)
        self._write(state)

    def replace_edges(self, edges: list[dict[str, Any]]) -> None:
        state = self._read()
        state["edges"] = [dict(edge) for edge in edges]
        state["edges"].sort(key=_edge_key)
        self._write(state)

    def logical_edges(
        self, where: str, params: tuple[str, ...] = ()
    ) -> list[dict[str, Any]]:
        edges = [dict(edge) for edge in self._read()["edges"]]
        if where == "src_repo_id != dst_repo_id":
            return [edge for edge in edges if edge.get("src_repo_id") != edge.get("dst_repo_id")]
        if where == "src_repo_id = ? AND src_repo_id != dst_repo_id":
            repo_id = params[0] if params else ""
            return [
                edge
                for edge in edges
                if edge.get("src_repo_id") == repo_id
                and edge.get("src_repo_id") != edge.get("dst_repo_id")
            ]
        return edges

    def _read(self) -> dict[str, list[dict[str, Any]]]:
        if not self.path.exists():
            return {"repos": [], "contracts": [], "edges": []}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return {"repos": [], "contracts": [], "edges": []}
        return {
            "repos": [dict(item) for item in data.get("repos", []) if isinstance(item, dict)],
            "contracts": [
                dict(item) for item in data.get("contracts", []) if isinstance(item, dict)
            ],
            "edges": [dict(item) for item in data.get("edges", []) if isinstance(item, dict)],
        }

    def _write(self, state: dict[str, list[dict[str, Any]]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_name(f".{self.path.name}.{os.getpid()}.tmp")
        try:
            temporary.write_text(
                json.dumps(state, sort_keys=True, separators=(",", ":")),
                encoding="utf-8",
            )
            os.replace(temporary, self.path)
        finally:
            temporary.unlink(missing_ok=True)


def _edge_key(edge: dict[str, Any]) -> tuple[str, str, str, str, str]:
    return (
        str(edge.get("src_repo_id") or ""),
        str(edge.get("src_node_id") or ""),
        str(edge.get("dst_repo_id") or ""),
        str(edge.get("dst_node_id") or ""),
        str(edge.get("kind") or ""),
    )


__all__ = ["WorkspaceContractStore"]
