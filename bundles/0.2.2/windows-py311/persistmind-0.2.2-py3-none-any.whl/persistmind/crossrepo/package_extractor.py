from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def extract(repo_root: Path) -> list[dict[str, Any]]:
    contracts: list[dict[str, Any]] = []
    package_json = repo_root / "package.json"
    if package_json.exists():
        data = json.loads(package_json.read_text(encoding="utf-8"))
        if data.get("name"):
            contracts.append(
                {
                    "path": "package.json",
                    "kind": "provides_package",
                    "name": str(data["name"]),
                    "metadata": {"version": data.get("version")},
                }
            )
        for dep in sorted({**data.get("dependencies", {}), **data.get("devDependencies", {})}):
            contracts.append(
                {
                    "path": "package.json",
                    "kind": "depends_on_package",
                    "name": dep,
                    "metadata": {},
                }
            )
    pyproject = repo_root / "pyproject.toml"
    if pyproject.exists():
        text = pyproject.read_text(encoding="utf-8", errors="replace")
        if 'name = "' in text:
            name = text.split('name = "', 1)[1].split('"', 1)[0]
            contracts.append(
                {
                    "path": "pyproject.toml",
                    "kind": "provides_package",
                    "name": name,
                    "metadata": {},
                }
            )
    return contracts
