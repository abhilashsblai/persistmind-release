from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, Protocol

Document = Mapping[str, Any]


class ControlApplicationPort(Protocol):
    def status(self) -> Document: ...

    def verify(self, *, full: bool = False) -> Document: ...

    def doctor(self) -> Document: ...


class SourceApplicationPort(Protocol):
    def source_status(self) -> Document: ...

    def search(self, query: str, *, limit: int = 20) -> Document: ...

    def impact(self, paths: Sequence[str]) -> Document: ...


class TaskApplicationPort(Protocol):
    def task_show(self, task_session_id: str) -> Document: ...

    def plan_show(self, plan_id: str) -> Document: ...

    def continuation_search(self, task: str, *, limit: int = 20) -> Document: ...


class ActivityApplicationPort(Protocol):
    def activity_events(self, *, limit: int = 100) -> Document: ...

    def activity_event(self, event_id: str) -> Document: ...


class AuditApplicationPort(Protocol):
    def get_audit_record(self, record_id: str) -> Document: ...

    def verify_audit(self) -> Document: ...


class KnowledgeApplicationPort(Protocol):
    def memory_search(
        self,
        query: str,
        types: Sequence[str] | None = None,
        status: str | None = None,
    ) -> Document: ...

    def memory_show(self, record_id: str) -> Document: ...


class PolicyApplicationPort(Protocol):
    def policy_applicable(self, scope: str) -> Document: ...

    def constitution_check(self, paths: Sequence[str]) -> Document: ...


class LearningApplicationPort(Protocol):
    def learning_active_manifest(self) -> Document: ...

    def learning_versions(self, skill_id: str | None = None) -> Document: ...


class PackApplicationPort(Protocol):
    def get_pack_manifest(self, pack_id: str) -> Document: ...

    def reconstruct_pack(self, pack_id: str, task_text: str | None = None) -> Document: ...


class ReleaseApplicationPort(Protocol):
    def status(self) -> Document: ...

    def validate(self) -> Document: ...
