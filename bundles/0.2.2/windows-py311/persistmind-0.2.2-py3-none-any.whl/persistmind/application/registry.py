from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from importlib import resources
from typing import Any, Protocol

CATALOG_SCHEMA_VERSION = "persistmind.operation_catalog.v2"
VALID_OWNERS = frozenset(
    {
        "control",
        "source",
        "task",
        "activity",
        "audit",
        "knowledge",
        "policy",
        "learning",
        "composite",
    }
)
VALID_ROLES = frozenset(
    {
        "control",
        "source_manifest",
        "source_segment",
        "task_state",
        "activity_active",
        "activity_sealed",
        "audit_active",
        "audit_sealed",
        "knowledge",
        "policy",
        "learning",
    }
)


class OperationMode(StrEnum):
    QUERY = "query"
    COMMAND = "command"


class OperationAvailability(StrEnum):
    ACTIVE = "active"
    DEFERRED = "deferred"
    DEPRECATED = "deprecated"
    RETIRED = "retired"
    INTERNAL = "internal"


@dataclass(frozen=True, slots=True)
class OperationDescriptor:
    operation_id: str
    canonical_operation: str
    aliases: tuple[str, ...]
    feature_id: str
    owner: str
    mode: OperationMode
    handler: str | None
    request_schema: str
    response_schema: str
    error_contracts: tuple[str, ...]
    writer_role: str | None
    reader_roles: tuple[str, ...]
    projection_consumers: tuple[str, ...]
    required_roles: tuple[str, ...]
    scope_policy: str
    capabilities: tuple[str, ...]
    risk_floor: str
    autonomy_ceiling: str
    maturity: str
    availability: OperationAvailability
    disposition: str
    authorization_action: str
    transports: tuple[str, ...]
    transport_bindings: Mapping[str, tuple[str, ...]]
    query_guarantees: tuple[str, ...]
    evidence_policy: str
    effect_classes: tuple[str, ...]
    recovery_class: str
    deprecation_window: Mapping[str, int] | None
    field_gate: str

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> OperationDescriptor:
        bindings = {
            str(name): tuple(str(item) for item in items)
            for name, items in dict(value.get("transport_bindings") or {}).items()
        }
        return cls(
            operation_id=str(value["operation_id"]),
            canonical_operation=str(value["canonical_operation"]),
            aliases=tuple(str(item) for item in value.get("aliases", ())),
            feature_id=str(value["feature_id"]),
            owner=str(value["owner"]),
            mode=OperationMode(str(value["mode"])),
            handler=str(value["handler"]) if value.get("handler") else None,
            request_schema=str(value["request_schema"]),
            response_schema=str(value["response_schema"]),
            error_contracts=tuple(str(item) for item in value.get("error_contracts", ())),
            writer_role=str(value["writer_role"]) if value.get("writer_role") else None,
            reader_roles=tuple(str(item) for item in value.get("reader_roles", ())),
            projection_consumers=tuple(str(item) for item in value.get("projection_consumers", ())),
            required_roles=tuple(str(item) for item in value.get("required_roles", ())),
            scope_policy=str(value.get("scope_policy") or "workspace"),
            capabilities=tuple(str(item) for item in value.get("capabilities", ())),
            risk_floor=str(value["risk_floor"]),
            autonomy_ceiling=str(value["autonomy_ceiling"]),
            maturity=str(value.get("maturity") or "stable"),
            availability=OperationAvailability(str(value["availability"])),
            disposition=str(value["disposition"]),
            authorization_action=str(value["authorization_action"]),
            transports=tuple(str(item) for item in value.get("transports", ())),
            transport_bindings=bindings,
            query_guarantees=tuple(str(item) for item in value.get("query_guarantees", ())),
            evidence_policy=str(value.get("evidence_policy") or "operational"),
            effect_classes=tuple(str(item) for item in value.get("effect_classes", ())),
            recovery_class=str(value["recovery_class"]),
            deprecation_window={
                str(name): int(item) for name, item in dict(value["deprecation_window"]).items()
            }
            if value.get("deprecation_window")
            else None,
            field_gate=str(value["field_gate"]),
        )


class OperationCatalogError(RuntimeError):
    status = "operation_catalog_invalid"


class UnsupportedOperationError(RuntimeError):
    status = "unsupported_operation"

    def __init__(self, operation_id: str) -> None:
        self.operation_id = operation_id
        super().__init__(f"unsupported PersistMind operation: {operation_id}")


class OperationUnavailableError(RuntimeError):
    status = "operation_unavailable"

    def __init__(self, descriptor: OperationDescriptor) -> None:
        self.descriptor = descriptor
        super().__init__(
            f"PersistMind operation is {descriptor.availability.value}: {descriptor.operation_id}"
        )


class OperationHandler(Protocol):
    def __call__(self, request: Mapping[str, Any]) -> Mapping[str, Any]: ...


def operation_catalog_document() -> dict[str, Any]:
    target = resources.files("persistmind.architecture").joinpath("operations.v2.json")
    document = json.loads(target.read_text(encoding="utf-8"))
    if not isinstance(document, dict):
        raise OperationCatalogError("operation catalog must be a JSON object")
    if document.get("schema_version") != CATALOG_SCHEMA_VERSION:
        raise OperationCatalogError("unsupported operation catalog schema")
    return document


def operation_catalog() -> Mapping[str, OperationDescriptor]:
    document = operation_catalog_document()
    rows = document.get("operations")
    if not isinstance(rows, list) or not rows:
        raise OperationCatalogError("operation catalog contains no operations")
    result: dict[str, OperationDescriptor] = {}
    transport_bindings: set[tuple[str, str]] = set()
    for raw in rows:
        if not isinstance(raw, dict):
            raise OperationCatalogError("operation catalog row must be an object")
        descriptor = OperationDescriptor.from_dict(raw)
        if descriptor.operation_id in result:
            raise OperationCatalogError(f"duplicate operation id: {descriptor.operation_id}")
        if descriptor.availability is OperationAvailability.ACTIVE and not descriptor.handler:
            raise OperationCatalogError(
                f"active operation has no handler: {descriptor.operation_id}"
            )
        if descriptor.owner not in VALID_OWNERS:
            raise OperationCatalogError(
                f"operation has an unknown owner: {descriptor.operation_id}"
            )
        if not descriptor.required_roles or not set(descriptor.required_roles) <= VALID_ROLES:
            raise OperationCatalogError(
                f"operation has invalid required roles: {descriptor.operation_id}"
            )
        semantic_roles = set(descriptor.reader_roles) | set(descriptor.projection_consumers)
        if descriptor.writer_role:
            semantic_roles.add(descriptor.writer_role)
        if semantic_roles != set(descriptor.required_roles):
            raise OperationCatalogError(
                f"operation compatibility roles diverge: {descriptor.operation_id}"
            )
        if descriptor.mode is OperationMode.QUERY and descriptor.writer_role is not None:
            raise OperationCatalogError(f"query operation has a writer: {descriptor.operation_id}")
        if descriptor.mode is OperationMode.COMMAND and descriptor.writer_role is None:
            raise OperationCatalogError(
                f"command operation lacks a writer: {descriptor.operation_id}"
            )
        if descriptor.scope_policy not in {"workspace", "repository", "workspace_repository"}:
            raise OperationCatalogError(
                f"operation has an invalid scope policy: {descriptor.operation_id}"
            )
        if set(descriptor.transports) != set(descriptor.transport_bindings):
            raise OperationCatalogError(
                f"operation transport bindings diverge: {descriptor.operation_id}"
            )
        if descriptor.availability is OperationAvailability.ACTIVE and not str(
            descriptor.handler
        ).startswith(("builtin:", "service:")):
            raise OperationCatalogError(
                f"active operation has an unsupported handler: {descriptor.operation_id}"
            )
        if descriptor.mode is OperationMode.QUERY and any(
            guarantee == "writer-required" for guarantee in descriptor.query_guarantees
        ):
            raise OperationCatalogError(
                f"query operation requires a writer: {descriptor.operation_id}"
            )
        if descriptor.mode is OperationMode.QUERY and not {
            "read-only",
            "non-indexing",
            "no-writer-resolution",
        } <= set(descriptor.query_guarantees):
            raise OperationCatalogError(
                f"query operation lacks purity guarantees: {descriptor.operation_id}"
            )
        for transport, names in descriptor.transport_bindings.items():
            for name in names:
                binding = (transport, name)
                if binding in transport_bindings:
                    raise OperationCatalogError(f"duplicate transport binding: {transport}:{name}")
                transport_bindings.add(binding)
        result[descriptor.operation_id] = descriptor
    for operation_id, descriptor in result.items():
        canonical = descriptor.canonical_operation
        if canonical not in result:
            raise OperationCatalogError(
                f"operation has a missing canonical target: {operation_id} -> {canonical}"
            )
        if canonical != operation_id and operation_id not in result[canonical].aliases:
            raise OperationCatalogError(
                f"canonical operation omits alias: {operation_id} -> {canonical}"
            )
    return result


def descriptor_for(operation_id: str) -> OperationDescriptor:
    catalog = operation_catalog()
    try:
        descriptor = catalog[operation_id]
    except KeyError as exc:
        raise UnsupportedOperationError(operation_id) from exc
    visited = {operation_id}
    while descriptor.canonical_operation != descriptor.operation_id:
        target = descriptor.canonical_operation
        if target in visited:
            raise OperationCatalogError(f"operation alias cycle: {operation_id}")
        visited.add(target)
        try:
            descriptor = catalog[target]
        except KeyError as exc:
            raise OperationCatalogError(
                f"operation has a missing canonical target: {operation_id} -> {target}"
            ) from exc
    return descriptor


def owner_for(operation_id: str) -> str:
    return descriptor_for(operation_id).owner


def is_query(operation_id: str) -> bool:
    return descriptor_for(operation_id).mode is OperationMode.QUERY


def validate_operation_catalog() -> dict[str, Any]:
    catalog = operation_catalog()
    active = [
        item for item in catalog.values() if item.availability is OperationAvailability.ACTIVE
    ]
    return {
        "ok": True,
        "status": "verified",
        "schema_version": "persistmind.operation_catalog_validation.v1",
        "operations": len(catalog),
        "active": len(active),
        "deferred": sum(
            item.availability is OperationAvailability.DEFERRED for item in catalog.values()
        ),
        "queries": sum(item.mode is OperationMode.QUERY for item in catalog.values()),
        "commands": sum(item.mode is OperationMode.COMMAND for item in catalog.values()),
    }
