from __future__ import annotations

from typing import Any, Mapping


def promotion_cli_kwargs(args: Any) -> dict[str, Any]:
    values = {
        "rollback_version": args.rollback_version,
        "approver": args.actor,
        "signature": args.signature,
        "field_experiment_id": args.field_experiment_id,
        "policy_decision_id": args.policy_decision_id,
        "policy_decision_hash": args.policy_decision_hash,
        "protected_surface_hash": args.protected_surface_hash,
    }
    if not args.learning_arg or not all(
        value for name, value in values.items() if name != "rollback_version"
    ):
        raise ValueError(
            "learning promotion requires version_id, signature, field experiment, "
            "Policy decision, and protected-surface hash"
        )
    return values


def promotion_payload_kwargs(payload: Mapping[str, Any], *, default_actor: str) -> dict[str, Any]:
    return {
        "rollback_version": payload.get("rollback_version"),
        "approver": str(payload.get("actor") or default_actor),
        "signature": str(payload.get("signature") or ""),
        "field_experiment_id": str(payload.get("field_experiment_id") or ""),
        "policy_decision_id": str(payload.get("policy_decision_id") or ""),
        "policy_decision_hash": str(payload.get("policy_decision_hash") or ""),
        "protected_surface_hash": str(payload.get("protected_surface_hash") or ""),
    }


__all__ = ["promotion_cli_kwargs", "promotion_payload_kwargs"]
