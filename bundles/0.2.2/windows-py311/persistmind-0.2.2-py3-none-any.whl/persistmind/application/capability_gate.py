from __future__ import annotations

from pathlib import Path
from typing import Iterable

from persistmind.config import load_settings
from persistmind.deferred.contracts import CapabilityGuard


class FeatureDisabledError(PermissionError):
    status = "feature_disabled"

    def __init__(self, capability_id: str, reason: str, profile: str) -> None:
        self.capability_id = capability_id
        self.reason = reason
        self.profile = profile
        super().__init__(f"capability {capability_id} is disabled for profile {profile}: {reason}")


def require_capabilities(repo_root: Path, capability_ids: Iterable[str]) -> None:
    settings = load_settings(repo_root.resolve())
    enabled = set(settings.deferred.enabled)
    profile = str(settings.profile.name)
    guard = CapabilityGuard()
    for capability_id in capability_ids:
        result = guard.authorize(
            capability_id,
            profile=profile,
            explicitly_enabled=capability_id in enabled,
            authority=None,
        )
        if not result.ok:
            raise FeatureDisabledError(capability_id, result.status, profile)
