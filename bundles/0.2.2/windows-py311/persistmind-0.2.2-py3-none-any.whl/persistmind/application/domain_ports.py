from __future__ import annotations

from typing import Any, Mapping, Protocol, Sequence


Document = Mapping[str, Any]


class SourceQueries(Protocol):
    def snapshot_current(self) -> Document: ...
    def snapshot_lineage(self, snapshot_id: str | None, *, limit: int) -> Document: ...
    def search(self, query: str, *, limit: int) -> Sequence[Document]: ...


class SourceCommands(Protocol):
    def build(self) -> Document: ...


class TaskQueries(Protocol):
    def task_show(self, task_session_id: str) -> Document: ...
    def plan_show(self, plan_id: str) -> Document: ...


class TaskCommands(Protocol):
    def task_start(self, task: str) -> Document: ...
    def task_transition(
        self, task_session_id: str, target: str, *, actor: str, reason: str
    ) -> Document: ...


class ActivityQueries(Protocol):
    def activity_events(self, *, limit: int = 100) -> Document: ...
    def activity_event(self, event_id: str) -> Document: ...


class ActivityEventSink(Protocol):
    def append_event(self, event: Document, *, idempotency_key: str) -> str: ...


class AuditQueries(Protocol):
    def get_audit_record(self, record_id: str) -> Document: ...
    def verify_audit(self) -> Document: ...


class KnowledgeQueries(Protocol):
    def memory_search(
        self, query: str, types: Sequence[str] | None = None, status: str | None = None
    ) -> Document: ...


class PolicyDecisionPort(Protocol):
    def policy_applicable(self, scope: str) -> Document: ...
    def decide(self, proposal_id: str, decision: str, *, actor: str) -> Document: ...


class LearningQueries(Protocol):
    def learning_active_manifest(self) -> Document: ...


class RecoveryControlPort(Protocol):
    def recovery_plan(self, authority: str, *, output: Any) -> Document: ...
    def recovery_status(self, stage_path: Any) -> Document: ...


__all__ = [
    "ActivityEventSink",
    "ActivityQueries",
    "AuditQueries",
    "KnowledgeQueries",
    "LearningQueries",
    "PolicyDecisionPort",
    "RecoveryControlPort",
    "SourceCommands",
    "SourceQueries",
    "TaskCommands",
    "TaskQueries",
]
