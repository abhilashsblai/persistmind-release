from __future__ import annotations

from typing import Any, Mapping

from persistmind.utils import canonical_json, sha256_text, utc_now


CLAIM_STATUSES = frozenset(
    {
        "candidate",
        "supported",
        "refuted",
        "contested",
        "stale",
        "superseded",
        "expired",
        "rejected",
        "quarantined",
        "unknown",
    }
)
EVIDENCE_KINDS = frozenset(
    {
        "observation",
        "source_text",
        "execution_result",
        "human_decision",
        "inference",
        "policy",
        "preference",
        "external_report",
    }
)


def normalize_epistemic_claim(
    value: Mapping[str, Any],
    *,
    workspace_id: str,
    repository_id: str,
) -> dict[str, Any]:
    claim = dict(value)
    proposition = str(claim.get("proposition") or "").strip()
    if not proposition:
        raise ValueError("epistemic claim proposition is required")
    claim_id = str(claim.get("claim_id") or "claim_" + sha256_text(proposition)[:32])
    status = str(claim.get("status") or "candidate").lower()
    if status not in CLAIM_STATUSES:
        raise ValueError(f"unsupported epistemic claim status: {status}")
    support_score = _optional_unit(claim.get("support_score"), "support_score")
    probability = _optional_unit(claim.get("calibrated_probability"), "calibrated_probability")
    support_adapter_id = claim.get("support_adapter_id")
    calibration_model_id = claim.get("calibration_model_id")
    if support_score is not None and not str(support_adapter_id or "").strip():
        raise ValueError("support_score requires a named support adapter")
    if probability is not None and not str(calibration_model_id or "").strip():
        raise ValueError("calibrated_probability requires a calibration model")
    if "confidence" in claim:
        raise ValueError(
            "epistemic claims separate support_score and calibrated_probability; confidence is ambiguous"
        )
    now = utc_now()
    normalized = {
        "record_id": claim_id,
        "kind": "epistemic_claim",
        "claim_id": claim_id,
        "proposition": proposition,
        "proposition_hash": "sha256:" + sha256_text(canonical_json(proposition)),
        "claim_kind": str(claim.get("claim_kind") or "assertion"),
        "workspace_id": str(claim.get("workspace_id") or workspace_id),
        "repository_id": str(claim.get("repository_id") or repository_id),
        "branch_or_generation_scope": str(claim.get("branch_or_generation_scope") or "current"),
        "path_scope": sorted({str(item) for item in claim.get("path_scope", [])}),
        "valid_from": str(claim.get("valid_from") or now),
        "valid_to": claim.get("valid_to"),
        "observed_at": str(claim.get("observed_at") or now),
        "transaction_time": now,
        "status": status,
        "sensitivity": str(claim.get("sensitivity") or "internal"),
        "source_class": str(claim.get("source_class") or "human_decision"),
        "source_identity": dict(claim.get("source_identity") or {}),
        "support_score": support_score,
        "support_adapter_id": support_adapter_id,
        "calibrated_probability": probability,
        "calibration_model_id": calibration_model_id,
        "decision_confidence": dict(claim.get("decision_confidence") or {}),
        "evidence_ids": sorted({str(item) for item in claim.get("evidence_ids", [])}),
        "contradiction_ids": sorted({str(item) for item in claim.get("contradiction_ids", [])}),
        "supersedes": sorted({str(item) for item in claim.get("supersedes", [])}),
        "derived_from": sorted({str(item) for item in claim.get("derived_from", [])}),
        "assumptions": list(claim.get("assumptions") or []),
        "limitations": list(claim.get("limitations") or []),
        "expiry_policy": dict(claim.get("expiry_policy") or {}),
        "causal_label": str(claim.get("causal_label") or "associational"),
        "causal_contract": dict(claim.get("causal_contract") or {}),
        "revision": int(claim.get("revision") or 1),
        "scope": f"repo:{str(claim.get('repository_id') or repository_id)}",
    }
    valid_to = normalized.get("valid_to")
    valid_from = str(normalized.get("valid_from") or "")
    if valid_to and str(valid_to) < valid_from:
        raise ValueError("claim valid_to precedes valid_from")
    if normalized.get("causal_label") == "causal":
        required = {
            "graph_version",
            "identification_strategy",
            "assumptions",
            "estimand",
            "sensitivity",
        }
        raw_contract = normalized.get("causal_contract")
        causal_contract = dict(raw_contract) if isinstance(raw_contract, Mapping) else {}
        missing = sorted(required - set(causal_contract))
        if missing:
            raise ValueError(f"causal claim lacks identification fields: {missing}")
    return normalized


def _optional_unit(value: Any, name: str) -> float | None:
    if value is None:
        return None
    result = float(value)
    if not 0 <= result <= 1:
        raise ValueError(f"{name} must be between 0 and 1")
    return result


__all__ = ["CLAIM_STATUSES", "EVIDENCE_KINDS", "normalize_epistemic_claim"]
