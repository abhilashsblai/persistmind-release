from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, Protocol


class AgentRuntimeTaskPort(Protocol):
    def runtime_epoch(self) -> Mapping[str, Any]: ...

    def activate_epoch(self, protocol_version: int, engine_version: str) -> Mapping[str, Any]: ...

    def put_protocol_migration(self, migration: Mapping[str, Any]) -> Mapping[str, Any]: ...

    def update_protocol_migration(
        self, migration_id: str, *, state: str, error: str | None = None
    ) -> Mapping[str, Any]: ...

    def enqueue_job(self, job: Mapping[str, Any]) -> Mapping[str, Any]: ...

    def claim_jobs(
        self, *, worker_id: str, claim_token_hash: str, limit: int, lease_ms: int
    ) -> Sequence[Mapping[str, Any]]: ...

    def renew_job(
        self,
        job_id: str,
        *,
        worker_id: str,
        claim_token_hash: str,
        fencing_token: int,
        lease_ms: int,
    ) -> Mapping[str, Any]: ...

    def finish_job(
        self,
        job_id: str,
        *,
        worker_id: str,
        claim_token_hash: str,
        fencing_token: int,
        state: str,
        result: Mapping[str, Any] | None = None,
        error: str | None = None,
    ) -> Mapping[str, Any]: ...

    def cancel_job(self, job_id: str) -> Mapping[str, Any]: ...

    def jobs(
        self, *, state: str | None = None, limit: int = 100
    ) -> Sequence[Mapping[str, Any]]: ...

    def put_grant(self, grant: Mapping[str, Any]) -> Mapping[str, Any]: ...

    def grant(self, grant_id: str) -> Mapping[str, Any] | None: ...

    def consume_grant(self, grant_id: str, *, expected_uses: int) -> bool: ...

    def revoke_grant(self, grant_id: str) -> bool: ...

    def put_external_run(self, run: Mapping[str, Any]) -> Mapping[str, Any]: ...

    def external_run(self, run_id: str) -> Mapping[str, Any] | None: ...

    def external_runs(self, *, limit: int = 100) -> Sequence[Mapping[str, Any]]: ...

    def update_external_run(
        self, run_id: str, *, state: str, values: Mapping[str, Any]
    ) -> Mapping[str, Any]: ...

    def put_acp_session(self, session: Mapping[str, Any]) -> Mapping[str, Any]: ...

    def acp_session(self, connection_id: str) -> Mapping[str, Any] | None: ...

    def acp_sessions(self, *, limit: int = 100) -> Sequence[Mapping[str, Any]]: ...

    def update_acp_session(
        self, connection_id: str, *, state: str, values: Mapping[str, Any]
    ) -> Mapping[str, Any]: ...

    def put_acp_terminal(self, terminal: Mapping[str, Any]) -> Mapping[str, Any]: ...

    def update_acp_terminal(
        self, terminal_id: str, *, state: str, output_bytes: int
    ) -> Mapping[str, Any]: ...

    def put_worktree_lease(self, lease: Mapping[str, Any]) -> Mapping[str, Any]: ...

    def worktree_lease(self, lease_id: str) -> Mapping[str, Any] | None: ...

    def worktree_leases(self, *, limit: int = 100) -> Sequence[Mapping[str, Any]]: ...

    def renew_worktree_lease(
        self,
        lease_id: str,
        *,
        owner_token_hash: str,
        fencing_token: int,
        expires_at: str,
    ) -> Mapping[str, Any]: ...

    def update_worktree_lease(
        self,
        lease_id: str,
        *,
        state: str,
        owner_token_hash: str | None = None,
        fencing_token: int | None = None,
    ) -> Mapping[str, Any]: ...

    def put_model_route_evidence(self, evidence: Mapping[str, Any]) -> Mapping[str, Any]: ...

    def put_runtime_process(self, process: Mapping[str, Any]) -> Mapping[str, Any]: ...

    def runtime_process(self, owner_kind: str, owner_id: str) -> Mapping[str, Any] | None: ...

    def clear_runtime_process(self, owner_kind: str, owner_id: str) -> bool: ...


class AgentRuntimeActivityPort(Protocol):
    def append_agent_event(self, event: Mapping[str, Any]) -> Mapping[str, Any]: ...

    def agent_event(self, event_id: str) -> Mapping[str, Any] | None: ...

    def agent_events(
        self, *, stream_id: str | None = None, state: str | None = None, limit: int = 100
    ) -> Sequence[Mapping[str, Any]]: ...

    def claim_agent_events(
        self, *, worker_id: str, limit: int, lease_ms: int
    ) -> Sequence[Mapping[str, Any]]: ...

    def complete_agent_event(self, event_id: str, *, worker_id: str) -> bool: ...

    def fail_agent_event(
        self,
        event_id: str,
        *,
        worker_id: str,
        error: str,
        retry_at: str | None,
        dead_letter: bool,
    ) -> bool: ...

    def dead_letters(self, *, limit: int = 100) -> Sequence[Mapping[str, Any]]: ...

    def requeue_dead_letters(
        self, *, event_ids: Sequence[str] = (), limit: int = 100
    ) -> Sequence[str]: ...

    def unsettled_agent_event_count(self) -> int: ...


class AgentRuntimeAuditPort(Protocol):
    def append_agent_security_projection(
        self, record: Mapping[str, Any], *, idempotency_key: str
    ) -> str: ...


class AgentRuntimePorts(Protocol):
    task: AgentRuntimeTaskPort
    activity: AgentRuntimeActivityPort
    audit: AgentRuntimeAuditPort
    plugin_trust: Any

    def close(self) -> None: ...


__all__ = [
    "AgentRuntimeActivityPort",
    "AgentRuntimeAuditPort",
    "AgentRuntimePorts",
    "AgentRuntimeTaskPort",
]
