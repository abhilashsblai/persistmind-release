from __future__ import annotations

import copy
import hashlib
from typing import Any

from persistmind.utils import canonical_json


RESPONSE_ONLY_FIELDS = frozenset(
    {
        "agent_session_id",
        "audit",
        "correlation_id",
        "lifecycle_event",
        "operation_id",
        "served_at",
        "transport",
    }
)
VOLATILE_MANIFEST_FIELDS = frozenset(
    {"bound_at", "created_at", "latency_ms", "probe_id", "served_at", "wal_bytes"}
)


def assemble_pack(manifest: dict[str, Any]) -> dict[str, Any]:
    """Return a complete immutable manifest whose ID hashes all immutable bytes."""

    provisional_id = str(manifest.get("pack_id") or "")
    immutable = _normalize(manifest, provisional_id=provisional_id)
    encoded = canonical_json(immutable).encode("utf-8")
    immutable["pack_id"] = hashlib.sha256(b"persistmind.context-pack.v3\0" + encoded).hexdigest()
    return immutable


def _normalize(value: Any, *, provisional_id: str) -> Any:
    if isinstance(value, dict):
        return {
            key: _normalize(item, provisional_id=provisional_id)
            for key, item in value.items()
            if key != "pack_id"
            and key not in RESPONSE_ONLY_FIELDS
            and key not in VOLATILE_MANIFEST_FIELDS
        }
    if isinstance(value, list):
        return [_normalize(item, provisional_id=provisional_id) for item in value]
    if isinstance(value, tuple):
        return [_normalize(item, provisional_id=provisional_id) for item in value]
    if isinstance(value, str) and provisional_id:
        return value.replace(provisional_id, "<pack_id>")
    return copy.deepcopy(value)


def validate_pack_identity(manifest: dict[str, Any]) -> None:
    expected = assemble_pack(manifest)["pack_id"]
    if str(manifest.get("pack_id") or "") != expected:
        raise ValueError("context pack ID does not match its complete immutable manifest")


def immutable_pack_bytes(manifest: dict[str, Any]) -> bytes:
    validate_pack_identity(manifest)
    return canonical_json(manifest).encode("utf-8")
