from __future__ import annotations

import hashlib
import hmac
import math
import struct
from decimal import Decimal, ROUND_HALF_EVEN, localcontext
from fractions import Fraction
from typing import Any, Mapping, Sequence


MICRO = Decimal(1_000_000)
SERIAL = Decimal("0.000000000001")
_BERNOULLI = (
    Fraction(1, 6),
    Fraction(-1, 30),
    Fraction(1, 42),
    Fraction(-1, 30),
    Fraction(5, 66),
    Fraction(-691, 2730),
    Fraction(7, 6),
    Fraction(-3617, 510),
    Fraction(43867, 798),
    Fraction(-174611, 330),
    Fraction(854513, 138),
    Fraction(-236364091, 2730),
    Fraction(8553103, 6),
)


def encode_assignment_v1(experiment_id: str, assignment_unit_id: str) -> bytes:
    values = []
    for value in (experiment_id, assignment_unit_id):
        encoded = value.encode("utf-8")
        if len(encoded) > 0xFFFFFFFF:
            raise ValueError("assignment identity exceeds encode_v1 length")
        values.append(struct.pack(">I", len(encoded)) + encoded)
    return b"".join(values)


def assign_arm(secret_key: bytes, experiment_id: str, assignment_unit_id: str) -> str:
    if len(secret_key) != 32:
        raise ValueError("field assignment requires a uniformly random 256-bit key")
    digest = hmac.new(
        secret_key,
        encode_assignment_v1(experiment_id, assignment_unit_id),
        hashlib.sha256,
    ).digest()
    return "candidate" if int.from_bytes(digest[:8], "big") % 2 else "baseline"


def assignment_anchor(secret_key: bytes, experiment_id: str, protocol_hash: str) -> str:
    if len(secret_key) != 32:
        raise ValueError("field assignment requires a uniformly random 256-bit key")
    return (
        "sha256:"
        + hashlib.sha256(
            secret_key + experiment_id.encode("utf-8") + protocol_hash.encode("utf-8")
        ).hexdigest()
    )


def analyze_treatment_stream(
    observations: Sequence[Mapping[str, Any]],
    *,
    missing_mode: str = "primary",
) -> dict[str, Any]:
    if missing_mode not in {"primary", "promotion_worst_case"}:
        raise ValueError("unsupported missing-outcome analysis")
    ordered = sorted(
        observations,
        key=lambda item: (int(item["enrollment_sequence"]), str(item["assignment_unit_id"])),
    )
    sequences = [int(item["enrollment_sequence"]) for item in ordered]
    if len(sequences) != len(set(sequences)):
        raise ValueError("enrollment sequence must be unique")
    with localcontext() as context:
        context.prec = 70
        total = Decimal(0)
        intrinsic_variance = Decimal(0)
        rows = []
        for index, item in enumerate(ordered, 1):
            assignment = str(item["assignment"])
            if assignment not in {"baseline", "candidate"}:
                raise ValueError("assignment must be baseline or candidate")
            observed = item.get("outcome_micro")
            if observed is None:
                observed_value = _missing_value(assignment, missing_mode)
                missing = True
            else:
                observed_value = _unit_micro(observed, "outcome_micro")
                missing = False
            prediction_baseline = _unit_micro(
                item.get("prediction_baseline_micro", 0), "prediction_baseline_micro"
            )
            prediction_candidate = _unit_micro(
                item.get("prediction_candidate_micro", 0), "prediction_candidate_micro"
            )
            z = Decimal(1) if assignment == "candidate" else Decimal(0)
            prediction_observed = (
                prediction_candidate if assignment == "candidate" else prediction_baseline
            )
            predictable = prediction_candidate - prediction_baseline
            x_value = predictable + Decimal(4) * (z - Decimal("0.5")) * (
                observed_value - prediction_observed
            )
            total += x_value
            intrinsic = (x_value - predictable) ** 2
            intrinsic_variance += intrinsic
            mean = total / Decimal(index)
            boundary = stitched_boundary(
                intrinsic_variance, alpha=Decimal("0.025"), scale=Decimal(4)
            )
            lower = max(Decimal(-1), mean - boundary / Decimal(index))
            upper = min(Decimal(1), mean + boundary / Decimal(index))
            rows.append(
                {
                    "enrollment_sequence": int(item["enrollment_sequence"]),
                    "assignment_unit_id": str(item["assignment_unit_id"]),
                    "assignment": assignment,
                    "missing": missing,
                    "observed": _render(observed_value),
                    "prediction_baseline": _render(prediction_baseline),
                    "prediction_candidate": _render(prediction_candidate),
                    "x_t": _render(x_value),
                    "predictable_x_t": _render(predictable),
                    "intrinsic_variance_t": _render(intrinsic),
                    "variance_sum": _render(intrinsic_variance),
                    "boundary": _render(boundary),
                    "mean": _render(mean),
                    "lower": _render(lower),
                    "upper": _render(upper),
                }
            )
        if not rows:
            return {
                "status": "not_computable",
                "count": 0,
                "missing_mode": missing_mode,
                "rows": [],
            }
        final = rows[-1]
        return {
            "status": "verified",
            "count": len(rows),
            "missing": sum(bool(item["missing"]) for item in rows),
            "missing_mode": missing_mode,
            "mean_lift": final["mean"],
            "lower_lift": final["lower"],
            "upper_lift": final["upper"],
            "rows": rows,
            "arithmetic": {
                "decimal_precision": 50,
                "input_unit": "integer_micro_units",
                "rounding": "round_half_even",
                "eta": "2",
                "s": "1.4",
                "m": "1",
                "scale": "4",
                "alpha": "0.025",
                "zeta_7_5": _render(zeta_7_5()),
            },
        }


def stitched_boundary(variance: Decimal, *, alpha: Decimal, scale: Decimal) -> Decimal:
    with localcontext() as context:
        context.prec = 70
        eta = Decimal(2)
        s = Decimal(7) / Decimal(5)
        v = max(variance, Decimal(1))
        ell = s * (eta * v).ln().ln() + (zeta_7_5() / (alpha * (eta.ln() ** s))).ln()
        k1 = (eta ** Decimal("0.25") + eta ** Decimal("-0.25")) / Decimal(2).sqrt()
        k2 = (eta.sqrt() + Decimal(1)) / Decimal(2)
        return k1 * (v * ell).sqrt() + scale * k2 * ell


def zeta_7_5() -> Decimal:
    """Euler-Maclaurin zeta(7/5), certified by the first omitted term."""

    with localcontext() as context:
        context.prec = 70
        s = Decimal(7) / Decimal(5)
        threshold = Decimal("1e-40")
        size = 16
        while True:
            n = Decimal(size)
            total = sum((_pow(Decimal(index), -s) for index in range(1, size)), Decimal(0))
            total += _pow(n, Decimal(1) - s) / (s - Decimal(1))
            total += _pow(n, -s) / Decimal(2)
            for order, bernoulli in enumerate(_BERNOULLI[:-1], 1):
                total += _em_term(s, n, order, bernoulli)
            remainder = abs(_em_term(s, n, len(_BERNOULLI), _BERNOULLI[-1]))
            if remainder < threshold:
                return +total
            size *= 2
            if size > 4096:
                raise ArithmeticError("Euler-Maclaurin zeta remainder did not converge")


def zero_event_upper_bound(executions: int, *, alpha: float = 0.05) -> float:
    if executions < 1 or not 0 < alpha < 1:
        raise ValueError("zero-event bound requires executions>0 and alpha in (0,1)")
    return 1.0 - alpha ** (1.0 / executions)


def allocation_integrity(assignments: Sequence[str]) -> dict[str, Any]:
    if not assignments:
        return {"ok": False, "status": "not_computable", "candidate_share": None}
    candidate = sum(item == "candidate" for item in assignments)
    if candidate + sum(item == "baseline" for item in assignments) != len(assignments):
        raise ValueError("unknown field assignment arm")
    share = candidate / len(assignments)
    return {
        "ok": 0.40 <= share <= 0.60,
        "status": "verified" if 0.40 <= share <= 0.60 else "assignment_integrity_review",
        "candidate_share": round(share, 12),
        "candidate": candidate,
        "baseline": len(assignments) - candidate,
    }


def _missing_value(assignment: str, mode: str) -> Decimal:
    if mode == "primary" or assignment == "candidate":
        return Decimal(0)
    return Decimal(1)


def _unit_micro(value: Any, name: str) -> Decimal:
    integer = int(value)
    if integer < 0 or integer > 1_000_000:
        raise ValueError(f"{name} must be an integer in [0,1000000]")
    return Decimal(integer) / MICRO


def _em_term(s: Decimal, n: Decimal, order: int, bernoulli: Fraction) -> Decimal:
    rising = Decimal(1)
    for offset in range(2 * order - 1):
        rising *= s + Decimal(offset)
    coefficient = Decimal(bernoulli.numerator) / Decimal(bernoulli.denominator)
    coefficient /= Decimal(math.factorial(2 * order))
    return coefficient * rising * _pow(n, -s - Decimal(2 * order - 1))


def _pow(base: Decimal, exponent: Decimal) -> Decimal:
    return (exponent * base.ln()).exp()


def _render(value: Decimal) -> str:
    return str(value.quantize(SERIAL, rounding=ROUND_HALF_EVEN))


__all__ = [
    "allocation_integrity",
    "analyze_treatment_stream",
    "assign_arm",
    "assignment_anchor",
    "encode_assignment_v1",
    "stitched_boundary",
    "zero_event_upper_bound",
    "zeta_7_5",
]
