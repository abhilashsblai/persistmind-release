from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Protocol


class PluginTrustPort(Protocol):
    def put(self, record: Mapping[str, Any], *, idempotency_key: str | None = None) -> str: ...

    def get(self, record_id: str) -> Mapping[str, Any] | None: ...


__all__ = ["PluginTrustPort"]
