from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Iterator

from .registry import OperationMode


@dataclass(frozen=True, slots=True)
class OperationExecutionScope:
    operation_id: str
    mode: OperationMode
    roles: frozenset[str]
    scope_policy: str


_CURRENT_SCOPE: ContextVar[OperationExecutionScope | None] = ContextVar(
    "persistmind_operation_execution_scope", default=None
)


def current_operation_scope() -> OperationExecutionScope | None:
    return _CURRENT_SCOPE.get()


@contextmanager
def bind_operation_scope(scope: OperationExecutionScope) -> Iterator[None]:
    token = _CURRENT_SCOPE.set(scope)
    try:
        yield
    finally:
        _CURRENT_SCOPE.reset(token)


__all__ = ["OperationExecutionScope", "bind_operation_scope", "current_operation_scope"]
