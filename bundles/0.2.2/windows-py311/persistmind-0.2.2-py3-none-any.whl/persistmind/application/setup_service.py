from __future__ import annotations

import os
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from persistmind.agents.adapters import detect_running, resolve
from persistmind.agents.adapters.base import BootstrapContext
from persistmind.agents.contract import capabilities_yaml, write_if_changed
from persistmind.branding import CAPABILITIES_FILE, resolve_project_state
from persistmind.runtime_invocation import RuntimeInvocation, runtime_invocation
from persistmind.setup import (
    ensure_project_state_ignored,
    init_git_repo,
    is_git_repo,
    record_setup_gating_baseline,
    setup_readiness,
)
from persistmind.updater.atomic import write_json
from persistmind.utils import utc_now


class SetupService:
    """Agent-surface installer; it has no database or product-domain authority."""

    def __init__(self, repo_root: Path) -> None:
        self.repo_root = repo_root.resolve()
        self.workspace_root = resolve_project_state(self.repo_root)

    def setup(
        self,
        agents: Iterable[str],
        *,
        mcp_command: str = "persistmind",
        install_hooks: bool = True,
        configure_mcp: bool = False,
        init_git: bool = False,
        absolute_mcp_repo: bool = False,
        codex_config: str | None = None,
        skip_index: bool = True,
        runtime: RuntimeInvocation | None = None,
        **_: Any,
    ) -> dict[str, Any]:
        del skip_index
        self.workspace_root.mkdir(parents=True, exist_ok=True)
        git = None
        if init_git and not is_git_repo(self.repo_root):
            git = init_git_repo(self.repo_root)
            if not git["ok"]:
                return {"ok": False, "status": "git_init_failed", "git": git}
        selected = resolve(agents)
        invocation = runtime or runtime_invocation(
            executable=mcp_command if mcp_command != "persistmind" else None
        )
        context = BootstrapContext(
            repo_root=self.repo_root,
            workspace_root=self.workspace_root,
            runtime_invocation=invocation,
            mcp_repo=str(self.repo_root) if absolute_mcp_repo else ".",
            shell="powershell",
            agent_names=[adapter.name for adapter in selected],
        )
        written: list[str] = []
        configured: list[dict[str, Any]] = []
        for adapter in selected:
            written.extend(str(path) for path in adapter.render(context))
            if configure_mcp:
                target = (
                    Path(codex_config).expanduser()
                    if codex_config and adapter.name == "codex"
                    else None
                )
                configured.append(adapter.configure_mcp(context, config_path=target))
        written.append(
            str(write_if_changed(self.repo_root / CAPABILITIES_FILE, capabilities_yaml()))
        )
        ignore = ensure_project_state_ignored(self.repo_root)
        if ignore.get("changed"):
            written.append(str(ignore["path"]))
        hooks = None
        if install_hooks:
            from persistmind.git_hooks import install_git_hooks

            hooks = install_git_hooks(self.repo_root, invocation)
            hooks["removal"] = "Remove PersistMind Git hooks with: persistmind --repo . uninstall --hooks"
        readiness = setup_readiness(
            self.repo_root,
            [adapter.name for adapter in selected],
            probe_mcp=False,
            live_probes=False,
        )
        gating_baseline = record_setup_gating_baseline(self.repo_root)
        from persistmind import __version__

        profile_path = self.workspace_root / "setup-profile.json"
        write_json(
            profile_path,
            {
                "schema_version": "persistmind.setup_profile.v2",
                "updated_at": utc_now(),
                "engine_version": __version__,
                "agents": [adapter.name for adapter in selected],
                "mcp_command": mcp_command,
                "install_hooks": bool(install_hooks),
                "configure_mcp": bool(configure_mcp),
                "absolute_mcp_repo": bool(absolute_mcp_repo),
                "codex_config": codex_config,
                "runtime_invocation": invocation.to_dict(),
                "runtime_invocation_sha256": invocation.invocation_sha256,
            },
        )
        written.append(str(profile_path))
        return {
            "ok": bool(readiness["ok"]),
            "status": "ready" if readiness["ok"] else "incomplete",
            "schema_version": "persistmind.setup_result.v1",
            "agents": [adapter.name for adapter in selected],
            "written": sorted(set(written)),
            "configured": configured,
            "readiness": readiness,
            "git": git,
            "hooks": hooks,
            "gating_baseline": gating_baseline,
        }

    def setup_auto(
        self,
        *,
        env: dict[str, str] | None = None,
        **options: Any,
    ) -> dict[str, Any]:
        selected = detect_running(os.environ if env is None else env)
        if not selected:
            raise ValueError("no supported running coding agent was detected")
        return self.setup([adapter.name for adapter in selected], **options)

    def refresh_index(self) -> dict[str, Any]:
        raise RuntimeError(
            "source refresh is not owned by SetupService; use the Source command port"
        )

    def doctor(self) -> dict[str, Any]:
        raise RuntimeError(
            "storage diagnostics are not owned by SetupService; use the Control query port"
        )
