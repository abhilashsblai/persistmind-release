from __future__ import annotations

from collections.abc import Sequence

from .ports import (
    Document,
    KnowledgeApplicationPort,
    PackApplicationPort,
    PolicyApplicationPort,
    ReleaseApplicationPort,
    SourceApplicationPort,
    TaskApplicationPort,
)


class IndexService:
    def __init__(self, source: SourceApplicationPort) -> None:
        self.source = source

    def status(self) -> Document:
        return self.source.source_status()

    def search(self, query: str, *, limit: int = 20) -> Document:
        return self.source.search(query, limit=limit)


class PackService:
    def __init__(self, packs: PackApplicationPort) -> None:
        self.packs = packs

    def show(self, pack_id: str) -> Document:
        return self.packs.get_pack_manifest(pack_id)

    def reconstruct(self, pack_id: str, task: str | None = None) -> Document:
        return self.packs.reconstruct_pack(pack_id, task)


class ImpactService:
    def __init__(self, source: SourceApplicationPort) -> None:
        self.source = source

    def assess(self, paths: Sequence[str]) -> Document:
        return self.source.impact(paths)


class WorkflowService:
    def __init__(self, tasks: TaskApplicationPort) -> None:
        self.tasks = tasks

    def task(self, task_session_id: str) -> Document:
        return self.tasks.task_show(task_session_id)

    def plan(self, plan_id: str) -> Document:
        return self.tasks.plan_show(plan_id)


class MemoryService:
    def __init__(self, knowledge: KnowledgeApplicationPort) -> None:
        self.knowledge = knowledge

    def search(
        self,
        query: str,
        *,
        types: Sequence[str] | None = None,
        status: str | None = None,
    ) -> Document:
        return self.knowledge.memory_search(query, types, status)

    def show(self, record_id: str) -> Document:
        return self.knowledge.memory_show(record_id)


class PolicyService:
    def __init__(self, policy: PolicyApplicationPort) -> None:
        self.policy = policy

    def applicable(self, scope: str) -> Document:
        return self.policy.policy_applicable(scope)

    def check(self, paths: Sequence[str]) -> Document:
        return self.policy.constitution_check(paths)


class ReleaseService:
    def __init__(self, release: ReleaseApplicationPort) -> None:
        self.release = release

    def status(self) -> Document:
        return self.release.status()

    def validate(self) -> Document:
        return self.release.validate()
