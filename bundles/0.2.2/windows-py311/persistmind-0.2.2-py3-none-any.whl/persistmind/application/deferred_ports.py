from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, Protocol

Document = Mapping[str, Any]


class PolyglotIndexPort(Protocol):
    def parse(self, path: str, text: str, language: str) -> Document: ...


class SemanticRankingPort(Protocol):
    def rank(self, candidates: Sequence[Document], required_ids: Sequence[str]) -> Document: ...


class AdvisoryIntelligencePort(Protocol):
    def report(self, binding: Document, evidence: Sequence[str]) -> Document: ...


class LearningAdoptionPort(Protocol):
    def propose(self, artifact: Document) -> Document: ...

    def adopt(self, artifact_id: str, principal: Document) -> Document: ...

    def rollback(self, artifact_kind: str) -> Document: ...


class AnticipationPort(Protocol):
    def predict(self, binding: Document, known_paths: Sequence[str]) -> Document: ...


class PatchProposalPort(Protocol):
    def propose(self, base_commit: str, patch: str, validations: Sequence[str]) -> Document: ...


class WorkspaceGraphPort(Protocol):
    def replace_edges(self, edges: Sequence[Document]) -> Document: ...

    def disconnect(self, repository_id: str) -> Document: ...


class OrganizationKnowledgePort(Protocol):
    def query(self, principal: Document, text: str = "") -> Document: ...

    def delete_source(self, tenant_id: str, source_id: str) -> Document: ...


class TeamReadPort(Protocol):
    def read(self, principal: Document, operation: str, parameters: Document) -> Document: ...


class MCPMutationBrokerPort(Protocol):
    def mutate(self, capability: str, operation: str, payload: Document) -> Document: ...


class ConnectorIngestPort(Protocol):
    def ingest(self, connector_id: str, cursor: str | None) -> Document: ...

    def revoke(self, connector_id: str) -> Document: ...
