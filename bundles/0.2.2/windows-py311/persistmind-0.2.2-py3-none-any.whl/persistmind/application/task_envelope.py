from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from enum import StrEnum
from types import MappingProxyType
from typing import Any

from persistmind.utils import canonical_json, sha256_text


class ResolutionStatus(StrEnum):
    UNSAFE = "unsafe"
    NOT_AUTHORIZED = "not_authorized"
    CONTRADICTORY = "contradictory"
    UNDERSPECIFIED = "underspecified"
    EXTERNAL_DEPENDENCY = "external_dependency"
    NOT_COMPUTABLE = "not_computable"
    INTRACTABLE = "intractable"
    UNIDENTIFIABLE = "unidentifiable"
    UNKNOWN = "unknown"
    CANDIDATE = "candidate"
    BOUNDED_APPROXIMATION = "bounded_approximation"
    VERIFIED = "verified"


RESOLUTION_PRECEDENCE = tuple(ResolutionStatus)


def resolve_status(
    conditions: Iterable[str | ResolutionStatus],
) -> tuple[ResolutionStatus, tuple[ResolutionStatus, ...]]:
    observed = {ResolutionStatus(str(item)) for item in conditions}
    if not observed:
        observed = {ResolutionStatus.UNKNOWN}
    ordered = tuple(item for item in RESOLUTION_PRECEDENCE if item in observed)
    return ordered[0], ordered[1:]


def resolution_satisfies_gate(terminal_status: str | ResolutionStatus | None) -> bool:
    if terminal_status is None:
        return False
    try:
        return ResolutionStatus(str(terminal_status)) is ResolutionStatus.VERIFIED
    except ValueError:
        return False


@dataclass(frozen=True, slots=True)
class TaskEnvelope:
    schema_version: str
    goals: tuple[Mapping[str, Any], ...]
    constraints: Mapping[str, Any]
    source_state: Mapping[str, Any]
    evidence: tuple[Mapping[str, Any], ...]
    actions: tuple[Mapping[str, Any], ...]
    budgets: Mapping[str, Any]
    risk: Mapping[str, Any]
    horizon: Mapping[str, Any]
    verifier: Mapping[str, Any]
    actor: str
    rationale: str
    prior_envelope_hash: str | None = None

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> TaskEnvelope:
        schema_version = str(value.get("schema_version") or "TaskEnvelope.v1")
        if schema_version != "TaskEnvelope.v1":
            raise ValueError(f"unsupported task envelope schema: {schema_version}")
        goals = tuple(_objects(value.get("goals")))
        if not goals or any(not str(goal.get("predicate") or "").strip() for goal in goals):
            raise ValueError("TaskEnvelope.v1 requires explicit goal predicates")
        actor = str(value.get("actor") or "").strip()
        rationale = str(value.get("rationale") or "").strip()
        if not actor or not rationale:
            raise ValueError("TaskEnvelope.v1 requires actor and rationale")
        source_state = _object(value.get("source_state"))
        if not str(source_state.get("workspace_id") or "") or not str(
            source_state.get("repository_id") or ""
        ):
            raise ValueError("TaskEnvelope.v1 source state requires workspace and repository ids")
        budgets = _object(value.get("budgets"))
        for name, amount in budgets.items():
            if isinstance(amount, (int, float)) and amount < 0:
                raise ValueError(f"TaskEnvelope.v1 budget cannot be negative: {name}")
        return cls(
            schema_version=schema_version,
            goals=goals,
            constraints=_object(value.get("constraints")),
            source_state=source_state,
            evidence=tuple(_objects(value.get("evidence"))),
            actions=tuple(_objects(value.get("actions"))),
            budgets=budgets,
            risk=_object(value.get("risk")),
            horizon=_object(value.get("horizon")),
            verifier=_object(value.get("verifier")),
            actor=actor,
            rationale=rationale,
            prior_envelope_hash=(
                str(value["prior_envelope_hash"]) if value.get("prior_envelope_hash") else None
            ),
        )

    def document(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "goals": [dict(item) for item in self.goals],
            "constraints": dict(self.constraints),
            "source_state": dict(self.source_state),
            "evidence": [dict(item) for item in self.evidence],
            "actions": [dict(item) for item in self.actions],
            "budgets": dict(self.budgets),
            "risk": dict(self.risk),
            "horizon": dict(self.horizon),
            "verifier": dict(self.verifier),
            "actor": self.actor,
            "rationale": self.rationale,
            "prior_envelope_hash": self.prior_envelope_hash,
        }

    @property
    def envelope_hash(self) -> str:
        return "sha256:" + sha256_text(canonical_json(self.document()))


def _object(value: Any) -> Mapping[str, Any]:
    if value is None:
        return MappingProxyType({})
    if not isinstance(value, Mapping):
        raise ValueError("TaskEnvelope.v1 object field must be an object")
    return MappingProxyType({str(key): item for key, item in value.items()})


def _objects(value: Any) -> list[Mapping[str, Any]]:
    if value is None:
        return []
    if not isinstance(value, (list, tuple)):
        raise ValueError("TaskEnvelope.v1 collection field must be an array")
    return [_object(item) for item in value]


__all__ = [
    "RESOLUTION_PRECEDENCE",
    "ResolutionStatus",
    "TaskEnvelope",
    "resolution_satisfies_gate",
    "resolve_status",
]
