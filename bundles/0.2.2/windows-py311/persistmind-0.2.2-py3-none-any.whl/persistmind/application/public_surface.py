from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping
from pathlib import Path, PurePosixPath
from typing import Any

SourceRecordProvider = Callable[[str, int], Iterable[Mapping[str, Any]]]

_PUBLIC_INTENT_TERMS = {
    "add",
    "alias",
    "api",
    "compatibility",
    "create",
    "expose",
    "export",
    "facade",
    "function",
    "implement",
    "public",
    "service",
}


def task_exposes_public_functionality(task: str | None) -> bool:
    terms = {
        token.strip(".,:;()[]{}").casefold()
        for token in str(task or "").replace("-", " ").replace("_", " ").split()
    }
    return bool(terms & _PUBLIC_INTENT_TERMS) and bool(
        terms & {"add", "alias", "api", "create", "expose", "export", "function", "implement"}
    )


def derive_public_surface_files(
    paths: Iterable[str],
    *,
    repo_root: Path | None = None,
    known_paths: Iterable[str] = (),
    source_records: SourceRecordProvider | None = None,
) -> set[str]:
    normalized = {_normalize_path(path) for path in paths if str(path).strip()}
    known = {_normalize_path(path) for path in known_paths if str(path).strip()}
    surfaces: set[str] = set()
    for path in normalized:
        surfaces.update(_package_init_paths(path, repo_root=repo_root, known_paths=known))
    if source_records is not None and normalized:
        surfaces.update(_reexport_sources(normalized, source_records))
    return {path for path in surfaces if path and path not in normalized}


def _package_init_paths(
    path: str, *, repo_root: Path | None, known_paths: set[str]
) -> set[str]:
    pure = PurePosixPath(_normalize_path(path))
    if not pure.parts or pure.name == "__init__.py":
        return set()
    surfaces: set[str] = set()
    for parent in pure.parents:
        if str(parent) in {"", "."}:
            continue
        candidate = (parent / "__init__.py").as_posix()
        if candidate in known_paths or (repo_root is not None and (repo_root / candidate).exists()):
            surfaces.add(candidate)
    return surfaces


def _reexport_sources(
    normalized_paths: set[str], source_records: SourceRecordProvider
) -> set[str]:
    module_targets = {_module_name(path) for path in normalized_paths}
    package_inits = {
        (PurePosixPath(path).parent / "__init__.py").as_posix() for path in normalized_paths
    }
    surfaces: set[str] = set()
    for record in source_records("", 10_000):
        if record.get("kind") != "source_edge":
            continue
        source = _normalize_path(str(record.get("source") or record.get("path") or ""))
        target = _normalize_path(str(record.get("target") or ""))
        if source in normalized_paths:
            continue
        if target in module_targets or source in package_inits:
            surfaces.add(source)
    return surfaces


def _module_name(path: str) -> str:
    normalized = _normalize_path(path)
    return normalized.removesuffix(".py")


def _normalize_path(path: str) -> str:
    return str(path).replace("\\", "/").strip().lstrip("./")


__all__ = ["derive_public_surface_files", "task_exposes_public_functionality"]
