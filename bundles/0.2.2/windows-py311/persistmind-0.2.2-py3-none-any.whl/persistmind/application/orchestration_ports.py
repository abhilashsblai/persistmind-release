from __future__ import annotations

from collections.abc import Sequence
from typing import Any, Protocol


class OrchestrationTaskPort(Protocol):
    """Task-owned transactional gateway for the legacy orchestration model."""

    def __enter__(self) -> OrchestrationTaskPort: ...

    def __exit__(self, *args: object) -> None: ...

    def execute(self, statement: str, parameters: Sequence[Any] = ()) -> Any: ...


__all__ = ["OrchestrationTaskPort"]
