from __future__ import annotations

import importlib
from typing import Any

from persistmind.application.registry import OperationAvailability, operation_catalog

from .handlers import IMPLEMENTATIONS


def validate_active_handlers() -> dict[str, Any]:
    """Resolve every active handler without constructing services or opening storage."""
    failures: list[dict[str, str]] = []
    active = 0
    for descriptor in operation_catalog().values():
        if descriptor.availability is not OperationAvailability.ACTIVE:
            continue
        active += 1
        handler = str(descriptor.handler)
        try:
            if handler.startswith("builtin:"):
                if descriptor.operation_id not in IMPLEMENTATIONS:
                    raise AttributeError(handler)
                continue
            _, module_name, class_name, method_name = handler.split(":", 3)
            service_type = getattr(importlib.import_module(module_name), class_name)
            if not callable(getattr(service_type, method_name)):
                raise TypeError(f"handler is not callable: {handler}")
        except Exception as exc:  # noqa: BLE001 - return complete catalog diagnostics.
            failures.append(
                {"operation_id": descriptor.operation_id, "handler": handler, "error": str(exc)}
            )
    return {
        "ok": not failures,
        "status": "verified" if not failures else "invalid",
        "schema_version": "persistmind.active_handler_validation.v1",
        "active": active,
        "failures": failures,
    }


__all__ = ["validate_active_handlers"]
