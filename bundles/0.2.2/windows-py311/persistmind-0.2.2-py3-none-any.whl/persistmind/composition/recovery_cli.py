from __future__ import annotations

from pathlib import Path
from typing import Any

from .registry import OperationRegistry


def dispatch_storage_recovery(repo_root: Path, args: Any) -> dict[str, Any]:
    """Adapt the recovery CLI grammar to explicit catalog operations."""
    registry = OperationRegistry(repo_root, force_read_only=args.recover_command == "status")
    if args.recover_command == "plan":
        return registry.invoke(
            "storage_recovery_plan", {"authority": args.authority, "output": args.output}
        )
    if args.recover_command == "status":
        return registry.invoke("storage_recovery_status", {"stage_path": args.stage})
    if not args.yes:
        raise PermissionError(f"storage recover {args.recover_command} requires --yes")
    if args.recover_command == "stage":
        return registry.invoke(
            "storage_recovery_stage",
            {
                "plan_path": args.plan,
                "backup_destination": args.backup_destination,
                "backup_id": args.backup,
            },
        )
    if args.recover_command == "apply":
        return registry.invoke(
            "storage_recovery_apply",
            {"stage_path": args.stage, "loss_acceptance": args.loss_acceptance},
        )
    if args.recover_command == "rollback":
        return registry.invoke("storage_recovery_rollback", {"stage_path": args.stage})
    if args.recover_command == "finalize":
        return registry.invoke("storage_recovery_finalize", {"stage_path": args.stage})
    raise ValueError(f"unsupported storage recovery operation: {args.recover_command}")


__all__ = ["dispatch_storage_recovery"]
