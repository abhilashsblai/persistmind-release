from __future__ import annotations

from collections.abc import Callable
from typing import Any


class OperationClientTypingMixin:
    """Static view of catalog-generated client methods.

    The runtime client deliberately has no generic attribute fallback. The architecture
    generator and checker validate the exact generated method IDs and their concrete service
    signatures; this mixin exists only so static analysis can model those installed methods.
    """

    def __getattr__(self, _name: str) -> Callable[..., dict[str, Any]]:
        raise AttributeError(_name)
