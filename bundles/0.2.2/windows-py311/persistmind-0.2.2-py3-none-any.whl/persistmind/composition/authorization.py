from __future__ import annotations

from pathlib import Path

from persistmind.application.registry import OperationMode


def authorize_operation(
    repo_root: Path,
    *,
    operation_id: str,
    mode: OperationMode,
    authorization_action: str,
    roles: tuple[str, ...],
    scope_policy: str,
) -> None:
    if not authorization_action or not roles:
        raise PermissionError(f"operation has no executable authorization plan: {operation_id}")
    expected_suffix = ".read" if mode is OperationMode.QUERY else ".write"
    if not authorization_action.endswith(expected_suffix):
        raise PermissionError(
            f"operation authorization action does not match its mode: {operation_id}"
        )

    from persistmind.security.context import current_principal
    from persistmind.security.principals import anonymous_principal

    principal = current_principal()
    if principal is None:
        if mode is OperationMode.COMMAND:
            raise PermissionError(f"command requires a transport-bound principal: {operation_id}")
        principal = anonymous_principal(repo_root)
    if principal.is_expired():
        raise PermissionError("principal has expired")
    permitted_roles = (
        frozenset({"reader", "operator", "admin"})
        if mode is OperationMode.QUERY
        else frozenset({"operator", "admin"})
    )
    if not principal.roles & permitted_roles:
        raise PermissionError(f"principal lacks required role for {authorization_action}")
    if scope_policy in {"repository", "workspace_repository"} and not principal.permits_repo(
        repo_root
    ):
        raise PermissionError("principal repository scope mismatch")
    if scope_policy in {"workspace", "workspace_repository"} and not principal.permits_workspace(
        repo_root
    ):
        raise PermissionError("principal workspace scope mismatch")
    if mode is OperationMode.COMMAND:
        from persistmind.storage.control import StorageControlPlane

        kill_switch = StorageControlPlane(repo_root).kill_switch_status()
        if kill_switch.get("active"):
            raise PermissionError("Control kill switch is active; command execution is halted")


__all__ = ["authorize_operation"]
