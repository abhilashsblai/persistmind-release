from __future__ import annotations

import importlib
import inspect
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from persistmind.application.execution_scope import OperationExecutionScope, bind_operation_scope
from persistmind.application.registry import (
    OperationAvailability,
    OperationDescriptor,
    OperationMode,
    OperationUnavailableError,
    UnsupportedOperationError,
    descriptor_for,
    operation_catalog,
)

from .authorization import authorize_operation
from .handlers import IMPLEMENTATIONS, arguments

if TYPE_CHECKING:
    from .typing import OperationClientTypingMixin
else:
    OperationClientTypingMixin = object


@dataclass(frozen=True, slots=True)
class OperationRuntimePlan:
    operation_id: str
    mode: OperationMode
    roles: tuple[str, ...]
    scope_policy: str
    authorization_action: str

    @classmethod
    def from_descriptor(cls, descriptor: OperationDescriptor) -> OperationRuntimePlan:
        if descriptor.scope_policy not in {"workspace", "repository", "workspace_repository"}:
            raise ValueError(f"unsupported scope policy: {descriptor.scope_policy}")
        if (
            descriptor.mode is OperationMode.QUERY
            and "read-only" not in descriptor.query_guarantees
        ):
            raise ValueError(f"query lacks a read-only guarantee: {descriptor.operation_id}")
        runtime_roles = set(descriptor.required_roles)
        return cls(
            descriptor.operation_id,
            descriptor.mode,
            tuple(sorted(runtime_roles)),
            descriptor.scope_policy,
            descriptor.authorization_action,
        )


class OperationRegistry:
    """Invoke only catalog-declared handlers through a fixed execution order."""

    def __init__(self, repo_root: Path, *, force_read_only: bool = False) -> None:
        self.repo_root = repo_root.resolve()
        self.force_read_only = force_read_only

    def invoke(self, operation_id: str, request: Mapping[str, Any]) -> dict[str, Any]:
        descriptor = descriptor_for(operation_id)
        if descriptor.availability is not OperationAvailability.ACTIVE:
            raise OperationUnavailableError(descriptor)
        if self.force_read_only and descriptor.mode is OperationMode.COMMAND:
            raise PermissionError(f"read-only interface cannot invoke command: {operation_id}")
        plan = OperationRuntimePlan.from_descriptor(descriptor)
        self._authorize_capabilities(descriptor)
        self._authorize_local_action(plan)
        scope = OperationExecutionScope(
            operation_id=operation_id,
            mode=descriptor.mode,
            roles=frozenset(plan.roles),
            scope_policy=descriptor.scope_policy,
        )
        with bind_operation_scope(scope):
            implementation = IMPLEMENTATIONS.get(operation_id)
            if implementation is not None:
                result = implementation(self.repo_root, request)
            elif descriptor.handler and descriptor.handler.startswith("service:"):
                result = self._invoke_service(descriptor, request)
            else:
                raise UnsupportedOperationError(operation_id)
        if not isinstance(result, dict):
            raise RuntimeError(f"operation returned a non-object result: {operation_id}")
        return result

    def _authorize_local_action(self, plan: OperationRuntimePlan) -> None:
        authorize_operation(
            self.repo_root,
            operation_id=plan.operation_id,
            mode=plan.mode,
            authorization_action=plan.authorization_action,
            roles=plan.roles,
            scope_policy=plan.scope_policy,
        )

    def _invoke_service(
        self, descriptor: OperationDescriptor, request: Mapping[str, Any]
    ) -> dict[str, Any]:
        _, module_name, class_name, method_name = str(descriptor.handler).split(":", 3)
        module = importlib.import_module(module_name)
        service_type = getattr(module, class_name)
        constructor = inspect.signature(service_type)
        constructor_kwargs: dict[str, Any] = {}
        if "read_only" in constructor.parameters:
            constructor_kwargs["read_only"] = descriptor.mode is OperationMode.QUERY
        service = service_type(self.repo_root, **constructor_kwargs)
        try:
            method = getattr(service, method_name)
            args, kwargs = arguments(request)
            positional: list[Any] = []
            parameters = list(inspect.signature(method).parameters.values())
            for value in args:
                if not parameters:
                    positional.append(value)
                    continue
                parameter = parameters.pop(0)
                if parameter.kind is inspect.Parameter.KEYWORD_ONLY:
                    kwargs.setdefault(parameter.name, value)
                else:
                    positional.append(value)
            return dict(method(*positional, **kwargs))
        finally:
            close = getattr(service, "close", None)
            if callable(close):
                close()

    def _authorize_capabilities(self, descriptor: OperationDescriptor) -> None:
        if not descriptor.capabilities:
            return
        from persistmind.application.capability_gate import require_capabilities

        require_capabilities(self.repo_root, descriptor.capabilities)


class OperationClient(OperationClientTypingMixin):
    """Catalog-backed calling shape with an explicit generated method set.

    Methods are installed from the checked-in catalog at import time.  There is
    intentionally no ``__getattr__`` and no generic record store.
    """

    def __init__(self, repo_root: Path, *, read_only: bool = False) -> None:
        self.repo_root = repo_root.resolve()
        self.registry = OperationRegistry(self.repo_root, force_read_only=read_only)

    def close(self) -> None:
        return None

    def __enter__(self) -> OperationClient:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


def _operation_method(operation_id: str) -> Callable[..., dict[str, Any]]:
    def invoke(self: OperationClient, *args: Any, **kwargs: Any) -> dict[str, Any]:
        return self.registry.invoke(
            operation_id,
            {"operation_id": operation_id, "args": list(args), **kwargs},
        )

    invoke.__name__ = operation_id
    invoke.__qualname__ = f"OperationClient.{operation_id}"
    invoke.__doc__ = f"Invoke catalog operation ``{operation_id}``."
    return invoke


for _operation_id in operation_catalog():
    if _operation_id.isidentifier() and not hasattr(OperationClient, _operation_id):
        setattr(OperationClient, _operation_id, _operation_method(_operation_id))

del _operation_id


__all__ = ["OperationClient", "OperationRegistry", "OperationRuntimePlan"]
