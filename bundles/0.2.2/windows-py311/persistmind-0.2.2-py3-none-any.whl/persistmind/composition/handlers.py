from __future__ import annotations

from collections.abc import Callable, Mapping
from pathlib import Path
from typing import Any


OperationImplementation = Callable[[Path, Mapping[str, Any]], dict[str, Any]]


def arguments(request: Mapping[str, Any]) -> tuple[list[Any], dict[str, Any]]:
    positional = request.get("args") or ()
    if not isinstance(positional, (list, tuple)):
        positional = (positional,)
    return list(positional), {
        str(key): value for key, value in request.items() if key not in {"args", "operation_id"}
    }


def storage_bootstrap(repo_root: Path, request: Mapping[str, Any]) -> dict[str, Any]:
    del request
    from persistmind.storage.control import StorageControlPlane

    return StorageControlPlane(repo_root).bootstrap()


def source_build(repo_root: Path, request: Mapping[str, Any]) -> dict[str, Any]:
    del request
    from persistmind.storage.source_service import SourceService

    with SourceService(repo_root) as service:
        return service.build()


def snapshot_current(repo_root: Path, request: Mapping[str, Any]) -> dict[str, Any]:
    del request
    from persistmind.storage.source_service import SourceService

    with SourceService(repo_root, read_only=True) as service:
        return service.snapshot_current()


def snapshot_lineage(repo_root: Path, request: Mapping[str, Any]) -> dict[str, Any]:
    args, kwargs = arguments(request)
    snapshot_id = kwargs.pop("snapshot_id", args.pop(0) if args else None)
    limit = kwargs.pop("limit", args.pop(0) if args else 50)
    if kwargs:
        raise ValueError(f"unexpected snapshot lineage parameters: {sorted(kwargs)}")
    from persistmind.storage.source_service import SourceService

    with SourceService(repo_root, read_only=True) as service:
        return service.snapshot_lineage(snapshot_id, limit=int(limit))


def doctor(repo_root: Path, request: Mapping[str, Any]) -> dict[str, Any]:
    del request
    from persistmind.storage.control import StorageControlPlane

    return StorageControlPlane(repo_root).doctor()


def release_validate(repo_root: Path, request: Mapping[str, Any]) -> dict[str, Any]:
    args, kwargs = arguments(request)
    version = str(kwargs.pop("version", args.pop(0) if args else "current"))
    if kwargs:
        raise ValueError(f"unexpected release validation parameters: {sorted(kwargs)}")
    from persistmind.release.readiness import validate_release_contracts

    return validate_release_contracts(repo_root, version=version)


def runtime_status(repo_root: Path, request: Mapping[str, Any]) -> dict[str, Any]:
    del request
    from persistmind.storage.control import StorageControlPlane

    result = StorageControlPlane(repo_root).topology()
    return {
        "ok": bool(result.get("ok")),
        "status": result.get("status"),
        "schema_version": "persistmind.database_backend_status.v2",
        "backend": "sqlite-apsw",
        "topology": result,
    }


def mcp_capabilities(repo_root: Path, request: Mapping[str, Any]) -> dict[str, Any]:
    del repo_root, request
    from persistmind.server.mcp_server import READ_ONLY_MCP_TOOLS

    return {
        "ok": True,
        "schema_version": "persistmind.mcp_capabilities.v2",
        "mode": "read-only",
        "mutation_status": "transport_authority_required",
        "mutation_owner": "local-cli",
        "tools": sorted(READ_ONLY_MCP_TOOLS),
    }


def codex_enforcement_status(repo_root: Path, request: Mapping[str, Any]) -> dict[str, Any]:
    _, kwargs = arguments(request)
    probe = bool(kwargs.pop("probe", False))
    if kwargs:
        raise ValueError(f"unexpected Codex enforcement parameters: {sorted(kwargs)}")
    from persistmind.codex import enforcement_status
    from persistmind.setup import setup_readiness

    readiness = setup_readiness(
        repo_root,
        ["codex"],
        probe_mcp=False,
        live_probes=False,
    )
    return {
        **enforcement_status(repo_root, readiness),
        "probe_requested": probe,
        "runtime_probe": "deferred_nonrecursive",
    }


def codex_hook_event(repo_root: Path, request: Mapping[str, Any]) -> dict[str, Any]:
    args, kwargs = arguments(request)
    event = str(kwargs.pop("event", args.pop(0) if args else ""))
    payload = kwargs.pop("payload", args.pop(0) if args else {})
    if kwargs:
        raise ValueError(f"unexpected Codex hook parameters: {sorted(kwargs)}")
    if not event:
        raise ValueError("Codex hook event is required")
    from persistmind.agent_runtime.events import handle_host_hook_event

    return handle_host_hook_event(repo_root, event, payload)


def source_search(repo_root: Path, request: Mapping[str, Any]) -> dict[str, Any]:
    args, kwargs = arguments(request)
    query = str(kwargs.pop("term", kwargs.pop("query", args.pop(0) if args else "")))
    max_hops = int(kwargs.pop("max_hops", 2))
    limit = int(kwargs.pop("limit", 20))
    if kwargs:
        raise ValueError(f"unexpected source-search parameters: {sorted(kwargs)}")
    from persistmind.storage.source_service import SourceService

    with SourceService(repo_root, read_only=True) as service:
        result = service.search(query, limit=limit)
    result["max_hops"] = max_hops
    return result


def source_impact(repo_root: Path, request: Mapping[str, Any]) -> dict[str, Any]:
    args, kwargs = arguments(request)
    paths = kwargs.pop("paths", None)
    if paths is None:
        paths = [
            value
            for value in (
                kwargs.pop("path", None),
                kwargs.pop("source_path", None),
                kwargs.pop("target_path", None),
            )
            if value
        ]
    if not paths and args:
        paths = args.pop(0)
    max_hops = kwargs.pop("max_hops", None)
    limit = int(kwargs.pop("limit", 1000))
    if kwargs:
        raise ValueError(f"unexpected source-impact parameters: {sorted(kwargs)}")
    from persistmind.storage.source_service import SourceService

    with SourceService(repo_root, read_only=True) as service:
        result = service.impact(
            [paths] if isinstance(paths, str) else list(paths or []), limit=limit
        )
    if max_hops is not None:
        result["max_hops"] = int(max_hops)
    return result


def source_or_pack_impact(repo_root: Path, request: Mapping[str, Any]) -> dict[str, Any]:
    args, kwargs = arguments(request)
    pack_id = kwargs.pop("pack_id", args.pop(0) if args else None)
    paths = list(kwargs.pop("paths", None) or [])
    diff = kwargs.pop("diff", None)
    kwargs.pop("business", None)
    if kwargs:
        raise ValueError(f"unexpected impact parameters: {sorted(kwargs)}")
    if diff:
        from persistmind.git_utils import paths_from_diff

        paths.extend(paths_from_diff(str(diff)))
    if pack_id:
        from persistmind.storage.pack_service import PackService

        with PackService(repo_root, read_only=True) as service:
            return service.verify_paths(
                str(pack_id),
                paths,
                verification_name="impact",
                diff=str(diff) if diff else None,
            )
    return source_impact(repo_root, {"paths": paths})


def check_diff_against_pack(repo_root: Path, request: Mapping[str, Any]) -> dict[str, Any]:
    args, kwargs = arguments(request)
    pack_id = str(kwargs.pop("pack_id", args.pop(0) if args else ""))
    diff = kwargs.pop("diff", args.pop(0) if args else None)
    paths = list(kwargs.pop("paths", None) or [])
    if kwargs:
        raise ValueError(f"unexpected check-diff parameters: {sorted(kwargs)}")
    if diff:
        from persistmind.git_utils import paths_from_diff

        paths.extend(paths_from_diff(str(diff)))
    from persistmind.storage.pack_service import PackService

    with PackService(repo_root, read_only=False) as service:
        return service.verify_paths(
            pack_id,
            paths,
            verification_name="check-diff",
            diff=str(diff) if diff else None,
        )


def incident_query(repo_root: Path, request: Mapping[str, Any]) -> dict[str, Any]:
    operation_id = str(request.get("operation_id") or "")
    args, kwargs = arguments(request)
    from persistmind.reporting.service import ReportingService

    with ReportingService(repo_root, create=False) as reporting:
        if operation_id == "incident_list":
            return reporting.list(**kwargs)
        occurrence_id = str(kwargs.pop("occurrence_id", args.pop(0) if args else ""))
        if kwargs:
            raise ValueError(f"unexpected incident parameters: {sorted(kwargs)}")
        return (
            reporting.show(occurrence_id)
            if operation_id == "incident_show"
            else reporting.validate(occurrence_id)
        )


IMPLEMENTATIONS: dict[str, OperationImplementation] = {
    "mcp_capabilities": mcp_capabilities,
    "codex_enforcement_status": codex_enforcement_status,
    "codex_hook_event": codex_hook_event,
    "init": storage_bootstrap,
    "refresh_index": source_build,
    "resolve_snapshot": snapshot_current,
    "snapshot_current": snapshot_current,
    "snapshot_lineage": snapshot_lineage,
    "doctor": doctor,
    "release_check": release_validate,
    "release_validate": release_validate,
    "db_backend_status": runtime_status,
    "search_repo": source_search,
    "graph_neighbors": source_impact,
    "graph_path": source_impact,
    "graph_tests_for_path": source_impact,
    "graph_contracts_for_path": source_impact,
    "get_impact_report": source_or_pack_impact,
    "check_diff_against_pack": check_diff_against_pack,
    "incident_list": incident_query,
    "incident_show": incident_query,
    "incident_validate": incident_query,
}


__all__ = ["IMPLEMENTATIONS", "arguments"]
