"""Concrete PersistMind composition roots.

Application contracts remain storage-agnostic.  Transports import composition
roots when they need to bind those contracts to the local storage runtime.
"""

from .registry import OperationClient, OperationRegistry

__all__ = ["OperationClient", "OperationRegistry"]
