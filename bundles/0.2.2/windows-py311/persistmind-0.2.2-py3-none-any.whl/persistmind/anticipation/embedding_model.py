from __future__ import annotations

import json
from collections import Counter, defaultdict
from typing import Any

from persistmind.retrieval.embedder import Embedder, cosine, make_embedder

from .world_model import (
    MODEL_KIND as FREQUENCY_KIND,
    WorldModel,
    _calibration_from_outcome_stats,
    _dirname,
    _holdout_rows,
    _json,
    _json_list,
    _looks_critical,
    _outcome_failure_stats,
    _payload_paths,
    _seq_key,
    _top_terms,
)


MODEL_KIND = "embedding_v1"


class EmbeddingWorldModel:
    """Prototype-centroid semantic world model with the same surface as WorldModel."""

    def __init__(
        self,
        store: Any,
        repo_id: str,
        *,
        embedder: Embedder,
        transfer_patterns: list[dict[str, Any]] | None = None,
        kind: str = MODEL_KIND,
    ):
        self.store = store
        self.repo_id = repo_id
        self.embedder = embedder
        self.transfer_patterns = transfer_patterns or []
        self.kind = kind
        self._row: Any | None = None

    def train(
        self,
        *,
        workspace_id: str | None = None,
        outcome_rows: list[dict[str, Any]] | None = None,
    ) -> str:
        events = self._event_rows(workspace_id=workspace_id)
        buckets: dict[str, list[list[float]]] = defaultdict(list)
        event_vocab: set[str] = set()
        dir_counts: Counter[str] = Counter()
        last_by_session: dict[str, str] = {}
        trained_on_count = 0
        for row in events:
            session_id = str(row["session_id"])
            event_type = str(row["event_type"])
            payload = _json(row["payload_json"])
            previous = last_by_session.get(session_id, "START")
            context = context_from_event_payload(payload, previous_event=previous)
            observation = observation_from_event_payload(event_type, payload)
            descriptor = situation_descriptor(context, observation)
            bucket = _seq_key(str(context["state"]), previous)
            vector = self.embedder.embed(descriptor)
            buckets[bucket].append(vector)
            event_vocab.add(event_type)
            for path in observation["target_paths"]:
                dir_counts[_dirname(path)] += 1
            last_by_session[session_id] = event_type
            trained_on_count += 1

        outcome_rows = self._outcome_rows() if outcome_rows is None else outcome_rows
        outcome_stats = _outcome_failure_stats(outcome_rows)
        holdout_stats = _outcome_failure_stats(_holdout_rows(outcome_rows))
        outcome_priors = {
            key: value["smoothed_failure_rate"] for key, value in sorted(outcome_stats.items())
        }
        failure_prototypes = self._failure_prototypes(outcome_stats)
        transfer_prototypes = self._transfer_failure_prototypes()
        failure_prototypes.extend(transfer_prototypes)
        params = {
            "schema": "persistmind.anticipation.embedding_v1",
            "repo_id": self.repo_id,
            "embedder": self._embedder_signature(),
            "normal_prototypes": [
                {
                    "seq_key": key,
                    "vector": _round_vector(_centroid(vectors)),
                    "count": len(vectors),
                }
                for key, vectors in sorted(buckets.items())
                if vectors
            ],
            "failure_prototypes": failure_prototypes,
            "dir_counts": dict(sorted(dir_counts.items())),
            "event_vocab": sorted(event_vocab),
            "outcome_failure_prior": outcome_priors,
            "failure_lesson_prior": self._failure_lesson_priors(),
            "weights": {"novelty": 0.40, "danger": 0.35, "failure_prior": 0.25},
            "smoothing": 1.0,
        }
        calibration = _calibration_from_outcome_stats(outcome_stats, holdout_stats)
        model_id = self.store.put_anticipation_model(
            repo_id=self.repo_id,
            workspace_id=workspace_id,
            kind=self.kind,
            params=params,
            calibration=calibration,
            trained_on_count=max(trained_on_count, len(transfer_prototypes)),
            ece=calibration.get("ece"),
        )
        self._row = self.store.conn.execute(
            "SELECT * FROM anticipation_models WHERE model_id = ?", (model_id,)
        ).fetchone()
        return model_id

    def latest(self) -> dict[str, Any] | None:
        row = self._latest_row()
        if row is None:
            return None
        return {
            "model_id": row["model_id"],
            "repo_id": row["repo_id"],
            "workspace_id": row["workspace_id"],
            "kind": row["kind"],
            "params": json.loads(row["params_json"] or "{}"),
            "calibration": json.loads(row["calibration_json"] or "{}"),
            "trained_on_count": int(row["trained_on_count"] or 0),
            "ece": row["ece"],
            "params_hash": row["params_hash"],
            "created_at": row["created_at"],
        }

    def predict(self, context: dict[str, Any]) -> dict[str, Any]:
        model = self.latest()
        if not model or int(model["trained_on_count"] or 0) <= 0:
            return _cold_start()
        params = model["params"]
        active_dir = _dirname(str(context.get("active_path") or context.get("active_dir") or ""))
        failure_prior = float(
            params.get("outcome_failure_prior", {}).get(
                active_dir, params.get("failure_lesson_prior", {}).get(active_dir, 0.0)
            )
            or 0.0
        )
        return {
            "model_id": model["model_id"],
            "params_hash": model["params_hash"],
            "event_type": _uniform(params.get("event_vocab", [])),
            "target_dir": _uniform(list(params.get("dir_counts", {}).keys())),
            "failure_prior": round(failure_prior, 6),
            "normality": None,
            "danger": None,
        }

    def score_observation(
        self, *, context: dict[str, Any], observation: dict[str, Any]
    ) -> dict[str, Any]:
        model = self.latest()
        if not model or int(model["trained_on_count"] or 0) <= 0:
            return _cold_start()
        params = model["params"]
        vector = self.situation_vector(context, observation)
        role_tags = _role_tags_for_paths(observation.get("target_paths", []))
        normality = _max_cosine(vector, params.get("normal_prototypes", []))
        danger = max(
            _max_cosine(vector, params.get("failure_prototypes", [])),
            _role_danger_for(role_tags, params.get("failure_prototypes", [])),
        )
        target_dir = str(observation.get("target_dir") or "")
        outcome_prior = float(params.get("outcome_failure_prior", {}).get(target_dir, 0.0) or 0.0)
        lesson_prior = float(params.get("failure_lesson_prior", {}).get(target_dir, 0.0) or 0.0)
        transfer_prior = _transfer_prior_for(
            role_tags,
            params.get("failure_prototypes", []),
        )
        failure_prior = min(1.0, max(outcome_prior, lesson_prior, transfer_prior))
        weights = params.get("weights", {})
        novelty = 1.0 - normality
        raw = (
            float(weights.get("novelty", 0.40)) * novelty
            + float(weights.get("danger", 0.35)) * danger
            + float(weights.get("failure_prior", 0.25)) * failure_prior
        )
        return {
            "model_id": model["model_id"],
            "params_hash": model["params_hash"],
            "surprise_raw": round(min(1.0, max(0.0, raw)), 6),
            "failure_prior": round(failure_prior, 6),
            "normality": round(normality, 6),
            "danger": round(danger, 6),
            "components": {
                "novelty": round(novelty, 6),
                "danger": round(danger, 6),
                "failure_prior": round(failure_prior, 6),
                "normality": round(normality, 6),
                "transfer_prior": round(transfer_prior, 6),
            },
        }

    def situation_vector(self, context: dict[str, Any], observation: dict[str, Any]) -> list[float]:
        return self.embedder.embed(situation_descriptor(context, observation))

    def _latest_row(self) -> Any | None:
        if self._row is None:
            self._row = self.store.latest_anticipation_model(repo_id=self.repo_id, kind=self.kind)
        return self._row

    def _event_rows(self, *, workspace_id: str | None) -> list[Any]:
        clauses = ["s.repo_id = ?"]
        params: list[Any] = [self.repo_id]
        if workspace_id:
            clauses.append("s.workspace_id = ?")
            params.append(workspace_id)
        return self.store.conn.execute(
            f"""
            SELECT e.*, s.workspace_id, s.repo_id
            FROM agent_session_events e
            JOIN agent_sessions s ON s.session_id = e.session_id
            WHERE {" AND ".join(clauses)}
            ORDER BY e.event_time, e.event_id
            """,
            params,
        ).fetchall()

    def _outcome_rows(self) -> list[dict[str, Any]]:
        rows = self.store.conn.execute(
            "SELECT result, files_changed_json FROM outcomes ORDER BY rowid"
        ).fetchall()
        return [
            {
                "result": str(row["result"] or ""),
                "files": _json_list(row["files_changed_json"]),
            }
            for row in rows
        ]

    def _failure_prototypes(self, outcome_stats: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
        prototypes: list[dict[str, Any]] = []
        for directory, stats in sorted(outcome_stats.items()):
            if int(stats.get("failures", 0) or 0) <= 0:
                continue
            descriptor = (
                "state=outcome last=verification task=failure "
                f"action=outcome_failure dir={directory} critical={_looks_critical(directory)}"
            )
            prototypes.append(
                {
                    "vector": _round_vector(self.embedder.embed(descriptor)),
                    "count": int(stats["failures"]),
                    "failure_prior": float(stats["smoothed_failure_rate"]),
                    "role_tags": _role_tags_for_paths([directory]),
                    "source": "local_outcome",
                }
            )
        for directory, prior in self._failure_lesson_priors().items():
            descriptor = (
                "state=memory last=lesson task=failure "
                f"action=failure_lesson dir={directory} critical={_looks_critical(directory)}"
            )
            prototypes.append(
                {
                    "vector": _round_vector(self.embedder.embed(descriptor)),
                    "count": 1,
                    "failure_prior": float(prior),
                    "role_tags": _role_tags_for_paths([directory]),
                    "source": "failure_lesson",
                }
            )
        return prototypes

    def _transfer_failure_prototypes(self) -> list[dict[str, Any]]:
        prototypes = []
        for item in self.transfer_patterns:
            vector = item.get("vector")
            if not isinstance(vector, list):
                continue
            prototypes.append(
                {
                    "vector": _round_vector([float(value) for value in vector]),
                    "count": int(item.get("count", 1) or 1),
                    "failure_prior": float(item.get("failure_prior", 0.0) or 0.0),
                    "role_tags": sorted(str(tag) for tag in item.get("role_tags", [])),
                    "source": "transfer",
                    "transfer_weight": float(item.get("transfer_weight", 0.0) or 0.0),
                }
            )
        return prototypes

    def _failure_lesson_priors(self) -> dict[str, float]:
        priors: dict[str, float] = {}
        try:
            rows = self.store.memory_records(type="failure_lesson", repo_id=self.repo_id)
        except Exception:
            rows = []
        for row in rows:
            text = " ".join(
                str(row[key] or "")
                for key in ("subject_key", "assertion", "applies_when", "avoid_when")
                if key in row.keys()
            )
            for token in text.replace("\\", "/").split():
                if "/" not in token:
                    continue
                priors[_dirname(token.strip("`'\".,:;()[]{}"))] = 0.8
        return dict(sorted(priors.items()))

    def _embedder_signature(self) -> dict[str, Any]:
        signature = {
            "name": self.embedder.model_name,
            "dim": int(self.embedder.dims),
            "backend": str(getattr(self.embedder, "backend", "unknown")),
        }
        degraded_reason = getattr(self.embedder, "degraded_reason", None)
        if degraded_reason:
            signature["degraded"] = degraded_reason
        return signature

    def embedder_status(self) -> dict[str, Any]:
        return self._embedder_signature()


def build_world_model(store: Any, repo_id: str, settings: Any | None = None) -> Any:
    anticipation = getattr(settings, "anticipation", None)
    model_config = getattr(anticipation, "model", None)
    kind = str(getattr(model_config, "kind", FREQUENCY_KIND))
    if kind == MODEL_KIND:
        toolchain = getattr(settings, "toolchain", None)
        embedder = make_embedder(
            model_name=str(getattr(toolchain, "embed_model", "local-lexical-v1")),
            backend=str(getattr(toolchain, "embed_backend", "auto")),
        )
        transfer_patterns = []
        transfer = getattr(getattr(settings, "anticipation", None), "transfer", None)
        if transfer and bool(getattr(transfer, "enabled", False)):
            from .pattern_library import PatternLibrary

            transfer_patterns = PatternLibrary(
                library=str(getattr(transfer, "library", "user")),
                max_transfer_weight=float(getattr(transfer, "max_transfer_weight", 0.4)),
                embedder_signature={
                    "name": embedder.model_name,
                    "dim": embedder.dims,
                    "backend": str(getattr(embedder, "backend", "unknown")),
                },
            ).import_for(repo_id)
        return EmbeddingWorldModel(
            store, repo_id, embedder=embedder, transfer_patterns=transfer_patterns
        )
    return WorldModel(store, repo_id)


def context_from_event_payload(payload: dict[str, Any], *, previous_event: str) -> dict[str, Any]:
    paths = _payload_paths(payload)
    active = paths[0] if paths else ""
    task_text = str(payload.get("task") or payload.get("task_text") or "")
    return {
        "task_terms": _top_terms(task_text),
        "state": str(payload.get("state") or payload.get("task_state") or "unknown"),
        "last_event": previous_event,
        "active_dir": _dirname(active),
        "active_path": active,
    }


def observation_from_event_payload(event_type: str, payload: dict[str, Any]) -> dict[str, Any]:
    paths = _payload_paths(payload)
    return {
        "event_type": event_type,
        "target_paths": paths,
        "target_dir": _dirname(paths[0]) if paths else "",
        "touches_critical": any(_looks_critical(path) for path in paths),
    }


def situation_descriptor(context: dict[str, Any], observation: dict[str, Any]) -> str:
    return (
        f"state={context.get('state') or 'unknown'} "
        f"last={context.get('last_event') or 'START'} "
        f"task={' '.join(str(term) for term in context.get('task_terms', []))} "
        f"action={observation.get('event_type') or '__other__'} "
        f"dir={observation.get('target_dir') or context.get('active_dir') or ''} "
        f"critical={bool(observation.get('touches_critical'))}"
    )


def _centroid(vectors: list[list[float]]) -> list[float]:
    if not vectors:
        return []
    dims = len(vectors[0])
    return [sum(vector[i] for vector in vectors) / len(vectors) for i in range(dims)]


def _round_vector(vector: list[float]) -> list[float]:
    return [round(float(value), 6) for value in vector]


def _max_cosine(vector: list[float], prototypes: list[dict[str, Any]]) -> float:
    if not vector or not prototypes:
        return 0.0
    return max(
        0.0,
        max(cosine(vector, [float(v) for v in item.get("vector", [])]) for item in prototypes),
    )


def _uniform(keys: list[str]) -> dict[str, float]:
    values = sorted(set(keys) | {"__other__"})
    probability = round(1.0 / len(values), 6) if values else 1.0
    return {key: probability for key in values}


def _cold_start() -> dict[str, Any]:
    return {
        "model_id": None,
        "reason": "insufficient_history",
        "event_type": {},
        "target_dir": {},
        "failure_prior": 0.0,
    }


def _transfer_prior_for(role_tags: list[str], prototypes: list[dict[str, Any]]) -> float:
    wanted = set(role_tags)
    prior = 0.0
    for item in prototypes:
        if item.get("source") != "transfer":
            continue
        tags = set(str(tag) for tag in item.get("role_tags", []))
        if wanted and not wanted.intersection(tags):
            continue
        prior = max(
            prior,
            float(item.get("failure_prior", 0.0) or 0.0)
            * float(item.get("transfer_weight", 0.0) or 0.0),
        )
    return min(1.0, prior)


def _role_danger_for(role_tags: list[str], prototypes: list[dict[str, Any]]) -> float:
    wanted = set(role_tags)
    if not wanted:
        return 0.0
    for item in prototypes:
        tags = set(str(tag) for tag in item.get("role_tags", []))
        if wanted.intersection(tags):
            return min(0.85, max(0.55, float(item.get("failure_prior", 0.55) or 0.55)))
    return 0.0


def _role_tags_for_paths(paths: list[str]) -> list[str]:
    tags: set[str] = set()
    for path in paths:
        lowered = str(path).replace("\\", "/").lower()
        if (
            "auth" in lowered
            or "session" in lowered
            or "token" in lowered
            or "login" in lowered
            or "credential" in lowered
            or "oauth" in lowered
        ):
            tags.add("auth")
        if "billing" in lowered:
            tags.add("billing")
        if "payment" in lowered:
            tags.add("payments")
        if "migration" in lowered or "schema" in lowered:
            tags.add("migration")
        if "test" in lowered or "spec" in lowered:
            tags.add("test")
        if "config" in lowered or lowered.endswith((".toml", ".yaml", ".yml", ".json")):
            tags.add("config")
        if "generated" in lowered or "dist/" in lowered or "build/" in lowered:
            tags.add("generated")
    return sorted(tags or {"general"})
