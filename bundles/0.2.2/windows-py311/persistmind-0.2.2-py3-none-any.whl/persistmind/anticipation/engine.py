from __future__ import annotations

import json
from typing import Any

from persistmind.learning.online import OnlineLearner

from .efe import EFEScorer
from .embedding_model import build_world_model
from .interoception import InteroceptiveState
from .surprise import SurpriseEngine
from .world_model import context_from_payload, observation_from_event


class AnticipationEngine:
    """Facade for world-model training, surprise scoring, EFE, gut, and online updates."""

    def __init__(
        self,
        store: Any,
        repo_id: str,
        *,
        workspace_id: str | None = None,
        snapshot_resolver: Any | None = None,
        impact_engine: Any | None = None,
        behavior_engine: Any | None = None,
        settings: Any | None = None,
    ):
        self.store = store
        self.repo_id = repo_id
        self.workspace_id = workspace_id
        self.snapshot_resolver = snapshot_resolver
        self.impact_engine = impact_engine
        self.behavior_engine = behavior_engine
        self.settings = settings
        self.world_model = build_world_model(store, repo_id, settings)
        self.surprise = SurpriseEngine(store, self.world_model)

    def train(self, **kw: Any) -> dict[str, Any]:
        workspace_id = kw.get("workspace_id", self.workspace_id)
        model_id = self.world_model.train(workspace_id=workspace_id)
        model = self.world_model.latest()
        return {
            "ok": True,
            "model_id": model_id,
            "repo_id": self.repo_id,
            "trained_on_count": int(model["trained_on_count"] or 0) if model else 0,
            "ece": (float(model["ece"] or 0.0) if model and model["ece"] is not None else 0.0),
            "params_hash": model["params_hash"] if model else None,
        }

    def status(self) -> dict[str, Any]:
        model = self.world_model.latest()
        embedder = (
            self.world_model.embedder_status()
            if hasattr(self.world_model, "embedder_status")
            else None
        )
        degraded = (
            str(embedder.get("degraded"))
            if isinstance(embedder, dict) and embedder.get("degraded")
            else None
        )
        prediction_count = self.store.conn.execute(
            "SELECT COUNT(*) AS count FROM anticipation_predictions WHERE repo_id = ?",
            (self.repo_id,),
        ).fetchone()["count"]
        return {
            "ok": True,
            "repo_id": self.repo_id,
            "cold_start": model is None or int(model["trained_on_count"] or 0) <= 0,
            "embedder": embedder,
            "degraded": degraded,
            "latest_model": (
                None
                if model is None
                else {
                    "model_id": model["model_id"],
                    "kind": model["kind"],
                    "trained_on_count": int(model["trained_on_count"] or 0),
                    "ece": (float(model["ece"] or 0.0) if model["ece"] is not None else None),
                    "params_hash": model["params_hash"],
                    "created_at": model["created_at"],
                    "embedder": (model.get("params") or {}).get("embedder"),
                }
            ),
            "prediction_count": int(prediction_count or 0),
        }

    def score_action(
        self,
        *,
        context: dict[str, Any],
        observation: dict[str, Any],
        session_id: str | None = None,
        task_session_id: str | None = None,
        online: bool = True,
    ) -> dict[str, Any]:
        learner = (
            OnlineLearner(self.store, self.repo_id, session_id) if online and session_id else None
        )
        return self.surprise.score(
            context=context,
            observation=observation,
            session_id=session_id,
            task_session_id=task_session_id,
            online=learner,
        )

    def score_session(self, *, session_id: str) -> dict[str, Any]:
        events = self.store.agent_session_events(session_id)
        scores = []
        previous = "START"
        for event in events:
            payload = _json(event["payload_json"])
            context = context_from_payload(payload, previous_event=previous)
            observation = observation_from_event(event["event_type"], payload)
            scores.append(
                {
                    "event_id": event["event_id"],
                    "event_type": event["event_type"],
                    **self.score_action(
                        context=context,
                        observation=observation,
                        session_id=session_id,
                    ),
                }
            )
            previous = str(event["event_type"])
        return {"ok": True, "session_id": session_id, "scores": scores}

    def lookahead(
        self,
        *,
        snapshot: Any,
        task: str,
        current_paths: list[str],
        candidates: list[dict[str, Any]] | None = None,
        pack: dict[str, Any] | None = None,
        top_k: int = 5,
    ) -> dict[str, Any]:
        if self.impact_engine is None:
            raise ValueError("anticipation lookahead requires an impact engine")
        scorer = EFEScorer(self.store, self.world_model, self.impact_engine)
        return scorer.score(
            snapshot=snapshot,
            task=task,
            current_paths=current_paths,
            candidates=candidates,
            pack=pack,
            top_k=top_k,
        )

    def simulate(
        self,
        *,
        snapshot: Any,
        task: str,
        current_paths: list[str],
        candidates: list[dict[str, Any]] | None = None,
        pack: dict[str, Any] | None = None,
        depth: int = 2,
        beam: int = 3,
    ) -> dict[str, Any]:
        if self.impact_engine is None:
            raise ValueError("anticipation simulate requires an impact engine")
        scorer = EFEScorer(self.store, self.world_model, self.impact_engine)
        return scorer.rollout(
            snapshot=snapshot,
            task=task,
            current_paths=current_paths,
            candidates=candidates,
            pack=pack,
            depth=depth,
            beam=beam,
        )

    def gut(
        self,
        *,
        session_id: str,
        task_session_id: str | None = None,
        active_paths: list[str] | None = None,
    ) -> dict[str, Any]:
        state = InteroceptiveState(
            self.store,
            self.repo_id,
            behavior_engine=self.behavior_engine,
            impact_engine=self.impact_engine,
        )
        return state.vector(
            session_id=session_id,
            task_session_id=task_session_id,
            active_paths=active_paths,
        )

    def observe(
        self,
        *,
        session_id: str,
        signal_kind: str,
        context: dict[str, Any],
        observation: dict[str, Any],
        magnitude: float = 1.0,
        task_session_id: str | None = None,
    ) -> dict[str, Any]:
        learner = OnlineLearner(self.store, self.repo_id, session_id)
        update_id = learner.observe(
            signal_kind=signal_kind,
            context=context,
            observation=observation,
            magnitude=magnitude,
            task_session_id=task_session_id,
        )
        return {"ok": True, "update_id": update_id}


def _json(value: str | None) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}
