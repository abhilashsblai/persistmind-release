from __future__ import annotations

import re
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any


UI_EXTENSIONS = {".html", ".jsx", ".tsx", ".vue", ".svelte"}
SCRIPT_EXTENSIONS = {".js", ".ts"}
SKIP_DIRS = {
    ".persistmind",
    ".persistmind",
    ".git",
    ".mypy_cache",
    ".pytest_cache",
    "__pycache__",
    "coverage",
    "dist",
    "node_modules",
}
LABEL_ATTR_RE = re.compile(
    r"""(?:aria-label|title|label|placeholder)\s*=\s*["']([^"']{2,80})["']""",
    re.IGNORECASE,
)
JSX_TEXT_RE = re.compile(r">([^<>{}\n][^<>{}]{1,80})<")
STRING_RE = re.compile(r"""["']([A-Za-z][A-Za-z0-9 &/_:-]{2,80})["']""")
COMPONENT_RE = re.compile(r"\b(?:function|const)\s+([A-Z][A-Za-z0-9_]*)")

STOP_WORDS = {
    "all",
    "card",
    "cards",
    "count",
    "current",
    "dashboard",
    "display",
    "metric",
    "metrics",
    "number",
    "section",
    "summary",
    "the",
    "total",
    "widget",
    "widgets",
}
KPI_TERMS = {
    "active",
    "amount",
    "billable",
    "case",
    "cases",
    "closed",
    "completed",
    "count",
    "hour",
    "hours",
    "kpi",
    "matter",
    "matters",
    "metric",
    "open",
    "overdue",
    "pending",
    "revenue",
    "status",
    "task",
    "tasks",
    "ticket",
    "tickets",
    "widget",
}
SYNONYMS = {
    "case": "matter",
    "cases": "matter",
    "hour": "hours",
    "issue": "ticket",
    "issues": "ticket",
    "matter": "matter",
    "matters": "matter",
    "task": "task",
    "tasks": "task",
    "ticket": "ticket",
    "tickets": "ticket",
}


@dataclass(frozen=True)
class UISurfaceItem:
    label: str
    concept: str
    path: str
    line: int
    route: str
    section: str
    source: str = "repo"

    def as_dict(self) -> dict[str, Any]:
        return {
            "label": self.label,
            "concept": self.concept,
            "path": self.path,
            "line": self.line,
            "route": self.route,
            "section": self.section,
            "source": self.source,
        }


def review_ui_redundancy(
    repo_root: Path,
    *,
    task: str = "",
    paths: list[str] | None = None,
    proposed_content: str | None = None,
    proposed_path: str | None = None,
    max_findings: int = 5,
) -> dict[str, Any]:
    """Return deterministic visible-label redundancy findings for UI work.

    This is intentionally conservative: it only warns on repeated normalized
    UI concepts, and it gives stronger weight to KPI/status labels on the same
    inferred route.
    """

    root = Path(repo_root)
    selected_paths = [_normalize_path(path) for path in paths or [] if path]
    relevant = _looks_like_ui_task(task, selected_paths, proposed_path)
    repo_items = _scan_repo(root)
    proposed_items: list[UISurfaceItem] = []
    if proposed_content and proposed_path:
        proposed_items = _extract_items(
            proposed_path,
            proposed_content,
            source="proposed",
        )
        relevant = relevant or bool(proposed_items)

    active_paths = set(selected_paths)
    if proposed_path:
        active_paths.add(_normalize_path(proposed_path))
    findings = _find_duplicates(
        repo_items=repo_items,
        proposed_items=proposed_items,
        active_paths=active_paths,
        task=task,
        max_findings=max_findings,
        force_scope=relevant,
    )
    return {
        "schema_version": "persistmind.ui_redundancy.v1",
        "ok": not findings,
        "relevant": relevant,
        "finding_count": len(findings),
        "findings": findings,
        "surface_count": len(repo_items) + len(proposed_items),
        "active_paths": sorted(active_paths),
        "message": _message(findings),
    }


def _scan_repo(root: Path) -> list[UISurfaceItem]:
    items: list[UISurfaceItem] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or _skip(path, root):
            continue
        rel = _normalize_path(path.relative_to(root).as_posix())
        if not _is_ui_path(rel):
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        items.extend(_extract_items(rel, text, source="repo"))
    return items


def _extract_items(path: str, text: str, *, source: str) -> list[UISurfaceItem]:
    route = _route_for(path, text)
    items: list[UISurfaceItem] = []
    for match in list(LABEL_ATTR_RE.finditer(text)) + list(JSX_TEXT_RE.finditer(text)):
        label = _clean_label(match.group(1))
        if not _useful_label(label):
            continue
        concept = _concept(label)
        if not concept:
            continue
        line = text.count("\n", 0, match.start()) + 1
        items.append(
            UISurfaceItem(
                label=label,
                concept=concept,
                path=_normalize_path(path),
                line=line,
                route=route,
                section=_section_for(text, line, path),
                source=source,
            )
        )
    if _is_frontend_script(path):
        for match in STRING_RE.finditer(text):
            label = _clean_label(match.group(1))
            if not _useful_label(label) or not _kpi_like(label):
                continue
            concept = _concept(label)
            if not concept:
                continue
            line = text.count("\n", 0, match.start()) + 1
            items.append(
                UISurfaceItem(
                    label=label,
                    concept=concept,
                    path=_normalize_path(path),
                    line=line,
                    route=route,
                    section=_section_for(text, line, path),
                    source=source,
                )
            )
    return _dedupe_items(items)


def _find_duplicates(
    *,
    repo_items: list[UISurfaceItem],
    proposed_items: list[UISurfaceItem],
    active_paths: set[str],
    task: str,
    max_findings: int,
    force_scope: bool,
) -> list[dict[str, Any]]:
    all_items = repo_items + proposed_items
    pairs: list[tuple[float, dict[str, Any]]] = []
    for index, left in enumerate(all_items):
        for right in all_items[index + 1 :]:
            if not _comparable(left, right, active_paths, force_scope):
                continue
            score = _similarity(left.concept, right.concept)
            if score < 0.86:
                continue
            if left.path == right.path and left.line == right.line:
                continue
            kpi = _kpi_like(left.label) or _kpi_like(right.label)
            if not kpi and "dashboard" not in task.lower():
                continue
            severity = "high" if kpi and left.route == right.route else "medium"
            pairs.append(
                (
                    score + (0.1 if kpi else 0.0),
                    {
                        "kind": "duplicate_ui_concept",
                        "severity": severity,
                        "concept": left.concept,
                        "similarity": round(score, 3),
                        "route": left.route if left.route == right.route else None,
                        "recommendation": (
                            "consolidate repeated KPI/status widgets or document why "
                            "the duplicate presentation is intentional"
                        ),
                        "existing": left.as_dict(),
                        "candidate": right.as_dict(),
                    },
                )
            )
    pairs = sorted(
        pairs,
        key=lambda item: (
            -item[0],
            item[1]["existing"]["path"],
            item[1]["candidate"]["path"],
        ),
    )
    return [item for _score, item in pairs[:max_findings]]


def _comparable(
    left: UISurfaceItem,
    right: UISurfaceItem,
    active_paths: set[str],
    force_scope: bool,
) -> bool:
    if left.concept == "" or right.concept == "":
        return False
    if left.route != right.route:
        return False
    if left.section == right.section and left.path == right.path:
        return False
    if left.source == "proposed" or right.source == "proposed":
        return True
    if not active_paths:
        return force_scope
    return left.path in active_paths or right.path in active_paths or force_scope


def _route_for(path: str, text: str) -> str:
    lowered = path.lower().replace("\\", "/")
    route_match = re.search(r"['\"](/[-A-Za-z0-9_/]+)['\"]", text)
    if route_match and len(route_match.group(1)) > 1:
        return route_match.group(1).rstrip("/")
    for token in ("dashboard", "home", "settings", "notifications", "reports"):
        if token in lowered:
            return f"/{token}"
    return "/" + Path(lowered).stem.replace("index", "").strip("-_")


def _section_for(text: str, line: int, path: str) -> str:
    start = max(0, line - 8)
    end = line + 4
    nearby = "\n".join(text.splitlines()[start:end]).lower()
    for token in (
        "hero",
        "header",
        "summary",
        "kpi",
        "metric",
        "action",
        "quick",
        "sidebar",
        "body",
        "footer",
    ):
        if token in nearby or token in path.lower():
            return token
    component = COMPONENT_RE.search(text)
    return component.group(1) if component else "unknown"


def _concept(label: str) -> str:
    tokens = []
    for raw in re.findall(r"[A-Za-z0-9]+", label.lower()):
        token = SYNONYMS.get(raw, raw)
        if token in STOP_WORDS:
            continue
        if len(token) > 3 and token.endswith("s") and token not in {"hours"}:
            token = token[:-1]
        tokens.append(token)
    return " ".join(tokens)


def _similarity(left: str, right: str) -> float:
    if left == right:
        return 1.0
    left_tokens = set(left.split())
    right_tokens = set(right.split())
    if not left_tokens or not right_tokens:
        return 0.0
    jaccard = len(left_tokens & right_tokens) / len(left_tokens | right_tokens)
    sequence = SequenceMatcher(None, left, right).ratio()
    return max(jaccard, sequence)


def _clean_label(label: str) -> str:
    return re.sub(r"\s+", " ", label).strip(" -:_\t\r\n")


def _useful_label(label: str) -> bool:
    if len(label) < 3 or len(label) > 80:
        return False
    if "{" in label or "}" in label or "<" in label:
        return False
    return any(char.isalpha() for char in label)


def _kpi_like(label: str) -> bool:
    tokens = set(re.findall(r"[A-Za-z0-9]+", label.lower()))
    return bool(tokens & KPI_TERMS)


def _looks_like_ui_task(task: str, paths: list[str], proposed_path: str | None = None) -> bool:
    text = " ".join([task, proposed_path or "", *paths]).lower()
    return any(
        token in text
        for token in (
            "dashboard",
            "frontend",
            "widget",
            "kpi",
            "metric",
            ".tsx",
            ".jsx",
            ".html",
        )
    )


def _is_ui_path(path: str) -> bool:
    suffix = Path(path).suffix.lower()
    if suffix in UI_EXTENSIONS:
        return True
    return suffix in SCRIPT_EXTENSIONS and any(
        token in path.lower()
        for token in ("component", "dashboard", "page", "route", "screen", "view")
    )


def _is_frontend_script(path: str) -> bool:
    return Path(path).suffix.lower() in UI_EXTENSIONS | SCRIPT_EXTENSIONS


def _skip(path: Path, root: Path) -> bool:
    try:
        rel_parts = path.relative_to(root).parts
    except ValueError:
        rel_parts = path.parts
    return any(part in SKIP_DIRS or part.startswith("pytesttmp") for part in rel_parts)


def _dedupe_items(items: list[UISurfaceItem]) -> list[UISurfaceItem]:
    deduped: dict[tuple[str, str, int, str], UISurfaceItem] = {}
    for item in items:
        deduped[(item.path, item.concept, item.line, item.source)] = item
    return list(deduped.values())


def _normalize_path(path: str) -> str:
    return str(path).replace("\\", "/").removeprefix("./")


def _message(findings: list[dict[str, Any]]) -> str:
    if not findings:
        return "No repeated visible UI concepts detected."
    first = findings[0]
    return (
        "Repeated UI concept detected: "
        f"{first['concept']} appears in "
        f"{first['existing']['section']} and {first['candidate']['section']}."
    )
