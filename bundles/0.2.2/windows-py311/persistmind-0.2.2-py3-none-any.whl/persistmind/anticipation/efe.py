from __future__ import annotations

import math
from pathlib import Path
from typing import Any

ScoredCandidate = dict[str, Any]
RolloutNode = dict[str, Any]


class EFEScorer:
    def __init__(self, store: Any, world_model: Any, impact_engine: Any):
        self.store = store
        self.world_model = world_model
        self.impact_engine = impact_engine

    def predict_change_set(
        self, *, candidate: dict[str, Any], context: dict[str, Any]
    ) -> dict[str, Any]:
        paths = [
            _normalize_path(path)
            for path in candidate.get("paths", []) or candidate.get("current_paths", []) or []
            if str(path).strip()
        ]
        if not paths and candidate.get("path"):
            paths = [_normalize_path(str(candidate["path"]))]
        if not paths:
            directory = str(candidate.get("target_dir") or context.get("active_dir") or "")
            paths = [f"{directory}/__candidate__" if directory else "__candidate__"]
        prediction = self.world_model.predict(context)
        probabilities = {path: round(1.0 / len(paths), 6) for path in paths}
        return {
            "paths": sorted(paths),
            "probabilities": probabilities,
            "model_id": prediction.get("model_id"),
            "approximate": prediction.get("model_id") is None,
        }

    def expected_uncertainty(
        self,
        *,
        candidate: dict[str, Any],
        context: dict[str, Any],
        pack: dict[str, Any] | None = None,
    ) -> float:
        predicted = self.predict_change_set(candidate=candidate, context=context)
        paths = predicted["paths"]
        pack_paths = _pack_paths(pack)
        coverage_gap = 0.0
        if paths:
            missing = [path for path in paths if path not in pack_paths]
            coverage_gap = len(missing) / len(paths)
        entropy = _entropy(list(predicted["probabilities"].values()))
        return round(min(1.0, (coverage_gap * 0.7) + (entropy * 0.3)), 6)

    def score(
        self,
        *,
        snapshot: Any,
        task: str,
        current_paths: list[str],
        candidates: list[dict[str, Any]] | None = None,
        pack: dict[str, Any] | None = None,
        top_k: int = 5,
        interoception: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        context = {
            "task_terms": _terms(task),
            "active_dir": _dirname(current_paths[0]) if current_paths else "",
        }
        candidate_items = (
            candidates
            or [{"kind": "path", "paths": [path], "label": path} for path in current_paths]
            or [{"kind": "task", "target_dir": "", "label": "current task"}]
        )
        candidate_predictions = [
            (candidate, self.predict_change_set(candidate=candidate, context=context))
            for candidate in candidate_items
        ]
        combined_paths = sorted(
            {path for _candidate, predicted in candidate_predictions for path in predicted["paths"]}
        )
        combined_report = self.impact_engine.report(
            snapshot=snapshot,
            paths=combined_paths,
            pack_id=pack.get("pack_id") if isinstance(pack, dict) else None,
        )
        combined_risk = min(
            1.0,
            float(combined_report.get("risk", {}).get("score", 0.0) or 0.0) / 10.0,
        )
        scored: list[ScoredCandidate] = []
        model_id = None
        for candidate, predicted in candidate_predictions:
            model_id = model_id or predicted.get("model_id")
            gut = float((interoception or {}).get("gut", 0.0) or 0.0)
            expected_risk = round(min(1.0, combined_risk * (1.0 + (0.3 * gut))), 6)
            expected_uncertainty = self.expected_uncertainty(
                candidate=candidate, context=context, pack=pack
            )
            efe = round(min(1.0, (0.6 * expected_risk) + (0.4 * expected_uncertainty)), 6)
            item: ScoredCandidate = {
                "candidate": candidate,
                "predicted_paths": predicted["paths"],
                "expected_risk": expected_risk,
                "expected_uncertainty": expected_uncertainty,
                "efe": efe,
                "recommended_action": _recommended_action(expected_risk, expected_uncertainty),
                "rationale": _rationale(expected_risk, expected_uncertainty),
                "approximate": bool(predicted.get("approximate")),
            }
            scored.append(item)
        scored = sorted(scored, key=lambda item: (item["efe"], str(item["candidate"])))[:top_k]
        prefetch = sorted(
            {
                path
                for item in scored
                if item["expected_uncertainty"] >= 0.5
                for path in item["predicted_paths"]
            }
        )
        return {
            "schema_version": "persistmind.anticipation.efe.v1",
            "task": task,
            "candidates": scored,
            "recommended": scored[0] if scored else None,
            "prefetch": prefetch,
            "model_id": model_id,
        }

    def rollout(
        self,
        *,
        snapshot: Any,
        task: str,
        current_paths: list[str],
        candidates: list[dict[str, Any]] | None = None,
        pack: dict[str, Any] | None = None,
        depth: int = 2,
        beam: int = 3,
        discount: float = 0.8,
        interoception: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        depth = max(1, min(5, int(depth)))
        beam = max(1, min(8, int(beam)))
        root = self.score(
            snapshot=snapshot,
            task=task,
            current_paths=current_paths,
            candidates=candidates,
            pack=pack,
            top_k=beam,
            interoception=interoception,
        )
        root_candidates = root["candidates"]
        frontier: list[RolloutNode] = [
            {
                "path": [item],
                "cumulative_efe": float(item["efe"]),
                "paths": list(item["predicted_paths"]),
                "confidence": 1.0,
            }
            for item in root_candidates
        ]
        pruned = 0
        for level in range(2, depth + 1):
            expanded: list[RolloutNode] = []
            for node in frontier:
                if not node["paths"]:
                    pruned += 1
                    continue
                step_task = f"{task} consequence step {level}"
                node_paths = [str(path) for path in node["paths"]]
                next_candidates = [
                    {
                        "label": f"follow {path}",
                        "paths": [_next_consequence_path(path, level)],
                    }
                    for path in node_paths[:beam]
                ]
                scored = self.score(
                    snapshot=snapshot,
                    task=step_task,
                    current_paths=node_paths,
                    candidates=next_candidates,
                    pack=pack,
                    top_k=beam,
                    interoception=interoception,
                )
                for item in scored["candidates"]:
                    confidence = round(float(node["confidence"]) * discount, 6)
                    cumulative = round(
                        float(node["cumulative_efe"])
                        + (discount ** (level - 1)) * float(item["efe"]),
                        6,
                    )
                    expanded.append(
                        {
                            "path": [*node["path"], item],
                            "cumulative_efe": cumulative,
                            "paths": list(item["predicted_paths"]),
                            "confidence": confidence,
                        }
                    )
            if not expanded:
                break
            expanded = sorted(
                expanded,
                key=lambda item: (
                    item["cumulative_efe"],
                    _chain_label(item["path"]),
                ),
            )
            pruned += max(0, len(expanded) - beam)
            frontier = expanded[:beam]
        recommended = min(frontier, key=lambda item: item["cumulative_efe"]) if frontier else None
        riskiest = max(frontier, key=lambda item: item["cumulative_efe"]) if frontier else None
        chain: list[dict[str, Any]] = list(recommended["path"]) if recommended else []
        riskiest_chain: list[dict[str, Any]] = list(riskiest["path"]) if riskiest else []
        model_id = root.get("model_id")
        rollout_hash = self.store.record_anticipation_prediction(
            repo_id=self.world_model.repo_id,
            workspace_id=None,
            session_id=None,
            task_session_id=None,
            model_id=model_id or "rollout",
            context={"kind": "rollout", "task": task, "depth": depth, "beam": beam},
            observation={"current_paths": current_paths},
            surprise_raw=float(recommended["cumulative_efe"] if recommended else 0.0),
            surprise=float(recommended["cumulative_efe"] if recommended else 0.0),
            components={
                "depth_reached": len(chain),
                "pruned": pruned,
                "recommended_path": [_node_summary(item) for item in chain],
                "riskiest_path": [_node_summary(item) for item in riskiest_chain],
            },
        )
        return {
            "schema_version": "persistmind.anticipation.rollout.v1",
            "task": task,
            "recommended_path": [_node_summary(item) for item in chain],
            "riskiest_path": [_node_summary(item) for item in riskiest_chain],
            "chain_rationale": _chain_rationale(chain),
            "cumulative_efe": round(
                float(recommended["cumulative_efe"] if recommended else 0.0), 6
            ),
            "depth_reached": len(chain),
            "pruned": pruned,
            "approximate": depth > 1,
            "prediction_id": rollout_hash,
            "model_id": model_id,
            "depth_1": root,
        }


def _recommended_action(risk: float, uncertainty: float) -> str:
    if uncertainty >= 0.55 and uncertainty >= risk:
        return "fetch_context"
    if risk >= 0.75:
        return "replan"
    if risk >= 0.45:
        return "warn"
    return "proceed"


def _rationale(risk: float, uncertainty: float) -> str:
    if uncertainty >= 0.55 and uncertainty >= risk:
        return "uncertainty dominates; fetch context before editing"
    if risk >= 0.45:
        return "expected risk is elevated"
    return "expected risk and uncertainty are low"


def _entropy(probabilities: list[float]) -> float:
    if len(probabilities) <= 1:
        return 0.0
    entropy = -sum(p * math.log(max(p, 1e-9), 2) for p in probabilities)
    return min(1.0, entropy / math.log(len(probabilities), 2))


def _pack_paths(pack: dict[str, Any] | None) -> set[str]:
    if not isinstance(pack, dict):
        return set()
    paths = {
        _normalize_path(item["path"])
        for item in pack.get("items", [])
        if isinstance(item, dict) and item.get("path")
    }
    manifest = pack.get("manifest")
    if isinstance(manifest, dict):
        paths.update(
            _normalize_path(item["path"])
            for item in manifest.get("items", [])
            if isinstance(item, dict) and item.get("path")
        )
    return paths


def _terms(task: str) -> list[str]:
    return sorted({part.strip(".,:;()[]{}").lower() for part in task.split() if len(part) >= 4})


def _dirname(path: str) -> str:
    parent = str(Path(_normalize_path(path)).parent).replace("\\", "/")
    return "" if parent == "." else parent


def _normalize_path(path: str) -> str:
    return str(path).replace("\\", "/").removeprefix("./")


def _next_consequence_path(path: str, level: int) -> str:
    normalized = _normalize_path(path)
    parent = _dirname(normalized)
    stem = Path(normalized).stem or "__candidate__"
    suffix = Path(normalized).suffix or ".py"
    return (
        f"{parent}/{stem}.consequence{level}{suffix}"
        if parent
        else f"{stem}.consequence{level}{suffix}"
    )


def _node_summary(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "candidate": item.get("candidate", {}).get("label")
        or item.get("candidate", {}).get("kind")
        or "candidate",
        "predicted_paths": item.get("predicted_paths", []),
        "efe": item.get("efe", 0.0),
        "expected_risk": item.get("expected_risk", 0.0),
        "expected_uncertainty": item.get("expected_uncertainty", 0.0),
        "recommended_action": item.get("recommended_action", "proceed"),
        "rationale": item.get("rationale", ""),
    }


def _chain_label(path: list[dict[str, Any]]) -> str:
    return " -> ".join(str(_node_summary(item)["candidate"]) for item in path)


def _chain_rationale(path: list[dict[str, Any]]) -> str:
    if not path:
        return "no consequence chain predicted"
    pieces = []
    for item in path:
        summary = _node_summary(item)
        target = ", ".join(summary["predicted_paths"]) or str(summary["candidate"])
        pieces.append(f"{target} ({summary['recommended_action']})")
    return " -> ".join(pieces)
