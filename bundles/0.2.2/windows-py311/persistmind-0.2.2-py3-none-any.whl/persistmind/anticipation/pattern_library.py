from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from persistmind.branding import canonical_user_home
from persistmind.utils import canonical_json, stable_id, utc_now

ALLOWED_ROLE_TAGS = {
    "auth",
    "billing",
    "payments",
    "migration",
    "test",
    "config",
    "generated",
    "general",
}


class PatternLibrary:
    """Local privacy-safe store for cross-repo anticipation signatures."""

    def __init__(
        self,
        *,
        library: str = "user",
        max_transfer_weight: float = 0.4,
        embedder_signature: dict[str, Any] | None = None,
    ):
        self.path = _library_path(library)
        self.max_transfer_weight = max(0.0, min(1.0, float(max_transfer_weight)))
        self.embedder_signature = (
            _redacted_embedder(embedder_signature) if embedder_signature else {}
        )

    def export(self, model: Any) -> list[dict[str, Any]]:
        latest = model.latest() if hasattr(model, "latest") else None
        if not latest:
            return []
        params = latest.get("params", {})
        embedder = params.get("embedder", {})
        ece = latest.get("ece")
        patterns = []
        for item in params.get("failure_prototypes", []):
            signature = self.redact(
                {
                    "embedder": embedder,
                    "vector": item.get("vector", []),
                    "count": int(item.get("count", 1) or 1),
                    "role_tags": item.get("role_tags", ["general"]),
                    "failure_prior": float(item.get("failure_prior", 0.0) or 0.0),
                    "ece": float(ece or 0.0),
                }
            )
            patterns.append(signature)
        return patterns

    def write(self, patterns: list[dict[str, Any]]) -> dict[str, Any]:
        payload = self._read()
        existing = {
            str(item.get("signature_id")): item
            for item in payload.get("patterns", [])
            if isinstance(item, dict) and item.get("signature_id")
        }
        for pattern in patterns:
            current = existing.get(pattern["signature_id"])
            if current:
                current["repo_count"] = int(current.get("repo_count", 1) or 1) + 1
                current["confirmations"] = int(current.get("confirmations", 0) or 0) + int(
                    pattern.get("confirmations", 0) or 0
                )
                current["failure_prior"] = max(
                    float(current.get("failure_prior", 0.0) or 0.0),
                    float(pattern.get("failure_prior", 0.0) or 0.0),
                )
                current["updated_at"] = utc_now()
            else:
                existing[pattern["signature_id"]] = {
                    **pattern,
                    "repo_count": 1,
                    "created_at": utc_now(),
                    "updated_at": utc_now(),
                }
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            canonical_json(
                {"patterns": sorted(existing.values(), key=lambda x: x["signature_id"])}
            ),
            encoding="utf-8",
        )
        return {"ok": True, "path": str(self.path), "exported": len(patterns)}

    def import_for(self, repo_id: str) -> list[dict[str, Any]]:
        del repo_id
        payload = self._read()
        imported = []
        for item in payload.get("patterns", []):
            if not isinstance(item, dict):
                continue
            if self.embedder_signature and item.get("embedder") != self.embedder_signature:
                continue
            repo_count = int(item.get("repo_count", 1) or 1)
            confirmations = int(item.get("confirmations", 0) or 0)
            confidence = min(1.0, (repo_count / 3.0) + (confirmations / 10.0))
            imported.append(
                {
                    "vector": item.get("vector", []),
                    "role_tags": item.get("role_tags", ["general"]),
                    "failure_prior": float(item.get("failure_prior", 0.0) or 0.0),
                    "count": int(item.get("confirmations", 1) or 1),
                    "transfer_weight": round(self.max_transfer_weight * confidence, 6),
                    "signature_id": item.get("signature_id"),
                }
            )
        return imported

    def redact(self, signature: dict[str, Any]) -> dict[str, Any]:
        vector = [round(float(value), 6) for value in signature.get("vector", [])]
        role_tags = sorted(
            {
                str(tag)
                for tag in signature.get("role_tags", ["general"])
                if str(tag) in ALLOWED_ROLE_TAGS
            }
            or {"general"}
        )
        payload = {
            "embedder": _redacted_embedder(signature.get("embedder"), dim=len(vector)),
            "vector": vector,
            "role_tags": role_tags,
            "failure_prior": round(float(signature.get("failure_prior", 0.0) or 0.0), 6),
            "ece": round(float(signature.get("ece", 0.0) or 0.0), 6),
            "confirmations": int(signature.get("count", 1) or 1),
        }
        _assert_no_artifacts(
            {
                "vector": payload["vector"],
                "role_tags": payload["role_tags"],
                "failure_prior": payload["failure_prior"],
                "ece": payload["ece"],
                "confirmations": payload["confirmations"],
            }
        )
        return {
            "signature_id": stable_id("pattern", canonical_json(payload)),
            **payload,
        }

    def _read(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"patterns": []}
        try:
            parsed = json.loads(self.path.read_text(encoding="utf-8") or "{}")
        except json.JSONDecodeError:
            return {"patterns": []}
        return parsed if isinstance(parsed, dict) else {"patterns": []}


def _library_path(library: str) -> Path:
    override = os.environ.get("PERSISTMIND_PATTERN_LIBRARY")
    if override:
        return Path(override)
    if library in {"", "user"}:
        return canonical_user_home() / "pattern-library.json"
    if library == "off":
        return Path(os.devnull)
    return Path(library)


def _redacted_embedder(
    embedder: dict[str, Any] | None, *, dim: int | None = None
) -> dict[str, Any]:
    embedder = embedder or {}
    name = str(embedder.get("name") or "")
    resolved_dim = int(embedder.get("dim") or dim or 0)
    return {
        "name_hash": stable_id("embedder", name),
        "dim": resolved_dim,
        "backend": str(embedder.get("backend") or "unknown"),
    }


def _assert_no_artifacts(payload: dict[str, Any]) -> None:
    blob = canonical_json(payload).lower()
    forbidden = ("/", "\\", ".py", ".ts", ".js", "src", "app/")
    if any(token in blob for token in forbidden):
        raise ValueError("pattern signature contains repository artifacts")
