from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from typing import Any


def changed_paths(repo_root: Path, *, staged: bool) -> list[str]:
    command = ["git", "diff", "--name-only"]
    if staged:
        command.append("--cached")
    completed = subprocess.run(
        command,
        cwd=repo_root,
        capture_output=True,
        text=True,
        check=False,
    )
    if completed.returncode:
        raise RuntimeError(completed.stderr.strip() or "cannot inspect changed paths")
    return [
        line.strip().replace("\\", "/") for line in completed.stdout.splitlines() if line.strip()
    ]


def agent_gate_thresholds(args: Any) -> dict[str, float | int]:
    return {
        "min_cases": args.min_cases,
        "min_success_rate_delta": args.min_success_rate_delta,
        "min_tests_pass_rate_delta": args.min_tests_pass_rate_delta,
        "min_wrong_files_touched_reduction": args.min_wrong_files_reduction,
        "min_missing_files_reduction": args.min_missing_files_reduction,
        "min_persistmind_success_rate": args.min_persistmind_success_rate,
    }


def csv_or_space(value: str) -> list[str]:
    return [item for chunk in value.split(",") for item in chunk.split() if item]


def normalize_global_args(argv: list[str]) -> list[str]:
    if "--repo" not in argv:
        return argv
    if len(argv) >= 3 and argv[0] == "eval" and argv[1] == "harvest":
        return argv
    if len(argv) >= 2 and argv[0] == "workspace" and argv[1] == "impact":
        return argv
    idx = argv.index("--repo")
    if idx == 0 or idx + 1 >= len(argv):
        return argv
    repo_pair = argv[idx : idx + 2]
    rest = argv[:idx] + argv[idx + 2 :]
    return [*repo_pair, *rest]


def npx_doctor(package_root: Path) -> dict[str, Any]:
    return {
        "ok": True,
        "python_cli": True,
        "package_root": str(package_root),
        "npm_update_command": 'persistmind npx update --source "<path-to-persistmind-repo>"',
    }


def npx_update(package_root: Path, source: str | None, project: bool) -> dict[str, Any]:
    source_path = source or str(package_root)
    npm = "npm.cmd" if sys.platform == "win32" else "npm"
    args = [npm, "install", "--save-dev" if project else "-g", source_path]
    result = subprocess.run(args, text=True)
    return {
        "ok": result.returncode == 0,
        "command": args,
        "source": source_path,
        "mode": "project" if project else "global",
        "returncode": result.returncode,
    }
