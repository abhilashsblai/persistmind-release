from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable
from typing import Any


GRAPH_RECALL_KINDS = (
    "supersedes",
    "contradicts",
    "derived_from",
    "causes",
    "co_occurs_with",
    "relates_to",
)


def write_memory_edge(
    store: Any,
    *,
    workspace_id: str,
    repo_id: str | None,
    src_record_id: str,
    dst_record_id: str,
    kind: str,
    confidence: float = 1.0,
    evidence: dict[str, Any] | None = None,
    created_by: str = "deterministic",
) -> str | None:
    if not src_record_id or not dst_record_id or src_record_id == dst_record_id:
        return None
    return store.memory_edge_create(
        workspace_id=workspace_id,
        repo_id=repo_id,
        src_record_id=src_record_id,
        dst_record_id=dst_record_id,
        kind=kind,
        confidence=confidence,
        evidence=evidence or {},
        created_by=created_by,
    )


def memory_graph_signal(
    store: Any,
    *,
    workspace_id: str,
    repo_id: str | None,
    record_id: str,
    seed_record_ids: set[str],
    max_hops: int = 2,
) -> dict[str, Any] | None:
    return memory_graph_signals(
        store,
        workspace_id=workspace_id,
        repo_id=repo_id,
        record_ids=[record_id],
        seed_record_ids=seed_record_ids,
        max_hops=max_hops,
    ).get(record_id)


def memory_graph_signals(
    store: Any,
    *,
    workspace_id: str,
    repo_id: str | None,
    record_ids: Iterable[str],
    seed_record_ids: set[str],
    max_hops: int = 2,
) -> dict[str, dict[str, Any]]:
    targets = {
        str(record_id) for record_id in record_ids if record_id and record_id not in seed_record_ids
    }
    if not targets or not seed_record_ids:
        return {}
    walk = store.memory_graph_walk(
        workspace_id=workspace_id,
        repo_id=repo_id,
        start_record_ids=seed_record_ids,
        kinds=GRAPH_RECALL_KINDS,
        max_hops=max_hops,
        limit=200,
    )
    matches_by_record: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for item in walk:
        record_id = str(item.get("record_id") or "")
        if record_id in targets:
            matches_by_record[record_id].append(item)
    signals: dict[str, dict[str, Any]] = {}
    for record_id, matches in matches_by_record.items():
        best = max(matches, key=lambda item: float(item.get("confidence", 0.0) or 0.0))
        signals[record_id] = {
            "kind": "memory_graph",
            "score": round(min(0.8, float(best.get("confidence", 0.0) or 0.0)), 4),
            "reason": "Memory is linked to a query/path-matched memory record.",
            "matches": matches[:5],
        }
    return signals
