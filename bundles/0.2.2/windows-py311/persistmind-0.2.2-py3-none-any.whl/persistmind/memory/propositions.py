from __future__ import annotations

import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation


_STOP = {
    "a",
    "an",
    "and",
    "at",
    "be",
    "for",
    "in",
    "is",
    "of",
    "on",
    "or",
    "the",
    "to",
    "use",
    "uses",
    "must",
    "not",
    "never",
    "shall",
    "should",
    "required",
    "minimum",
    "maximum",
    "least",
    "most",
    "exactly",
}


@dataclass(frozen=True)
class Proposition:
    subject: tuple[str, ...]
    polarity: str
    comparator: str | None
    threshold: Decimal | None
    unit: str | None
    scope: tuple[str, ...]


def normalize_proposition(assertion: str) -> Proposition:
    text = assertion.casefold()
    polarity = (
        "prohibited"
        if re.search(r"\b(?:must\s+not|shall\s+not|do\s+not|never)\b", text)
        else "required"
        if re.search(r"\b(?:must|shall|required)\b", text)
        else "asserted"
    )
    comparator, threshold, unit = _constraint(text)
    words = re.findall(r"[a-z][a-z0-9_-]*", text)
    subject = tuple(
        sorted(
            {
                word
                for word in words
                if word not in _STOP
                and not word.isdigit()
                and _normalize_unit(word) is None
                and len(word) > 2
            }
        )
    )
    scope_match = re.search(r"\b(?:for|in|on)\s+([a-z][a-z0-9_-]*)", text)
    scope = (scope_match.group(1),) if scope_match else ()
    return Proposition(subject, polarity, comparator, threshold, unit, scope)


def conflict_summary(left: str, right: str) -> str | None:
    first = normalize_proposition(left)
    second = normalize_proposition(right)
    if not _same_proposition(first, second):
        return None
    if {first.polarity, second.polarity} == {"required", "prohibited"}:
        return "Conflicting obligation: the same proposition is both required and prohibited."
    if first.polarity == second.polarity == "prohibited":
        return None
    if _constraints_conflict(first, second):
        return (
            "The same proposition has incompatible constraints: "
            f"{first.comparator} {first.threshold} {first.unit or ''} vs "
            f"{second.comparator} {second.threshold} {second.unit or ''}."
        ).strip()
    return None


def _constraint(text: str) -> tuple[str | None, Decimal | None, str | None]:
    match = re.search(
        r"(?P<operator>at\s+least|minimum|no\s+less\s+than|>=|at\s+most|maximum|"
        r"no\s+more\s+than|<=|exactly|==|=|>|<)?\s*"
        r"(?P<number>\d+(?:\.\d+)?)\s*(?P<unit>%|percent|ms|milliseconds?|seconds?|"
        r"minutes?|hours?|kb|mb|gb|requests?|items?)?",
        text,
    )
    if not match:
        return None, None, None
    operator = (match.group("operator") or "=").replace("  ", " ")
    comparator = {
        "at least": "gte",
        "minimum": "gte",
        "no less than": "gte",
        ">=": "gte",
        ">": "gt",
        "at most": "lte",
        "maximum": "lte",
        "no more than": "lte",
        "<=": "lte",
        "<": "lt",
        "exactly": "eq",
        "==": "eq",
        "=": "eq",
    }[operator]
    try:
        threshold = Decimal(match.group("number"))
    except InvalidOperation:
        return None, None, None
    return comparator, threshold, _normalize_unit(match.group("unit") or "")


def _normalize_unit(value: str) -> str | None:
    unit = value.casefold()
    if unit in {"%", "percent"}:
        return "percent"
    if unit in {"ms", "millisecond", "milliseconds"}:
        return "milliseconds"
    if unit in {"second", "seconds"}:
        return "seconds"
    if unit in {"minute", "minutes"}:
        return "minutes"
    if unit in {"hour", "hours"}:
        return "hours"
    if unit in {"kb", "mb", "gb"}:
        return unit
    if unit in {"request", "requests"}:
        return "requests"
    if unit in {"item", "items"}:
        return "items"
    return None


def _same_proposition(left: Proposition, right: Proposition) -> bool:
    left_terms = set(left.subject)
    right_terms = set(right.subject)
    overlap = left_terms & right_terms
    return (
        bool(overlap)
        and len(overlap) >= max(1, min(len(left_terms), len(right_terms)) - 1)
        and (not left.scope or not right.scope or left.scope == right.scope)
        and (not left.unit or not right.unit or left.unit == right.unit)
    )


def _constraints_conflict(left: Proposition, right: Proposition) -> bool:
    if left.threshold is None or right.threshold is None:
        return False
    if left.unit != right.unit:
        return False
    a: Decimal = left.threshold
    b: Decimal = right.threshold
    if left.comparator == right.comparator == "eq":
        return a != b
    lower = next((item for item in (left, right) if item.comparator in {"gte", "gt"}), None)
    upper = next((item for item in (left, right) if item.comparator in {"lte", "lt"}), None)
    if lower and upper:
        if lower.threshold is None or upper.threshold is None:
            return False
        lower_value: Decimal = lower.threshold
        upper_value: Decimal = upper.threshold
        return bool(
            lower_value > upper_value
            or (
                lower_value == upper_value
                and (lower.comparator == "gt" or upper.comparator == "lt")
            )
        )
    exact = next((item for item in (left, right) if item.comparator == "eq"), None)
    bound = right if exact is left else left if exact is right else None
    if exact and bound:
        if exact.threshold is None or bound.threshold is None:
            return False
        exact_value: Decimal = exact.threshold
        bound_value: Decimal = bound.threshold
        if bound.comparator == "gte":
            return exact_value < bound_value
        if bound.comparator == "gt":
            return exact_value <= bound_value
        if bound.comparator == "lte":
            return exact_value > bound_value
        if bound.comparator == "lt":
            return exact_value >= bound_value
    return False
