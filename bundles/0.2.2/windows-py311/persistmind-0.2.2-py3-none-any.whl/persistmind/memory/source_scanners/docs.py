from __future__ import annotations

from pathlib import Path

from persistmind.memory.evidence import RuleCandidate
from persistmind.memory.source_scanners.common import scan_rule_text


def scan(root: Path) -> list[RuleCandidate]:
    candidates: list[RuleCandidate] = []
    for path in [*root.rglob("*.md"), *root.rglob("*.txt")]:
        if ".persistmind" in path.parts or ".git" in path.parts:
            continue
        candidates.extend(scan_rule_text(path, root, "docs", 0.6))
    return candidates
