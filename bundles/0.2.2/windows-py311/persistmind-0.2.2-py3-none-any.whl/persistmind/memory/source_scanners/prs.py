from __future__ import annotations

from pathlib import Path

from persistmind.memory.evidence import RuleCandidate
from persistmind.memory.source_scanners.common import scan_rule_text


def scan(root: Path) -> list[RuleCandidate]:
    candidates: list[RuleCandidate] = []
    for folder in [
        root / "prs",
        root / ".persistmind" / "prs",
        root / ".persistmind" / "prs",
    ]:
        if not folder.exists():
            continue
        for path in folder.rglob("*.md"):
            candidates.extend(scan_rule_text(path, root, "pr", 0.58))
    return candidates
