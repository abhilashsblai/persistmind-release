from __future__ import annotations

import ast
import re
import subprocess
from pathlib import Path


def git_changed_paths(repo_root: Path, *, staged: bool = False) -> list[str]:
    args = (
        [
            "git",
            "diff",
            "--cached" if staged else "--name-only",
            "--name-only" if staged else "HEAD",
            "HEAD",
        ]
        if staged
        else ["git", "diff", "--name-only", "HEAD"]
    )
    try:
        result = subprocess.run(
            args,
            cwd=repo_root,
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=10,
        )
    except (subprocess.SubprocessError, FileNotFoundError):
        return []
    return [line.strip().replace("\\", "/") for line in result.stdout.splitlines() if line.strip()]


def paths_from_diff(diff: str | None) -> list[str]:
    if not diff:
        return []
    paths: set[str] = set()
    for line in diff.splitlines():
        if line.startswith("diff --git "):
            payload = line[len("diff --git ") :]
            if payload.startswith('"'):
                match = re.fullmatch(r'("(?:\\.|[^"\\])*")\s+("(?:\\.|[^"\\])*")', payload)
                parts = match.groups() if match else ()
            else:
                boundary = payload.rfind(" b/")
                parts = (payload[:boundary], payload[boundary + 1 :]) if boundary > 0 else ()
            for part in parts:
                if path := _decode_git_diff_path(part):
                    paths.add(path)
        elif line.startswith(("+++ ", "--- ")):
            if path := _decode_git_diff_path(line[4:]):
                paths.add(path)
        elif line.startswith(("rename from ", "rename to ")):
            if path := _decode_git_diff_path(line.split(" ", 2)[2]):
                paths.add(path)
    return sorted(path for path in paths if path != "/dev/null")


def _decode_git_diff_path(value: str) -> str | None:
    raw = value.strip()
    if not raw or raw == "/dev/null":
        return None
    if raw.startswith('"') and raw.endswith('"'):
        try:
            decoded = ast.literal_eval(raw)
        except (SyntaxError, ValueError):
            return None
        if not isinstance(decoded, str):
            return None
        raw = decoded
        try:
            raw = raw.encode("latin-1").decode("utf-8")
        except (UnicodeEncodeError, UnicodeDecodeError):
            pass
    raw = raw.replace("\\", "/")
    if raw.startswith(("a/", "b/")):
        raw = raw[2:]
    return raw or None
