from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any

from persistmind.security.context import require_current_principal
from persistmind.utils import canonical_json, stable_id, utc_now


class TeacherBenchmarkHarness:
    def __init__(self, conn: Any, repo_id: str) -> None:
        self.conn = conn
        self.repo_id = repo_id

    def suite_create(
        self,
        name: str,
        version: str,
        purpose: str,
        tasks: list[dict[str, Any]],
        *,
        config: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        manifest = canonical_json(tasks)
        suite_id = stable_id("teacher-benchmark-suite", self.repo_id, name, version)
        with self.conn:
            self.conn.execute(
                "INSERT INTO teacher_benchmark_suites(suite_id, repo_id, name, version, purpose, task_manifest_digest, config_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(repo_id, name, version) DO UPDATE SET purpose=excluded.purpose, task_manifest_digest=excluded.task_manifest_digest, config_json=excluded.config_json",
                (
                    suite_id,
                    self.repo_id,
                    name,
                    version,
                    purpose,
                    stable_id(manifest),
                    canonical_json(config or {}),
                    utc_now(),
                ),
            )
            for index, task in enumerate(tasks):
                task_id = stable_id("teacher-benchmark-task", suite_id, task.get("name"), index)
                self.conn.execute(
                    "INSERT OR REPLACE INTO teacher_benchmark_tasks(benchmark_task_id, suite_id, name, fixture_ref, snapshot_ref, expected_contracts_json, timeout_seconds, privacy_class) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        task_id,
                        suite_id,
                        str(task.get("name") or f"task-{index + 1}"),
                        str(task.get("fixture_ref") or ""),
                        str(task.get("snapshot_ref") or ""),
                        canonical_json(task.get("expected_contracts") or []),
                        int(task.get("timeout_seconds") or 300),
                        str(task.get("privacy_class") or "summary_only"),
                    ),
                )
        return self.suite_show(suite_id)

    def suite_show(self, suite_id: str) -> dict[str, Any]:
        row = self.conn.execute(
            "SELECT * FROM teacher_benchmark_suites WHERE suite_id=?", (suite_id,)
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown teacher benchmark suite: {suite_id}")
        suite = dict(row)
        suite["config"] = json.loads(suite.pop("config_json") or "{}")
        tasks = []
        for task_row in self.conn.execute(
            "SELECT * FROM teacher_benchmark_tasks WHERE suite_id=? ORDER BY benchmark_task_id",
            (suite_id,),
        ).fetchall():
            task = dict(task_row)
            task["expected_contracts"] = json.loads(task.pop("expected_contracts_json") or "[]")
            tasks.append(task)
        return {
            "schema_version": "persistmind.teacher_benchmark_suite.v1",
            "suite": suite,
            "tasks": tasks,
        }

    def run_start(
        self,
        suite_id: str,
        *,
        baseline_run_id: str | None = None,
        code_commit: str | None = None,
        graph_version_id: str | None = None,
        model_label: str = "",
        environment: dict[str, Any] | None = None,
        feature_flags: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        self.suite_show(suite_id)
        config = canonical_json(
            {
                "baseline": baseline_run_id,
                "commit": code_commit,
                "graph": graph_version_id,
                "model": model_label,
                "environment": environment or {},
                "flags": feature_flags or {},
            }
        )
        run_id = stable_id("teacher-benchmark-run", suite_id, config)
        with self.conn:
            self.conn.execute(
                "INSERT OR IGNORE INTO teacher_benchmark_runs(benchmark_run_id, suite_id, baseline_run_id, code_commit, graph_version_id, model_label, environment_json, feature_flags_json, started_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    run_id,
                    suite_id,
                    baseline_run_id,
                    code_commit,
                    graph_version_id,
                    model_label,
                    canonical_json(environment or {}),
                    canonical_json(feature_flags or {}),
                    utc_now(),
                ),
            )
        return self.run_show(run_id)

    def metric(
        self,
        benchmark_run_id: str,
        name: str,
        value: float,
        unit: str,
        *,
        benchmark_task_id: str | None = None,
        provenance: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        metric_id = stable_id("teacher-benchmark-metric", benchmark_run_id, benchmark_task_id, name)
        with self.conn:
            self.conn.execute(
                "INSERT OR REPLACE INTO teacher_benchmark_metrics(metric_id, benchmark_run_id, benchmark_task_id, metric_name, metric_value, unit, provenance_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    metric_id,
                    benchmark_run_id,
                    benchmark_task_id,
                    name,
                    float(value),
                    unit,
                    canonical_json(provenance or {}),
                    utc_now(),
                ),
            )
        return {
            "schema_version": "persistmind.teacher_benchmark_metric.v1",
            "metric_id": metric_id,
            "benchmark_run_id": benchmark_run_id,
            "metric_name": name,
            "metric_value": float(value),
            "unit": unit,
            "provenance": provenance or {},
        }

    def run_finish(
        self,
        benchmark_run_id: str,
        *,
        status: str = "complete",
        invalidation_reason: str | None = None,
    ) -> dict[str, Any]:
        if status not in {"complete", "failed", "invalid", "interrupted"}:
            raise ValueError(f"unsupported benchmark status: {status}")
        with self.conn:
            self.conn.execute(
                "UPDATE teacher_benchmark_runs SET status=?, invalidation_reason=?, completed_at=? WHERE benchmark_run_id=?",
                (status, invalidation_reason, utc_now(), benchmark_run_id),
            )
        return self.run_show(benchmark_run_id)

    def run_resume(self, benchmark_run_id: str) -> dict[str, Any]:
        run = self.run_show(benchmark_run_id)
        if run["run"]["status"] not in {"interrupted", "failed"}:
            raise ValueError("only interrupted or failed benchmark runs can resume")
        with self.conn:
            self.conn.execute(
                """
                UPDATE teacher_benchmark_runs SET status='running',
                  invalidation_reason=NULL, completed_at=NULL
                WHERE benchmark_run_id=?
                """,
                (benchmark_run_id,),
            )
        return self.run_show(benchmark_run_id)

    def run_show(self, benchmark_run_id: str) -> dict[str, Any]:
        row = self.conn.execute(
            "SELECT * FROM teacher_benchmark_runs WHERE benchmark_run_id=?", (benchmark_run_id,)
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown teacher benchmark run: {benchmark_run_id}")
        run = dict(row)
        run["environment"] = json.loads(run.pop("environment_json") or "{}")
        run["feature_flags"] = json.loads(run.pop("feature_flags_json") or "{}")
        metrics = []
        for metric_row in self.conn.execute(
            "SELECT * FROM teacher_benchmark_metrics WHERE benchmark_run_id=? ORDER BY metric_name, benchmark_task_id",
            (benchmark_run_id,),
        ).fetchall():
            metric = dict(metric_row)
            metric["provenance"] = json.loads(metric.pop("provenance_json") or "{}")
            metrics.append(metric)
        return {
            "schema_version": "persistmind.teacher_benchmark_run.v1",
            "run": run,
            "metrics": metrics,
        }

    def compare(
        self, baseline_run_id: str, candidate_run_id: str, thresholds: dict[str, float]
    ) -> dict[str, Any]:
        baseline_run = self.run_show(baseline_run_id)["run"]
        candidate_run = self.run_show(candidate_run_id)["run"]
        if baseline_run["suite_id"] != candidate_run["suite_id"]:
            raise ValueError("benchmark comparison requires runs from the same suite")
        if baseline_run["status"] != "complete" or candidate_run["status"] != "complete":
            raise ValueError("benchmark comparison requires complete runs")
        baseline = self._metric_map(baseline_run_id)
        candidate = self._metric_map(candidate_run_id)
        regressions = []
        now = utc_now()
        with self.conn:
            for name in sorted(set(baseline) & set(candidate)):
                delta = candidate[name] - baseline[name]
                threshold = float(thresholds.get(name, 0.0))
                if delta <= threshold:
                    continue
                regression_id = stable_id(
                    "teacher-benchmark-regression", baseline_run_id, candidate_run_id, name
                )
                self.conn.execute(
                    "INSERT OR REPLACE INTO teacher_benchmark_regressions(regression_id, baseline_run_id, candidate_run_id, metric_name, threshold, observed_delta, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (regression_id, baseline_run_id, candidate_run_id, name, threshold, delta, now),
                )
                regressions.append(
                    {
                        "regression_id": regression_id,
                        "metric_name": name,
                        "threshold": threshold,
                        "observed_delta": delta,
                        "status": "open",
                    }
                )
        return {
            "schema_version": "persistmind.teacher_benchmark_comparison.v1",
            "baseline_run_id": baseline_run_id,
            "candidate_run_id": candidate_run_id,
            "comparable_metrics": sorted(set(baseline) & set(candidate)),
            "regressions": regressions,
            "ok": not regressions,
        }

    def claim_evaluate(
        self,
        claim: str,
        candidate_run_id: str,
        *,
        baseline_run_id: str | None = None,
        minimum_samples: int = 1,
    ) -> dict[str, Any]:
        candidate = self.run_show(candidate_run_id)
        metric_count = len(candidate["metrics"])
        regressions = self.conn.execute(
            "SELECT COUNT(*) FROM teacher_benchmark_regressions WHERE candidate_run_id=? AND status='open' AND severity='blocking'",
            (candidate_run_id,),
        ).fetchone()[0]
        reasons = []
        if candidate["run"]["status"] != "complete":
            reasons.append("candidate run is not complete")
        if metric_count < minimum_samples:
            reasons.append("insufficient metric evidence")
        if not baseline_run_id:
            reasons.append("comparable baseline is required")
        else:
            baseline = self.run_show(baseline_run_id)
            if baseline["run"]["suite_id"] != candidate["run"]["suite_id"]:
                reasons.append("baseline and candidate suites do not match")
            if baseline["run"]["status"] != "complete":
                reasons.append("baseline run is not complete")
        if regressions:
            reasons.append("blocking regressions remain open")
        metric_names = {str(item["metric_name"]) for item in candidate["metrics"]}
        claim_lower = claim.casefold()
        required_metrics: set[str] = set()
        for term, metrics in {
            "speed": {"elapsed_ms"},
            "faster": {"elapsed_ms"},
            "token": {"token_estimate"},
            "autonomy": {"autonomy_violations", "rollback_success"},
            "enforcement": {"obligation_violations"},
            "branch": {"branch_contamination"},
        }.items():
            if term in claim_lower:
                required_metrics.update(metrics)
        missing_metrics = sorted(required_metrics - metric_names)
        if missing_metrics:
            reasons.append(f"claim lacks required metrics: {', '.join(missing_metrics)}")
        claim_id = stable_id("teacher-claim", claim, candidate_run_id, baseline_run_id)
        status = "supported" if not reasons else "rejected"
        with self.conn:
            self.conn.execute(
                "INSERT OR REPLACE INTO teacher_claim_evidence(claim_id, repo_id, claim_text, baseline_run_id, candidate_run_id, status, reasons_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    claim_id,
                    self.repo_id,
                    claim,
                    baseline_run_id,
                    candidate_run_id,
                    status,
                    canonical_json(reasons),
                    utc_now(),
                ),
            )
        return {
            "schema_version": "persistmind.teacher_claim.v1",
            "claim_id": claim_id,
            "claim": claim,
            "status": status,
            "reasons": reasons,
            "baseline_run_id": baseline_run_id,
            "candidate_run_id": candidate_run_id,
        }

    def regression_waive(
        self,
        regression_id: str,
        *,
        actor: str,
        reason: str,
        expires_at: str,
    ) -> dict[str, Any]:
        require_current_principal(roles=frozenset({"admin"}), action="teacher.waive")
        expiry = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
        if expiry <= datetime.now(UTC):
            raise ValueError("benchmark waiver expiry must be in the future")
        with self.conn:
            self.conn.execute(
                """
                UPDATE teacher_benchmark_regressions SET status='waived',
                  waiver_actor=?, waiver_reason=?, waiver_expires_at=?
                WHERE regression_id=?
                """,
                (actor, reason, expiry.isoformat(), regression_id),
            )
        row = self.conn.execute(
            "SELECT * FROM teacher_benchmark_regressions WHERE regression_id=?",
            (regression_id,),
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown benchmark regression: {regression_id}")
        return {"schema_version": "persistmind.teacher_benchmark_waiver.v1", **dict(row)}

    def release_gate(self, suite_id: str) -> dict[str, Any]:
        runs = self.conn.execute(
            "SELECT * FROM teacher_benchmark_runs WHERE suite_id=? ORDER BY started_at DESC",
            (suite_id,),
        ).fetchall()
        complete = [row for row in runs if row["status"] == "complete"]
        open_regressions = self.conn.execute(
            """
            SELECT COUNT(*) FROM teacher_benchmark_regressions r
            JOIN teacher_benchmark_runs c ON c.benchmark_run_id=r.candidate_run_id
            WHERE c.suite_id=? AND r.status='open' AND r.severity='blocking'
            """,
            (suite_id,),
        ).fetchone()[0]
        rejected_claims = self.conn.execute(
            """
            SELECT COUNT(*) FROM teacher_claim_evidence c
            JOIN teacher_benchmark_runs r ON r.benchmark_run_id=c.candidate_run_id
            WHERE r.suite_id=? AND c.status!='supported'
            """,
            (suite_id,),
        ).fetchone()[0]
        reasons = []
        if len(complete) < 2:
            reasons.append("at least two complete comparable runs are required")
        if open_regressions:
            reasons.append("blocking regressions remain open")
        if rejected_claims:
            reasons.append("unsupported or rejected claims remain")
        return {
            "schema_version": "persistmind.teacher_release_gate.v1",
            "ok": not reasons,
            "suite_id": suite_id,
            "complete_run_count": len(complete),
            "open_blocking_regression_count": open_regressions,
            "rejected_claim_count": rejected_claims,
            "reasons": reasons,
        }

    def _metric_map(self, run_id: str) -> dict[str, float]:
        rows = self.conn.execute(
            "SELECT metric_name, AVG(metric_value) AS value FROM teacher_benchmark_metrics WHERE benchmark_run_id=? GROUP BY metric_name",
            (run_id,),
        ).fetchall()
        return {str(row["metric_name"]): float(row["value"]) for row in rows}
