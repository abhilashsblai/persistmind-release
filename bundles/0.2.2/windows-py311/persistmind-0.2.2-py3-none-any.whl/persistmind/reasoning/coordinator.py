from __future__ import annotations

from typing import Any

from persistmind.reasoning.cycle import cycle_manifest, reasoning_cycle_id
from persistmind.reasoning.synthesis import synthesize_engineering_recommendation
from persistmind.utils import canonical_json, stable_id


class ReasoningCoordinator:
    def __init__(self, store: Any, *, repo_id: str):
        self.store = store
        self.repo_id = repo_id

    def run_checkpoint(
        self,
        *,
        task: str,
        checkpoint: str,
        paths: list[str],
        pack: dict[str, Any],
        task_session_id: str | None = None,
        goal_id: str | None = None,
        intent_id: str | None = None,
        metacognition: dict[str, Any] | None = None,
        provider_status: dict[str, Any] | None = None,
        provider_candidate: dict[str, Any] | None = None,
        working_memory: list[dict[str, Any]] | None = None,
        foresight: dict[str, Any] | None = None,
        reconsideration: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        cycle_id = reasoning_cycle_id(
            repo_id=self.repo_id,
            task_session_id=task_session_id,
            pack_id=pack.get("pack_id"),
            task=task,
            goal_id=goal_id,
            intent_id=intent_id,
        )
        cycle = self.store.upsert_reasoning_cycle(
            cycle_id=cycle_id,
            repo_id=self.repo_id,
            task_session_id=task_session_id,
            goal_id=goal_id,
            intent_id=intent_id,
            phase=_phase_for_checkpoint(checkpoint),
            status="open",
        )
        recommendation = synthesize_engineering_recommendation(
            task=task,
            paths=paths,
            pack=pack,
            metacognition=metacognition,
            provider_status=provider_status,
            provider_candidate=provider_candidate,
            working_memory=working_memory,
            foresight=foresight,
        )
        synthesis_id = stable_id(
            "reasoning_synthesis",
            cycle_id,
            checkpoint,
            recommendation.action,
            canonical_json(recommendation.drivers),
        )
        self.store.write_reasoning_synthesis(
            synthesis_id=synthesis_id,
            cycle_id=cycle_id,
            checkpoint=checkpoint,
            action=recommendation.action,
            confidence=recommendation.confidence,
            rationale=recommendation.rationale,
            drivers=recommendation.drivers,
            goal_fit=recommendation.goal_fit,
            provider_status=provider_status,
        )
        return {
            "ok": True,
            "schema_version": "persistmind.reasoning.v1",
            "active": True,
            "cycle": {
                **cycle_manifest(cycle),
                "goal_fit": round(recommendation.goal_fit, 4),
            },
            "recommendation": recommendation.to_manifest(),
            "working_memory": working_memory or [],
            "foresight": foresight or {},
            "provider_status": provider_status or {},
            "provider_candidate": provider_candidate or {},
            "reconsideration": reconsideration or {},
            "synthesis_id": synthesis_id,
        }


def _phase_for_checkpoint(checkpoint: str) -> str:
    if checkpoint in {"session_start", "pre_plan"}:
        return "context"
    if checkpoint in {"pre_complete", "verify"}:
        return "verify"
    return "execute"
