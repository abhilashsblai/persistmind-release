from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class EngineeringRecommendation:
    action: str
    confidence: float
    rationale: str
    drivers: list[dict[str, Any]]
    goal_fit: float
    provider_candidate: dict[str, Any] | None = None

    def to_manifest(self) -> dict[str, Any]:
        manifest = {
            "action": self.action,
            "confidence": round(self.confidence, 4),
            "rationale": self.rationale,
            "drivers": self.drivers,
        }
        if self.provider_candidate is not None:
            manifest["provider_candidate"] = self.provider_candidate
        return manifest


def synthesize_engineering_recommendation(
    *,
    task: str,
    paths: list[str],
    pack: dict[str, Any],
    metacognition: dict[str, Any] | None = None,
    provider_status: dict[str, Any] | None = None,
    provider_candidate: dict[str, Any] | None = None,
    working_memory: list[dict[str, Any]] | None = None,
    foresight: dict[str, Any] | None = None,
) -> EngineeringRecommendation:
    drivers: list[dict[str, Any]] = []
    low_confidence = bool(pack.get("low_confidence"))
    metacognition = metacognition or {}
    provider_status = provider_status or {}
    working_memory = working_memory or []
    foresight = foresight or {}
    uncertainty = _bounded_float(metacognition.get("uncertainty"), default=0.25)
    meta_action = str(metacognition.get("action") or "proceed")

    if paths:
        drivers.append(
            {
                "faculty": "impact",
                "signal": f"{len(paths)} scoped path(s) anchor the recommendation",
                "contribution": 0.25,
                "trust": "measured",
                "refs": [{"kind": "path", "value": path} for path in paths[:8]],
            }
        )
    else:
        drivers.append(
            {
                "faculty": "impact",
                "signal": "no explicit edit paths were supplied",
                "contribution": 0.2,
                "trust": "derived",
                "refs": [],
            }
        )

    if low_confidence:
        drivers.append(
            {
                "faculty": "retrieval",
                "signal": "context pack is low confidence",
                "contribution": 0.3,
                "trust": "measured",
                "refs": [{"kind": "pack", "value": pack.get("pack_id")}],
            }
        )

    if metacognition.get("active"):
        drivers.append(
            {
                "faculty": "metacognition",
                "signal": f"controller action is {meta_action}",
                "contribution": 0.3,
                "trust": "measured",
                "refs": [{"kind": "state", "value": metacognition.get("state_id")}],
            }
        )

    if working_memory:
        drivers.append(
            {
                "faculty": "working_memory",
                "signal": f"{len(working_memory)} active note(s) influence the checkpoint",
                "contribution": 0.2,
                "trust": "runtime",
                "refs": [
                    {"kind": "working_memory_note", "value": note.get("note_id")}
                    for note in working_memory[:8]
                ],
            }
        )

    foresight_predictions = list(foresight.get("predictions") or [])
    if foresight_predictions:
        drivers.append(
            {
                "faculty": "foresight",
                "signal": f"{len(foresight_predictions)} likely omission/co-change path(s)",
                "contribution": 0.2,
                "trust": "deterministic",
                "refs": [
                    {"kind": "path", "value": item.get("path")}
                    for item in foresight_predictions[:8]
                ],
            }
        )

    if provider_status.get("configured"):
        drivers.append(
            {
                "faculty": "provider",
                "signal": f"provider mode {provider_status.get('mode', 'unknown')} is configured",
                "contribution": 0.15,
                "trust": "runtime",
                "refs": [{"kind": "provider", "value": provider_status.get("provider_id")}],
            }
        )
    else:
        drivers.append(
            {
                "faculty": "provider",
                "signal": provider_status.get("reason") or "provider inactive",
                "contribution": 0.0,
                "trust": "inactive",
                "refs": [],
            }
        )

    if meta_action in {"ask_human", "replan", "gather_more"}:
        action = meta_action
    elif low_confidence:
        action = "gather_more"
    else:
        action = "proceed"

    confidence = max(0.0, min(1.0, 1.0 - uncertainty - (0.15 if low_confidence else 0.0)))
    goal_fit = max(0.0, min(1.0, confidence + (0.1 if task.strip() else -0.1)))
    rationale = _rationale(action=action, low_confidence=low_confidence, paths=paths)
    return EngineeringRecommendation(
        action=action,
        confidence=confidence,
        rationale=rationale,
        drivers=drivers,
        goal_fit=goal_fit,
        provider_candidate=provider_candidate,
    )


def _bounded_float(value: Any, *, default: float) -> float:
    try:
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return default


def _rationale(*, action: str, low_confidence: bool, paths: list[str]) -> str:
    if action == "ask_human":
        return "Pause for human clarification because the monitor marked the task unresolved."
    if action == "replan":
        return "Replan before continuing because current signals indicate the task is off track."
    if action == "gather_more" or low_confidence:
        return "Gather more context before writing because the current pack is not strong enough."
    if paths:
        return "Proceed with the scoped plan while preserving the current governance gates."
    return "Proceed cautiously; no explicit path scope was provided."
