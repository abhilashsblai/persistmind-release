from __future__ import annotations

from typing import Any

from persistmind.utils import stable_id


def reasoning_cycle_id(
    *,
    repo_id: str,
    task_session_id: str | None,
    pack_id: str | None,
    task: str,
    goal_id: str | None = None,
    intent_id: str | None = None,
) -> str:
    return stable_id(
        "reasoning_cycle",
        repo_id,
        task_session_id or "",
        pack_id or "",
        task,
        goal_id or "",
        intent_id or "",
    )


def cycle_manifest(row: Any) -> dict[str, Any]:
    return {
        "cycle_id": row["cycle_id"],
        "phase": row["phase"],
        "status": row["status"],
        "goal_id": row["goal_id"],
        "intent_id": row["intent_id"],
    }
