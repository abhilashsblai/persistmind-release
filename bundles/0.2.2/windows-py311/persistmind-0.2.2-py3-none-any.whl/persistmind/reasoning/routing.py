from __future__ import annotations

from typing import Any

from persistmind.utils import stable_id, utc_now


def route_provider_candidate(
    *,
    task: str,
    paths: list[str],
    provider_status: dict[str, Any] | None = None,
    provider_result: dict[str, Any] | None = None,
) -> dict[str, Any]:
    status = provider_status or {}
    result = provider_result or {}
    configured = bool(status.get("configured"))
    has_candidate = configured or bool(result)
    route_id = stable_id(
        "reasoner_provider_route",
        task,
        "|".join(sorted(paths)),
        str(status.get("provider_id") or ""),
        str(result.get("assertion") or result.get("action") or ""),
    )
    candidate = {
        "route_id": route_id,
        "schema_version": "persistmind.reasoner_routing.v1",
        "mode": "candidate_quarantine",
        "decision": "candidate" if has_candidate else "inactive",
        "authority": "advisory_candidate",
        "provider": {
            "configured": configured,
            "provider_id": status.get("provider_id"),
            "mode": status.get("mode"),
            "reason": status.get("reason"),
            "spend": status.get("spend") or {},
        },
        "candidate": result,
        "adopted": False,
        "approval_required": True,
        "promotion_policy": {
            "allowed": False,
            "requires": ["human_approval", "outcome_earned_trust"],
            "reason": "provider_output_never_authoritative_on_first_sight",
        },
        "adoption_boundary": "quarantined_until_human_or_outcome_approval",
        "quarantine_reason": (
            "provider_output_requires_outcome_or_human_approval"
            if has_candidate
            else "provider_not_configured"
        ),
        "paths": paths,
        "created_at": utc_now(),
    }
    return candidate
