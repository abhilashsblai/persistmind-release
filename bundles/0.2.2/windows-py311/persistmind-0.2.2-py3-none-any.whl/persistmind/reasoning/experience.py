from __future__ import annotations

from typing import Any

from persistmind.utils import stable_id


def task_shape_key(*, task: str, paths: list[str]) -> str:
    families = sorted({_family(path) for path in paths if path})
    words = [word.lower() for word in task.split() if len(word) > 3][:8]
    return stable_id("task_shape", " ".join(words), "|".join(families))


def lesson_from_surprise(
    *,
    task: str,
    paths: list[str],
    surprise: float,
    trigger: str = "checkpoint_surprise",
    evidence: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    shape = task_shape_key(task=task, paths=paths)
    score = max(0.0, min(1.0, float(surprise)))
    lesson = (
        "High-surprise checkpoint: slow down, re-check impacted paths, and capture "
        "the missing assumption before continuing."
        if score >= 0.55
        else "Low-surprise checkpoint: continue with scoped verification and retain evidence."
    )
    return {
        "schema_version": "persistmind.experience_lesson.v1",
        "task_shape_key": shape,
        "trigger": trigger,
        "lesson": lesson,
        "importance": round(max(0.2, score), 4),
        "support": 1,
        "lift": round(score, 4),
        "evidence": evidence or [],
    }


def critique_write_scope(
    *,
    task: str,
    paths: list[str],
    diff: str = "",
    risk_threshold: int = 8,
) -> dict[str, Any]:
    normalized = [path.replace("\\", "/") for path in paths if path]
    findings: list[dict[str, Any]] = []
    if not normalized:
        findings.append(
            {
                "kind": "missing_scope",
                "severity": "warn",
                "detail": "No paths were supplied for critique.",
            }
        )
    if len(normalized) > risk_threshold:
        findings.append(
            {
                "kind": "broad_scope",
                "severity": "warn",
                "detail": f"{len(normalized)} paths exceed threshold {risk_threshold}.",
            }
        )
    if diff and "TODO" in diff:
        findings.append(
            {
                "kind": "todo_in_diff",
                "severity": "info",
                "detail": "Diff contains TODO markers that may need follow-up evidence.",
            }
        )
    status = "warn" if any(item["severity"] == "warn" for item in findings) else "pass"
    return {
        "schema_version": "persistmind.workspace_critique.v1",
        "task": task,
        "task_shape_key": task_shape_key(task=task, paths=normalized),
        "status": status,
        "paths": normalized,
        "finding_count": len(findings),
        "findings": findings,
    }


def _family(path: str) -> str:
    normalized = path.replace("\\", "/")
    if "/" not in normalized:
        return normalized.rsplit(".", 1)[-1]
    parts = normalized.split("/")
    return "/".join(parts[:2]) if len(parts) > 1 else parts[0]
