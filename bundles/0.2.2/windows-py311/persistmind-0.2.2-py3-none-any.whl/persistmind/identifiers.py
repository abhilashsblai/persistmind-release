from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from enum import Enum
from typing import Mapping


class WorkflowIdKind(str, Enum):
    TASK = "task"
    PACK = "pack"
    PLAN = "plan"
    CHECKPOINT = "checkpoint"
    OUTCOME = "outcome"


@dataclass(frozen=True, slots=True)
class WorkflowIdSpec:
    key: str
    prefix: str
    hex_length: int


@dataclass(frozen=True, slots=True)
class ParsedWorkflowId:
    kind: WorkflowIdKind
    value: str
    canonical: bool

    @property
    def compatibility(self) -> bool:
        return not self.canonical


SPECS: Mapping[WorkflowIdKind, WorkflowIdSpec] = {
    WorkflowIdKind.TASK: WorkflowIdSpec("task_session_id", "task_", 64),
    WorkflowIdKind.PACK: WorkflowIdSpec("pack_id", "pack_", 32),
    WorkflowIdKind.PLAN: WorkflowIdSpec("plan_id", "plan_", 64),
    WorkflowIdKind.CHECKPOINT: WorkflowIdSpec("checkpoint_id", "checkpoint_", 64),
    WorkflowIdKind.OUTCOME: WorkflowIdSpec("outcome_id", "outcome_", 32),
}

KIND_BY_KEY: Mapping[str, WorkflowIdKind] = {spec.key: kind for kind, spec in SPECS.items()}

_LOWER_HEX = re.compile(r"^[0-9a-f]+$")
_LEGACY_ID = re.compile(r"^[0-9a-f]{64}$")


def parse_workflow_id(
    kind: WorkflowIdKind | str,
    value: str,
    *,
    allow_legacy: bool = True,
) -> ParsedWorkflowId:
    parsed_kind = WorkflowIdKind(kind)
    candidate = str(value)
    spec = SPECS[parsed_kind]
    if candidate.startswith(spec.prefix):
        suffix = candidate[len(spec.prefix) :]
        if len(suffix) == spec.hex_length and _LOWER_HEX.fullmatch(suffix):
            return ParsedWorkflowId(parsed_kind, candidate, canonical=True)
        raise ValueError(f"unsupported_id_format:{spec.key}")
    if allow_legacy and _LEGACY_ID.fullmatch(candidate):
        return ParsedWorkflowId(parsed_kind, candidate, canonical=False)
    raise ValueError(f"unsupported_id_format:{spec.key}")


def workflow_id_is_valid(
    kind: WorkflowIdKind | str,
    value: object,
    *,
    allow_legacy: bool = True,
) -> bool:
    if not isinstance(value, str):
        return False
    try:
        parse_workflow_id(kind, value, allow_legacy=allow_legacy)
    except (TypeError, ValueError):
        return False
    return True


def validate_binding_identifiers(
    values: Mapping[str, object],
    *,
    allow_legacy: bool = True,
) -> dict[str, str]:
    validated: dict[str, str] = {}
    for key, kind in KIND_BY_KEY.items():
        value = values.get(key)
        if value is None:
            continue
        if not isinstance(value, str):
            raise ValueError(f"unsupported_id_format:{key}")
        parse_workflow_id(kind, value, allow_legacy=allow_legacy)
        validated[key] = value
    return validated


def validate_host_session_id(value: object) -> str:
    if not isinstance(value, str) or not value or len(value) > 256:
        raise ValueError("invalid_host_session_id")
    if any(unicodedata.category(character) == "Cc" for character in value):
        raise ValueError("invalid_host_session_id")
    return value


__all__ = [
    "KIND_BY_KEY",
    "ParsedWorkflowId",
    "SPECS",
    "WorkflowIdKind",
    "parse_workflow_id",
    "validate_binding_identifiers",
    "validate_host_session_id",
    "workflow_id_is_valid",
]
