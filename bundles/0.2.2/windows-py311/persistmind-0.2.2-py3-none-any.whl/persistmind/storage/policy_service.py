from __future__ import annotations

import fnmatch
import hashlib
import json
import re
import subprocess
from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from persistmind.application.execution_scope import current_operation_scope
from persistmind.application.field_statistics import assign_arm, assignment_anchor
from persistmind.application.registry import operation_catalog
from persistmind.config import load_settings
from persistmind.governance.policy import CapabilityPolicy
from persistmind.security.approvals import require_approval_quorum, require_approval_signature
from persistmind.security.envelope import WorkspaceKeyProvider
from persistmind.security.secret_scan import SecretScanner
from persistmind.utils import canonical_json, stable_id, utc_now

from .adapters.sqlite_control import SQLiteControlStore
from .adapters.sqlite_knowledge import SQLiteKnowledgeStore
from .adapters.sqlite_learning import SQLiteLearningStore
from .adapters.sqlite_policy import SQLitePolicyStore
from .descriptors import StoreRole
from .runtime import StorageOpenIntent, StorageRuntime, resolve_runtime_store


class PolicyService:
    """Independent approval boundary between Learning proposals and Task execution."""

    def __init__(
        self,
        repo_root: Path,
        *,
        read_only: bool = False,
        allow_development_driver: bool = False,
    ) -> None:
        self.repo_root = repo_root.resolve()
        settings = load_settings(self.repo_root)
        operation_scope = current_operation_scope()
        required_roles = (
            frozenset(StoreRole(role) for role in operation_scope.roles)
            if operation_scope is not None
            else frozenset(
                {
                    StoreRole.CONTROL,
                    StoreRole.LEARNING,
                    StoreRole.POLICY,
                    StoreRole.KNOWLEDGE,
                }
            )
        )
        required_roles = required_roles | {StoreRole.POLICY}
        self.runtime = StorageRuntime.open(
            self.repo_root / settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            read_only=read_only,
            allow_development_driver=allow_development_driver,
            required_roles=required_roles,
        )
        policy = resolve_runtime_store(self.runtime, StoreRole.POLICY, read_only=read_only)
        if not isinstance(policy, SQLitePolicyStore):
            raise RuntimeError("PolicyService authority routing is invalid")
        self.policy = policy
        self._learning: SQLiteLearningStore | None = None
        self._knowledge: SQLiteKnowledgeStore | None = None
        self._control: SQLiteControlStore | None = None
        self.read_only = read_only
        self._allow_development_driver = allow_development_driver

    def close(self) -> None:
        self.runtime.close()

    def __enter__(self) -> PolicyService:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    @property
    def learning(self) -> SQLiteLearningStore:
        if self._learning is None:
            value = resolve_runtime_store(self.runtime, StoreRole.LEARNING, read_only=True)
            if not isinstance(value, SQLiteLearningStore):
                raise RuntimeError("Learning read route is invalid")
            self._learning = value
        return self._learning

    @property
    def knowledge(self) -> SQLiteKnowledgeStore:
        if self._knowledge is None:
            value = resolve_runtime_store(self.runtime, StoreRole.KNOWLEDGE, read_only=True)
            if not isinstance(value, SQLiteKnowledgeStore):
                raise RuntimeError("Knowledge read route is invalid")
            self._knowledge = value
        return self._knowledge

    @property
    def control(self) -> SQLiteControlStore:
        if self._control is None:
            value = resolve_runtime_store(self.runtime, StoreRole.CONTROL, read_only=True)
            if not isinstance(value, SQLiteControlStore):
                raise RuntimeError("Control read route is invalid")
            self._control = value
        return self._control

    def decide_proposal(
        self,
        proposal_id: str,
        *,
        decision: str,
        actor: str,
        signature: str,
        reason: str,
        approvals: list[Mapping[str, str]] | None = None,
    ) -> dict[str, Any]:
        if self.read_only:
            raise PermissionError("Policy decision requires a write-capable handler")
        normalized_decision = decision.strip().lower()
        row = (
            self.learning._reader()
            .execute("SELECT * FROM learning_action_proposals WHERE proposal_id=?", (proposal_id,))
            .fetchone()
        )
        if row is None:
            raise KeyError(f"unknown Learning proposal: {proposal_id}")
        proposal = dict(row)
        if str(proposal["state"]) not in {"policy_pending", normalized_decision}:
            raise RuntimeError(f"proposal is already terminal: {proposal['state']}")
        decision_document = {
            "schema_version": "persistmind.policy_decision_document.v1",
            "proposal_id": proposal_id,
            "proposal_hash": hashlib.sha256(canonical_json(proposal).encode("utf-8")).hexdigest(),
            "action_class": str(proposal["action_class"]),
            "decision": normalized_decision,
            "actor": actor,
            "reason": reason,
        }
        risk_floor = str(proposal.get("risk_floor") or "medium").lower()
        if risk_floor == "critical":
            approval_rows = list(approvals or [{"principal": actor, "signature": signature}])
            signer_identities = require_approval_quorum(
                self.runtime.root,
                approval_rows,
                decision_document,
                quorum=2,
                allow_test_provider=self._allow_development_driver,
            )
        else:
            approval_rows = [{"principal": actor, "signature": signature}]
            signer_identities = [
                require_approval_signature(
                    self.runtime.root,
                    signature,
                    decision_document,
                    expected_principal=actor,
                    allow_test_provider=self._allow_development_driver,
                )
            ]
        result = dict(
            self.policy.decide_action_proposal(
                proposal,
                decision=normalized_decision,
                actor=actor,
                signature=signature,
                reason=reason,
                decision_document=decision_document,
                approvals=approval_rows,
                signer_identities=signer_identities,
            )
        )
        from .policy_reconciler import PolicyProjectionReconciler

        reconciler = PolicyProjectionReconciler(
            self.repo_root,
            allow_development_driver=self._allow_development_driver,
        )
        result["learning_projection"] = reconciler.apply_learning_decision(
            str(result["outbox_event_id"])
        )
        result["audit_projection"] = reconciler.apply_audit_decision(str(result["outbox_event_id"]))
        result["proposal"] = json.loads(str(proposal["payload_json"]))
        return result

    def policy_approve_business_rule(
        self,
        candidate_id: str,
        *,
        approver: str,
        signature: str,
    ) -> dict[str, Any]:
        """Verify Knowledge evidence, then commit an independent Policy decision."""
        if self.read_only:
            raise PermissionError("Policy approval requires a write-capable handler")
        candidate = self.knowledge.get(candidate_id)
        if (
            candidate is None
            or str(candidate.get("kind")) != "memory"
            or str(candidate.get("type")) != "business_rule_candidate"
        ):
            raise ValueError("policy approval requires a business_rule_candidate")
        if str(candidate.get("status")) not in {"candidate", "needs_review"}:
            raise ValueError("only non-authoritative business-rule candidates can be approved")
        evidence = list(self.knowledge.evidence(candidate_id))
        evidence_hashes = sorted(
            {str(item.get("content_hash")) for item in evidence if item.get("content_hash")}
        )
        if not evidence_hashes:
            raise ValueError("business-rule policy approval requires candidate evidence")
        policy_id = (
            "policy_"
            + stable_id(
                "approved-business-rule",
                candidate_id,
                str(candidate.get("_content_hash") or ""),
                *evidence_hashes,
            )[:32]
        )
        document = {
            "schema_version": "persistmind.policy_decision_document.v1",
            "action": "policy_approve_business_rule",
            "policy_id": policy_id,
            "candidate_id": candidate_id,
            "candidate_content_hash": str(candidate.get("_content_hash") or ""),
            "evidence_hashes": evidence_hashes,
            "approver": approver,
        }
        signer = require_approval_signature(
            self.runtime.root,
            signature,
            document,
            expected_principal=approver,
            allow_test_provider=self._allow_development_driver,
        )
        payload = dict(candidate.get("metadata") or {})
        scopes = sorted({str(item) for item in payload.get("scope_refs", []) if str(item)})
        policy = {
            **document,
            "policy_type": "approved_business_rule",
            "scope": "global" if not scopes else f"path:{scopes[0]}",
            "path_globs": scopes or ["**"],
            "priority": 80,
            "rule_text": str(candidate.get("assertion") or ""),
            "status": "active",
            "approved_by": approver,
            "signer": signer,
            "approved_at": utc_now(),
        }
        existing = self.policy.policy(policy_id)
        if existing is None:
            self.policy.approve_policy(
                policy,
                approver=approver,
                signature=signature,
                signer_identity=signer,
                decision_document=document,
            )
        elif any(
            existing.get(key) != policy.get(key)
            for key in ("candidate_id", "candidate_content_hash", "evidence_hashes", "rule_text")
        ):
            raise ValueError("policy id conflicts with different immutable evidence")
        from .policy_reconciler import PolicyProjectionReconciler

        event_id = "event_" + stable_id(policy_id, "PolicyDecisionObserved.v1")[:32]
        audit_projection = PolicyProjectionReconciler(
            self.repo_root,
            allow_development_driver=self._allow_development_driver,
        ).apply_audit_decision(event_id)
        return {
            "ok": True,
            "status": "approved",
            "schema_version": "persistmind.policy_business_rule_decision.v1",
            "policy": dict(self.policy.policy(policy_id) or {}),
            "decision_document": document,
            "signer": signer,
            "audit_projection": audit_projection,
        }

    def experiment_approve(
        self,
        experiment_id: str,
        *,
        protocol: Mapping[str, Any],
        actor: str,
        signature: str,
        approvals: list[Mapping[str, str]] | None = None,
    ) -> dict[str, Any]:
        if self.read_only:
            raise PermissionError("experiment approval requires Policy write authority")
        protocol_document = dict(protocol)
        required = {
            "primary_metric",
            "eligible_population",
            "exclusions",
            "task_family_strata",
            "risk_strata",
            "baseline_version",
            "candidate_version",
            "stop_rules",
            "allowed_scope",
            "expires_at",
        }
        missing = sorted(required - set(protocol_document))
        if missing:
            raise ValueError("field protocol is incomplete: " + ", ".join(missing))
        protocol_hash = (
            "sha256:"
            + hashlib.sha256(canonical_json(protocol_document).encode("utf-8")).hexdigest()
        )
        risk = str(protocol_document.get("maximum_risk") or "medium").lower()
        quorum = 2 if risk == "critical" else 1
        key_id = "field-assignment-v1-" + stable_id(experiment_id)[:24]
        provider = WorkspaceKeyProvider(
            self.runtime.root, allow_test_provider=self._allow_development_driver
        )
        secret = provider.get_or_create(key_id)
        anchor = assignment_anchor(secret, experiment_id, protocol_hash)
        document = {
            "schema_version": "persistmind.policy_decision_document.v1",
            "action": "experiment_approve",
            "experiment_id": experiment_id,
            "protocol_hash": protocol_hash,
            "protocol": protocol_document,
            "assignment_key_id": key_id,
            "assignment_anchor": anchor,
            "required_quorum": quorum,
            "actor": actor,
        }
        signed = list(approvals or [{"principal": actor, "signature": signature}])
        identities = require_approval_quorum(
            self.runtime.root,
            signed,
            document,
            quorum=quorum,
            allow_test_provider=self._allow_development_driver,
        )
        approval = self.policy.approve_experiment(
            {
                "experiment_id": experiment_id,
                "protocol_hash": protocol_hash,
                "protocol": protocol_document,
                "allowed_scope": dict(protocol_document["allowed_scope"]),
                "required_quorum": quorum,
                "expires_at": str(protocol_document["expires_at"]),
            },
            signatures=signed,
            signer_identities=identities,
            decision_document=document,
        )
        return {
            "ok": True,
            "status": "approved",
            "schema_version": "persistmind.field_experiment_policy_approval.v1",
            "approval": dict(approval),
            "protocol_hash": protocol_hash,
            "assignment_key_id": key_id,
            "assignment_anchor": anchor,
            "decision_document": document,
            "signers": identities,
        }

    def experiment_assign(self, experiment_id: str, *, assignment_unit_id: str) -> dict[str, Any]:
        approval = self.policy.experiment_approval(experiment_id)
        if approval is None or str(approval.get("state")) != "approved":
            raise PermissionError("field experiment lacks an active Policy approval")
        key_id = "field-assignment-v1-" + stable_id(experiment_id)[:24]
        provider = WorkspaceKeyProvider(
            self.runtime.root, allow_test_provider=self._allow_development_driver
        )
        secret = provider.get_or_create(key_id)
        arm = assign_arm(secret, experiment_id, assignment_unit_id)
        receipt = {
            "schema_version": "persistmind.field_assignment.v1",
            "experiment_id": experiment_id,
            "assignment_unit_id": assignment_unit_id,
            "assignment": arm,
            "assignment_key_id": key_id,
            "protocol_hash": str(approval["protocol_hash"]),
        }
        result = {
            "ok": True,
            **receipt,
            "assignment_receipt_hash": "sha256:"
            + hashlib.sha256(canonical_json(receipt).encode("utf-8")).hexdigest(),
        }
        self.policy.record_experiment_assignment(result)
        return result

    def learning_promotion_decide(
        self,
        request_id: str,
        *,
        actor: str,
        signature: str,
    ) -> dict[str, Any]:
        if self.read_only:
            raise PermissionError("learning promotion decision requires Policy authority")
        request = self.learning.get(request_id)
        if request is None or request.get("kind") != "learning_promotion_request":
            raise KeyError(f"learning promotion request not found: {request_id}")
        document = {
            "schema_version": "persistmind.policy_decision_document.v1",
            "action": "learning_promotion_decide",
            "request_id": request_id,
            "version_id": str(request["version_id"]),
            "artifact_ref": str(request["artifact_ref"]),
            "field_experiment_id": str(request["field_experiment_id"]),
            "protocol_hash": str(request["protocol_hash"]),
            "statistics_hash": str(request["statistics_hash"]),
            "rollback_version": str(request["rollback_version"]),
            "protected_surface_hash": str(request["protected_surface_hash"]),
            "actor": actor,
        }
        identity = require_approval_signature(
            self.runtime.root,
            signature,
            document,
            expected_principal=actor,
            allow_test_provider=self._allow_development_driver,
        )
        policy_id = "learning-promotion-" + request_id
        policy = {
            **document,
            "policy_id": policy_id,
            "decision_type": "learning_promotion",
            "scope": "learning:" + str(request["skill_id"]),
            "priority": 95,
            "status": "active",
        }
        self.policy.approve_policy(
            policy,
            approver=actor,
            signature=signature,
            signer_identity=identity,
            decision_document=document,
        )
        stored = dict(self.policy.policy(policy_id) or {})
        decision_hash = (
            "sha256:" + hashlib.sha256(canonical_json(stored).encode("utf-8")).hexdigest()
        )
        return {
            "ok": True,
            "status": "approved",
            "schema_version": "persistmind.learning_promotion_policy_decision.v1",
            "policy_decision": stored,
            "policy_decision_id": policy_id,
            "policy_decision_hash": decision_hash,
            "signer": identity,
        }

    def capability_matrix(self, output_format: str = "json") -> dict[str, Any]:
        if output_format != "json":
            raise ValueError("Policy capability matrix supports canonical JSON output only")
        rows = []
        for operation_id, descriptor in sorted(operation_catalog().items()):
            rows.append(
                {
                    "operation_id": operation_id,
                    "owner": descriptor.owner,
                    "authorization_action": descriptor.authorization_action,
                    "risk_floor": descriptor.risk_floor,
                    "autonomy_ceiling": descriptor.autonomy_ceiling,
                    "capabilities": list(descriptor.capabilities),
                    "availability": descriptor.availability.value,
                }
            )
        return {
            "ok": True,
            "status": "verified",
            "schema_version": "persistmind.capability_matrix.v1",
            "operations": rows,
        }

    def capability_claims_check(self, claim: str | None = None) -> dict[str, Any]:
        matrix = self.capability_matrix()
        rows = list(matrix["operations"])
        if claim:
            rows = [
                row
                for row in rows
                if claim == row["operation_id"]
                or claim == row["authorization_action"]
                or claim in row["capabilities"]
            ]
        unsupported = [row for row in rows if row["availability"] != "active"]
        return {
            "ok": bool(rows) and not unsupported,
            "status": "verified" if rows and not unsupported else "unsupported_operation",
            "schema_version": "persistmind.capability_claims_check.v1",
            "claim": claim,
            "matches": rows,
            "unsupported": unsupported,
        }

    def constitution_build(
        self,
        *,
        actor: str,
        signature: str,
        nonce: str,
        issued_at: str,
        expires_at: str,
        approvals: list[Mapping[str, str]] | None = None,
    ) -> dict[str, Any]:
        capability_policy = CapabilityPolicy(self.repo_root, load_settings(self.repo_root))
        body = {
            "schema_version": "persistmind.constitution.v2",
            "workspace_id": stable_id(str(self.repo_root))[:16],
            "capabilities": capability_policy.manifest,
            "critical_paths": sorted(load_settings(self.repo_root).ci.critical_paths),
            "execution_states": ["INTAKE", "PACK", "PLAN", "EXECUTE", "PREFLIGHT", "OUTCOME"],
            "safety_constraint_hashes": sorted(
                str(item["content_hash"]) for item in self.policy.safety_constraints()
            ),
        }
        return self._approve_policy_artifact(
            "constitution",
            body,
            scope="workspace",
            priority=100,
            risk_class="critical",
            actor=actor,
            signature=signature,
            nonce=nonce,
            issued_at=issued_at,
            expires_at=expires_at,
            approvals=approvals,
        )

    def constitution_show(self) -> dict[str, Any]:
        rows = [
            dict(item)
            for item in self.policy.policies(status="active")
            if str(item.get("policy_type")) == "constitution"
        ]
        latest = rows[0] if rows else None
        return {
            "ok": latest is not None,
            "status": "active" if latest is not None else "source_not_ready",
            "schema_version": "persistmind.constitution_show.v1",
            "constitution": latest,
        }

    def constitution_check(
        self,
        paths: list[str] | None = None,
        *,
        task_session_id: str | None = None,
        for_ci: bool = False,
        staged: bool | None = None,
    ) -> dict[str, Any]:
        settings = load_settings(self.repo_root)
        checked_paths = list(paths or [])
        if staged and not checked_paths:
            checked_paths = _staged_paths(self.repo_root)
        constitution = self.constitution_show()
        constitution_built = bool(constitution["ok"])
        constitution_required = bool(settings.governance.require_constitution)
        constitution_ok = constitution_built or not constitution_required
        path_check = CapabilityPolicy(self.repo_root, settings).check_paths(
            checked_paths, task_session_id=task_session_id, for_ci=for_ci
        )
        ok = bool(constitution_ok) and bool(path_check["ok"])
        status = (
            "verified"
            if ok and constitution_built
            else "constitution_not_built"
            if ok and not constitution_built
            else "not_authorized"
        )
        details: dict[str, Any] = {
            "constitution_required": constitution_required,
            "constitution_built": constitution_built,
            "staged": bool(staged),
            "checked_paths": checked_paths,
        }
        if not path_check["ok"]:
            details["failing_capabilities"] = sorted(
                {
                    str(item.get("capability") or item.get("capability_id") or "")
                    for item in path_check.get("violations", [])
                    if isinstance(item, Mapping)
                }
            )
        remediation = None
        if constitution_required and not constitution_built:
            remediation = (
                "Build a signed constitution with: persistmind --repo . constitution build "
                "--signature <sig> --nonce <nonce> --issued-at <iso> --expires-at <iso>"
            )
        elif not path_check["ok"]:
            remediation = (
                "Review the reported capability violations or bind the commit to an "
                "approved task session."
            )
        return {
            "ok": ok,
            "status": status,
            "schema_version": "persistmind.constitution_check.v1",
            "enforced": constitution_built or constitution_required,
            "constitution": constitution.get("constitution"),
            "path_check": path_check,
            "details": details,
            "remediation": remediation,
        }

    def governance_propose(
        self, proposal: Mapping[str, Any] | None = None, *, min_samples: int | None = None
    ) -> dict[str, Any]:
        if self.read_only:
            raise PermissionError("governance proposal requires Policy write authority")
        payload = dict(proposal or {})
        payload.setdefault("minimum_samples", min_samples)
        payload.setdefault("schema_version", "persistmind.governance_proposal.v1")
        payload.setdefault("proposed_at", utc_now())
        stored = self.policy.create_governance_proposal("governance", payload)
        return {
            "ok": True,
            "status": "proposed",
            "schema_version": "persistmind.governance_proposal_result.v1",
            "proposal": dict(stored),
        }

    def governance_list(self, status: str | None = None) -> dict[str, Any]:
        rows = [dict(item) for item in self.policy.governance_proposals(state=status)]
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.governance_list.v1",
            "proposals": rows,
        }

    def governance_show(self, proposal_id: str) -> dict[str, Any]:
        row = self.policy.governance_proposal(proposal_id)
        return {
            "ok": row is not None,
            "status": str(row["state"]) if row is not None else "unidentifiable",
            "schema_version": "persistmind.governance_show.v1",
            "proposal": dict(row) if row is not None else None,
        }

    def governance_preview_adoption(self, proposal_id: str) -> dict[str, Any]:
        row = self.policy.governance_proposal(proposal_id)
        if row is None:
            raise KeyError(f"unknown governance proposal: {proposal_id}")
        return {
            "ok": str(row["state"]) == "proposed",
            "status": "candidate" if str(row["state"]) == "proposed" else str(row["state"]),
            "schema_version": "persistmind.governance_adoption_preview.v1",
            "proposal_id": proposal_id,
            "payload_hash": row["payload_hash"],
            "scope": row["payload"].get("scope", "workspace"),
            "risk_class": row["payload"].get("risk_class", "critical"),
        }

    def governance_adopt(self, proposal_id: str, **decision: Any) -> dict[str, Any]:
        return self._governance_transition(proposal_id, "adopted", **decision)

    def governance_reject(self, proposal_id: str, **decision: Any) -> dict[str, Any]:
        return self._governance_transition(proposal_id, "rejected", **decision)

    def governance_rollback(self, proposal_id: str, **decision: Any) -> dict[str, Any]:
        return self._governance_transition(proposal_id, "rolled_back", **decision)

    def governance_status(self) -> dict[str, Any]:
        rows = [dict(item) for item in self.policy.governance_proposals()]
        counts = {
            state: sum(item["state"] == state for item in rows)
            for state in ("proposed", "adopted", "rejected", "rolled_back")
        }
        return {
            "ok": True,
            "status": "active",
            "schema_version": "persistmind.governance_status.v1",
            "counts": counts,
            "constitution": self.constitution_show().get("constitution"),
        }

    def guardrail_override(
        self,
        directive_id: str,
        *,
        rationale: str,
        actor: str,
        signature: str,
        nonce: str,
        issued_at: str,
        expires_at: str,
        task_session_id: str | None = None,
        session_id: str | None = None,
        target_paths: list[str] | None = None,
        approvals: list[Mapping[str, str]] | None = None,
    ) -> dict[str, Any]:
        return self._approve_policy_artifact(
            "guardrail_override",
            {
                "directive_id": directive_id,
                "rationale": rationale,
                "task_session_id": task_session_id,
                "session_id": session_id,
                "target_paths": sorted(target_paths or []),
            },
            scope="workspace",
            priority=100,
            risk_class="critical",
            actor=actor,
            signature=signature,
            nonce=nonce,
            issued_at=issued_at,
            expires_at=expires_at,
            approvals=approvals,
        )

    def security_scan(self) -> dict[str, Any]:
        if self.read_only:
            raise PermissionError("security scan recording requires Policy write authority")
        scan = SecretScanner(self.repo_root).scan()
        stored = self.policy.record_security_snapshot("secret_scan", scan)
        return {
            "ok": bool(scan["ok"]),
            "status": "verified" if scan["ok"] else "unsafe",
            "schema_version": "persistmind.security_scan.v1",
            "scan": scan,
            "snapshot": dict(stored),
        }

    def security_ingest_redteam(
        self, fixtures: str, *, output: str | None = None, strict: bool = False
    ) -> dict[str, Any]:
        if self.read_only:
            raise PermissionError("red-team ingestion requires Policy write authority")
        source = (self.repo_root / fixtures).resolve()
        if not source.is_relative_to(self.repo_root) or not source.is_file():
            raise ValueError("red-team fixture must be a file inside the repository")
        payload = json.loads(source.read_text(encoding="utf-8"))
        document = {
            "source": source.relative_to(self.repo_root).as_posix(),
            "strict": strict,
            "output": output,
            "fixture_hash": _domain_hash("persistmind.redteam-fixture.v1", {"payload": payload}),
            "case_count": len(payload) if isinstance(payload, list) else 1,
        }
        stored = self.policy.record_security_snapshot("redteam", document)
        return {
            "ok": True,
            "status": "ingested",
            "schema_version": "persistmind.security_redteam_ingestion.v1",
            "snapshot": dict(stored),
        }

    def security_status(self) -> dict[str, Any]:
        rows = [dict(item) for item in self.policy.security_snapshots(limit=50)]
        unsafe = [
            item
            for item in rows
            if item["snapshot_type"] == "secret_scan" and not item["payload"].get("ok", False)
        ]
        return {
            "ok": not unsafe,
            "status": "verified" if not unsafe else "unsafe",
            "schema_version": "persistmind.security_status.v1",
            "snapshots": rows,
            "unsafe_snapshot_ids": [item["snapshot_id"] for item in unsafe],
        }

    def provider_status(self) -> dict[str, Any]:
        provider = WorkspaceKeyProvider(
            self.runtime.root, allow_test_provider=self._allow_development_driver
        )
        return {
            "ok": not self._allow_development_driver,
            "status": "production" if not self._allow_development_driver else "development_only",
            "schema_version": "persistmind.policy_provider_status.v1",
            "provider": type(provider).__name__,
            "workspace_root": str(self.runtime.root),
        }

    def _approve_policy_artifact(
        self,
        policy_type: str,
        payload: Mapping[str, Any],
        *,
        scope: str,
        priority: int,
        risk_class: str,
        actor: str,
        signature: str,
        nonce: str,
        issued_at: str,
        expires_at: str,
        approvals: list[Mapping[str, str]] | None,
        policy_id: str | None = None,
    ) -> dict[str, Any]:
        if self.read_only:
            raise PermissionError("Policy artifact approval requires write authority")
        _timestamp(issued_at)
        if _timestamp(expires_at) <= _timestamp(issued_at):
            raise ValueError("Policy artifact expiry must follow issuance")
        _nonce(nonce)
        risk = _risk(risk_class)
        content_hash = _domain_hash("persistmind.policy-artifact.v1", dict(payload))
        artifact_id = policy_id or policy_type + "_" + stable_id(content_hash)[:32]
        quorum = 2 if risk == "critical" else 1
        scope_hash = _domain_hash("persistmind.policy-scope.v1", {"scope": scope})
        document = _policy_document(
            subject_type=policy_type,
            subject_id=artifact_id,
            subject_content_hash=content_hash,
            action="activate",
            scope_hash=scope_hash,
            risk_class=risk,
            quorum=quorum,
            maximum_uses=1,
            issued_at=issued_at,
            expires_at=expires_at,
            nonce=nonce,
            prior_state_hash=_domain_hash("persistmind.policy-state.v1", {"state": None}),
            actor=actor,
            artifact_hash=content_hash,
        )
        signed = list(approvals or [{"principal": actor, "signature": signature}])
        identities = require_approval_quorum(
            self.runtime.root,
            signed,
            document,
            quorum=quorum,
            allow_test_provider=self._allow_development_driver,
        )
        policy = {
            "policy_id": artifact_id,
            "policy_type": policy_type,
            "scope": scope,
            "priority": priority,
            "risk_class": risk,
            "content_hash": content_hash,
            "payload": dict(payload),
            "issued_at": issued_at,
            "expires_at": expires_at,
            "status": "active",
        }
        self.policy.approve_policy_quorum(
            policy,
            signatures=signed,
            signer_identities=identities,
            decision_document=document,
        )
        return {
            "ok": True,
            "status": "active",
            "schema_version": "persistmind.policy_artifact_approval.v1",
            "policy": dict(self.policy.policy(artifact_id) or {}),
            "decision_document": document,
            "signers": identities,
        }

    def _governance_transition(
        self,
        proposal_id: str,
        to_state: str,
        *,
        actor: str,
        signature: str,
        nonce: str,
        issued_at: str,
        expires_at: str,
        reason: str | None = None,
        approvals: list[Mapping[str, str]] | None = None,
    ) -> dict[str, Any]:
        if self.read_only:
            raise PermissionError("governance transition requires Policy authority")
        proposal = self.policy.governance_proposal(proposal_id)
        if proposal is None:
            raise KeyError(f"unknown governance proposal: {proposal_id}")
        _timestamp(issued_at)
        if _timestamp(expires_at) <= _timestamp(issued_at):
            raise ValueError("governance decision expiry must follow issuance")
        _nonce(nonce)
        quorum = 2
        document = _policy_document(
            subject_type="governance_proposal",
            subject_id=proposal_id,
            subject_content_hash=str(proposal["payload_hash"]),
            action=to_state,
            scope_hash=_domain_hash(
                "persistmind.policy-scope.v1",
                {"scope": proposal["payload"].get("scope", "workspace")},
            ),
            risk_class="critical",
            quorum=quorum,
            maximum_uses=1,
            issued_at=issued_at,
            expires_at=expires_at,
            nonce=nonce,
            prior_state_hash=_domain_hash(
                "persistmind.policy-state.v1", {"state": proposal["state"]}
            ),
            actor=actor,
            artifact_hash=str(proposal["payload_hash"]),
        )
        signed = list(approvals or [{"principal": actor, "signature": signature}])
        identities = require_approval_quorum(
            self.runtime.root,
            signed,
            document,
            quorum=quorum,
            allow_test_provider=self._allow_development_driver,
        )
        if to_state == "adopted":
            policy = {
                "policy_id": "governance-" + proposal_id,
                "policy_type": "governance_adoption",
                "scope": proposal["payload"].get("scope", "workspace"),
                "priority": int(proposal["payload"].get("priority", 90)),
                "proposal_id": proposal_id,
                "proposal_hash": proposal["payload_hash"],
                "payload": proposal["payload"],
                "status": "active",
            }
            self.policy.approve_policy_quorum(
                policy,
                signatures=signed,
                signer_identities=identities,
                decision_document=document,
            )
        elif to_state == "rolled_back":
            self.policy.set_policy_status_quorum(
                "governance-" + proposal_id,
                status="suspended",
                actor=actor,
                reason=reason or "governance rollback",
                signatures=signed,
                signer_identities=identities,
                decision_document=document,
            )
        stored = self.policy.transition_governance_proposal(
            proposal_id,
            to_state=to_state,
            actor=actor,
            reason=reason or to_state,
            signatures=signed,
            signer_identities=identities,
            decision_document=document,
        )
        return {
            "ok": True,
            "status": to_state,
            "schema_version": "persistmind.governance_transition.v1",
            "proposal": dict(stored),
            "decision_document": document,
            "signers": identities,
        }

    def safety_constraint_add(
        self,
        constraint_id: str,
        *,
        contract_version: str,
        predicate: Mapping[str, Any],
        risk_floor: str,
        fail_state: str,
        valid_from: str,
        valid_to: str | None,
        actor: str,
        signature: str,
        nonce: str,
        approvals: list[Mapping[str, str]] | None = None,
    ) -> dict[str, Any]:
        if self.read_only:
            raise PermissionError("safety-constraint creation requires Policy authority")
        risk = _risk(risk_floor)
        if fail_state not in {"not_authorized", "unsafe", "unknown"}:
            raise ValueError("invalid safety-constraint fail state")
        _timestamp(valid_from)
        if valid_to is not None and _timestamp(valid_to) < _timestamp(valid_from):
            raise ValueError("constraint validity interval is inverted")
        _nonce(nonce)
        subject = {
            "constraint_id": constraint_id,
            "contract_version": contract_version,
            "predicate": dict(predicate),
            "risk_floor": risk,
            "fail_state": fail_state,
            "valid_from": valid_from,
            "valid_to": valid_to,
        }
        content_hash = _domain_hash("persistmind.policy-safety-constraint.v1", subject)
        quorum = 2 if risk == "critical" else 1
        document = _policy_document(
            subject_type="safety_constraint",
            subject_id=constraint_id,
            subject_content_hash=content_hash,
            action="create",
            scope_hash=_domain_hash("persistmind.policy-scope.v1", {"scope": "workspace"}),
            risk_class=risk,
            quorum=quorum,
            maximum_uses=1,
            issued_at=valid_from,
            expires_at=valid_to,
            nonce=nonce,
            prior_state_hash=_domain_hash("persistmind.policy-state.v1", {"state": None}),
            actor=actor,
        )
        signed = list(approvals or [{"principal": actor, "signature": signature}])
        identities = require_approval_quorum(
            self.runtime.root,
            signed,
            document,
            quorum=quorum,
            allow_test_provider=self._allow_development_driver,
        )
        stored = self.policy.add_safety_constraint(
            {
                **subject,
                "content_hash": content_hash,
                "required_quorum": quorum,
            },
            signatures=signed,
            signer_identities=identities,
            decision_document=document,
        )
        return {
            "ok": True,
            "status": "created",
            "schema_version": "persistmind.policy_safety_constraint.v1",
            "constraint": dict(stored),
            "decision_document": document,
            "signers": identities,
        }

    def safety_check(self, context: Mapping[str, Any]) -> dict[str, Any]:
        now = datetime.now(UTC)
        violations: list[dict[str, Any]] = []
        for constraint in self.policy.safety_constraints():
            if _timestamp(str(constraint["valid_from"])) > now:
                continue
            valid_to = constraint.get("valid_to")
            if valid_to is not None and _timestamp(str(valid_to)) <= now:
                continue
            result = _predicate_matches(constraint["predicate"], context)
            if result is not False:
                violations.append(
                    {
                        "constraint_id": constraint["constraint_id"],
                        "content_hash": constraint["content_hash"],
                        "status": constraint["fail_state"] if result is True else "unknown",
                        "predicate_result": result,
                    }
                )
        status = "safe"
        for candidate in ("unsafe", "not_authorized", "unknown"):
            if any(item["status"] == candidate for item in violations):
                status = candidate
                break
        return {
            "ok": not violations,
            "status": status,
            "schema_version": "persistmind.policy_safety_check.v1",
            "violations": violations,
        }

    def autonomy_grant_issue(
        self,
        grant_id: str,
        *,
        capability: str,
        artifact_version: str,
        scope: Mapping[str, Any],
        maximum_risk: str,
        maximum_uses: int,
        issued_at: str,
        expires_at: str,
        actor: str,
        signature: str,
        nonce: str,
        approvals: list[Mapping[str, str]] | None = None,
    ) -> dict[str, Any]:
        if self.read_only:
            raise PermissionError("autonomy-grant issuance requires Policy authority")
        protected = {
            "policy",
            "audit",
            "evaluator",
            "release_signing",
            "key_management",
            "kill_switch",
        }
        if capability in protected:
            raise PermissionError(f"protected capability cannot be delegated: {capability}")
        risk = _risk(maximum_risk)
        if maximum_uses < 1:
            raise ValueError("autonomy grant requires a positive use ceiling")
        issued = _timestamp(issued_at)
        expiry = _timestamp(expires_at)
        if expiry <= issued or expiry <= datetime.now(UTC):
            raise ValueError("autonomy grant expiry must be in the future")
        _nonce(nonce)
        scope_value = dict(scope)
        scope_hash = _domain_hash("persistmind.policy-scope.v1", scope_value)
        subject = {
            "grant_id": grant_id,
            "capability": capability,
            "artifact_version": artifact_version,
            "scope": scope_value,
            "maximum_risk": risk,
            "maximum_uses": maximum_uses,
            "issued_at": issued_at,
            "expires_at": expires_at,
        }
        content_hash = _domain_hash("persistmind.policy-autonomy-grant.v1", subject)
        quorum = 2 if risk == "critical" else 1
        document = _policy_document(
            subject_type="autonomy_grant",
            subject_id=grant_id,
            subject_content_hash=content_hash,
            action="issue",
            scope_hash=scope_hash,
            risk_class=risk,
            quorum=quorum,
            maximum_uses=maximum_uses,
            issued_at=issued_at,
            expires_at=expires_at,
            nonce=nonce,
            prior_state_hash=_domain_hash("persistmind.policy-state.v1", {"state": None}),
            actor=actor,
            artifact_hash=_domain_hash(
                "persistmind.policy-artifact.v1", {"artifact_version": artifact_version}
            ),
        )
        signed = list(approvals or [{"principal": actor, "signature": signature}])
        identities = require_approval_quorum(
            self.runtime.root,
            signed,
            document,
            quorum=quorum,
            allow_test_provider=self._allow_development_driver,
        )
        stored = self.policy.issue_autonomy_grant(
            {**subject, "required_quorum": quorum},
            signatures=signed,
            signer_identities=identities,
            decision_document=document,
        )
        return {
            "ok": True,
            "status": "active",
            "schema_version": "persistmind.policy_autonomy_grant.v1",
            "grant": dict(stored),
            "decision_document": document,
            "signers": identities,
        }

    def autonomy_grant_check(
        self,
        grant_id: str,
        *,
        task_session_id: str,
        capability: str,
        artifact_version: str,
        risk_class: str,
        action: Mapping[str, Any],
        context: Mapping[str, Any],
    ) -> dict[str, Any]:
        kill = dict(self.control.kill_switch_status())
        if bool(kill.get("active")):
            return _grant_denial(grant_id, "unsafe", "Control kill switch is active")
        grant = self.policy.autonomy_grant(grant_id)
        if grant is None:
            return _grant_denial(grant_id, "not_authorized", "autonomy grant is unknown")
        state = str(grant["state"])
        if state != "active":
            return _grant_denial(grant_id, "not_authorized", f"grant is {state}")
        if _timestamp(str(grant["expires_at"])) <= datetime.now(UTC):
            return _grant_denial(grant_id, "not_authorized", "grant is expired")
        if int(grant["uses"]) >= int(grant["maximum_uses"]):
            return _grant_denial(grant_id, "not_authorized", "grant is exhausted")
        if str(grant["capability"]) != capability:
            return _grant_denial(grant_id, "not_authorized", "capability differs")
        if str(grant["artifact_version"]) != artifact_version:
            return _grant_denial(grant_id, "not_authorized", "artifact version differs")
        if _risk_index(_risk(risk_class)) > _risk_index(str(grant["maximum_risk"])):
            return _grant_denial(grant_id, "unsafe", "action risk exceeds grant ceiling")
        action_context = {**dict(context), "task_session_id": task_session_id}
        if not _scope_allows(grant["scope"], action_context):
            return _grant_denial(grant_id, "not_authorized", "action is outside grant scope")
        safety = self.safety_check({**action_context, **dict(action)})
        if not safety["ok"]:
            return {
                **_grant_denial(
                    grant_id, str(safety["status"]), "safety constraint blocked action"
                ),
                "safety": safety,
            }
        action_hash = _domain_hash("persistmind.task-action.v1", dict(action))
        return {
            "ok": True,
            "status": "authorized",
            "schema_version": "persistmind.policy_autonomy_check.v1",
            "grant_id": grant_id,
            "action_hash": action_hash,
            "remaining_uses": int(grant["maximum_uses"]) - int(grant["uses"]),
            "safety": safety,
        }

    def autonomy_grant_consume(self, grant_id: str, **request: Any) -> dict[str, Any]:
        if self.read_only:
            raise PermissionError("grant consumption requires Policy authority")
        checked = self.autonomy_grant_check(grant_id, **request)
        if not checked["ok"]:
            raise PermissionError(str(checked["reason"]))
        grant = self.policy.consume_autonomy_grant(
            grant_id,
            task_session_id=str(request["task_session_id"]),
            capability=str(request["capability"]),
            action_hash=str(checked["action_hash"]),
        )
        return {**checked, "status": "consumed", "grant": dict(grant)}

    def autonomy_grant_transition(
        self,
        grant_id: str,
        *,
        to_state: str,
        actor: str,
        reason: str,
        signature: str,
        issued_at: str,
        nonce: str,
        approvals: list[Mapping[str, str]] | None = None,
    ) -> dict[str, Any]:
        if self.read_only:
            raise PermissionError("grant transition requires Policy authority")
        grant = self.policy.autonomy_grant(grant_id)
        if grant is None:
            raise KeyError(f"unknown autonomy grant: {grant_id}")
        if to_state not in {"active", "suspended", "revoked", "expired", "exhausted"}:
            raise ValueError("invalid grant transition state")
        _timestamp(issued_at)
        _nonce(nonce)
        quorum = 2 if to_state == "active" or str(grant["maximum_risk"]) == "critical" else 1
        prior_hash = _domain_hash(
            "persistmind.policy-state.v1",
            {
                "grant_id": grant_id,
                "state": grant["state"],
                "transition": grant.get("latest_transition"),
            },
        )
        document = _policy_document(
            subject_type="autonomy_grant_transition",
            subject_id=grant_id,
            subject_content_hash=_domain_hash("persistmind.policy-autonomy-grant.v1", grant),
            action=to_state,
            scope_hash=_domain_hash("persistmind.policy-scope.v1", grant["scope"]),
            risk_class=str(grant["maximum_risk"]),
            quorum=quorum,
            maximum_uses=int(grant["maximum_uses"]),
            issued_at=issued_at,
            expires_at=str(grant["expires_at"]),
            nonce=nonce,
            prior_state_hash=prior_hash,
            actor=actor,
        )
        signed = list(approvals or [{"principal": actor, "signature": signature}])
        identities = require_approval_quorum(
            self.runtime.root,
            signed,
            document,
            quorum=quorum,
            allow_test_provider=self._allow_development_driver,
        )
        stored = self.policy.transition_autonomy_grant(
            grant_id,
            to_state=to_state,
            actor=actor,
            reason=reason,
            signatures=signed,
            signer_identities=identities,
            decision_document=document,
        )
        return {
            "ok": True,
            "status": to_state,
            "schema_version": "persistmind.policy_autonomy_grant_transition.v1",
            "grant": dict(stored),
            "decision_document": document,
            "signers": identities,
        }

    def decision(self, decision_id: str) -> dict[str, Any] | None:
        result = self.policy.action_decision(decision_id)
        return dict(result) if result is not None else None

    def policy_applicable(self, scope: str | None = None) -> dict[str, Any]:
        requested = (scope or "global").strip() or "global"
        policies = [dict(item) for item in self.policy.applicable_policy({"scope": requested})]
        return {
            "ok": True,
            "schema_version": "persistmind.policy_applicable.v1",
            "scope": requested,
            "policies": policies,
        }


_RISKS = ("low", "medium", "high", "critical")


def _risk(value: str) -> str:
    normalized = value.strip().lower()
    if normalized not in _RISKS:
        raise ValueError(f"invalid risk class: {value}")
    return normalized


def _risk_index(value: str) -> int:
    return _RISKS.index(_risk(value))


def _timestamp(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("Policy timestamps must include a timezone")
    return parsed.astimezone(UTC)


def _nonce(value: str) -> None:
    normalized = value.removeprefix("0x")
    if re.fullmatch(r"[0-9a-fA-F]{64}", normalized) is None:
        raise ValueError("Policy decision nonce must be exactly 256 bits of hexadecimal")


def _domain_hash(domain: str, value: Mapping[str, Any]) -> str:
    material = domain + "\x00" + canonical_json(dict(value))
    return "sha256:" + hashlib.sha256(material.encode("utf-8")).hexdigest()


def _policy_document(
    *,
    subject_type: str,
    subject_id: str,
    subject_content_hash: str,
    action: str,
    scope_hash: str,
    risk_class: str,
    quorum: int,
    maximum_uses: int,
    issued_at: str,
    expires_at: str | None,
    nonce: str,
    prior_state_hash: str,
    actor: str,
    artifact_hash: str | None = None,
) -> dict[str, Any]:
    return {
        "schema_version": "persistmind.policy-decision.v2",
        "domain": "persistmind.policy-decision.v2",
        "subject_type": subject_type,
        "subject_id": subject_id,
        "subject_content_hash": subject_content_hash,
        "action": action,
        "scope_hash": scope_hash,
        "artifact_hash": artifact_hash,
        "protocol_hash": None,
        "evaluator_hash": None,
        "risk_class": risk_class,
        "required_quorum": quorum,
        "maximum_uses": maximum_uses,
        "issued_at": issued_at,
        "expires_at": expires_at,
        "nonce": nonce.lower().removeprefix("0x"),
        "prior_state_hash": prior_state_hash,
        "actor": actor,
    }


def _lookup(context: Mapping[str, Any], path: str) -> tuple[bool, Any]:
    value: Any = context
    for part in path.split("."):
        if not isinstance(value, Mapping) or part not in value:
            return False, None
        value = value[part]
    return True, value


def _predicate_matches(predicate: Mapping[str, Any], context: Mapping[str, Any]) -> bool | None:
    if set(predicate) == {"all"}:
        results = [_predicate_matches(item, context) for item in predicate["all"]]
        return False if False in results else None if None in results else True
    if set(predicate) == {"any"}:
        results = [_predicate_matches(item, context) for item in predicate["any"]]
        return True if True in results else None if None in results else False
    if set(predicate) == {"not"}:
        result = _predicate_matches(predicate["not"], context)
        return None if result is None else not result
    field = predicate.get("field")
    operation = predicate.get("op", "eq")
    if not isinstance(field, str):
        return None
    found, actual = _lookup(context, field)
    if not found:
        return None
    expected = predicate.get("value")
    if operation == "eq":
        return actual == expected
    if operation == "ne":
        return actual != expected
    if operation == "in" and isinstance(expected, list):
        return actual in expected
    if operation == "contains" and isinstance(actual, (list, str)):
        return expected in actual
    if operation == "matches" and isinstance(actual, str) and isinstance(expected, str):
        return fnmatch.fnmatchcase(actual, expected)
    if operation == "risk_at_least" and isinstance(actual, str) and isinstance(expected, str):
        try:
            return _risk_index(actual) >= _risk_index(expected)
        except ValueError:
            return None
    return None


def _scope_allows(scope: Mapping[str, Any], context: Mapping[str, Any]) -> bool:
    for key, expected in scope.items():
        if key == "path_globs":
            path = context.get("path")
            if not isinstance(path, str) or not isinstance(expected, list):
                return False
            if not any(fnmatch.fnmatchcase(path, str(pattern)) for pattern in expected):
                return False
        elif key in {"actions", "tools", "network_hosts"}:
            singular = {"actions": "action", "tools": "tool", "network_hosts": "network_host"}[key]
            actual = context.get(singular)
            if not isinstance(expected, list) or actual not in expected:
                return False
        elif context.get(key) != expected:
            return False
    return True


def _grant_denial(grant_id: str, status: str, reason: str) -> dict[str, Any]:
    return {
        "ok": False,
        "status": status,
        "schema_version": "persistmind.policy_autonomy_check.v1",
        "grant_id": grant_id,
        "reason": reason,
    }


def _staged_paths(repo_root: Path) -> list[str]:
    result = subprocess.run(
        ["git", "diff", "--cached", "--name-only", "-z"],
        cwd=repo_root,
        check=False,
        capture_output=True,
    )
    if result.returncode != 0:
        return []
    return sorted(
        {
            item.decode("utf-8", errors="replace").replace("\\", "/")
            for item in result.stdout.split(b"\0")
            if item
        }
    )
