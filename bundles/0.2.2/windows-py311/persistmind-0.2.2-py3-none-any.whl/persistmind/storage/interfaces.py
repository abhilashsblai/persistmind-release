from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable

from .descriptors import (
    ConsistencyWatermark,
    StorageDomain,
    StoreDescriptor,
    StoreRole,
    TopologyManifest,
)


@dataclass(frozen=True, slots=True)
class RoutePlan:
    """A bounded, explainable route selected by logical ownership and role."""

    domain: StorageDomain
    operation: str
    roles: tuple[StoreRole, ...]
    stores: tuple[DomainStore, ...]
    consistency: str = "fail_if_stale"


@runtime_checkable
class DomainStore(Protocol):
    @property
    def descriptor(self) -> StoreDescriptor: ...

    def get(self, record_id: str) -> Mapping[str, Any] | None: ...

    def put(self, record: Mapping[str, Any], *, idempotency_key: str | None = None) -> str: ...

    def search(self, query: str, *, limit: int = 20) -> Sequence[Mapping[str, Any]]: ...

    def revision(self) -> int: ...

    def health(self) -> Mapping[str, Any]: ...

    def verify_integrity(self, *, full: bool = False) -> Mapping[str, Any]: ...

    def reconciliation_health(self) -> Mapping[str, Any]: ...

    def close(self) -> None: ...


class SourceIntelligenceStore(DomainStore, Protocol):
    def resolve_evidence(self, locator: Mapping[str, Any]) -> Mapping[str, Any] | None: ...

    def rebuild(self, manifest: Mapping[str, Any]) -> Mapping[str, Any]: ...


class TaskStateStore(DomainStore, Protocol):
    def create_session(
        self,
        task_session_id: str,
        *,
        state: str,
        payload: Mapping[str, Any],
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]: ...

    def transition(
        self,
        task_session_id: str,
        *,
        to_state: str,
        payload: Mapping[str, Any],
        expected_revision: int,
        transition_id: str,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]: ...

    def write_plan(
        self,
        plan_id: str,
        *,
        task_session_id: str,
        status: str,
        payload: Mapping[str, Any],
        expected_revision: int | None = None,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]: ...

    def create_plan_checkpoint(
        self,
        checkpoint_id: str,
        *,
        plan_id: str,
        task_session_id: str,
        payload: Mapping[str, Any],
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]: ...

    def rebind_pack(
        self,
        task_session_id: str,
        *,
        pack_id: str,
        expected_revision: int,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]: ...

    def active_continuation(self, task_session_id: str) -> Mapping[str, Any] | None: ...

    def upsert_continuation(
        self,
        continuation_id: str,
        *,
        task_session_id: str,
        task_hash: str,
        status: str,
        payload: Mapping[str, Any],
        expected_revision: int | None = None,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]: ...

    def continuation(self, continuation_id: str) -> Mapping[str, Any] | None: ...

    def continuations(
        self, *, status: str | None = None, limit: int = 20
    ) -> Sequence[Mapping[str, Any]]: ...

    def acquire_lease(
        self,
        lease_name: str,
        *,
        owner: str,
        token: str,
        owner_boot_id: str,
        owner_nonce: str,
        duration_ms: int = 30_000,
        recovery_proof: Mapping[str, Any] | None = None,
    ) -> Mapping[str, Any]: ...

    def heartbeat_lease(
        self,
        lease_name: str,
        *,
        token: str,
        fencing_token: int,
        duration_ms: int = 30_000,
    ) -> Mapping[str, Any]: ...

    def release_lease(self, lease_name: str, *, token: str, fencing_token: int) -> bool: ...

    def compare_and_swap(
        self, record_id: str, expected_revision: int, value: Mapping[str, Any]
    ) -> bool: ...


class TaskQueryStore(DomainStore, Protocol):
    def session(self, task_session_id: str) -> Mapping[str, Any] | None: ...

    def transitions(self, task_session_id: str) -> Sequence[Mapping[str, Any]]: ...

    def plan(self, plan_id: str) -> Mapping[str, Any] | None: ...

    def plan_revisions(self, plan_id: str) -> Sequence[Mapping[str, Any]]: ...

    def checkpoints(self, plan_id: str) -> Sequence[Mapping[str, Any]]: ...


class ActivityStore(DomainStore, Protocol):
    def append(self, event: Mapping[str, Any], *, idempotency_key: str) -> str: ...

    def seal_partition(self) -> Mapping[str, Any]: ...


class AuditStore(DomainStore, Protocol):
    def append_audit(self, record: Mapping[str, Any], *, idempotency_key: str) -> str: ...

    def anchor_partition(
        self, partition_id: str, *, signature: str, principal: str
    ) -> Mapping[str, Any]: ...

    def latest(self, correlation_id: str) -> Mapping[str, Any] | None: ...

    def verify_chain(self) -> Mapping[str, Any]: ...

    def tip(self) -> Mapping[str, Any]: ...


class KnowledgeStore(DomainStore, Protocol):
    def evidence(self, record_id: str) -> Sequence[Mapping[str, Any]]: ...

    def put_evidence(
        self,
        record_id: str,
        locator: Mapping[str, Any],
        *,
        content_hash: str,
        trust: str,
    ) -> str: ...

    def memory_records(
        self,
        *,
        status: str | None = None,
        types: Sequence[str] | None = None,
        limit: int = 1000,
    ) -> Sequence[Mapping[str, Any]]: ...

    def memory_fts_search(
        self,
        query: str,
        *,
        status: str | None = None,
        types: Sequence[str] | None = None,
        limit: int = 100,
    ) -> Sequence[Mapping[str, Any]]: ...

    def memory_revisions(self, record_id: str) -> Sequence[Mapping[str, Any]]: ...

    def memory_transitions(self, record_id: str) -> Sequence[Mapping[str, Any]]: ...

    def write_memory_record(
        self,
        record: Mapping[str, Any],
        *,
        actor: str,
        reason: str,
        decision_document_hash: str,
        expected_revision: int | None = None,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]: ...


class PolicyAuthorityStore(DomainStore, Protocol):
    def applicable_policy(self, context: Mapping[str, Any]) -> Sequence[Mapping[str, Any]]: ...

    def approve_policy(
        self,
        policy: Mapping[str, Any],
        *,
        approver: str,
        signature: str,
        signer_identity: Mapping[str, str],
        decision_document: Mapping[str, Any],
    ) -> str: ...

    def policy(self, policy_id: str) -> Mapping[str, Any] | None: ...

    def policies(
        self, *, status: str | None = None, limit: int = 1000
    ) -> Sequence[Mapping[str, Any]]: ...

    def approve_experiment(
        self,
        approval: Mapping[str, Any],
        *,
        signatures: Sequence[Mapping[str, str]],
        signer_identities: Sequence[Mapping[str, str]],
        decision_document: Mapping[str, Any],
    ) -> Mapping[str, Any]: ...

    def experiment_approval(self, experiment_id: str) -> Mapping[str, Any] | None: ...

    def record_experiment_assignment(self, assignment: Mapping[str, Any]) -> Mapping[str, Any]: ...

    def experiment_assignment(
        self, experiment_id: str, assignment_unit_id: str
    ) -> Mapping[str, Any] | None: ...

    def set_policy_status(
        self,
        policy_id: str,
        *,
        status: str,
        actor: str,
        reason: str,
        signature: str,
        signer_identity: Mapping[str, str],
        decision_document: Mapping[str, Any],
    ) -> Mapping[str, Any] | None: ...


class LearningStore(DomainStore, Protocol):
    def register_version(
        self,
        version: Mapping[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]: ...

    def version(self, version_id: str) -> Mapping[str, Any] | None: ...

    def versions(
        self, *, skill_id: str | None = None, limit: int = 1000
    ) -> Sequence[Mapping[str, Any]]: ...

    def record_evaluation(self, evaluation: Mapping[str, Any]) -> Mapping[str, Any]: ...

    def evaluations(self, version_id: str) -> Sequence[Mapping[str, Any]]: ...

    def active_manifest(self) -> Mapping[str, Any]: ...

    def promote(self, version_id: str, *, approval: Mapping[str, Any]) -> Mapping[str, Any]: ...

    def rollback(self, version_id: str, *, approval: Mapping[str, Any]) -> Mapping[str, Any]: ...


class CatalogStore(Protocol):
    def current(self) -> TopologyManifest: ...

    def activate(self, manifest: TopologyManifest, *, expected_generation: int) -> None: ...


class ArtifactStore(Protocol):
    def put(self, payload: bytes, *, classification: str = "internal") -> str: ...

    def get(self, reference: str) -> bytes: ...

    def verify(self, reference: str) -> bool: ...


class FederatedStorage(Protocol):
    def watermark(self) -> ConsistencyWatermark: ...
