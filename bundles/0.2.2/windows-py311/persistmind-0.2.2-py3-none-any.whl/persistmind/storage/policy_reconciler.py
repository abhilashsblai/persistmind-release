from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from persistmind.application.execution_scope import OperationExecutionScope, bind_operation_scope
from persistmind.application.registry import OperationMode
from persistmind.config import load_settings
from persistmind.utils import utc_now

from .adapters.sqlite_learning import SQLiteLearningStore
from .adapters.sqlite_policy import SQLitePolicyStore
from .adapters.sqlite_activity import SQLiteAuditStore
from .descriptors import StoreRole
from .runtime import StorageOpenIntent, StorageRuntime, resolve_runtime_store


class PolicyProjectionReconciler:
    """Apply Policy outbox events through payload-hash checked owner receipts."""

    CONSUMER_ID = "learning.policy_decision.v1"
    HANDLER_VERSION = "v1"
    AUDIT_CONSUMER_ID = "audit.policy_decision.v1"

    def __init__(self, repo_root: Path, *, allow_development_driver: bool = False) -> None:
        self.repo_root = repo_root.resolve()
        self.workspace_root = self.repo_root / load_settings(self.repo_root).toolchain.workspace_dir
        self.allow_development_driver = allow_development_driver

    def apply_learning_decision(self, event_id: str) -> dict[str, Any]:
        event = self._read_policy_event(event_id, expected_type="policy.action_decided.v1")
        payload_json = str(event["payload_json"])
        payload_hash = str(event["payload_hash"])
        observed_hash = hashlib.sha256(payload_json.encode("utf-8")).hexdigest()
        if observed_hash != payload_hash:
            raise RuntimeError("Policy outbox payload hash does not verify")
        payload = json.loads(payload_json)
        scope = OperationExecutionScope(
            operation_id="policy_decision_projection",
            mode=OperationMode.COMMAND,
            roles=frozenset({StoreRole.LEARNING.value}),
            scope_policy="workspace",
        )
        with (
            bind_operation_scope(scope),
            StorageRuntime.open(
                self.workspace_root,
                intent=StorageOpenIntent.REQUIRE_INITIALIZED,
                allow_development_driver=self.allow_development_driver,
                required_roles=frozenset({StoreRole.LEARNING}),
            ) as runtime,
        ):
            store = resolve_runtime_store(runtime, StoreRole.LEARNING, read_only=False)
            if not isinstance(store, SQLiteLearningStore):
                raise RuntimeError("Learning projection route is unavailable")
            with store._write_lock, store.connection:
                receipt = store.connection.execute(
                    "SELECT payload_hash,status FROM domain_consumer_receipts "
                    "WHERE consumer_id=? AND event_id=?",
                    (self.CONSUMER_ID, event_id),
                ).fetchone()
                if receipt is not None:
                    if str(receipt["payload_hash"]) != payload_hash:
                        raise RuntimeError("Policy projection receipt payload hash differs")
                    return {
                        "ok": True,
                        "status": "duplicate",
                        "event_id": event_id,
                        "payload_hash": payload_hash,
                    }
                cursor = store.connection.execute(
                    "UPDATE learning_action_proposals SET state=?,policy_decision_id=?,"
                    "decided_at=?,updated_at=? WHERE proposal_id=? AND state='policy_pending'",
                    (
                        str(payload["decision"]),
                        str(payload["decision_id"]),
                        utc_now(),
                        utc_now(),
                        str(payload["proposal_id"]),
                    ),
                )
                if cursor.rowcount not in {0, 1}:
                    raise RuntimeError("Policy projection updated an unexpected row count")
                store.connection.execute(
                    "INSERT INTO domain_consumer_receipts VALUES(?,?,?,?,?,?)",
                    (
                        self.CONSUMER_ID,
                        event_id,
                        payload_hash,
                        self.HANDLER_VERSION,
                        "applied",
                        utc_now(),
                    ),
                )
                store.connection.execute(
                    "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
                )
        return {
            "ok": True,
            "status": "applied",
            "event_id": event_id,
            "payload_hash": payload_hash,
        }

    def apply_audit_decision(self, event_id: str) -> dict[str, Any]:
        event = self._read_policy_event(event_id)
        payload_json = str(event["payload_json"])
        payload_hash = str(event["payload_hash"])
        if hashlib.sha256(payload_json.encode("utf-8")).hexdigest() != payload_hash:
            raise RuntimeError("Policy audit payload hash does not verify")
        payload = json.loads(payload_json)
        scope = OperationExecutionScope(
            operation_id="policy_audit_projection",
            mode=OperationMode.COMMAND,
            roles=frozenset({StoreRole.AUDIT_ACTIVE.value}),
            scope_policy="workspace",
        )
        with (
            bind_operation_scope(scope),
            StorageRuntime.open(
                self.workspace_root,
                intent=StorageOpenIntent.REQUIRE_INITIALIZED,
                allow_development_driver=self.allow_development_driver,
                required_roles=frozenset({StoreRole.AUDIT_ACTIVE}),
            ) as runtime,
        ):
            store = resolve_runtime_store(runtime, StoreRole.AUDIT_ACTIVE, read_only=False)
            if not isinstance(store, SQLiteAuditStore):
                raise RuntimeError("Audit projection route is unavailable")
            receipt = (
                store._reader()
                .execute(
                    "SELECT payload_hash FROM domain_consumer_receipts "
                    "WHERE consumer_id=? AND event_id=?",
                    (self.AUDIT_CONSUMER_ID, event_id),
                )
                .fetchone()
            )
            if receipt is not None:
                if str(receipt["payload_hash"]) != payload_hash:
                    raise RuntimeError("Policy audit receipt payload hash differs")
                return {"ok": True, "status": "duplicate", "event_id": event_id}
            store.append_audit(
                {
                    "audit_id": event_id,
                    "correlation_id": str(event["aggregate_id"]),
                    "kind": str(event["event_type"]),
                    "principal": str(payload.get("principal") or "policy"),
                    "payload": payload,
                },
                idempotency_key=f"policy-audit:{event_id}",
            )
            with store._write_lock, store.connection:
                store.connection.execute(
                    "INSERT OR IGNORE INTO domain_consumer_receipts VALUES(?,?,?,?,?,?)",
                    (
                        self.AUDIT_CONSUMER_ID,
                        event_id,
                        payload_hash,
                        self.HANDLER_VERSION,
                        "applied",
                        utc_now(),
                    ),
                )
        return {"ok": True, "status": "applied", "event_id": event_id}

    def reconcile(self, *, limit: int = 100) -> dict[str, Any]:
        event_ids = self._pending_event_ids(limit=max(1, min(int(limit), 10_000)))
        applied = 0
        duplicates = 0
        errors: list[dict[str, str]] = []
        for event_id, event_type in event_ids:
            try:
                results = [self.apply_audit_decision(event_id)]
                if event_type == "policy.action_decided.v1":
                    results.append(self.apply_learning_decision(event_id))
                duplicates += sum(item.get("status") == "duplicate" for item in results)
                self._mark_published(event_id)
                applied += 1
            except Exception as exc:  # noqa: BLE001 - reconciliation returns typed failures.
                errors.append(
                    {
                        "event_id": event_id,
                        "error_type": type(exc).__name__,
                        "error": str(exc),
                    }
                )
        return {
            "ok": not errors,
            "scanned": len(event_ids),
            "applied": applied,
            "duplicates": duplicates,
            "failed": len(errors),
            "errors": errors,
        }

    def _pending_event_ids(self, *, limit: int) -> list[tuple[str, str]]:
        with StorageRuntime.open(
            self.workspace_root,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=self.allow_development_driver,
            read_only=True,
            required_roles=frozenset({StoreRole.POLICY}),
        ) as runtime:
            store = resolve_runtime_store(runtime, StoreRole.POLICY, read_only=True)
            if not isinstance(store, SQLitePolicyStore):
                raise RuntimeError("Policy projection source is unavailable")
            rows = (
                store._reader()
                .execute(
                    "SELECT event_id,event_type FROM domain_outbox "
                    "WHERE published_at IS NULL ORDER BY occurred_at,event_id LIMIT ?",
                    (limit,),
                )
                .fetchall()
            )
            return [(str(row["event_id"]), str(row["event_type"])) for row in rows]

    def _mark_published(self, event_id: str) -> None:
        with StorageRuntime.open(
            self.workspace_root,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=self.allow_development_driver,
            required_roles=frozenset({StoreRole.POLICY}),
        ) as runtime:
            store = resolve_runtime_store(runtime, StoreRole.POLICY, read_only=False)
            if not isinstance(store, SQLitePolicyStore):
                raise RuntimeError("Policy projection source is unavailable")
            with store._write_lock, store.connection:
                store.connection.execute(
                    "UPDATE domain_outbox SET published_at=? WHERE event_id=?",
                    (utc_now(), event_id),
                )

    def _read_policy_event(
        self, event_id: str, *, expected_type: str | None = None
    ) -> dict[str, Any]:
        with StorageRuntime.open(
            self.workspace_root,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=self.allow_development_driver,
            read_only=True,
            required_roles=frozenset({StoreRole.POLICY}),
        ) as runtime:
            store = resolve_runtime_store(runtime, StoreRole.POLICY, read_only=True)
            if not isinstance(store, SQLitePolicyStore):
                raise RuntimeError("Policy projection source is unavailable")
            row = (
                store._reader()
                .execute(
                    "SELECT * FROM domain_outbox WHERE event_id=?",
                    (event_id,),
                )
                .fetchone()
            )
            if row is None:
                raise KeyError(f"unknown Policy outbox event: {event_id}")
            if expected_type and str(row["event_type"]) != expected_type:
                raise ValueError(f"unexpected Policy event type: {row['event_type']}")
            return dict(row)


__all__ = ["PolicyProjectionReconciler"]
