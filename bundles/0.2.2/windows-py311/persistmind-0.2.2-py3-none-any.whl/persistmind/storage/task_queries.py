from __future__ import annotations

from pathlib import Path
from typing import Any, cast

from persistmind.config import load_settings

from .descriptors import StoreRole
from .interfaces import TaskQueryStore
from .runtime import StorageOpenIntent, StorageRuntime, resolve_runtime_store
from .task_chain import verify_transition_chain as _verify_transition_chain


class TaskQueryService:
    """Task-only read model; it cannot construct a writer or another authority."""

    def __init__(
        self, repo_root: Path, *, allow_development_driver: bool = False, read_only: bool = True
    ) -> None:
        if not read_only:
            raise ValueError("TaskQueryService is read-only")
        self.repo_root = repo_root.resolve()
        settings = load_settings(self.repo_root)
        self.runtime = StorageRuntime.open(
            self.repo_root / settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=allow_development_driver,
            read_only=True,
            required_roles=frozenset({StoreRole.TASK_STATE}),
        )
        store = resolve_runtime_store(self.runtime, StoreRole.TASK_STATE, read_only=True)
        if not all(
            callable(getattr(store, name, None))
            for name in ("session", "transitions", "plan", "plan_revisions", "checkpoints")
        ):
            raise RuntimeError("Task query route is unavailable")
        self.store = cast(TaskQueryStore, store)

    def close(self) -> None:
        self.runtime.close()

    def __enter__(self) -> TaskQueryService:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def task_show(self, task_session_id: str) -> dict[str, Any]:
        session = self.store.session(task_session_id)
        if session is None:
            return {
                "ok": False,
                "error": "task session not found",
                "task_session_id": task_session_id,
            }
        transitions = [dict(item) for item in self.store.transitions(task_session_id)]
        chain = _verify_transition_chain(task_session_id, transitions)
        metadata = {
            key: value
            for key, value in dict(session).items()
            if key not in {"task_session_id", "state", "revision", "created_at", "updated_at"}
        }
        return {
            "ok": bool(chain["ok"]),
            "status": "ok" if chain["ok"] else "task_history_invalid",
            "schema_version": "persistmind.task_show.v1",
            "session": {**dict(session), "current_state": session["state"], "metadata": metadata},
            "transitions": transitions,
            "chain": chain,
            "nextgen_v1": True,
        }

    def plan_show(self, plan_id: str) -> dict[str, Any]:
        plan = self.store.plan(plan_id)
        if plan is None:
            return {"ok": False, "error": "task plan not found", "plan_id": plan_id}
        return {
            "ok": True,
            "schema_version": "persistmind.task_plan_show.v1",
            "plan": plan,
            "revisions": list(self.store.plan_revisions(plan_id)),
            "checkpoints": list(self.store.checkpoints(plan_id)),
            "nextgen_v1": True,
        }


def execute_task_query(repo_root: Path, operation: str, identifier: str | None) -> dict[str, Any]:
    """CLI boundary helper that preserves the catalog and read-only Task path."""
    if not identifier:
        raise ValueError(
            f"{operation} show requires {'task_session_id' if operation == 'task' else 'plan_id'}"
        )
    from persistmind.composition.registry import OperationRegistry

    operation_id = "task_show" if operation == "task" else "plan_show"
    return OperationRegistry(repo_root, force_read_only=True).invoke(
        operation_id,
        {"operation_id": operation_id, "args": [identifier]},
    )


__all__ = ["TaskQueryService", "execute_task_query"]
