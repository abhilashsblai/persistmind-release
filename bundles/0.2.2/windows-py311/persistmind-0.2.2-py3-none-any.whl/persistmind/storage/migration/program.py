from __future__ import annotations

import base64
import hashlib
import json
import sqlite3
from collections.abc import Mapping
from contextlib import closing
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from ..bootstrap import bootstrap_nextgen
from ..catalog import FileCatalog
from ..descriptors import StoreRole
from .backup import BackupManifest, create_backup, restore_backup
from .inventory import inventory
from .planner import MigrationPlan, build_plan
from .verify import table_digest


@dataclass(frozen=True, slots=True)
class MigrationResult:
    migration_id: str
    source_format: str
    source_fingerprint: str
    plan_hash: str
    backup: BackupManifest
    restore_drill: str
    archived_tables: int
    archived_rows: int
    rebuilt_objects: int
    transformed_rows: int
    target_generation: int
    report_path: str
    completed_at: str


class OfflineWorkspaceMigrator:
    """One-way, restartable old-workspace reader isolated from the application runtime."""

    def __init__(self, source_path: Path, target_root: Path) -> None:
        self.source_path = source_path.resolve()
        self.target_root = target_root.resolve()

    def source_fingerprint(self) -> str:
        values = {
            path.relative_to(self.source_path).as_posix()
            if self.source_path.is_dir()
            else path.name: _database_fingerprint(path)
            for path in self._source_files()
        }
        return hashlib.sha256(
            json.dumps(values, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()

    def plan(self) -> MigrationPlan:
        ownership = _ownership_map()
        plans: list[MigrationPlan] = []
        for source_file in self._source_files():
            with closing(self._source(source_file)) as connection:
                objects = inventory(connection)
            for item in objects:
                if item.object_type == "table" and item.name not in ownership:
                    ownership[item.name] = {
                        "canonical_domain": _infer_domain(item.name),
                        "migration_disposition": "rebuild"
                        if _is_rebuildable(item.name)
                        else "copy",
                    }
            plans.append(build_plan(objects, ownership, source_bytes=source_file.stat().st_size))
        units = tuple(unit for plan in plans for unit in plan.units)
        payload = [asdict(unit) for unit in units]
        plan_hash = hashlib.sha256(
            json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        estimated = sum(item.estimated_bytes for item in plans)
        return MigrationPlan(units, estimated, int(estimated * 1.25), plan_hash)

    def _source_files(self) -> tuple[Path, ...]:
        if self.source_path.is_file():
            return (self.source_path,)
        if not self.source_path.is_dir():
            raise FileNotFoundError(self.source_path)
        files = tuple(
            sorted(
                path
                for path in self.source_path.rglob("*.db")
                if path.is_file() and self.target_root not in path.parents
            )
        )
        if not files:
            raise FileNotFoundError(f"no SQLite authority files under {self.source_path}")
        return files

    def migrate(
        self,
        *,
        migration_id: str,
        allow_development_driver: bool = False,
    ) -> MigrationResult:
        source_files = self._source_files()
        if (self.target_root / "catalog" / "current.json").exists():
            raise FileExistsError("target workspace is already active")
        plan = self.plan()
        fingerprint = self.source_fingerprint()
        evidence = self.target_root / "migration" / migration_id
        evidence.mkdir(parents=True, exist_ok=True)
        backups: list[BackupManifest] = []
        restore_paths: list[Path] = []
        for ordinal, source_file in enumerate(source_files, 1):
            safe_name = f"{ordinal:03d}-{source_file.stem}"
            backup_item = create_backup(source_file, evidence / "backups" / f"{safe_name}.db")
            restore_path = evidence / "restore-drill" / f"{safe_name}.db"
            restore_backup(backup_item, restore_path)
            if _database_fingerprint(restore_path) != _database_fingerprint(
                Path(backup_item.image)
            ):
                raise RuntimeError(f"migration restore drill semantic mismatch: {source_file}")
            backups.append(backup_item)
            restore_paths.append(restore_path)
        backup = backups[0]

        topology = bootstrap_nextgen(
            self.target_root,
            activate=False,
            allow_development_driver=allow_development_driver,
            project_state_protocol=2,
        )
        catalog = FileCatalog(self.target_root / "catalog")
        targets = {
            descriptor.domain.value: catalog.resolve_location(descriptor.location)
            for descriptor in topology.stores
            if descriptor.store_role is not StoreRole.SOURCE_SEGMENT
        }
        archived_tables = archived_rows = rebuilt = transformed = 0
        parity: list[dict[str, Any]] = []
        ownership = _ownership_map()
        for source_file in source_files:
            with closing(self._source(source_file)) as source:
                objects = inventory(source)
                for item in objects:
                    if item.object_type == "table" and item.name not in ownership:
                        ownership[item.name] = {
                            "canonical_domain": _infer_domain(item.name),
                            "migration_disposition": "rebuild"
                            if _is_rebuildable(item.name)
                            else "copy",
                        }
                source_plan = build_plan(
                    objects, ownership, source_bytes=source_file.stat().st_size
                )
                for unit in source_plan.units:
                    qualified_name = (
                        unit.source_object
                        if len(source_files) == 1
                        else f"{source_file.stem}:{unit.source_object}"
                    )
                    if unit.disposition != "copy":
                        rebuilt += 1
                        parity.append(
                            {
                                "source_database": str(source_file),
                                "source_table": unit.source_object,
                                "disposition": "rebuild",
                                "rows": unit.source_rows,
                            }
                        )
                        continue
                    domain = (
                        unit.domain if unit.domain in targets else _infer_domain(unit.source_object)
                    )
                    target_path = targets[domain]
                    count, digest = _archive_table(
                        source,
                        target_path,
                        migration_id=migration_id,
                        source_table=unit.source_object,
                        archive_name=qualified_name,
                    )
                    archived_tables += 1
                    archived_rows += count
                    parity.append(
                        {
                            "source_database": str(source_file),
                            "source_table": unit.source_object,
                            "target_domain": domain,
                            "disposition": "archive",
                            "source_rows": unit.source_rows,
                            "target_rows": count,
                            "semantic_hash": digest,
                            "ok": count == unit.source_rows,
                        }
                    )
                    if count != unit.source_rows:
                        raise RuntimeError(
                            f"migration row-count mismatch for {qualified_name}: "
                            f"source={unit.source_rows} target={count}"
                        )
                transformed += _project_active_records(source, targets)

        if self.source_fingerprint() != fingerprint:
            raise RuntimeError("migration source changed while the offline copy was running")
        control = sqlite3.connect(targets["control"])
        try:
            now = _now()
            with control:
                control.execute(
                    "INSERT OR REPLACE INTO migration_runs("
                    "migration_id,source_fingerprint,target_topology,phase,state,"
                    "report_ref,started_at,updated_at,completed_at) VALUES(?,?,?,?,?,?,?,?,?)",
                    (
                        migration_id,
                        fingerprint,
                        topology.topology_id,
                        "activation",
                        "complete",
                        str(evidence / "report.json"),
                        now,
                        now,
                        now,
                    ),
                )
        finally:
            control.close()

        active = catalog.initialize(topology)
        report = {
            "schema_version": "persistmind.migration_report.v1",
            "migration_id": migration_id,
            "source_format": "legacy-workspace",
            "source_fingerprint": fingerprint,
            "plan_hash": plan.plan_hash,
            "parity": parity,
            "source_databases": [str(path) for path in source_files],
            "backups": [asdict(item) for item in backups],
            "archived_tables": archived_tables,
            "archived_rows": archived_rows,
            "rebuilt_objects": rebuilt,
            "transformed_rows": transformed,
            "unsupported": [],
            "loss": [],
            "target_generation": active.generation,
        }
        report_path = evidence / "report.json"
        report_path.write_text(
            json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        return MigrationResult(
            migration_id=migration_id,
            source_format="legacy-workspace",
            source_fingerprint=fingerprint,
            plan_hash=plan.plan_hash,
            backup=backup,
            restore_drill=str(restore_paths[0]),
            archived_tables=archived_tables,
            archived_rows=archived_rows,
            rebuilt_objects=rebuilt,
            transformed_rows=transformed,
            target_generation=active.generation,
            report_path=str(report_path),
            completed_at=_now(),
        )

    def _source(self, source_path: Path) -> sqlite3.Connection:
        connection = sqlite3.connect(f"file:{source_path.as_posix()}?mode=ro&immutable=1", uri=True)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA query_only=ON")
        return connection


def migrate_document(result: MigrationResult) -> dict[str, Any]:
    value = asdict(result)
    value["backup"] = asdict(result.backup)
    return value


def _archive_table(
    source: sqlite3.Connection,
    target_path: Path,
    *,
    migration_id: str,
    source_table: str,
    archive_name: str | None = None,
) -> tuple[int, str]:
    target = sqlite3.connect(target_path)
    digest = hashlib.sha256()
    count = 0
    try:
        rows = source.execute(f'SELECT * FROM "{source_table}" ORDER BY rowid')
        with target:
            target.execute(
                "DELETE FROM migration_archive_records WHERE migration_id=? AND source_table=?",
                (migration_id, archive_name or source_table),
            )
            for count, row in enumerate(rows, 1):
                record = {key: _json_value(row[key]) for key in row.keys()}
                encoded = json.dumps(record, sort_keys=True, separators=(",", ":"))
                row_hash = hashlib.sha256(encoded.encode()).hexdigest()
                digest.update(row_hash.encode())
                target.execute(
                    "INSERT INTO migration_archive_records VALUES(?,?,?,?,?,?,?)",
                    (
                        migration_id,
                        "legacy-workspace",
                        archive_name or source_table,
                        count,
                        encoded,
                        row_hash,
                        _now(),
                    ),
                )
    finally:
        target.close()
    return count, digest.hexdigest()


def _project_active_records(source: sqlite3.Connection, targets: Mapping[str, Path]) -> int:
    transformed = 0
    names = {
        str(row[0]) for row in source.execute("SELECT name FROM sqlite_master WHERE type='table'")
    }
    if "task_sessions" in names:
        target = sqlite3.connect(targets["task"])
        try:
            with target:
                for row in source.execute("SELECT * FROM task_sessions"):
                    document = dict(row)
                    identifier = str(document.get("task_session_id") or document.get("session_id"))
                    if not identifier:
                        continue
                    state = str(document.get("current_state") or document.get("state") or "INTAKE")
                    now = str(document.get("updated_at") or _now())
                    target.execute(
                        "INSERT OR IGNORE INTO task_sessions("
                        "task_session_id,state,payload_json,revision,created_at,updated_at) "
                        "VALUES(?,?,?,1,?,?)",
                        (
                            identifier,
                            state,
                            json.dumps(document, default=str, sort_keys=True),
                            now,
                            now,
                        ),
                    )
                    transformed += 1
        finally:
            target.close()
    return transformed


def _ownership_map() -> dict[str, Mapping[str, str]]:
    # Historical readers are intentionally isolated here. Ownership is inferred
    # from the source object and every row is retained in the authority archive,
    # so an unknown historical table can never be silently dropped.
    return {}


def _database_fingerprint(path: Path) -> str:
    with closing(sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True)) as connection:
        schema = "\n".join(
            str(row[0] or "")
            for row in connection.execute(
                "SELECT sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name"
            )
        )
        objects = inventory(connection)
        digests = {
            item.name: _source_table_fingerprint(connection, item)
            for item in objects
            if item.object_type == "table" and not item.name.startswith("sqlite_")
        }
    return hashlib.sha256(
        json.dumps(
            {"schema": hashlib.sha256(schema.encode()).hexdigest(), "tables": digests},
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
    ).hexdigest()


def _source_table_fingerprint(
    connection: sqlite3.Connection, item: Any
) -> tuple[int, str] | dict[str, Any]:
    """Fingerprint legacy tables even when an optional virtual module is absent.

    Rebuildable virtual indexes such as ``vec0`` may not be queryable in the
    isolated migration runtime. Their schema remains part of the database
    fingerprint, while their ordinary shadow tables are hashed independently.
    """

    try:
        return table_digest(connection, str(item.name))
    except sqlite3.DatabaseError as exc:
        sql = str(item.sql or "")
        if "virtual table" not in sql.casefold():
            raise
        return {
            "virtual_table_unavailable": True,
            "schema_sha256": hashlib.sha256(sql.encode()).hexdigest(),
            "observed_rows": item.rows,
            "error_type": type(exc).__name__,
        }


def _normalize_domain(domain: str, table: str) -> str:
    inferred = _infer_domain(table)
    if inferred in {"audit", "policy", "learning"}:
        return inferred
    return domain if domain in {"source", "task", "activity", "knowledge", "learning"} else inferred


def _infer_domain(table: str) -> str:
    name = table.casefold()
    if "audit" in name or "gating_baseline" in name:
        return "audit"
    if any(
        token in name for token in ("policy", "guardrail", "constitution", "capability", "approval")
    ):
        return "policy"
    if any(
        token in name
        for token in (
            "anticip",
            "skill",
            "learn",
            "benchmark",
            "teacher",
            "student",
            "cie",
            "metacog",
            "self_improve",
            "lesson",
        )
    ):
        return "learning"
    if any(
        token in name for token in ("task", "plan", "session", "workflow", "continuation", "job")
    ):
        return "task"
    if any(token in name for token in ("activity", "outcome", "metric", "incident", "event")):
        return "activity"
    if any(token in name for token in ("source", "chunk", "symbol", "edge", "snapshot", "file")):
        return "source"
    return "knowledge"


def _is_rebuildable(table: str) -> bool:
    name = table.casefold()
    return any(token in name for token in ("fts", "vec", "cache", "embedding", "chunk", "index"))


def _json_value(value: Any) -> Any:
    if isinstance(value, bytes):
        return {"base64": base64.b64encode(value).decode("ascii")}
    return value


def _file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="microseconds").replace("+00:00", "Z")
