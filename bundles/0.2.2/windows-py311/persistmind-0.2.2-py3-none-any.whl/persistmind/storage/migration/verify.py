from __future__ import annotations

import hashlib
import sqlite3
from dataclasses import dataclass
from typing import Iterable, Sequence


@dataclass(frozen=True, slots=True)
class Verification:
    table: str
    source_count: int
    target_count: int
    source_hash: str
    target_hash: str
    match: bool


def table_digest(
    connection: sqlite3.Connection, table: str, columns: Sequence[str] | None = None
) -> tuple[int, str]:
    if not table.replace("_", "").isalnum():
        raise ValueError("unsafe table name")
    digest = hashlib.sha256()
    count = 0
    projection = "*" if columns is None else ",".join(_quote_identifier(name) for name in columns)
    order_by = _stable_ordering(connection, table)
    for row in connection.execute(f'SELECT {projection} FROM "{table}" ORDER BY {order_by}'):
        digest.update(repr(tuple(row)).encode("utf-8", errors="replace"))
        digest.update(b"\n")
        count += 1
    return count, digest.hexdigest()


def _stable_ordering(connection: sqlite3.Connection, table: str) -> str:
    """Return a deterministic order for ordinary and ``WITHOUT ROWID`` tables."""

    try:
        connection.execute(f'SELECT rowid FROM "{table}" LIMIT 0')
    except sqlite3.OperationalError:
        info = list(connection.execute(f'PRAGMA table_info("{table}")'))
        primary_key = [
            str(row[1])
            for row in sorted(info, key=lambda row: int(row[5]) or len(info) + int(row[0]))
            if int(row[5]) > 0
        ]
        ordering = primary_key or [str(row[1]) for row in info]
        if not ordering:
            raise ValueError(f"table has no digestible columns: {table}")
        return ",".join(_quote_identifier(name) for name in ordering)
    return "rowid"


def _quote_identifier(value: str) -> str:
    return '"' + str(value).replace('"', '""') + '"'


def verify_databases(
    source: sqlite3.Connection, target: sqlite3.Connection, tables: Iterable[str]
) -> tuple[Verification, ...]:
    results: list[Verification] = []
    for table in tables:
        source_count, source_hash = table_digest(source, table)
        target_count, target_hash = table_digest(target, table)
        results.append(
            Verification(
                table,
                source_count,
                target_count,
                source_hash,
                target_hash,
                source_count == target_count and source_hash == target_hash,
            )
        )
    return tuple(results)
