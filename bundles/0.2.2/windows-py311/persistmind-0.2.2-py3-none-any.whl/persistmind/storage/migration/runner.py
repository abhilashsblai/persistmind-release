from __future__ import annotations

import json
import re
import sqlite3
from datetime import datetime, timedelta, timezone

from .planner import MigrationPlan, MigrationUnit
from .verify import table_digest


class MigrationRunner:
    def __init__(
        self, control: sqlite3.Connection, source: sqlite3.Connection, target: sqlite3.Connection
    ) -> None:
        self.control, self.source, self.target = control, source, target

    def start(self, run_id: str, plan: MigrationPlan, *, owner: str) -> None:
        now = _now()
        expires = (datetime.now(timezone.utc) + timedelta(minutes=5)).isoformat()
        with self.control:
            existing = self.control.execute(
                "SELECT plan_hash FROM storage_migration_runs WHERE run_id=?", (run_id,)
            ).fetchone()
            if existing:
                if str(existing[0]) != plan.plan_hash:
                    raise RuntimeError("migration run id is already bound to a different plan")
                fence = self.control.execute(
                    "SELECT token,expires_at FROM storage_fences WHERE fence_name='topology'"
                ).fetchone()
                if fence is not None and str(fence[0]) != run_id and str(fence[1]) > now:
                    raise RuntimeError("another migration owns the active topology fence")
                self.control.execute("DELETE FROM storage_fences WHERE fence_name='topology'")
                self.control.execute(
                    "INSERT INTO storage_fences VALUES('topology',?,?,?,?)",
                    (run_id, owner, now, expires),
                )
                return
            self.control.execute(
                "DELETE FROM storage_fences WHERE fence_name='topology' AND expires_at<=?",
                (now,),
            )
            self.control.execute(
                "INSERT INTO storage_fences VALUES('topology',?,?,?,?)",
                (run_id, owner, now, expires),
            )
            self.control.execute(
                "INSERT INTO storage_migration_runs VALUES(?,?,?,?,?,NULL,NULL,'{}','{}',?,?)",
                (
                    run_id,
                    "monolith-v1",
                    "persistmind-nextgen-v1",
                    "planned",
                    plan.plan_hash,
                    now,
                    now,
                ),
            )
            for unit in plan.units:
                self.control.execute(
                    "INSERT INTO storage_migration_units(run_id,unit_id,domain,source_object,target_object,disposition,state,cursor_json,source_count,target_count,updated_at) VALUES(?,?,?,?,?,?,'pending','{}',?,0,?)",
                    (
                        run_id,
                        unit.unit_id,
                        unit.domain,
                        unit.source_object,
                        unit.target_object,
                        unit.disposition,
                        unit.source_rows,
                        now,
                    ),
                )

    def copy_unit(self, run_id: str, unit: MigrationUnit, *, batch_size: int = 1000) -> int:
        if unit.disposition != "copy":
            self._state(run_id, unit.unit_id, "skipped", 0, unit.source_rows)
            return 0
        table = unit.source_object
        target_table = unit.target_object
        if not table.replace("_", "").isalnum() or not target_table.replace("_", "").isalnum():
            raise ValueError("unsafe table name")
        create_sql = self.source.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (table,)
        ).fetchone()
        if not create_sql or not create_sql[0]:
            raise KeyError(table)
        target_sql = re.sub(
            r"(?i)(CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?)[\"`\[]?"
            + re.escape(table)
            + r"[\"`\]]?",
            lambda match: f'{match.group(1)}"{target_table}"',
            str(create_sql[0]),
            count=1,
        )
        columns = [str(row[1]) for row in self.source.execute(f'PRAGMA table_info("{table}")')]
        target_exists = self.target.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (target_table,)
        ).fetchone()
        if target_exists:
            target_columns = [
                str(row[1]) for row in self.target.execute(f'PRAGMA table_info("{target_table}")')
            ]
            if set(target_columns) != set(columns):
                raise RuntimeError(
                    f"migration target schema differs for {table}: "
                    f"source={columns} target={target_columns}"
                )
        else:
            self.target.execute(target_sql)
        placeholders = ",".join("?" for _ in columns)
        column_sql = ",".join(f'"{name}"' for name in columns)
        progress = self.control.execute(
            "SELECT cursor_json,state FROM storage_migration_units WHERE run_id=? AND unit_id=?",
            (run_id, unit.unit_id),
        ).fetchone()
        if progress is None:
            raise KeyError(f"unknown migration unit: {run_id}/{unit.unit_id}")
        if str(progress[1]) == "copied":
            return int(json.loads(progress[0] or "{}").get("offset", 0))
        offset = int(json.loads(progress[0] or "{}").get("offset", 0))
        while True:
            rows = self.source.execute(
                f'SELECT * FROM "{table}" ORDER BY rowid LIMIT ? OFFSET ?', (batch_size, offset)
            ).fetchall()
            if not rows:
                break
            with self.target:
                self.target.executemany(
                    f'INSERT OR REPLACE INTO "{target_table}"({column_sql}) VALUES({placeholders})',
                    rows,
                )
            offset += len(rows)
            self._state(run_id, unit.unit_id, "copying", offset, unit.source_rows)
        self._state(run_id, unit.unit_id, "copied", offset, unit.source_rows)
        source_count, source_hash = table_digest(self.source, table, columns)
        target_count, target_hash = table_digest(self.target, target_table, columns)
        if source_count != target_count or source_hash != target_hash:
            self._state(run_id, unit.unit_id, "failed", offset, unit.source_rows)
            raise RuntimeError(
                f"migration parity failed for {table}: "
                f"source={source_count}/{source_hash} target={target_count}/{target_hash}"
            )
        with self.control:
            self.control.execute(
                "UPDATE storage_migration_units SET source_count=?,target_count=?,"
                "source_hash=?,target_hash=?,updated_at=? WHERE run_id=? AND unit_id=?",
                (
                    source_count,
                    target_count,
                    source_hash,
                    target_hash,
                    _now(),
                    run_id,
                    unit.unit_id,
                ),
            )
        return offset

    def finish(self, run_id: str) -> None:
        pending = self.control.execute(
            "SELECT COUNT(*) FROM storage_migration_units WHERE run_id=? AND state NOT IN ('copied','skipped')",
            (run_id,),
        ).fetchone()[0]
        if pending:
            raise RuntimeError(f"migration has {pending} incomplete units")
        with self.control:
            self.control.execute(
                "UPDATE storage_migration_runs SET state='ready',updated_at=? WHERE run_id=?",
                (_now(), run_id),
            )
            self.control.execute(
                "UPDATE storage_fences SET expires_at=? WHERE fence_name='topology' AND token=?",
                (_now(), run_id),
            )

    def pause(self, run_id: str) -> None:
        with self.control:
            self.control.execute(
                "UPDATE storage_migration_runs SET state='planned',updated_at=? "
                "WHERE run_id=? AND state IN ('copying','shadowing')",
                (_now(), run_id),
            )

    def fail(self, run_id: str, error: BaseException) -> None:
        payload = json.dumps({"type": type(error).__name__, "message": str(error)}, sort_keys=True)
        with self.control:
            self.control.execute(
                "UPDATE storage_migration_runs SET state='failed',error_json=?,updated_at=? "
                "WHERE run_id=?",
                (payload, _now(), run_id),
            )

    def _state(self, run_id: str, unit_id: str, state: str, cursor: int, source_count: int) -> None:
        with self.control:
            renewed = self.control.execute(
                "UPDATE storage_fences SET expires_at=? WHERE fence_name='topology' AND token=?",
                (
                    (datetime.now(timezone.utc) + timedelta(minutes=5)).isoformat(),
                    run_id,
                ),
            )
            if renewed.rowcount != 1:
                raise RuntimeError("migration topology fence was lost")
            self.control.execute(
                "UPDATE storage_migration_units SET state=?,cursor_json=?,target_count=?,updated_at=? WHERE run_id=? AND unit_id=?",
                (state, json.dumps({"offset": cursor}), cursor, _now(), run_id, unit_id),
            )


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()
