from __future__ import annotations

import sqlite3

from ..catalog import FileCatalog
from ..descriptors import TopologyManifest


def rollback_catalog(
    catalog: FileCatalog, previous: TopologyManifest, *, expected_generation: int
) -> TopologyManifest:
    rollback = TopologyManifest(
        f"{previous.topology_id}-rollback",
        expected_generation + 1,
        previous.profile,
        previous.stores,
    )
    catalog.activate(rollback, expected_generation=expected_generation)
    return rollback


def mark_rolled_back(control: sqlite3.Connection, run_id: str, *, reason: str) -> None:
    with control:
        control.execute(
            "UPDATE storage_migration_runs SET state='rolled_back',error_json=json_object('rollback_reason',?),updated_at=datetime('now') WHERE run_id=?",
            (reason, run_id),
        )
        control.execute(
            "UPDATE storage_fences SET expires_at=datetime('now'),owner=owner || ':rolled_back' WHERE token=?",
            (run_id,),
        )
