from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass

from .inventory import InventoryObject


@dataclass(frozen=True, slots=True)
class MigrationUnit:
    unit_id: str
    source_object: str
    target_object: str
    domain: str
    disposition: str
    source_rows: int


@dataclass(frozen=True, slots=True)
class MigrationPlan:
    units: tuple[MigrationUnit, ...]
    estimated_bytes: int
    required_free_bytes: int
    plan_hash: str


def build_plan(
    objects: Sequence[InventoryObject],
    ownership: Mapping[str, Mapping[str, str]],
    *,
    source_bytes: int = 0,
    target_prefix: str = "",
) -> MigrationPlan:
    if target_prefix and not target_prefix.replace("_", "").isalnum():
        raise ValueError("unsafe migration target prefix")
    units: list[MigrationUnit] = []
    for item in objects:
        if item.object_type != "table":
            continue
        owner = ownership.get(item.name, {})
        domain = owner.get("canonical_domain", "knowledge")
        disposition = owner.get("migration_disposition", "copy")
        target_name = f"{target_prefix}{item.name}" if disposition == "copy" else item.name
        units.append(
            MigrationUnit(
                f"{domain}:{item.name}",
                item.name,
                target_name,
                domain,
                disposition,
                int(item.rows or 0),
            )
        )
    payload = [asdict(item) for item in sorted(units, key=lambda unit: unit.unit_id)]
    plan_hash = hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    estimate = max(source_bytes, sum(unit.source_rows * 512 for unit in units))
    return MigrationPlan(
        tuple(sorted(units, key=lambda unit: unit.unit_id)),
        estimate,
        int(estimate * 1.25),
        plan_hash,
    )
