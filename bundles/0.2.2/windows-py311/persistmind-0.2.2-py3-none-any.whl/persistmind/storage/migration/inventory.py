from __future__ import annotations

import sqlite3
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class InventoryObject:
    name: str
    object_type: str
    sql: str
    rows: int | None


def inventory(connection: sqlite3.Connection) -> tuple[InventoryObject, ...]:
    objects: list[InventoryObject] = []
    rows = connection.execute(
        "SELECT type,name,COALESCE(sql,'') FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name"
    )
    for object_type, name, sql in rows:
        count: int | None = None
        if object_type == "table" and _identifier(name):
            try:
                count = int(connection.execute(f'SELECT COUNT(*) FROM "{name}"').fetchone()[0])
            except sqlite3.DatabaseError:
                count = None
        objects.append(InventoryObject(str(name), str(object_type), str(sql), count))
    return tuple(objects)


def _identifier(value: str) -> bool:
    return bool(value) and all(character.isalnum() or character == "_" for character in value)
