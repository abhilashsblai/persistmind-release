from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import closing
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path


@dataclass(frozen=True, slots=True)
class BackupManifest:
    source: str
    image: str
    sha256: str
    created_at: str
    bytes: int = 0
    schema_version: str = "persistmind.storage_backup.v1"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def create_backup(source: Path, destination: Path) -> BackupManifest:
    if not source.is_file():
        raise FileNotFoundError(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".partial")
    temporary.unlink(missing_ok=True)
    with (
        closing(sqlite3.connect(source)) as source_connection,
        closing(sqlite3.connect(temporary)) as target,
    ):
        with target:
            source_connection.backup(target)
            result = target.execute("PRAGMA integrity_check").fetchone()[0]
            if result != "ok":
                raise RuntimeError(f"backup integrity failed: {result}")
    temporary.replace(destination)
    manifest = BackupManifest(
        str(source.resolve()),
        str(destination.resolve()),
        _sha256(destination),
        datetime.now(timezone.utc).isoformat(),
        destination.stat().st_size,
    )
    destination.with_suffix(destination.suffix + ".manifest.json").write_text(
        json.dumps(asdict(manifest), indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return manifest


def restore_backup(manifest: BackupManifest, destination: Path) -> Path:
    source = Path(manifest.image)
    if not source.is_file() or _sha256(source) != manifest.sha256:
        raise RuntimeError("backup checksum mismatch")
    if manifest.bytes and source.stat().st_size != manifest.bytes:
        raise RuntimeError("backup size mismatch")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".restore-partial")
    temporary.unlink(missing_ok=True)
    with (
        closing(sqlite3.connect(source)) as backup,
        closing(sqlite3.connect(temporary)) as restored,
    ):
        with restored:
            backup.backup(restored)
            if restored.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise RuntimeError("restored database integrity failed")
    temporary.replace(destination)
    return destination
