from __future__ import annotations

import hashlib
import secrets
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from persistmind.config import load_settings
from persistmind.repo_identity import canonical_path_identity, canonical_repo_hash
from persistmind.utils import canonical_json, stable_id, utc_now

from .adapters.sqlite_task import SQLiteTaskStore
from .descriptors import StoreRole
from .runtime import StorageOpenIntent, StorageRuntime


EXECUTION_RECEIPT_SCHEMA = "persistmind.execution_receipt.v1"
RECEIPT_TTL_SECONDS = 300

_MCP_DEFAULTS: dict[str, dict[str, Any]] = {
    "task_transition": {
        "actor": "mcp-agent",
        "reason": None,
        "pack_id": None,
    },
    "plan_create": {"pack_id": None, "author": "mcp-agent"},
    "plan_amend": {"author": "mcp-agent", "reason": None},
    "plan_checkpoint": {"paths": None},
}


class ExecutionReceiptError(ValueError):
    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


def new_execution_receipt_id() -> str:
    return "receipt_" + secrets.token_hex(16)


def canonical_command_hash(
    route: str,
    argv: Sequence[str],
    *,
    repo_root: Path,
) -> str:
    normalized = _canonical_command_argv(argv, repo_root=repo_root)
    return _domain_hash("persistmind.receipt.command.v1", [route, normalized])


def canonical_cwd_hash(cwd: Path) -> str:
    return _domain_hash(
        "persistmind.receipt.cwd.v1",
        [canonical_path_identity(cwd.resolve())],
    )


def canonical_result_hash(result: Mapping[str, Any]) -> str:
    return _domain_hash("persistmind.receipt.result.v1", [dict(result)])


def canonical_mcp_input_hash(method: str, params: Mapping[str, Any]) -> str:
    normalized = dict(params)
    for key, default in _MCP_DEFAULTS.get(method, {}).items():
        if normalized.get(key, object()) == default:
            normalized.pop(key, None)
    return _domain_hash("persistmind.receipt.mcp_input.v1", [method, normalized])


class ExecutionReceiptStore:
    """Issue and atomically claim short-lived canonical hook receipts."""

    def __init__(
        self,
        repo_root: Path,
        *,
        allow_development_driver: bool = False,
        runtime: StorageRuntime | None = None,
    ) -> None:
        self.repo_root = repo_root.resolve()
        settings = load_settings(self.repo_root)
        self._owns_runtime = runtime is None
        self.runtime = runtime or StorageRuntime.open(
            self.repo_root / settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=allow_development_driver,
            required_roles=frozenset({StoreRole.TASK_STATE}),
        )
        store = self.runtime.router.resolve_write_store(StoreRole.TASK_STATE)
        if not isinstance(store, SQLiteTaskStore):
            raise RuntimeError("Task State route is unavailable for execution receipts")
        self.store = store

    def close(self) -> None:
        if self._owns_runtime:
            self.runtime.close()

    def __enter__(self) -> "ExecutionReceiptStore":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    @contextmanager
    def _immediate_transaction(self) -> Any:
        try:
            self.store.connection.execute("BEGIN IMMEDIATE")
        except Exception as exc:
            raise ExecutionReceiptError("execution_receipt_contention") from exc
        try:
            yield
        except BaseException:
            self.store.connection.execute("ROLLBACK")
            raise
        else:
            self.store.connection.execute("COMMIT")

    def issue(
        self,
        *,
        receipt_id: str,
        route: str,
        task_session_id: str,
        command_argv: Sequence[str] | None,
        result: Mapping[str, Any],
        lifecycle_event_id: str,
        lifecycle_sequence: int,
        mcp_method: str | None = None,
        mcp_input: Mapping[str, Any] | None = None,
        ttl_seconds: int = RECEIPT_TTL_SECONDS,
    ) -> dict[str, Any]:
        if not receipt_id.startswith("receipt_") or len(receipt_id) != 40:
            raise ExecutionReceiptError("invalid_execution_receipt_id")
        if self.store.session(task_session_id) is None:
            raise ExecutionReceiptError("receipt_task_not_found")
        event = self.store.connection.execute(
            "SELECT task_session_id,sequence FROM workflow_lifecycle_events WHERE event_id=?",
            (lifecycle_event_id,),
        ).fetchone()
        if event is None:
            raise ExecutionReceiptError("receipt_lifecycle_event_not_found")
        if str(event["task_session_id"]) != task_session_id or int(event["sequence"]) != int(
            lifecycle_sequence
        ):
            raise ExecutionReceiptError("receipt_lifecycle_event_mismatch")
        repo_hash = canonical_repo_hash(self.repo_root)
        project_uuid = stable_id("persistmind-project", repo_hash)
        created_at = utc_now()
        expires_at = (
            datetime.now(timezone.utc) + timedelta(seconds=max(1, ttl_seconds))
        ).isoformat()
        if mcp_method is not None:
            if command_argv is not None or mcp_input is None:
                raise ExecutionReceiptError("execution_receipt_input_ambiguous")
            input_hash = canonical_mcp_input_hash(mcp_method, mcp_input)
        elif command_argv is not None:
            input_hash = canonical_command_hash(
                route,
                command_argv,
                repo_root=self.repo_root,
            )
        else:
            raise ExecutionReceiptError("execution_receipt_input_missing")
        record = {
            "schema_version": EXECUTION_RECEIPT_SCHEMA,
            "receipt_id": receipt_id,
            "route": route,
            "task_session_id": task_session_id,
            "project_uuid": project_uuid,
            "canonical_repo_hash": repo_hash,
            "command_hash": input_hash,
            "cwd_hash": canonical_cwd_hash(self.repo_root),
            "result_hash": canonical_result_hash(result),
            "lifecycle_event_id": lifecycle_event_id,
            "lifecycle_sequence": int(lifecycle_sequence),
            "engine_generation": int(self.runtime.topology.generation),
            "success": True,
            "expires_at": expires_at,
            "created_at": created_at,
        }
        envelope_contract = {
            "execution_receipt_id": receipt_id,
            "route": route,
            "task_session_id": task_session_id,
            "project_uuid": project_uuid,
            "canonical_repo_hash": repo_hash,
            "lifecycle_event_id": lifecycle_event_id,
            "lifecycle_sequence": int(lifecycle_sequence),
            "engine_generation": int(self.runtime.topology.generation),
        }
        if any(str(result.get(key)) != str(value) for key, value in envelope_contract.items()):
            raise ExecutionReceiptError("execution_receipt_envelope_mismatch")
        with self.store._write_lock, self._immediate_transaction():
            existing = self.store.connection.execute(
                "SELECT * FROM workflow_execution_receipts WHERE receipt_id=?",
                (receipt_id,),
            ).fetchone()
            if existing is not None:
                if any(
                    str(existing[key]) != str(record[key])
                    for key in (
                        "route",
                        "task_session_id",
                        "project_uuid",
                        "canonical_repo_hash",
                        "command_hash",
                        "cwd_hash",
                        "result_hash",
                        "lifecycle_event_id",
                        "lifecycle_sequence",
                        "engine_generation",
                    )
                ):
                    raise ExecutionReceiptError("execution_receipt_divergence")
                return record
            self.store.connection.execute(
                "INSERT INTO workflow_execution_receipts VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    receipt_id,
                    route,
                    task_session_id,
                    project_uuid,
                    repo_hash,
                    record["command_hash"],
                    record["cwd_hash"],
                    record["result_hash"],
                    lifecycle_event_id,
                    int(lifecycle_sequence),
                    int(self.runtime.topology.generation),
                    1,
                    expires_at,
                    None,
                    None,
                    None,
                    None,
                    None,
                    created_at,
                ),
            )
            self.store._advance_revision()
        return record

    def claim(
        self,
        *,
        receipt_id: str,
        route: str,
        task_session_id: str,
        command_argv: Sequence[str] | None,
        cwd: Path,
        result: Mapping[str, Any],
        lifecycle_event_id: str,
        lifecycle_sequence: int,
        host: str,
        session_id: str,
        turn_id: str,
        tool_call_id: str,
        mcp_method: str | None = None,
        mcp_input: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        if mcp_method is not None:
            if command_argv is not None or mcp_input is None:
                raise ExecutionReceiptError("execution_receipt_input_ambiguous")
            input_hash = canonical_mcp_input_hash(mcp_method, mcp_input)
        elif command_argv is not None:
            input_hash = canonical_command_hash(
                route,
                command_argv,
                repo_root=self.repo_root,
            )
        else:
            raise ExecutionReceiptError("execution_receipt_input_missing")
        expected = {
            "route": route,
            "task_session_id": task_session_id,
            "canonical_repo_hash": canonical_repo_hash(self.repo_root),
            "command_hash": input_hash,
            "cwd_hash": canonical_cwd_hash(cwd),
            "result_hash": canonical_result_hash(result),
            "lifecycle_event_id": lifecycle_event_id,
            "lifecycle_sequence": int(lifecycle_sequence),
            "engine_generation": int(self.runtime.topology.generation),
        }
        expected["project_uuid"] = stable_id("persistmind-project", expected["canonical_repo_hash"])
        if any(
            str(result.get(key)) != str(value)
            for key, value in {
                "execution_receipt_id": receipt_id,
                "route": route,
                "task_session_id": task_session_id,
                "project_uuid": expected["project_uuid"],
                "canonical_repo_hash": expected["canonical_repo_hash"],
                "lifecycle_event_id": lifecycle_event_id,
                "lifecycle_sequence": int(lifecycle_sequence),
                "engine_generation": expected["engine_generation"],
            }.items()
        ):
            raise ExecutionReceiptError("execution_receipt_envelope_mismatch")
        claim_tuple = (host, session_id, turn_id, tool_call_id)
        with self.store._write_lock, self._immediate_transaction():
            row = self.store.connection.execute(
                "SELECT * FROM workflow_execution_receipts WHERE receipt_id=?",
                (receipt_id,),
            ).fetchone()
            if row is None:
                raise ExecutionReceiptError("execution_receipt_not_found")
            if int(row["success"]) != 1:
                raise ExecutionReceiptError("execution_receipt_unsuccessful")
            for key, value in expected.items():
                if str(row[key]) != str(value):
                    raise ExecutionReceiptError(f"execution_receipt_{key}_mismatch")
            event = self.store.connection.execute(
                "SELECT task_session_id,sequence FROM workflow_lifecycle_events WHERE event_id=?",
                (lifecycle_event_id,),
            ).fetchone()
            if event is None:
                raise ExecutionReceiptError("receipt_lifecycle_event_not_found")
            existing_claim = (
                row["claimed_host"],
                row["claimed_session_id"],
                row["claimed_turn_id"],
                row["claimed_tool_call_id"],
            )
            if row["claimed_at"] is not None:
                if tuple(str(item) for item in existing_claim) == claim_tuple:
                    return {
                        "ok": True,
                        "receipt_id": receipt_id,
                        "claimed": False,
                        "idempotent_replay": True,
                    }
                raise ExecutionReceiptError("execution_receipt_already_claimed")
            if _parse_time(str(row["expires_at"])) < datetime.now(timezone.utc):
                raise ExecutionReceiptError("execution_receipt_expired")
            cursor = self.store.connection.execute(
                "UPDATE workflow_execution_receipts SET claimed_host=?,claimed_session_id=?,"
                "claimed_turn_id=?,claimed_tool_call_id=?,claimed_at=? "
                "WHERE receipt_id=? AND claimed_at IS NULL",
                (*claim_tuple, utc_now(), receipt_id),
            )
            if cursor.rowcount != 1:
                raced = self.store.connection.execute(
                    "SELECT claimed_host,claimed_session_id,claimed_turn_id,"
                    "claimed_tool_call_id FROM workflow_execution_receipts "
                    "WHERE receipt_id=?",
                    (receipt_id,),
                ).fetchone()
                if raced is not None and tuple(str(item) for item in raced) == claim_tuple:
                    return {
                        "ok": True,
                        "receipt_id": receipt_id,
                        "claimed": False,
                        "idempotent_replay": True,
                    }
                raise ExecutionReceiptError("execution_receipt_claim_race")
            self.store._advance_revision()
        return {
            "ok": True,
            "receipt_id": receipt_id,
            "claimed": True,
            "idempotent_replay": False,
        }


def _canonical_command_argv(argv: Sequence[str], *, repo_root: Path) -> list[str]:
    del repo_root  # Repository identity is bound independently in the receipt.
    values = [str(value) for value in argv]
    normalized: list[str] = []
    repo_option: list[str] = []
    index = 0
    while index < len(values):
        value = values[index]
        if value == "--repo":
            if index + 1 >= len(values):
                raise ExecutionReceiptError("receipt_command_repo_missing")
            repo_option = ["--repo", "<canonical-repo>"]
            index += 2
            continue
        if value.startswith("--repo="):
            repo_option = ["--repo", "<canonical-repo>"]
            index += 1
            continue
        normalized.append(value)
        index += 1
    return [*repo_option, *normalized]


def _domain_hash(domain: str, values: list[Any]) -> str:
    digest = hashlib.sha256()
    digest.update(domain.encode("ascii") + b"\0")
    for value in values:
        encoded = canonical_json(value).encode("utf-8")
        digest.update(len(encoded).to_bytes(8, "big"))
        digest.update(encoded)
    return digest.hexdigest()


def _parse_time(value: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ExecutionReceiptError("execution_receipt_expiry_invalid") from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


__all__ = [
    "EXECUTION_RECEIPT_SCHEMA",
    "ExecutionReceiptError",
    "ExecutionReceiptStore",
    "canonical_command_hash",
    "canonical_cwd_hash",
    "canonical_mcp_input_hash",
    "canonical_result_hash",
    "new_execution_receipt_id",
]
