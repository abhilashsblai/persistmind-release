from __future__ import annotations

from .adapters.sqlite_control import SQLiteControlStore
from .descriptors import StoreRole, TopologyManifest
from .runtime import StorageRuntime


def publish_topology(
    runtime: StorageRuntime,
    topology: TopologyManifest,
    *,
    expected_generation: int,
) -> TopologyManifest:
    """Publish one catalog generation through the Control coordination authority."""

    control = runtime.router.resolve_write_store(StoreRole.CONTROL)
    if not isinstance(control, SQLiteControlStore):
        raise RuntimeError("Control route did not resolve for topology publication")
    control.stage_topology(topology.to_dict())
    runtime.catalog.activate(topology, expected_generation=expected_generation)
    # The catalog port deliberately models activation as a commit operation
    # with no return value. Re-read the committed pointer so downstream
    # control-plane state is derived from the durable publication, not from an
    # assumed return value or the caller's prepared manifest.
    published = runtime.catalog.current()
    control.activate_topology(published.generation)
    return published
