from __future__ import annotations


def classify_sqlite_error(exc: BaseException) -> str:
    message = str(exc).casefold()
    if any(
        token in message
        for token in ("malformed", "not a database", "database disk image is malformed")
    ):
        return "database_malformed"
    if "locked" in message:
        return "database_locked"
    if "busy" in message:
        return "database_busy"
    if any(token in message for token in ("i/o", "ioerr", "disk i/o")):
        return "database_io_error"
    return "database_unavailable"
