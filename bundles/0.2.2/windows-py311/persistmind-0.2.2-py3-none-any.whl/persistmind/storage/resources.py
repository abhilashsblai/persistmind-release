from __future__ import annotations

import hashlib
import json
from importlib import resources
from typing import Any

from .descriptors import MemoryKindDescriptor, TopologyManifest


RESOURCE_ROOT = resources.files("persistmind.storage").joinpath("resources")
_FROZEN_V1_STORAGE_EVENTS = frozenset(
    {
        "TaskCompleted.v1",
        "PolicyChanged.v1",
        "SkillActivated.v1",
        "KnowledgeChanged.v1",
        "SourceGenerationPublished.v1",
        "ActivityPartitionSealed.v1",
        "AuditPartitionSealed.v1",
        "SchemaHeadChanged.v1",
        "BackupVerified.v1",
        "RetentionApplied.v1",
        "ObjectDeleted.v1",
    }
)


def _raw_bytes(name: str) -> bytes:
    target = RESOURCE_ROOT.joinpath(*name.split("/"))
    # Resource identities are content identities, not checkout line-ending
    # identities. Git may materialize text as LF or CRLF depending on platform.
    return target.read_bytes().replace(b"\r\n", b"\n")


def read_bytes(name: str) -> bytes:
    payload = _raw_bytes(name)
    if name == "storage-manifest.v1.json":
        return payload
    manifest = json.loads(_raw_bytes("storage-manifest.v1.json").decode("utf-8"))
    expected = manifest.get("hashes", {}).get(name)
    if not expected:
        raise RuntimeError(f"storage resource is not checksummed: {name}")
    actual = hashlib.sha256(payload).hexdigest()
    if actual != expected:
        raise RuntimeError(
            f"storage resource checksum mismatch: {name} expected={expected} actual={actual}"
        )
    return payload


def load_json(name: str) -> dict[str, Any]:
    value = json.loads(read_bytes(name).decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"storage resource must be an object: {name}")
    return value


def sha256(name: str) -> str:
    return hashlib.sha256(read_bytes(name)).hexdigest()


def load_topology(profile: str) -> TopologyManifest:
    if profile != "persistmind-nextgen-v1":
        raise ValueError(f"unknown storage topology: {profile}")
    return TopologyManifest.from_dict(load_json(f"topologies/{profile}.json"))


def load_memory_kinds() -> dict[str, MemoryKindDescriptor]:
    document = load_json("memory-kinds.v1.json")
    descriptors = [MemoryKindDescriptor.from_dict(item) for item in document.get("kinds", [])]
    if not descriptors or len({item.kind for item in descriptors}) != len(descriptors):
        raise ValueError("memory kind registry is empty or contains duplicates")
    return {item.kind: item for item in descriptors}


def memory_kind(kind: str) -> MemoryKindDescriptor:
    try:
        return load_memory_kinds()[kind]
    except KeyError as exc:
        raise ValueError(f"unknown memory kind: {kind}") from exc


def load_storage_events() -> dict[str, dict[str, Any]]:
    document = load_json("storage-events.v1.json")
    events = document.get("events")
    if not isinstance(events, list):
        raise ValueError("storage event registry must contain an event array")
    registry: dict[str, dict[str, Any]] = {}
    for item in events:
        if not isinstance(item, dict) or not str(item.get("event_type") or ""):
            raise ValueError("invalid storage event registry entry")
        event_type = str(item["event_type"])
        if event_type in registry:
            raise ValueError(f"duplicate storage event type: {event_type}")
        registry[event_type] = dict(item)
    missing = sorted(_FROZEN_V1_STORAGE_EVENTS - set(registry))
    if missing:
        raise ValueError("storage event registry is missing frozen events: " + ", ".join(missing))
    return registry


def required_event_consumers(
    event_type: str, payload: dict[str, Any] | Any
) -> tuple[str, ...] | None:
    contract = load_storage_events().get(event_type)
    if contract is None:
        return None
    required = {str(item) for item in contract.get("required_consumers", [])}
    conditional = contract.get("conditional_consumers") or {}
    if isinstance(conditional, dict) and isinstance(payload, dict):
        required.update(
            str(consumer)
            for flag, consumer in conditional.items()
            if payload.get(str(flag)) is True
        )
    return tuple(sorted(required))
