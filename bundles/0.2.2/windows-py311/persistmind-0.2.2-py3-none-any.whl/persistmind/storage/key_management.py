from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from persistmind.security.envelope import WorkspaceKeyProvider, WrappedDataKey

from .backup import BACKUP_DIRECTORY_GLOB
from .lifecycle import OperationFence


class StorageKeyRotationService:
    """Crash-resumable DEK rewrap across live objects and retained backups."""

    def __init__(self, workspace_root: Path, *, allow_test_provider: bool = False) -> None:
        self.root = workspace_root.resolve()
        self.keys = WorkspaceKeyProvider(self.root, allow_test_provider=allow_test_provider)

    def rotate(self) -> dict[str, Any]:
        old_key_id = self.keys.current_key_id()
        new_key_id = self.keys.create_generation()
        targets = [
            *sorted((self.root / "objects" / "sha256").glob("*/*/manifest.json")),
            *sorted((self.root / "backups").glob(f"{BACKUP_DIRECTORY_GLOB}/manifest.json")),
        ]
        with OperationFence(
            self.root,
            "key-rotation",
            {
                "old_key_id": old_key_id,
                "new_key_id": new_key_id,
                "targets": [str(item.relative_to(self.root)) for item in targets],
            },
            scope="keys",
        ) as fence:
            rewrapped = []
            for path in targets:
                if self._rewrap(path, new_key_id):
                    rewrapped.append(str(path.relative_to(self.root)).replace("\\", "/"))
            self.keys.set_current(new_key_id)
            result = {
                "ok": True,
                "status": "rotated",
                "schema_version": "persistmind.key_rotation.v1",
                "old_key_id": old_key_id,
                "new_key_id": new_key_id,
                "rewrapped": rewrapped,
                "old_key_retained_for_restore": True,
            }
            fence.succeed(result)
            return result

    def _rewrap(self, path: Path, new_key_id: str) -> bool:
        try:
            document = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"encrypted manifest is unreadable: {path}") from exc
        if document.get("schema_version") == "persistmind.object.v2":
            envelope = document.get("encryption")
        elif document.get("schema_version") == "persistmind.backup_envelope.v1":
            envelope = document
        else:
            return False
        if not isinstance(envelope, dict) or not envelope.get("wrapped_dek"):
            return False
        wrapping_key_id = str(envelope.get("wrapping_key_id") or envelope["key_id"])
        if wrapping_key_id == new_key_id:
            return False
        wrapped = self.keys.rewrap_dek(
            WrappedDataKey(key_id=wrapping_key_id, wrapped_dek=str(envelope["wrapped_dek"])),
            new_key_id,
        )
        envelope["wrapping_key_id"] = wrapped.key_id
        envelope["wrapped_dek"] = wrapped.wrapped_dek
        _write_json(path, document)
        return True


def _write_json(path: Path, value: dict[str, Any]) -> None:
    temporary = path.with_suffix(".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, sort_keys=True, separators=(",", ":"))
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)
