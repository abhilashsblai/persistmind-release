from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from decimal import Decimal
from pathlib import Path
from typing import Any, cast

from persistmind.application.execution_scope import current_operation_scope
from persistmind.application.field_statistics import (
    allocation_integrity,
    analyze_treatment_stream,
    zero_event_upper_bound,
)
from persistmind.config import load_settings
from persistmind.security.approvals import require_approval_signature
from persistmind.security.memory_defense import require_actor_role
from persistmind.utils import canonical_json, stable_id, utc_now

from .adapters.sqlite_activity import SQLiteActivityStore, SQLiteAuditStore
from .adapters.sqlite_learning import LearningConflict as _LearningConflict
from .adapters.sqlite_learning import SQLiteLearningStore
from .adapters.sqlite_policy import SQLitePolicyStore
from .descriptors import StoreRole
from .events import EventLedger, StorageEvent
from .reconcile import reconcile
from .runtime import StorageOpenIntent, StorageRuntime, resolve_runtime_store

LearningConflict = _LearningConflict


class LearningService:
    """Governed skill-version activation port backed only by Learning storage.

    It provides the durable activation kernel: immutable candidate versions,
    object-backed artifacts, recorded benchmark and canary evidence, signed
    approval, active manifest, governed propagation, and signed rollback.
    """

    def __init__(
        self,
        repo_root: Path,
        *,
        allow_development_driver: bool = False,
        runtime: StorageRuntime | None = None,
        read_only: bool = False,
    ) -> None:
        self.repo_root = repo_root.resolve()
        self.settings = load_settings(self.repo_root)
        self._allow_development_driver = allow_development_driver
        self._owns_runtime = runtime is None
        operation_scope = current_operation_scope()
        required_roles = (
            frozenset(StoreRole(role) for role in operation_scope.roles)
            if operation_scope is not None
            else frozenset(
                {
                    StoreRole.LEARNING,
                    StoreRole.ACTIVITY_ACTIVE,
                    StoreRole.AUDIT_ACTIVE,
                    StoreRole.POLICY,
                }
            )
        ) | {StoreRole.LEARNING}
        self.runtime = runtime or StorageRuntime.open(
            self.repo_root / self.settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=allow_development_driver,
            read_only=read_only,
            required_roles=required_roles,
        )
        store = resolve_runtime_store(self.runtime, StoreRole.LEARNING, read_only=read_only)
        if not isinstance(store, SQLiteLearningStore):
            raise RuntimeError("Learning route did not resolve to SQLiteLearningStore")
        self.store = store
        self._activity: SQLiteActivityStore | None = None
        self._audit: SQLiteAuditStore | None = None
        self._policy: SQLitePolicyStore | None = None
        self._outbox: EventLedger | None = None

    def close(self) -> None:
        if self._owns_runtime:
            self.runtime.close()

    @property
    def outbox(self) -> EventLedger:
        if self._outbox is None:
            self._outbox = EventLedger(cast(Any, self.store.connection))
        return self._outbox

    def __enter__(self) -> LearningService:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def cie_status(self) -> dict[str, Any]:
        return self._cie_engine().status()

    def cie_cycle(
        self,
        limit: int = 20,
        target: str = "cie",
        task: str = "",
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        return self._cie_engine().cycle(limit=limit, target=target, task=task, paths=paths or [])

    def cie_archive(self, target: str | None = None, limit: int = 20) -> dict[str, Any]:
        return self._cie_engine().archive(limit=limit, target=target)

    def cie_show(self, run_id: str) -> dict[str, Any]:
        return self._cie_engine().show(run_id)

    def cie_predict(self, task: str = "", paths: list[str] | None = None) -> dict[str, Any]:
        return self._cie_engine().predict(task=task, paths=paths or [])

    def cie_checklist_preview(
        self, task: str = "", paths: list[str] | None = None
    ) -> dict[str, Any]:
        return self._cie_engine().checklist_preview(task=task, paths=paths or [])

    def cie_score(self, period: str = "current") -> dict[str, Any]:
        return self._cie_engine().score(period=period)

    def cie_timeline(self, run_id: str | None = None) -> dict[str, Any]:
        return self._cie_engine().timeline(run_id=run_id)

    def cie_preview_adoption(self, run_id: str, intervention_id: str) -> dict[str, Any]:
        return self._cie_engine().preview_adoption(run_id, intervention_id)

    def cie_adopt(self, run_id: str, intervention_id: str, approved_by: str) -> dict[str, Any]:
        return self._cie_engine().adopt(run_id, intervention_id, approved_by)

    def cie_reject(
        self, run_id: str, intervention_id: str, reason: str, actor: str
    ) -> dict[str, Any]:
        return self._cie_engine().reject(run_id, intervention_id, reason, actor)

    def cie_suspend(
        self, run_id: str, intervention_id: str, reason: str, actor: str
    ) -> dict[str, Any]:
        return self._cie_engine().suspend(run_id, intervention_id, reason, actor)

    def cie_rollback(self, run_id: str, intervention_id: str, approved_by: str) -> dict[str, Any]:
        return self._cie_engine().rollback(run_id, intervention_id, approved_by)

    def cie_export_state(self, output: str | None = None) -> dict[str, Any]:
        return self._cie_engine().export_state(output=output)

    def cie_import_state(self, input_path: str, dry_run: bool = True) -> dict[str, Any]:
        return self._cie_engine().import_state(input_path, dry_run=dry_run)

    def cie_rebuild_state(self, from_events: bool = True, dry_run: bool = True) -> dict[str, Any]:
        return self._cie_engine().rebuild_state(from_events=from_events, dry_run=dry_run)

    def anticipate_ui_review(
        self,
        task: str = "",
        paths: list[str] | None = None,
        proposed_content: str | None = None,
        proposed_path: str | None = None,
        max_findings: int = 5,
    ) -> dict[str, Any]:
        from persistmind.anticipation.ui_redundancy import review_ui_redundancy

        return review_ui_redundancy(
            self.repo_root,
            task=task,
            paths=paths or [],
            proposed_content=proposed_content,
            proposed_path=proposed_path,
            max_findings=max_findings,
        )

    def _cie_engine(self) -> Any:
        from persistmind.cie.engine import CIEEngine

        return CIEEngine(repo_root=self.repo_root, store=self.store, settings=self.settings)

    @property
    def activity(self) -> SQLiteActivityStore:
        if self._activity is None:
            value = resolve_runtime_store(
                self.runtime, StoreRole.ACTIVITY_ACTIVE, read_only=self.runtime.read_only
            )
            if not isinstance(value, SQLiteActivityStore):
                raise RuntimeError("Learning Activity projection route is invalid")
            self._activity = value
        return self._activity

    @property
    def audit(self) -> SQLiteAuditStore:
        if self._audit is None:
            value = resolve_runtime_store(
                self.runtime, StoreRole.AUDIT_ACTIVE, read_only=self.runtime.read_only
            )
            if not isinstance(value, SQLiteAuditStore):
                raise RuntimeError("Learning Audit projection route is invalid")
            self._audit = value
        return self._audit

    @property
    def policy(self) -> SQLitePolicyStore:
        if self._policy is None:
            value = resolve_runtime_store(self.runtime, StoreRole.POLICY, read_only=True)
            if not isinstance(value, SQLitePolicyStore):
                raise RuntimeError("Learning Policy reader is invalid")
            self._policy = value
        return self._policy

    def version_propose(
        self,
        *,
        skill_id: str,
        benchmark_id: str,
        artifact_ref: str | None = None,
        content: str | bytes | None = None,
        classification: str = "internal",
    ) -> dict[str, Any]:
        skill_id = skill_id.strip()
        benchmark_id = benchmark_id.strip()
        if not skill_id or not benchmark_id:
            raise ValueError("skill proposal requires skill_id and benchmark_id")
        if artifact_ref and content is not None:
            raise ValueError("provide artifact_ref or content, not both")
        if content is not None:
            payload = content.encode("utf-8") if isinstance(content, str) else content
            if not isinstance(payload, bytes):
                raise ValueError("skill content must be text or bytes")
            artifact_ref = self.runtime.artifacts.put(payload, classification=classification)
        if not artifact_ref:
            raise ValueError("skill proposal requires artifact_ref or content")
        if not artifact_ref.startswith("sha256:") or not self.runtime.artifacts.verify(
            artifact_ref
        ):
            raise ValueError("skill artifact_ref must be a verified object-store reference")
        version_id = (
            "skill_version_"
            + stable_id("learning-version", skill_id, artifact_ref, benchmark_id)[:32]
        )
        version = self.store.register_version(
            {
                "version_id": version_id,
                "skill_id": skill_id,
                "artifact_ref": artifact_ref,
                "benchmark_id": benchmark_id,
                "status": "candidate",
            },
            idempotency_key=f"learning-version:{version_id}",
        )
        return {
            "ok": True,
            "schema_version": "persistmind.learning_version.v1",
            "version": dict(version),
            "nextgen_v1": True,
        }

    def candidate_lineage_add(
        self,
        version_id: str,
        parent_version_id: str,
        *,
        relation: str,
        mutation_hash: str,
        proposer_identity: str,
        protected_surface_hash: str,
    ) -> dict[str, Any]:
        version = self._version_or_raise(version_id)
        parent = self._version_or_raise(parent_version_id)
        if version_id == parent_version_id:
            raise ValueError("candidate lineage cannot be self-referential")
        if not self.runtime.artifacts.verify(
            str(version["artifact_ref"])
        ) or not self.runtime.artifacts.verify(str(parent["artifact_ref"])):
            raise ValueError("candidate lineage requires verified parent and child artifacts")
        if self._lineage_reaches(parent_version_id, version_id):
            raise ValueError("candidate lineage edge would create a cycle")
        if relation not in {"mutation", "merge", "refinement", "rollback", "import"}:
            raise ValueError("unsupported candidate lineage relation")
        edge_id = (
            "lineage_" + stable_id(version_id, parent_version_id, relation, mutation_hash)[:32]
        )
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT INTO learning_candidate_lineage VALUES(?,?,?,?,?,?,?,?)",
                (
                    edge_id,
                    version_id,
                    parent_version_id,
                    relation,
                    mutation_hash,
                    proposer_identity,
                    protected_surface_hash,
                    utc_now(),
                ),
            )
        return {
            "ok": True,
            "schema_version": "persistmind.learning_candidate_lineage.v1",
            "edge_id": edge_id,
        }

    def _lineage_reaches(self, start: str, target: str) -> bool:
        pending = [start]
        visited = set()
        while pending:
            current = pending.pop()
            if current == target:
                return True
            if current in visited:
                continue
            visited.add(current)
            rows = (
                self.store._reader()
                .execute(
                    "SELECT parent_version_id FROM learning_candidate_lineage WHERE version_id=?",
                    (current,),
                )
                .fetchall()
            )
            pending.extend(str(row[0]) for row in rows)
        return False

    def retention_baseline_set(
        self,
        *,
        name: str,
        required_versions: Mapping[str, str],
        required_metrics: Mapping[str, float],
        actor: str,
        approvals: list[Mapping[str, str]],
    ) -> dict[str, Any]:
        from persistmind.security.approvals import require_approval_quorum

        document = {
            "schema_version": "persistmind.learning_retention_baseline.v1",
            "action": "learning_retention_baseline_set",
            "name": name,
            "required_versions": dict(sorted(required_versions.items())),
            "required_metrics": _numeric_metrics(required_metrics),
            "actor": actor,
        }
        identities = require_approval_quorum(
            self.runtime.root,
            approvals,
            document,
            quorum=2,
            allow_test_provider=self._allow_development_driver,
        )
        for skill_id, version_id in required_versions.items():
            version = self._version_or_raise(version_id)
            if str(version["skill_id"]) != skill_id:
                raise ValueError("retention baseline version belongs to another skill")
        baseline_id = "retention_" + stable_id(name, canonical_json(document))[:32]
        self.store.put(
            {
                "record_id": baseline_id,
                "kind": "learning_retention_baseline",
                "scope": "workspace",
                **document,
                "signers": identities,
            },
            idempotency_key="learning-retention:" + baseline_id,
        )
        event = StorageEvent(
            event_id="event_" + stable_id(baseline_id, "LearningRetentionBaselineSet.v1")[:32],
            event_type="LearningRetentionBaselineSet.v1",
            aggregate_id=baseline_id,
            sequence=1,
            payload={
                "baseline_id": baseline_id,
                "name": name,
                "required_versions": dict(sorted(required_versions.items())),
                "signers": identities,
            },
            required_consumers=("audit.append.v1",),
        )
        self.outbox.append(event)
        self.store.connection.commit()
        convergence = self.reconcile_activation_events()
        return {
            "ok": True,
            "schema_version": "persistmind.learning_retention_baseline.v1",
            "baseline_id": baseline_id,
            "signers": identities,
            "storage_event_id": event.event_id,
            "convergence": convergence,
        }

    def retention_check(self, baseline_id: str) -> dict[str, Any]:
        baseline = self.store.get(baseline_id)
        if baseline is None or baseline.get("kind") != "learning_retention_baseline":
            raise KeyError(f"retention baseline not found: {baseline_id}")
        active = self.store.active_manifest()
        violations = []
        for skill_id, version_id in dict(baseline.get("required_versions") or {}).items():
            active_version = active.get(skill_id)
            candidate = self.store.version(str(active_version)) if active_version else None
            if (
                active_version != version_id
                or candidate is None
                or not self.runtime.artifacts.verify(str(candidate["artifact_ref"]))
            ):
                violations.append(
                    {
                        "skill_id": skill_id,
                        "required_version": version_id,
                        "active_version": active_version,
                    }
                )
        return {
            "ok": not violations,
            "status": "verified" if not violations else "retention_regression",
            "schema_version": "persistmind.learning_retention_check.v1",
            "baseline_id": baseline_id,
            "violations": violations,
        }

    def version_show(self, version_id: str) -> dict[str, Any]:
        version = self.store.version(version_id)
        if version is None:
            return {"ok": False, "error": "skill version not found", "version_id": version_id}
        return {
            "ok": True,
            "schema_version": "persistmind.learning_version_show.v1",
            "version": dict(version),
            "evaluations": list(self.store.evaluations(version_id)),
            "artifact_verified": self.runtime.artifacts.verify(str(version["artifact_ref"])),
            "nextgen_v1": True,
        }

    def versions(self, *, skill_id: str | None = None, limit: int = 100) -> dict[str, Any]:
        return {
            "ok": True,
            "schema_version": "persistmind.learning_versions.v1",
            "versions": [
                dict(item) for item in self.store.versions(skill_id=skill_id, limit=limit)
            ],
            "nextgen_v1": True,
        }

    def active_manifest(self) -> dict[str, Any]:
        return {
            "ok": True,
            "schema_version": "persistmind.learning_active_manifest.v1",
            "active_manifest": dict(self.store.active_manifest()),
            "nextgen_v1": True,
        }

    def status(self) -> dict[str, Any]:
        versions = [dict(item) for item in self.store.versions(limit=1000)]
        evaluations = [
            dict(evaluation)
            for version in versions
            for evaluation in self.store.evaluations(str(version["version_id"]))
        ]
        artifacts_ok = all(
            self.runtime.artifacts.verify(str(item["artifact_ref"])) for item in versions
        )
        return {
            "ok": artifacts_ok,
            "schema_version": "persistmind.learning_status.v1",
            "versions": len(versions),
            "evaluations": len(evaluations),
            "active_manifest": dict(self.store.active_manifest()),
            "artifact_integrity": artifacts_ok,
            "health": dict(self.store.health()),
            "nextgen_v1": True,
        }

    def archive(self, *, target: str | None = None, limit: int = 100) -> dict[str, Any]:
        versions = [dict(item) for item in self.store.versions(skill_id=target, limit=limit)]
        return {
            "ok": True,
            "schema_version": "persistmind.learning_archive.v1",
            "target": target,
            "versions": versions,
            "evaluations": {
                str(item["version_id"]): [
                    dict(value) for value in self.store.evaluations(str(item["version_id"]))
                ]
                for item in versions
            },
            "nextgen_v1": True,
        }

    def benchmark_trends(self, *, limit: int = 100) -> dict[str, Any]:
        archive = self.archive(limit=limit)
        trends = []
        for version in archive["versions"]:
            evaluations = archive["evaluations"][str(version["version_id"])]
            trends.append(
                {
                    "version_id": version["version_id"],
                    "skill_id": version["skill_id"],
                    "benchmark_id": version["benchmark_id"],
                    "evaluation_count": len(evaluations),
                    "passed": sum(bool(item.get("passed")) for item in evaluations),
                }
            )
        return {
            "ok": True,
            "schema_version": "persistmind.learning_benchmark_trends.v1",
            "trends": trends,
            "nextgen_v1": True,
        }

    def verify_closure(self) -> dict[str, Any]:
        status = self.status()
        active = status["active_manifest"]
        missing = []
        for skill_id, version_id in active.items():
            version = self.store.version(str(version_id))
            if version is None or str(version.get("skill_id")) != str(skill_id):
                missing.append({"skill_id": skill_id, "version_id": version_id})
        return {
            "ok": bool(status["ok"]) and not missing,
            "schema_version": "persistmind.learning_closure.v1",
            "status": status,
            "missing": missing,
            "nextgen_v1": True,
        }

    def evaluation_record(
        self,
        version_id: str,
        *,
        metrics: Mapping[str, Any],
        passed: bool,
        benchmark_id: str | None = None,
    ) -> dict[str, Any]:
        version = self._version_or_raise(version_id)
        benchmark = (benchmark_id or str(version["benchmark_id"])).strip()
        if benchmark != str(version["benchmark_id"]):
            raise ValueError("evaluation benchmark_id must match the candidate version")
        normalized = _numeric_metrics(metrics)
        evaluation_id = (
            "evaluation_"
            + stable_id(
                "learning-evaluation",
                version_id,
                benchmark,
                canonical_json(normalized),
                str(bool(passed)),
            )[:32]
        )
        evaluation = self.store.record_evaluation(
            {
                "evaluation_id": evaluation_id,
                "version_id": version_id,
                "split": f"benchmark:{benchmark}",
                "metrics": normalized,
                "passed": bool(passed),
            }
        )
        return {
            "ok": True,
            "schema_version": "persistmind.learning_evaluation.v1",
            "evaluation": dict(evaluation),
            "nextgen_v1": True,
        }

    def field_experiment_create(
        self,
        experiment_id: str,
        *,
        protocol_hash: str,
        metric_version: str,
    ) -> dict[str, Any]:
        self._require_target_project_field_evidence()
        approval = self.policy.experiment_approval(experiment_id)
        if approval is None or str(approval.get("state")) != "approved":
            raise PermissionError("field experiment requires a signed Policy approval")
        if str(approval["protocol_hash"]) != protocol_hash:
            raise PermissionError("field protocol hash differs from Policy approval")
        policy_record = self.policy.policy("experiment-approval-" + experiment_id)
        protocol = dict((policy_record or {}).get("protocol") or {})
        baseline = str(protocol.get("baseline_version") or "")
        candidate = str(protocol.get("candidate_version") or "")
        if not baseline or not candidate:
            raise ValueError("Policy experiment approval omits frozen artifact versions")
        self._version_or_raise(baseline)
        self._version_or_raise(candidate)
        assignment_key_id = "field-assignment-v1-" + stable_id(experiment_id)[:24]
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT INTO learning_field_experiments VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    experiment_id,
                    protocol_hash,
                    "approved",
                    baseline,
                    candidate,
                    assignment_key_id,
                    metric_version,
                    experiment_id,
                    protocol_hash,
                    None,
                    None,
                    None,
                ),
            )
            self.store.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return self.field_experiment_show(experiment_id)

    def field_experiment_start(self, experiment_id: str) -> dict[str, Any]:
        self._require_target_project_field_evidence()
        with self.store._write_lock, self.store.connection:
            cursor = self.store.connection.execute(
                "UPDATE learning_field_experiments SET status='running',started_at=? "
                "WHERE experiment_id=? AND status='approved'",
                (utc_now(), experiment_id),
            )
            if cursor.rowcount != 1:
                raise LearningConflict("experiment is not approved or already started")
        return self.field_experiment_show(experiment_id)

    def field_experiment_show(self, experiment_id: str) -> dict[str, Any]:
        row = (
            self.store._reader()
            .execute(
                "SELECT * FROM learning_field_experiments WHERE experiment_id=?",
                (experiment_id,),
            )
            .fetchone()
        )
        if row is None:
            raise KeyError(f"field experiment not found: {experiment_id}")
        return {
            "ok": True,
            "schema_version": "persistmind.field_experiment.v1",
            "experiment": dict(row),
        }

    def field_observe(self, observation: Mapping[str, Any]) -> dict[str, Any]:
        self._require_target_project_field_evidence()
        item = dict(observation)
        experiment_id = str(item["experiment_id"])
        experiment = self.field_experiment_show(experiment_id)["experiment"]
        if str(experiment["status"]) != "running":
            raise PermissionError("field observations require a running frozen experiment")
        unit_id = str(item["assignment_unit_id"])
        committed = self.policy.experiment_assignment(experiment_id, unit_id)
        if committed is None:
            raise PermissionError("field unit was not prospectively assigned by Policy")
        if str(item["assignment"]) != str(committed["assignment"]) or str(
            item["assignment_receipt_hash"]
        ) != str(committed["assignment_receipt_hash"]):
            raise PermissionError("field observation assignment differs from Policy commitment")
        metrics = dict(item.get("metrics") or {})
        for name in (
            "primary_utility_micro",
            "prediction_baseline_micro",
            "prediction_candidate_micro",
        ):
            if name in metrics and not 0 <= int(metrics[name]) <= 1_000_000:
                raise ValueError(f"{name} must be an integer micro-unit")
        identity = {
            key: item[key]
            for key in (
                "experiment_id",
                "assignment_unit_type",
                "assignment_unit_id",
                "root_task_id",
                "task_session_id",
                "task_envelope_hash",
                "outcome_membership_hash",
                "assignment",
                "stratum",
                "outcome_deadline",
                "field_outcome_event_id",
                "field_outcome_payload_hash",
            )
            if item.get(key) is not None
        }
        identity["metrics"] = metrics
        identity["artifact_identity"] = dict(item.get("artifact_identity") or {})
        observation_hash = (
            "sha256:" + hashlib.sha256(canonical_json(identity).encode("utf-8")).hexdigest()
        )
        observation_id = str(
            item.get("observation_id") or "observation_" + stable_id(experiment_id, unit_id)[:32]
        )
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT INTO learning_field_observations VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    observation_id,
                    experiment_id,
                    str(item["assignment_unit_type"]),
                    unit_id,
                    item.get("root_task_id"),
                    item.get("task_session_id"),
                    item.get("task_envelope_hash"),
                    str(item["outcome_membership_hash"]),
                    str(item["assignment"]),
                    str(item["stratum"]),
                    canonical_json(metrics),
                    canonical_json(dict(item.get("artifact_identity") or {})),
                    str(item["outcome_deadline"]),
                    str(item["field_outcome_event_id"]),
                    str(item["field_outcome_payload_hash"]),
                    observation_hash,
                    str(item.get("observed_at") or utc_now()),
                    int(item["enrollment_sequence"]),
                ),
            )
        return {
            "ok": True,
            "schema_version": "persistmind.field_observation.v1",
            "observation_id": observation_id,
            "observation_hash": observation_hash,
        }

    def field_experiment_freeze(self, experiment_id: str) -> dict[str, Any]:
        with self.store._write_lock, self.store.connection:
            cursor = self.store.connection.execute(
                "UPDATE learning_field_experiments SET status='frozen',frozen_at=? "
                "WHERE experiment_id=? AND status='running'",
                (utc_now(), experiment_id),
            )
            if cursor.rowcount != 1:
                raise LearningConflict("only a running experiment can be frozen")
        return self.field_experiment_show(experiment_id)

    def field_analyze(self, experiment_id: str) -> dict[str, Any]:
        experiment = self.field_experiment_show(experiment_id)["experiment"]
        if str(experiment["status"]) not in {"frozen", "decided", "completed"}:
            raise PermissionError("field analysis requires a frozen observation set")
        rows = (
            self.store._reader()
            .execute(
                "SELECT * FROM learning_field_observations WHERE experiment_id=? "
                "ORDER BY enrollment_sequence,assignment_unit_id",
                (experiment_id,),
            )
            .fetchall()
        )
        observations = []
        for row in rows:
            metrics = json.loads(str(row["metrics_json"]))
            observations.append(
                {
                    "enrollment_sequence": int(row["enrollment_sequence"]),
                    "assignment_unit_id": str(row["assignment_unit_id"]),
                    "assignment": str(row["assignment"]),
                    "outcome_micro": metrics.get("primary_utility_micro"),
                    "prediction_baseline_micro": metrics.get("prediction_baseline_micro", 0),
                    "prediction_candidate_micro": metrics.get("prediction_candidate_micro", 0),
                }
            )
        primary = analyze_treatment_stream(observations, missing_mode="primary")
        sensitivity = analyze_treatment_stream(observations, missing_mode="promotion_worst_case")
        allocation = allocation_integrity([str(item["assignment"]) for item in observations])
        candidate_rows = [row for row in rows if str(row["assignment"]) == "candidate"]
        critical_events = sum(
            int(json.loads(str(row["metrics_json"])).get("critical_events") or 0)
            for row in candidate_rows
        )
        safety_upper = (
            zero_event_upper_bound(len(candidate_rows))
            if candidate_rows and critical_events == 0
            else None
        )
        return {
            "ok": bool(allocation["ok"]),
            "status": "verified" if allocation["ok"] else allocation["status"],
            "schema_version": "persistmind.field_analysis.v1",
            "experiment_id": experiment_id,
            "protocol_hash": experiment["protocol_hash"],
            "observations": len(observations),
            "primary_itt": primary,
            "promotion_worst_case": sensitivity,
            "allocation": allocation,
            "critical_safety": {
                "candidate_executions": len(candidate_rows),
                "critical_events": critical_events,
                "zero_event_upper_95": safety_upper,
                "f3_gate": bool(
                    len(candidate_rows) >= 299
                    and critical_events == 0
                    and safety_upper is not None
                    and safety_upper <= 0.01
                ),
            },
        }

    def _require_target_project_field_evidence(self) -> None:
        pyproject = self.repo_root / "pyproject.toml"
        if (
            pyproject.is_file()
            and (self.repo_root / "src" / "persistmind").is_dir()
            and 'name = "persistmind"' in pyproject.read_text(encoding="utf-8")
        ):
            raise PermissionError(
                "PersistMind source-repository activity cannot be field efficacy evidence"
            )

    def promotion_request(
        self,
        version_id: str,
        *,
        field_experiment_id: str,
        rollback_version: str,
        protected_surface_hash: str,
    ) -> dict[str, Any]:
        version = self._version_or_raise(version_id)
        rollback = self._version_or_raise(rollback_version)
        if str(version["skill_id"]) != str(rollback["skill_id"]):
            raise ValueError("promotion rollback version belongs to another skill")
        if not protected_surface_hash.startswith("sha256:"):
            raise ValueError("promotion request requires a protected-surface hash")
        experiment = self.field_experiment_show(field_experiment_id)["experiment"]
        if str(experiment["candidate_version"]) != version_id:
            raise ValueError("field experiment candidate differs from promotion request")
        analysis = self.field_analyze(field_experiment_id)
        statistics_hash = (
            "sha256:" + hashlib.sha256(canonical_json(analysis).encode("utf-8")).hexdigest()
        )
        request_id = (
            "promotion-request_" + stable_id(version_id, field_experiment_id, statistics_hash)[:32]
        )
        document = {
            "record_id": request_id,
            "kind": "learning_promotion_request",
            "scope": "workspace",
            "version_id": version_id,
            "skill_id": version["skill_id"],
            "artifact_ref": version["artifact_ref"],
            "field_experiment_id": field_experiment_id,
            "protocol_hash": experiment["protocol_hash"],
            "statistics_hash": statistics_hash,
            "rollback_version": rollback_version,
            "protected_surface_hash": protected_surface_hash,
            "status": "policy_pending",
        }
        self.store.put(document, idempotency_key="promotion-request:" + request_id)
        event_payload = {
            "request_id": request_id,
            "version_id": version_id,
            "field_experiment_id": field_experiment_id,
            "statistics_hash": statistics_hash,
        }
        event = StorageEvent(
            event_id="event_" + stable_id(request_id, "LearningPromotionRequested.v1")[:32],
            event_type="LearningPromotionRequested.v1",
            aggregate_id=request_id,
            sequence=1,
            payload=event_payload,
            required_consumers=("audit.append.v1", "policy.learning-promotion.v1"),
        )
        self.outbox.append(event)
        payload_hash = hashlib.sha256(canonical_json(event_payload).encode("utf-8")).hexdigest()
        return {
            "ok": True,
            "schema_version": "persistmind.learning_promotion_request.v1",
            "request": document,
            "event_id": event.event_id,
            "event_payload_hash": payload_hash,
        }

    def promote(
        self,
        version_id: str,
        *,
        rollback_version: str | None,
        approver: str,
        signature: str,
        field_experiment_id: str,
        policy_decision_id: str,
        policy_decision_hash: str,
        protected_surface_hash: str,
    ) -> dict[str, Any]:
        _require_codeowner(approver, "learning_promote")
        if not signature.strip():
            raise PermissionError("skill promotion requires a non-empty signature")
        version = self._version_or_raise(version_id)
        if str(version["status"]) != "candidate":
            raise ValueError("only candidate skill versions can be promoted")
        artifact_ref = str(version["artifact_ref"])
        if not self.runtime.artifacts.verify(artifact_ref):
            raise ValueError("candidate artifact does not verify")
        benchmark_id = str(version["benchmark_id"])
        evaluations = self.store.evaluations(version_id)
        if not any(
            bool(item.get("passed")) and str(item.get("split")) == f"benchmark:{benchmark_id}"
            for item in evaluations
        ):
            raise ValueError("skill promotion requires a passed matching benchmark evaluation")
        experiment = self.field_experiment_show(field_experiment_id)["experiment"]
        if str(experiment["candidate_version"]) != version_id:
            raise ValueError("field experiment candidate differs from promoted version")
        analysis = self.field_analyze(field_experiment_id)
        primary = analysis["primary_itt"]
        sensitivity = analysis["promotion_worst_case"]
        if (
            primary.get("status") != "verified"
            or Decimal(str(primary["mean_lift"])) < Decimal("0.05")
            or Decimal(str(primary["lower_lift"])) <= 0
            or sensitivity.get("status") != "verified"
            or Decimal(str(sensitivity["lower_lift"])) <= 0
            or not analysis["allocation"]["ok"]
            or analysis["critical_safety"]["critical_events"] != 0
        ):
            raise PermissionError("field experiment does not satisfy fixed promotion gates")
        policy_decision = self.policy.policy(policy_decision_id)
        if (
            policy_decision is None
            or str(policy_decision.get("status")) != "active"
            or str(policy_decision.get("decision_type")) != "learning_promotion"
            or str(policy_decision.get("version_id")) != version_id
        ):
            raise PermissionError("learning promotion lacks an active signed Policy decision")
        observed_policy_hash = (
            "sha256:"
            + hashlib.sha256(canonical_json(dict(policy_decision)).encode("utf-8")).hexdigest()
        )
        if observed_policy_hash != policy_decision_hash:
            raise PermissionError("learning promotion Policy decision hash differs")
        if str(policy_decision.get("protected_surface_hash")) != protected_surface_hash:
            raise PermissionError("learning promotion protected-surface hash differs from Policy")
        active = self.store.active_manifest()
        prior = active.get(str(version["skill_id"]))
        rollback_target = (rollback_version or prior or "none").strip()
        if rollback_target == "none":
            raise ValueError("learning promotion requires an exact rollback version")
        if rollback_target != "none":
            target = self._version_or_raise(rollback_target)
            if str(target["skill_id"]) != str(version["skill_id"]):
                raise ValueError("rollback_version must belong to the same skill")
            if not self.runtime.artifacts.verify(str(target["artifact_ref"])):
                raise ValueError("rollback artifact does not verify")
        approval_document = {
            "action": "learning_promote",
            "version_id": version_id,
            "approver": approver,
            "rollback_version": rollback_target,
            "field_experiment_id": field_experiment_id,
            "policy_decision_id": policy_decision_id,
            "policy_decision_hash": policy_decision_hash,
            "protected_surface_hash": protected_surface_hash,
        }
        require_approval_signature(
            self.runtime.root,
            signature,
            approval_document,
            expected_principal=approver,
            allow_test_provider=self._allow_development_driver,
        )
        approval = {
            "approved_by": approver,
            "benchmark_id": benchmark_id,
            "rollback_version": rollback_target,
            "signature": signature,
            "field_experiment_id": field_experiment_id,
            "policy_decision_id": policy_decision_id,
            "policy_decision_hash": policy_decision_hash,
            "protected_surface_hash": protected_surface_hash,
        }
        result = self.store.promote(version_id, approval=approval)
        promotion_id = (
            "promotion_" + stable_id(version_id, field_experiment_id, policy_decision_hash)[:32]
        )
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT INTO learning_promotion_decisions VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    promotion_id,
                    version_id,
                    field_experiment_id,
                    canonical_json(analysis),
                    policy_decision_id,
                    policy_decision_hash,
                    "active",
                    rollback_target,
                    utc_now(),
                ),
            )
        event, convergence = self._emit_activation(version, action="promoted", principal=approver)
        return {
            **dict(result),
            "schema_version": "persistmind.learning_promotion.v1",
            "approval": approval,
            "rollback_available": rollback_target != "none",
            "active_manifest": dict(self.store.active_manifest()),
            "storage_event_id": event.event_id,
            "convergence": convergence,
            "nextgen_v1": True,
        }

    def canary_evaluate(
        self,
        version_id: str,
        *,
        metrics: Mapping[str, Any],
        minimum_pass_rate: float = 0.95,
        maximum_regression: float = 0.02,
    ) -> dict[str, Any]:
        self._version_or_raise(version_id)
        normalized = _numeric_metrics(metrics)
        pass_rate = normalized.get("pass_rate", 0.0)
        regression = normalized.get("regression", 0.0)
        safety_violations = normalized.get("safety_violations", 0.0)
        passed = (
            pass_rate >= minimum_pass_rate
            and regression <= maximum_regression
            and safety_violations == 0
        )
        evaluation_id = (
            "canary_"
            + stable_id(
                version_id,
                canonical_json(normalized),
                str(minimum_pass_rate),
                str(maximum_regression),
            )[:32]
        )
        evaluation = self.store.record_evaluation(
            {
                "evaluation_id": evaluation_id,
                "version_id": version_id,
                "split": "canary:governed",
                "metrics": normalized,
                "passed": passed,
            }
        )
        self.store.put(
            {
                "record_id": "learning-canary-" + version_id,
                "kind": "learning_canary",
                "version_id": version_id,
                "passed": passed,
                "metrics": normalized,
                "thresholds": {
                    "minimum_pass_rate": minimum_pass_rate,
                    "maximum_regression": maximum_regression,
                    "maximum_safety_violations": 0,
                },
            },
            idempotency_key=f"learning-canary:{evaluation_id}",
        )
        return {
            "ok": passed,
            "status": "passed" if passed else "failed",
            "schema_version": "persistmind.learning_canary.v1",
            "evaluation": dict(evaluation),
            "nextgen_v1": True,
        }

    def propagate(
        self,
        version_id: str,
        *,
        targets: list[str],
        approver: str,
        signature: str,
    ) -> dict[str, Any]:
        _require_codeowner(approver, "learning_propagate")
        if not signature.strip():
            raise PermissionError("skill propagation requires a non-empty signature")
        require_approval_signature(
            self.runtime.root,
            signature,
            {
                "action": "learning_propagate",
                "version_id": version_id,
                "approver": approver,
                "targets": sorted({item.strip() for item in targets if item.strip()}),
            },
            expected_principal=approver,
            allow_test_provider=self._allow_development_driver,
        )
        version = self._version_or_raise(version_id)
        active = self.store.active_manifest()
        if active.get(str(version["skill_id"])) != version_id:
            raise ValueError("only the active skill version can propagate")
        canary = self.store.get("learning-canary-" + version_id)
        if canary is None or not bool(canary.get("passed")):
            raise ValueError("skill propagation requires a passed governed canary")
        normalized_targets = sorted({item.strip() for item in targets if item.strip()})
        if not normalized_targets or len(normalized_targets) > 100:
            raise ValueError("skill propagation requires 1 to 100 explicit targets")
        records = []
        for target in normalized_targets:
            record_id = "learning-propagation-" + stable_id(version_id, target)[:32]
            self.store.put(
                {
                    "record_id": record_id,
                    "kind": "learning_propagation",
                    "version_id": version_id,
                    "skill_id": version["skill_id"],
                    "target": target,
                    "artifact_ref": version["artifact_ref"],
                    "status": "applied",
                    "approved_by": approver,
                    "signature": signature,
                    "canary_record_id": canary["record_id"],
                },
                idempotency_key=f"learning-propagation:{version_id}:{target}",
            )
            records.append(dict(self.store.get(record_id) or {}))
        return {
            "ok": True,
            "status": "propagated",
            "schema_version": "persistmind.learning_propagation.v1",
            "version_id": version_id,
            "targets": normalized_targets,
            "records": records,
            "nextgen_v1": True,
        }

    def rollback(self, version_id: str, *, approver: str, signature: str) -> dict[str, Any]:
        _require_codeowner(approver, "learning_rollback")
        if not signature.strip():
            raise PermissionError("skill rollback requires a non-empty signature")
        require_approval_signature(
            self.runtime.root,
            signature,
            {
                "action": "learning_rollback",
                "version_id": version_id,
                "approver": approver,
            },
            expected_principal=approver,
            allow_test_provider=self._allow_development_driver,
        )
        target = self._version_or_raise(version_id)
        if not self.runtime.artifacts.verify(str(target["artifact_ref"])):
            raise ValueError("rollback artifact does not verify")
        active = self.store.active_manifest()
        current = active.get(str(target["skill_id"]))
        if current is None:
            raise ValueError("cannot roll back a skill with no active version")
        if str(target["status"]) not in {"active", "inactive"}:
            raise ValueError("rollback target must be a previously active skill version")
        approval = {"approved_by": approver, "signature": signature}
        result = self.store.rollback(version_id, approval=approval)
        with self.store._write_lock, self.store.connection:
            if current is not None:
                self.store.connection.execute(
                    "UPDATE learning_promotion_decisions SET state='rolled_back' "
                    "WHERE version_id=? AND state='active'",
                    (str(current),),
                )
        event, convergence = self._emit_activation(target, action="rolled_back", principal=approver)
        return {
            **dict(result),
            "schema_version": "persistmind.learning_rollback.v1",
            "approval": approval,
            "active_manifest": dict(self.store.active_manifest()),
            "storage_event_id": event.event_id,
            "convergence": convergence,
            "nextgen_v1": True,
        }

    def reconcile_activation_events(self, *, limit: int = 100) -> dict[str, Any]:
        audit = reconcile(
            self.outbox,
            "audit.append.v1",
            "v1",
            self._project_activation_audit,
            limit=limit,
        )
        activity = reconcile(
            self.outbox,
            "activity.ledger.v1",
            "v1",
            self._project_activation_activity,
            limit=limit,
        )
        return {
            "ok": audit.failed + activity.failed == 0,
            "scanned": audit.scanned + activity.scanned,
            "applied": audit.applied + activity.applied,
            "duplicates": audit.duplicates + activity.duplicates,
            "failed": audit.failed + activity.failed,
        }

    def _emit_activation(
        self, version: Mapping[str, Any], *, action: str, principal: str
    ) -> tuple[StorageEvent, dict[str, Any]]:
        event = StorageEvent(
            event_id="evt_"
            + stable_id("SkillActivated.v1", action, str(version["version_id"]))[:32],
            event_type="SkillActivated.v1",
            aggregate_id=str(version["skill_id"]),
            sequence=self.store.revision(),
            payload={
                "skill_id": version["skill_id"],
                "version_id": version["version_id"],
                "artifact_ref": version["artifact_ref"],
                "benchmark_id": version["benchmark_id"],
                "action": action,
                "principal": principal,
            },
            required_consumers=("activity.ledger.v1", "audit.append.v1"),
        )
        self.outbox.append(event)
        self.store.connection.commit()
        return event, self.reconcile_activation_events()

    def _project_activation_audit(self, event: StorageEvent) -> None:
        if event.event_type not in {"SkillActivated.v1", "LearningRetentionBaselineSet.v1"}:
            return
        self.audit.append_audit(
            {
                "audit_id": event.event_id,
                "correlation_id": event.aggregate_id,
                "kind": (
                    "skill_activated"
                    if event.event_type == "SkillActivated.v1"
                    else "learning_retention_baseline"
                ),
                "principal": event.payload.get("principal"),
                "payload": dict(event.payload),
            },
            idempotency_key=f"skill-audit:{event.event_id}",
        )

    def _project_activation_activity(self, event: StorageEvent) -> None:
        if event.event_type != "SkillActivated.v1":
            return
        self.activity.append(
            {
                "event_id": event.event_id,
                "event_type": "learning.skill_activated",
                "payload": dict(event.payload),
            },
            idempotency_key=f"skill-activity:{event.event_id}",
        )

    def learning_version_propose(self, **request: Any) -> dict[str, Any]:
        return self.version_propose(**request)

    def learning_evaluation_record(self, version_id: str, **request: Any) -> dict[str, Any]:
        return self.evaluation_record(version_id, **request)

    def learning_promote(self, version_id: str, **request: Any) -> dict[str, Any]:
        return self.promote(version_id, **request)

    def learning_canary_evaluate(self, version_id: str, **request: Any) -> dict[str, Any]:
        return self.canary_evaluate(version_id, **request)

    def learning_propagate(self, version_id: str, **request: Any) -> dict[str, Any]:
        return self.propagate(version_id, **request)

    def learning_rollback(self, version_id: str | None = None, **request: Any) -> dict[str, Any]:
        version_id = version_id or request.pop("target", None) or request.pop("run_id", None)
        if not version_id:
            raise ValueError("learning rollback requires a version_id")
        return self.rollback(version_id, **request)

    def learning_retention_baseline_set(self, **request: Any) -> dict[str, Any]:
        return self.retention_baseline_set(**request)

    def learning_retention_check(self, baseline_id: str) -> dict[str, Any]:
        return self.retention_check(baseline_id)

    def learning_verify_closure(self) -> dict[str, Any]:
        return self.verify_closure()

    def learning_loop_verify(
        self,
        task: str | None = None,
        *,
        probe: str | None = None,
        require_closure: bool = False,
    ) -> dict[str, Any]:
        closure = self.verify_closure()
        reconciliation = dict(self.store.reconciliation_health())
        return {
            "ok": bool(closure["ok"] and reconciliation["ok"]),
            "status": "verified"
            if closure["ok"] and reconciliation["ok"]
            else "projection_pending",
            "schema_version": "persistmind.learning_loop_verification.v1",
            "closure": closure,
            "reconciliation": reconciliation,
            "probe": {"task": task, "probe": probe, "require_closure": require_closure},
        }

    def bench(
        self,
        name: str = "learning",
        *,
        metrics: Mapping[str, Any] | None = None,
        artifact_version: str = "current",
        evaluator_hash: str = "builtin:learning-bench-v1",
        persist: bool | None = None,
        split: str | None = None,
    ) -> dict[str, Any]:
        metric_values = {
            key: value
            for key, value in dict(metrics or self.skill_metrics()).items()
            if isinstance(value, (int, float)) and not isinstance(value, bool)
        }
        metric_values.setdefault("versions", 0.0)
        record = self._feature_create(
            "learning_benchmark",
            {
                "name": name,
                "metrics": _numeric_metrics(metric_values),
                "artifact_version": artifact_version,
                "evaluator_hash": evaluator_hash,
                "persist_requested": persist,
                "split": split,
                "status": "recorded",
            },
        )
        return {
            "ok": True,
            "status": "recorded",
            "schema_version": "persistmind.benchmark.v1",
            "benchmark": record,
        }

    def bench_show(self, benchmark_id: str | None = None, *, limit: int = 100) -> dict[str, Any]:
        if benchmark_id:
            record = self.store.get(benchmark_id)
            return {
                "ok": record is not None,
                "status": "ok" if record is not None else "unidentifiable",
                "schema_version": "persistmind.benchmark_show.v1",
                "benchmark": dict(record) if record is not None else None,
            }
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.benchmark_show.v1",
            "benchmarks": self._feature_records("learning_benchmark")[-limit:],
        }

    def eval_harvest(
        self,
        version_id: str | None = None,
        project: str | None = None,
        limit: int = 1000,
    ) -> dict[str, Any]:
        del project
        if version_id and self.store.version(version_id) is None:
            version_id = None
        versions = (
            [self._version_or_raise(version_id)]
            if version_id
            else [dict(item) for item in self.store.versions(limit=limit)]
        )
        harvested = {
            str(item["version_id"]): [
                dict(value) for value in self.store.evaluations(str(item["version_id"]))
            ]
            for item in versions
        }
        return {
            "ok": True,
            "status": "harvested",
            "schema_version": "persistmind.evaluation_harvest.v1",
            "evaluations": harvested,
        }

    def eval_replay(
        self, version_id: str | int, holdout_ratio: float | None = None
    ) -> dict[str, Any]:
        del holdout_ratio
        version_id = self._resolve_version_reference(version_id)
        version = self._version_or_raise(version_id)
        evaluations = [dict(item) for item in self.store.evaluations(version_id)]
        digest = "sha256:" + hashlib.sha256(canonical_json(evaluations).encode("utf-8")).hexdigest()
        return {
            "ok": bool(evaluations),
            "status": "verified" if evaluations else "source_not_ready",
            "schema_version": "persistmind.evaluation_replay.v1",
            "version": dict(version),
            "evaluations": evaluations,
            "replay_hash": digest,
        }

    def eval_compare(self, baseline_version: str, candidate_version: str) -> dict[str, Any]:
        baseline = self._evaluation_means(baseline_version)
        candidate = self._evaluation_means(candidate_version)
        keys = sorted(set(baseline) | set(candidate))
        return {
            "ok": bool(keys),
            "status": "measured" if keys else "source_not_ready",
            "schema_version": "persistmind.evaluation_compare.v1",
            "baseline_version": baseline_version,
            "candidate_version": candidate_version,
            "baseline": baseline,
            "candidate": candidate,
            "deltas": {key: candidate.get(key, 0.0) - baseline.get(key, 0.0) for key in keys},
        }

    def eval_ab_baseline(
        self,
        version_id: str | int,
        *,
        metrics: Mapping[str, Any] | None = None,
        passed: bool = True,
    ) -> dict[str, Any]:
        return self.evaluation_record(
            self._resolve_version_reference(version_id),
            metrics=metrics or {"baseline": 0.0},
            passed=passed,
        )

    def eval_agent_benchmark(
        self,
        version_id: str,
        agent_command: str | None = None,
        *,
        metrics: Mapping[str, Any] | None = None,
        passed: bool | None = None,
        **legacy: Any,
    ) -> dict[str, Any]:
        if self.store.version(version_id) is None:
            return {
                "ok": True,
                "status": "candidate",
                "schema_version": "persistmind.agent_benchmark.v1",
                "request": self._feature_create(
                    "agent_benchmark_request",
                    {
                        "cases": version_id,
                        "agent_command": agent_command,
                        "parameters": legacy,
                        "status": "candidate",
                    },
                ),
            }
        result = self.evaluation_record(
            version_id,
            metrics=metrics or {"agent_pass": 1.0 if passed else 0.0},
            passed=bool(passed),
        )
        result["schema_version"] = "persistmind.agent_benchmark.v1"
        return result

    def eval_agent_gate(
        self, version_id: str, *, thresholds: Mapping[str, Any] | None = None
    ) -> dict[str, Any]:
        del thresholds
        if self.store.version(version_id) is None:
            return {
                "ok": False,
                "status": "source_not_ready",
                "schema_version": "persistmind.agent_evaluation_gate.v1",
                "version_id": version_id,
                "evaluations": [],
            }
        evaluations = list(self.store.evaluations(version_id))
        passed = bool(evaluations) and all(bool(item.get("passed")) for item in evaluations)
        return {
            "ok": passed,
            "status": "passed" if passed else "failed",
            "schema_version": "persistmind.agent_evaluation_gate.v1",
            "version_id": version_id,
            "evaluations": [dict(item) for item in evaluations],
        }

    def eval_components(self, version_id: str) -> dict[str, Any]:
        evaluations = list(self.store.evaluations(version_id))
        components: dict[str, list[float]] = {}
        for evaluation in evaluations:
            for name, value in dict(evaluation.get("metrics") or {}).items():
                if isinstance(value, (int, float)):
                    components.setdefault(str(name), []).append(float(value))
        return {
            "ok": bool(components),
            "status": "measured" if components else "source_not_ready",
            "schema_version": "persistmind.evaluation_components.v1",
            "components": {
                key: {"count": len(values), "mean": sum(values) / len(values)}
                for key, values in sorted(components.items())
            },
        }

    def eval_diagnose(self, version_id: str) -> dict[str, Any]:
        evaluations = [dict(item) for item in self.store.evaluations(version_id)]
        failed = [item for item in evaluations if not item.get("passed")]
        return {
            "ok": not failed and bool(evaluations),
            "status": "verified" if evaluations and not failed else "candidate",
            "schema_version": "persistmind.evaluation_diagnosis.v1",
            "version_id": version_id,
            "failed": failed,
            "hypotheses": [
                {
                    "split": item["split"],
                    "hypothesis": "Candidate underperforms on " + str(item["split"]),
                    "metrics": item["metrics"],
                }
                for item in failed
            ],
        }

    def eval_scorecard(self, version_id: str | None = None) -> dict[str, Any]:
        if not version_id or self.store.version(version_id) is None:
            versions = list(self.store.versions(limit=1))
            if not versions:
                return {
                    "ok": False,
                    "status": "source_not_ready",
                    "schema_version": "persistmind.evaluation_scorecard.v1",
                    "version_id": version_id,
                    "components": {},
                }
            version_id = str(versions[0]["version_id"])
        components = self.eval_components(version_id)
        gate = self.eval_agent_gate(version_id)
        return {
            "ok": gate["ok"],
            "status": gate["status"],
            "schema_version": "persistmind.evaluation_scorecard.v1",
            "version_id": version_id,
            "components": components["components"],
            "gate": gate,
        }

    def eval_run_efficacy(
        self, version_id: str, agent_command: str | None = None, **legacy: Any
    ) -> dict[str, Any]:
        if self.store.version(version_id) is None:
            return {
                "ok": True,
                "status": "candidate",
                "schema_version": "persistmind.evaluation_efficacy.v1",
                "request": self._feature_create(
                    "efficacy_evaluation_request",
                    {
                        "cases": version_id,
                        "agent_command": agent_command,
                        "parameters": legacy,
                        "status": "candidate",
                    },
                ),
            }
        return {
            **self.eval_scorecard(version_id),
            "schema_version": "persistmind.evaluation_efficacy.v1",
        }

    def eval_loop_verify(
        self,
        version_id: str | None = None,
        *,
        task: str | None = None,
        paths: Sequence[str] = (),
        result: str | None = None,
    ) -> dict[str, Any]:
        if not version_id:
            versions = list(self.store.versions(limit=1))
            if not versions:
                closure = self.verify_closure()
                return {
                    **closure,
                    "schema_version": "persistmind.evaluation_loop_verification.v1",
                    "probe": {"task": task, "paths": list(paths), "result": result},
                }
            version_id = str(versions[0]["version_id"])
        replay = self.eval_replay(version_id)
        gate = self.eval_agent_gate(version_id)
        return {
            "ok": bool(replay["ok"] and gate["ok"]),
            "status": "verified" if replay["ok"] and gate["ok"] else "candidate",
            "schema_version": "persistmind.evaluation_loop_verification.v1",
            "replay": replay,
            "gate": gate,
        }

    def eval_tune(
        self,
        version_id: str | int,
        holdout_ratio: float | None = None,
        *,
        search_space: Mapping[str, Sequence[Any]] | None = None,
    ) -> dict[str, Any]:
        del holdout_ratio
        version_id = self._resolve_version_reference(version_id)
        search_space = search_space or {}
        diagnosis = self.eval_diagnose(version_id)
        candidates = [
            {"parameter": name, "value": value, "status": "unevaluated"}
            for name, values in sorted(search_space.items())
            for value in values
        ]
        record = self._feature_create(
            "evaluation_tuning_proposal",
            {
                "version_id": version_id,
                "diagnosis": diagnosis,
                "candidates": candidates,
                "status": "candidate",
            },
        )
        return {
            "ok": True,
            "status": "candidate",
            "schema_version": "persistmind.evaluation_tuning.v1",
            "proposal": record,
        }

    def lesson_candidate(
        self,
        assertion: str,
        *,
        evidence: Sequence[Mapping[str, Any]] = (),
        scope: str = "workspace",
        rule_text: str | None = None,
        lesson_type: str | None = None,
    ) -> dict[str, Any]:
        assertion = rule_text or assertion
        if not evidence:
            evidence = (
                {
                    "source": "explicit_lesson_submission",
                    "content_hash": "sha256:"
                    + hashlib.sha256(assertion.encode("utf-8")).hexdigest(),
                    "lesson_type": lesson_type,
                },
            )
        if not assertion.strip() or not evidence:
            raise ValueError("lesson candidate requires an assertion and evidence")
        record = self._feature_create(
            "learning_lesson",
            {
                "assertion": assertion.strip(),
                "evidence": [dict(item) for item in evidence],
                "scope": scope,
                "status": "candidate",
            },
        )
        return {
            "ok": True,
            "status": "candidate",
            "schema_version": "persistmind.lesson_candidate.v1",
            "lesson": record,
        }

    def lesson_decide(
        self, lesson_id: str, *, decision: str, actor: str, reason: str
    ) -> dict[str, Any]:
        normalized = decision.strip().lower()
        if normalized not in {"accepted", "rejected"}:
            raise ValueError("lesson decision must be accepted or rejected")
        return self._feature_transition(lesson_id, normalized, actor=actor, reason=reason)

    def lesson_list(self, status: str | None = None) -> dict[str, Any]:
        rows = self._feature_records("learning_lesson", status=status)
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.lesson_list.v1",
            "lessons": rows,
        }

    def lesson_show(self, lesson_id: str) -> dict[str, Any]:
        record = self.store.get(lesson_id)
        return {
            "ok": record is not None,
            "status": str(record.get("status")) if record else "unidentifiable",
            "schema_version": "persistmind.lesson_show.v1",
            "lesson": dict(record) if record else None,
        }

    def judgment_propose(
        self,
        assertion: str = "Review observed Learning judgment candidate",
        *,
        evidence: Sequence[Mapping[str, Any]] = (),
        risk_class: str = "medium",
    ) -> dict[str, Any]:
        record = self._feature_create(
            "learning_judgment",
            {
                "assertion": assertion,
                "evidence": [dict(item) for item in evidence],
                "risk_class": risk_class,
                "status": "candidate",
            },
        )
        return {
            "ok": True,
            "status": "candidate",
            "schema_version": "persistmind.judgment_proposal.v1",
            "judgment": record,
        }

    def judgment_adopt(
        self,
        judgment_id: str,
        *,
        policy_decision_id: str = "",
        policy_decision_hash: str = "",
        actor: str,
        reason: str | None = None,
    ) -> dict[str, Any]:
        del reason
        policy = self.policy.policy(policy_decision_id)
        if policy is None or str(policy.get("status")) != "active":
            raise PermissionError("judgment adoption requires an active Policy decision")
        observed = (
            "sha256:" + hashlib.sha256(canonical_json(dict(policy)).encode("utf-8")).hexdigest()
        )
        if observed != policy_decision_hash:
            raise PermissionError("judgment Policy decision hash differs")
        return self._feature_transition(
            judgment_id,
            "policy_approved",
            actor=actor,
            reason="independent Policy approval",
            extra={
                "policy_decision_id": policy_decision_id,
                "policy_decision_hash": policy_decision_hash,
            },
        )

    def judgment_reject(
        self, judgment_id: str, *, reason: str, actor: str = "local-user"
    ) -> dict[str, Any]:
        return self._feature_transition(judgment_id, "rejected", actor=actor, reason=reason)

    def judgment_rollback(
        self, judgment_id: str, *, reason: str, actor: str = "local-user"
    ) -> dict[str, Any]:
        return self._feature_transition(judgment_id, "rolled_back", actor=actor, reason=reason)

    def judgment_list(self, status: str | None = None) -> dict[str, Any]:
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.judgment_list.v1",
            "judgments": self._feature_records("learning_judgment", status=status),
        }

    def judgment_status(self) -> dict[str, Any]:
        rows = self._feature_records("learning_judgment")
        counts: dict[str, int] = {}
        for item in rows:
            state = str(item.get("status") or "unknown")
            counts[state] = counts.get(state, 0) + 1
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.judgment_status.v1",
            "counts": counts,
        }

    def foresight_for(
        self,
        skill_id: str | None = None,
        *,
        paths: Sequence[str] = (),
        limit: int = 20,
        max_commits: int = 300,
    ) -> dict[str, Any]:
        del limit, max_commits
        if not skill_id:
            versions = list(self.store.versions(limit=1))
            if not versions:
                return {
                    "ok": True,
                    "status": "stable",
                    "schema_version": "persistmind.learning_foresight.v1",
                    "skill_id": None,
                    "paths": list(paths),
                    "hypotheses": [],
                }
            skill_id = str(versions[0]["skill_id"])
        versions = [dict(item) for item in self.store.versions(skill_id=skill_id, limit=100)]
        hypotheses = []
        for version in versions:
            failed = [
                dict(item)
                for item in self.store.evaluations(str(version["version_id"]))
                if not item.get("passed")
            ]
            if failed:
                hypotheses.append(
                    {
                        "version_id": version["version_id"],
                        "hypothesis": "Address observed failed evaluation strata before promotion.",
                        "failed_splits": [item["split"] for item in failed],
                    }
                )
        return {
            "ok": True,
            "status": "candidate" if hypotheses else "stable",
            "schema_version": "persistmind.learning_foresight.v1",
            "skill_id": skill_id,
            "hypotheses": hypotheses,
        }

    def flywheel_status(self) -> dict[str, Any]:
        versions = [dict(item) for item in self.store.versions(limit=1000)]
        return {
            "ok": True,
            "status": "stable",
            "schema_version": "persistmind.flywheel_status.v1",
            "candidate_versions": sum(item.get("status") == "candidate" for item in versions),
            "active_versions": sum(item.get("status") == "active" for item in versions),
            "failed_evaluations": sum(
                not evaluation.get("passed")
                for version in versions
                for evaluation in self.store.evaluations(str(version["version_id"]))
            ),
        }

    def flywheel_maintain(self) -> dict[str, Any]:
        status = self.flywheel_status()
        skill_ids = sorted(
            {
                str(item["skill_id"])
                for item in self.store.versions(limit=1000)
                if item.get("status") == "candidate"
            }
        )
        opportunities = [self.foresight_for(skill_id) for skill_id in skill_ids]
        return {
            "ok": True,
            "status": "stable" if not opportunities else "candidate",
            "schema_version": "persistmind.flywheel_maintenance.v1",
            "flywheel": status,
            "opportunities": opportunities,
        }

    def skill_artifact_register(
        self,
        skill_id: str,
        *,
        content: str | bytes,
        classification: str = "internal",
        artifact_kind: str | None = None,
        summary: str | None = None,
        structure: Mapping[str, Any] | None = None,
        session_id: str | None = None,
        task_session_id: str | None = None,
        output_id: str | None = None,
    ) -> dict[str, Any]:
        encoded = content.encode("utf-8") if isinstance(content, str) else bytes(content)
        artifact_ref = self.runtime.artifacts.put(encoded, classification=classification)
        record = self._feature_create(
            "skill_artifact",
            {
                "skill_id": skill_id,
                "artifact_ref": artifact_ref,
                "classification": classification,
                "bytes": len(encoded),
                "artifact_kind": artifact_kind,
                "summary": summary,
                "structure": dict(structure or {}),
                "session_id": session_id,
                "task_session_id": task_session_id,
                "output_id": output_id,
                "status": "registered",
            },
        )
        return {
            "ok": True,
            "status": "registered",
            "schema_version": "persistmind.skill_artifact.v1",
            "artifact": record,
        }

    def skill_induce(
        self,
        skill_id: str,
        *,
        content: str | None = None,
        benchmark_id: str = "skill-induction-v1",
        protected_surface_hash: str | None = None,
        parent_version_ids: Sequence[str] = (),
        proposer_identity: str = "learning-service",
    ) -> dict[str, Any]:
        content = content or canonical_json(
            {"source_session": skill_id, "kind": "declarative_skill_candidate"}
        )
        protected_surface_hash = protected_surface_hash or (
            "sha256:" + hashlib.sha256(content.encode("utf-8")).hexdigest()
        )
        proposed = self.version_propose(
            skill_id=skill_id, benchmark_id=benchmark_id, content=content
        )
        version_id = str(proposed["version"]["version_id"])
        edges = [
            self.candidate_lineage_add(
                version_id,
                parent_version_id=parent,
                relation="refinement",
                mutation_hash="sha256:" + hashlib.sha256(content.encode("utf-8")).hexdigest(),
                proposer_identity=proposer_identity,
                protected_surface_hash=protected_surface_hash,
            )
            for parent in parent_version_ids
        ]
        return {
            **proposed,
            "schema_version": "persistmind.skill_induction.v1",
            "lineage": edges,
        }

    def skill_list(self, status: str | None = None, *, trust: str | None = None) -> dict[str, Any]:
        del trust
        rows = [dict(item) for item in self.store.versions(limit=1000)]
        if status:
            rows = [item for item in rows if item.get("status") == status]
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.skill_list.v1",
            "versions": rows,
        }

    def skill_show(self, version_id: str) -> dict[str, Any]:
        return self.version_show(version_id)

    def skill_search(
        self,
        query: str,
        *,
        limit: int = 20,
        include_untrusted: bool = False,
    ) -> dict[str, Any]:
        del include_untrusted
        normalized = query.casefold()
        rows = [
            dict(item)
            for item in self.store.versions(limit=1000)
            if normalized in str(item.get("skill_id") or "").casefold()
            or normalized in str(item.get("benchmark_id") or "").casefold()
        ]
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.skill_search.v1",
            "query": query,
            "versions": rows[: max(1, min(int(limit), 1000))],
        }

    def skill_metrics(self, skill_id: str | None = None) -> dict[str, Any]:
        versions = [dict(item) for item in self.store.versions(skill_id=skill_id, limit=1000)]
        return {
            "ok": True,
            "status": "measured",
            "schema_version": "persistmind.skill_metrics.v1",
            "versions": len(versions),
            "evaluations": sum(
                len(self.store.evaluations(str(item["version_id"]))) for item in versions
            ),
            "passed": sum(
                bool(evaluation.get("passed"))
                for item in versions
                for evaluation in self.store.evaluations(str(item["version_id"]))
            ),
        }

    def skill_improvements(
        self, skill_id: str | None = None, *, status: str | None = None
    ) -> dict[str, Any]:
        del status
        if skill_id:
            return self.foresight_for(skill_id)
        return {
            "ok": True,
            "status": "candidate",
            "schema_version": "persistmind.skill_improvements.v1",
            "skills": sorted({str(item["skill_id"]) for item in self.store.versions(limit=1000)}),
        }

    def skill_maintain(
        self,
        skill_id: str | None = None,
        *,
        max_failures: int | None = None,
        stale_after_days: int | None = None,
    ) -> dict[str, Any]:
        del max_failures, stale_after_days
        metrics = self.skill_metrics(skill_id)
        closure = self.verify_closure()
        return {
            "ok": closure["ok"],
            "status": "stable" if closure["ok"] else "candidate",
            "schema_version": "persistmind.skill_maintenance.v1",
            "metrics": metrics,
            "closure": closure,
        }

    def skill_prune(
        self,
        version_id: str | None = None,
        *,
        actor: str = "maintenance",
        max_failures: int | None = None,
    ) -> dict[str, Any]:
        del max_failures
        if version_id is None:
            return {
                "ok": True,
                "status": "candidate",
                "schema_version": "persistmind.skill_prune.v1",
                "eligible": [
                    dict(item)
                    for item in self.store.versions(limit=1000)
                    if item.get("status") in {"inactive", "rejected"}
                ],
                "artifact_preserved": True,
            }
        active = self.store.active_manifest()
        version = self._version_or_raise(version_id)
        if active.get(str(version["skill_id"])) == version_id:
            raise PermissionError("active skill versions cannot be pruned")
        transitioned = self.store.transition_version(
            version_id,
            to_state="inactive",
            actor=actor,
            reason="retention archival candidate",
        )
        return {
            "ok": True,
            "status": "inactive",
            "schema_version": "persistmind.skill_prune.v1",
            "version": dict(transitioned),
            "artifact_preserved": True,
        }

    def skill_reject(
        self, version_id: str, *, reason: str, actor: str = "local-user"
    ) -> dict[str, Any]:
        transitioned = self.store.transition_version(
            version_id, to_state="rejected", actor=actor, reason=reason
        )
        return {
            "ok": True,
            "status": "rejected",
            "schema_version": "persistmind.skill_rejection.v1",
            "version": dict(transitioned),
        }

    def skill_accept_first_pass(
        self, version_id: str, *, actor: str = "local-user"
    ) -> dict[str, Any]:
        gate = self.eval_agent_gate(version_id)
        if not gate["ok"]:
            raise PermissionError("first-pass acceptance requires all recorded evaluations to pass")
        record = self._feature_create(
            "skill_first_pass",
            {"version_id": version_id, "actor": actor, "status": "accepted"},
        )
        return {
            "ok": True,
            "status": "accepted",
            "schema_version": "persistmind.skill_first_pass.v1",
            "record": record,
            "activation": "requires_field_experiment_and_policy",
        }

    def skill_replay(self, version_id: str, *, timeout: int | None = None) -> dict[str, Any]:
        del timeout
        return {
            **self.eval_replay(version_id),
            "schema_version": "persistmind.skill_replay.v1",
        }

    def skill_refinement_benchmark(
        self, baseline_version: str, candidate_version: str | None = None
    ) -> dict[str, Any]:
        candidate_version = candidate_version or baseline_version
        return {
            **self.eval_compare(baseline_version, candidate_version),
            "schema_version": "persistmind.skill_refinement_benchmark.v1",
        }

    def skill_revision_capture(
        self,
        version_id: str | None = None,
        *,
        changes: Mapping[str, Any] | None = None,
        actor: str = "local-user",
        revision_text: str | None = None,
        output_id: str | None = None,
        skill_id: str | None = None,
        session_id: str | None = None,
        task_session_id: str | None = None,
        signal_kind: str | None = None,
    ) -> dict[str, Any]:
        if version_id is None:
            versions = list(self.store.versions(skill_id=skill_id, limit=1))
            if not versions:
                raise KeyError("skill revision requires an existing Learning version")
            version_id = str(versions[0]["version_id"])
        self._version_or_raise(version_id)
        changes = dict(changes or {"revision_text": revision_text or ""})
        record = self._feature_create(
            "skill_revision",
            {
                "version_id": version_id,
                "changes": dict(changes),
                "actor": actor,
                "output_id": output_id,
                "session_id": session_id,
                "task_session_id": task_session_id,
                "signal_kind": signal_kind,
                "status": "captured",
            },
        )
        return {
            "ok": True,
            "status": "captured",
            "schema_version": "persistmind.skill_revision_capture.v1",
            "revision": record,
        }

    def skill_revision_classify(
        self, revision_id: str, *, skill_id: str | None = None
    ) -> dict[str, Any]:
        del skill_id
        revision = self.store.get(revision_id)
        if revision is None or revision.get("kind") != "skill_revision":
            raise KeyError(f"skill revision not found: {revision_id}")
        changes = dict(revision.get("changes") or {})
        protected = any(
            str(key).startswith(("policy", "audit", "evaluator", "release", "key", "kill"))
            for key in changes
        )
        classification = "protected_surface" if protected else "declarative"
        return {
            "ok": not protected,
            "status": "unsafe" if protected else "candidate",
            "schema_version": "persistmind.skill_revision_classification.v1",
            "revision_id": revision_id,
            "classification": classification,
        }

    def skill_closure_verify(self, skill_id: str | None = None) -> dict[str, Any]:
        del skill_id
        return {
            **self.verify_closure(),
            "schema_version": "persistmind.skill_closure.v1",
        }

    def team_lesson_export(
        self,
        output: str | Path,
        scope: str | None = None,
        actor: str | None = None,
        *,
        status: str = "accepted",
    ) -> dict[str, Any]:
        target = Path(output)
        lesson_id: str | None = None
        if self.store.get(str(output)) is not None:
            lesson_id = str(output)
            target = Path(".persistmind") / "exports" / f"{lesson_id}.json"
        if not target.is_absolute():
            target = self.repo_root / target
        target = target.resolve()
        if not target.is_relative_to(self.repo_root):
            raise ValueError("team lesson export must stay inside the repository")
        lessons = self._feature_records("learning_lesson", status=status)
        if lesson_id:
            lessons = [item for item in lessons if item.get("record_id") == lesson_id]
        payload = {
            "schema_version": "persistmind.team_lesson_exchange.v1",
            "lessons": [
                {
                    "assertion_hash": "sha256:"
                    + hashlib.sha256(str(item.get("assertion", "")).encode()).hexdigest(),
                    "assertion": item.get("assertion"),
                    "evidence_hashes": sorted(
                        str(value.get("content_hash") or "") for value in item.get("evidence", [])
                    ),
                    "scope": item.get("scope"),
                    "requested_scope": scope,
                    "exported_by": actor,
                }
                for item in lessons
            ],
        }
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return {
            "ok": True,
            "status": "exported",
            "schema_version": "persistmind.team_lesson_export.v1",
            "path": str(target),
            "count": len(lessons),
        }

    def team_lesson_import(
        self, path: str | Path, payload_override: Mapping[str, Any] | None = None
    ) -> dict[str, Any]:
        source = Path(path)
        if not source.is_absolute():
            source = self.repo_root / source
        source = source.resolve()
        if not source.is_relative_to(self.repo_root):
            raise ValueError("team lesson import must stay inside the repository")
        payload = (
            dict(payload_override)
            if payload_override is not None
            else json.loads(source.read_text(encoding="utf-8"))
        )
        rows = payload.get("lessons", []) if isinstance(payload, dict) else []
        imported = [
            self._feature_create(
                "team_lesson_import",
                {"lesson": dict(item), "source": str(source), "status": "quarantined"},
            )
            for item in rows
            if isinstance(item, Mapping)
        ]
        return {
            "ok": True,
            "status": "quarantined",
            "schema_version": "persistmind.team_lesson_import.v1",
            "imports": imported,
        }

    def team_lesson_import_decide(
        self,
        import_id: str,
        *,
        decision: str,
        target_evidence: Sequence[Mapping[str, Any]],
        actor: str,
    ) -> dict[str, Any]:
        normalized = decision.strip().lower()
        if normalized == "accepted" and not target_evidence:
            raise ValueError("cross-project lesson acceptance requires target-project evidence")
        if normalized not in {"accepted", "rejected"}:
            raise ValueError("import decision must be accepted or rejected")
        return self._feature_transition(
            import_id,
            normalized,
            actor=actor,
            reason="target-project lesson review",
            extra={"target_evidence": [dict(item) for item in target_evidence]},
        )

    def loop_runbook(
        self,
        task: str | None = None,
        paths: Sequence[str] = (),
        *,
        tests: Sequence[str] = (),
        result: str | None = None,
    ) -> dict[str, Any]:
        return {
            "ok": True,
            "status": "ready",
            "schema_version": "persistmind.learning_loop_runbook.v1",
            "steps": [
                "propose_candidate",
                "record_matching_benchmark",
                "obtain_policy_protocol",
                "run_field_experiment",
                "freeze_and_analyze",
                "request_policy_promotion",
                "promote_or_reject",
                "verify_retention_and_closure",
            ],
            "request": {
                "task": task,
                "paths": list(paths),
                "tests": list(tests),
                "result": result,
            },
        }

    def _self_evolution(self) -> Any:
        from .self_evolution import LearningSelfEvolution

        return LearningSelfEvolution(self)

    def self_improve_status(self) -> dict[str, Any]:
        return self._self_evolution().status()

    def self_improve_audit(
        self, *, force: bool = False, actor: str = "learning-observer"
    ) -> dict[str, Any]:
        return self._self_evolution().audit(force=force, actor=actor)

    def self_improve_brief(self, *, force: bool = False) -> dict[str, Any]:
        if force:
            raise PermissionError("self_improve_brief is query-pure; run self_improve_audit first")
        return self._self_evolution().brief()

    def self_improve_capture(self, **request: Any) -> dict[str, Any]:
        return self._self_evolution().capture(**request)

    def self_improve_evaluate(self, proposal_id: str, **request: Any) -> dict[str, Any]:
        return self._self_evolution().evaluate(proposal_id, **request)

    def self_improve_adopt(self, proposal_id: str, **request: Any) -> dict[str, Any]:
        return self._self_evolution().adopt(proposal_id, **request)

    def self_improve_reject(self, proposal_id: str, **request: Any) -> dict[str, Any]:
        return self._self_evolution().reject(proposal_id, **request)

    def self_improve_rollback(self, proposal_id: str, **request: Any) -> dict[str, Any]:
        return self._self_evolution().rollback(proposal_id, **request)

    def self_improve_archive(
        self, *, run_id: str | None = None, status: str | None = None, limit: int = 50
    ) -> dict[str, Any]:
        return self._self_evolution().archive(run_id=run_id, status=status, limit=limit)

    def self_improve_list(
        self, *, run_id: str | None = None, status: str | None = None, limit: int = 50
    ) -> dict[str, Any]:
        return self.self_improve_archive(run_id=run_id, status=status, limit=limit)

    def self_improve_show(self, proposal_id: str) -> dict[str, Any]:
        return self._self_evolution().show(proposal_id)

    def self_improve_lineage(
        self, *, proposal_id: str | None = None, limit: int = 100
    ) -> dict[str, Any]:
        return self._self_evolution().lineage(proposal_id=proposal_id, limit=limit)

    def self_improve_run(self, **request: Any) -> dict[str, Any]:
        return self._self_evolution().run(**request)

    def self_improve_doctor(self) -> dict[str, Any]:
        return self._self_evolution().doctor()

    def self_improve_verify_safety(
        self,
        *,
        policy_decision_id: str | None = None,
        confirm: bool | None = None,
    ) -> dict[str, Any]:
        del confirm
        return self._self_evolution().verify_safety(policy_decision_id=policy_decision_id)

    def learning_optimize(self, target: str = "learning", **request: Any) -> dict[str, Any]:
        return self._self_evolution().optimize(target, **request)

    def learning_selfmod_propose(
        self, target: str, *, weakness: str = "", ancestor_run_id: str | None = None
    ) -> dict[str, Any]:
        return self._self_evolution().selfmod_propose(
            target, weakness=weakness, ancestor_run_id=ancestor_run_id
        )

    def learning_selfmod_archive(
        self, target: str | None = None, *, limit: int = 20
    ) -> dict[str, Any]:
        result = self._self_evolution().archive(limit=limit)
        if target:
            result["proposals"] = [
                item for item in result["proposals"] if target in item.get("target_files", [])
            ]
        return result

    def learning_selfmod_adopt(
        self, proposal_id: str, *, approved_by: str = "local-user"
    ) -> dict[str, Any]:
        return self._self_evolution().selfmod_adopt(proposal_id, approved_by=approved_by)

    def learning_selfmod_reject(
        self,
        proposal_id: str,
        *,
        reason: str,
        actor: str = "local-user",
    ) -> dict[str, Any]:
        return self._self_evolution().reject(proposal_id, reason=reason, actor=actor)

    def learning_selfmod_revert(
        self, proposal_id: str, *, reason: str = "governed rollback"
    ) -> dict[str, Any]:
        return self._self_evolution().selfmod_revert(proposal_id, reason=reason)

    def learning_selfmod_show(self, proposal_id: str) -> dict[str, Any]:
        return self._self_evolution().show(proposal_id)

    def _feature_create(self, kind: str, payload: Mapping[str, Any]) -> dict[str, Any]:
        document = dict(payload)
        record_id = kind + "_" + stable_id(kind, canonical_json(document))[:32]
        document.update(
            {
                "record_id": record_id,
                "kind": kind,
                "scope": str(document.get("scope") or "workspace"),
                "created_at": document.get("created_at") or utc_now(),
            }
        )
        self.store.put(document, idempotency_key=kind + ":" + record_id)
        return dict(self.store.get(record_id) or document)

    def _feature_records(self, kind: str, status: str | None = None) -> list[dict[str, Any]]:
        rows = [
            dict(item)
            for item in self.store.search(f'"kind":"{kind}"', limit=10_000)
            if item.get("kind") == kind and (status is None or item.get("status") == status)
        ]
        rows.sort(key=lambda item: (str(item.get("created_at") or ""), str(item["record_id"])))
        return rows

    def _feature_transition(
        self,
        record_id: str,
        state: str,
        *,
        actor: str,
        reason: str,
        extra: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        current = self.store.get(record_id)
        if current is None:
            raise KeyError(f"Learning record not found: {record_id}")
        transition = self._feature_create(
            "learning_feature_transition",
            {
                "subject_id": record_id,
                "from_state": current.get("status"),
                "to_state": state,
                "actor": actor,
                "reason": reason,
                **dict(extra or {}),
            },
        )
        document = {key: value for key, value in current.items() if not str(key).startswith("_")}
        document.update({"status": state, "latest_transition_id": transition["record_id"]})
        self.store.put(document)
        return {
            "ok": True,
            "status": state,
            "schema_version": "persistmind.learning_feature_transition.v1",
            "record": dict(self.store.get(record_id) or {}),
            "transition": transition,
        }

    def _evaluation_means(self, version_id: str) -> dict[str, float]:
        self._version_or_raise(version_id)
        values: dict[str, list[float]] = {}
        for evaluation in self.store.evaluations(version_id):
            for key, value in dict(evaluation.get("metrics") or {}).items():
                if isinstance(value, (int, float)):
                    values.setdefault(str(key), []).append(float(value))
        return {key: sum(items) / len(items) for key, items in sorted(values.items()) if items}

    def _version_or_raise(self, version_id: str) -> Mapping[str, Any]:
        version = self.store.version(version_id)
        if version is None:
            raise KeyError(f"skill version not found: {version_id}")
        return version

    def _resolve_version_reference(self, version_id: str | int) -> str:
        candidate = str(version_id)
        if self.store.version(candidate) is not None:
            return candidate
        versions = list(self.store.versions(limit=1))
        if not versions:
            raise KeyError("no Learning version is available for evaluation")
        return str(versions[0]["version_id"])


def _numeric_metrics(metrics: Mapping[str, Any]) -> dict[str, float]:
    if not metrics:
        raise ValueError("evaluation metrics must not be empty")
    normalized: dict[str, float] = {}
    for key, value in metrics.items():
        try:
            number = float(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"evaluation metric {key} must be numeric") from exc
        if not math.isfinite(number):
            raise ValueError(f"evaluation metric {key} must be finite")
        normalized[str(key)] = number
    return normalized


def _require_codeowner(actor: str, action: str) -> None:
    authorization = require_actor_role(actor, "codeowner", action)
    if not authorization["ok"]:
        raise PermissionError(
            f"{action} requires {authorization['required_role']} role; "
            f"{authorization['actor']} is {authorization['actor_role']}"
        )
