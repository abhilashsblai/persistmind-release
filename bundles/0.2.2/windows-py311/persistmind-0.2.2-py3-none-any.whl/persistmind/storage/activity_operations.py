from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from persistmind.config import load_settings
from persistmind.utils import canonical_json, stable_id, utc_now

from .adapters.sqlite_activity import SQLiteActivityStore, _redact
from .descriptors import StoreRole
from .runtime import StorageOpenIntent, StorageRuntime, resolve_runtime_store


class ActivityOperations:
    """Activity-owned append-only observations that need no cross-authority dependency."""

    def __init__(self, repo_root: Path, *, read_only: bool = False) -> None:
        self.repo_root = repo_root.resolve()
        settings = load_settings(self.repo_root)
        self.runtime = StorageRuntime.open(
            self.repo_root / settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            read_only=read_only,
            required_roles=frozenset({StoreRole.ACTIVITY_ACTIVE}),
        )
        store = resolve_runtime_store(self.runtime, StoreRole.ACTIVITY_ACTIVE, read_only=read_only)
        if not isinstance(store, SQLiteActivityStore):
            raise RuntimeError("Activity write route is invalid")
        self.store = store

    def close(self) -> None:
        self.runtime.close()

    def feedback(
        self,
        category: str,
        message: str | None = None,
        *,
        correlation_id: str | None = None,
        severity: str = "info",
        metadata: Mapping[str, Any] | None = None,
        rating: str | int | float | None = None,
        reason: str | None = None,
        summary: str | None = None,
    ) -> dict[str, Any]:
        message = message or summary or reason or f"feedback rating={rating}"
        metadata = {**dict(metadata or {}), "rating": rating, "reason": reason}
        normalized_category = category.strip().lower()
        normalized_message = message.strip()
        if not normalized_category or not normalized_message:
            raise ValueError("feedback requires a category and message")
        if severity not in {"info", "warning", "error", "critical"}:
            raise ValueError("invalid feedback severity")
        payload = _redact(
            {
                "category": normalized_category,
                "message": normalized_message,
                "correlation_id": correlation_id,
                "severity": severity,
                "metadata": dict(metadata or {}),
            }
        )
        event_id = "feedback_" + stable_id(canonical_json(payload))[:32]
        self.store.append(
            {
                "event_id": event_id,
                "event_type": "feedback.recorded",
                "occurred_at": utc_now(),
                "payload": payload,
            },
            idempotency_key="feedback:" + event_id,
        )
        return {
            "ok": True,
            "status": "recorded",
            "schema_version": "persistmind.feedback.v1",
            "event_id": event_id,
        }
