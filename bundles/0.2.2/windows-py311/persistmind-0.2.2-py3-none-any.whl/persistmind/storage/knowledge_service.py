from __future__ import annotations

import fnmatch
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from persistmind.config import load_settings
from persistmind.application.execution_scope import current_operation_scope
from persistmind.application.epistemics import CLAIM_STATUSES, normalize_epistemic_claim
from persistmind.security.memory_defense import (
    detect_query_injection,
    evaluate_ingest,
    require_actor_role,
    serve_decision,
    trust_aware_rank,
)
from persistmind.utils import canonical_json, sha256_text, stable_id, utc_now

from .adapters.sqlite_knowledge import KnowledgeConflict as _KnowledgeConflict
from .adapters.sqlite_knowledge import SQLiteKnowledgeStore
from .adapters.sqlite_policy import SQLitePolicyStore
from .descriptors import StoreRole
from .resources import load_memory_kinds
from .runtime import StorageOpenIntent, StorageRuntime, resolve_runtime_store

KnowledgeConflict = _KnowledgeConflict

_CLAIM_TRANSITIONS = {
    "candidate": {"supported", "refuted", "contested", "rejected", "quarantined", "unknown"},
    "supported": {"contested", "refuted", "stale", "superseded", "expired", "quarantined"},
    "refuted": {"contested", "superseded", "expired"},
    "contested": {"supported", "refuted", "stale", "superseded", "expired", "quarantined"},
    "stale": {"candidate", "supported", "refuted", "superseded", "expired"},
    "unknown": {"candidate", "supported", "refuted", "contested", "expired"},
    "quarantined": {"candidate", "rejected", "expired"},
    "superseded": set(),
    "expired": set(),
    "rejected": set(),
}


_TERMINAL_MEMORY_STATUSES = {
    "rejected",
    "expired",
    "quarantined",
    "needs_review",
    "superseded",
}
_ALLOWED_MEMORY_STATUSES = _TERMINAL_MEMORY_STATUSES | {
    "candidate",
    "active",
    "approved",
}
_SENSITIVE_MEMORY_TYPES = {
    "business_rule_candidate",
    "policy_reference",
    "preference",
    "org_knowledge",
}
_KNOWLEDGE_MEMORY_TYPES = {
    "fact",
    "decision",
    "episode",
    "architectural_decision",
    "convention",
    "preference",
    "gotcha",
    "failure_lesson",
    "pattern",
    "policy_reference",
    "business_rule_candidate",
    "org_knowledge",
    "org_knowledge_candidate",
}
_TYPE_METADATA_REQUIREMENTS: dict[str, dict[str, str]] = {
    "architectural_decision": {
        "rationale": "non_empty_string",
        "alternatives": "non_empty_list",
    },
    "decision": {"rationale": "non_empty_string", "alternatives": "non_empty_list"},
    "failure_lesson": {
        "symptom": "non_empty_string",
        "root_cause": "non_empty_string",
        "resolution": "non_empty_string",
    },
    "policy_reference": {
        "policy_file": "non_empty_string",
        "policy_key": "non_empty_string",
    },
    "preference": {"priority": "priority"},
}


class KnowledgeService:
    """Knowledge and Policy Authority application port for an active next-generation catalog.

    This port owns canonical facts, decisions, evidence, provenance, lifecycle
    history, and non-authoritative business-rule candidates in the Knowledge
    role.  Policy activation is deliberately a separate operation against the
    Policy Authority role. No method can cross the declared authority routes.
    """

    def __init__(
        self,
        repo_root: Path,
        *,
        allow_development_driver: bool = False,
        runtime: StorageRuntime | None = None,
        read_only: bool = False,
    ) -> None:
        self.repo_root = repo_root.resolve()
        self.settings = load_settings(self.repo_root)
        self._allow_development_driver = allow_development_driver
        self.workspace_id = stable_id(str(self.repo_root))[:16]
        self.repo_id = self.workspace_id
        self._owns_runtime = runtime is None
        operation_scope = current_operation_scope()
        required_roles = (
            frozenset(StoreRole(role) for role in operation_scope.roles)
            if operation_scope is not None
            else frozenset({StoreRole.KNOWLEDGE, StoreRole.POLICY})
        ) | {StoreRole.KNOWLEDGE}
        self.runtime = runtime or StorageRuntime.open(
            self.repo_root / self.settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=allow_development_driver,
            read_only=read_only,
            required_roles=required_roles,
        )
        knowledge = resolve_runtime_store(self.runtime, StoreRole.KNOWLEDGE, read_only=read_only)
        if not isinstance(knowledge, SQLiteKnowledgeStore):
            raise RuntimeError("Knowledge route did not resolve to SQLiteKnowledgeStore")
        self.knowledge = knowledge
        self._policy: SQLitePolicyStore | None = None

    def close(self) -> None:
        if self._owns_runtime:
            self.runtime.close()

    def __enter__(self) -> "KnowledgeService":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    @property
    def policy(self) -> SQLitePolicyStore:
        if self._policy is None:
            value = resolve_runtime_store(self.runtime, StoreRole.POLICY, read_only=True)
            if not isinstance(value, SQLitePolicyStore):
                raise RuntimeError("Policy read route did not resolve")
            self._policy = value
        return self._policy

    # -- Knowledge records -------------------------------------------------

    def claim_create(
        self, payload: Mapping[str, Any], *, actor: str = "local-user"
    ) -> dict[str, Any]:
        raw = dict(payload)
        source_class = str(raw.get("source_class") or "human_decision")
        external = source_class in {
            "external_report",
            "prompt",
            "tool_output",
            "connector",
        }
        defense = evaluate_ingest(
            str(raw.get("proposition") or ""),
            actor=actor,
            source_connector=source_class if external else None,
            external=external,
        )
        if external:
            raw["proposition"] = defense["sanitized_text"]
            raw["status"] = "candidate" if defense["ok"] else "quarantined"
            raw["source_identity"] = {
                **dict(raw.get("source_identity") or {}),
                "untrusted": True,
                "serve_authoritative": False,
                "defense": defense,
            }
        claim = normalize_epistemic_claim(
            raw,
            workspace_id=self.workspace_id,
            repository_id=self.repo_id,
        )
        record = self.knowledge.write_claim(
            claim,
            actor=actor,
            reason="claim created",
            expected_revision=0,
        )
        evidence_ids = self._put_evidence(str(claim["claim_id"]), payload.get("evidence"))
        return {
            "ok": True,
            "status": str(claim["status"]),
            "schema_version": "persistmind.epistemic_claim.v1",
            "claim": dict(record),
            "evidence_ids": evidence_ids,
            "defense": defense,
        }

    def claim_transition(
        self,
        claim_id: str,
        *,
        status: str,
        actor: str,
        reason: str,
        updates: Mapping[str, Any] | None = None,
        expected_revision: int | None = None,
    ) -> dict[str, Any]:
        current = self.knowledge.get(claim_id)
        if current is None or str(current.get("kind")) != "epistemic_claim":
            raise KeyError(f"epistemic claim not found: {claim_id}")
        normalized_status = status.strip().lower()
        if normalized_status not in CLAIM_STATUSES:
            raise ValueError(f"unsupported epistemic claim status: {status}")
        current_status = str(current.get("status") or "unknown")
        if (
            normalized_status != current_status
            and normalized_status not in _CLAIM_TRANSITIONS[current_status]
        ):
            raise ValueError(
                f"invalid epistemic claim transition: {current_status} -> {normalized_status}"
            )
        if normalized_status in {"supported", "refuted"} and not self.knowledge.evidence(claim_id):
            raise ValueError(f"claim status {normalized_status} requires immutable evidence")
        document = {
            key: value
            for key, value in current.items()
            if not str(key).startswith("_") and key not in {"record_id", "kind", "scope"}
        }
        document.update(dict(updates or {}))
        document.update(
            {
                "claim_id": claim_id,
                "status": normalized_status,
                "revision": int(current["_revision"]) + 1,
            }
        )
        claim = normalize_epistemic_claim(
            document,
            workspace_id=self.workspace_id,
            repository_id=self.repo_id,
        )
        record = self.knowledge.write_claim(
            claim,
            actor=actor,
            reason=reason,
            expected_revision=(
                expected_revision if expected_revision is not None else int(current["_revision"])
            ),
        )
        return {
            "ok": True,
            "status": normalized_status,
            "schema_version": "persistmind.epistemic_claim_transition.v1",
            "claim": dict(record),
        }

    def claim_relation_add(
        self,
        subject_id: str,
        predicate: str,
        object_id: str,
        *,
        evidence_id: str | None = None,
        support_score: float | None = None,
        valid_from: str | None = None,
        valid_to: str | None = None,
    ) -> dict[str, Any]:
        for claim_id in (subject_id, object_id):
            claim = self.knowledge.get(claim_id)
            if claim is None or str(claim.get("kind")) != "epistemic_claim":
                raise KeyError(f"epistemic claim not found: {claim_id}")
        if support_score is not None and not 0 <= float(support_score) <= 1:
            raise ValueError("relation support_score must be between 0 and 1")
        relation_id = (
            "relation_"
            + stable_id(subject_id, predicate, object_id, evidence_id or "", valid_from or "")[:32]
        )
        with self.knowledge._write_lock, self.knowledge.connection:
            self.knowledge.connection.execute(
                "INSERT OR IGNORE INTO knowledge_claim_relations VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    relation_id,
                    subject_id,
                    predicate,
                    object_id,
                    evidence_id,
                    support_score,
                    valid_from or utc_now(),
                    valid_to,
                    utc_now(),
                ),
            )
            self.knowledge.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return {"ok": True, "relation_id": relation_id}

    def forecast_create(
        self,
        claim_id: str,
        *,
        probability: float,
        calibrator_id: str,
        stratum: str,
        context: Mapping[str, Any],
        resolves_by: str,
        support_score: float | None = None,
    ) -> dict[str, Any]:
        if self.knowledge.get(claim_id) is None:
            raise KeyError(f"epistemic claim not found: {claim_id}")
        if not 0 <= probability <= 1 or (support_score is not None and not 0 <= support_score <= 1):
            raise ValueError("forecast probability and support score must be between 0 and 1")
        context_hash = "sha256:" + sha256_text(canonical_json(dict(context)))
        predicted_at = utc_now()
        forecast_id = (
            "forecast_"
            + stable_id(claim_id, calibrator_id, stratum, context_hash, predicted_at)[:32]
        )
        with self.knowledge._write_lock, self.knowledge.connection:
            self.knowledge.connection.execute(
                "INSERT INTO knowledge_forecasts VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    forecast_id,
                    claim_id,
                    probability,
                    support_score,
                    calibrator_id,
                    stratum,
                    context_hash,
                    predicted_at,
                    resolves_by,
                ),
            )
        return {"ok": True, "forecast_id": forecast_id, "context_hash": context_hash}

    def forecast_observe(
        self,
        forecast_id: str,
        *,
        outcome: bool,
        evidence_id: str,
        observed_at: str | None = None,
    ) -> dict[str, Any]:
        with self.knowledge._write_lock, self.knowledge.connection:
            self.knowledge.connection.execute(
                "INSERT INTO knowledge_forecast_outcomes VALUES(?,?,?,?)",
                (forecast_id, int(outcome), evidence_id, observed_at or utc_now()),
            )
        return {"ok": True, "forecast_id": forecast_id, "outcome": bool(outcome)}

    def claim_show(
        self,
        claim_id: str,
        *,
        valid_at: str | None = None,
        transaction_at: str | None = None,
    ) -> dict[str, Any]:
        revisions = [dict(item) for item in self.knowledge.claim_revisions(claim_id)]
        candidates = revisions
        if transaction_at:
            candidates = [
                item for item in candidates if str(item.get("recorded_at") or "") <= transaction_at
            ]
        if valid_at:
            candidates = [
                item
                for item in candidates
                if str(item.get("valid_from") or "") <= valid_at
                and (item.get("valid_to") is None or str(item.get("valid_to")) >= valid_at)
            ]
        claim = candidates[-1] if candidates else None
        if claim is None:
            return {
                "ok": False,
                "status": "unknown",
                "schema_version": "persistmind.epistemic_claim_view.v1",
                "claim_id": claim_id,
            }
        return {
            "ok": True,
            "status": str(claim.get("status") or "unknown"),
            "schema_version": "persistmind.epistemic_claim_view.v1",
            "claim": claim,
            "evidence": list(self.knowledge.evidence(claim_id)),
            "relations": self._claim_relations(claim_id),
            "revisions": revisions,
            "valid_at": valid_at,
            "transaction_at": transaction_at,
        }

    def claim_recall(
        self,
        query: str,
        *,
        paths: Sequence[str] | None = None,
        valid_at: str | None = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        defense = detect_query_injection(query)
        if not defense["ok"]:
            return {
                "ok": True,
                "status": "unknown",
                "schema_version": "persistmind.epistemic_claim_recall.v1",
                "claims": [],
                "defense": defense,
            }
        now = valid_at or utc_now()
        terms = _terms(query)
        requested_paths = {str(item).replace("\\", "/") for item in paths or []}
        rows = self.knowledge.connection.execute(
            "SELECT * FROM domain_records WHERE kind='epistemic_claim' ORDER BY updated_at DESC"
        ).fetchall()
        included: list[dict[str, Any]] = []
        excluded = {"lifecycle": 0, "validity": 0, "scope": 0, "untrusted": 0}
        for row in rows:
            claim = self.knowledge._record(row)
            if str(claim.get("status")) not in {"supported", "contested"}:
                excluded["lifecycle"] += 1
                continue
            if str(claim.get("valid_from") or "") > now or (
                claim.get("valid_to") is not None and str(claim.get("valid_to")) < now
            ):
                excluded["validity"] += 1
                continue
            source_identity = dict(claim.get("source_identity") or {})
            if source_identity.get("untrusted") and not source_identity.get("validated_by"):
                excluded["untrusted"] += 1
                continue
            scopes = {str(item).replace("\\", "/") for item in claim.get("path_scope") or []}
            if (
                requested_paths
                and scopes
                and not any(
                    fnmatch.fnmatch(path, scope) or fnmatch.fnmatch(scope, path)
                    for path in requested_paths
                    for scope in scopes
                )
            ):
                excluded["scope"] += 1
                continue
            score = _lexical_score(terms, str(claim.get("proposition") or ""))
            if score > 0:
                included.append({**claim, "score": score})
        included.sort(key=lambda item: (-float(item["score"]), str(item["claim_id"])))
        selected = included[: max(1, min(int(limit), 1000))]
        return {
            "ok": True,
            "status": "supported" if selected else "unknown",
            "schema_version": "persistmind.epistemic_claim_recall.v1",
            "claims": selected,
            "excluded": excluded,
            "defense": defense,
        }

    def claim_conflicts(self, claim_id: str | None = None) -> dict[str, Any]:
        clause = " WHERE subject_id=? OR object_id=?" if claim_id else ""
        values = (claim_id, claim_id) if claim_id else ()
        rows = self.knowledge.connection.execute(
            "SELECT * FROM knowledge_claim_relations" + clause + " ORDER BY relation_id",
            values,
        ).fetchall()
        conflicts = [
            dict(row)
            for row in rows
            if str(row["predicate"]) in {"contradicts", "refutes", "incompatible_with"}
        ]
        return {
            "ok": not conflicts,
            "status": "contradictory" if conflicts else "supported",
            "schema_version": "persistmind.epistemic_conflicts.v1",
            "conflicts": conflicts,
        }

    def forecast_calibration(
        self, *, calibrator_id: str | None = None, bins: int = 10
    ) -> dict[str, Any]:
        bounded_bins = max(2, min(int(bins), 100))
        where = " WHERE f.calibrator_id=?" if calibrator_id else ""
        values = (calibrator_id,) if calibrator_id else ()
        rows = self.knowledge.connection.execute(
            "SELECT f.*,o.outcome,o.observed_at,r.payload_json "
            "FROM knowledge_forecasts f "
            "JOIN knowledge_forecast_outcomes o ON o.forecast_id=f.forecast_id "
            "JOIN domain_records r ON r.record_id=f.claim_id"
            + where
            + " ORDER BY f.stratum,f.predicted_at,f.forecast_id",
            values,
        ).fetchall()
        groups: dict[str, list[tuple[float, int, str]]] = {}
        sources: dict[str, list[tuple[float, int]]] = {}
        for row in rows:
            probability, outcome = float(row["probability"]), int(row["outcome"])
            groups.setdefault(str(row["stratum"]), []).append(
                (probability, outcome, str(row["forecast_id"]))
            )
            claim = json.loads(str(row["payload_json"]))
            source = canonical_json(dict(claim.get("source_identity") or {}))
            sources.setdefault(source, []).append((probability, outcome))
        strata = {
            name: _calibration_metrics(items, bins=bounded_bins)
            for name, items in sorted(groups.items())
        }
        reliability = {
            source: {
                "resolved_outcomes": len(items),
                "brier_score": round(
                    sum((probability - outcome) ** 2 for probability, outcome in items)
                    / len(items),
                    12,
                ),
            }
            for source, items in sorted(sources.items())
        }
        return {
            "ok": True,
            "status": "not_computable" if not rows else "verified",
            "schema_version": "persistmind.forecast_calibration.v1",
            "calibrator_id": calibrator_id,
            "resolved_forecasts": len(rows),
            "strata": strata,
            "source_reliability": reliability,
        }

    def _claim_relations(self, claim_id: str) -> list[dict[str, Any]]:
        rows = self.knowledge.connection.execute(
            "SELECT * FROM knowledge_claim_relations "
            "WHERE subject_id=? OR object_id=? ORDER BY relation_id",
            (claim_id, claim_id),
        ).fetchall()
        return [dict(row) for row in rows]

    def memory_create_typed(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        """Create a candidate/ordinary memory without granting policy authority."""

        raw = dict(payload)
        requested_type = str(raw.get("type") or raw.get("record_type") or "").strip()
        record_type = (
            "business_rule_candidate" if requested_type == "business_rule" else requested_type
        )
        assertion = str(raw.get("assertion") or "").strip()
        metadata = _as_dict(raw.get("metadata") or raw.get("metadata_json"))
        scope_refs = raw.get("scope_refs")
        if scope_refs is not None:
            metadata["scope_refs"] = _as_strings(scope_refs)
        provenance = _as_dict(raw.get("provenance"))
        source_kind = str(raw.get("source_kind") or "manual")
        status = str(raw.get("status") or "candidate").strip().lower()
        trust = str(raw.get("trust") or _default_trust(status)).strip().lower()
        self._validate_memory_payload(
            record_type=record_type,
            assertion=assertion,
            status=status,
            provenance=provenance,
            metadata=metadata,
        )
        evidence_items = raw.get("evidence") or raw.get("evidence_refs") or []
        if record_type == "business_rule_candidate":
            if status != "candidate":
                raise ValueError(
                    "business_rule_candidate must remain candidate until explicit Policy approval"
                )
            if (
                not isinstance(evidence_items, Sequence)
                or isinstance(evidence_items, (str, bytes))
                or not evidence_items
            ):
                raise ValueError("business_rule_candidate requires at least one evidence record")
        defense = self._ingest_defense(
            assertion,
            source_kind=source_kind,
            owner=_optional_string(raw.get("owner")),
            provenance=provenance,
            metadata=metadata,
        )
        assertion = str(defense["assertion"])
        provenance = dict(defense["provenance"])
        metadata = dict(defense["metadata"])
        if not defense["ok"]:
            status = "quarantined"
            trust = "untrusted"

        scope = str(raw.get("scope") or self._scope_from_refs(raw, metadata))
        record_id = str(
            raw.get("record_id") or self._memory_id(record_type, assertion, scope, source_kind)
        )
        document = {
            "schema_version": "persistmind.knowledge_record.v1",
            "record_id": record_id,
            "kind": "memory",
            "type": record_type,
            "title": _optional_string(raw.get("title")) or assertion[:80],
            "assertion": assertion,
            "scope": scope,
            "scope_kind": _scope_kind(scope),
            "scope_refs": _scope_refs(scope, metadata),
            "status": status,
            "confidence": _confidence(raw.get("confidence"), default=1.0),
            "importance": _confidence(
                raw.get("importance"), default=_confidence(raw.get("confidence"), default=1.0)
            ),
            "trust": trust,
            "source_kind": source_kind,
            "extraction_method": str(raw.get("extraction_method") or "manual"),
            "owner": _optional_string(raw.get("owner")),
            "applies_when": _optional_string(raw.get("applies_when")),
            "avoid_when": _optional_string(raw.get("avoid_when")),
            "expires_at": _optional_string(raw.get("expires_at")),
            "invalidates_when": _optional_string(raw.get("invalidates_when")),
            "last_validated_at": _optional_string(raw.get("last_validated_at")),
            "superseded_by": _optional_string(raw.get("superseded_by")),
            "provenance": provenance,
            "metadata": metadata,
        }
        record = self.knowledge.write_memory_record(
            document,
            actor=str(raw.get("actor") or "local-user"),
            reason="create",
            idempotency_key=f"knowledge-create:{record_id}",
        )
        self._put_evidence(record_id, evidence_items)
        response = self._record_response(record)
        if requested_type == "business_rule":
            response["warnings"] = [
                {
                    "type": "deprecated_memory_kind",
                    "message": "business_rule is stored as business_rule_candidate; use policy approve-business-rule for authority.",
                }
            ]
        return response

    def memory_propose(
        self,
        record_type: str,
        assertion: str,
        evidence_refs: Sequence[Mapping[str, Any]] | None = None,
        source_kind: str = "manual",
        confidence: float = 1.0,
    ) -> dict[str, Any]:
        result = self.memory_create_typed(
            {
                "type": record_type,
                "assertion": assertion,
                "evidence": list(evidence_refs or ()),
                "source_kind": source_kind,
                "confidence": confidence,
                "status": "candidate",
            }
        )
        return {
            "ok": True,
            "record_id": result["record"]["record_id"],
            "status": result["record"]["status"],
            "record": result["record"],
            "nextgen_v1": True,
        }

    def memory_records(
        self, status: str | None = None, types: Sequence[str] | None = None
    ) -> dict[str, Any]:
        return {
            "ok": True,
            "schema_version": "persistmind.knowledge_records.v1",
            "records": [
                self._project_record(row)
                for row in self.knowledge.memory_records(status=status, types=types)
            ],
            "nextgen_v1": True,
        }

    def memory_list(self, status: str | None = None) -> dict[str, Any]:
        return self.memory_records(status=status)

    def memory_show(self, record_id: str) -> dict[str, Any]:
        record = self.knowledge.get(record_id)
        if record is None or str(record.get("kind")) != "memory":
            return {"ok": False, "error": "memory not found", "record_id": record_id}
        return {
            "ok": True,
            "schema_version": "persistmind.knowledge_memory_show.v1",
            "record": self._project_record(record),
            "evidence": list(self.knowledge.evidence(record_id)),
            "revisions": list(self.knowledge.memory_revisions(record_id)),
            "transitions": list(self.knowledge.memory_transitions(record_id)),
            "nextgen_v1": True,
        }

    def memory_explain(self, record_id: str) -> dict[str, Any]:
        shown = self.memory_show(record_id)
        if not shown.get("ok"):
            return shown
        return {"ok": True, "type": "memory_record", **shown}

    def memory_search(
        self,
        query: str,
        types: Sequence[str] | None = None,
        status: str | None = None,
    ) -> dict[str, Any]:
        query = query.strip()
        if not query:
            raise ValueError("memory search requires a query")
        terms = _terms(query)
        results: list[dict[str, Any]] = []
        for record in self.knowledge.memory_records(status=status, types=types):
            score, match_method = _deterministic_score(query, terms, _memory_text(record))
            if score <= 0:
                continue
            projected = self._project_record(record)
            projected["score"] = score
            projected["match_method"] = match_method
            results.append(projected)
        results.sort(key=lambda item: (-float(item["score"]), item["record_id"]))
        return {
            "ok": True,
            "schema_version": "persistmind.knowledge_memory_search.v1",
            "query": query,
            "results": results,
            "backend_status": {
                "full_text": "not_configured",
                "vector": "not_configured",
                "fallback": "deterministic_lexical",
                "exact_identifier": "always_on",
            },
            "nextgen_v1": True,
        }

    def memory_recall(
        self,
        query: str,
        paths: Sequence[str] | None = None,
        types: Sequence[str] | None = None,
        limit: int = 20,
        include_org: bool = False,
    ) -> dict[str, Any]:
        if include_org:
            from persistmind.security.context import require_current_principal

            require_current_principal(
                roles=frozenset({"operator", "admin"}),
                action="organization.memory.read",
            )
        query = query.strip()
        if not query:
            raise ValueError("memory recall requires a query")
        query_defense = detect_query_injection(query)
        if not query_defense["ok"]:
            return {
                "ok": True,
                "schema_version": "persistmind.memory_recall.v1",
                "query": query,
                "items": [],
                "records": [],
                "defense": {"query": query_defense, "excluded": {"query_injection": 1}},
                "nextgen_v1": True,
            }
        path_set = {item.replace("\\", "/") for item in paths or () if item}
        allowed_types = {str(item) for item in types or ()}
        query_terms = _terms(query)
        candidates: list[dict[str, Any]] = []
        stale_candidates: list[dict[str, Any]] = []
        excluded = {
            "terminal": 0,
            "not_authoritative": 0,
            "scope": 0,
            "org": 0,
            "stale": 0,
        }
        for record in self.knowledge.memory_records():
            record_type = str(record.get("type") or "")
            status = str(record.get("status") or "candidate")
            if allowed_types and record_type not in allowed_types:
                continue
            if status in _TERMINAL_MEMORY_STATUSES or status not in {"active", "approved"}:
                excluded["terminal"] += 1
                continue
            if record_type == "org_knowledge" and not include_org:
                excluded["org"] += 1
                continue
            if not self._serves_authoritatively(record):
                excluded["not_authoritative"] += 1
                continue
            if path_set and not self._scope_matches(record, path_set):
                excluded["scope"] += 1
                continue
            score, match_method = _deterministic_score(query, query_terms, _memory_text(record))
            if score <= 0:
                continue
            projected = self._project_record(record)
            if _is_expired(record):
                projected["score"] = score
                projected["match_method"] = match_method
                projected["freshness_status"] = "stale"
                projected["requires_revalidation"] = True
                stale_candidates.append(projected)
                excluded["stale"] += 1
                continue
            if _as_dict(record.get("metadata")).get("live_state"):
                projected["freshness_status"] = "last_verified"
                projected["requires_revalidation"] = False
            projected["score"] = round(score + float(projected["confidence"]) * 0.05, 6)
            projected["match_method"] = match_method
            candidates.append(projected)
        ranked = trust_aware_rank(candidates)
        selected = ranked[: max(1, min(int(limit), 1000))]
        return {
            "ok": True,
            "schema_version": "persistmind.memory_recall.v1",
            "query": query,
            "items": selected,
            "records": selected,
            "stale_records": sorted(
                stale_candidates,
                key=lambda item: (-float(item["score"]), str(item["record_id"])),
            )[: max(1, min(int(limit), 1000))],
            "defense": {"query": query_defense, "excluded": excluded},
            "backend_status": {
                "full_text": "not_configured",
                "vector": "not_configured",
                "fallback": "deterministic_lexical",
                "exact_identifier": "always_on",
            },
            "nextgen_v1": True,
        }

    def memory_update(
        self,
        record_id: str,
        patch: Mapping[str, Any],
        reason: str = "manual update",
        actor: str = "local-user",
    ) -> dict[str, Any]:
        current = self._memory_or_raise(record_id)
        raw_patch = dict(patch)
        expected_revision = raw_patch.pop("expected_revision", None)
        forbidden = {
            "record_id",
            "type",
            "kind",
            "status",
            "trust",
            "policy_id",
            "directive_id",
            "approved_by",
            "signature",
        }
        bad = sorted(forbidden & set(raw_patch))
        if bad:
            raise ValueError(
                "memory update cannot alter authority or lifecycle fields: " + ", ".join(bad)
            )
        document = _without_internal(current)
        for field in {
            "title",
            "assertion",
            "scope",
            "confidence",
            "importance",
            "source_kind",
            "extraction_method",
            "owner",
            "applies_when",
            "avoid_when",
            "expires_at",
            "invalidates_when",
            "last_validated_at",
            "superseded_by",
        }:
            if field in raw_patch:
                document[field] = raw_patch[field]
        if "metadata" in raw_patch:
            document["metadata"] = _as_dict(raw_patch["metadata"])
        if "provenance" in raw_patch:
            document["provenance"] = _as_dict(raw_patch["provenance"])
        if "scope_refs" in raw_patch:
            metadata = _as_dict(document.get("metadata"))
            metadata["scope_refs"] = _as_strings(raw_patch["scope_refs"])
            document["metadata"] = metadata
            document["scope_refs"] = _scope_refs(str(document["scope"]), metadata)
        document["assertion"] = str(document.get("assertion") or "").strip()
        document["scope"] = str(document.get("scope") or "").strip()
        document["confidence"] = _confidence(document.get("confidence"), default=1.0)
        document["importance"] = _confidence(
            document.get("importance"), default=document["confidence"]
        )
        document["scope_kind"] = _scope_kind(document["scope"])
        self._validate_memory_payload(
            record_type=str(document["type"]),
            assertion=document["assertion"],
            status=str(document["status"]),
            provenance=_as_dict(document.get("provenance")),
            metadata=_as_dict(document.get("metadata")),
        )
        defense = self._ingest_defense(
            document["assertion"],
            source_kind=str(document.get("source_kind") or "manual"),
            owner=_optional_string(document.get("owner")),
            provenance=_as_dict(document.get("provenance")),
            metadata=_as_dict(document.get("metadata")),
        )
        document["assertion"] = defense["assertion"]
        document["provenance"] = defense["provenance"]
        document["metadata"] = defense["metadata"]
        if not defense["ok"]:
            document["status"] = "quarantined"
            document["trust"] = "untrusted"
        updated = self.knowledge.write_memory_record(
            document,
            actor=actor,
            reason=reason,
            expected_revision=(int(expected_revision) if expected_revision is not None else None),
        )
        return self._record_response(updated)

    def memory_validate(
        self,
        record_id: str,
        validator: str,
        evidence: Mapping[str, Any] | None = None,
        actor: str = "local-user",
    ) -> dict[str, Any]:
        record = self._memory_or_raise(record_id)
        if str(record["type"]) == "business_rule_candidate":
            raise ValueError(
                "business_rule_candidate remains non-authoritative; use policy approve-business-rule"
            )
        if str(record["type"]) in _SENSITIVE_MEMORY_TYPES or str(record["status"]) in {
            "needs_review",
            "quarantined",
        }:
            _require_actor_role(actor, "codeowner", "memory_validate_sensitive")
        document = _without_internal(record)
        provenance = _as_dict(document.get("provenance"))
        provenance.update({"validator": validator, "validated_at": utc_now()})
        if evidence:
            provenance["validation_evidence"] = dict(evidence)
        document["provenance"] = provenance
        document["last_validated_at"] = utc_now()
        document["trust"] = "active"
        document["status"] = "active"
        updated = self.knowledge.write_memory_record(
            document,
            actor=actor,
            reason=f"validated by {validator}",
            expected_revision=int(record["_revision"]),
        )
        response = self._record_response(updated)
        return response

    def memory_approve(
        self,
        record_id: str,
        approved_by: str = "local-user",
        signature: str | None = None,
    ) -> dict[str, Any]:
        record = self._memory_or_raise(record_id)
        if str(record["type"]) == "business_rule_candidate":
            if not signature:
                raise ValueError(
                    "business_rule candidate approval requires a policy signature; use policy approve-business-rule"
                )
            return self.policy_approve_business_rule(
                record_id,
                approver=approved_by,
                signature=signature,
            )
        return self.memory_validate(
            record_id,
            validator="human:approval",
            actor=approved_by,
        )

    def memory_reject(self, record_id: str, actor: str = "local-user") -> dict[str, Any]:
        return self._set_memory_status(record_id, "rejected", actor=actor, reason="rejected")

    def memory_expire(
        self, record_id: str, reason: str, actor: str = "local-user"
    ) -> dict[str, Any]:
        return self._set_memory_status(record_id, "expired", actor=actor, reason=reason)

    def memory_quarantine(
        self,
        record_id: str,
        reason: str,
        severity: str = "high",
        actor: str = "codeowner",
    ) -> dict[str, Any]:
        _require_actor_role(actor, "codeowner", "memory_quarantine")
        result = self._set_memory_status(
            record_id,
            "quarantined",
            actor=actor,
            reason=reason,
            trust="untrusted",
        )
        result["review"] = {
            "status": "pending",
            "severity": severity,
            "reason": reason,
            "note": "quarantined record is present in the derived review queue",
        }
        return result

    def memory_supersede(
        self, old_record_id: str, new_record_id: str, approved_by: str = "local-user"
    ) -> dict[str, Any]:
        old = self._memory_or_raise(old_record_id)
        new = self._memory_or_raise(new_record_id)
        if (
            str(old["type"]) in _SENSITIVE_MEMORY_TYPES
            or str(new["type"]) in _SENSITIVE_MEMORY_TYPES
        ):
            _require_actor_role(approved_by, "codeowner", "memory_supersede_sensitive")
        document = _without_internal(old)
        document["status"] = "superseded"
        document["superseded_by"] = new_record_id
        updated = self.knowledge.write_memory_record(
            document,
            actor=approved_by,
            reason=f"superseded by {new_record_id}",
            expected_revision=int(old["_revision"]),
        )
        old_policy_id = _as_dict(old.get("metadata")).get("policy_id")
        return {
            "ok": True,
            "old_record_id": old_record_id,
            "new_record_id": new_record_id,
            "record": self._project_record(updated),
            "policy_transition_required": str(old_policy_id) if old_policy_id else None,
            "nextgen_v1": True,
        }

    def memory_diff(
        self,
        record_id: str,
        revision_a: str | None = None,
        revision_b: str | None = None,
    ) -> dict[str, Any]:
        revisions = list(self.knowledge.memory_revisions(record_id))
        if not revisions:
            return {"ok": False, "record_id": record_id, "error": "no revisions"}
        left = _find_revision(revisions, revision_a) if revision_a else revisions[0]
        right = _find_revision(revisions, revision_b) if revision_b else revisions[-1]
        if left is None or right is None:
            return {"ok": False, "record_id": record_id, "error": "revision not found"}
        before = _as_dict(left.get("record"))
        after = _as_dict(right.get("record"))
        changed = {
            key: {"before": before.get(key), "after": after.get(key)}
            for key in sorted(set(before) | set(after))
            if before.get(key) != after.get(key)
        }
        return {
            "ok": True,
            "record_id": record_id,
            "revision_a": left["revision_id"],
            "revision_b": right["revision_id"],
            "changed": changed,
            "nextgen_v1": True,
        }

    def memory_conflicts(self) -> dict[str, Any]:
        records = [
            item
            for item in self.knowledge.memory_records()
            if str(item.get("status")) in {"active", "approved"}
        ]
        conflicts: list[dict[str, Any]] = []
        for index, left in enumerate(records):
            for right in records[index + 1 :]:
                if str(left.get("scope")) != str(right.get("scope")):
                    continue
                summary = _conflict_summary(
                    str(left.get("assertion") or ""), str(right.get("assertion") or "")
                )
                if summary:
                    conflicts.append(
                        {
                            "record_ids": [left["record_id"], right["record_id"]],
                            "type": "semantic_conflict",
                            "summary": summary,
                            "recommended_action": "Review and supersede one record.",
                        }
                    )
        return {
            "ok": not conflicts,
            "status": "conflict_detected" if conflicts else "ok",
            "conflicts": conflicts,
            "nextgen_v1": True,
        }

    def memory_stale(self) -> dict[str, Any]:
        stale: list[dict[str, Any]] = []
        for record in self.knowledge.memory_records():
            if str(record.get("status")) not in {"active", "approved"}:
                continue
            if _is_expired(record):
                stale.append({"record_id": record["record_id"], "reason": "expired"})
            elif not self.knowledge.evidence(str(record["record_id"])):
                stale.append({"record_id": record["record_id"], "reason": "no evidence"})
        return {"ok": True, "stale": stale, "nextgen_v1": True}

    def memory_verify(self) -> dict[str, Any]:
        violations: list[dict[str, Any]] = []
        for record in self.knowledge.memory_records():
            if str(record.get("type")) != "business_rule_candidate":
                continue
            # Candidate rows never become policy by changing their local status.
            # Their authority is represented only by immutable Policy records.
            if str(record.get("status")) in {"active", "approved"}:
                violations.append(
                    {
                        "record_id": record["record_id"],
                        "type": "candidate_has_authoritative_status",
                    }
                )
        for policy in self.policy.policies(status="active"):
            if str(policy.get("policy_type")) != "approved_business_rule":
                continue
            candidate_id = str(policy.get("candidate_id") or "")
            candidate = self.knowledge.get(candidate_id)
            evidence_hashes = _as_strings(policy.get("evidence_hashes"))
            known_hashes = {
                str(item.get("content_hash")) for item in self.knowledge.evidence(candidate_id)
            }
            if (
                candidate is None
                or str(candidate.get("type")) != "business_rule_candidate"
                or not evidence_hashes
                or not set(evidence_hashes).issubset(known_hashes)
            ):
                violations.append(
                    {
                        "policy_id": policy.get("policy_id"),
                        "candidate_id": candidate_id,
                        "type": "approved_business_rule_evidence_missing",
                    }
                )
        health = {"knowledge": self.knowledge.health(), "policy": self.policy.health()}
        return {
            "ok": not violations and all(item.get("ok") for item in health.values()),
            "schema_version": "persistmind.knowledge_verify.v1",
            "health": health,
            "violations": violations,
            "nextgen_v1": True,
        }

    # -- Policy Authority --------------------------------------------------

    def memory_enforce(
        self,
        record_id: str,
        *,
        level: str = "warn",
        severity: str = "medium",
        scope: Sequence[str] | None = None,
        anti_patterns: Sequence[str] | None = None,
        required_patterns: Sequence[str] | None = None,
        remediation: str | None = None,
        rationale: str | None = None,
        approve: bool = False,
        approved_by: str = "local-user",
        status: str = "active",
        source: str = "manual",
    ) -> dict[str, Any]:
        if not approve:
            raise PermissionError("policy activation requires approve=true")
        _require_actor_role(approved_by, "codeowner", "memory_enforce")
        record = self._memory_or_raise(record_id)
        if str(record.get("status")) not in {"active", "approved"}:
            raise ValueError("only validated memory can become an enforcement directive")
        directive = self._activate_policy(
            record,
            approver=approved_by,
            policy_type="memory_enforcement",
            scope=_as_strings(scope)
            or _scope_refs(str(record.get("scope") or ""), _as_dict(record.get("metadata")))
            or ["**"],
            priority=_policy_priority(severity),
            details={
                "enforcement_level": level,
                "severity": severity,
                "path_globs": _as_strings(scope) or ["**"],
                "anti_patterns": _as_strings(anti_patterns),
                "required_patterns": _as_strings(required_patterns),
                "remediation": remediation,
                "rationale": rationale or str(record.get("assertion") or ""),
                "source": source,
                "requested_status": status,
            },
        )
        return {"ok": True, "directive": directive, "nextgen_v1": True}

    def memory_enforcements(
        self,
        *,
        status: str | None = None,
        paths: Sequence[str] | None = None,
    ) -> dict[str, Any]:
        path_set = [item.replace("\\", "/") for item in paths or () if item]
        directives = [
            item
            for item in self.policy.policies(status=status)
            if str(item.get("policy_type")) in {"memory_enforcement", "approved_business_rule"}
        ]
        if path_set:
            directives = [
                directive for directive in directives if _policy_matches_paths(directive, path_set)
            ]
        return {"ok": True, "directives": directives, "nextgen_v1": True}

    def memory_unenforce(
        self,
        directive_id: str,
        *,
        reason: str = "manual suspend",
        actor: str = "local-user",
    ) -> dict[str, Any]:
        del directive_id, reason, actor
        raise PermissionError(
            "Knowledge cannot change Policy state; submit the transition to PolicyService"
        )

    def policy_approve_business_rule(
        self,
        candidate_id: str,
        *,
        approver: str,
        signature: str,
    ) -> dict[str, Any]:
        del candidate_id, approver, signature
        raise PermissionError(
            "Knowledge cannot approve Policy; use PolicyService.approve_business_rule"
        )

    def policy_applicable(self, scope: str | None = None) -> dict[str, Any]:
        requested = (scope or "global").strip() or "global"
        candidates = self.policy.policies(status="active")
        applicable = [item for item in candidates if _policy_matches_scope(item, requested)]
        applicable.sort(
            key=lambda item: (-int(item.get("priority") or 0), str(item.get("policy_id")))
        )
        return {
            "ok": True,
            "schema_version": "persistmind.policy_applicable.v1",
            "scope": requested,
            "policies": applicable,
            "nextgen_v1": True,
        }

    def memory_review(self, *, status: str | None = None, limit: int = 100) -> dict[str, Any]:
        records = [
            self._project_record(item)
            for item in self.knowledge.memory_records(limit=max(1, min(limit, 1000)))
            if str(item.get("status")) in {"candidate", "needs_review", "quarantined"}
            and (status is None or str(item.get("status")) == status)
        ]
        records.sort(key=lambda item: (str(item.get("status")), str(item["record_id"])))
        return {
            "ok": True,
            "schema_version": "persistmind.memory_review.v1",
            "records": records[:limit],
            "count": min(len(records), limit),
            "nextgen_v1": True,
        }

    def memory_maintain(self, *, apply: bool = False, limit: int = 1000) -> dict[str, Any]:
        now = datetime.now(timezone.utc)
        stale = []
        for item in self.knowledge.memory_records(limit=max(1, min(limit, 1000))):
            expires_at = _optional_string(item.get("expires_at"))
            if not expires_at or str(item.get("status")) in _TERMINAL_MEMORY_STATUSES:
                continue
            try:
                expired = datetime.fromisoformat(expires_at.replace("Z", "+00:00")) <= now
            except ValueError:
                expired = False
            if expired:
                stale.append(str(item["record_id"]))
        applied = []
        if apply:
            for record_id in stale:
                self.memory_expire(record_id, "retention expiry", actor="maintenance")
                applied.append(record_id)
        verification = dict(self.knowledge.health())
        return {
            "ok": bool(verification.get("ok")),
            "schema_version": "persistmind.memory_maintenance.v1",
            "dry_run": not apply,
            "eligible": stale,
            "applied": applied,
            "verification": verification,
            "nextgen_v1": True,
        }

    def memory_graph(
        self,
        record_id: str | None = None,
        *,
        limit: int = 100,
        max_hops: int | None = None,
    ) -> dict[str, Any]:
        records = [
            self._project_record(item)
            for item in self.knowledge.memory_records(limit=max(1, min(limit, 1000)))
        ]
        by_id = {str(item["record_id"]): item for item in records}
        selected = [by_id[record_id]] if record_id and record_id in by_id else records
        edges: list[dict[str, Any]] = []
        for left in selected:
            left_refs = set(_as_strings(left.get("scope_refs")))
            for right in records:
                if left["record_id"] == right["record_id"]:
                    continue
                overlap = sorted(left_refs & set(_as_strings(right.get("scope_refs"))))
                if overlap:
                    edges.append(
                        {
                            "source": left["record_id"],
                            "target": right["record_id"],
                            "kind": "shared_scope",
                            "scope_refs": overlap,
                        }
                    )
        edges.sort(key=lambda item: (item["source"], item["target"]))
        return {
            "ok": True,
            "schema_version": "persistmind.memory_graph.v1",
            "nodes": selected[:limit],
            "edges": edges[:limit],
            "max_hops": max_hops,
            "nextgen_v1": True,
        }

    def memory_utilization(self, record_id: str | None = None) -> dict[str, Any]:
        graph = self.memory_graph(record_id=record_id, limit=1000)
        return {
            "ok": True,
            "status": "measured",
            "schema_version": "persistmind.memory_utilization.v1",
            "record_id": record_id,
            "nodes": len(graph["nodes"]),
            "edges": len(graph["edges"]),
        }

    def memory_metrics(self) -> dict[str, Any]:
        records = list(self.knowledge.memory_records(limit=1000))
        by_status: dict[str, int] = {}
        by_type: dict[str, int] = {}
        for item in records:
            status = str(item.get("status") or "unknown")
            kind = str(item.get("type") or item.get("kind") or "unknown")
            by_status[status] = by_status.get(status, 0) + 1
            by_type[kind] = by_type.get(kind, 0) + 1
        return {
            "ok": True,
            "schema_version": "persistmind.memory_metrics.v1",
            "records": len(records),
            "by_status": dict(sorted(by_status.items())),
            "by_type": dict(sorted(by_type.items())),
            "verification": dict(self.knowledge.health()),
            "nextgen_v1": True,
        }

    def business_entity_add(
        self,
        name: str,
        *,
        entity_type: str = "entity",
        attributes: Mapping[str, Any] | None = None,
        evidence: Sequence[Mapping[str, Any]] | None = None,
        actor: str = "local-user",
        node_type: str | None = None,
        attrs: Mapping[str, Any] | None = None,
        origin: str | None = None,
        source_type: str | None = None,
        source_ref: str | None = None,
        proposed_by: str | None = None,
        confidence: float | None = None,
    ) -> dict[str, Any]:
        normalized = name.strip()
        if not normalized:
            raise ValueError("business entity requires a name")
        return self.claim_create(
            {
                "proposition": canonical_json(
                    {
                        "entity_name": normalized,
                        "entity_type": node_type or entity_type,
                        "attributes": dict(attributes or attrs or {}),
                    }
                ),
                "claim_kind": "business_entity",
                "status": "candidate",
                "source_class": "human_decision",
                "evidence": list(evidence or []),
                "source_identity": {
                    "actor": proposed_by or actor,
                    "origin": origin,
                    "source_type": source_type,
                    "source_ref": source_ref,
                },
                "confidence": confidence if confidence is not None else 1.0,
            },
            actor=proposed_by or actor,
        )

    def business_entity_bulk_add(
        self,
        entities: Sequence[Mapping[str, Any]] | None = None,
        *,
        actor: str = "local-user",
        file: str | Path | None = None,
        origin: str | None = None,
        proposed_by: str | None = None,
    ) -> dict[str, Any]:
        values = list(entities or ())
        if file is not None:
            source = Path(file)
            if not source.is_absolute():
                source = self.repo_root / source
            payload = json.loads(source.read_text(encoding="utf-8"))
            values = (
                list(payload.get("entities", [])) if isinstance(payload, Mapping) else list(payload)
            )
        if not values:
            raise ValueError("business entity bulk add requires entities or a JSON file")
        results = []
        for entity in values:
            value = dict(entity)
            name = str(value.pop("name", ""))
            results.append(
                self.business_entity_add(
                    name,
                    actor=proposed_by or actor,
                    origin=origin,
                    **value,
                )
            )
        return {
            "ok": all(item["ok"] for item in results),
            "status": "created",
            "schema_version": "persistmind.business_entity_bulk.v1",
            "entities": results,
        }

    def business_entity_list(
        self,
        status: str | None = None,
        *,
        node_type: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        records = [
            dict(item)
            for item in self.knowledge.search('"claim_kind":"business_entity"', limit=10_000)
            if item.get("kind") == "epistemic_claim"
            and (status is None or item.get("status") == status)
        ]
        if node_type:
            records = [
                item
                for item in records
                if json.loads(str(item.get("proposition") or "{}")).get("entity_type") == node_type
            ]
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.business_entity_list.v1",
            "entities": records[: max(1, min(int(limit), 1000))],
        }

    def business_entity_approve(
        self,
        entity_id: str,
        *,
        actor: str = "local-user",
        reason: str = "approved",
        approver: str | None = None,
        notes: str | None = None,
    ) -> dict[str, Any]:
        return self.claim_transition(
            entity_id,
            status="supported",
            actor=approver or actor,
            reason=notes or reason,
        )

    def business_entity_reject(
        self,
        entity_id: str,
        *,
        actor: str = "local-user",
        reason: str = "rejected",
        approver: str | None = None,
    ) -> dict[str, Any]:
        return self.claim_transition(
            entity_id, status="rejected", actor=approver or actor, reason=reason
        )

    def business_link(
        self,
        subject_id: str | None = None,
        predicate: str | None = None,
        object_id: str | None = None,
        *,
        evidence_id: str | None = None,
        support_score: float | None = None,
        src_node_id: str | None = None,
        dst_node_id: str | None = None,
        kind: str | None = None,
        source_ref: str | None = None,
        source_type: str | None = None,
        proposed_by: str | None = None,
        confidence: float | None = None,
    ) -> dict[str, Any]:
        del source_type, proposed_by
        subject_id = subject_id or src_node_id
        object_id = object_id or dst_node_id
        predicate = predicate or kind
        if not subject_id or not object_id or not predicate:
            raise ValueError("business link requires subject, predicate, and object")
        return self.claim_relation_add(
            subject_id,
            predicate,
            object_id,
            evidence_id=evidence_id or source_ref,
            support_score=support_score if support_score is not None else confidence,
        )

    def decision_start(
        self,
        question: str,
        *,
        alternatives: Sequence[str] = (),
        rationale: str = "decision analysis started",
        actor: str = "local-user",
        options: Sequence[str] | None = None,
        seed_paths: Sequence[str] | None = None,
    ) -> dict[str, Any]:
        return self.memory_create_typed(
            {
                "type": "decision",
                "assertion": question,
                "status": "candidate",
                "source_kind": "human_decision",
                "actor": actor,
                "metadata": {
                    "rationale": rationale,
                    "alternatives": list(options or alternatives),
                    "seed_paths": list(seed_paths or ()),
                    "decision_state": "open",
                },
            }
        )

    def decision_record(
        self,
        decision: str = "",
        *,
        rationale: str = "decision recorded",
        alternatives: Sequence[str] = (),
        evidence: Sequence[Mapping[str, Any]] | None = None,
        actor: str = "local-user",
        chosen_option_id: str | None = None,
    ) -> dict[str, Any]:
        if chosen_option_id:
            current = self._memory_or_raise(decision)
            metadata = _as_dict(current.get("metadata"))
            metadata.update(
                {
                    "chosen_option_id": chosen_option_id,
                    "rationale": rationale,
                    "decision_state": "recorded",
                }
            )
            return self.memory_update(
                decision,
                {"metadata": metadata},
                reason="decision recorded",
                actor=actor,
            )
        return self.memory_create_typed(
            {
                "type": "decision",
                "assertion": decision,
                "status": "candidate",
                "source_kind": "human_decision",
                "actor": actor,
                "evidence": list(evidence or []),
                "metadata": {
                    "rationale": rationale,
                    "alternatives": list(alternatives),
                    "decision_state": "recorded",
                },
            }
        )

    def decision_list(self, status: str | None = None, *, limit: int = 50) -> dict[str, Any]:
        result = self.memory_records(status=status, types=["decision", "architectural_decision"])
        result["records"] = result["records"][: max(1, min(int(limit), 1000))]
        return result

    def decision_show(self, decision_id: str) -> dict[str, Any]:
        return self.memory_show(decision_id)

    def decision_analyze(self, decision_id: str) -> dict[str, Any]:
        shown = self.memory_show(decision_id)
        if not shown.get("ok"):
            return shown
        record = dict(shown["record"])
        metadata = _as_dict(record.get("metadata"))
        contradictions = [
            item
            for item in self.memory_conflicts()["conflicts"]
            if decision_id in set(item.get("record_ids", []))
        ]
        return {
            "ok": True,
            "status": "contested" if contradictions else "candidate",
            "schema_version": "persistmind.decision_analysis.v1",
            "decision": record,
            "alternatives": metadata.get("alternatives", []),
            "rationale": metadata.get("rationale"),
            "evidence": shown["evidence"],
            "contradictions": contradictions,
        }

    def memory_consolidate(
        self,
        record_ids: Sequence[str] | str,
        recent: int | None = None,
        *,
        actor: str = "maintenance",
    ) -> dict[str, Any]:
        if isinstance(record_ids, str):
            candidates = list(self.knowledge.memory_records(limit=max(2, int(recent or 20))))
            record_ids = [str(item["record_id"]) for item in candidates[:2]]
        if len(set(record_ids)) < 2:
            raise ValueError("consolidation requires at least two distinct source records")
        sources = [self._memory_or_raise(record_id) for record_id in sorted(set(record_ids))]
        assertions = [str(item["assertion"]) for item in sources]
        scope_refs = sorted(
            {ref for item in sources for ref in _as_strings(item.get("scope_refs"))}
        )
        evidence = [
            {
                "source_ref": str(item["record_id"]),
                "content_hash": str(item.get("_content_hash") or ""),
                "evidence_kind": "inference",
                "trust": "candidate",
            }
            for item in sources
        ]
        return self.memory_create_typed(
            {
                "type": "pattern",
                "assertion": "Consolidated candidate: " + " | ".join(assertions),
                "status": "candidate",
                "source_kind": "consolidation",
                "actor": actor,
                "scope_refs": scope_refs,
                "evidence": evidence,
                "metadata": {
                    "source_record_ids": [str(item["record_id"]) for item in sources],
                    "alternatives_preserved": assertions,
                    "reversible": True,
                },
            }
        )

    def memory_prefetch(
        self,
        query: str,
        *,
        paths: Sequence[str] | None = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        recalled = self.memory_recall(query, paths=paths, limit=limit)
        record_id = (
            "memory-prefetch_" + stable_id(query, canonical_json(paths or []), utc_now())[:32]
        )
        self.knowledge.put(
            {
                "record_id": record_id,
                "kind": "memory_service_observation",
                "scope": f"repo:{self.repo_id}",
                "event": "prefetch",
                "query_hash": "sha256:" + sha256_text(query),
                "served_ids": [item["record_id"] for item in recalled.get("items", [])],
                "excluded": recalled.get("defense", {}).get("excluded", {}),
                "created_at": utc_now(),
            },
            idempotency_key="memory-prefetch:" + record_id,
        )
        return {
            **recalled,
            "schema_version": "persistmind.memory_prefetch.v1",
            "observation_id": record_id,
        }

    def memory_reflect(
        self,
        session_id: str | None = None,
        recent: int | None = None,
        *,
        limit: int = 100,
    ) -> dict[str, Any]:
        del session_id
        if recent is not None:
            limit = recent
        failures = [
            self._project_record(item)
            for item in self.knowledge.memory_records(
                types=["failure_lesson", "gotcha", "episode"], limit=limit
            )
        ]
        hypotheses = [
            {
                "source_record_id": item["record_id"],
                "hypothesis": "Recurrence may be reduced by validating: " + str(item["assertion"]),
                "status": "candidate",
            }
            for item in failures
        ]
        record_id = "memory-reflection_" + stable_id(canonical_json(hypotheses))[:32]
        self.knowledge.put(
            {
                "record_id": record_id,
                "kind": "memory_reflection",
                "scope": f"repo:{self.repo_id}",
                "hypotheses": hypotheses,
                "created_at": utc_now(),
            },
            idempotency_key="memory-reflection:" + record_id,
        )
        return {
            "ok": True,
            "status": "candidate",
            "schema_version": "persistmind.memory_reflection.v1",
            "reflection_id": record_id,
            "hypotheses": hypotheses,
        }

    def memory_review_resolve(
        self,
        record_id: str,
        *,
        decision: str = "",
        actor: str = "local-user",
        reason: str = "review resolved",
        resolution: str | None = None,
        target_record_id: str | None = None,
        validator: str | None = None,
    ) -> dict[str, Any]:
        del target_record_id, validator
        decision = resolution or decision
        normalized = decision.strip().lower()
        if normalized == "approve":
            return self.memory_validate(record_id, validator="human:review", actor=actor)
        if normalized == "reject":
            return self._set_memory_status(record_id, "rejected", actor=actor, reason=reason)
        if normalized == "quarantine":
            return self.memory_quarantine(record_id, reason, actor=actor)
        raise ValueError("review decision must be approve, reject, or quarantine")

    def memory_security_reviews(self, status: str | None = None) -> dict[str, Any]:
        records = [
            self._project_record(item)
            for item in self.knowledge.memory_records(limit=1000)
            if str(item.get("status")) in {"quarantined", "needs_review"}
            or str(item.get("type")) in _SENSITIVE_MEMORY_TYPES
        ]
        if status:
            records = [item for item in records if item.get("status") == status]
        return {
            "ok": not any(item.get("status") == "quarantined" for item in records),
            "status": "review_required" if records else "verified",
            "schema_version": "persistmind.memory_security_reviews.v1",
            "records": records,
        }

    def memory_sleep(self, *, apply: bool = False, limit: int = 100) -> dict[str, Any]:
        candidates = [
            str(item["record_id"])
            for item in self.knowledge.memory_records(status="active", limit=limit)
        ]
        consolidations = []
        if apply:
            for offset in range(0, len(candidates) - 1, 2):
                consolidations.append(self.memory_consolidate(candidates[offset : offset + 2]))
        return {
            "ok": True,
            "status": "applied" if apply else "candidate",
            "schema_version": "persistmind.memory_sleep.v1",
            "candidate_pairs": len(candidates) // 2,
            "consolidations": consolidations,
            "maintenance": self.memory_maintain(apply=apply, limit=limit),
        }

    def memory_sweep(self, *, apply: bool = False, limit: int = 1000) -> dict[str, Any]:
        return self.memory_maintain(apply=apply, limit=limit)

    def memory_trust_calibrate(self, *, apply: bool = False) -> dict[str, Any]:
        calibration = self.forecast_calibration()
        return {
            "ok": calibration["ok"],
            "status": "reported" if not apply else "candidate_only",
            "schema_version": "persistmind.memory_trust_calibration.v1",
            "calibration": calibration,
            "applied": False,
            "reason": "source reliability changes require resolved outcomes and review",
        }

    def memory_extraction_eval(
        self,
        fixtures: str | None = None,
        source_type: str | None = None,
        **_: Any,
    ) -> dict[str, Any]:
        del fixtures, source_type
        return {**self.memory_metrics(), "schema_version": "persistmind.memory_extraction_eval.v1"}

    def memory_eval(self, query: str = "memory", *, limit: int = 20) -> dict[str, Any]:
        recalled = self.memory_recall(query, limit=limit)
        return {
            "ok": True,
            "status": "measured",
            "schema_version": "persistmind.memory_eval.v1",
            "query_hash": "sha256:" + sha256_text(query),
            "served": len(recalled.get("items", [])),
            "excluded": recalled.get("defense", {}).get("excluded", {}),
        }

    def memory_bench(
        self,
        queries: Sequence[str] | None = None,
        *,
        samples: int | None = None,
    ) -> dict[str, Any]:
        values = list(queries or ["decision", "failure", "convention"])
        if samples is not None:
            values = values[: max(1, min(int(samples), len(values)))]
        reports = [self.memory_eval(query) for query in values]
        return {
            "ok": all(item["ok"] for item in reports),
            "status": "measured",
            "schema_version": "persistmind.memory_benchmark.v1",
            "reports": reports,
        }

    def narrative_show(self) -> dict[str, Any]:
        records = [
            self._project_record(item)
            for item in self.knowledge.memory_records(status="active", limit=1000)
        ]
        records.sort(key=lambda item: str(item.get("updated_at") or item["record_id"]))
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.knowledge_narrative.v1",
            "timeline": [
                {
                    "record_id": item["record_id"],
                    "type": item.get("type"),
                    "assertion": item.get("assertion"),
                    "scope_refs": item.get("scope_refs", []),
                }
                for item in records
            ],
        }

    def workspace_init(self, name: str | None = None) -> dict[str, Any]:
        return self._workspace_record(
            "workspace_init",
            {"workspace_id": self.workspace_id, "name": name or self.repo_root.name},
        )

    def workspace_add_repo(self, path: str, *, label: str | None = None) -> dict[str, Any]:
        target = Path(path).resolve()
        return self._workspace_record(
            "workspace_repository",
            {"path": str(target), "label": label or target.name},
        )

    def workspace_index(self) -> dict[str, Any]:
        return {
            "ok": True,
            "status": "indexed",
            "schema_version": "persistmind.workspace_index.v1",
            "workspace": self.workspace_status(),
            "knowledge": self.memory_metrics(),
            "graph": self.memory_graph(limit=1000),
        }

    def workspace_status(self) -> dict[str, Any]:
        records = [
            dict(item)
            for item in self.knowledge.search('"kind":"workspace_record"', limit=1000)
            if item.get("kind") == "workspace_record"
        ]
        return {
            "ok": True,
            "status": "initialized" if records else "source_not_ready",
            "schema_version": "persistmind.workspace_status.v1",
            "workspace_id": self.workspace_id,
            "records": records,
        }

    def workspace_explain(self, task: str, paths: Sequence[str] | None = None) -> dict[str, Any]:
        recalled = self.memory_recall(task, paths=paths, limit=50)
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.workspace_explain.v1",
            "task_hash": "sha256:" + sha256_text(task),
            "included": recalled.get("items", []),
            "retrieval": recalled.get("defense", {}),
        }

    def workspace_impact(self, paths: Sequence[str]) -> dict[str, Any]:
        normalized = {item.replace("\\", "/") for item in paths}
        records = [
            self._project_record(item)
            for item in self.knowledge.memory_records(limit=10_000)
            if normalized & set(_as_strings(item.get("scope_refs")))
        ]
        observation = self._workspace_record(
            "workspace_impact",
            {"paths": sorted(normalized), "record_ids": [item["record_id"] for item in records]},
        )
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.workspace_impact.v1",
            "paths": sorted(normalized),
            "records": records,
            "observation": observation,
        }

    def workspace_critique(
        self,
        *,
        task: str | None = None,
        paths: Sequence[str] | None = None,
        diff: str | None = None,
        risk_threshold: float | None = None,
    ) -> dict[str, Any]:
        conflicts = self.memory_conflicts()
        stale = self.memory_stale()
        return {
            "ok": not conflicts["conflicts"] and not stale.get("stale", []),
            "status": "verified"
            if not conflicts["conflicts"] and not stale.get("stale", [])
            else "contested",
            "schema_version": "persistmind.workspace_critique.v1",
            "conflicts": conflicts,
            "stale": stale,
            "request": {
                "task": task,
                "paths": list(paths or ()),
                "diff_supplied": bool(diff),
                "risk_threshold": risk_threshold,
            },
        }

    def workspace_rule_promotions(self) -> dict[str, Any]:
        candidates = [
            self._project_record(item)
            for item in self.knowledge.memory_records(
                status="candidate", types=["business_rule_candidate"], limit=1000
            )
        ]
        return {
            "ok": True,
            "status": "candidate",
            "schema_version": "persistmind.workspace_rule_promotions.v1",
            "candidates": candidates,
            "authority": "PolicyService",
        }

    def _workspace_record(self, record_type: str, payload: Mapping[str, Any]) -> dict[str, Any]:
        record_id = "workspace_" + stable_id(record_type, canonical_json(dict(payload)))[:32]
        self.knowledge.put(
            {
                "record_id": record_id,
                "kind": "workspace_record",
                "scope": f"workspace:{self.workspace_id}",
                "record_type": record_type,
                "payload": dict(payload),
                "created_at": utc_now(),
            },
            idempotency_key="workspace-record:" + record_id,
        )
        return {
            "record_id": record_id,
            "record_type": record_type,
            "payload": dict(payload),
        }

    # -- Internal helpers --------------------------------------------------

    def _memory_or_raise(self, record_id: str) -> Mapping[str, Any]:
        record = self.knowledge.get(record_id)
        if record is None or str(record.get("kind")) != "memory":
            raise KeyError(f"memory record not found: {record_id}")
        return record

    def _record_response(self, record: Mapping[str, Any]) -> dict[str, Any]:
        return {"ok": True, "record": self._project_record(record), "nextgen_v1": True}

    def _set_memory_status(
        self,
        record_id: str,
        status: str,
        *,
        actor: str,
        reason: str,
        trust: str | None = None,
    ) -> dict[str, Any]:
        record = self._memory_or_raise(record_id)
        if str(record["type"]) in _SENSITIVE_MEMORY_TYPES:
            _require_actor_role(actor, "codeowner", f"memory_{status}_sensitive")
        document = _without_internal(record)
        document["status"] = status
        if trust is not None:
            document["trust"] = trust
        updated = self.knowledge.write_memory_record(
            document,
            actor=actor,
            reason=reason,
            expected_revision=int(record["_revision"]),
        )
        return self._record_response(updated)

    def _activate_policy(
        self,
        record: Mapping[str, Any],
        *,
        approver: str,
        policy_type: str,
        scope: Sequence[str],
        priority: int,
        details: Mapping[str, Any],
    ) -> Mapping[str, Any]:
        del record, approver, policy_type, scope, priority, details
        raise PermissionError(
            "Knowledge can propose policy evidence but PolicyService alone can activate it"
        )

    def _put_evidence(self, record_id: str, evidence: Any) -> list[str]:
        if not isinstance(evidence, Sequence) or isinstance(evidence, (str, bytes)):
            return []
        evidence_ids: list[str] = []
        for raw in evidence:
            if not isinstance(raw, Mapping):
                raise ValueError("memory evidence entries must be objects")
            item = dict(raw)
            locator = {
                key: item[key]
                for key in (
                    "repo_id",
                    "path",
                    "symbol_identity_id",
                    "evidence_kind",
                    "line_start",
                    "line_end",
                    "source_ref",
                    "metadata",
                )
                if item.get(key) is not None
            }
            content_hash = str(item.get("content_hash") or item.get("evidence_hash") or "")
            if not content_hash:
                content_hash = sha256_text(canonical_json(locator))
            evidence_ids.append(
                self.knowledge.put_evidence(
                    record_id,
                    locator,
                    content_hash=content_hash,
                    trust=str(item.get("trust") or "candidate"),
                )
            )
        return evidence_ids

    def _scope_from_refs(self, raw: Mapping[str, Any], metadata: Mapping[str, Any]) -> str:
        scope_kind = _optional_string(raw.get("scope_kind"))
        refs = _as_strings(raw.get("scope_refs") or metadata.get("scope_refs"))
        if scope_kind == "workspace":
            return "workspace"
        if scope_kind and refs:
            return f"{scope_kind}:{refs[0]}"
        return f"repo:{self.repo_id}"

    def _memory_id(self, record_type: str, assertion: str, scope: str, source_kind: str) -> str:
        subject = sha256_text(
            canonical_json(
                {
                    "type": record_type,
                    "scope": scope,
                    "terms": sorted(_terms(assertion))[:12],
                }
            )
        )
        return (
            "memory_"
            + stable_id(self.workspace_id, self.repo_id, record_type, subject, source_kind)[:32]
        )

    def _validate_memory_payload(
        self,
        *,
        record_type: str,
        assertion: str,
        status: str,
        provenance: Mapping[str, Any],
        metadata: Mapping[str, Any],
    ) -> None:
        if record_type not in _KNOWLEDGE_MEMORY_TYPES:
            if record_type in load_memory_kinds():
                raise ValueError(
                    f"memory type {record_type} belongs to another authority and cannot be written to Knowledge"
                )
            raise ValueError(f"unsupported memory type: {record_type}")
        if not assertion:
            raise ValueError("memory assertion is required")
        if status not in _ALLOWED_MEMORY_STATUSES:
            raise ValueError(f"unsupported memory status: {status}")
        if status in {"active", "approved"} and _agent_generated_without_validator(provenance):
            raise ValueError("agent-generated active memory requires provenance.validator")
        if record_type == "policy_reference" and _claims_policy_enforcement(assertion, metadata):
            raise ValueError("policy_reference memory may reference policy but cannot enforce it")
        if metadata.get("enforces") is True or metadata.get("policy_id"):
            raise ValueError("generic memory cannot carry Policy Authority fields")
        requirements = _TYPE_METADATA_REQUIREMENTS.get(record_type, {})
        missing = [
            key
            for key, expected in requirements.items()
            if not _metadata_satisfies(metadata.get(key), expected)
        ]
        if missing:
            raise ValueError(
                f"{record_type} memory requires metadata: {', '.join(sorted(missing))}"
            )

    def _ingest_defense(
        self,
        assertion: str,
        *,
        source_kind: str,
        owner: str | None,
        provenance: Mapping[str, Any],
        metadata: Mapping[str, Any],
    ) -> dict[str, Any]:
        next_provenance = dict(provenance)
        next_metadata = dict(metadata)
        external = _is_external(source_kind, next_provenance)
        if external:
            result = evaluate_ingest(
                assertion,
                actor=owner or next_provenance.get("actor"),
                source_connector=str(next_provenance.get("source_connector") or source_kind),
                external=True,
            )
            next_metadata["defense_result"] = result
            next_provenance.update(
                {
                    "external": True,
                    "source_kind": source_kind,
                    "source_connector": next_provenance.get("source_connector") or source_kind,
                    "serve_authoritative": False,
                }
            )
            return {
                "ok": result["decision"] == "candidate",
                "assertion": str(result["sanitized_text"]),
                "provenance": next_provenance,
                "metadata": next_metadata,
            }
        defense = detect_query_injection(assertion)
        if not defense["ok"] or _claims_policy_override(assertion, next_metadata):
            next_metadata["memory_defense"] = {
                "ok": False,
                "reason": "memory_poisoning_suspected",
                "flagged": list(defense.get("flagged") or [])
                + (
                    ["preference_policy_override"]
                    if _claims_policy_override(assertion, next_metadata)
                    else []
                ),
                "severity": "high",
            }
            return {
                "ok": False,
                "assertion": assertion,
                "provenance": next_provenance,
                "metadata": next_metadata,
            }
        return {
            "ok": True,
            "assertion": assertion,
            "provenance": next_provenance,
            "metadata": next_metadata,
        }

    def _serves_authoritatively(self, record: Mapping[str, Any]) -> bool:
        provenance = _as_dict(record.get("provenance"))
        metadata = _as_dict(record.get("metadata"))
        decision = serve_decision(metadata.get("defense_result"), provenance)
        return bool(decision.get("serve_authoritative"))

    def _scope_matches(self, record: Mapping[str, Any], paths: set[str]) -> bool:
        scope = str(record.get("scope") or "")
        if scope in {"workspace", f"repo:{self.repo_id}"}:
            return True
        refs = _as_strings(record.get("scope_refs"))
        for evidence in self.knowledge.evidence(str(record["record_id"])):
            path = _optional_string(_as_dict(evidence.get("locator")).get("path"))
            if path:
                refs.append(path)
        return any(
            fnmatch.fnmatch(path, reference) or fnmatch.fnmatch(reference, path)
            for path in paths
            for reference in refs
        )

    @staticmethod
    def _project_record(record: Mapping[str, Any]) -> dict[str, Any]:
        projected = {
            key: value
            for key, value in dict(record).items()
            if key not in {"kind", "schema_version", "_content_hash"}
        }
        if _as_dict(record.get("metadata")).get("live_state"):
            stale = _is_expired(record)
            projected["freshness_status"] = "stale" if stale else "last_verified"
            projected["requires_revalidation"] = stale
        return projected


def _as_dict(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, Mapping) else {}


def _as_strings(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value] if value else []
    if not isinstance(value, Sequence):
        return []
    return [str(item) for item in value if str(item).strip()]


def _optional_string(value: Any) -> str | None:
    text = str(value).strip() if value is not None else ""
    return text or None


def _confidence(value: Any, *, default: float) -> float:
    try:
        parsed = float(default if value is None else value)
    except (TypeError, ValueError) as exc:
        raise ValueError("memory confidence must be numeric") from exc
    if not math.isfinite(parsed) or not 0.0 <= parsed <= 1.0:
        raise ValueError("memory confidence must be between 0 and 1")
    return parsed


def _without_internal(record: Mapping[str, Any]) -> dict[str, Any]:
    return {
        str(key): value
        for key, value in dict(record).items()
        if key not in {"_revision", "_content_hash"}
    }


def _scope_kind(scope: str) -> str:
    return scope.split(":", 1)[0] if ":" in scope else scope


def _scope_refs(scope: str, metadata: Mapping[str, Any]) -> list[str]:
    declared = _as_strings(metadata.get("scope_refs"))
    if declared:
        return declared
    return [scope.split(":", 1)[1]] if ":" in scope else []


def _default_trust(status: str) -> str:
    return "active" if status in {"active", "approved"} else "candidate"


def _terms(text: str) -> set[str]:
    return set(re.findall(r"[a-zA-Z][a-zA-Z0-9_]{3,}", text.lower()))


def _memory_text(record: Mapping[str, Any]) -> str:
    metadata = _as_dict(record.get("metadata"))
    parts = [
        str(record.get("title") or ""),
        str(record.get("assertion") or ""),
        str(record.get("applies_when") or ""),
        str(metadata.get("root_cause") or ""),
        str(metadata.get("resolution") or ""),
        " ".join(_as_strings(metadata.get("steps"))),
        " ".join(_as_strings(metadata.get("identifiers"))),
        _searchable_external_evidence(metadata.get("external_evidence")),
    ]
    return "\n".join(part for part in parts if part)


def _searchable_external_evidence(value: Any) -> str:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return ""
    parts: list[str] = []
    for item in value:
        if not isinstance(item, Mapping):
            continue
        parts.extend(
            str(item.get(key) or "")
            for key in ("source", "project_reference", "function_name", "verification_result")
        )
        parts.extend(_as_strings(item.get("secret_names")))
    return " ".join(part for part in parts if part)


def _lexical_score(query_terms: set[str], text: str) -> float:
    if not query_terms:
        return 0.0
    text_terms = _terms(text)
    overlap = query_terms & text_terms
    return round(len(overlap) / max(1, len(query_terms)), 6)


def _deterministic_score(query: str, query_terms: set[str], text: str) -> tuple[float, str]:
    normalized_query = query.strip().casefold()
    if normalized_query and normalized_query in text.casefold():
        return 1.25, "exact_identifier"
    return _lexical_score(query_terms, text), "deterministic_lexical"


def _calibration_metrics(
    observations: Sequence[tuple[float, int, str]], *, bins: int
) -> dict[str, Any]:
    count = len(observations)
    brier = sum((probability - outcome) ** 2 for probability, outcome, _ in observations)
    grouped: dict[int, list[tuple[float, int]]] = {}
    for probability, outcome, _ in observations:
        index = min(bins - 1, int(probability * bins))
        grouped.setdefault(index, []).append((probability, outcome))
    calibration_bins = []
    ece = 0.0
    for index, items in sorted(grouped.items()):
        mean_probability = sum(item[0] for item in items) / len(items)
        observed_rate = sum(item[1] for item in items) / len(items)
        ece += len(items) / count * abs(mean_probability - observed_rate)
        calibration_bins.append(
            {
                "bin": index,
                "count": len(items),
                "mean_probability": round(mean_probability, 12),
                "observed_rate": round(observed_rate, 12),
            }
        )
    return {
        "count": count,
        "brier_score": round(brier / count, 12),
        "expected_calibration_error": round(ece, 12),
        "bins": calibration_bins,
        "forecast_ids": [item[2] for item in observations],
    }


def _find_revision(
    revisions: Sequence[Mapping[str, Any]], revision_id: str | None
) -> Mapping[str, Any] | None:
    return next(
        (item for item in revisions if str(item.get("revision_id")) == str(revision_id)),
        None,
    )


def _metadata_satisfies(value: Any, expected: str) -> bool:
    if expected == "non_empty_string":
        return isinstance(value, str) and bool(value.strip())
    if expected == "non_empty_list":
        return isinstance(value, Sequence) and not isinstance(value, str) and bool(value)
    if expected == "priority":
        return isinstance(value, (int, float)) or (
            isinstance(value, str)
            and value.strip().lower() in {"low", "medium", "high", "critical"}
        )
    return value is not None


def _agent_generated_without_validator(provenance: Mapping[str, Any]) -> bool:
    generator = str(provenance.get("generator") or "")
    validator = str(provenance.get("validator") or "none")
    return generator.startswith("agent:") and validator in {"", "none", "null"}


def _claims_policy_enforcement(assertion: str, metadata: Mapping[str, Any]) -> bool:
    if metadata.get("enforces") is True:
        return True
    lowered = assertion.lower()
    return any(
        phrase in lowered
        for phrase in (
            "this memory enforces",
            "enforce this policy",
            "must override policy",
            "bypass policy",
        )
    )


def _claims_policy_override(assertion: str, metadata: Mapping[str, Any]) -> bool:
    if metadata.get("overrides_policy") is True:
        return True
    lowered = assertion.lower()
    return any(
        phrase in lowered
        for phrase in (
            "override policy",
            "ignore policy",
            "bypass policy",
            "preference overrides",
            "must override policy",
        )
    )


def _is_external(source_kind: str, provenance: Mapping[str, Any]) -> bool:
    if bool(provenance.get("external")):
        return True
    normalized = source_kind.strip().lower()
    return normalized.startswith(
        ("external:", "slack", "email", "transcript", "jira", "confluence", "crm")
    )


def _require_actor_role(actor: str, minimum: str, action: str) -> None:
    authorization = require_actor_role(actor, minimum, action)
    if not authorization["ok"]:
        raise PermissionError(
            f"{action} requires {authorization['required_role']} role; "
            f"{authorization['actor']} is {authorization['actor_role']}"
        )


def _is_expired(record: Mapping[str, Any]) -> bool:
    value = _optional_string(record.get("expires_at"))
    if not value:
        return False
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed <= datetime.now(timezone.utc)


def _conflict_summary(left: str, right: str) -> str | None:
    left_l, right_l = left.lower(), right.lower()
    if ("must " in left_l and "must not" in right_l) or (
        "must not" in left_l and "must " in right_l
    ):
        return "Rules use conflicting obligation verbs."
    left_numbers = set(re.findall(r"\b\d+(?:[,_]\d+)*\b", left_l))
    right_numbers = set(re.findall(r"\b\d+(?:[,_]\d+)*\b", right_l))
    shared_terms = _terms(left_l) & _terms(right_l)
    if left_numbers and right_numbers and left_numbers != right_numbers and shared_terms:
        return "Records describe the same scope with incompatible numeric thresholds."
    return None


def _policy_priority(severity: str) -> int:
    return {"critical": 100, "high": 75, "medium": 50, "low": 25}.get(severity.strip().lower(), 50)


def _policy_matches_paths(policy: Mapping[str, Any], paths: Sequence[str]) -> bool:
    globs = _as_strings(policy.get("path_globs")) or ["**"]
    return any(fnmatch.fnmatch(path, glob) for path in paths for glob in globs)


def _policy_matches_scope(policy: Mapping[str, Any], scope: str) -> bool:
    declared = str(policy.get("scope") or "global")
    if declared == "global":
        return True
    if declared == scope:
        return True
    path = scope.removeprefix("path:")
    return _policy_matches_paths(policy, [path])
