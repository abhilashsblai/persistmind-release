from __future__ import annotations

import fnmatch
import hashlib
import json
import math
import re
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from persistmind.application.epistemics import CLAIM_STATUSES, normalize_epistemic_claim
from persistmind.application.execution_scope import current_operation_scope
from persistmind.config import load_settings
from persistmind.memory.decay import decayed_confidence
from persistmind.memory.source_scanners import SCANNERS
from persistmind.retrieval.embedder import cosine, make_embedder
from persistmind.security.memory_defense import (
    detect_query_injection,
    evaluate_ingest,
    require_actor_role,
    serve_decision,
    trust_aware_rank,
)
from persistmind.security.redaction import redact_with_summary
from persistmind.utils import canonical_json, sha256_text, stable_id, utc_now

from .adapters.sqlite_knowledge import KnowledgeConflict as _KnowledgeConflict
from .adapters.sqlite_knowledge import SQLiteKnowledgeStore
from .adapters.sqlite_policy import SQLitePolicyStore
from .descriptors import StoreRole
from .resources import load_memory_kinds
from .runtime import StorageOpenIntent, StorageRuntime, resolve_runtime_store

KnowledgeConflict = _KnowledgeConflict

_CLAIM_TRANSITIONS = {
    "candidate": {"supported", "refuted", "contested", "rejected", "quarantined", "unknown"},
    "supported": {"contested", "refuted", "stale", "superseded", "expired", "quarantined"},
    "refuted": {"contested", "superseded", "expired"},
    "contested": {"supported", "refuted", "stale", "superseded", "expired", "quarantined"},
    "stale": {"candidate", "supported", "refuted", "superseded", "expired"},
    "unknown": {"candidate", "supported", "refuted", "contested", "expired"},
    "quarantined": {"candidate", "rejected", "expired"},
    "superseded": set(),
    "expired": set(),
    "rejected": set(),
}


_TERMINAL_MEMORY_STATUSES = {
    "rejected",
    "expired",
    "quarantined",
    "needs_review",
    "superseded",
}
_ALLOWED_MEMORY_STATUSES = _TERMINAL_MEMORY_STATUSES | {
    "candidate",
    "active",
    "approved",
}
_SENSITIVE_MEMORY_TYPES = {
    "business_rule_candidate",
    "policy_reference",
    "preference",
    "org_knowledge",
}
_KNOWLEDGE_MEMORY_TYPES = {
    "fact",
    "decision",
    "episode",
    "architectural_decision",
    "convention",
    "preference",
    "gotcha",
    "failure_lesson",
    "pattern",
    "policy_reference",
    "business_rule_candidate",
    "org_knowledge",
    "org_knowledge_candidate",
}
MEMORY_TYPES = tuple(sorted(_KNOWLEDGE_MEMORY_TYPES))
MEMORY_STATUSES = tuple(sorted(_ALLOWED_MEMORY_STATUSES))
_TYPE_METADATA_REQUIREMENTS: dict[str, dict[str, str]] = {
    "architectural_decision": {
        "rationale": "non_empty_string",
        "alternatives": "non_empty_list",
    },
    "decision": {"rationale": "non_empty_string", "alternatives": "non_empty_list"},
    "failure_lesson": {
        "symptom": "non_empty_string",
        "root_cause": "non_empty_string",
        "resolution": "non_empty_string",
    },
    "policy_reference": {
        "policy_file": "non_empty_string",
        "policy_key": "non_empty_string",
    },
    "preference": {"priority": "priority"},
}


class KnowledgeService:
    """Knowledge and Policy Authority application port for an active next-generation catalog.

    This port owns canonical facts, decisions, evidence, provenance, lifecycle
    history, and non-authoritative business-rule candidates in the Knowledge
    role.  Policy activation is deliberately a separate operation against the
    Policy Authority role. No method can cross the declared authority routes.
    """

    def __init__(
        self,
        repo_root: Path,
        *,
        allow_development_driver: bool = False,
        runtime: StorageRuntime | None = None,
        read_only: bool = False,
    ) -> None:
        self.repo_root = repo_root.resolve()
        self.settings = load_settings(self.repo_root)
        self._allow_development_driver = allow_development_driver
        self.workspace_id = stable_id(str(self.repo_root))[:16]
        self.repo_id = self.workspace_id
        self._owns_runtime = runtime is None
        operation_scope = current_operation_scope()
        required_roles = (
            frozenset(StoreRole(role) for role in operation_scope.roles)
            if operation_scope is not None
            else frozenset({StoreRole.KNOWLEDGE, StoreRole.POLICY})
        ) | {StoreRole.KNOWLEDGE}
        self.runtime = runtime or StorageRuntime.open(
            self.repo_root / self.settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=allow_development_driver,
            read_only=read_only,
            required_roles=required_roles,
        )
        knowledge = resolve_runtime_store(self.runtime, StoreRole.KNOWLEDGE, read_only=read_only)
        if not isinstance(knowledge, SQLiteKnowledgeStore):
            raise RuntimeError("Knowledge route did not resolve to SQLiteKnowledgeStore")
        self.knowledge = knowledge
        self._policy: SQLitePolicyStore | None = None

    def close(self) -> None:
        if self._owns_runtime:
            self.runtime.close()

    def __enter__(self) -> KnowledgeService:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    @property
    def policy(self) -> SQLitePolicyStore:
        if self._policy is None:
            value = resolve_runtime_store(self.runtime, StoreRole.POLICY, read_only=True)
            if not isinstance(value, SQLitePolicyStore):
                raise RuntimeError("Policy read route did not resolve")
            self._policy = value
        return self._policy

    # -- Knowledge records -------------------------------------------------

    def claim_create(
        self, payload: Mapping[str, Any], *, actor: str = "local-user"
    ) -> dict[str, Any]:
        raw = dict(payload)
        source_class = str(raw.get("source_class") or "human_decision")
        external = source_class in {
            "external_report",
            "prompt",
            "tool_output",
            "connector",
        }
        defense = evaluate_ingest(
            str(raw.get("proposition") or ""),
            actor=actor,
            source_connector=source_class if external else None,
            external=external,
        )
        if external:
            raw["proposition"] = defense["sanitized_text"]
            raw["status"] = "candidate" if defense["ok"] else "quarantined"
            raw["source_identity"] = {
                **dict(raw.get("source_identity") or {}),
                "untrusted": True,
                "serve_authoritative": False,
                "defense": defense,
            }
        claim = normalize_epistemic_claim(
            raw,
            workspace_id=self.workspace_id,
            repository_id=self.repo_id,
        )
        record = self.knowledge.write_claim(
            claim,
            actor=actor,
            reason="claim created",
            expected_revision=0,
        )
        evidence_ids = self._put_evidence(str(claim["claim_id"]), payload.get("evidence"))
        return {
            "ok": True,
            "status": str(claim["status"]),
            "schema_version": "persistmind.epistemic_claim.v1",
            "claim": dict(record),
            "evidence_ids": evidence_ids,
            "defense": defense,
        }

    def claim_transition(
        self,
        claim_id: str,
        *,
        status: str,
        actor: str,
        reason: str,
        updates: Mapping[str, Any] | None = None,
        expected_revision: int | None = None,
    ) -> dict[str, Any]:
        current = self.knowledge.get(claim_id)
        if current is None or str(current.get("kind")) != "epistemic_claim":
            raise KeyError(f"epistemic claim not found: {claim_id}")
        normalized_status = status.strip().lower()
        if normalized_status not in CLAIM_STATUSES:
            raise ValueError(f"unsupported epistemic claim status: {status}")
        current_status = str(current.get("status") or "unknown")
        if (
            normalized_status != current_status
            and normalized_status not in _CLAIM_TRANSITIONS[current_status]
        ):
            raise ValueError(
                f"invalid epistemic claim transition: {current_status} -> {normalized_status}"
            )
        if normalized_status in {"supported", "refuted"} and not self.knowledge.evidence(claim_id):
            raise ValueError(f"claim status {normalized_status} requires immutable evidence")
        document = {
            key: value
            for key, value in current.items()
            if not str(key).startswith("_") and key not in {"record_id", "kind", "scope"}
        }
        document.update(dict(updates or {}))
        document.update(
            {
                "claim_id": claim_id,
                "status": normalized_status,
                "revision": int(current["_revision"]) + 1,
            }
        )
        claim = normalize_epistemic_claim(
            document,
            workspace_id=self.workspace_id,
            repository_id=self.repo_id,
        )
        record = self.knowledge.write_claim(
            claim,
            actor=actor,
            reason=reason,
            expected_revision=(
                expected_revision if expected_revision is not None else int(current["_revision"])
            ),
        )
        return {
            "ok": True,
            "status": normalized_status,
            "schema_version": "persistmind.epistemic_claim_transition.v1",
            "claim": dict(record),
        }

    def claim_relation_add(
        self,
        subject_id: str,
        predicate: str,
        object_id: str,
        *,
        evidence_id: str | None = None,
        support_score: float | None = None,
        valid_from: str | None = None,
        valid_to: str | None = None,
    ) -> dict[str, Any]:
        for claim_id in (subject_id, object_id):
            claim = self.knowledge.get(claim_id)
            if claim is None or str(claim.get("kind")) != "epistemic_claim":
                raise KeyError(f"epistemic claim not found: {claim_id}")
        if support_score is not None and not 0 <= float(support_score) <= 1:
            raise ValueError("relation support_score must be between 0 and 1")
        relation_id = (
            "relation_"
            + stable_id(subject_id, predicate, object_id, evidence_id or "", valid_from or "")[:32]
        )
        with self.knowledge._write_lock, self.knowledge.connection:
            self.knowledge.connection.execute(
                "INSERT OR IGNORE INTO knowledge_claim_relations VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    relation_id,
                    subject_id,
                    predicate,
                    object_id,
                    evidence_id,
                    support_score,
                    valid_from or utc_now(),
                    valid_to,
                    utc_now(),
                ),
            )
            self.knowledge.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return {"ok": True, "relation_id": relation_id}

    def forecast_create(
        self,
        claim_id: str,
        *,
        probability: float,
        calibrator_id: str,
        stratum: str,
        context: Mapping[str, Any],
        resolves_by: str,
        support_score: float | None = None,
    ) -> dict[str, Any]:
        if self.knowledge.get(claim_id) is None:
            raise KeyError(f"epistemic claim not found: {claim_id}")
        if not 0 <= probability <= 1 or (support_score is not None and not 0 <= support_score <= 1):
            raise ValueError("forecast probability and support score must be between 0 and 1")
        context_hash = "sha256:" + sha256_text(canonical_json(dict(context)))
        predicted_at = utc_now()
        forecast_id = (
            "forecast_"
            + stable_id(claim_id, calibrator_id, stratum, context_hash, predicted_at)[:32]
        )
        with self.knowledge._write_lock, self.knowledge.connection:
            self.knowledge.connection.execute(
                "INSERT INTO knowledge_forecasts VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    forecast_id,
                    claim_id,
                    probability,
                    support_score,
                    calibrator_id,
                    stratum,
                    context_hash,
                    predicted_at,
                    resolves_by,
                ),
            )
        return {"ok": True, "forecast_id": forecast_id, "context_hash": context_hash}

    def forecast_observe(
        self,
        forecast_id: str,
        *,
        outcome: bool,
        evidence_id: str,
        observed_at: str | None = None,
    ) -> dict[str, Any]:
        with self.knowledge._write_lock, self.knowledge.connection:
            self.knowledge.connection.execute(
                "INSERT INTO knowledge_forecast_outcomes VALUES(?,?,?,?)",
                (forecast_id, int(outcome), evidence_id, observed_at or utc_now()),
            )
        return {"ok": True, "forecast_id": forecast_id, "outcome": bool(outcome)}

    def claim_show(
        self,
        claim_id: str,
        *,
        valid_at: str | None = None,
        transaction_at: str | None = None,
    ) -> dict[str, Any]:
        revisions = [dict(item) for item in self.knowledge.claim_revisions(claim_id)]
        candidates = revisions
        if transaction_at:
            candidates = [
                item for item in candidates if str(item.get("recorded_at") or "") <= transaction_at
            ]
        if valid_at:
            candidates = [
                item
                for item in candidates
                if str(item.get("valid_from") or "") <= valid_at
                and (item.get("valid_to") is None or str(item.get("valid_to")) >= valid_at)
            ]
        claim = candidates[-1] if candidates else None
        if claim is None:
            return {
                "ok": False,
                "status": "unknown",
                "schema_version": "persistmind.epistemic_claim_view.v1",
                "claim_id": claim_id,
            }
        return {
            "ok": True,
            "status": str(claim.get("status") or "unknown"),
            "schema_version": "persistmind.epistemic_claim_view.v1",
            "claim": claim,
            "evidence": list(self.knowledge.evidence(claim_id)),
            "relations": self._claim_relations(claim_id),
            "revisions": revisions,
            "valid_at": valid_at,
            "transaction_at": transaction_at,
        }

    def claim_recall(
        self,
        query: str,
        *,
        paths: Sequence[str] | None = None,
        valid_at: str | None = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        defense = detect_query_injection(query)
        if not defense["ok"]:
            return {
                "ok": True,
                "status": "unknown",
                "schema_version": "persistmind.epistemic_claim_recall.v1",
                "claims": [],
                "defense": defense,
            }
        now = valid_at or utc_now()
        terms = _terms(query)
        requested_paths = {str(item).replace("\\", "/") for item in paths or []}
        rows = self.knowledge.connection.execute(
            "SELECT * FROM domain_records WHERE kind='epistemic_claim' ORDER BY updated_at DESC"
        ).fetchall()
        included: list[dict[str, Any]] = []
        excluded = {"lifecycle": 0, "validity": 0, "scope": 0, "untrusted": 0}
        for row in rows:
            claim = self.knowledge._record(row)
            if str(claim.get("status")) not in {"supported", "contested"}:
                excluded["lifecycle"] += 1
                continue
            if str(claim.get("valid_from") or "") > now or (
                claim.get("valid_to") is not None and str(claim.get("valid_to")) < now
            ):
                excluded["validity"] += 1
                continue
            source_identity = dict(claim.get("source_identity") or {})
            if source_identity.get("untrusted") and not source_identity.get("validated_by"):
                excluded["untrusted"] += 1
                continue
            scopes = {str(item).replace("\\", "/") for item in claim.get("path_scope") or []}
            if (
                requested_paths
                and scopes
                and not any(
                    fnmatch.fnmatch(path, scope) or fnmatch.fnmatch(scope, path)
                    for path in requested_paths
                    for scope in scopes
                )
            ):
                excluded["scope"] += 1
                continue
            score = _lexical_score(terms, str(claim.get("proposition") or ""))
            if score > 0:
                included.append({**claim, "score": score})
        included.sort(key=lambda item: (-float(item["score"]), str(item["claim_id"])))
        selected = included[: max(1, min(int(limit), 1000))]
        return {
            "ok": True,
            "status": "supported" if selected else "unknown",
            "schema_version": "persistmind.epistemic_claim_recall.v1",
            "claims": selected,
            "excluded": excluded,
            "defense": defense,
        }

    def claim_conflicts(self, claim_id: str | None = None) -> dict[str, Any]:
        clause = " WHERE subject_id=? OR object_id=?" if claim_id else ""
        values = (claim_id, claim_id) if claim_id else ()
        rows = self.knowledge.connection.execute(
            "SELECT * FROM knowledge_claim_relations" + clause + " ORDER BY relation_id",
            values,
        ).fetchall()
        conflicts = [
            dict(row)
            for row in rows
            if str(row["predicate"]) in {"contradicts", "refutes", "incompatible_with"}
        ]
        return {
            "ok": not conflicts,
            "status": "contradictory" if conflicts else "supported",
            "schema_version": "persistmind.epistemic_conflicts.v1",
            "conflicts": conflicts,
        }

    def forecast_calibration(
        self, *, calibrator_id: str | None = None, bins: int = 10
    ) -> dict[str, Any]:
        bounded_bins = max(2, min(int(bins), 100))
        where = " WHERE f.calibrator_id=?" if calibrator_id else ""
        values = (calibrator_id,) if calibrator_id else ()
        rows = self.knowledge.connection.execute(
            "SELECT f.*,o.outcome,o.observed_at,r.payload_json "
            "FROM knowledge_forecasts f "
            "JOIN knowledge_forecast_outcomes o ON o.forecast_id=f.forecast_id "
            "JOIN domain_records r ON r.record_id=f.claim_id"
            + where
            + " ORDER BY f.stratum,f.predicted_at,f.forecast_id",
            values,
        ).fetchall()
        groups: dict[str, list[tuple[float, int, str]]] = {}
        sources: dict[str, list[tuple[float, int]]] = {}
        for row in rows:
            probability, outcome = float(row["probability"]), int(row["outcome"])
            groups.setdefault(str(row["stratum"]), []).append(
                (probability, outcome, str(row["forecast_id"]))
            )
            claim = json.loads(str(row["payload_json"]))
            source = canonical_json(dict(claim.get("source_identity") or {}))
            sources.setdefault(source, []).append((probability, outcome))
        strata = {
            name: _calibration_metrics(items, bins=bounded_bins)
            for name, items in sorted(groups.items())
        }
        reliability = {
            source: {
                "resolved_outcomes": len(items),
                "brier_score": round(
                    sum((probability - outcome) ** 2 for probability, outcome in items)
                    / len(items),
                    12,
                ),
            }
            for source, items in sorted(sources.items())
        }
        return {
            "ok": True,
            "status": "not_computable" if not rows else "verified",
            "schema_version": "persistmind.forecast_calibration.v1",
            "calibrator_id": calibrator_id,
            "resolved_forecasts": len(rows),
            "strata": strata,
            "source_reliability": reliability,
        }

    def _claim_relations(self, claim_id: str) -> list[dict[str, Any]]:
        rows = self.knowledge.connection.execute(
            "SELECT * FROM knowledge_claim_relations "
            "WHERE subject_id=? OR object_id=? ORDER BY relation_id",
            (claim_id, claim_id),
        ).fetchall()
        return [dict(row) for row in rows]

    def memory_create_typed(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        """Create a candidate/ordinary memory without granting policy authority."""

        raw = dict(payload)
        requested_type = str(raw.get("type") or raw.get("record_type") or "").strip()
        record_type = (
            "business_rule_candidate" if requested_type == "business_rule" else requested_type
        )
        assertion = str(raw.get("assertion") or "").strip()
        metadata = _as_dict(raw.get("metadata") or raw.get("metadata_json"))
        evidence_items = raw.get("evidence") or raw.get("evidence_refs") or []
        scope_refs = raw.get("scope_refs")
        if scope_refs is not None:
            metadata["scope_refs"] = _as_strings(scope_refs)
        for scope_key in ("branch", "task_session_id", "cross_branch_ok"):
            if raw.get(scope_key) is not None:
                metadata[scope_key] = raw.get(scope_key)
        if raw.get("source_revision_at_write") is not None:
            metadata["source_revision_at_write"] = raw.get("source_revision_at_write")
        elif _needs_source_revision_stamp(raw, metadata):
            metadata.setdefault("source_revision_at_write", self._source_revision_at_write())
        source_paths = _source_bound_paths(raw, metadata, evidence_items)
        if source_paths:
            metadata["source_path_hashes_at_write"] = self._source_path_hashes(source_paths)
        provenance = _as_dict(raw.get("provenance"))
        source_kind = str(raw.get("source_kind") or "manual")
        status = str(raw.get("status") or "candidate").strip().lower()
        trust = str(raw.get("trust") or _default_trust(status)).strip().lower()
        self._validate_memory_payload(
            record_type=record_type,
            assertion=assertion,
            status=status,
            provenance=provenance,
            metadata=metadata,
        )
        if record_type == "business_rule_candidate":
            if status != "candidate":
                raise ValueError(
                    "business_rule_candidate must remain candidate until explicit Policy approval"
                )
            if (
                not isinstance(evidence_items, Sequence)
                or isinstance(evidence_items, (str, bytes))
                or not evidence_items
            ):
                raise ValueError("business_rule_candidate requires at least one evidence record")
        defense = self._ingest_defense(
            assertion,
            source_kind=source_kind,
            owner=_optional_string(raw.get("owner")),
            provenance=provenance,
            metadata=metadata,
        )
        assertion = str(defense["assertion"])
        provenance = dict(defense["provenance"])
        metadata = dict(defense["metadata"])
        if not defense["ok"]:
            status = "quarantined"
            trust = "untrusted"
        assertion, metadata = _redact_memory_assertion(assertion, metadata)

        scope = str(raw.get("scope") or self._scope_from_refs(raw, metadata))
        record_id = str(
            raw.get("record_id") or self._memory_id(record_type, assertion, scope, source_kind)
        )
        document = {
            "schema_version": "persistmind.knowledge_record.v1",
            "record_id": record_id,
            "kind": "memory",
            "type": record_type,
            "title": _optional_string(raw.get("title")) or assertion[:80],
            "assertion": assertion,
            "scope": scope,
            "scope_kind": _scope_kind(scope),
            "scope_refs": _scope_refs(scope, metadata),
            "status": status,
            "confidence": _confidence(raw.get("confidence"), default=1.0),
            "importance": _confidence(
                raw.get("importance"), default=_confidence(raw.get("confidence"), default=1.0)
            ),
            "trust": trust,
            "source_kind": source_kind,
            "extraction_method": str(raw.get("extraction_method") or "manual"),
            "owner": _optional_string(raw.get("owner")),
            "applies_when": _optional_string(raw.get("applies_when")),
            "avoid_when": _optional_string(raw.get("avoid_when")),
            "expires_at": _optional_string(raw.get("expires_at")),
            "invalidates_when": _optional_string(raw.get("invalidates_when")),
            "last_validated_at": _optional_string(raw.get("last_validated_at")),
            "superseded_by": _optional_string(raw.get("superseded_by")),
            "provenance": provenance,
            "metadata": metadata,
        }
        record = self.knowledge.write_memory_record(
            document,
            actor=str(raw.get("actor") or "local-user"),
            reason="create",
            idempotency_key=f"knowledge-create:{record_id}",
        )
        projection = self._after_memory_write(
            record,
            actor=str(raw.get("actor") or "local-user"),
            reason="create",
        )
        self._put_evidence(record_id, evidence_items)
        response = self._record_response(record)
        _attach_projection_report(response, projection)
        if requested_type == "business_rule":
            response.setdefault("warnings", []).append(
                {
                    "type": "deprecated_memory_kind",
                    "message": "business_rule is stored as business_rule_candidate; use policy approve-business-rule for authority.",
                }
            )
        return response

    def memory_propose(
        self,
        record_type: str,
        assertion: str,
        evidence_refs: Sequence[Mapping[str, Any]] | None = None,
        source_kind: str = "manual",
        confidence: float = 1.0,
    ) -> dict[str, Any]:
        result = self.memory_create_typed(
            {
                "type": record_type,
                "assertion": assertion,
                "evidence": list(evidence_refs or ()),
                "source_kind": source_kind,
                "confidence": confidence,
                "status": "candidate",
            }
        )
        return {
            "ok": True,
            "record_id": result["record"]["record_id"],
            "status": result["record"]["status"],
            "record": result["record"],
            "nextgen_v1": True,
        }

    def memory_records(
        self, status: str | None = None, types: Sequence[str] | None = None
    ) -> dict[str, Any]:
        return {
            "ok": True,
            "schema_version": "persistmind.knowledge_records.v1",
            "records": [
                self._project_record(row)
                for row in self.knowledge.memory_records(status=status, types=types)
            ],
            "nextgen_v1": True,
        }

    def memory_list(self, status: str | None = None) -> dict[str, Any]:
        return self.memory_records(status=status)

    def memory_show(self, record_id: str) -> dict[str, Any]:
        record = self.knowledge.get(record_id)
        if record is None or str(record.get("kind")) != "memory":
            return {"ok": False, "error": "memory not found", "record_id": record_id}
        return {
            "ok": True,
            "schema_version": "persistmind.knowledge_memory_show.v1",
            "record": self._project_record(record),
            "evidence": list(self.knowledge.evidence(record_id)),
            "revisions": list(self.knowledge.memory_revisions(record_id)),
            "transitions": list(self.knowledge.memory_transitions(record_id)),
            "nextgen_v1": True,
        }

    def memory_explain(self, record_id: str) -> dict[str, Any]:
        shown = self.memory_show(record_id)
        if not shown.get("ok"):
            return shown
        return {"ok": True, "type": "memory_record", **shown}

    def memory_search(
        self,
        query: str,
        types: Sequence[str] | None = None,
        status: str | None = None,
    ) -> dict[str, Any]:
        query = query.strip()
        if not query:
            raise ValueError("memory search requires a query")
        terms = _terms(query)
        fts_records, fts_status = self._memory_fts_candidates(
            query, status=status, types=types, limit=1000
        )
        fts_rank_by_id = {
            str(item["record_id"]): float(item.get("_fts_rank") or 0.0) for item in fts_records
        }
        source_records = fts_records or list(
            self.knowledge.memory_records(status=status, types=types)
        )
        results: list[dict[str, Any]] = []
        for record in source_records:
            score, match_method = _deterministic_score(query, terms, _memory_text(record))
            if str(record["record_id"]) in fts_rank_by_id:
                fts_candidate = _fts_score(fts_rank_by_id[str(record["record_id"])])
                if fts_candidate > score:
                    score = fts_candidate
                    match_method = "fts5"
            if score <= 0:
                continue
            projected = self._project_record(record)
            projected["score"] = score
            projected["match_method"] = match_method
            results.append(projected)
        results.sort(key=lambda item: (-float(item["score"]), item["record_id"]))
        return {
            "ok": True,
            "schema_version": "persistmind.knowledge_memory_search.v1",
            "query": query,
            "results": results,
            "backend_status": {
                "full_text": fts_status["status"],
                "vector": "not_configured",
                "fallback": "deterministic_lexical",
                "exact_identifier": "always_on",
                "full_text_error": fts_status.get("error"),
            },
            "nextgen_v1": True,
        }

    def _memory_fts_candidates(
        self,
        query: str,
        *,
        status: str | None = None,
        types: Sequence[str] | None = None,
        limit: int = 1000,
    ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        try:
            records = [
                dict(item)
                for item in self.knowledge.memory_fts_search(
                    query, status=status, types=types, limit=limit
                )
            ]
        except Exception as exc:
            return [], {"status": "degraded", "error": str(exc)}
        return records, {"status": "ready", "error": None}

    def memory_recall(
        self,
        query: str,
        paths: Sequence[str] | None = None,
        types: Sequence[str] | None = None,
        limit: int = 20,
        include_org: bool = False,
    ) -> dict[str, Any]:
        if include_org:
            from persistmind.security.context import require_current_principal

            require_current_principal(
                roles=frozenset({"operator", "admin"}),
                action="organization.memory.read",
            )
        query = query.strip()
        if not query:
            raise ValueError("memory recall requires a query")
        query_defense = detect_query_injection(query)
        if not query_defense["ok"]:
            return {
                "ok": True,
                "schema_version": "persistmind.memory_recall.v1",
                "query": query,
                "items": [],
                "records": [],
                "defense": {"query": query_defense, "excluded": {"query_injection": 1}},
                "nextgen_v1": True,
            }
        path_set = {item.replace("\\", "/") for item in paths or () if item}
        allowed_types = {str(item) for item in types or ()}
        query_terms = _terms(query)
        candidates: list[dict[str, Any]] = []
        stale_candidates: list[dict[str, Any]] = []
        excluded = {
            "terminal": 0,
            "not_authoritative": 0,
            "scope": 0,
            "org": 0,
            "stale": 0,
            "generic": 0,
        }
        total_matching = self.knowledge.memory_record_count(status=None, types=types)
        corpus_limit = 10_000
        corpus_truncated = total_matching > corpus_limit
        fts_records, fts_status = self._memory_fts_candidates(
            query, types=types, limit=corpus_limit
        )
        fts_rank_by_id = {
            str(item["record_id"]): float(item.get("_fts_rank") or 0.0) for item in fts_records
        }
        vector_enabled = bool(getattr(self.settings.storage, "memory_vector_index", True))
        vector_model = str(getattr(self.settings.toolchain, "embed_model", "local-lexical-v1"))
        embedder = None
        query_vector: list[float] = []
        if vector_enabled:
            embedder = make_embedder(
                model_name=vector_model,
                backend=str(getattr(self.settings.toolchain, "embed_backend", "auto")),
            )
            query_vector = embedder.embed(query)
        for raw_record in self.knowledge.memory_records(types=types, limit=corpus_limit):
            record = dict(raw_record)
            metadata = _as_dict(record.get("metadata"))
            source_hashes = _as_dict(metadata.get("source_path_hashes_at_write"))
            if source_hashes:
                metadata["source_path_hashes_current"] = self._source_path_hashes(
                    source_hashes.keys()
                )
                record["metadata"] = metadata
            record_type = str(record.get("type") or "")
            status = str(record.get("status") or "candidate")
            if allowed_types and record_type not in allowed_types:
                continue
            if status in _TERMINAL_MEMORY_STATUSES or status not in {"active", "approved"}:
                excluded["terminal"] += 1
                continue
            if record_type == "org_knowledge" and not include_org:
                excluded["org"] += 1
                continue
            if not self._serves_authoritatively(record):
                excluded["not_authoritative"] += 1
                continue
            if path_set and not self._scope_matches(record, path_set):
                excluded["scope"] += 1
                continue
            text = _memory_text(record)
            score, match_method = _deterministic_score(query, query_terms, text)
            if str(record["record_id"]) in fts_rank_by_id:
                fts_candidate = _fts_score(fts_rank_by_id[str(record["record_id"])])
                if fts_candidate > score:
                    score = fts_candidate
                    match_method = "fts5"
            vector_score = 0.0
            if query_vector and embedder is not None:
                record_vector = self.knowledge.memory_vector(
                    str(record["record_id"]), model_name=vector_model
                )
                if record_vector is None:
                    record_vector = embedder.embed(text)
                    self.knowledge.memory_vector_upsert(
                        str(record["record_id"]),
                        model_name=vector_model,
                        vector=record_vector,
                    )
                vector_score = max(0.0, cosine(query_vector, record_vector))
                if vector_score >= 0.15 and vector_score > score:
                    score = round((score * 0.45) + (vector_score * 0.85), 6)
                    match_method = "vector_semantic"
            if score <= 0:
                continue
            projected = self._project_record(record)
            if _is_expired(record):
                projected["score"] = score
                projected["match_method"] = match_method
                projected["freshness_status"] = "stale"
                projected["requires_revalidation"] = True
                stale_candidates.append(projected)
                excluded["stale"] += 1
                continue
            if _as_dict(record.get("metadata")).get("live_state"):
                projected["freshness_status"] = "last_verified"
                projected["requires_revalidation"] = False
            generic = _is_generic_recall_record(record)
            if generic:
                score *= 0.25
                projected["recall_generic"] = True
                excluded["generic"] += 1
            age_days = _memory_age_days(record)
            decayed = decayed_confidence(float(projected["confidence"]), age_days)
            projected["score"] = round(score + decayed * 0.05, 6)
            projected["match_method"] = match_method
            projected["decayed_confidence"] = decayed
            projected["decay_age_days"] = age_days
            if vector_score:
                projected["vector_score"] = round(vector_score, 6)
            candidates.append(projected)
        ranked = trust_aware_rank(candidates)
        selected = _select_recall_items(ranked, max(1, min(int(limit), 1000)))
        return {
            "ok": True,
            "schema_version": "persistmind.memory_recall.v1",
            "query": query,
            "items": selected,
            "records": selected,
            "stale_records": sorted(
                stale_candidates,
                key=lambda item: (-float(item["score"]), str(item["record_id"])),
            )[: max(1, min(int(limit), 1000))],
            "defense": {"query": query_defense, "excluded": excluded},
            "corpus": {
                "total_matching": total_matching,
                "loaded": min(total_matching, corpus_limit),
                "limit": corpus_limit,
                "truncated": corpus_truncated,
            },
            "backend_status": {
                "full_text": fts_status["status"],
                "vector": (
                    "disabled"
                    if not vector_enabled
                    else ("degraded" if getattr(embedder, "degraded_reason", None) else "ready")
                ),
                "fallback": "deterministic_lexical",
                "exact_identifier": "always_on",
                "vector_backend": getattr(embedder, "backend", None),
                "vector_model": getattr(embedder, "model_name", None),
                "degraded_reason": getattr(embedder, "degraded_reason", None),
                "degraded_remediation": getattr(embedder, "degraded_remediation", None),
                "full_text_error": fts_status.get("error"),
            },
            "nextgen_v1": True,
        }

    def memory_update(
        self,
        record_id: str,
        patch: Mapping[str, Any],
        reason: str = "manual update",
        actor: str = "local-user",
    ) -> dict[str, Any]:
        current = self._memory_or_raise(record_id)
        raw_patch = dict(patch)
        expected_revision = raw_patch.pop("expected_revision", None)
        forbidden = {
            "record_id",
            "type",
            "kind",
            "status",
            "trust",
            "policy_id",
            "directive_id",
            "approved_by",
            "signature",
        }
        bad = sorted(forbidden & set(raw_patch))
        if bad:
            raise ValueError(
                "memory update cannot alter authority or lifecycle fields: " + ", ".join(bad)
            )
        document = _without_internal(current)
        for field in (
            "title",
            "assertion",
            "scope",
            "confidence",
            "importance",
            "source_kind",
            "extraction_method",
            "owner",
            "applies_when",
            "avoid_when",
            "expires_at",
            "invalidates_when",
            "last_validated_at",
            "superseded_by",
        ):
            if field in raw_patch:
                document[field] = raw_patch[field]
        if "metadata" in raw_patch:
            document["metadata"] = _as_dict(raw_patch["metadata"])
        if "provenance" in raw_patch:
            document["provenance"] = _as_dict(raw_patch["provenance"])
        if "scope_refs" in raw_patch:
            metadata = _as_dict(document.get("metadata"))
            metadata["scope_refs"] = _as_strings(raw_patch["scope_refs"])
            document["metadata"] = metadata
            document["scope_refs"] = _scope_refs(str(document["scope"]), metadata)
        document["assertion"] = str(document.get("assertion") or "").strip()
        document["scope"] = str(document.get("scope") or "").strip()
        document["confidence"] = _confidence(document.get("confidence"), default=1.0)
        document["importance"] = _confidence(
            document.get("importance"), default=document["confidence"]
        )
        document["scope_kind"] = _scope_kind(document["scope"])
        self._validate_memory_payload(
            record_type=str(document["type"]),
            assertion=document["assertion"],
            status=str(document["status"]),
            provenance=_as_dict(document.get("provenance")),
            metadata=_as_dict(document.get("metadata")),
        )
        defense = self._ingest_defense(
            document["assertion"],
            source_kind=str(document.get("source_kind") or "manual"),
            owner=_optional_string(document.get("owner")),
            provenance=_as_dict(document.get("provenance")),
            metadata=_as_dict(document.get("metadata")),
        )
        document["assertion"] = defense["assertion"]
        document["provenance"] = defense["provenance"]
        document["metadata"] = defense["metadata"]
        if not defense["ok"]:
            document["status"] = "quarantined"
            document["trust"] = "untrusted"
        document["assertion"], document["metadata"] = _redact_memory_assertion(
            str(document["assertion"]), _as_dict(document.get("metadata"))
        )
        updated = self.knowledge.write_memory_record(
            document,
            actor=actor,
            reason=reason,
            expected_revision=(int(expected_revision) if expected_revision is not None else None),
        )
        projection = self._after_memory_write(updated, actor=actor, reason=reason)
        response = self._record_response(updated)
        _attach_projection_report(response, projection)
        return response

    def memory_validate(
        self,
        record_id: str,
        validator: str,
        evidence: Mapping[str, Any] | None = None,
        actor: str = "local-user",
    ) -> dict[str, Any]:
        record = self._memory_or_raise(record_id)
        if str(record["type"]) == "business_rule_candidate":
            raise ValueError(
                "business_rule_candidate remains non-authoritative; use policy approve-business-rule"
            )
        if str(record["type"]) in _SENSITIVE_MEMORY_TYPES or str(record["status"]) in {
            "needs_review",
            "quarantined",
        }:
            _require_actor_role(actor, "codeowner", "memory_validate_sensitive")
        document = _without_internal(record)
        provenance = _as_dict(document.get("provenance"))
        provenance.update({"validator": validator, "validated_at": utc_now()})
        if evidence:
            provenance["validation_evidence"] = dict(evidence)
        document["provenance"] = provenance
        document["last_validated_at"] = utc_now()
        document["trust"] = "active"
        document["status"] = "active"
        updated = self.knowledge.write_memory_record(
            document,
            actor=actor,
            reason=f"validated by {validator}",
            expected_revision=int(record["_revision"]),
        )
        projection = self._after_memory_write(
            updated, actor=actor, reason=f"validated by {validator}"
        )
        response = self._record_response(updated)
        _attach_projection_report(response, projection)
        return response

    def memory_approve(
        self,
        record_id: str,
        approved_by: str = "local-user",
        signature: str | None = None,
    ) -> dict[str, Any]:
        record = self._memory_or_raise(record_id)
        if str(record["type"]) == "business_rule_candidate":
            if not signature:
                raise ValueError(
                    "business_rule candidate approval requires a policy signature; use policy approve-business-rule"
                )
            return self.policy_approve_business_rule(
                record_id,
                approver=approved_by,
                signature=signature,
            )
        return self.memory_validate(
            record_id,
            validator="human:approval",
            actor=approved_by,
        )

    def memory_reject(self, record_id: str, actor: str = "local-user") -> dict[str, Any]:
        return self._set_memory_status(record_id, "rejected", actor=actor, reason="rejected")

    def memory_expire(
        self, record_id: str, reason: str, actor: str = "local-user"
    ) -> dict[str, Any]:
        return self._set_memory_status(record_id, "expired", actor=actor, reason=reason)

    def memory_quarantine(
        self,
        record_id: str,
        reason: str,
        severity: str = "high",
        actor: str = "codeowner",
    ) -> dict[str, Any]:
        _require_actor_role(actor, "codeowner", "memory_quarantine")
        result = self._set_memory_status(
            record_id,
            "quarantined",
            actor=actor,
            reason=reason,
            trust="untrusted",
        )
        result["review"] = {
            "status": "pending",
            "severity": severity,
            "reason": reason,
            "note": "quarantined record is present in the derived review queue",
        }
        return result

    def memory_supersede(
        self, old_record_id: str, new_record_id: str, approved_by: str = "local-user"
    ) -> dict[str, Any]:
        old = self._memory_or_raise(old_record_id)
        new = self._memory_or_raise(new_record_id)
        if (
            str(old["type"]) in _SENSITIVE_MEMORY_TYPES
            or str(new["type"]) in _SENSITIVE_MEMORY_TYPES
        ):
            _require_actor_role(approved_by, "codeowner", "memory_supersede_sensitive")
        document = _without_internal(old)
        document["status"] = "superseded"
        document["superseded_by"] = new_record_id
        updated = self.knowledge.write_memory_record(
            document,
            actor=approved_by,
            reason=f"superseded by {new_record_id}",
            expected_revision=int(old["_revision"]),
        )
        self.knowledge.memory_edge_create(
            new_record_id,
            old_record_id,
            "supersedes",
            weight=1.0,
            evidence=[{"reason": "memory_supersede"}],
        )
        projection = self._after_memory_write(
            updated,
            actor=approved_by,
            reason=f"superseded by {new_record_id}",
        )
        old_policy_id = _as_dict(old.get("metadata")).get("policy_id")
        result = {
            "ok": True,
            "old_record_id": old_record_id,
            "new_record_id": new_record_id,
            "record": self._project_record(updated),
            "policy_transition_required": str(old_policy_id) if old_policy_id else None,
            "nextgen_v1": True,
        }
        _attach_projection_report(result, projection)
        return result

    def memory_diff(
        self,
        record_id: str,
        revision_a: str | None = None,
        revision_b: str | None = None,
    ) -> dict[str, Any]:
        revisions = list(self.knowledge.memory_revisions(record_id))
        if not revisions:
            return {"ok": False, "record_id": record_id, "error": "no revisions"}
        left = _find_revision(revisions, revision_a) if revision_a else revisions[0]
        right = _find_revision(revisions, revision_b) if revision_b else revisions[-1]
        if left is None or right is None:
            return {"ok": False, "record_id": record_id, "error": "revision not found"}
        before = _as_dict(left.get("record"))
        after = _as_dict(right.get("record"))
        changed = {
            key: {"before": before.get(key), "after": after.get(key)}
            for key in sorted(set(before) | set(after))
            if before.get(key) != after.get(key)
        }
        return {
            "ok": True,
            "record_id": record_id,
            "revision_a": left["revision_id"],
            "revision_b": right["revision_id"],
            "changed": changed,
            "nextgen_v1": True,
        }

    def memory_conflicts(self) -> dict[str, Any]:
        records = [
            item
            for item in self.knowledge.memory_records(limit=10_000)
            if str(item.get("status")) in {"active", "approved"}
        ]
        by_subject: dict[str, list[Mapping[str, Any]]] = {}
        for record in records:
            by_subject.setdefault(_memory_subject_key(record), []).append(record)
        for subject_key, subject_records in by_subject.items():
            for index, left in enumerate(subject_records):
                for right in subject_records[index + 1 :]:
                    summary = _conflict_summary(
                        str(left.get("assertion") or ""), str(right.get("assertion") or "")
                    )
                    if not summary:
                        continue
                    conflict = self.knowledge.upsert_memory_conflict(
                        str(left["record_id"]),
                        str(right["record_id"]),
                        subject_key=subject_key,
                        summary=summary,
                        metadata={"detected_by": "memory_conflicts"},
                    )
                    self.knowledge.memory_edge_create(
                        str(left["record_id"]),
                        str(right["record_id"]),
                        "contradicts",
                        weight=0.9,
                        evidence=[{"conflict_id": str(conflict["conflict_id"])}],
                    )
        conflicts: list[dict[str, Any]] = []
        for item in self.knowledge.memory_conflicts(status="open"):
            left = self.knowledge.get(str(item.get("left_record_id")))
            right = self.knowledge.get(str(item.get("right_record_id")))
            if (
                left is None
                or right is None
                or str(left.get("status")) not in {"active", "approved", "needs_review"}
                or str(right.get("status")) not in {"active", "approved", "needs_review"}
            ):
                continue
            summary = _conflict_summary(
                str(left.get("assertion") or ""), str(right.get("assertion") or "")
            )
            if summary:
                projected = dict(item)
                projected["summary"] = summary
                projected["recommended_action"] = "Review and supersede one record."
                conflicts.append(projected)
        return {
            "ok": not conflicts,
            "status": "conflict_detected" if conflicts else "ok",
            "conflicts": conflicts,
            "nextgen_v1": True,
        }

    def memory_stale(self) -> dict[str, Any]:
        stale: list[dict[str, Any]] = []
        for record in self.knowledge.memory_records():
            if str(record.get("status")) not in {"active", "approved"}:
                continue
            if _is_expired(record):
                stale.append({"record_id": record["record_id"], "reason": "expired"})
            elif not self.knowledge.evidence(str(record["record_id"])):
                stale.append({"record_id": record["record_id"], "reason": "no evidence"})
        return {"ok": True, "stale": stale, "nextgen_v1": True}

    def memory_verify(self) -> dict[str, Any]:
        violations: list[dict[str, Any]] = []
        for record in self.knowledge.memory_records():
            if str(record.get("type")) != "business_rule_candidate":
                continue
            # Candidate rows never become policy by changing their local status.
            # Their authority is represented only by immutable Policy records.
            if str(record.get("status")) in {"active", "approved"}:
                violations.append(
                    {
                        "record_id": record["record_id"],
                        "type": "candidate_has_authoritative_status",
                    }
                )
        for policy in self.policy.policies(status="active"):
            if str(policy.get("policy_type")) != "approved_business_rule":
                continue
            candidate_id = str(policy.get("candidate_id") or "")
            candidate = self.knowledge.get(candidate_id)
            evidence_hashes = _as_strings(policy.get("evidence_hashes"))
            known_hashes = {
                str(item.get("content_hash")) for item in self.knowledge.evidence(candidate_id)
            }
            if (
                candidate is None
                or str(candidate.get("type")) != "business_rule_candidate"
                or not evidence_hashes
                or not set(evidence_hashes).issubset(known_hashes)
            ):
                violations.append(
                    {
                        "policy_id": policy.get("policy_id"),
                        "candidate_id": candidate_id,
                        "type": "approved_business_rule_evidence_missing",
                    }
                )
        health = {"knowledge": self.knowledge.health(), "policy": self.policy.health()}
        return {
            "ok": not violations and all(item.get("ok") for item in health.values()),
            "schema_version": "persistmind.knowledge_verify.v1",
            "health": health,
            "violations": violations,
            "nextgen_v1": True,
        }

    # -- Policy Authority --------------------------------------------------

    def memory_enforce(
        self,
        record_id: str,
        *,
        level: str = "warn",
        severity: str = "medium",
        scope: Sequence[str] | None = None,
        anti_patterns: Sequence[str] | None = None,
        required_patterns: Sequence[str] | None = None,
        remediation: str | None = None,
        rationale: str | None = None,
        approve: bool = False,
        approved_by: str = "local-user",
        status: str = "active",
        source: str = "manual",
    ) -> dict[str, Any]:
        if not approve:
            raise PermissionError("policy activation requires approve=true")
        _require_actor_role(approved_by, "codeowner", "memory_enforce")
        record = self._memory_or_raise(record_id)
        if str(record.get("status")) not in {"active", "approved"}:
            raise ValueError("only validated memory can become an enforcement directive")
        directive = self._activate_policy(
            record,
            approver=approved_by,
            policy_type="memory_enforcement",
            scope=_as_strings(scope)
            or _scope_refs(str(record.get("scope") or ""), _as_dict(record.get("metadata")))
            or ["**"],
            priority=_policy_priority(severity),
            details={
                "enforcement_level": level,
                "severity": severity,
                "path_globs": _as_strings(scope) or ["**"],
                "anti_patterns": _as_strings(anti_patterns),
                "required_patterns": _as_strings(required_patterns),
                "remediation": remediation,
                "rationale": rationale or str(record.get("assertion") or ""),
                "source": source,
                "requested_status": status,
            },
        )
        return {"ok": True, "directive": directive, "nextgen_v1": True}

    def memory_enforcements(
        self,
        *,
        status: str | None = None,
        paths: Sequence[str] | None = None,
    ) -> dict[str, Any]:
        path_set = [item.replace("\\", "/") for item in paths or () if item]
        directives = [
            item
            for item in self.policy.policies(status=status)
            if str(item.get("policy_type")) in {"memory_enforcement", "approved_business_rule"}
        ]
        if path_set:
            directives = [
                directive for directive in directives if _policy_matches_paths(directive, path_set)
            ]
        return {"ok": True, "directives": directives, "nextgen_v1": True}

    def memory_unenforce(
        self,
        directive_id: str,
        *,
        reason: str = "manual suspend",
        actor: str = "local-user",
    ) -> dict[str, Any]:
        del directive_id, reason, actor
        raise PermissionError(
            "Knowledge cannot change Policy state; submit the transition to PolicyService"
        )

    def policy_approve_business_rule(
        self,
        candidate_id: str,
        *,
        approver: str,
        signature: str,
    ) -> dict[str, Any]:
        del candidate_id, approver, signature
        raise PermissionError(
            "Knowledge cannot approve Policy; use PolicyService.approve_business_rule"
        )

    def policy_applicable(self, scope: str | None = None) -> dict[str, Any]:
        requested = (scope or "global").strip() or "global"
        candidates = self.policy.policies(status="active")
        applicable = [item for item in candidates if _policy_matches_scope(item, requested)]
        applicable.sort(
            key=lambda item: (-int(item.get("priority") or 0), str(item.get("policy_id")))
        )
        return {
            "ok": True,
            "schema_version": "persistmind.policy_applicable.v1",
            "scope": requested,
            "policies": applicable,
            "nextgen_v1": True,
        }

    def memory_review(self, *, status: str | None = None, limit: int = 100) -> dict[str, Any]:
        records = [
            self._project_record(item)
            for item in self.knowledge.memory_records(limit=max(1, min(limit, 1000)))
            if str(item.get("status")) in {"candidate", "needs_review", "quarantined"}
            and (status is None or str(item.get("status")) == status)
        ]
        records.sort(key=lambda item: (str(item.get("status")), str(item["record_id"])))
        return {
            "ok": True,
            "schema_version": "persistmind.memory_review.v1",
            "records": records[:limit],
            "count": min(len(records), limit),
            "nextgen_v1": True,
        }

    def memory_candidates(self, status: str | None = None, limit: int = 100) -> dict[str, Any]:
        extraction = self._extract_memory_candidates()
        review = self.memory_review(status=status, limit=limit)
        return {
            **review,
            "schema_version": "persistmind.memory_candidates.v1",
            "extraction_status": "verified",
            "candidate_source": "source_scanners",
            "extraction": extraction,
        }

    def memory_scan(self, status: str | None = None, limit: int = 100) -> dict[str, Any]:
        result = self.memory_candidates(status=status, limit=limit)
        return {
            **result,
            "schema_version": "persistmind.memory_scan.v1",
        }

    def _extract_memory_candidates(self) -> dict[str, Any]:
        persisted = 0
        suppressed = 0
        errors: list[dict[str, str]] = []
        seen: set[str] = set()
        existing_ids = {
            str(item["record_id"])
            for item in self.knowledge.memory_records(
                status=None, types=["business_rule_candidate"], limit=10_000
            )
        }
        for source_type, scanner in SCANNERS.items():
            try:
                candidates = scanner(self.repo_root)
            except Exception as exc:
                errors.append({"source_type": source_type, "error": str(exc)})
                continue
            for candidate in candidates:
                assertion = " ".join(str(candidate.text).split())
                if not assertion:
                    suppressed += 1
                    continue
                dedupe_key = f"{source_type}:{assertion}"
                if dedupe_key in seen:
                    continue
                seen.add(dedupe_key)
                evidence = [
                    {
                        "path": evidence_item.path,
                        "evidence_kind": evidence_item.evidence_kind,
                        "evidence_hash": evidence_item.evidence_hash,
                        "line_start": evidence_item.line_start,
                        "line_end": evidence_item.line_end,
                        "source_ref": evidence_item.path,
                    }
                    for evidence_item in candidate.evidence
                ]
                if not evidence:
                    suppressed += 1
                    continue
                result = self.memory_create_typed(
                    {
                        "type": "business_rule_candidate",
                        "assertion": assertion,
                        "evidence": evidence,
                        "source_kind": source_type,
                        "confidence": candidate.confidence,
                        "extraction_method": f"source_scanner:{source_type}",
                        "metadata": {
                            "scanner_source_type": source_type,
                            "extraction_dedupe_key": dedupe_key,
                        },
                        "scope_refs": sorted(
                            {
                                str(item.get("path") or "")
                                for item in evidence
                                if str(item.get("path") or "").strip()
                            }
                        ),
                        "actor": "memory_candidates",
                    }
                )
                record_id = str(result.get("record", {}).get("record_id") or "")
                if record_id and record_id not in existing_ids:
                    persisted += 1
                    existing_ids.add(record_id)
        return {
            "ok": not errors,
            "scanned_sources": sorted(SCANNERS),
            "persisted": persisted,
            "suppressed": suppressed,
            "errors": errors,
        }

    def memory_maintain(self, *, apply: bool = False, limit: int = 1000) -> dict[str, Any]:
        now = datetime.now(UTC)
        stale = []
        for item in self.knowledge.memory_records(limit=max(1, min(limit, 1000))):
            expires_at = _optional_string(item.get("expires_at"))
            if not expires_at or str(item.get("status")) in _TERMINAL_MEMORY_STATUSES:
                continue
            try:
                expired = datetime.fromisoformat(expires_at.replace("Z", "+00:00")) <= now
            except ValueError:
                expired = False
            if expired:
                stale.append(str(item["record_id"]))
        applied = []
        if apply:
            for record_id in stale:
                self.memory_expire(record_id, "retention expiry", actor="maintenance")
                applied.append(record_id)
        hard_deleted: list[str] = []
        legal_hold_active = self._active_legal_hold_exists()
        if apply and not legal_hold_active:
            retention_days = max(1, int(getattr(self.settings.memory, "stale_after_days", 180)))
            before = (now - timedelta(days=retention_days)).isoformat()
            hard_deleted = list(
                self.knowledge.memory_hard_delete_terminal(
                    statuses=sorted(_TERMINAL_MEMORY_STATUSES),
                    before=before,
                    limit=limit,
                )
            )
        verification = dict(self.knowledge.health())
        return {
            "ok": bool(verification.get("ok")),
            "schema_version": "persistmind.memory_maintenance.v1",
            "dry_run": not apply,
            "eligible": stale,
            "applied": applied,
            "hard_deleted": hard_deleted,
            "legal_hold_active": legal_hold_active,
            "verification": verification,
            "nextgen_v1": True,
        }

    def memory_graph(
        self,
        record_id: str | None = None,
        *,
        limit: int = 100,
        max_hops: int | None = None,
    ) -> dict[str, Any]:
        bounded_limit = max(1, min(int(limit), 1000))
        hops = max(1, min(int(max_hops or 1), 10))
        if record_id:
            walked = self.knowledge.memory_graph_walk(
                record_id, max_hops=hops, limit=bounded_limit
            )
            selected = [self._project_record(item) for item in walked["nodes"]]
            edges = [dict(item) for item in walked["edges"]]
        else:
            records = [
                self._project_record(item)
                for item in self.knowledge.memory_records(limit=bounded_limit)
            ]
            selected = records
            edges = [dict(item) for item in self.knowledge.memory_edges()]
        if not edges:
            by_id = {str(item["record_id"]): item for item in selected}
            records = selected
            fallback_edges: list[dict[str, Any]] = []
            for left in records:
                left_refs = set(_as_strings(left.get("scope_refs")))
                for right in records:
                    if left["record_id"] == right["record_id"]:
                        continue
                    overlap = sorted(left_refs & set(_as_strings(right.get("scope_refs"))))
                    if overlap:
                        fallback_edges.append(
                            {
                                "source": left["record_id"],
                                "target": right["record_id"],
                                "kind": "co_occurs_with",
                                "scope_refs": overlap,
                                "derived": True,
                            }
                        )
            edges = fallback_edges
            selected = list(by_id.values())
        edges.sort(
            key=lambda item: (
                int(item.get("hop") or 1),
                str(item.get("source") or item.get("src_record_id") or ""),
                str(item.get("target") or item.get("dst_record_id") or ""),
            )
        )
        return {
            "ok": True,
            "schema_version": "persistmind.memory_graph.v1",
            "nodes": selected[:bounded_limit],
            "edges": edges[:bounded_limit],
            "max_hops": hops,
            "nextgen_v1": True,
        }

    def memory_utilization(self, record_id: str | None = None) -> dict[str, Any]:
        graph = self.memory_graph(record_id=record_id, limit=1000)
        return {
            "ok": True,
            "status": "measured",
            "schema_version": "persistmind.memory_utilization.v1",
            "record_id": record_id,
            "nodes": len(graph["nodes"]),
            "edges": len(graph["edges"]),
        }

    def memory_metrics(self) -> dict[str, Any]:
        records = list(self.knowledge.memory_records(limit=1000))
        by_status: dict[str, int] = {}
        by_type: dict[str, int] = {}
        for item in records:
            status = str(item.get("status") or "unknown")
            kind = str(item.get("type") or item.get("kind") or "unknown")
            by_status[status] = by_status.get(status, 0) + 1
            by_type[kind] = by_type.get(kind, 0) + 1
        return {
            "ok": True,
            "schema_version": "persistmind.memory_metrics.v1",
            "records": len(records),
            "by_status": dict(sorted(by_status.items())),
            "by_type": dict(sorted(by_type.items())),
            "verification": dict(self.knowledge.health()),
            "nextgen_v1": True,
        }

    def business_entity_add(
        self,
        name: str,
        *,
        entity_type: str = "entity",
        attributes: Mapping[str, Any] | None = None,
        evidence: Sequence[Mapping[str, Any]] | None = None,
        actor: str = "local-user",
        node_type: str | None = None,
        attrs: Mapping[str, Any] | None = None,
        origin: str | None = None,
        source_type: str | None = None,
        source_ref: str | None = None,
        proposed_by: str | None = None,
        confidence: float | None = None,
    ) -> dict[str, Any]:
        normalized = name.strip()
        if not normalized:
            raise ValueError("business entity requires a name")
        return self.claim_create(
            {
                "proposition": canonical_json(
                    {
                        "entity_name": normalized,
                        "entity_type": node_type or entity_type,
                        "attributes": dict(attributes or attrs or {}),
                    }
                ),
                "claim_kind": "business_entity",
                "status": "candidate",
                "source_class": "human_decision",
                "evidence": list(evidence or []),
                "source_identity": {
                    "actor": proposed_by or actor,
                    "origin": origin,
                    "source_type": source_type,
                    "source_ref": source_ref,
                },
                "confidence": confidence if confidence is not None else 1.0,
            },
            actor=proposed_by or actor,
        )

    def business_entity_bulk_add(
        self,
        entities: Sequence[Mapping[str, Any]] | None = None,
        *,
        actor: str = "local-user",
        file: str | Path | None = None,
        origin: str | None = None,
        proposed_by: str | None = None,
    ) -> dict[str, Any]:
        values = list(entities or ())
        if file is not None:
            source = Path(file)
            if not source.is_absolute():
                source = self.repo_root / source
            payload = json.loads(source.read_text(encoding="utf-8"))
            values = (
                list(payload.get("entities", [])) if isinstance(payload, Mapping) else list(payload)
            )
        if not values:
            raise ValueError("business entity bulk add requires entities or a JSON file")
        results = []
        for entity in values:
            value = dict(entity)
            name = str(value.pop("name", ""))
            results.append(
                self.business_entity_add(
                    name,
                    actor=proposed_by or actor,
                    origin=origin,
                    **value,
                )
            )
        return {
            "ok": all(item["ok"] for item in results),
            "status": "created",
            "schema_version": "persistmind.business_entity_bulk.v1",
            "entities": results,
        }

    def business_entity_list(
        self,
        status: str | None = None,
        *,
        node_type: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        records = [
            dict(item)
            for item in self.knowledge.search('"claim_kind":"business_entity"', limit=10_000)
            if item.get("kind") == "epistemic_claim"
            and (status is None or item.get("status") == status)
        ]
        if node_type:
            records = [
                item
                for item in records
                if json.loads(str(item.get("proposition") or "{}")).get("entity_type") == node_type
            ]
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.business_entity_list.v1",
            "entities": records[: max(1, min(int(limit), 1000))],
        }

    def business_entity_approve(
        self,
        entity_id: str,
        *,
        actor: str = "local-user",
        reason: str = "approved",
        approver: str | None = None,
        notes: str | None = None,
    ) -> dict[str, Any]:
        return self.claim_transition(
            entity_id,
            status="supported",
            actor=approver or actor,
            reason=notes or reason,
        )

    def business_entity_reject(
        self,
        entity_id: str,
        *,
        actor: str = "local-user",
        reason: str = "rejected",
        approver: str | None = None,
    ) -> dict[str, Any]:
        return self.claim_transition(
            entity_id, status="rejected", actor=approver or actor, reason=reason
        )

    def business_link(
        self,
        subject_id: str | None = None,
        predicate: str | None = None,
        object_id: str | None = None,
        *,
        evidence_id: str | None = None,
        support_score: float | None = None,
        src_node_id: str | None = None,
        dst_node_id: str | None = None,
        kind: str | None = None,
        source_ref: str | None = None,
        source_type: str | None = None,
        proposed_by: str | None = None,
        confidence: float | None = None,
    ) -> dict[str, Any]:
        del source_type, proposed_by
        subject_id = subject_id or src_node_id
        object_id = object_id or dst_node_id
        predicate = predicate or kind
        if not subject_id or not object_id or not predicate:
            raise ValueError("business link requires subject, predicate, and object")
        return self.claim_relation_add(
            subject_id,
            predicate,
            object_id,
            evidence_id=evidence_id or source_ref,
            support_score=support_score if support_score is not None else confidence,
        )

    def decision_start(
        self,
        question: str,
        *,
        alternatives: Sequence[str] = (),
        rationale: str = "decision analysis started",
        actor: str = "local-user",
        options: Sequence[str] | None = None,
        seed_paths: Sequence[str] | None = None,
    ) -> dict[str, Any]:
        return self.memory_create_typed(
            {
                "type": "decision",
                "assertion": question,
                "status": "candidate",
                "source_kind": "human_decision",
                "actor": actor,
                "metadata": {
                    "rationale": rationale,
                    "alternatives": list(options or alternatives),
                    "seed_paths": list(seed_paths or ()),
                    "decision_state": "open",
                },
            }
        )

    def decision_record(
        self,
        decision: str = "",
        *,
        rationale: str = "decision recorded",
        alternatives: Sequence[str] = (),
        evidence: Sequence[Mapping[str, Any]] | None = None,
        actor: str = "local-user",
        chosen_option_id: str | None = None,
    ) -> dict[str, Any]:
        if chosen_option_id:
            current = self._memory_or_raise(decision)
            metadata = _as_dict(current.get("metadata"))
            metadata.update(
                {
                    "chosen_option_id": chosen_option_id,
                    "rationale": rationale,
                    "decision_state": "recorded",
                }
            )
            return self.memory_update(
                decision,
                {"metadata": metadata},
                reason="decision recorded",
                actor=actor,
            )
        return self.memory_create_typed(
            {
                "type": "decision",
                "assertion": decision,
                "status": "candidate",
                "source_kind": "human_decision",
                "actor": actor,
                "evidence": list(evidence or []),
                "metadata": {
                    "rationale": rationale,
                    "alternatives": list(alternatives),
                    "decision_state": "recorded",
                },
            }
        )

    def decision_list(self, status: str | None = None, *, limit: int = 50) -> dict[str, Any]:
        result = self.memory_records(status=status, types=["decision", "architectural_decision"])
        result["records"] = result["records"][: max(1, min(int(limit), 1000))]
        return result

    def decision_show(self, decision_id: str) -> dict[str, Any]:
        return self.memory_show(decision_id)

    def decision_analyze(self, decision_id: str) -> dict[str, Any]:
        shown = self.memory_show(decision_id)
        if not shown.get("ok"):
            return shown
        record = dict(shown["record"])
        metadata = _as_dict(record.get("metadata"))
        contradictions = [
            item
            for item in self.memory_conflicts()["conflicts"]
            if decision_id in set(item.get("record_ids", []))
        ]
        return {
            "ok": True,
            "status": "contested" if contradictions else "candidate",
            "schema_version": "persistmind.decision_analysis.v1",
            "decision": record,
            "alternatives": metadata.get("alternatives", []),
            "rationale": metadata.get("rationale"),
            "evidence": shown["evidence"],
            "contradictions": contradictions,
        }

    def memory_consolidate(
        self,
        record_ids: Sequence[str] | str,
        recent: int | None = None,
        *,
        actor: str = "maintenance",
    ) -> dict[str, Any]:
        if isinstance(record_ids, str):
            raise ValueError(
                "memory_consolidate requires an explicit list of at least two record ids; "
                "use memory_sleep to discover similar consolidation candidates"
            )
        if len(set(record_ids)) < 2:
            raise ValueError("consolidation requires at least two distinct source records")
        sources = [self._memory_or_raise(record_id) for record_id in sorted(set(record_ids))]
        assertions = [str(item["assertion"]) for item in sources]
        scope_refs = sorted(
            {ref for item in sources for ref in _as_strings(item.get("scope_refs"))}
        )
        evidence = [
            {
                "source_ref": str(item["record_id"]),
                "content_hash": str(item.get("_content_hash") or ""),
                "evidence_kind": "inference",
                "trust": "candidate",
            }
            for item in sources
        ]
        return self.memory_create_typed(
            {
                "type": "pattern",
                "assertion": "Consolidated candidate: " + " | ".join(assertions),
                "status": "candidate",
                "source_kind": "consolidation",
                "actor": actor,
                "scope_refs": scope_refs,
                "evidence": evidence,
                "metadata": {
                    "source_record_ids": [str(item["record_id"]) for item in sources],
                    "alternatives_preserved": assertions,
                    "reversible": True,
                },
            }
        )

    def memory_prefetch(
        self,
        query: str,
        *,
        paths: Sequence[str] | None = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        recalled = self.memory_recall(query, paths=paths, limit=limit)
        record_id = (
            "memory-prefetch_" + stable_id(query, canonical_json(paths or []), utc_now())[:32]
        )
        self.knowledge.put(
            {
                "record_id": record_id,
                "kind": "memory_service_observation",
                "scope": f"repo:{self.repo_id}",
                "event": "prefetch",
                "query_hash": "sha256:" + sha256_text(query),
                "served_ids": [item["record_id"] for item in recalled.get("items", [])],
                "excluded": recalled.get("defense", {}).get("excluded", {}),
                "created_at": utc_now(),
            },
            idempotency_key="memory-prefetch:" + record_id,
        )
        return {
            **recalled,
            "schema_version": "persistmind.memory_prefetch.v1",
            "observation_id": record_id,
        }

    def memory_reflect(
        self,
        session_id: str | None = None,
        recent: int | None = None,
        *,
        limit: int = 100,
    ) -> dict[str, Any]:
        del session_id
        if recent is not None:
            limit = recent
        failures = [
            self._project_record(item)
            for item in self.knowledge.memory_records(
                types=["failure_lesson", "gotcha", "episode"], limit=limit
            )
        ]
        hypotheses = [
            {
                "source_record_id": item["record_id"],
                "hypothesis": "Recurrence may be reduced by validating: " + str(item["assertion"]),
                "status": "candidate",
            }
            for item in failures
        ]
        record_id = "memory-reflection_" + stable_id(canonical_json(hypotheses))[:32]
        self.knowledge.put(
            {
                "record_id": record_id,
                "kind": "memory_reflection",
                "scope": f"repo:{self.repo_id}",
                "hypotheses": hypotheses,
                "created_at": utc_now(),
            },
            idempotency_key="memory-reflection:" + record_id,
        )
        return {
            "ok": True,
            "status": "candidate",
            "schema_version": "persistmind.memory_reflection.v1",
            "reflection_id": record_id,
            "hypotheses": hypotheses,
        }

    def memory_review_resolve(
        self,
        record_id: str,
        *,
        decision: str = "",
        actor: str = "local-user",
        reason: str = "review resolved",
        resolution: str | None = None,
        target_record_id: str | None = None,
        validator: str | None = None,
    ) -> dict[str, Any]:
        del target_record_id, validator
        decision = resolution or decision
        normalized = decision.strip().lower()
        if normalized == "approve":
            return self.memory_validate(record_id, validator="human:review", actor=actor)
        if normalized == "reject":
            return self._set_memory_status(record_id, "rejected", actor=actor, reason=reason)
        if normalized == "quarantine":
            return self.memory_quarantine(record_id, reason, actor=actor)
        raise ValueError("review decision must be approve, reject, or quarantine")

    def memory_security_reviews(self, status: str | None = None) -> dict[str, Any]:
        records = [
            self._project_record(item)
            for item in self.knowledge.memory_records(limit=1000)
            if str(item.get("status")) in {"quarantined", "needs_review"}
            or str(item.get("type")) in _SENSITIVE_MEMORY_TYPES
        ]
        if status:
            records = [item for item in records if item.get("status") == status]
        return {
            "ok": not any(item.get("status") == "quarantined" for item in records),
            "status": "review_required" if records else "verified",
            "schema_version": "persistmind.memory_security_reviews.v1",
            "records": records,
        }

    def memory_sleep(self, *, apply: bool = False, limit: int = 100) -> dict[str, Any]:
        records = list(self.knowledge.memory_records(status="active", limit=limit))
        threshold = float(getattr(self.settings.memory.sleep, "similarity_threshold", 0.85))
        pairs: list[dict[str, Any]] = []
        for index, left in enumerate(records):
            for right in records[index + 1 :]:
                similarity = _memory_similarity(left, right)
                if similarity < threshold:
                    continue
                pairs.append(
                    {
                        "record_ids": [str(left["record_id"]), str(right["record_id"])],
                        "similarity": round(similarity, 6),
                        "action": "consolidate_duplicate_or_pattern",
                    }
                )
        pairs.sort(key=lambda item: (-float(item["similarity"]), item["record_ids"]))
        consolidations = []
        if apply:
            for pair in pairs:
                consolidations.append(self.memory_consolidate(pair["record_ids"]))
        return {
            "ok": True,
            "status": "applied" if apply else "candidate",
            "schema_version": "persistmind.memory_sleep.v1",
            "candidate_pairs": len(pairs),
            "candidates": pairs,
            "consolidations": consolidations,
            "maintenance": self.memory_maintain(apply=apply, limit=limit),
        }

    def memory_sweep(self, *, apply: bool = False, limit: int = 1000) -> dict[str, Any]:
        return self.memory_maintain(apply=apply, limit=limit)

    def memory_trust_calibrate(self, *, apply: bool = False) -> dict[str, Any]:
        records = list(self.knowledge.memory_records(limit=10_000))
        groups: dict[str, list[Mapping[str, Any]]] = {}
        for record in records:
            source = str(record.get("source_kind") or "unknown")
            groups.setdefault(source, []).append(record)
        strata: dict[str, dict[str, Any]] = {}
        applied: list[str] = []
        for source, items in sorted(groups.items()):
            active = sum(1 for item in items if str(item.get("status")) in {"active", "approved"})
            terminal = sum(1 for item in items if str(item.get("status")) in _TERMINAL_MEMORY_STATUSES)
            total = len(items)
            reliability = active / total if total else 0.0
            strata[source] = {
                "records": total,
                "active": active,
                "terminal": terminal,
                "reliability": round(reliability, 6),
            }
            if apply:
                for item in items:
                    if str(item.get("status")) not in {"active", "approved"}:
                        continue
                    document = _without_internal(item)
                    metadata = _as_dict(document.get("metadata"))
                    metadata["trust_calibration"] = {
                        "source_kind": source,
                        "reliability": round(reliability, 6),
                        "calibrated_at": utc_now(),
                    }
                    document["metadata"] = metadata
                    calibrated = min(
                        float(document.get("confidence") or 1.0),
                        max(0.25, reliability),
                    )
                    document["confidence"] = round(calibrated, 6)
                    updated = self.knowledge.write_memory_record(
                        document,
                        actor="maintenance",
                        reason="trust calibration",
                        expected_revision=int(item["_revision"]),
                    )
                    self._after_memory_write(
                        updated, actor="maintenance", reason="trust calibration"
                    )
                    applied.append(str(item["record_id"]))
        calibration = self.forecast_calibration()
        return {
            "ok": calibration["ok"],
            "status": "applied" if apply else "reported",
            "schema_version": "persistmind.memory_trust_calibration.v1",
            "calibration": calibration,
            "source_reliability": strata,
            "applied": applied,
        }

    def memory_extraction_eval(
        self,
        fixtures: str | None = None,
        source_type: str | None = None,
        **_: Any,
    ) -> dict[str, Any]:
        labels = _load_extraction_labels(self.repo_root, fixtures)
        if not labels:
            return {
                **self.memory_metrics(),
                "schema_version": "persistmind.memory_extraction_eval.v1",
                "status": "no_fixtures",
                "precision": None,
                "recall": None,
            }
        records = [
            item
            for item in self.knowledge.memory_records(limit=10_000)
            if source_type is None or str(item.get("source_kind")) == str(source_type)
        ]
        predicted = {
            _normalize_eval_assertion(str(item.get("assertion") or ""))
            for item in records
            if str(item.get("status")) not in _TERMINAL_MEMORY_STATUSES
        }
        expected = {
            _normalize_eval_assertion(str(item.get("assertion") or item.get("text") or ""))
            for item in labels
            if bool(item.get("expected", True))
        }
        true_positive = len(predicted & expected)
        precision = true_positive / len(predicted) if predicted else 0.0
        recall = true_positive / len(expected) if expected else 1.0
        return {
            "ok": True,
            "schema_version": "persistmind.memory_extraction_eval.v1",
            "status": "measured",
            "source_type": source_type,
            "fixtures": fixtures,
            "expected": len(expected),
            "predicted": len(predicted),
            "true_positive": true_positive,
            "precision": round(precision, 6),
            "recall": round(recall, 6),
            "nextgen_v1": True,
        }

    def memory_eval(self, query: str = "memory", *, limit: int = 20) -> dict[str, Any]:
        recalled = self.memory_recall(query, limit=limit)
        return {
            "ok": True,
            "status": "measured",
            "schema_version": "persistmind.memory_eval.v1",
            "query_hash": "sha256:" + sha256_text(query),
            "served": len(recalled.get("items", [])),
            "excluded": recalled.get("defense", {}).get("excluded", {}),
        }

    def memory_bench(
        self,
        queries: Sequence[str] | None = None,
        *,
        samples: int | None = None,
    ) -> dict[str, Any]:
        values = list(queries or ["decision", "failure", "convention"])
        if samples is not None:
            values = values[: max(1, min(int(samples), len(values)))]
        reports = [self.memory_eval(query) for query in values]
        return {
            "ok": all(item["ok"] for item in reports),
            "status": "measured",
            "schema_version": "persistmind.memory_benchmark.v1",
            "reports": reports,
        }

    def narrative_show(self) -> dict[str, Any]:
        records = [
            self._project_record(item)
            for item in self.knowledge.memory_records(status="active", limit=1000)
        ]
        records.sort(key=lambda item: str(item.get("updated_at") or item["record_id"]))
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.knowledge_narrative.v1",
            "timeline": [
                {
                    "record_id": item["record_id"],
                    "type": item.get("type"),
                    "assertion": item.get("assertion"),
                    "scope_refs": item.get("scope_refs", []),
                }
                for item in records
            ],
        }

    def workspace_init(self, name: str | None = None) -> dict[str, Any]:
        manager = self._crossrepo_workspace_manager()
        initialized = manager.init()
        record = self._workspace_record(
            "workspace_init",
            {"workspace_id": self.workspace_id, "name": name or self.repo_root.name},
        )
        return {**record, "crossrepo": initialized}

    def workspace_add_repo(self, path: str, *, label: str | None = None) -> dict[str, Any]:
        target = Path(path).resolve()
        manager = self._crossrepo_workspace_manager()
        added = manager.add_repo(target)
        record = self._workspace_record(
            "workspace_repository",
            {"path": str(target), "label": label or target.name},
        )
        return {**record, "crossrepo": added}

    def workspace_index(self) -> dict[str, Any]:
        manager = self._crossrepo_workspace_manager()
        crossrepo = manager.index()
        try:
            from persistmind.storage.source_service import SourceService

            with SourceService(
                self.repo_root,
                allow_development_driver=self._allow_development_driver,
            ) as source:
                crossrepo["source_projection"] = source.publish_crossrepo_projection(
                    contracts=manager.store.contracts(),
                    edges=manager.store.logical_edges("src_repo_id != dst_repo_id"),
                )
        except Exception as exc:  # noqa: BLE001 - keep workspace index durable if projection fails
            crossrepo["source_projection"] = {
                "ok": False,
                "status": "projection_failed",
                "error": str(exc),
            }
        return {
            "ok": True,
            "status": "indexed",
            "schema_version": "persistmind.workspace_index.v1",
            "workspace": self.workspace_status(),
            "knowledge": self.memory_metrics(),
            "graph": self.memory_graph(limit=1000),
            "crossrepo": crossrepo,
        }

    def workspace_status(self) -> dict[str, Any]:
        records = [
            dict(item)
            for item in self.knowledge.search('"kind":"workspace_record"', limit=1000)
            if item.get("kind") == "workspace_record"
        ]
        return {
            "ok": True,
            "status": "initialized" if records else "source_not_ready",
            "schema_version": "persistmind.workspace_status.v1",
            "workspace_id": self.workspace_id,
            "records": records,
            "crossrepo": self._crossrepo_workspace_manager().status(),
        }

    def workspace_explain(self, task: str, paths: Sequence[str] | None = None) -> dict[str, Any]:
        recalled = self.memory_recall(task, paths=paths, limit=50)
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.workspace_explain.v1",
            "task_hash": "sha256:" + sha256_text(task),
            "included": recalled.get("items", []),
            "retrieval": recalled.get("defense", {}),
        }

    def workspace_impact(self, paths: Sequence[str] | str) -> dict[str, Any]:
        if isinstance(paths, str):
            return self._crossrepo_workspace_manager().impact(paths)
        normalized = {item.replace("\\", "/") for item in paths}
        records = [
            self._project_record(item)
            for item in self.knowledge.memory_records(limit=10_000)
            if normalized & set(_as_strings(item.get("scope_refs")))
        ]
        observation = self._workspace_record(
            "workspace_impact",
            {"paths": sorted(normalized), "record_ids": [item["record_id"] for item in records]},
        )
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.workspace_impact.v1",
            "paths": sorted(normalized),
            "records": records,
            "observation": observation,
        }

    def _crossrepo_workspace_manager(self) -> Any:
        from persistmind.crossrepo.store import WorkspaceContractStore
        from persistmind.crossrepo.workspace import WorkspaceManager

        workspace_root = self.repo_root / self.settings.toolchain.workspace_dir
        return WorkspaceManager(workspace_root, WorkspaceContractStore(workspace_root))

    def workspace_critique(
        self,
        *,
        task: str | None = None,
        paths: Sequence[str] | None = None,
        diff: str | None = None,
        risk_threshold: float | None = None,
    ) -> dict[str, Any]:
        conflicts = self.memory_conflicts()
        stale = self.memory_stale()
        return {
            "ok": not conflicts["conflicts"] and not stale.get("stale", []),
            "status": "verified"
            if not conflicts["conflicts"] and not stale.get("stale", [])
            else "contested",
            "schema_version": "persistmind.workspace_critique.v1",
            "conflicts": conflicts,
            "stale": stale,
            "request": {
                "task": task,
                "paths": list(paths or ()),
                "diff_supplied": bool(diff),
                "risk_threshold": risk_threshold,
            },
        }

    def workspace_rule_promotions(self) -> dict[str, Any]:
        candidates = [
            self._project_record(item)
            for item in self.knowledge.memory_records(
                status="candidate", types=["business_rule_candidate"], limit=1000
            )
        ]
        return {
            "ok": True,
            "status": "candidate",
            "schema_version": "persistmind.workspace_rule_promotions.v1",
            "candidates": candidates,
            "authority": "PolicyService",
        }

    def _workspace_record(self, record_type: str, payload: Mapping[str, Any]) -> dict[str, Any]:
        record_id = "workspace_" + stable_id(record_type, canonical_json(dict(payload)))[:32]
        self.knowledge.put(
            {
                "record_id": record_id,
                "kind": "workspace_record",
                "scope": f"workspace:{self.workspace_id}",
                "record_type": record_type,
                "payload": dict(payload),
                "created_at": utc_now(),
            },
            idempotency_key="workspace-record:" + record_id,
        )
        return {
            "record_id": record_id,
            "record_type": record_type,
            "payload": dict(payload),
        }

    # -- Internal helpers --------------------------------------------------

    def _memory_or_raise(self, record_id: str) -> Mapping[str, Any]:
        record = self.knowledge.get(record_id)
        if record is None or str(record.get("kind")) != "memory":
            raise KeyError(f"memory record not found: {record_id}")
        return record

    def _record_response(self, record: Mapping[str, Any]) -> dict[str, Any]:
        return {"ok": True, "record": self._project_record(record), "nextgen_v1": True}

    def _after_memory_write(
        self, record: Mapping[str, Any], *, actor: str, reason: str
    ) -> dict[str, Any]:
        report: dict[str, Any] = {
            "ok": True,
            "record_id": str(record.get("record_id") or ""),
            "warnings": [],
            "conflict_ids": [],
            "quarantine_applied": False,
        }
        try:
            self.knowledge.memory_fts_upsert(record)
        except Exception:
            pass
        self._ensure_memory_vector(record)
        try:
            conflicts = self._persist_detected_conflicts(record)
        except Exception as exc:
            conflicts = []
            report["ok"] = False
            report["warnings"].append(
                {
                    "type": "memory_conflict_projection_failed",
                    "message": "Memory conflict projection failed after the record write.",
                    "error": str(exc),
                }
            )
        conflict_ids = [str(item["conflict_id"]) for item in conflicts]
        report["conflict_ids"] = conflict_ids
        if conflicts and str(record.get("status")) == "active":
            try:
                self._mark_memory_needs_review_for_conflict(
                    record,
                    conflict_ids=conflict_ids,
                    actor=actor,
                )
                report["quarantine_applied"] = True
            except Exception as exc:
                report["ok"] = False
                warning = {
                    "type": "memory_conflict_quarantine_failed",
                    "message": "Conflicts were detected, but the new memory record could not be moved to needs_review.",
                    "record_id": str(record.get("record_id") or ""),
                    "conflict_ids": conflict_ids,
                    "error": str(exc),
                }
                report["warnings"].append(warning)
                self._record_memory_projection_warning(record, warning, actor=actor)
        audit = self._audit_memory_transition(record, actor=actor, reason=reason)
        if audit is not None and not audit.get("ok", True):
            report["warnings"].append(
                {
                    "type": "memory_audit_projection_failed",
                    "message": "Memory transition audit append failed.",
                    "error": str(audit.get("error") or ""),
                }
            )
        return report

    def _ensure_memory_vector(self, record: Mapping[str, Any]) -> list[float] | None:
        model_name = str(getattr(self.settings.toolchain, "embed_model", "local-lexical-v1"))
        cached = self.knowledge.memory_vector(str(record["record_id"]), model_name=model_name)
        if cached is not None:
            return cached
        try:
            embedder = make_embedder(
                model_name=model_name,
                backend=str(getattr(self.settings.toolchain, "embed_backend", "auto")),
            )
            vector = embedder.embed(_memory_text(record))
            self.knowledge.memory_vector_upsert(
                str(record["record_id"]),
                model_name=model_name,
                vector=vector,
            )
            return vector
        except Exception:
            return None

    def _persist_detected_conflicts(self, record: Mapping[str, Any]) -> list[dict[str, Any]]:
        if str(record.get("status")) not in {"active", "approved"}:
            return []
        persisted: list[dict[str, Any]] = []
        subject_key = _memory_subject_key(record)
        candidates = self.knowledge.memory_records(status=None, limit=10_000)
        for other in candidates:
            if str(other.get("record_id")) == str(record.get("record_id")):
                continue
            if str(other.get("status")) not in {"active", "approved"}:
                continue
            if _memory_subject_key(other) != subject_key:
                continue
            summary = _conflict_summary(
                str(record.get("assertion") or ""), str(other.get("assertion") or "")
            )
            if not summary:
                continue
            conflict = dict(
                self.knowledge.upsert_memory_conflict(
                    str(record["record_id"]),
                    str(other["record_id"]),
                    subject_key=subject_key,
                    summary=summary,
                    metadata={"detected_by": "knowledge_service"},
                )
            )
            self.knowledge.memory_edge_create(
                str(record["record_id"]),
                str(other["record_id"]),
                "contradicts",
                weight=0.9,
                evidence=[{"conflict_id": conflict["conflict_id"]}],
            )
            persisted.append(conflict)
        return persisted

    def _audit_memory_transition(
        self,
        record: Mapping[str, Any],
        *,
        actor: str,
        reason: str,
    ) -> dict[str, Any] | None:
        try:
            from .audit_service import AuditService

            with AuditService(
                self.repo_root,
                allow_development_driver=self._allow_development_driver,
            ) as audit:
                audit_id = "audit_" + stable_id(
                    "memory", str(record["record_id"]), str(record.get("_revision")), reason
                )[:32]
                stored_id = audit.store.append_audit(
                    {
                        "audit_id": audit_id,
                        "correlation_id": str(record["record_id"]),
                        "kind": "memory_transition",
                        "principal": actor,
                        "record_id": str(record["record_id"]),
                        "record_revision": int(record.get("_revision") or 0),
                        "status": str(record.get("status") or ""),
                        "reason": reason,
                        "content_hash": str(record.get("_content_hash") or ""),
                    },
                    idempotency_key="memory-transition:" + audit_id,
                )
                return {"ok": True, "audit_id": stored_id}
        except Exception as exc:
            return {"ok": False, "warning": "audit_unavailable", "error": str(exc)}

    def _active_legal_hold_exists(self) -> bool:
        try:
            row = self.knowledge.connection.execute(
                "SELECT COUNT(*) AS count FROM domain_legal_holds WHERE state='active'"
            ).fetchone()
            return bool(row is not None and int(row["count"]) > 0)
        except Exception:
            return False

    def _record_memory_projection_warning(
        self,
        record: Mapping[str, Any],
        warning: Mapping[str, Any],
        *,
        actor: str,
    ) -> None:
        try:
            warning_id = "memory_projection_warning_" + stable_id(
                str(record.get("record_id") or ""),
                canonical_json(dict(warning)),
                utc_now(),
            )[:32]
            self.knowledge.put(
                {
                    "record_id": warning_id,
                    "kind": "memory_projection_warning",
                    "scope": str(record.get("scope") or f"repo:{self.repo_id}"),
                    "memory_record_id": str(record.get("record_id") or ""),
                    "warning": dict(warning),
                    "actor": actor,
                    "created_at": utc_now(),
                },
                idempotency_key="memory-projection-warning:" + warning_id,
            )
        except Exception:
            return

    def _mark_memory_needs_review_for_conflict(
        self,
        record: Mapping[str, Any],
        *,
        conflict_ids: Sequence[str],
        actor: str,
    ) -> None:
        document = _without_internal(record)
        metadata = _as_dict(document.get("metadata"))
        metadata["conflict_review"] = {
            "status": "pending",
            "conflict_ids": list(conflict_ids),
            "detected_at": utc_now(),
        }
        document["metadata"] = metadata
        document["status"] = "needs_review"
        document["trust"] = "untrusted"
        updated = self.knowledge.write_memory_record(
            document,
            actor=actor,
            reason="conflict detected",
            expected_revision=int(record["_revision"]),
        )
        self._audit_memory_transition(updated, actor=actor, reason="conflict detected")

    def _set_memory_status(
        self,
        record_id: str,
        status: str,
        *,
        actor: str,
        reason: str,
        trust: str | None = None,
    ) -> dict[str, Any]:
        record = self._memory_or_raise(record_id)
        if str(record["type"]) in _SENSITIVE_MEMORY_TYPES:
            _require_actor_role(actor, "codeowner", f"memory_{status}_sensitive")
        document = _without_internal(record)
        document["status"] = status
        if trust is not None:
            document["trust"] = trust
        updated = self.knowledge.write_memory_record(
            document,
            actor=actor,
            reason=reason,
            expected_revision=int(record["_revision"]),
        )
        projection = self._after_memory_write(updated, actor=actor, reason=reason)
        response = self._record_response(updated)
        _attach_projection_report(response, projection)
        return response

    def _activate_policy(
        self,
        record: Mapping[str, Any],
        *,
        approver: str,
        policy_type: str,
        scope: Sequence[str],
        priority: int,
        details: Mapping[str, Any],
    ) -> Mapping[str, Any]:
        del record, approver, policy_type, scope, priority, details
        raise PermissionError(
            "Knowledge can propose policy evidence but PolicyService alone can activate it"
        )

    def _put_evidence(self, record_id: str, evidence: Any) -> list[str]:
        if not isinstance(evidence, Sequence) or isinstance(evidence, (str, bytes)):
            return []
        evidence_ids: list[str] = []
        for raw in evidence:
            if not isinstance(raw, Mapping):
                raise ValueError("memory evidence entries must be objects")
            item = dict(raw)
            locator = {
                key: item[key]
                for key in (
                    "repo_id",
                    "path",
                    "symbol_identity_id",
                    "evidence_kind",
                    "line_start",
                    "line_end",
                    "source_ref",
                    "metadata",
                )
                if item.get(key) is not None
            }
            content_hash = str(item.get("content_hash") or item.get("evidence_hash") or "")
            if not content_hash:
                content_hash = sha256_text(canonical_json(locator))
            evidence_ids.append(
                self.knowledge.put_evidence(
                    record_id,
                    locator,
                    content_hash=content_hash,
                    trust=str(item.get("trust") or "candidate"),
                )
            )
        return evidence_ids

    def _scope_from_refs(self, raw: Mapping[str, Any], metadata: Mapping[str, Any]) -> str:
        scope_kind = _optional_string(raw.get("scope_kind"))
        refs = _as_strings(raw.get("scope_refs") or metadata.get("scope_refs"))
        if scope_kind == "workspace":
            return "workspace"
        branch = _optional_string(raw.get("branch"))
        task_session_id = _optional_string(raw.get("task_session_id"))
        if branch and not bool(metadata.get("cross_branch_ok")):
            return f"repo:{self.repo_id}:branch:{branch}"
        if task_session_id:
            return f"repo:{self.repo_id}:task:{task_session_id}"
        if scope_kind and refs:
            return f"{scope_kind}:{refs[0]}"
        return f"repo:{self.repo_id}"

    def _source_revision_at_write(self) -> str | None:
        try:
            from persistmind.agent_runtime.hooks import _source_generation_revision

            return _source_generation_revision(self.runtime.root)
        except Exception:
            return None

    def _source_path_hashes(self, paths: Sequence[str]) -> dict[str, str]:
        hashes: dict[str, str] = {}
        for raw_path in paths:
            normalized = str(raw_path).replace("\\", "/").lstrip("./")
            if not normalized:
                continue
            candidate = (self.repo_root / normalized).resolve()
            try:
                candidate.relative_to(self.repo_root)
            except ValueError:
                continue
            try:
                hashes[normalized] = hashlib.sha256(candidate.read_bytes()).hexdigest()
            except OSError:
                hashes[normalized] = "missing"
        return hashes

    def _memory_id(self, record_type: str, assertion: str, scope: str, source_kind: str) -> str:
        subject = sha256_text(
            canonical_json(
                {
                    "type": record_type,
                    "scope": scope,
                    "terms": sorted(_terms(assertion))[:12],
                }
            )
        )
        return (
            "memory_"
            + stable_id(self.workspace_id, self.repo_id, record_type, subject, source_kind)[:32]
        )

    def _validate_memory_payload(
        self,
        *,
        record_type: str,
        assertion: str,
        status: str,
        provenance: Mapping[str, Any],
        metadata: Mapping[str, Any],
    ) -> None:
        if record_type not in _KNOWLEDGE_MEMORY_TYPES:
            if record_type in load_memory_kinds():
                raise ValueError(
                    f"memory type {record_type} belongs to another authority and cannot be written to Knowledge"
                )
            raise ValueError(f"unsupported memory type: {record_type}")
        if not assertion:
            raise ValueError("memory assertion is required")
        if status not in _ALLOWED_MEMORY_STATUSES:
            raise ValueError(f"unsupported memory status: {status}")
        if status in {"active", "approved"} and _agent_generated_without_validator(provenance):
            raise ValueError("agent-generated active memory requires provenance.validator")
        if record_type == "policy_reference" and _claims_policy_enforcement(assertion, metadata):
            raise ValueError("policy_reference memory may reference policy but cannot enforce it")
        if metadata.get("enforces") is True or metadata.get("policy_id"):
            raise ValueError("generic memory cannot carry Policy Authority fields")
        requirements = _TYPE_METADATA_REQUIREMENTS.get(record_type, {})
        missing = [
            key
            for key, expected in requirements.items()
            if not _metadata_satisfies(metadata.get(key), expected)
        ]
        if missing:
            raise ValueError(
                f"{record_type} memory requires metadata: {', '.join(sorted(missing))}"
            )

    def _ingest_defense(
        self,
        assertion: str,
        *,
        source_kind: str,
        owner: str | None,
        provenance: Mapping[str, Any],
        metadata: Mapping[str, Any],
    ) -> dict[str, Any]:
        next_provenance = dict(provenance)
        next_metadata = dict(metadata)
        external = _is_external(source_kind, next_provenance)
        if external:
            result = evaluate_ingest(
                assertion,
                actor=owner or next_provenance.get("actor"),
                source_connector=str(next_provenance.get("source_connector") or source_kind),
                external=True,
            )
            next_metadata["defense_result"] = result
            next_provenance.update(
                {
                    "external": True,
                    "source_kind": source_kind,
                    "source_connector": next_provenance.get("source_connector") or source_kind,
                    "serve_authoritative": False,
                }
            )
            return {
                "ok": result["decision"] == "candidate",
                "assertion": str(result["sanitized_text"]),
                "provenance": next_provenance,
                "metadata": next_metadata,
            }
        defense = detect_query_injection(assertion)
        if not defense["ok"] or _claims_policy_override(assertion, next_metadata):
            next_metadata["memory_defense"] = {
                "ok": False,
                "reason": "memory_poisoning_suspected",
                "flagged": list(defense.get("flagged") or [])
                + (
                    ["preference_policy_override"]
                    if _claims_policy_override(assertion, next_metadata)
                    else []
                ),
                "severity": "high",
            }
            return {
                "ok": False,
                "assertion": assertion,
                "provenance": next_provenance,
                "metadata": next_metadata,
            }
        return {
            "ok": True,
            "assertion": assertion,
            "provenance": next_provenance,
            "metadata": next_metadata,
        }

    def _serves_authoritatively(self, record: Mapping[str, Any]) -> bool:
        provenance = _as_dict(record.get("provenance"))
        metadata = _as_dict(record.get("metadata"))
        decision = serve_decision(metadata.get("defense_result"), provenance)
        return bool(decision.get("serve_authoritative"))

    def _scope_matches(self, record: Mapping[str, Any], paths: set[str]) -> bool:
        scope = str(record.get("scope") or "")
        if scope in {"workspace", f"repo:{self.repo_id}"}:
            return True
        refs = _as_strings(record.get("scope_refs"))
        for evidence in self.knowledge.evidence(str(record["record_id"])):
            path = _optional_string(_as_dict(evidence.get("locator")).get("path"))
            if path:
                refs.append(path)
        return any(
            fnmatch.fnmatch(path, reference) or fnmatch.fnmatch(reference, path)
            for path in paths
            for reference in refs
        )

    @staticmethod
    def _project_record(record: Mapping[str, Any]) -> dict[str, Any]:
        projected = {
            key: value
            for key, value in dict(record).items()
            if key not in {"kind", "schema_version", "_content_hash"}
        }
        if _as_dict(record.get("metadata")).get("live_state"):
            stale = _is_expired(record)
            projected["freshness_status"] = "stale" if stale else "last_verified"
            projected["requires_revalidation"] = stale
        return projected


def _as_dict(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, Mapping) else {}


def _as_strings(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value] if value else []
    if not isinstance(value, Sequence):
        return []
    return [str(item) for item in value if str(item).strip()]


def _optional_string(value: Any) -> str | None:
    text = str(value).strip() if value is not None else ""
    return text or None


def _confidence(value: Any, *, default: float) -> float:
    try:
        parsed = float(default if value is None else value)
    except (TypeError, ValueError) as exc:
        raise ValueError("memory confidence must be numeric") from exc
    if not math.isfinite(parsed) or not 0.0 <= parsed <= 1.0:
        raise ValueError("memory confidence must be between 0 and 1")
    return parsed


def _without_internal(record: Mapping[str, Any]) -> dict[str, Any]:
    return {
        str(key): value
        for key, value in dict(record).items()
        if key not in {"_revision", "_content_hash"}
    }


def _attach_projection_report(response: dict[str, Any], report: Mapping[str, Any]) -> None:
    warnings = [dict(item) for item in report.get("warnings", []) if isinstance(item, Mapping)]
    if warnings:
        response.setdefault("warnings", []).extend(warnings)
    projection = {
        key: value
        for key, value in dict(report).items()
        if key not in {"warnings"} and value not in (None, [], {})
    }
    if projection:
        response["memory_projection"] = projection


def _scope_kind(scope: str) -> str:
    return scope.split(":", 1)[0] if ":" in scope else scope


def _scope_refs(scope: str, metadata: Mapping[str, Any]) -> list[str]:
    declared = _as_strings(metadata.get("scope_refs"))
    if declared:
        return declared
    return [scope.split(":", 1)[1]] if ":" in scope else []


def _default_trust(status: str) -> str:
    return "active" if status in {"active", "approved"} else "candidate"


def _terms(text: str) -> set[str]:
    return set(re.findall(r"[a-zA-Z][a-zA-Z0-9_]{3,}", text.lower()))


def _memory_text(record: Mapping[str, Any]) -> str:
    metadata = _as_dict(record.get("metadata"))
    parts = [
        str(record.get("title") or ""),
        str(record.get("assertion") or ""),
        str(record.get("applies_when") or ""),
        str(metadata.get("root_cause") or ""),
        str(metadata.get("resolution") or ""),
        " ".join(_as_strings(metadata.get("steps"))),
        " ".join(_as_strings(metadata.get("identifiers"))),
        _searchable_external_evidence(metadata.get("external_evidence")),
    ]
    return "\n".join(part for part in parts if part)


def _memory_subject_key(record: Mapping[str, Any]) -> str:
    metadata = _as_dict(record.get("metadata"))
    explicit = _optional_string(metadata.get("subject_key"))
    if explicit:
        return explicit.lower()
    refs = _as_strings(record.get("scope_refs") or metadata.get("scope_refs"))
    if refs:
        return "scope:" + "|".join(sorted(refs)).lower()
    terms = sorted(_terms(str(record.get("assertion") or "")))[:6]
    return "terms:" + "|".join(terms) if terms else str(record.get("scope") or "global")


def _memory_similarity(left: Mapping[str, Any], right: Mapping[str, Any]) -> float:
    left_terms = {_term_stem(item) for item in _terms(_memory_text(left))}
    right_terms = {_term_stem(item) for item in _terms(_memory_text(right))}
    if not left_terms or not right_terms:
        return 0.0
    overlap = len(left_terms & right_terms)
    union = len(left_terms | right_terms)
    jaccard = overlap / union if union else 0.0
    containment = overlap / min(len(left_terms), len(right_terms))
    same_subject = 1.0 if _memory_subject_key(left) == _memory_subject_key(right) else 0.0
    return max(jaccard, containment * 0.9, same_subject * jaccard)


def _term_stem(value: str) -> str:
    if len(value) > 5 and value.endswith("ies"):
        return value[:-3] + "y"
    if len(value) > 4 and value.endswith("s"):
        return value[:-1]
    return value


def _load_extraction_labels(repo_root: Path, fixtures: str | None) -> list[dict[str, Any]]:
    if not fixtures:
        return []
    path = Path(fixtures)
    if not path.is_absolute():
        path = repo_root / path
    if not path.exists():
        raise FileNotFoundError(f"memory extraction fixture not found: {path}")
    if path.suffix.lower() == ".jsonl":
        rows = []
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                rows.append(json.loads(line))
        return [dict(item) for item in rows if isinstance(item, Mapping)]
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data, Mapping):
        data = data.get("labels") or data.get("items") or data.get("records") or []
    if not isinstance(data, Sequence) or isinstance(data, (str, bytes)):
        return []
    return [dict(item) for item in data if isinstance(item, Mapping)]


def _normalize_eval_assertion(value: str) -> str:
    return " ".join(sorted(_terms(value))) or value.strip().lower()


def _searchable_external_evidence(value: Any) -> str:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return ""
    parts: list[str] = []
    for item in value:
        if not isinstance(item, Mapping):
            continue
        parts.extend(
            str(item.get(key) or "")
            for key in ("source", "project_reference", "function_name", "verification_result")
        )
        parts.extend(_as_strings(item.get("secret_names")))
    return " ".join(part for part in parts if part)


def _lexical_score(query_terms: set[str], text: str) -> float:
    if not query_terms:
        return 0.0
    text_terms = _terms(text)
    overlap = query_terms & text_terms
    return round(len(overlap) / max(1, len(query_terms)), 6)


def _deterministic_score(query: str, query_terms: set[str], text: str) -> tuple[float, str]:
    normalized_query = query.strip().casefold()
    if normalized_query and normalized_query in text.casefold():
        return 1.25, "exact_identifier"
    return _lexical_score(query_terms, text), "deterministic_lexical"


def _fts_score(rank: float) -> float:
    # FTS5 bm25 scores are lower for better matches and are often negative.
    return round(1.0 / (1.0 + max(0.0, float(rank))), 6)


def _memory_age_days(record: Mapping[str, Any]) -> int:
    timestamp = str(record.get("last_validated_at") or record.get("updated_at") or "")
    parsed = _parse_timestamp(timestamp)
    if parsed is None:
        return 0
    return max(0, int((datetime.now(UTC) - parsed).total_seconds() // 86400))


def _parse_timestamp(value: str) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _redact_memory_assertion(assertion: str, metadata: Mapping[str, Any]) -> tuple[str, dict[str, Any]]:
    redacted, summary = redact_with_summary(assertion)
    next_metadata = dict(metadata)
    if int(summary.get("redacted_count", 0) or 0) > 0:
        next_metadata["redaction"] = {
            **summary,
            "values_persisted": False,
            "redaction_scope": "memory_assertion",
        }
    return redacted, next_metadata


def _is_generic_recall_record(record: Mapping[str, Any]) -> bool:
    from persistmind.memory_quality import is_generic_completion_episode

    return is_generic_completion_episode(record)


def _select_recall_items(ranked: list[dict[str, Any]], limit: int) -> list[dict[str, Any]]:
    if not any(not item.get("recall_generic") for item in ranked):
        return ranked[:limit]
    generic_cap = max(1, limit // 4)
    selected: list[dict[str, Any]] = []
    generic_count = 0
    deferred_generic: list[dict[str, Any]] = []
    for item in ranked:
        if len(selected) >= limit:
            break
        if item.get("recall_generic"):
            if generic_count >= generic_cap:
                deferred_generic.append(item)
                continue
            generic_count += 1
        selected.append(item)
    if len(selected) < limit:
        for item in deferred_generic:
            if len(selected) >= limit:
                break
            selected.append(item)
    return selected


def _calibration_metrics(
    observations: Sequence[tuple[float, int, str]], *, bins: int
) -> dict[str, Any]:
    count = len(observations)
    brier = sum((probability - outcome) ** 2 for probability, outcome, _ in observations)
    grouped: dict[int, list[tuple[float, int]]] = {}
    for probability, outcome, _ in observations:
        index = min(bins - 1, int(probability * bins))
        grouped.setdefault(index, []).append((probability, outcome))
    calibration_bins = []
    ece = 0.0
    for index, items in sorted(grouped.items()):
        mean_probability = sum(item[0] for item in items) / len(items)
        observed_rate = sum(item[1] for item in items) / len(items)
        ece += len(items) / count * abs(mean_probability - observed_rate)
        calibration_bins.append(
            {
                "bin": index,
                "count": len(items),
                "mean_probability": round(mean_probability, 12),
                "observed_rate": round(observed_rate, 12),
            }
        )
    return {
        "count": count,
        "brier_score": round(brier / count, 12),
        "expected_calibration_error": round(ece, 12),
        "bins": calibration_bins,
        "forecast_ids": [item[2] for item in observations],
    }


def _find_revision(
    revisions: Sequence[Mapping[str, Any]], revision_id: str | None
) -> Mapping[str, Any] | None:
    return next(
        (item for item in revisions if str(item.get("revision_id")) == str(revision_id)),
        None,
    )


def _metadata_satisfies(value: Any, expected: str) -> bool:
    if expected == "non_empty_string":
        return isinstance(value, str) and bool(value.strip())
    if expected == "non_empty_list":
        return isinstance(value, Sequence) and not isinstance(value, str) and bool(value)
    if expected == "priority":
        return isinstance(value, (int, float)) or (
            isinstance(value, str)
            and value.strip().lower() in {"low", "medium", "high", "critical"}
        )
    return value is not None


def _agent_generated_without_validator(provenance: Mapping[str, Any]) -> bool:
    generator = str(provenance.get("generator") or "")
    validator = str(provenance.get("validator") or "none")
    return generator.startswith("agent:") and validator in {"", "none", "null"}


def _claims_policy_enforcement(assertion: str, metadata: Mapping[str, Any]) -> bool:
    if metadata.get("enforces") is True:
        return True
    lowered = assertion.lower()
    return any(
        phrase in lowered
        for phrase in (
            "this memory enforces",
            "enforce this policy",
            "must override policy",
            "bypass policy",
        )
    )


def _claims_policy_override(assertion: str, metadata: Mapping[str, Any]) -> bool:
    if metadata.get("overrides_policy") is True:
        return True
    lowered = assertion.lower()
    return any(
        phrase in lowered
        for phrase in (
            "override policy",
            "ignore policy",
            "bypass policy",
            "preference overrides",
            "must override policy",
        )
    )


def _is_external(source_kind: str, provenance: Mapping[str, Any]) -> bool:
    if bool(provenance.get("external")):
        return True
    normalized = source_kind.strip().lower()
    return normalized.startswith(
        ("external:", "slack", "email", "transcript", "jira", "confluence", "crm")
    )


def _needs_source_revision_stamp(
    raw: Mapping[str, Any], metadata: Mapping[str, Any]
) -> bool:
    return bool(
        raw.get("branch")
        or raw.get("task_session_id")
        or raw.get("scope_refs")
        or raw.get("paths")
        or metadata.get("branch")
        or metadata.get("source_bound")
        or metadata.get("scope_refs")
    )


def _source_bound_paths(
    raw: Mapping[str, Any],
    metadata: Mapping[str, Any],
    evidence_items: object,
) -> list[str]:
    paths = set(_as_strings(raw.get("paths")))
    paths.update(_as_strings(raw.get("scope_refs") or metadata.get("scope_refs")))
    if isinstance(evidence_items, Sequence) and not isinstance(evidence_items, (str, bytes)):
        for item in evidence_items:
            if not isinstance(item, Mapping):
                continue
            path = _optional_string(item.get("path"))
            if path:
                paths.add(path)
    return sorted(paths)


def _require_actor_role(actor: str, minimum: str, action: str) -> None:
    authorization = require_actor_role(actor, minimum, action)
    if not authorization["ok"]:
        raise PermissionError(
            f"{action} requires {authorization['required_role']} role; "
            f"{authorization['actor']} is {authorization['actor_role']}"
        )


def _is_expired(record: Mapping[str, Any]) -> bool:
    metadata = _as_dict(record.get("metadata"))
    source_at_write = _as_dict(metadata.get("source_path_hashes_at_write"))
    source_current = _as_dict(metadata.get("source_path_hashes_current"))
    if source_at_write and source_current and source_at_write != source_current:
        return True
    value = _optional_string(record.get("expires_at"))
    if not value:
        return False
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed <= datetime.now(UTC)


def _conflict_summary(left: str, right: str) -> str | None:
    left_l, right_l = left.lower(), right.lower()
    if ("must " in left_l and "must not" in right_l) or (
        "must not" in left_l and "must " in right_l
    ):
        return "Rules use conflicting obligation verbs."
    polarity_pairs = (
        ("enabled", "disabled"),
        ("enable", "disable"),
        ("allowed", "forbidden"),
        ("allow", "block"),
        ("required", "prohibited"),
    )
    shared_terms = _terms(left_l) & _terms(right_l)
    if shared_terms:
        for positive, negative in polarity_pairs:
            if (
                re.search(rf"\b{positive}\b", left_l)
                and re.search(rf"\b{negative}\b", right_l)
            ) or (
                re.search(rf"\b{negative}\b", left_l)
                and re.search(rf"\b{positive}\b", right_l)
            ):
                return "Records describe the same subject with incompatible polarity."
    left_numbers = set(re.findall(r"\b\d+(?:[,_]\d+)*\b", left_l))
    right_numbers = set(re.findall(r"\b\d+(?:[,_]\d+)*\b", right_l))
    if left_numbers and right_numbers and left_numbers != right_numbers and shared_terms:
        return "Records describe the same scope with incompatible numeric thresholds."
    return None


def _policy_priority(severity: str) -> int:
    return {"critical": 100, "high": 75, "medium": 50, "low": 25}.get(severity.strip().lower(), 50)


def _policy_matches_paths(policy: Mapping[str, Any], paths: Sequence[str]) -> bool:
    globs = _as_strings(policy.get("path_globs")) or ["**"]
    return any(fnmatch.fnmatch(path, glob) for path in paths for glob in globs)


def _policy_matches_scope(policy: Mapping[str, Any], scope: str) -> bool:
    declared = str(policy.get("scope") or "global")
    if declared == "global":
        return True
    if declared == scope:
        return True
    path = scope.removeprefix("path:")
    return _policy_matches_paths(policy, [path])
