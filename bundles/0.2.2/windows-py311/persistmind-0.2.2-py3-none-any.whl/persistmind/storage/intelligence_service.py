from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from persistmind.application.capability_gate import require_capabilities
from persistmind.config import load_settings
from persistmind.utils import canonical_json, stable_id, utc_now

from .adapters.sqlite_learning import SQLiteLearningStore
from .descriptors import StoreRole
from .runtime import StorageOpenIntent, StorageRuntime, resolve_runtime_store

ADVISORY_CAPABILITIES = frozenset(
    {
        "anticipation",
        "intuition",
        "sixth_sense",
        "gut",
        "lookahead",
        "surprise",
        "interoception",
        "cie",
        "teaching",
        "student",
        "curriculum",
        "metacognition",
        "agency",
        "world_model",
        "self_improvement",
        "self_modification",
        "benchmark",
        "flywheel",
        "critique",
        "foresight",
    }
)
QUERY_ACTIONS = frozenset(
    {
        "status",
        "show",
        "list",
        "score",
        "preview",
        "timeline",
        "doctor",
        "brief",
        "profile",
        "mastery",
        "compare",
        "verify",
        "audit",
        "for",
        "consult",
        "gut",
        "lookahead",
        "predict",
        "simulate",
        "ui-review",
    }
)
GATED_ACTIONS = frozenset(
    {"adopt", "activate", "apply", "rollback", "run", "import", "modify", "execute"}
)

CAPABILITY_CONTRACTS = {
    **{
        name: "DF-05"
        for name in (
            "anticipation",
            "intuition",
            "sixth_sense",
            "gut",
            "lookahead",
            "surprise",
            "interoception",
        )
    },
    **{
        name: "DF-04"
        for name in (
            "cie",
            "teaching",
            "student",
            "curriculum",
            "metacognition",
            "agency",
            "world_model",
        )
    },
    **{name: "DF-06" for name in ("self_improvement", "self_modification")},
    **{name: "DF-03" for name in ("benchmark", "flywheel", "critique", "foresight")},
}


class CapabilityNotImplementedError(RuntimeError):
    """Raised when a routed capability has no operational implementation yet."""

    status = "capability_not_implemented"

    def __init__(self, capability: str) -> None:
        self.capability = capability
        super().__init__(
            f"PersistMind capability is not implemented: {capability}. "
            "It cannot return advisory records in place of a real result."
        )


class IntelligenceService:
    """Learning-owned intelligence that can advise but cannot self-authorize."""

    def __init__(
        self, repo_root: Path, *, allow_development_driver: bool = False, read_only: bool = False
    ) -> None:
        self.repo_root = repo_root.resolve()
        self.read_only = read_only
        self.allow_development_driver = allow_development_driver
        self.runtime: StorageRuntime | None = None
        self.store: SQLiteLearningStore | None = None

    def _ensure_open(self) -> SQLiteLearningStore:
        if self.store is not None:
            return self.store
        settings = load_settings(self.repo_root)
        self.runtime = StorageRuntime.open(
            self.repo_root / settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=self.allow_development_driver,
            read_only=self.read_only,
            required_roles=frozenset({StoreRole.LEARNING}),
        )
        store = resolve_runtime_store(self.runtime, StoreRole.LEARNING, read_only=self.read_only)
        if not isinstance(store, SQLiteLearningStore):
            raise RuntimeError("Learning route did not resolve for advanced intelligence")
        self.store = store
        return store

    def close(self) -> None:
        if self.runtime is not None:
            self.runtime.close()
            self.runtime = None
            self.store = None

    def __enter__(self) -> IntelligenceService:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def execute(self, capability: str, action: str, request: Mapping[str, Any]) -> dict[str, Any]:
        capability = capability.strip().casefold().replace("-", "_")
        action = action.strip().casefold().replace("_", "-") or "status"
        if capability not in ADVISORY_CAPABILITIES:
            raise ValueError(f"unknown Learning capability: {capability}")
        require_capabilities(self.repo_root, (CAPABILITY_CONTRACTS[capability],))
        if capability in {"teaching", "student", "curriculum"}:
            raise CapabilityNotImplementedError(capability)
        self._ensure_open()
        if action in QUERY_ACTIONS:
            return self._query(capability, action, request)
        if self.read_only:
            raise PermissionError("Learning command requires a write-capable handler")
        return self._record(capability, action, request)

    def _query(self, capability: str, action: str, request: Mapping[str, Any]) -> dict[str, Any]:
        store = self._ensure_open()
        identifier = str(
            request.get("record_id") or request.get("run_id") or request.get("proposal_id") or ""
        )
        if identifier:
            row = (
                store._reader()
                .execute(
                    "SELECT * FROM learning_capability_records WHERE record_id=?", (identifier,)
                )
                .fetchone()
            )
            records = [dict(row)] if row is not None else []
        else:
            rows = (
                store._reader()
                .execute(
                    "SELECT * FROM learning_capability_records WHERE capability=? "
                    "ORDER BY updated_at DESC,record_id LIMIT ?",
                    (capability, max(1, min(int(request.get("limit") or 20), 200))),
                )
                .fetchall()
            )
            records = [dict(row) for row in rows]
        return {
            "ok": True,
            "schema_version": "persistmind.learning.advisory_query.v1",
            "capability": capability,
            "action": action,
            "maturity": "experimental",
            "advisory_only": True,
            "records": [_decode_record(item) for item in records],
            "count": len(records),
            "limitations": [
                "Predictions cannot authorize or execute changes.",
                "Confidence measures evidence coverage, not correctness probability.",
            ],
        }

    def _record(self, capability: str, action: str, request: Mapping[str, Any]) -> dict[str, Any]:
        store = self._ensure_open()
        sanitized = {key: _json_safe(value) for key, value in request.items() if value is not None}
        evidence = sorted(
            {
                str(value)
                for key, value in sanitized.items()
                if key.endswith(("_id", "_ref", "_hash")) and value
            }
        )
        request_hash = hashlib.sha256(canonical_json(sanitized).encode()).hexdigest()
        record_id = "learning_" + stable_id(capability, action, request_hash)[:32]
        confidence = min(0.95, 0.35 + min(len(evidence), 6) * 0.1)
        now = utc_now()
        result = {
            "recommendation": str(sanitized.get("task") or sanitized.get("rationale") or action),
            "action_class": str(sanitized.get("action_class") or action),
            "advisory_only": True,
        }
        proposal_id = None
        with store._write_lock, store.connection:
            store.connection.execute(
                "INSERT INTO learning_capability_records VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?) "
                "ON CONFLICT(record_id) DO UPDATE SET result_json=excluded.result_json,"
                "evidence_json=excluded.evidence_json,confidence=excluded.confidence,"
                "revision=learning_capability_records.revision+1,updated_at=excluded.updated_at",
                (
                    record_id,
                    capability,
                    action,
                    "advisory",
                    "experimental",
                    canonical_json(sanitized),
                    canonical_json(result),
                    canonical_json(evidence),
                    "persistmind-deterministic-advisory-v1",
                    confidence,
                    canonical_json({"method": "evidence-coverage", "samples": len(evidence)}),
                    canonical_json(["requires independent verification", "cannot self-authorize"]),
                    f"{capability}:{action}:{request_hash}",
                    now,
                    now,
                ),
            )
            if action in GATED_ACTIONS:
                proposal_id = "proposal_" + stable_id(record_id, action)[:32]
                store.connection.execute(
                    "INSERT OR IGNORE INTO learning_action_proposals VALUES(?,?,?,?,NULL,NULL,NULL,?,1,?,?)",
                    (
                        proposal_id,
                        record_id,
                        result["action_class"],
                        "policy_pending",
                        canonical_json(sanitized),
                        now,
                        now,
                    ),
                )
            store.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return {
            "ok": True,
            "schema_version": "persistmind.learning.advisory.v1",
            "capability": capability,
            "action": action,
            "record_id": record_id,
            "proposal_id": proposal_id,
            "state": "policy_pending" if proposal_id else "advisory",
            "maturity": "experimental",
            "advisory_only": True,
            "model_version": "persistmind-deterministic-advisory-v1",
            "evidence_ids": evidence,
            "confidence": confidence,
            "calibration": {"method": "evidence-coverage", "samples": len(evidence)},
            "limitations": ["requires independent verification", "cannot self-authorize"],
        }


def _decode_record(record: Mapping[str, Any]) -> dict[str, Any]:
    value = dict(record)
    for key in (
        "request_json",
        "result_json",
        "evidence_json",
        "calibration_json",
        "limitations_json",
    ):
        value[key.removesuffix("_json")] = json.loads(str(value.pop(key)))
    return value


def _json_safe(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_json_safe(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)
