from __future__ import annotations

import time
from collections.abc import Iterable, Mapping
from concurrent.futures import ThreadPoolExecutor, wait
from dataclasses import asdict
from typing import Any

from .cache import RevisionCache
from .descriptors import PRIMARY_ROLE_BY_DOMAIN, ConsistencyWatermark, StorageDomain
from .router import StorageRouter


class FederationTimeout(TimeoutError):
    def __init__(self, elapsed_ms: float, completed: Iterable[str]) -> None:
        super().__init__(f"federated retrieval timed out after {elapsed_ms:.1f} ms")
        self.elapsed_ms, self.completed = elapsed_ms, tuple(completed)


class FederatedRetrieval:
    def __init__(self, router: StorageRouter, *, max_workers: int = 5) -> None:
        self.router = router
        self.max_workers = max_workers
        self.cache: RevisionCache[dict[str, Any]] = RevisionCache(max_entries=128, ttl_seconds=5)

    def exact(self, domain: StorageDomain | str, record_id: str) -> Mapping[str, Any] | None:
        requested = StorageDomain(domain)
        for store in self.router.resolve_read_set(PRIMARY_ROLE_BY_DOMAIN[requested]):
            result = store.get(record_id)
            if result is not None:
                return result
        return None

    def search(
        self,
        query: str,
        *,
        domains: Iterable[StorageDomain | str] = tuple(StorageDomain),
        limit: int = 20,
        timeout_ms: int = 250,
        max_bytes: int = 262144,
    ) -> dict[str, Any]:
        selected = tuple(StorageDomain(item) for item in domains)
        stores = {
            f"{domain.value}:{store.descriptor.store_id}": store
            for domain in selected
            for store in self.router.resolve_read_set(PRIMARY_ROLE_BY_DOMAIN[domain])
        }
        revisions = {store.descriptor.store_id: store.revision() for store in stores.values()}
        cache_key = (query, tuple(sorted(stores)), limit, max_bytes)
        cached = self.cache.get(cache_key, revision=tuple(sorted(revisions.items())))
        if cached is not None:
            return {**cached, "cache": "hit"}
        started = time.perf_counter()
        executor = ThreadPoolExecutor(
            max_workers=min(self.max_workers, len(stores) or 1), thread_name_prefix="ctx-federation"
        )
        futures = {
            executor.submit(store.search, query, limit=limit): name
            for name, store in stores.items()
        }
        done, pending = wait(futures, timeout=timeout_ms / 1000)
        completed = [futures[future] for future in done]
        if pending:
            for future in pending:
                future.cancel()
            executor.shutdown(wait=False, cancel_futures=True)
            raise FederationTimeout((time.perf_counter() - started) * 1000, completed)
        executor.shutdown(wait=True)
        candidates: list[dict[str, Any]] = []
        for future in done:
            route = futures[future]
            domain = route.split(":", 1)[0]
            for item in future.result():
                candidate = dict(item)
                candidate["_domain"] = domain
                candidates.append(candidate)
        candidates.sort(key=lambda item: (str(item.get("record_id", "")), item["_domain"]))
        bounded: list[dict[str, Any]] = []
        used = 0
        import json

        for item in candidates[: max(1, min(limit, 1000))]:
            size = len(json.dumps(item, sort_keys=True, default=str).encode())
            if used + size > max_bytes:
                break
            bounded.append(item)
            used += size
        watermark = ConsistencyWatermark(self.router.topology.generation, revisions)
        result = {
            "results": bounded,
            "result_bytes": used,
            "truncated": len(bounded) < len(candidates),
            "watermark": asdict(watermark),
            "elapsed_ms": round((time.perf_counter() - started) * 1000, 3),
            "cache": "miss",
        }
        self.cache.put(cache_key, result, revision=tuple(sorted(revisions.items())))
        return result
