from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path

from .artifacts import ContentAddressedArtifacts
from .bootstrap import bootstrap_nextgen
from .catalog import FileCatalog
from .descriptors import StoreRole, TopologyManifest
from .interfaces import DomainStore
from .local_path import require_local_live_state_path
from .router import StorageRouter
from .runtime_policy import require_qualified_nextgen_runtime
from .services import nextgen_router
from .workspace_lock import WorkspaceRuntimeLock


class StorageOpenIntent(StrEnum):
    INSPECT = "inspect"
    REQUIRE_INITIALIZED = "require_initialized"
    INITIALIZE = "initialize"


class StorageNotInitialized(RuntimeError):
    status = "storage_not_initialized"
    remediation = "persistmind --repo . init"


@dataclass(frozen=True, slots=True)
class StorageInspection:
    root: Path
    initialized: bool
    topology: TopologyManifest | None


def inspect_storage(root: Path) -> StorageInspection:
    """Read catalog state without creating the workspace or opening SQLite files."""

    root = root.resolve()
    catalog = FileCatalog(root / "catalog")
    if not catalog.current_path.exists():
        return StorageInspection(root=root, initialized=False, topology=None)
    return StorageInspection(root=root, initialized=True, topology=catalog.current())


def resolve_runtime_store(
    runtime: StorageRuntime, role: StoreRole, *, read_only: bool
) -> DomainStore:
    """Resolve one role through the structurally correct query/command path."""

    if read_only:
        stores = runtime.router.resolve_read_set(role)
        if not stores:
            raise RuntimeError(f"read route is unavailable: {role.value}")
        return stores[0]
    return runtime.router.resolve_write_store(role)


class StorageRuntime:
    """Own a lazy, role-scoped router and artifact store for one operation."""

    def __init__(
        self,
        root: Path,
        router: StorageRouter,
        *,
        allow_development_driver: bool = False,
        read_only: bool = False,
        runtime_lock: WorkspaceRuntimeLock | None = None,
    ) -> None:
        self.root = root.resolve()
        self.catalog = FileCatalog(self.root / "catalog")
        self.router = router
        self.artifacts = ContentAddressedArtifacts(
            self.root / "objects",
            allow_test_key_provider=allow_development_driver,
        )
        self.read_only = read_only
        self._runtime_lock = runtime_lock

    @classmethod
    def open(
        cls,
        root: Path,
        *,
        intent: StorageOpenIntent,
        allow_development_driver: bool = False,
        read_only: bool = False,
        required_roles: frozenset[StoreRole] | None = None,
    ) -> StorageRuntime:
        """Open PersistMind next-generation storage only under the locked production runtime.

        ``allow_development_driver`` is deliberately test-only: source-tree
        characterization tests can exercise the adapters with stdlib SQLite,
        while normal product paths fail closed without the pinned APSW build.
        """

        require_local_live_state_path(root)
        root = root.resolve()
        inspection = inspect_storage(root)
        if not inspection.initialized:
            if intent is StorageOpenIntent.INITIALIZE:
                if not allow_development_driver:
                    require_qualified_nextgen_runtime()
                bootstrap_nextgen(
                    root,
                    activate=True,
                    allow_development_driver=allow_development_driver,
                    project_state_protocol=2,
                )
            else:
                raise StorageNotInitialized(
                    "persistmind-nextgen-v1 storage is not initialized; use an explicit initialize intent"
                )
        if intent is StorageOpenIntent.INSPECT:
            raise ValueError("inspect intent returns StorageInspection; use inspect_storage")
        runtime_lock = WorkspaceRuntimeLock(root, exclusive=False).acquire()
        if not allow_development_driver:
            try:
                require_qualified_nextgen_runtime()
            except BaseException:
                runtime_lock.close()
                raise
        if required_roles is None:
            runtime_lock.close()
            raise ValueError("storage runtime requires an explicit role set")
        allowed_roles = frozenset(required_roles)
        if not allowed_roles:
            runtime_lock.close()
            raise ValueError("storage runtime role set must not be empty")
        from persistmind.application.execution_scope import current_operation_scope
        from persistmind.application.registry import OperationMode

        execution_scope = current_operation_scope()
        if execution_scope is not None:
            requested = frozenset(role.value for role in allowed_roles)
            undeclared = sorted(requested - execution_scope.roles)
            if undeclared:
                runtime_lock.close()
                raise PermissionError(
                    f"operation {execution_scope.operation_id} requested undeclared roles: {undeclared}"
                )
            if execution_scope.mode is OperationMode.QUERY and not read_only:
                runtime_lock.close()
                raise PermissionError(
                    f"query operation requested a writable runtime: {execution_scope.operation_id}"
                )
        try:
            return cls(
                root,
                nextgen_router(
                    root,
                    allow_development_driver=allow_development_driver,
                    read_only=read_only,
                    allowed_roles=allowed_roles,
                ),
                allow_development_driver=allow_development_driver,
                read_only=read_only,
                runtime_lock=runtime_lock,
            )
        except BaseException:
            runtime_lock.close()
            raise

    @property
    def topology(self) -> TopologyManifest:
        return self.router.topology

    def close(self) -> None:
        try:
            self.router.close()
        except BaseException as exc:
            raise RuntimeError("storage resources failed to close") from exc
        finally:
            if self._runtime_lock is not None:
                self._runtime_lock.close()
                self._runtime_lock = None

    def __enter__(self) -> StorageRuntime:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
