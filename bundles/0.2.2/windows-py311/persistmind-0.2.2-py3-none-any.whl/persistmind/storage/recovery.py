from __future__ import annotations

import hashlib
import json
import os
import shutil
from collections.abc import Mapping
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from persistmind.utils import stable_id

from .backup import BackupService, verify_authority_image
from .catalog import FileCatalog
from .descriptors import StoreDescriptor, StoreRole
from .lifecycle import OperationFence
from .runtime import inspect_storage
from .workspace_lock import WorkspaceRuntimeLock

RECOVERY_PLAN_SCHEMA = "persistmind.authority_recovery_plan.v1"
RECOVERY_STAGE_SCHEMA = "persistmind.authority_recovery_stage.v1"


class RecoverySafetyError(RuntimeError):
    status = "recovery_safety_gate_failed"


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _file_evidence(path: Path, root: Path) -> dict[str, Any]:
    stat = path.stat()
    return {
        "path": path.relative_to(root).as_posix(),
        "bytes": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
        "sha256": _sha256(path),
    }


def _read_json(path: Path, schema: str) -> dict[str, Any]:
    try:
        value = json.loads(path.resolve().read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RecoverySafetyError(f"recovery document is unreadable: {path}") from exc
    if not isinstance(value, dict) or value.get("schema_version") != schema:
        raise RecoverySafetyError(f"unexpected recovery document schema: {path}")
    return value


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def _available_bytes(path: Path) -> int:
    candidate = path.resolve()
    while not candidate.exists() and candidate != candidate.parent:
        candidate = candidate.parent
    return int(shutil.disk_usage(candidate).free)


def _tree_bytes(path: Path) -> int:
    return sum(item.stat().st_size for item in path.rglob("*") if item.is_file())


def _restore_authority_image(live: Path, quarantined: Path, local_quarantine: Path) -> None:
    replacement = live.with_suffix(live.suffix + ".restore-original")
    shutil.copy2(quarantined, replacement)
    os.replace(replacement, live)
    for suffix in ("-wal", "-shm"):
        current = Path(str(live) + suffix)
        current.unlink(missing_ok=True)
        saved = local_quarantine / (live.name + suffix)
        if saved.exists():
            os.replace(saved, current)


def _verify_capture(stage: Mapping[str, Any]) -> None:
    root = Path(str(stage["capture"])).resolve()
    observed: list[dict[str, Any]] = []
    for expected in stage.get("capture_files", []):
        path = root / str(expected["path"])
        if (
            not path.is_file()
            or path.stat().st_size != int(expected["bytes"])
            or _sha256(path) != str(expected["sha256"])
        ):
            raise RecoverySafetyError(f"immutable recovery capture changed: {path}")
        observed.append(dict(expected))
    digest = hashlib.sha256(
        json.dumps(observed, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    if digest != stage.get("capture_root_hash"):
        raise RecoverySafetyError("recovery capture root hash changed")


def _sqlite_integrity(path: Path, descriptor: StoreDescriptor) -> dict[str, Any]:
    try:
        return verify_authority_image(path, descriptor)
    except Exception as exc:
        return {
            "ok": False,
            "error_type": type(exc).__name__,
            "error": str(exc),
        }


def _authority_semantics(path: Path, descriptor: StoreDescriptor) -> dict[str, Any]:
    if descriptor.store_role is not StoreRole.TASK_STATE:
        return {"ok": True, "status": "identity_and_integrity_only"}
    from .adapters.sqlite_task import SQLiteTaskStore

    store = SQLiteTaskStore(path, descriptor=replace(descriptor, read_only=True))
    try:
        return store.semantic_recovery_report()
    finally:
        store.close()


def _authority_revision(path: Path, descriptor: StoreDescriptor) -> int | None:
    if descriptor.store_role is not StoreRole.TASK_STATE:
        return None
    from .adapters.sqlite_task import SQLiteTaskStore

    try:
        store = SQLiteTaskStore(path, descriptor=replace(descriptor, read_only=True))
        try:
            return store.revision()
        finally:
            store.close()
    except Exception:
        return None


class AuthorityRecoveryService:
    """Backup-first, copy-only authority recovery with separate activation.

    Planning never opens a writer.  Staging captures the complete workspace and
    restores a candidate outside it.  Only ``apply`` may replace an authority
    image, and it retains a hash-verified quarantine copy for rollback.
    """

    def __init__(self, repo_root: Path, workspace_root: Path) -> None:
        self.repo_root = repo_root.resolve()
        self.workspace_root = workspace_root.resolve()

    def plan(self, authority: str, *, output: Path) -> dict[str, Any]:
        inspection = inspect_storage(self.workspace_root)
        if not inspection.initialized or inspection.topology is None:
            raise RecoverySafetyError("storage is not initialized")
        try:
            role = StoreRole(authority.strip().lower())
        except ValueError as exc:
            raise ValueError(f"unknown authority role: {authority}") from exc
        matches = [
            item
            for item in inspection.topology.stores
            if item.store_role is role and item.state == "active"
        ]
        if len(matches) != 1:
            raise RecoverySafetyError(
                f"recovery requires exactly one active authority image: {role.value}"
            )
        descriptor = matches[0]
        authority_path = FileCatalog(self.workspace_root / "catalog").resolve_location(
            descriptor.location
        )
        files = [
            path
            for path in (
                authority_path,
                Path(str(authority_path) + "-wal"),
                Path(str(authority_path) + "-shm"),
            )
            if path.is_file()
        ]
        if not files:
            raise RecoverySafetyError("declared authority image is missing")
        run_id = (
            "recovery_"
            + stable_id(
                str(self.workspace_root), role.value, str(inspection.topology.generation), _now()
            )[:32]
        )
        document = {
            "ok": True,
            "schema_version": RECOVERY_PLAN_SCHEMA,
            "recovery_run_id": run_id,
            "created_at": _now(),
            "source_workspace": str(self.workspace_root),
            "topology_generation": inspection.topology.generation,
            "topology_id": inspection.topology.topology_id,
            "authority": descriptor.to_dict(),
            "source_revision": _authority_revision(authority_path, descriptor),
            "source_files": [_file_evidence(path, self.workspace_root) for path in files],
            "configuration_files": [
                _file_evidence(path, self.repo_root)
                for name in ("persistmind.toml", "persistmind.yaml", "persistmind.yml")
                if (path := self.repo_root / name).is_file()
            ],
            "strategies": [
                "verified_backup_with_replay_parity",
                "pinned_sqlite_recover_into_fresh_schema",
                "derived_projection_reconstruction",
            ],
            "prohibited_actions": [
                "vacuum_live",
                "reindex_live",
                "direct_page_edit",
                "blind_wal_delete",
                "activate_raw_recovery_output",
            ],
            "next_action": "stage",
        }
        target = output.resolve()
        if target.is_relative_to(self.workspace_root):
            raise RecoverySafetyError("recovery plans must be stored outside the live workspace")
        if target.exists():
            raise FileExistsError(target)
        _write_json(target, document)
        return {**document, "plan": str(target)}

    def stage(
        self,
        plan_path: Path,
        *,
        backup_destination: Path,
        backup_id: str | None,
    ) -> dict[str, Any]:
        plan = _read_json(plan_path, RECOVERY_PLAN_SCHEMA)
        self._require_workspace(plan)
        destination = backup_destination.resolve()
        if destination.is_relative_to(self.workspace_root):
            raise RecoverySafetyError("recovery staging must be outside the live workspace")
        if destination.exists():
            raise FileExistsError(destination)
        required_bytes = max(64 * 1024 * 1024, _tree_bytes(self.workspace_root) * 3)
        available_bytes = _available_bytes(destination.parent)
        if available_bytes < required_bytes:
            raise RecoverySafetyError(
                "insufficient recovery staging space: "
                f"required={required_bytes} available={available_bytes}"
            )
        with OperationFence(
            self.workspace_root,
            "authority-recovery-stage",
            plan,
            scope=str(plan["authority"]["store_role"]),
        ) as fence:
            with WorkspaceRuntimeLock(self.workspace_root, exclusive=True):
                self._revalidate_source(plan)
                capture = destination / "capture"
                shutil.copytree(
                    self.workspace_root,
                    capture,
                    ignore=shutil.ignore_patterns("lifecycle-*.lock"),
                )
                configuration = destination / "configuration"
                for item in plan.get("configuration_files", []):
                    source = self.repo_root / str(item["path"])
                    if not source.is_file() or _sha256(source) != str(item["sha256"]):
                        raise RecoverySafetyError(f"recovery configuration changed: {source}")
                    configuration.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source, configuration / source.name)
            capture_files = [
                _file_evidence(path, capture)
                for path in sorted(capture.rglob("*"))
                if path.is_file()
            ]
            capture_root_hash = hashlib.sha256(
                json.dumps(capture_files, sort_keys=True, separators=(",", ":")).encode()
            ).hexdigest()
            for path in capture.rglob("*"):
                if path.is_file():
                    path.chmod(0o444)
            capture_completion = destination / "capture.complete.json"
            _write_json(
                capture_completion,
                {
                    "schema_version": "persistmind.recovery_capture_completion.v1",
                    "recovery_run_id": plan["recovery_run_id"],
                    "plan_sha256": _sha256(plan_path.resolve()),
                    "capture_root_hash": capture_root_hash,
                    "file_count": len(capture_files),
                    "bytes": sum(int(item["bytes"]) for item in capture_files),
                    "completed_at": _now(),
                },
            )
            candidate_workspace: Path | None = None
            candidate_integrity: dict[str, Any] | None = None
            candidate_semantics: dict[str, Any] | None = None
            backup_result: dict[str, Any] | None = None
            candidate_sha256: str | None = None
            candidate_companions: list[dict[str, Any]] = []
            parity: dict[str, Any] = {
                "ok": False,
                "status": "backup_required" if not backup_id else "unverified",
                "authoritative_loss": "unknown",
            }
            if backup_id:
                candidate_workspace = destination / "candidate-workspace"
                backup_service = BackupService(self.workspace_root)
                backup_result = backup_service.verify(backup_id)
                backup_service.restore_stage(backup_id, target=candidate_workspace)
                descriptor = StoreDescriptor.from_dict(plan["authority"])
                candidate = FileCatalog(candidate_workspace / "catalog").resolve_location(
                    descriptor.location
                )
                candidate_integrity = _sqlite_integrity(candidate, descriptor)
                candidate_semantics = _authority_semantics(candidate, descriptor)
                candidate_sha256 = _sha256(candidate)
                candidate_companions = [
                    {
                        "path": str(path),
                        "suffix": suffix,
                        "bytes": path.stat().st_size,
                        "sha256": _sha256(path),
                    }
                    for suffix in ("-wal", "-shm")
                    if (path := Path(str(candidate) + suffix)).is_file()
                ]
                backup_images = {
                    str(item["store_id"]): item for item in backup_result["backup"]["images"]
                }
                image = backup_images.get(descriptor.store_id)
                same_generation = int(backup_result["backup"]["topology_generation"]) == int(
                    plan["topology_generation"]
                )
                backup_revision = int(image["revision"]) if image else None
                source_revision = plan.get("source_revision")
                revision_equal = (
                    source_revision is not None
                    and backup_revision is not None
                    and int(source_revision) == backup_revision
                )
                candidate_ok = bool(candidate_integrity.get("ok")) and bool(
                    candidate_semantics.get("ok")
                )
                parity = {
                    "ok": candidate_ok and same_generation and revision_equal,
                    "status": "verified"
                    if candidate_ok and same_generation and revision_equal
                    else "replay_or_loss_acceptance_required",
                    "authoritative_loss": "none_proven" if revision_equal else "unknown",
                    "source_revision": source_revision,
                    "backup_revision": backup_revision,
                    "revision_equal": revision_equal,
                    "same_topology_generation": same_generation,
                }
            stage = {
                "ok": bool(
                    candidate_integrity
                    and candidate_integrity.get("ok")
                    and candidate_semantics
                    and candidate_semantics.get("ok")
                ),
                "schema_version": RECOVERY_STAGE_SCHEMA,
                "recovery_run_id": plan["recovery_run_id"],
                "created_at": _now(),
                "plan": str(plan_path.resolve()),
                "plan_sha256": _sha256(plan_path.resolve()),
                "backup_destination": str(destination),
                "capture": str(capture),
                "capture_files": capture_files,
                "capture_root_hash": capture_root_hash,
                "capture_immutable": True,
                "capture_completion": str(capture_completion),
                "required_bytes": required_bytes,
                "available_bytes_at_start": available_bytes,
                "candidate_workspace": str(candidate_workspace) if candidate_workspace else None,
                "candidate_sha256": candidate_sha256,
                "candidate_companions": candidate_companions,
                "candidate_integrity": candidate_integrity,
                "candidate_semantics": candidate_semantics,
                "backup_id": backup_id,
                "parity": parity,
                "activated": False,
                "events_reconciled": False,
                "fully_verified": False,
                "rollback": None,
                "next_action": "apply"
                if parity["ok"]
                else "establish_replay_parity_or_authorize_loss",
            }
            _write_json(destination / "recovery-stage.json", stage)
            fence.succeed({"stage": str(destination), "parity": parity})
            return stage

    def status(self, stage_path: Path) -> dict[str, Any]:
        path = stage_path.resolve()
        manifest = path if path.is_file() else path / "recovery-stage.json"
        return _read_json(manifest, RECOVERY_STAGE_SCHEMA)

    def apply(
        self,
        stage_path: Path,
        *,
        loss_acceptance: Path | None = None,
    ) -> dict[str, Any]:
        manifest_path = stage_path.resolve()
        if manifest_path.is_dir():
            manifest_path = manifest_path / "recovery-stage.json"
        stage = _read_json(manifest_path, RECOVERY_STAGE_SCHEMA)
        plan = _read_json(Path(str(stage["plan"])), RECOVERY_PLAN_SCHEMA)
        self._require_workspace(plan)
        if stage.get("activated"):
            return stage
        if _sha256(Path(str(stage["plan"])).resolve()) != str(stage.get("plan_sha256")):
            raise RecoverySafetyError("recovery plan changed after staging")
        completion_path = Path(str(stage.get("capture_completion") or "")).resolve()
        completion = _read_json(completion_path, "persistmind.recovery_capture_completion.v1")
        if completion.get("recovery_run_id") != stage.get("recovery_run_id") or completion.get(
            "capture_root_hash"
        ) != stage.get("capture_root_hash"):
            raise RecoverySafetyError("recovery capture completion evidence does not match")
        _verify_capture(stage)
        activation_record_path = Path(str(stage["backup_destination"])) / "activation-record.json"
        if activation_record_path.is_file():
            activation = _read_json(
                activation_record_path, "persistmind.authority_recovery_activation.v1"
            )
            descriptor = StoreDescriptor.from_dict(plan["authority"])
            live = FileCatalog(self.workspace_root / "catalog").resolve_location(
                descriptor.location
            )
            if (
                activation.get("recovery_run_id") != stage.get("recovery_run_id")
                or not live.is_file()
                or _sha256(live) != activation.get("activated_sha256")
            ):
                raise RecoverySafetyError("activation record does not match the live authority")
            result = {
                **stage,
                **{key: value for key, value in activation.items() if key != "schema_version"},
                "ok": True,
                "activated": True,
                "resumed_from_activation_record": True,
            }
            _write_json(manifest_path, result)
            return result
        accepted_loss = self._validate_loss_acceptance(stage, loss_acceptance)
        if not bool(stage.get("parity", {}).get("ok")) and not accepted_loss:
            raise RecoverySafetyError(
                "candidate parity is incomplete; a matching explicit loss-acceptance document is required"
            )
        candidate_workspace = Path(str(stage.get("candidate_workspace") or "")).resolve()
        descriptor = StoreDescriptor.from_dict(plan["authority"])
        candidate = FileCatalog(candidate_workspace / "catalog").resolve_location(
            descriptor.location
        )
        if not candidate.is_file() or _sha256(candidate) != stage.get("candidate_sha256"):
            raise RecoverySafetyError("staged recovery candidate is unavailable or changed")
        for item in stage.get("candidate_companions", []):
            path = Path(str(item["path"])).resolve()
            if not path.is_file() or _sha256(path) != str(item["sha256"]):
                raise RecoverySafetyError("staged recovery companion is unavailable or changed")
        integrity = _sqlite_integrity(candidate, descriptor)
        if not integrity.get("ok"):
            raise RecoverySafetyError(
                "candidate failed full integrity immediately before activation"
            )
        semantics = _authority_semantics(candidate, descriptor)
        if not semantics.get("ok"):
            raise RecoverySafetyError("candidate failed authority semantic validation")
        live = FileCatalog(self.workspace_root / "catalog").resolve_location(descriptor.location)
        quarantine = Path(str(stage["backup_destination"])) / "quarantine"
        quarantine.mkdir(parents=True, exist_ok=True)
        quarantined_companions: list[dict[str, str]] = []
        with OperationFence(
            self.workspace_root,
            "authority-recovery-apply",
            stage,
            scope=descriptor.store_role.value,
        ) as fence:
            with WorkspaceRuntimeLock(self.workspace_root, exclusive=True):
                self._revalidate_source(plan)
                quarantined = quarantine / f"{descriptor.store_id}-{_sha256(live)[:16]}.db"
                shutil.copy2(live, quarantined)
                if _sha256(quarantined) != _sha256(live):
                    raise RecoverySafetyError("quarantine copy hash mismatch")
                replacement = live.with_suffix(live.suffix + ".recovery-candidate")
                shutil.copy2(candidate, replacement)
                if _sha256(replacement) != _sha256(candidate):
                    replacement.unlink(missing_ok=True)
                    raise RecoverySafetyError("candidate copy hash mismatch")
                prepared_companions: list[tuple[str, Path]] = []
                for item in stage.get("candidate_companions", []):
                    suffix = str(item["suffix"])
                    source = Path(str(item["path"])).resolve()
                    temporary = Path(str(live) + suffix + ".recovery-candidate")
                    shutil.copy2(source, temporary)
                    if _sha256(temporary) != str(item["sha256"]):
                        temporary.unlink(missing_ok=True)
                        replacement.unlink(missing_ok=True)
                        raise RecoverySafetyError("candidate companion copy hash mismatch")
                    prepared_companions.append((suffix, temporary))
                local_quarantine = (
                    live.parent / ".recovery-quarantine" / str(stage["recovery_run_id"])
                )
                local_quarantine.mkdir(parents=True, exist_ok=True)
                try:
                    for suffix in ("-wal", "-shm"):
                        companion = Path(str(live) + suffix)
                        if companion.exists():
                            target = local_quarantine / (live.name + suffix)
                            os.replace(companion, target)
                            external = quarantine / (quarantined.name + suffix)
                            shutil.copy2(target, external)
                            quarantined_companions.append(
                                {
                                    "path": str(external),
                                    "sha256": _sha256(external),
                                    "suffix": suffix,
                                }
                            )
                    os.replace(replacement, live)
                    for suffix, temporary in prepared_companions:
                        os.replace(temporary, Path(str(live) + suffix))
                    activated_integrity = _sqlite_integrity(live, descriptor)
                    if not activated_integrity.get("ok"):
                        raise RecoverySafetyError("activated candidate failed full integrity")
                    activated_semantics = _authority_semantics(live, descriptor)
                    if not activated_semantics.get("ok"):
                        raise RecoverySafetyError("activated candidate failed semantics")
                except BaseException as exc:
                    _restore_authority_image(live, quarantined, local_quarantine)
                    for _, temporary in prepared_companions:
                        temporary.unlink(missing_ok=True)
                    raise RecoverySafetyError(
                        "recovery activation failed; original evidence was restored in a "
                        "write-blocked state"
                    ) from exc
                activated_sha256 = _sha256(live)
                activation = {
                    "schema_version": "persistmind.authority_recovery_activation.v1",
                    "recovery_run_id": stage["recovery_run_id"],
                    "activated": True,
                    "activated_at": _now(),
                    "activated_sha256": activated_sha256,
                    "activated_integrity": activated_integrity,
                    "activated_semantics": activated_semantics,
                    "loss_acceptance": accepted_loss,
                    "rollback": {
                        "available": True,
                        "quarantined_original": str(quarantined),
                        "sha256": _sha256(quarantined),
                        "companions": quarantined_companions,
                    },
                    "next_action": "reconcile_events_then_full_verify",
                }
                _write_json(activation_record_path, activation)
                quarantined.chmod(0o444)
                for item in quarantined_companions:
                    Path(item["path"]).chmod(0o444)
            result = {
                **stage,
                "ok": True,
                **{key: value for key, value in activation.items() if key != "schema_version"},
            }
            _write_json(manifest_path, result)
            fence.succeed({"activated": True, "sha256": result["activated_sha256"]})
            return result

    def rollback(self, stage_path: Path) -> dict[str, Any]:
        manifest_path = stage_path.resolve()
        if manifest_path.is_dir():
            manifest_path = manifest_path / "recovery-stage.json"
        stage = _read_json(manifest_path, RECOVERY_STAGE_SCHEMA)
        if not stage.get("activated"):
            raise RecoverySafetyError("recovery stage has not been activated")
        plan = _read_json(Path(str(stage["plan"])), RECOVERY_PLAN_SCHEMA)
        self._require_workspace(plan)
        descriptor = StoreDescriptor.from_dict(plan["authority"])
        rollback = dict(stage.get("rollback") or {})
        original = Path(str(rollback.get("quarantined_original") or "")).resolve()
        if not original.is_file() or _sha256(original) != rollback.get("sha256"):
            raise RecoverySafetyError("quarantined original is unavailable or changed")
        if not _sqlite_integrity(original, descriptor).get("ok"):
            raise RecoverySafetyError(
                "quarantined original is corrupt; rollback cannot re-enable it"
            )
        live = FileCatalog(self.workspace_root / "catalog").resolve_location(descriptor.location)
        with OperationFence(
            self.workspace_root,
            "authority-recovery-rollback",
            stage,
            scope=descriptor.store_role.value,
        ) as fence:
            with WorkspaceRuntimeLock(self.workspace_root, exclusive=True):
                safety = (
                    live.parent
                    / ".recovery-quarantine"
                    / (str(stage["recovery_run_id"]) + "-rollback")
                )
                safety.mkdir(parents=True, exist_ok=True)
                saved_live = safety / live.name
                os.replace(live, saved_live)
                saved_companions: list[tuple[Path, Path]] = []
                try:
                    for suffix in ("-wal", "-shm"):
                        current = Path(str(live) + suffix)
                        if current.exists():
                            saved = safety / (live.name + suffix)
                            os.replace(current, saved)
                            saved_companions.append((saved, current))
                    replacement = live.with_suffix(live.suffix + ".rollback-candidate")
                    shutil.copy2(original, replacement)
                    if _sha256(replacement) != str(rollback["sha256"]):
                        raise RecoverySafetyError("rollback candidate copy hash mismatch")
                    os.replace(replacement, live)
                    for item in rollback.get("companions", []):
                        source = Path(str(item["path"])).resolve()
                        suffix = str(item["suffix"])
                        if (
                            suffix not in {"-wal", "-shm"}
                            or not source.is_file()
                            or _sha256(source) != str(item["sha256"])
                        ):
                            raise RecoverySafetyError(
                                "rollback companion is unavailable or changed"
                            )
                        target = Path(str(live) + suffix)
                        temporary = Path(str(target) + ".rollback-candidate")
                        shutil.copy2(source, temporary)
                        os.replace(temporary, target)
                    rolled_back_integrity = _sqlite_integrity(live, descriptor)
                    rolled_back_semantics = _authority_semantics(live, descriptor)
                    if not rolled_back_integrity.get("ok") or not rolled_back_semantics.get("ok"):
                        raise RecoverySafetyError("rolled-back authority failed validation")
                except Exception:
                    failed = safety / (live.name + ".failed-rollback")
                    if live.exists():
                        os.replace(live, failed)
                    for suffix in ("-wal", "-shm"):
                        Path(str(live) + suffix).unlink(missing_ok=True)
                    os.replace(saved_live, live)
                    for saved, current in saved_companions:
                        os.replace(saved, current)
                    raise
            result = {
                **stage,
                "ok": True,
                "activated": False,
                "rolled_back": True,
                "rolled_back_at": _now(),
                "rolled_back_integrity": rolled_back_integrity,
                "rolled_back_semantics": rolled_back_semantics,
                "next_action": "diagnose_or_stage_new_candidate",
            }
            _write_json(manifest_path, result)
            fence.succeed({"rolled_back": True})
            return result

    def record_closure(
        self,
        stage_path: Path,
        *,
        reconciliation: Mapping[str, Any],
        verification: Mapping[str, Any],
    ) -> dict[str, Any]:
        manifest_path = stage_path.resolve()
        if manifest_path.is_dir():
            manifest_path = manifest_path / "recovery-stage.json"
        stage = _read_json(manifest_path, RECOVERY_STAGE_SCHEMA)
        if not stage.get("activated"):
            raise RecoverySafetyError("recovery must be activated before reconciliation")
        reconciled = bool(reconciliation.get("ok"))
        verified = bool(verification.get("ok"))
        result = {
            **stage,
            "events_reconciled": reconciled,
            "reconciliation": dict(reconciliation),
            "fully_verified": verified,
            "full_verification": dict(verification),
            "closed": reconciled and verified,
            "closed_at": _now() if reconciled and verified else None,
            "next_action": "closed"
            if reconciled and verified
            else "resolve_reconciliation_or_verification_failures",
        }
        _write_json(manifest_path, result)
        return result

    def _require_workspace(self, plan: Mapping[str, Any]) -> None:
        if Path(str(plan.get("source_workspace"))).resolve() != self.workspace_root:
            raise RecoverySafetyError("recovery plan belongs to a different workspace")
        inspection = inspect_storage(self.workspace_root)
        if not inspection.initialized or inspection.topology is None:
            raise RecoverySafetyError("storage is not initialized")
        if inspection.topology.generation != int(plan["topology_generation"]):
            raise RecoverySafetyError("topology changed after the recovery plan was created")

    def _revalidate_source(self, plan: Mapping[str, Any]) -> None:
        for item in plan.get("source_files", []):
            path = self.workspace_root / str(item["path"])
            if not path.is_file() or path.stat().st_size != int(item["bytes"]):
                raise RecoverySafetyError(f"recovery source changed: {path}")
            if _sha256(path) != str(item["sha256"]):
                raise RecoverySafetyError(f"recovery source hash changed: {path}")

    @staticmethod
    def _validate_loss_acceptance(stage: Mapping[str, Any], path: Path | None) -> bool:
        if path is None:
            return False
        try:
            document = json.loads(path.resolve().read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RecoverySafetyError("loss-acceptance document is unreadable") from exc
        return bool(
            isinstance(document, dict)
            and document.get("accepted") is True
            and document.get("recovery_run_id") == stage.get("recovery_run_id")
            and document.get("stage_sha256")
            == _sha256(Path(str(stage["backup_destination"])) / "recovery-stage.json")
        )
