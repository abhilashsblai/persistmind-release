from __future__ import annotations

from collections.abc import Callable
from dataclasses import replace
from pathlib import Path
from typing import cast

from .adapters.sqlite_activity import SQLiteActivityStore, SQLiteAuditStore
from .adapters.sqlite_control import SQLiteControlStore
from .adapters.sqlite_knowledge import SQLiteKnowledgeStore
from .adapters.sqlite_learning import SQLiteLearningStore
from .adapters.sqlite_policy import SQLitePolicyStore
from .adapters.sqlite_source import SQLiteSourceSegmentStore, SQLiteSourceStore
from .adapters.sqlite_task import SQLiteTaskStore
from .catalog import FileCatalog
from .descriptors import StoreDescriptor, StoreRole
from .interfaces import DomainStore
from .router import StorageRouter

_SPLIT_ADAPTERS = {
    StoreRole.CONTROL: SQLiteControlStore,
    StoreRole.SOURCE_MANIFEST: SQLiteSourceStore,
    StoreRole.SOURCE_SEGMENT: SQLiteSourceSegmentStore,
    StoreRole.TASK_STATE: SQLiteTaskStore,
    StoreRole.ACTIVITY_ACTIVE: SQLiteActivityStore,
    StoreRole.ACTIVITY_SEALED: lambda path, descriptor, allow_development_driver: (
        SQLiteActivityStore(
            path,
            descriptor=descriptor,
            role=StoreRole.ACTIVITY_SEALED,
            allow_development_driver=allow_development_driver,
        )
    ),
    StoreRole.AUDIT_ACTIVE: SQLiteAuditStore,
    StoreRole.AUDIT_SEALED: lambda path, descriptor, allow_development_driver: SQLiteAuditStore(
        path,
        descriptor=descriptor,
        role=StoreRole.AUDIT_SEALED,
        allow_development_driver=allow_development_driver,
    ),
    StoreRole.KNOWLEDGE: SQLiteKnowledgeStore,
    StoreRole.POLICY: SQLitePolicyStore,
    StoreRole.LEARNING: SQLiteLearningStore,
}


def nextgen_router(
    root: Path,
    *,
    allow_development_driver: bool = False,
    read_only: bool = False,
    allowed_roles: frozenset[StoreRole] | None = None,
) -> StorageRouter:
    """Build a lazy router; no database opens until an allowed role is resolved."""

    catalog = FileCatalog(root / "catalog")
    manifest = catalog.current()
    providers: dict[str, Callable[[], DomainStore]] = {}
    scope_by_role: dict[StoreRole, str] = {}
    for descriptor in manifest.stores:
        if descriptor.state not in {"active", "ready", "sealed"}:
            continue
        if allowed_roles is not None and descriptor.store_role not in allowed_roles:
            continue
        existing_scope = scope_by_role.setdefault(
            descriptor.store_role, descriptor.authorization_scope
        )
        if existing_scope != descriptor.authorization_scope:
            raise ValueError(
                f"one runtime role cannot span authorization scopes: {descriptor.store_role.value}"
            )
        implementation = cast(Callable[..., DomainStore], _SPLIT_ADAPTERS[descriptor.store_role])
        effective = replace(descriptor, read_only=True) if read_only else descriptor
        path = catalog.resolve_location(descriptor.location)

        def open_store(
            implementation: Callable[..., DomainStore] = implementation,
            path: Path = path,
            effective: StoreDescriptor = effective,
        ) -> DomainStore:
            return implementation(
                path,
                descriptor=effective,
                allow_development_driver=allow_development_driver,
            )

        providers[descriptor.store_id] = open_store
    return StorageRouter(
        manifest,
        providers,
        allowed_roles=allowed_roles,
        scope_by_role=scope_by_role,
        read_only=read_only,
    )
