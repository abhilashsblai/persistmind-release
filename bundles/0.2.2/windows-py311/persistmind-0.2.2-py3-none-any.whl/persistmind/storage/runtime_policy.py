from __future__ import annotations

import platform
import sys
from dataclasses import dataclass
from typing import Any, Mapping

from .resources import load_json


class SQLiteRuntimeUnsupported(RuntimeError):
    status = "sqlite_runtime_unsupported"


@dataclass(frozen=True, slots=True)
class SQLiteRuntimeQualification:
    ok: bool
    driver: str
    sqlite_version: str | None
    reason: str | None
    using_amalgamation: bool | None
    platform: str
    python: str
    source_id: str | None = None
    compile_options: tuple[str, ...] = ()
    vfs: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "driver": self.driver,
            "sqlite_version": self.sqlite_version,
            "reason": self.reason,
            "using_amalgamation": self.using_amalgamation,
            "platform": self.platform,
            "python": self.python,
            "source_id": self.source_id,
            "compile_options": list(self.compile_options),
            "vfs": list(self.vfs),
        }


def qualify_nextgen_runtime() -> SQLiteRuntimeQualification:
    """Check the frozen production persistmind-nextgen-v1 SQLite delivery contract.

    Source-tree tests intentionally use the stdlib development adapter.  This
    function makes that distinction visible and blocks production activation
    rather than silently treating the host SQLite version as qualified.
    """

    policy = load_json("sqlite-runtime-policy.v1.json")
    expected = str(policy["driver"]["apsw_version"])
    expected_sqlite = str(policy["driver"]["sqlite_version"])
    expected_source = str(policy["driver"].get("source_id") or "")
    try:
        import apsw  # type: ignore[import-not-found]
    except (ImportError, ModuleNotFoundError):
        return SQLiteRuntimeQualification(
            ok=False,
            driver="stdlib-sqlite3",
            sqlite_version=None,
            reason="apsw_unavailable",
            using_amalgamation=None,
            platform=platform.system(),
            python=platform.python_version(),
        )
    required_api = (
        "apswversion",
        "sqlitelibversion",
        "sqlite3_sourceid",
        "vfsnames",
        "Connection",
    )
    if any(not callable(getattr(apsw, name, None)) for name in required_api):
        return SQLiteRuntimeQualification(
            ok=False,
            driver="apsw",
            sqlite_version=None,
            reason="apsw_api_unavailable",
            using_amalgamation=None,
            platform=platform.system(),
            python=platform.python_version(),
        )
    actual = str(apsw.apswversion())
    sqlite_version = str(apsw.sqlitelibversion())
    amalgamation = bool(getattr(apsw, "using_amalgamation", False))
    source_id = str(apsw.sqlite3_sourceid())
    compile_options = tuple(sorted(str(item) for item in apsw.compile_options))
    vfs = tuple(sorted(str(item) for item in apsw.vfsnames()))
    required_options = {str(item) for item in policy["driver"].get("required_compile_options", [])}
    forbidden_prefixes = tuple(
        str(item) for item in policy["driver"].get("forbidden_compile_option_prefixes", [])
    )
    supported_python = {str(item) for item in policy["nextgen_v1"].get("supported_python", [])}
    allowed_vfs = _platform_vfs(policy, platform.system())
    reason: str | None
    if actual != expected:
        reason = f"apsw_version_mismatch:{actual}"
    elif sqlite_version != expected_sqlite:
        reason = f"sqlite_version_mismatch:{sqlite_version}"
    elif not amalgamation:
        reason = "apsw_not_using_amalgamation"
    elif expected_source and source_id != expected_source:
        reason = "sqlite_source_id_mismatch"
    elif required_options - set(compile_options):
        reason = "sqlite_compile_options_missing"
    elif any(
        option == prefix or option.startswith(prefix + "=")
        for option in compile_options
        for prefix in forbidden_prefixes
    ):
        reason = "sqlite_compile_options_forbidden"
    elif allowed_vfs and not (set(vfs) & allowed_vfs):
        reason = "sqlite_vfs_unsupported"
    elif f"{sys.version_info.major}.{sys.version_info.minor}" not in supported_python:
        reason = "unsupported_python"
    else:
        reason = _behavior_probe(apsw)
    return SQLiteRuntimeQualification(
        ok=reason is None,
        driver="apsw",
        sqlite_version=sqlite_version,
        reason=reason,
        using_amalgamation=amalgamation,
        platform=platform.system(),
        python=platform.python_version(),
        source_id=source_id,
        compile_options=compile_options,
        vfs=vfs,
    )


def require_qualified_nextgen_runtime() -> SQLiteRuntimeQualification:
    qualification = qualify_nextgen_runtime()
    if not qualification.ok:
        raise SQLiteRuntimeUnsupported("sqlite_runtime_unsupported: " + str(qualification.reason))
    return qualification


def _platform_vfs(policy: Mapping[str, Any], system: str) -> set[str]:
    raw = policy.get("nextgen_v1", {}).get("allowed_vfs", {})
    if not isinstance(raw, Mapping):
        return set()
    value = raw.get(system, [])
    return {str(item) for item in value} if isinstance(value, list) else set()


def _behavior_probe(apsw: Any) -> str | None:
    """Exercise the minimum locked SQLite feature surface before store creation."""

    try:
        connection = apsw.Connection(":memory:")
        try:
            if tuple(connection.execute("SELECT json_valid('[]')").fetchone()) != (1,):
                return "sqlite_json_probe_failed"
            connection.execute("CREATE TEMP TABLE runtime_strict_probe(value INTEGER) STRICT")
            connection.execute("INSERT INTO runtime_strict_probe VALUES(1)")
            connection.config(apsw.SQLITE_DBCONFIG_DEFENSIVE, 1)
            connection.config(apsw.SQLITE_DBCONFIG_TRUSTED_SCHEMA, 0)
        finally:
            connection.close()
    except Exception as exc:  # noqa: BLE001 - convert native driver errors to a typed gate.
        return f"sqlite_behavior_probe_failed:{type(exc).__name__}"
    return None
