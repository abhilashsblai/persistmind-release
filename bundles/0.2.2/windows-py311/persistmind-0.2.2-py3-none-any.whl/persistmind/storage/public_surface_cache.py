from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping
from pathlib import Path

from persistmind.agent_runtime.cache import (
    RuntimeCache,
    build_cache_key,
    cache_scope,
    cache_scope_matches,
)
from persistmind.application.public_surface import SourceRecordProvider, derive_public_surface_files

PUBLIC_SURFACE_CACHE_ALGORITHM = "persistmind.public_surface.v1"


def derive_cached_public_surface_files(
    repo_root: Path,
    runtime_root: Path,
    cache: RuntimeCache,
    *,
    paths: Iterable[str],
    source_generation: str | None,
    known_paths: Iterable[str] = (),
    source_records: SourceRecordProvider | None = None,
    current_generation: Callable[[], str | None] | None = None,
) -> set[str]:
    normalized = sorted({str(path).replace("\\", "/") for path in paths if str(path).strip()})
    generation_id = str(source_generation or "unpublished")
    key = build_cache_key(
        repo_root,
        runtime_root,
        source_generation=generation_id,
        request={"paths": normalized},
        limits={},
        algorithm_version=PUBLIC_SURFACE_CACHE_ALGORITHM,
    )
    cached = cache.get(
        "public_surface",
        key,
        authorize=lambda value: (
            cache_scope_matches(value, key)
            and (
                current_generation is None
                or str(current_generation() or "unpublished") == generation_id
            )
        ),
    )
    if cached is not None:
        result = cached.get("result")
        if isinstance(result, Mapping) and isinstance(result.get("paths"), list):
            return {str(path) for path in result["paths"]}
    surfaces = derive_public_surface_files(
        normalized,
        repo_root=repo_root,
        known_paths=known_paths,
        source_records=source_records,
    )
    if not cache.read_only:
        cache.put(
            "public_surface",
            key,
            {"scope": cache_scope(key), "result": {"paths": sorted(surfaces)}},
        )
    return surfaces


__all__ = ["PUBLIC_SURFACE_CACHE_ALGORITHM", "derive_cached_public_surface_files"]
