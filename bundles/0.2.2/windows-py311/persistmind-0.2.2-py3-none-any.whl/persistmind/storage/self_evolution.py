from __future__ import annotations

import hashlib
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from persistmind.selfimprove.brief import build_improvement_brief
from persistmind.selfimprove.evaluate import evaluate_proposal
from persistmind.selfimprove.overseer import inspect_proposal
from persistmind.selfimprove.proposals import capability_verdict
from persistmind.utils import canonical_json, stable_id, utc_now


_PROTECTED_TARGET_GLOBS = (
    "persistmind.toml",
    "persistmind.capabilities.yaml",
    ".persistmind/**",
    "src/persistmind/application/**",
    "src/persistmind/architecture/**",
    "src/persistmind/composition/**",
    "src/persistmind/release/**",
    "src/persistmind/security/**",
    "src/persistmind/selfimprove/**",
    "src/persistmind/storage/**",
    "plans/existing-functionality-completion-plan.md",
)


class LearningSelfEvolution:
    """Bounded self-evolution behavior hosted by the Learning authority.

    Candidate artifacts and observations are immutable. State changes are separate
    transition records, and adoption only acknowledges a version that the normal
    field-experiment/Policy promotion path has already activated.
    """

    def __init__(self, service: Any) -> None:
        self.service = service
        self.repo_root = service.repo_root
        self.config = service.settings.learning.self_improve

    def status(self) -> dict[str, Any]:
        candidates = self._candidates()
        cycles = self.service._feature_records("self_evolution_cycle")
        return {
            "ok": True,
            "status": "experimental_gated",
            "schema_version": "persistmind.self_improve_status.v2",
            "availability": "deferred_until_f4",
            "autonomy": "A2_proposal_only",
            "candidate_counts": _counts(self._state(item["record_id"]) for item in candidates),
            "cycle_counts": _counts(str(item.get("status") or "unknown") for item in cycles),
            "trusted_computing_base": self._trusted_computing_base(),
            "activation_rule": "Learning field promotion plus signed Policy decision",
        }

    def audit(self, *, force: bool = False, actor: str = "learning-observer") -> dict[str, Any]:
        today = utc_now()[:10]
        prior = [
            item
            for item in self.service._feature_records("self_evolution_audit")
            if item.get("run_day") == today
        ]
        if prior and not force:
            return {"ok": True, "ran": False, "audit": prior[-1]}
        opportunities = self._observed_opportunities()
        control = self._kill_switch_status()
        audit = {
            "schema_version": "persistmind.self_improve_audit.v2",
            "run_day": today,
            "snapshot_id": self._repository_snapshot(),
            "actor": actor,
            "signals": {
                "doctor": {
                    "ok": not bool(control.get("active")),
                    "status": control.get("status", "unknown"),
                    "ready_for_work": not bool(control.get("active")),
                    "setup_status": "authority_initialized",
                },
                "failure_hypotheses": [
                    item for item in opportunities if item["origin_type"] == "observed_failure"
                ],
                "unused_opportunities": [
                    item for item in opportunities if item["origin_type"] == "unused_opportunity"
                ],
                "candidate_count": len(self._candidates()),
            },
            "regressions": [],
            "trusted_computing_base": self._trusted_computing_base(),
            "observed_at": utc_now(),
        }
        stored = self.service._feature_create("self_evolution_audit", audit)
        return {"ok": True, "ran": True, "audit": stored}

    def brief(self) -> dict[str, Any]:
        audits = self.service._feature_records("self_evolution_audit")
        if not audits:
            return {
                "ok": False,
                "status": "source_not_ready",
                "schema_version": "persistmind.self_improve_brief.v2",
                "reason": "self_improve_audit_required",
            }
        audit = audits[-1]
        brief = build_improvement_brief(audit, top_n=int(self.config.brief_top_n))
        return {
            "ok": True,
            "status": "advisory",
            "schema_version": "persistmind.self_improve_brief.v2",
            "audit_id": audit["record_id"],
            "brief": brief,
        }

    def capture(
        self,
        *,
        title: str,
        rationale: str,
        target_files: Sequence[str],
        evidence: Mapping[str, Any] | None = None,
        predicted_effect: Mapping[str, Any] | None = None,
        parent_id: str | None = None,
        proposer_identity: str = "local-user",
    ) -> dict[str, Any]:
        title = title.strip()
        rationale = rationale.strip()
        paths = sorted({str(item).replace("\\", "/").strip() for item in target_files if item})
        if not title or not rationale or not paths:
            raise ValueError("self-improvement capture requires title, rationale, and target files")
        if len(paths) > 20:
            raise ValueError("self-improvement candidate exceeds the 20-path ceiling")
        evidence_value = dict(evidence or {})
        effect = dict(predicted_effect or {})
        if str(effect.get("transitive_effect") or "low").lower() != "low":
            raise PermissionError("A4 candidates are limited to low transitive effects")
        diff = str(evidence_value.get("diff") or "")
        if len(diff.encode("utf-8")) > 1_000_000:
            raise ValueError("self-improvement candidate exceeds the one-megabyte artifact ceiling")
        if parent_id:
            self._proposal(parent_id)
        probe = {
            "target_files": paths,
            "evidence": {"diff": diff},
        }
        overseer = inspect_proposal(probe, protected_globs=list(self._protected_globs()))
        capability = capability_verdict(self.repo_root, self.service.settings, paths)
        origin_type = str(evidence_value.get("origin_type") or "human_hypothesis")
        source_ref = str(evidence_value.get("source_ref") or "")
        artifact_payload = (
            diff.encode("utf-8")
            if diff.strip()
            else canonical_json(
                {
                    "title": title,
                    "rationale": rationale,
                    "target_files": paths,
                    "evidence": evidence_value,
                    "predicted_effect": effect,
                }
            ).encode("utf-8")
        )
        artifact_ref = self.service.runtime.artifacts.put(
            artifact_payload, classification="internal"
        )
        skill_id = "self-evolution:" + stable_id(*paths)[:24]
        version = self.service.version_propose(
            skill_id=skill_id,
            benchmark_id="self-evolution-f4.v1",
            artifact_ref=artifact_ref,
        )["version"]
        blocked = capability["verdict"] == "block" or not overseer["ok"]
        proposal = self.service._feature_create(
            "self_evolution_candidate",
            {
                "title": title,
                "rationale": rationale,
                "target_files": paths,
                "evidence": {key: value for key, value in evidence_value.items() if key != "diff"},
                "predicted_effect": {**effect, "transitive_effect": "low"},
                "origin_type": origin_type,
                "source_ref": source_ref,
                "parent_id": parent_id,
                "proposer_identity": proposer_identity,
                "artifact_ref": artifact_ref,
                "artifact_kind": "unified_diff" if diff.strip() else "declarative_candidate",
                "version_id": version["version_id"],
                "protected_surface_hash": self._trusted_computing_base()["content_hash"],
                "capability": capability,
                "overseer": overseer,
                "status": "human_review_required" if blocked else "captured",
                "activation_risk_floor": "medium",
                "autonomy_ceiling": "A2",
            },
        )
        return {
            "ok": not blocked,
            "status": proposal["status"],
            "schema_version": "persistmind.self_improve_proposal.v2",
            "proposal": self._decorate(proposal),
        }

    def evaluate(
        self,
        proposal_id: str,
        *,
        evaluator_identity: str,
        evaluator_version: str | None = None,
        commands: Sequence[str] | None = None,
    ) -> dict[str, Any]:
        proposal = self._proposal(proposal_id)
        if not evaluator_identity.strip():
            raise ValueError("self-improvement evaluation requires an evaluator identity")
        if evaluator_identity == proposal.get("proposer_identity"):
            raise PermissionError("proposer and evaluator identities must be independent")
        tcb = self._trusted_computing_base()
        if proposal.get("protected_surface_hash") != tcb["content_hash"]:
            raise PermissionError("trusted computing base changed after candidate capture")
        selected = list(self.config.validation_commands)
        if commands is not None and list(commands) != selected:
            raise PermissionError("a candidate cannot replace the fixed evaluation protocol")
        if proposal.get("artifact_kind") != "unified_diff":
            result = {
                "ok": False,
                "status": "needs_patch",
                "reason": "candidate_diff_required",
                "attempts": [],
            }
        elif proposal.get("status") == "human_review_required":
            result = {
                "ok": False,
                "status": "blocked",
                "reason": "protected_or_disallowed_surface",
                "attempts": [],
            }
        else:
            diff = self.service.runtime.artifacts.get(str(proposal["artifact_ref"])).decode("utf-8")
            result = evaluate_proposal(
                self.repo_root,
                {**proposal, "evidence": {"diff": diff}},
                commands=selected,
                timeout=int(self.config.validation_timeout_seconds),
            )
        evaluation = self.service._feature_create(
            "self_evolution_evaluation",
            {
                "proposal_id": proposal_id,
                "version_id": proposal["version_id"],
                "evaluator_identity": evaluator_identity,
                "evaluator_version": evaluator_version or tcb["content_hash"],
                "protocol_hash": _hash_document(
                    {
                        "commands": selected,
                        "timeout": int(self.config.validation_timeout_seconds),
                    }
                ),
                "protected_surface_hash": tcb["content_hash"],
                "result": result,
                "status": "passed" if result.get("ok") else str(result.get("status")),
            },
        )
        self.service.evaluation_record(
            str(proposal["version_id"]),
            metrics={
                "sandbox_pass": 1.0 if result.get("ok") else 0.0,
                "protected_surface_pass": 1.0 if proposal.get("overseer", {}).get("ok") else 0.0,
            },
            passed=bool(result.get("ok")),
        )
        self._transition(
            proposal_id,
            "evaluated" if result.get("ok") else "evaluation_failed",
            actor=evaluator_identity,
            reason=str(result.get("reason") or result.get("status") or "evaluated"),
            evidence_ref=evaluation["record_id"],
        )
        return {
            "ok": bool(result.get("ok")),
            "status": evaluation["status"],
            "schema_version": "persistmind.self_improve_evaluation.v2",
            "proposal": self.show(proposal_id)["proposal"],
            "evaluation": evaluation,
        }

    def adopt(
        self, proposal_id: str, *, actor: str = "learning-activation-observer"
    ) -> dict[str, Any]:
        proposal = self._proposal(proposal_id)
        promotion = self._promotion(str(proposal["version_id"]))
        if promotion is None or promotion.get("state") != "active":
            raise PermissionError(
                "self-improvement adoption requires prior Learning field promotion"
            )
        active = self.service.store.active_manifest()
        version = self.service._version_or_raise(str(proposal["version_id"]))
        if active.get(str(version["skill_id"])) != proposal["version_id"]:
            raise PermissionError("candidate is not the exact active Learning version")
        policy = self.service.policy.policy(str(promotion["policy_decision_id"]))
        if policy is None or str(policy.get("status")) != "active":
            raise PermissionError("self-improvement adoption lacks an active Policy decision")
        expected_policy_hash = _hash_document(dict(policy))
        if expected_policy_hash != promotion["policy_decision_hash"]:
            raise PermissionError("self-improvement Policy decision hash differs")
        tcb_hash = self._trusted_computing_base()["content_hash"]
        if (
            str(policy.get("protected_surface_hash")) != tcb_hash
            or str(proposal.get("protected_surface_hash")) != tcb_hash
        ):
            raise PermissionError("signed trusted computing base does not match activation")
        transition = self._transition(
            proposal_id,
            "adopted",
            actor=actor,
            reason="observed signed Learning promotion",
            evidence_ref=str(promotion["decision_id"]),
        )
        return {
            "ok": True,
            "status": "adopted",
            "schema_version": "persistmind.self_improve_adoption.v2",
            "proposal": self.show(proposal_id)["proposal"],
            "transition": transition,
            "manifest_mutated_by": "learning_promote",
        }

    def reject(self, proposal_id: str, *, reason: str, actor: str = "local-user") -> dict[str, Any]:
        if not reason.strip():
            raise ValueError("self-improvement rejection requires a reason")
        transition = self._transition(
            proposal_id, "rejected", actor=actor, reason=reason, evidence_ref=None
        )
        return {
            "ok": True,
            "status": "rejected",
            "schema_version": "persistmind.self_improve_rejection.v2",
            "proposal": self.show(proposal_id)["proposal"],
            "transition": transition,
        }

    def rollback(
        self, proposal_id: str, *, reason: str, actor: str = "local-user"
    ) -> dict[str, Any]:
        if not reason.strip():
            raise ValueError("self-improvement rollback acknowledgement requires a reason")
        proposal = self._proposal(proposal_id)
        promotion = self._promotion(str(proposal["version_id"]))
        if promotion is None or promotion.get("state") != "rolled_back":
            raise PermissionError(
                "run learning_rollback before acknowledging self-evolution rollback"
            )
        rollback_version = str(promotion.get("rollback_version_id") or "")
        target = self.service._version_or_raise(rollback_version)
        active = self.service.store.active_manifest()
        if active.get(str(target["skill_id"])) != rollback_version:
            raise PermissionError("exact rollback version is not active")
        transition = self._transition(
            proposal_id,
            "rolled_back",
            actor=actor,
            reason=reason,
            evidence_ref=str(promotion["decision_id"]),
        )
        return {
            "ok": True,
            "status": "rolled_back",
            "schema_version": "persistmind.self_improve_rollback.v2",
            "rollback_version": rollback_version,
            "proposal": self.show(proposal_id)["proposal"],
            "transition": transition,
        }

    def archive(
        self, *, run_id: str | None = None, status: str | None = None, limit: int = 50
    ) -> dict[str, Any]:
        del run_id
        candidates = [self._decorate(item) for item in self._candidates()]
        if status:
            candidates = [item for item in candidates if item["state"] == status]
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.self_improve_archive.v2",
            "proposals": candidates[-max(1, min(int(limit), 1000)) :],
        }

    def show(self, proposal_id: str) -> dict[str, Any]:
        proposal = self._proposal(proposal_id)
        evaluations = [
            item
            for item in self.service._feature_records("self_evolution_evaluation")
            if item.get("proposal_id") == proposal_id
        ]
        return {
            "ok": True,
            "status": self._state(proposal_id),
            "schema_version": "persistmind.self_improve_show.v2",
            "proposal": {
                **self._decorate(proposal),
                "evaluations": evaluations,
                "transitions": self._transitions(proposal_id),
            },
        }

    def lineage(self, *, proposal_id: str | None = None, limit: int = 100) -> dict[str, Any]:
        candidates = self._candidates()
        if proposal_id:
            self._proposal(proposal_id)
            candidates = [
                item
                for item in candidates
                if item["record_id"] == proposal_id or item.get("parent_id") == proposal_id
            ]
        rows = []
        for item in candidates[-max(1, min(int(limit), 1000)) :]:
            children = [
                value for value in self._candidates() if value.get("parent_id") == item["record_id"]
            ]
            passed = sum(self._state(value["record_id"]) == "adopted" for value in children)
            rows.append(
                {
                    "proposal_id": item["record_id"],
                    "parent_id": item.get("parent_id"),
                    "descendants": len(children),
                    "productive_descendants": passed,
                    "clade_productivity": passed / len(children) if children else 0.0,
                    "state": self._state(item["record_id"]),
                }
            )
        return {
            "ok": True,
            "status": "measured",
            "schema_version": "persistmind.self_improve_lineage.v2",
            "lineage": rows,
        }

    def run(
        self,
        *,
        auto: bool = False,
        max_iters: int | None = None,
        budget_tokens: int | None = None,
        actor: str = "learning-observer",
    ) -> dict[str, Any]:
        iterations = int(max_iters or self.config.max_iters)
        budget = int(budget_tokens or self.config.budget_tokens)
        if iterations < 1 or iterations > int(self.config.max_iters):
            raise ValueError("self-evolution run exceeds the configured iteration ceiling")
        if budget < 1 or budget > int(self.config.budget_tokens):
            raise ValueError("self-evolution run exceeds the configured token ceiling")
        audit_result = self.audit(force=True, actor=actor)
        audit = audit_result["audit"]
        opportunities = [
            *audit["signals"]["failure_hypotheses"],
            *audit["signals"]["unused_opportunities"],
        ]
        cycle = self.service._feature_create(
            "self_evolution_cycle",
            {
                "audit_id": audit["record_id"],
                "opportunity_refs": [item["source_ref"] for item in opportunities[:iterations]],
                "requested_auto": bool(auto),
                "execution_mode": "proposal_only",
                "budget_tokens": budget,
                "iteration_ceiling": iterations,
                "evaluator_version": self._trusted_computing_base()["content_hash"],
                "status": "observed" if opportunities else "stable_no_candidate",
            },
        )
        return {
            "ok": True,
            "status": cycle["status"],
            "schema_version": "persistmind.self_improve_cycle.v2",
            "cycle": cycle,
            "opportunities": opportunities[:iterations],
            "generated_candidates": [],
            "stable_cycle": not opportunities,
            "reason": (
                "observed hypotheses require an immutable candidate artifact"
                if opportunities
                else "no safe beneficial candidate"
            ),
        }

    def doctor(self) -> dict[str, Any]:
        control = self._kill_switch_status()
        return {
            "ok": not bool(control.get("active")),
            "status": "ready" if not control.get("active") else "unsafe",
            "schema_version": "persistmind.self_improve_doctor.v2",
            "availability": "experimental_gated",
            "kill_switch": control,
            "trusted_computing_base": self._trusted_computing_base(),
            "limits": {
                "max_iters": int(self.config.max_iters),
                "budget_tokens": int(self.config.budget_tokens),
                "transitive_effect": "low",
                "activation_risk_floor": "medium",
            },
        }

    def verify_safety(self, *, policy_decision_id: str | None = None) -> dict[str, Any]:
        tcb = self._trusted_computing_base()
        control = self._kill_switch_status()
        policy: Mapping[str, Any] | None = None
        if policy_decision_id:
            policy = self.service.policy.policy(policy_decision_id)
        policy_ok = bool(
            policy
            and policy.get("status") == "active"
            and policy.get("protected_surface_hash") == tcb["content_hash"]
        )
        checks = {
            "kill_switch_clear": not bool(control.get("active")),
            "trusted_computing_base_hashed": bool(tcb["files"]),
            "signed_policy_matches": policy_ok,
            "independent_roles_required": True,
            "candidate_effect_ceiling": "low",
            "activation_floor": "medium",
        }
        return {
            "ok": all(value is True for value in checks.values() if isinstance(value, bool)),
            "status": "verified" if policy_ok and not control.get("active") else "not_authorized",
            "schema_version": "persistmind.self_improve_verify_safety.v2",
            "checks": checks,
            "trusted_computing_base": tcb,
            "policy_decision_id": policy_decision_id,
        }

    def optimize(
        self,
        target: str = "learning",
        *,
        iterations: int = 1,
        limit: int = 20,
        holdout_ratio: float = 0.3,
        adopt: bool = False,
    ) -> dict[str, Any]:
        del limit, holdout_ratio
        if adopt:
            raise PermissionError("optimization cannot activate its own candidates")
        result = self.run(max_iters=iterations)
        return {
            **result,
            "schema_version": "persistmind.learning_optimize.v2",
            "target": target,
            "adoption": "requires_independent_field_and_policy_path",
        }

    def selfmod_propose(
        self, target: str, *, weakness: str = "", ancestor_run_id: str | None = None
    ) -> dict[str, Any]:
        return self.capture(
            title=f"Candidate improvement for {target}",
            rationale=weakness or "Observed improvement opportunity",
            target_files=[target],
            evidence={
                "origin_type": "observed_failure" if weakness else "unused_opportunity",
                "source_ref": ancestor_run_id or "legacy-selfmod-proposal",
            },
            parent_id=ancestor_run_id if self._candidate_exists(ancestor_run_id) else None,
        )

    def selfmod_adopt(self, proposal_id: str, *, approved_by: str = "local-user") -> dict[str, Any]:
        return self.adopt(proposal_id, actor=approved_by)

    def selfmod_revert(
        self, proposal_id: str, *, reason: str = "governed rollback"
    ) -> dict[str, Any]:
        return self.rollback(proposal_id, reason=reason)

    def _proposal(self, proposal_id: str) -> dict[str, Any]:
        value = self.service.store.get(proposal_id)
        if value is None or value.get("kind") != "self_evolution_candidate":
            raise KeyError(f"self-improvement proposal not found: {proposal_id}")
        return dict(value)

    def _candidate_exists(self, proposal_id: str | None) -> bool:
        if not proposal_id:
            return False
        value = self.service.store.get(proposal_id)
        return bool(value and value.get("kind") == "self_evolution_candidate")

    def _candidates(self) -> list[dict[str, Any]]:
        return self.service._feature_records("self_evolution_candidate")

    def _decorate(self, proposal: Mapping[str, Any]) -> dict[str, Any]:
        return {**dict(proposal), "state": self._state(str(proposal["record_id"]))}

    def _state(self, proposal_id: str) -> str:
        transitions = self._transitions(proposal_id)
        if transitions:
            return str(transitions[-1]["to_state"])
        return str(self._proposal(proposal_id).get("status") or "captured")

    def _transitions(self, proposal_id: str) -> list[dict[str, Any]]:
        return [
            item
            for item in self.service._feature_records("self_evolution_transition")
            if item.get("proposal_id") == proposal_id
        ]

    def _transition(
        self,
        proposal_id: str,
        to_state: str,
        *,
        actor: str,
        reason: str,
        evidence_ref: str | None,
    ) -> dict[str, Any]:
        self._proposal(proposal_id)
        return self.service._feature_create(
            "self_evolution_transition",
            {
                "proposal_id": proposal_id,
                "from_state": self._state(proposal_id),
                "to_state": to_state,
                "actor": actor,
                "reason": reason,
                "evidence_ref": evidence_ref,
                "status": to_state,
            },
        )

    def _promotion(self, version_id: str) -> dict[str, Any] | None:
        row = (
            self.service.store._reader()
            .execute(
                "SELECT * FROM learning_promotion_decisions WHERE version_id=? "
                "ORDER BY created_at DESC,decision_id DESC LIMIT 1",
                (version_id,),
            )
            .fetchone()
        )
        return dict(row) if row is not None else None

    def _observed_opportunities(self) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for version in self.service.store.versions(limit=1000):
            failed = [
                item
                for item in self.service.store.evaluations(str(version["version_id"]))
                if not item.get("passed")
            ]
            for item in failed:
                rows.append(
                    {
                        "origin_type": "observed_failure",
                        "source_ref": str(item["evaluation_id"]),
                        "hypothesis": "Improve the failed " + str(item["split"]) + " stratum.",
                        "version_id": str(version["version_id"]),
                    }
                )
        for lesson in self.service._feature_records("learning_lesson", status="accepted"):
            if not any(
                item.get("source_ref") == lesson["record_id"] for item in self._candidates()
            ):
                rows.append(
                    {
                        "origin_type": "unused_opportunity",
                        "source_ref": str(lesson["record_id"]),
                        "hypothesis": str(lesson.get("assertion") or "Apply accepted lesson"),
                    }
                )
        rows.sort(key=lambda item: (item["origin_type"], item["source_ref"]))
        return rows

    def _protected_globs(self) -> tuple[str, ...]:
        return tuple(sorted(set(_PROTECTED_TARGET_GLOBS) | set(self.config.protected_path_globs)))

    def _trusted_computing_base(self) -> dict[str, Any]:
        package_root = Path(__file__).resolve().parents[1]
        protected_roots = {
            "application",
            "architecture",
            "composition",
            "release",
            "security",
            "selfimprove",
            "storage",
        }
        files: list[dict[str, str]] = []
        for path in sorted(package_root.rglob("*")):
            if not path.is_file() or "__pycache__" in path.parts:
                continue
            relative = path.relative_to(package_root).as_posix()
            if relative == "config.py" or relative.split("/", 1)[0] in protected_roots:
                if path.suffix.lower() not in {".py", ".json", ".sql", ".toml", ".yaml", ".yml"}:
                    continue
                files.append(
                    {
                        "path": "package:persistmind/" + relative,
                        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                    }
                )
        for relative in ("persistmind.toml", "persistmind.capabilities.yaml"):
            path = self.repo_root / relative
            if path.is_file():
                files.append(
                    {
                        "path": "workspace:" + relative,
                        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                    }
                )
        files.sort(key=lambda item: item["path"])
        return {
            "schema_version": "persistmind.self_evolution_tcb.v1",
            "content_hash": _hash_document(files),
            "files": len(files),
            "protected_target_globs": list(self._protected_globs()),
        }

    def _repository_snapshot(self) -> str:
        values: list[str] = []
        for path in sorted(self.repo_root.rglob("*")):
            if path.is_file() and ".git" not in path.parts and ".persistmind" not in path.parts:
                try:
                    stat = path.stat()
                except OSError:
                    continue
                values.append(
                    f"{path.relative_to(self.repo_root).as_posix()}:{stat.st_size}:{stat.st_mtime_ns}"
                )
                if len(values) >= 10_000:
                    break
        return _hash_document(values)

    def _kill_switch_status(self) -> dict[str, Any]:
        from .control import StorageControlPlane

        return StorageControlPlane(self.repo_root).kill_switch_status()


def _hash_document(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def _counts(values: Sequence[str] | Any) -> dict[str, int]:
    result: dict[str, int] = {}
    for value in values:
        result[str(value)] = result.get(str(value), 0) + 1
    return dict(sorted(result.items()))
