from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any, Mapping, Sequence, cast

from ..descriptors import StorageDomain, StoreDescriptor, StoreRole
from .apsw_driver import open_nextgen_connection
from .sqlite_base import APPLICATION_IDS, SQLiteDomainStore, _now


class SQLiteActivityStore(SQLiteDomainStore):
    """Append-only current Activity partition with explicit physical sealing."""

    def __init__(
        self,
        path: Path,
        *,
        descriptor: StoreDescriptor | None = None,
        role: StoreRole = StoreRole.ACTIVITY_ACTIVE,
        store_id: str | None = None,
        allow_development_driver: bool = False,
    ) -> None:
        if role not in {StoreRole.ACTIVITY_ACTIVE, StoreRole.ACTIVITY_SEALED}:
            raise ValueError(f"invalid activity role: {role.value}")
        super().__init__(
            path,
            StorageDomain.ACTIVITY,
            role,
            resource="schemas/activity/v1.sql",
            extra_resources=("schemas/reporting/activity.v1.sql",),
            store_id=(
                store_id or "activity-current" if role is StoreRole.ACTIVITY_ACTIVE else store_id
            ),
            descriptor=descriptor,
            allow_development_driver=allow_development_driver,
        )

    def append(self, event: Mapping[str, Any], *, idempotency_key: str) -> str:
        if self.role is not StoreRole.ACTIVITY_ACTIVE:
            raise PermissionError("sealed activity partition is read-only")
        event_id = str(event["event_id"])
        normalized = _redact(dict(event))
        payload = json.dumps(normalized, sort_keys=True, separators=(",", ":"))
        if len(payload.encode()) > 65_536:
            raise ValueError("activity event exceeds 64 KiB inline payload limit")
        occurred_at = str(normalized.get("occurred_at") or _now())
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT event_id,payload_json FROM activity_events WHERE idempotency_key=?",
                (idempotency_key,),
            ).fetchone()
            if existing is not None:
                existing_payload = json.loads(str(existing["payload_json"]))
                requested_payload = json.loads(payload)
                if isinstance(existing_payload, dict):
                    existing_payload.pop("occurred_at", None)
                if isinstance(requested_payload, dict):
                    requested_payload.pop("occurred_at", None)
                if existing_payload != requested_payload:
                    raise ValueError("activity idempotency key payload divergence")
                return str(existing["event_id"])
            self.connection.execute(
                "INSERT INTO activity_events("
                "event_id,event_type,payload_json,idempotency_key,occurred_at,committed_at) "
                "VALUES(?,?,?,?,?,?)",
                (
                    event_id,
                    str(normalized.get("event_type", "event")),
                    payload,
                    idempotency_key,
                    occurred_at,
                    _now(),
                ),
            )
            changes_row = self.connection.execute("SELECT changes()").fetchone()
            if changes_row is not None and int(cast(Sequence[Any], changes_row)[0]) != 0:
                self.connection.execute(
                    "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
                )
        return event_id

    def event(self, event_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute("SELECT * FROM activity_events WHERE event_id=?", (event_id,))
            .fetchone()
        )
        return _activity_row(cast(Mapping[str, Any], row)) if row else None

    def events(
        self,
        *,
        event_type: str | None = None,
        since: str | None = None,
        limit: int = 100,
    ) -> list[Mapping[str, Any]]:
        clauses: list[str] = []
        values: list[Any] = []
        if event_type:
            clauses.append("event_type=?")
            values.append(event_type)
        if since:
            clauses.append("committed_at>=?")
            values.append(since)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        values.append(max(1, min(int(limit), 1000)))
        rows = (
            self._reader()
            .execute(
                "SELECT * FROM activity_events"
                + where
                + " ORDER BY committed_at DESC,event_id DESC LIMIT ?",
                tuple(values),
            )
            .fetchall()
        )
        return [_activity_row(cast(Mapping[str, Any], row)) for row in rows]

    def seal_partition(
        self, sealed_path: Path | None = None, *, sealed_store_id: str | None = None
    ) -> Mapping[str, Any]:
        """Close a WAL-free immutable image when a destination is supplied.

        A no-destination call remains a non-destructive proof for backwards
        compatibility; production rotation always provides a catalog-selected
        sealed path and publishes the result only after this returns.
        """

        if sealed_path is not None:
            self._close_readers()
        with self._write_lock:
            rows = self.connection.execute(
                "SELECT event_id,payload_json,committed_at FROM activity_events "
                "ORDER BY committed_at,event_id"
            ).fetchall()
        digest = hashlib.sha256(b"CTX-LOGICAL-v1\0activity")
        for row in rows:
            for value in (row["event_id"], row["payload_json"]):
                encoded = str(value).encode("utf-8")
                digest.update(len(encoded).to_bytes(4, "big"))
                digest.update(encoded)
        content_hash = digest.hexdigest()
        partition_id = f"activity-{content_hash[:24]}"
        minimum = str(rows[0]["committed_at"]) if rows else ""
        maximum = str(rows[-1]["committed_at"]) if rows else ""
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT OR REPLACE INTO activity_partitions VALUES(?,?,?,?,?,?,?)",
                (
                    partition_id,
                    "sealed" if sealed_path else "ready_to_seal",
                    minimum,
                    maximum,
                    len(rows),
                    content_hash,
                    _now(),
                ),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        if sealed_path is not None:
            with self._write_lock:
                self.connection.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        result: dict[str, Any] = {
            "sealed": sealed_path is not None,
            "partition_id": partition_id,
            "events": len(rows),
            "min_committed_at": minimum,
            "max_committed_at": maximum,
            "logical_content_hash": content_hash,
            "anchor_required": False,
        }
        if sealed_path is not None:
            sealed_path.parent.mkdir(parents=True, exist_ok=True)
            temporary = sealed_path.with_name(f".{sealed_path.name}.{os.getpid()}.tmp")
            self._copy_wal_free_image(temporary)
            _finalize_sealed_image(
                temporary,
                sealed_path,
                role=StoreRole.ACTIVITY_SEALED,
                logical_hash=content_hash,
                store_id=sealed_store_id or partition_id,
                allow_development_driver=self._allow_development_driver,
            )
            result["location"] = str(sealed_path)
            result["physical_image_hash"] = _file_hash(sealed_path)
        return result

    def _copy_wal_free_image(self, target: Path) -> None:
        with self._write_lock:
            self.copy_image_to(target)
        # backup() creates a standalone snapshot; ensure no accidental sidecars survive.
        Path(f"{target}-wal").unlink(missing_ok=True)
        Path(f"{target}-shm").unlink(missing_ok=True)


class SQLiteAuditStore(SQLiteDomainStore):
    """Independent hash-chain Audit role; telemetry cannot write it accidentally."""

    def __init__(
        self,
        path: Path,
        *,
        descriptor: StoreDescriptor | None = None,
        role: StoreRole = StoreRole.AUDIT_ACTIVE,
        store_id: str | None = None,
        allow_development_driver: bool = False,
    ) -> None:
        if role not in {StoreRole.AUDIT_ACTIVE, StoreRole.AUDIT_SEALED}:
            raise ValueError(f"invalid audit role: {role.value}")
        super().__init__(
            path,
            StorageDomain.AUDIT,
            role,
            resource="schemas/audit/v1.sql",
            store_id=(store_id or "audit-current" if role is StoreRole.AUDIT_ACTIVE else store_id),
            descriptor=descriptor,
            allow_development_driver=allow_development_driver,
        )

    def append_audit(self, record: Mapping[str, Any], *, idempotency_key: str) -> str:
        if self.role is not StoreRole.AUDIT_ACTIVE:
            raise PermissionError("sealed audit partition is read-only")
        audit_id = str(record["audit_id"])
        payload = json.dumps(_redact(dict(record)), sort_keys=True, separators=(",", ":"))
        if len(payload.encode()) > 65_536:
            raise ValueError("audit record exceeds 64 KiB inline payload limit")
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT audit_id FROM audit_records WHERE idempotency_key=?",
                (idempotency_key,),
            ).fetchone()
            if existing:
                return str(existing[0])
            previous = self.connection.execute(
                "SELECT event_hash FROM audit_records ORDER BY sequence DESC LIMIT 1"
            ).fetchone()
            previous_hash = str(previous[0]) if previous else "0" * 64
            event_hash = hashlib.sha256(f"{previous_hash}\0{payload}".encode("utf-8")).hexdigest()
            sequence_row = self.connection.execute(
                "SELECT COALESCE(MAX(sequence),0)+1 FROM audit_records"
            ).fetchone()
            sequence = int(cast(Sequence[Any], sequence_row)[0]) if sequence_row else 1
            self.connection.execute(
                "INSERT INTO audit_records("
                "audit_id,partition_id,sequence,event_hash,prev_hash,principal,payload_json,"
                "idempotency_key,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    audit_id,
                    str(record.get("partition_id", "active")),
                    sequence,
                    event_hash,
                    previous_hash,
                    str(record.get("principal", "system")),
                    payload,
                    idempotency_key,
                    _now(),
                ),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return audit_id

    def latest(self, correlation_id: str) -> Mapping[str, Any] | None:
        """Return the newest typed audit record for a correlation identity."""

        # Audit verification must see the current writer state. A pooled WAL
        # reader may keep an older read snapshot after a tamper/repair probe.
        with self._write_lock:
            rows = self.connection.execute(
                "SELECT * FROM audit_records ORDER BY sequence DESC"
            ).fetchall()
        for row in rows:
            record = _audit_row(cast(Mapping[str, Any], row))
            payload = record["payload"]
            if (
                str(payload.get("correlation_id") or "") == correlation_id
                or str(payload.get("audit_id") or "") == correlation_id
            ):
                return record
        return None

    def verify_chain(self) -> Mapping[str, Any]:
        """Verify sequence, predecessor, event hash, and the active chain tip."""

        # See the same current state as append_audit; a stale reader would make
        # a tampered active chain appear valid until its snapshot is refreshed.
        with self._write_lock:
            rows = self.connection.execute(
                "SELECT * FROM audit_records ORDER BY sequence,audit_id"
            ).fetchall()
        expected_sequence = 1
        previous_hash = "0" * 64
        for row in rows:
            payload = str(row["payload_json"])
            expected_hash = hashlib.sha256(
                f"{previous_hash}\0{payload}".encode("utf-8")
            ).hexdigest()
            if int(row["sequence"]) != expected_sequence:
                return {
                    "ok": False,
                    "status": "verification_failed",
                    "reason": "audit_sequence_gap",
                    "audit_id": str(row["audit_id"]),
                    "expected_sequence": expected_sequence,
                    "actual_sequence": int(row["sequence"]),
                }
            if str(row["prev_hash"]) != previous_hash:
                return {
                    "ok": False,
                    "status": "verification_failed",
                    "reason": "audit_predecessor_mismatch",
                    "audit_id": str(row["audit_id"]),
                    "expected": previous_hash,
                    "actual": str(row["prev_hash"]),
                }
            if str(row["event_hash"]) != expected_hash:
                return {
                    "ok": False,
                    "status": "verification_failed",
                    "reason": "audit_event_hash_mismatch",
                    "audit_id": str(row["audit_id"]),
                    "expected": expected_hash,
                    "actual": str(row["event_hash"]),
                }
            expected_sequence += 1
            previous_hash = expected_hash
        return {
            "ok": True,
            "schema_version": "persistmind.audit_chain_verify.v1",
            "records": len(rows),
            "tip": previous_hash,
            "partition_id": "active",
        }

    def tip(self) -> Mapping[str, Any]:
        verified = self.verify_chain()
        return {
            "ok": bool(verified.get("ok")),
            "tip": verified.get("tip"),
            "records": verified.get("records", 0),
            "chain": verified,
        }

    def seal_partition(
        self, sealed_path: Path | None = None, *, sealed_store_id: str | None = None
    ) -> Mapping[str, Any]:
        if sealed_path is not None:
            self._close_readers()
        with self._write_lock:
            rows = self.connection.execute(
                "SELECT audit_id,event_hash,created_at FROM audit_records ORDER BY sequence"
            ).fetchall()
        tip = str(rows[-1]["event_hash"]) if rows else "0" * 64
        partition_id = f"audit-{tip[:24]}"
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT OR REPLACE INTO audit_partitions VALUES(?,?,?,?,?,?)",
                (
                    partition_id,
                    "sealed" if sealed_path else "ready_to_seal",
                    len(rows),
                    tip,
                    _now(),
                    None,
                ),
            )
        if sealed_path is not None:
            with self._write_lock:
                self.connection.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        result: dict[str, Any] = {
            "sealed": sealed_path is not None,
            "partition_id": partition_id,
            "records": len(rows),
            "root_hash": tip,
            "anchor_required": True,
        }
        if sealed_path is not None:
            sealed_path.parent.mkdir(parents=True, exist_ok=True)
            temporary = sealed_path.with_name(f".{sealed_path.name}.{os.getpid()}.tmp")
            self._copy_wal_free_image(temporary)
            _finalize_sealed_image(
                temporary,
                sealed_path,
                role=StoreRole.AUDIT_SEALED,
                logical_hash=tip,
                store_id=sealed_store_id or partition_id,
                allow_development_driver=self._allow_development_driver,
            )
            result["location"] = str(sealed_path)
            result["physical_image_hash"] = _file_hash(sealed_path)
        return result

    def anchor_partition(
        self, partition_id: str, *, signature: str, principal: str
    ) -> Mapping[str, Any]:
        if not signature or not principal:
            raise PermissionError("audit anchor requires principal and external signature")
        with self._write_lock, self.connection:
            row = self.connection.execute(
                "SELECT root_hash FROM audit_partitions "
                "WHERE partition_id=? AND state IN ('sealed','ready_to_seal')",
                (partition_id,),
            ).fetchone()
            if row is None:
                raise KeyError(partition_id)
            anchor_id = hashlib.sha256(
                f"{partition_id}:{row[0]}:{signature}".encode("utf-8")
            ).hexdigest()
            self.connection.execute(
                "INSERT OR REPLACE INTO audit_anchors VALUES(?,?,?,?,?,?)",
                (anchor_id, partition_id, row[0], signature, principal, _now()),
            )
            self.connection.execute(
                "UPDATE audit_partitions SET anchor_id=? WHERE partition_id=?",
                (anchor_id, partition_id),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return {
            "anchor_id": anchor_id,
            "partition_id": partition_id,
            "principal": principal,
            "root_hash": row[0],
        }

    def _copy_wal_free_image(self, target: Path) -> None:
        with self._write_lock:
            self.copy_image_to(target)
        Path(f"{target}-wal").unlink(missing_ok=True)
        Path(f"{target}-shm").unlink(missing_ok=True)


def _finalize_sealed_image(
    temporary: Path,
    destination: Path,
    *,
    role: StoreRole,
    logical_hash: str,
    store_id: str,
    allow_development_driver: bool,
) -> None:
    try:
        connection = open_nextgen_connection(
            temporary,
            allow_development_driver=allow_development_driver,
        )
        try:
            connection.execute("PRAGMA journal_mode=DELETE")
            connection.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            connection.execute("PRAGMA application_id=" + str(APPLICATION_IDS[role]))
            connection.execute(
                "UPDATE domain_metadata SET store_role=?,store_id=?,lifecycle_state='sealed',"
                "sealed_at=?,logical_content_hash=? WHERE singleton=1",
                (role.value, store_id, _now(), logical_hash),
            )
            connection.execute("PRAGMA optimize")
            connection.commit()
        finally:
            connection.close()
        Path(f"{temporary}-wal").unlink(missing_ok=True)
        Path(f"{temporary}-shm").unlink(missing_ok=True)
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _audit_row(row: Mapping[str, Any]) -> dict[str, Any]:
    try:
        payload = json.loads(str(row["payload_json"]))
    except (KeyError, TypeError, json.JSONDecodeError):
        payload = {}
    return {
        "audit_id": str(row["audit_id"]),
        "partition_id": str(row["partition_id"]),
        "sequence": int(row["sequence"]),
        "event_hash": str(row["event_hash"]),
        "prev_hash": str(row["prev_hash"]),
        "principal": str(row["principal"]),
        "payload": payload if isinstance(payload, dict) else {},
        "idempotency_key": str(row["idempotency_key"]),
        "created_at": str(row["created_at"]),
    }


def _activity_row(row: Mapping[str, Any]) -> dict[str, Any]:
    payload = json.loads(str(row["payload_json"]))
    return {
        "event_id": str(row["event_id"]),
        "event_type": str(row["event_type"]),
        "payload": payload if isinstance(payload, dict) else {},
        "idempotency_key": str(row["idempotency_key"]),
        "occurred_at": str(row["occurred_at"]),
        "committed_at": str(row["committed_at"]),
    }


_SECRET_KEYS = {"password", "passwd", "secret", "token", "api_key", "authorization"}


def _redact(value: Any) -> Any:
    if isinstance(value, dict):
        return {
            str(key): "[REDACTED]" if str(key).lower() in _SECRET_KEYS else _redact(item)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_redact(item) for item in value]
    return value
