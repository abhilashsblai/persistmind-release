from __future__ import annotations

import hashlib
import sqlite3
import time
from collections.abc import Iterator
from pathlib import Path
from types import TracebackType
from typing import Any, Sequence

from ..runtime_policy import require_qualified_nextgen_runtime


class ApswRow:
    """Small sqlite3.Row-compatible projection for APSW query results."""

    def __init__(self, names: Sequence[str], values: Sequence[Any]) -> None:
        self._names = tuple(names)
        self._values = tuple(values)
        self._by_name = dict(zip(self._names, self._values, strict=True))

    def __getitem__(self, key: int | slice | str) -> Any:
        if isinstance(key, (int, slice)):
            return self._values[key]
        return self._by_name[key]

    def __iter__(self) -> Iterator[Any]:
        return iter(self._values)

    def __len__(self) -> int:
        return len(self._values)

    def keys(self) -> list[str]:
        return list(self._names)


class ApswCursor:
    def __init__(self, connection: "ApswConnection", cursor: Any) -> None:
        self._connection = connection
        self._cursor = cursor
        self.rowcount = -1
        self.lastrowid: int | None = None

    def execute(
        self, statement: str, parameters: Sequence[Any] | dict[str, Any] | None = None
    ) -> "ApswCursor":
        delays = (0.01, 0.025, 0.05, 0.1)
        for attempt in range(len(delays) + 1):
            try:
                if parameters is None:
                    self._cursor.execute(statement)
                else:
                    self._cursor.execute(statement, parameters)
                break
            except Exception as exc:
                if attempt == len(delays) or not _is_busy_error(exc):
                    raise
                time.sleep(delays[attempt])
        self.rowcount = self._connection._raw.changes()
        self.lastrowid = self._connection._raw.last_insert_rowid()
        return self

    def fetchone(self) -> ApswRow | None:
        return self._cursor.fetchone()

    def fetchall(self) -> list[ApswRow]:
        return self._cursor.fetchall()

    def __iter__(self) -> Iterator[ApswRow]:
        return iter(self._cursor)

    def close(self) -> None:
        self._cursor.close()


class ApswConnection:
    """Narrow DB-API-shaped wrapper used exclusively for persistmind-nextgen-v1 files.

    Product adapters use the same small connection surface in source tests and
    in the installed runtime.  The latter goes through APSW only; this wrapper
    deliberately does not fall back to ``sqlite3``.
    """

    def __init__(
        self,
        path: Path,
        *,
        read_only: bool = False,
        immutable: bool = False,
        max_attached: int = 0,
    ) -> None:
        qualification = require_qualified_nextgen_runtime()
        del qualification
        import apsw  # type: ignore[import-not-found]

        if read_only:
            flags = apsw.SQLITE_OPEN_READONLY | apsw.SQLITE_OPEN_URI
            location = f"file:{path.resolve().as_posix()}?mode=ro"
            if immutable:
                location += "&immutable=1"
        else:
            flags = apsw.SQLITE_OPEN_READWRITE | apsw.SQLITE_OPEN_CREATE
            location = str(path)
        self._raw = apsw.Connection(location, flags=flags)
        self._raw.setrowtrace(_row_trace)
        self._configure_hardening(apsw, max_attached=max_attached)
        self.row_factory: Any = None
        self.sqlite_vec: dict[str, Any] | None = None

    def load_sqlite_vec(self) -> dict[str, Any]:
        """Load only the exact pinned sqlite-vec package, then close the load scope."""

        import sqlite_vec  # type: ignore[import-untyped]

        version = str(getattr(sqlite_vec, "__version__", ""))
        if version != "0.1.9":
            raise RuntimeError(f"unsupported sqlite-vec version: {version or 'unknown'}")
        loadable = Path(sqlite_vec.loadable_path()).resolve()
        path = _loadable_artifact(loadable)
        if path is None:
            raise RuntimeError("sqlite-vec loadable artifact is missing")
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        self._raw.enableloadextension(True)
        try:
            self._raw.loadextension(str(path))
        finally:
            self._raw.enableloadextension(False)
        version_row = self._raw.execute("SELECT vec_version()").fetchone()
        if version_row is None:
            raise RuntimeError("sqlite-vec did not report its loaded version")
        loaded = str(version_row[0])
        if not _sqlite_vec_versions_match(loaded, version):
            raise RuntimeError("sqlite-vec loaded version does not match its package")
        self.sqlite_vec = {
            "version": version,
            "artifact": str(path),
            "sha256": digest,
        }
        return dict(self.sqlite_vec)

    def _configure_hardening(self, apsw: Any, *, max_attached: int) -> None:
        self._raw.config(apsw.SQLITE_DBCONFIG_DEFENSIVE, 1)
        self._raw.config(apsw.SQLITE_DBCONFIG_TRUSTED_SCHEMA, 0)
        self._raw.config(apsw.SQLITE_DBCONFIG_DQS_DDL, 0)
        self._raw.config(apsw.SQLITE_DBCONFIG_DQS_DML, 0)
        for name, value in {
            "SQLITE_LIMIT_ATTACHED": max(0, min(max_attached, 6)),
            "SQLITE_LIMIT_LENGTH": 16 * 1024 * 1024,
            "SQLITE_LIMIT_SQL_LENGTH": 1024 * 1024,
            "SQLITE_LIMIT_COLUMN": 256,
            "SQLITE_LIMIT_EXPR_DEPTH": 100,
            "SQLITE_LIMIT_COMPOUND_SELECT": 20,
            "SQLITE_LIMIT_VARIABLE_NUMBER": 999,
            "SQLITE_LIMIT_FUNCTION_ARG": 100,
            "SQLITE_LIMIT_TRIGGER_DEPTH": 32,
        }.items():
            constant = getattr(apsw, name, None)
            if constant is not None:
                self._raw.limit(constant, value)

    def execute(
        self, statement: str, parameters: Sequence[Any] | dict[str, Any] | None = None
    ) -> ApswCursor:
        return ApswCursor(self, self._raw.cursor()).execute(statement, parameters)

    def executescript(self, script: str) -> ApswCursor:
        return self.execute(script)

    def cursor(self) -> ApswCursor:
        return ApswCursor(self, self._raw.cursor())

    def commit(self) -> None:
        try:
            self._raw.execute("COMMIT")
        except Exception as exc:  # APSW raises when no transaction is active.
            if "no transaction" not in str(exc).lower():
                raise

    def close(self) -> None:
        self._raw.close()

    def __enter__(self) -> "ApswConnection":
        self._raw.__enter__()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        self._raw.__exit__(exc_type, exc_value, traceback)


def open_nextgen_connection(
    path: Path,
    *,
    read_only: bool = False,
    immutable: bool = False,
    allow_development_driver: bool,
) -> ApswConnection | sqlite3.Connection:
    """Open one authority file through APSW or the explicit test-only fallback."""

    if not allow_development_driver:
        return ApswConnection(path, read_only=read_only, immutable=immutable)
    if read_only:
        query = "?mode=ro"
        if immutable:
            query += "&immutable=1"
        return sqlite3.connect(
            f"file:{path.resolve()}" + query,
            uri=True,
            timeout=5.0,
            check_same_thread=False,
        )
    return sqlite3.connect(path, timeout=5.0, check_same_thread=False)


def copy_nextgen_database(
    source: ApswConnection | sqlite3.Connection,
    destination: Path,
    *,
    allow_development_driver: bool,
) -> None:
    """Create a standalone online image without opening a authority file via two drivers."""

    destination.unlink(missing_ok=True)
    if isinstance(source, ApswConnection):
        target = ApswConnection(destination)
        try:
            backup = target._raw.backup("main", source._raw, "main")
            try:
                backup.step(-1)
            finally:
                backup.finish()
        finally:
            target.close()
        return
    if not allow_development_driver:
        raise RuntimeError("authority runtime driver mismatch")
    assert isinstance(source, sqlite3.Connection)
    sqlite_target = sqlite3.connect(destination)
    try:
        source.backup(sqlite_target)
        sqlite_target.commit()
    finally:
        sqlite_target.close()


def _row_trace(cursor: Any, values: Sequence[Any]) -> ApswRow:
    return ApswRow([str(item[0]) for item in cursor.getdescription()], values)


def _loadable_artifact(loadable: Path) -> Path | None:
    """Resolve sqlite-vec's extensionless load path to its packaged artifact."""

    if loadable.is_file():
        return loadable
    for suffix in (".dll", ".so", ".dylib"):
        candidate = Path(f"{loadable}{suffix}")
        if candidate.is_file():
            return candidate
    return None


def _sqlite_vec_versions_match(loaded: str, packaged: str) -> bool:
    return loaded.removeprefix("v") == packaged.removeprefix("v")


def _is_busy_error(exc: BaseException) -> bool:
    name = type(exc).__name__.casefold()
    message = str(exc).casefold()
    return "busy" in name or "locked" in message or "database is busy" in message
