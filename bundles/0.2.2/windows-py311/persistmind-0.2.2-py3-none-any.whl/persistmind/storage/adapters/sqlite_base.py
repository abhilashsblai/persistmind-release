from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from ..descriptors import (
    StorageDomain,
    StoreCapabilities,
    StoreDescriptor,
    StoreRole,
)
from ..resources import read_bytes, sha256
from .apsw_driver import ApswConnection, copy_nextgen_database, open_nextgen_connection

SQLITE_BUSY_TIMEOUT_MS = 30_000


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


COMMON_SCHEMA = """
CREATE TABLE IF NOT EXISTS domain_metadata(
    singleton INTEGER PRIMARY KEY CHECK(singleton=1),
    domain TEXT NOT NULL,
    store_role TEXT NOT NULL,
    store_id TEXT NOT NULL,
    schema_head INTEGER NOT NULL,
    generation INTEGER NOT NULL,
    revision INTEGER NOT NULL DEFAULT 0,
    lifecycle_state TEXT NOT NULL DEFAULT 'active',
    resource_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    sealed_at TEXT,
    logical_content_hash TEXT,
    physical_image_hash TEXT
);
CREATE TABLE IF NOT EXISTS domain_schema_migrations(
    version INTEGER PRIMARY KEY,
    resource TEXT NOT NULL,
    checksum TEXT NOT NULL,
    applied_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS domain_records(
    record_id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    scope TEXT NOT NULL DEFAULT '',
    payload_json TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    revision INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    idempotency_key TEXT UNIQUE
);
CREATE INDEX IF NOT EXISTS idx_domain_records_kind_scope
    ON domain_records(kind,scope,updated_at DESC,record_id);
"""


APPLICATION_IDS: dict[StoreRole, int] = {
    StoreRole.CONTROL: 0x504D434C,  # PMCL
    StoreRole.SOURCE_MANIFEST: 0x504D534D,  # PMSM
    StoreRole.SOURCE_SEGMENT: 0x504D5347,  # PMSG
    StoreRole.TASK_STATE: 0x504D5453,  # PMTS
    StoreRole.ACTIVITY_ACTIVE: 0x504D4143,  # PMAC
    StoreRole.ACTIVITY_SEALED: 0x504D4153,  # PMAS
    StoreRole.AUDIT_ACTIVE: 0x504D4155,  # PMAU
    StoreRole.AUDIT_SEALED: 0x504D4144,  # PMAD
    StoreRole.KNOWLEDGE: 0x504D4B4E,  # PMKN
    StoreRole.POLICY: 0x504D504C,  # PMPL
    StoreRole.LEARNING: 0x504D4C4E,  # PMLN
}


def _combined_resource_hash(resources: Sequence[str]) -> str:
    return hashlib.sha256("\n".join(sha256(item) for item in resources).encode("ascii")).hexdigest()


def _schema_head_hash(base_resources: Sequence[str], upgrades: Sequence[str]) -> str:
    digest = _combined_resource_hash(base_resources)
    for resource in upgrades:
        digest = hashlib.sha256((digest + "\n" + sha256(resource)).encode("ascii")).hexdigest()
    return digest


_PRODUCT_V4_SCHEMA_BY_ROLE = {
    StoreRole.SOURCE_MANIFEST: "schemas/source/v4.sql",
    StoreRole.TASK_STATE: "schemas/task/v4.sql",
    StoreRole.ACTIVITY_ACTIVE: "schemas/activity/v4.sql",
    StoreRole.ACTIVITY_SEALED: "schemas/activity/v4.sql",
    StoreRole.KNOWLEDGE: "schemas/knowledge/v4.sql",
    StoreRole.POLICY: "schemas/policy/v4.sql",
    StoreRole.LEARNING: "schemas/learning/v4.sql",
}

_PRODUCT_V5_SCHEMA_BY_ROLE = {
    StoreRole.TASK_STATE: "schemas/task/v5.sql",
}

_PRODUCT_V6_SCHEMA_BY_ROLE = {
    StoreRole.TASK_STATE: "schemas/task/v6.sql",
}

_PRODUCT_V7_SCHEMA_BY_ROLE = {
    StoreRole.TASK_STATE: "schemas/task/v7.sql",
}

_PRODUCT_V8_SCHEMA_BY_ROLE = {
    StoreRole.TASK_STATE: "schemas/task/v8.sql",
}

_BASE_SCHEMA_RESOURCES_BY_ROLE: dict[StoreRole, tuple[str, ...]] = {
    StoreRole.CONTROL: ("schemas/control/v1.sql",),
    StoreRole.SOURCE_MANIFEST: ("schemas/source/v1.sql",),
    StoreRole.SOURCE_SEGMENT: ("schemas/source_segment/v1.sql",),
    StoreRole.TASK_STATE: ("schemas/task/v1.sql",),
    StoreRole.ACTIVITY_ACTIVE: (
        "schemas/activity/v1.sql",
        "schemas/reporting/activity.v1.sql",
    ),
    StoreRole.ACTIVITY_SEALED: (
        "schemas/activity/v1.sql",
        "schemas/reporting/activity.v1.sql",
    ),
    StoreRole.AUDIT_ACTIVE: ("schemas/audit/v1.sql",),
    StoreRole.AUDIT_SEALED: ("schemas/audit/v1.sql",),
    StoreRole.KNOWLEDGE: ("schemas/knowledge/v1.sql",),
    StoreRole.POLICY: ("schemas/policy/v1.sql",),
    StoreRole.LEARNING: (
        "schemas/learning/v1.sql",
        "schemas/reporting/learning.v1.sql",
    ),
}


def schema_upgrade_resources(
    role: StoreRole, from_head: int, to_head: int
) -> tuple[tuple[int, str], ...]:
    """Return the immutable, ordered resources needed for one authority upgrade."""

    if from_head < 1 or to_head < from_head:
        raise ValueError(f"invalid schema-head range: {from_head}..{to_head}")
    resources: list[tuple[int, str]] = []
    for version in range(from_head + 1, to_head + 1):
        resource: str | None
        if version == 2:
            resource = "schemas/common/v2.sql"
        elif version == 3:
            resource = "schemas/common/v3.sql"
        else:
            resource = {
                4: _PRODUCT_V4_SCHEMA_BY_ROLE,
                5: _PRODUCT_V5_SCHEMA_BY_ROLE,
                6: _PRODUCT_V6_SCHEMA_BY_ROLE,
                7: _PRODUCT_V7_SCHEMA_BY_ROLE,
                8: _PRODUCT_V8_SCHEMA_BY_ROLE,
            }.get(version, {}).get(role)
        if resource is None:
            raise StoreIdentityMismatch(f"schema head {version} is unsupported for {role.value}")
        resources.append((version, resource))
    return tuple(resources)


def schema_resource_hash(role: StoreRole, schema_head: int) -> str:
    """Compute the identity hash an adapter will require at ``schema_head``."""

    base_resources = _BASE_SCHEMA_RESOURCES_BY_ROLE[role]
    upgrades = tuple(resource for _, resource in schema_upgrade_resources(role, 1, schema_head))
    return _schema_head_hash(base_resources, upgrades)


class StoreIdentityMismatch(RuntimeError):
    """A file is not the physical role declared by the catalog."""

    status = "store_identity_mismatch"

    def __init__(
        self,
        message: str,
        *,
        expected: Mapping[str, object] | None = None,
        observed: Mapping[str, object] | None = None,
        mismatched_fields: Sequence[str] = (),
        path: Path | None = None,
    ) -> None:
        self.expected = dict(expected or {})
        self.observed = dict(observed or {})
        self.mismatched_fields = tuple(str(item) for item in mismatched_fields)
        self.path = str(path) if path is not None else None
        super().__init__(message)

    def diagnostics(self) -> dict[str, object]:
        return {
            "status": self.status,
            "path": self.path,
            "mismatched_fields": list(self.mismatched_fields),
            "expected": self.expected,
            "observed": self.observed,
        }


class SQLiteDomainStore:
    """Role-scoped persistmind-nextgen-v1 adapter with an APSW production connection path."""

    def __init__(
        self,
        path: Path,
        domain: StorageDomain,
        role: StoreRole,
        *,
        resource: str,
        extra_resources: tuple[str, ...] = (),
        store_id: str | None = None,
        descriptor: StoreDescriptor | None = None,
        allow_development_driver: bool = False,
    ) -> None:
        if descriptor is not None:
            if descriptor.domain is not domain or descriptor.store_role is not role:
                raise StoreIdentityMismatch(
                    "adapter does not match descriptor: "
                    f"adapter={domain.value}/{role.value} "
                    f"descriptor={descriptor.domain.value}/{descriptor.store_role.value}"
                )
            store_id = descriptor.store_id
        self.path, self.domain, self.role = path, domain, role
        self._allow_development_driver = allow_development_driver
        read_only = (
            bool(descriptor.read_only)
            if descriptor is not None
            else role
            in {
                StoreRole.ACTIVITY_SEALED,
                StoreRole.AUDIT_SEALED,
            }
        )
        self._opened_read_only = read_only
        exists = path.exists()
        if read_only:
            if not exists:
                raise FileNotFoundError(f"sealed store is missing: {path}")
            self.connection = open_nextgen_connection(
                path,
                read_only=True,
                immutable=bool(descriptor is not None and descriptor.state == "sealed"),
                allow_development_driver=allow_development_driver,
            )
        else:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.connection = open_nextgen_connection(
                path,
                allow_development_driver=allow_development_driver,
            )
        self.connection.row_factory = sqlite3.Row
        if read_only:
            self.connection.execute("PRAGMA query_only=ON")
        else:
            self._configure_connection(new_file=not exists)
        self._reader_state = threading.local()
        self._write_lock = threading.RLock()
        self._readers_lock = threading.Lock()
        self._readers: set[ApswConnection | sqlite3.Connection] = set()
        self._closed = False
        requested_head = descriptor.schema_head if descriptor is not None else 1
        supported_heads = (
            {1, 2, 3, 4, 5, 6, 7, 8}
            if role is StoreRole.TASK_STATE
            else {1, 2, 3, 4}
            if role
            in {
                StoreRole.SOURCE_MANIFEST,
                StoreRole.ACTIVITY_ACTIVE,
                StoreRole.ACTIVITY_SEALED,
                StoreRole.KNOWLEDGE,
                StoreRole.POLICY,
                StoreRole.LEARNING,
            }
            else {1, 2, 3}
        )
        if requested_head not in supported_heads:
            raise StoreIdentityMismatch(
                f"unsupported schema head for {role.value}: {requested_head}"
            )
        base_resources = (resource, *extra_resources)
        upgrade_resources: tuple[str, ...] = ()
        if requested_head >= 2:
            upgrade_resources = (*upgrade_resources, "schemas/common/v2.sql")
        if requested_head >= 3:
            upgrade_resources = (*upgrade_resources, "schemas/common/v3.sql")
        if requested_head >= 4:
            product_resource = _PRODUCT_V4_SCHEMA_BY_ROLE.get(role)
            if product_resource is None:
                raise StoreIdentityMismatch(f"schema head 4 is unsupported for {role.value}")
            upgrade_resources = (*upgrade_resources, product_resource)
        if requested_head >= 5:
            product_resource = _PRODUCT_V5_SCHEMA_BY_ROLE.get(role)
            if product_resource is None:
                raise StoreIdentityMismatch(f"schema head 5 is unsupported for {role.value}")
            upgrade_resources = (*upgrade_resources, product_resource)
        if requested_head >= 6:
            product_resource = _PRODUCT_V6_SCHEMA_BY_ROLE.get(role)
            if product_resource is None:
                raise StoreIdentityMismatch(f"schema head 6 is unsupported for {role.value}")
            upgrade_resources = (*upgrade_resources, product_resource)
        if requested_head >= 7:
            product_resource = _PRODUCT_V7_SCHEMA_BY_ROLE.get(role)
            if product_resource is None:
                raise StoreIdentityMismatch(f"schema head 7 is unsupported for {role.value}")
            upgrade_resources = (*upgrade_resources, product_resource)
        if requested_head >= 8:
            product_resource = _PRODUCT_V8_SCHEMA_BY_ROLE.get(role)
            if product_resource is None:
                raise StoreIdentityMismatch(f"schema head 8 is unsupported for {role.value}")
            upgrade_resources = (*upgrade_resources, product_resource)
        schema_resources = (*base_resources, *upgrade_resources)
        resource_hash = _schema_head_hash(base_resources, upgrade_resources)
        provided_identity = store_id
        identity = provided_identity or f"{role.value}-current"
        require_identity_match = (
            not read_only or descriptor is not None or provided_identity is not None
        )
        with self._write_lock:
            if not read_only and not exists:
                with self.connection:
                    self.connection.executescript(COMMON_SCHEMA)
                    for schema_resource in schema_resources:
                        self.connection.executescript(read_bytes(schema_resource).decode("utf-8"))
                    self.connection.execute(
                        "INSERT OR IGNORE INTO domain_metadata("
                        "singleton,domain,store_role,store_id,schema_head,generation,revision,"
                        "lifecycle_state,resource_hash,created_at) VALUES(1,?,?,?,?,1,0,'active',?,?)",
                        (domain.value, role.value, identity, requested_head, resource_hash, _now()),
                    )
                    self.connection.execute(
                        "INSERT OR IGNORE INTO domain_schema_migrations VALUES(1,?,?,?)",
                        (
                            ",".join(base_resources),
                            _combined_resource_hash(base_resources),
                            _now(),
                        ),
                    )
                    if requested_head >= 2:
                        self.connection.execute(
                            "INSERT OR IGNORE INTO domain_schema_migrations VALUES(2,?,?,?)",
                            ("schemas/common/v2.sql", sha256("schemas/common/v2.sql"), _now()),
                        )
                    if requested_head >= 3:
                        self.connection.execute(
                            "INSERT OR IGNORE INTO domain_schema_migrations VALUES(3,?,?,?)",
                            ("schemas/common/v3.sql", sha256("schemas/common/v3.sql"), _now()),
                        )
                    if requested_head >= 4:
                        product_resource = _PRODUCT_V4_SCHEMA_BY_ROLE[role]
                        self.connection.execute(
                            "INSERT OR IGNORE INTO domain_schema_migrations VALUES(4,?,?,?)",
                            (product_resource, sha256(product_resource), _now()),
                        )
                    if requested_head >= 5:
                        product_resource = _PRODUCT_V5_SCHEMA_BY_ROLE[role]
                        self.connection.execute(
                            "INSERT OR IGNORE INTO domain_schema_migrations VALUES(5,?,?,?)",
                            (product_resource, sha256(product_resource), _now()),
                        )
                    if requested_head >= 6:
                        product_resource = _PRODUCT_V6_SCHEMA_BY_ROLE[role]
                        self.connection.execute(
                            "INSERT OR IGNORE INTO domain_schema_migrations VALUES(6,?,?,?)",
                            (product_resource, sha256(product_resource), _now()),
                        )
                    if requested_head >= 7:
                        product_resource = _PRODUCT_V7_SCHEMA_BY_ROLE[role]
                        self.connection.execute(
                            "INSERT OR IGNORE INTO domain_schema_migrations VALUES(7,?,?,?)",
                            (product_resource, sha256(product_resource), _now()),
                        )
                    if requested_head >= 8:
                        product_resource = _PRODUCT_V8_SCHEMA_BY_ROLE[role]
                        self.connection.execute(
                            "INSERT OR IGNORE INTO domain_schema_migrations VALUES(8,?,?,?)",
                            (product_resource, sha256(product_resource), _now()),
                        )
                    self.connection.execute(f"PRAGMA user_version={requested_head}")
            header = self.connection.execute(
                "SELECT domain,store_role,store_id,schema_head,resource_hash "
                "FROM domain_metadata WHERE singleton=1"
            ).fetchone()
            migration = self.connection.execute(
                "SELECT checksum FROM domain_schema_migrations WHERE version=1"
            ).fetchone()
            expected = {
                "domain": domain.value,
                "store_role": role.value,
                "store_id": identity,
                "schema_head": requested_head,
                "resource_hash": resource_hash,
                "base_migration_checksum": _combined_resource_hash(base_resources),
            }
            observed = (
                {
                    "domain": str(header["domain"]),
                    "store_role": str(header["store_role"]),
                    "store_id": str(header["store_id"]),
                    "schema_head": int(header["schema_head"]),
                    "resource_hash": str(header["resource_hash"]),
                    "base_migration_checksum": str(migration[0]) if migration is not None else None,
                }
                if header is not None
                else {}
            )
            compared_fields = [
                "domain",
                "store_role",
                "schema_head",
                "resource_hash",
                "base_migration_checksum",
            ]
            if require_identity_match:
                compared_fields.insert(2, "store_id")
            mismatched_fields = [
                field for field in compared_fields if observed.get(field) != expected[field]
            ]
            if mismatched_fields:
                self.connection.close()
                raise StoreIdentityMismatch(
                    "store identity mismatch: "
                    f"expected {domain.value}/{role.value}/{identity}; "
                    f"mismatched fields: {', '.join(mismatched_fields)}",
                    expected=expected,
                    observed=observed,
                    mismatched_fields=mismatched_fields,
                    path=path,
                )
        if descriptor is None:
            descriptor = StoreDescriptor(
                store_id=(
                    str(header["store_id"])
                    if header is not None and read_only and not require_identity_match
                    else identity
                ),
                domain=domain,
                store_role=role,
                backend="sqlite",
                location=str(path),
                schema_head=requested_head,
                read_only=role in {StoreRole.ACTIVITY_SEALED, StoreRole.AUDIT_SEALED},
                capabilities=StoreCapabilities(
                    full_text=False,
                    vector_search=False,
                    online_backup=True,
                    point_in_time_recovery=False,
                    partitioning=role
                    in {
                        StoreRole.SOURCE_SEGMENT,
                        StoreRole.ACTIVITY_ACTIVE,
                        StoreRole.ACTIVITY_SEALED,
                        StoreRole.AUDIT_ACTIVE,
                        StoreRole.AUDIT_SEALED,
                    },
                ),
            )
        self._descriptor = descriptor

    def _configure_connection(self, *, new_file: bool) -> None:
        if new_file:
            self.connection.execute("PRAGMA page_size=4096")
            self.connection.execute(
                "PRAGMA auto_vacuum="
                + ("NONE" if self.role is StoreRole.SOURCE_SEGMENT else "INCREMENTAL")
            )
            self.connection.execute("PRAGMA application_id=" + str(APPLICATION_IDS[self.role]))
            self.connection.execute("PRAGMA user_version=1")
            self.connection.execute("PRAGMA journal_mode=WAL")
            self.connection.execute("PRAGMA synchronous=FULL")
            self.connection.execute("PRAGMA wal_autocheckpoint=0")
            self.connection.execute("PRAGMA journal_size_limit=67108864")
        self.connection.execute("PRAGMA foreign_keys=ON")
        self.connection.execute("PRAGMA trusted_schema=OFF")
        self.connection.execute("PRAGMA read_uncommitted=OFF")
        self.connection.execute("PRAGMA temp_store=MEMORY")
        self.connection.execute("PRAGMA mmap_size=0")
        self.connection.execute("PRAGMA synchronous=FULL")
        self.connection.execute(f"PRAGMA busy_timeout={SQLITE_BUSY_TIMEOUT_MS}")
        self.connection.execute("PRAGMA wal_autocheckpoint=0")
        app_id = int(_scalar(self.connection.execute("PRAGMA application_id").fetchone()))
        page_size = int(_scalar(self.connection.execute("PRAGMA page_size").fetchone()))
        if app_id != APPLICATION_IDS[self.role] or page_size != 4096:
            raise StoreIdentityMismatch(
                f"SQLite header mismatch for {self.role.value}: "
                f"application_id={app_id:#x} page_size={page_size}"
            )

    @property
    def descriptor(self) -> StoreDescriptor:
        return self._descriptor

    def get(self, record_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute("SELECT * FROM domain_records WHERE record_id=?", (record_id,))
            .fetchone()
        )
        return self._record(row) if row else None

    def put(self, record: Mapping[str, Any], *, idempotency_key: str | None = None) -> str:
        if self._descriptor.read_only:
            raise PermissionError(f"sealed store is read-only: {self.role.value}")
        record_id = str(record["record_id"])
        payload = json.dumps(dict(record), sort_keys=True, separators=(",", ":"))
        digest = hashlib.sha256(payload.encode()).hexdigest()
        now = _now()
        with self._write_lock, self.connection:
            if idempotency_key:
                existing = self.connection.execute(
                    "SELECT record_id FROM domain_records WHERE idempotency_key=?",
                    (idempotency_key,),
                ).fetchone()
                if existing:
                    return str(existing[0])
            self.connection.execute(
                "INSERT INTO domain_records VALUES(?,?,?,?,?,1,?,?,?) "
                "ON CONFLICT(record_id) DO UPDATE SET "
                "kind=excluded.kind,scope=excluded.scope,payload_json=excluded.payload_json,"
                "content_hash=excluded.content_hash,revision=domain_records.revision+1,"
                "updated_at=excluded.updated_at",
                (
                    record_id,
                    str(record.get("kind", "record")),
                    str(record.get("scope", "")),
                    payload,
                    digest,
                    now,
                    now,
                    idempotency_key,
                ),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return record_id

    def search(self, query: str, *, limit: int = 20) -> Sequence[Mapping[str, Any]]:
        escaped = query.replace("%", "\\%").replace("_", "\\_")
        rows = (
            self._reader()
            .execute(
                "SELECT * FROM domain_records WHERE payload_json LIKE ? ESCAPE '\\' "
                "ORDER BY updated_at DESC,record_id LIMIT ?",
                (f"%{escaped}%", max(1, min(limit, 1000))),
            )
            .fetchall()
        )
        return [self._record(row) for row in rows]

    def revision(self) -> int:
        with self._write_lock:
            return int(
                _scalar(
                    self.connection.execute(
                        "SELECT revision FROM domain_metadata WHERE singleton=1"
                    ).fetchone()
                )
            )

    def health(self) -> Mapping[str, Any]:
        return self.verify_integrity(full=False)

    def verify_integrity(self, *, full: bool = False) -> Mapping[str, Any]:
        pragma = "integrity_check" if full else "quick_check"
        with self._write_lock:
            rows = self.connection.execute(f"PRAGMA {pragma}").fetchall()
            messages = [str(row[0]) for row in rows]
            foreign_keys = [
                tuple(row) for row in self.connection.execute("PRAGMA foreign_key_check").fetchall()
            ]
            journal_mode = str(_scalar(self.connection.execute("PRAGMA journal_mode").fetchone()))
            metadata = self.connection.execute(
                "SELECT schema_head,generation,resource_hash,lifecycle_state "
                "FROM domain_metadata WHERE singleton=1"
            ).fetchone()
        integrity = "ok" if messages == ["ok"] else "; ".join(messages)
        companions: list[dict[str, Any]] = []
        for suffix in ("-wal", "-shm"):
            path = Path(str(self.path) + suffix)
            if path.is_file():
                try:
                    companions.append(
                        {
                            "suffix": suffix,
                            "bytes": path.stat().st_size,
                            "sha256": _file_sha256(path),
                            "state": "observed",
                        }
                    )
                except OSError as exc:
                    # WAL/SHM files are volatile and can be replaced between
                    # existence, stat, and hash probes. Their observability
                    # must not quarantine a database that passed SQLite's own
                    # integrity and foreign-key checks.
                    companions.append(
                        {
                            "suffix": suffix,
                            "bytes": None,
                            "sha256": None,
                            "state": "volatile",
                            "observation_error": type(exc).__name__,
                        }
                    )
        return {
            "ok": integrity == "ok" and not foreign_keys,
            "integrity": integrity,
            "integrity_mode": "full" if full else "quick",
            "foreign_key_violations": foreign_keys,
            "domain": self.domain.value,
            "store_role": self.role.value,
            "revision": self.revision(),
            "schema_head": int(metadata[0]) if metadata is not None else None,
            "generation": int(metadata[1]) if metadata is not None else None,
            "resource_hash": str(metadata[2]) if metadata is not None else None,
            "resource_hash_matches": bool(
                metadata is not None and self.descriptor.resource_hash in {None, str(metadata[2])}
            ),
            "lifecycle_state": str(metadata[3]) if metadata is not None else None,
            "journal_mode": journal_mode,
            "companions": companions,
            "bytes": self.path.stat().st_size,
            "point_in_time_recovery": False,
        }

    def checkpoint(self) -> tuple[int, int, int]:
        with self._write_lock:
            row = self.connection.execute("PRAGMA wal_checkpoint(PASSIVE)").fetchone()
            if row is None:
                raise RuntimeError("WAL checkpoint returned no status")
            return int(row[0]), int(row[1]), int(row[2])

    def reconciliation_health(self) -> Mapping[str, Any]:
        tables = {
            str(row[0])
            for row in self._reader()
            .execute("SELECT name FROM sqlite_master WHERE type='table'")
            .fetchall()
        }
        pending = (
            int(
                _scalar(
                    self._reader()
                    .execute("SELECT COUNT(*) FROM storage_outbox WHERE published_at IS NULL")
                    .fetchone()
                )
            )
            if "storage_outbox" in tables
            else 0
        )
        dead_letters = (
            int(
                _scalar(
                    self._reader().execute("SELECT COUNT(*) FROM storage_dead_letters").fetchone()
                )
            )
            if "storage_dead_letters" in tables
            else 0
        )
        return {
            "ok": dead_letters == 0,
            "pending_publications": pending,
            "dead_letters": dead_letters,
            "store_id": self.descriptor.store_id,
            "role": self.role.value,
        }

    def copy_image_to(self, target: Path) -> None:
        """Write a standalone image using the same SQLite driver as this store."""

        copy_nextgen_database(
            self.connection,
            target,
            allow_development_driver=self._allow_development_driver,
        )

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._close_readers()
        with self._write_lock:
            self.connection.close()

    def _close_readers(self) -> None:
        with self._readers_lock:
            readers = tuple(self._readers)
            self._readers.clear()
        for reader in readers:
            reader.close()
        self._reader_state.connection = None

    def _reader(self) -> ApswConnection | sqlite3.Connection:
        reader = getattr(self._reader_state, "connection", None)
        if reader is None:
            reader = open_nextgen_connection(
                self.path,
                read_only=True,
                immutable=self.descriptor.state == "sealed",
                allow_development_driver=self._allow_development_driver,
            )
            reader.row_factory = sqlite3.Row
            reader.execute("PRAGMA query_only=ON")
            reader.execute(f"PRAGMA busy_timeout={SQLITE_BUSY_TIMEOUT_MS}")
            self._reader_state.connection = reader
            with self._readers_lock:
                self._readers.add(reader)
        return reader

    @staticmethod
    def _record(row: Any) -> Mapping[str, Any]:
        payload = json.loads(row["payload_json"])
        payload["_revision"] = int(row["revision"])
        payload["_content_hash"] = row["content_hash"]
        return payload

    def __enter__(self) -> SQLiteDomainStore:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


def _scalar(row: Any | None) -> Any:
    if row is None:
        raise RuntimeError("scalar query returned no row")
    return row[0]


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="microseconds").replace("+00:00", "Z")
