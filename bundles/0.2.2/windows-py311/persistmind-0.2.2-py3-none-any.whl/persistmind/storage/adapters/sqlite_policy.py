from __future__ import annotations

import json
import hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from ..descriptors import StorageDomain, StoreDescriptor, StoreRole
from .sqlite_base import SQLiteDomainStore, _now, _scalar
from persistmind.utils import canonical_json, stable_id


class SQLitePolicyStore(SQLiteDomainStore):
    """Small authoritative policy store isolated from generic knowledge writes."""

    def __init__(
        self,
        path: Path,
        *,
        descriptor: StoreDescriptor | None = None,
        allow_development_driver: bool = False,
    ) -> None:
        super().__init__(
            path,
            StorageDomain.POLICY,
            StoreRole.POLICY,
            resource="schemas/policy/v1.sql",
            store_id="policy-current",
            descriptor=descriptor,
            allow_development_driver=allow_development_driver,
        )

    def applicable_policy(self, context: Mapping[str, Any]) -> Sequence[Mapping[str, Any]]:
        scope = str(context.get("scope", "global"))
        rows = (
            self._reader()
            .execute(
                "SELECT * FROM policy_authority "
                "WHERE status='active' AND (scope='global' OR scope=?) "
                "ORDER BY priority DESC,policy_id",
                (scope,),
            )
            .fetchall()
        )
        return [dict(row) for row in rows]

    def approve_policy(
        self,
        policy: Mapping[str, Any],
        *,
        approver: str,
        signature: str,
        signer_identity: Mapping[str, str],
        decision_document: Mapping[str, Any],
    ) -> str:
        if not approver or not signature.startswith("ed25519-v2:"):
            raise PermissionError("policy activation requires a verified Ed25519-v2 decision")
        policy_id = str(policy["policy_id"])
        payload_json = canonical_json(dict(policy))
        document_hash = (
            "sha256:"
            + hashlib.sha256(canonical_json(dict(decision_document)).encode("utf-8")).hexdigest()
        )
        if str(signer_identity.get("principal")) != approver:
            raise PermissionError("Policy signer identity does not match the approver")
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT payload_json,approved_by,signature FROM policy_authority WHERE policy_id=?",
                (policy_id,),
            ).fetchone()
            if existing is not None:
                if (
                    str(existing["payload_json"]) != payload_json
                    or str(existing["approved_by"]) != approver
                    or str(existing["signature"]) != signature
                ):
                    raise PermissionError("an immutable Policy decision already exists for this id")
                return policy_id
            self.connection.execute(
                "INSERT INTO policy_authority VALUES(?,?,?,?,?,?,?,?)",
                (
                    policy_id,
                    str(policy.get("scope", "global")),
                    int(policy.get("priority", 0)),
                    payload_json,
                    "active",
                    approver,
                    signature,
                    _now(),
                ),
            )
            self.connection.execute(
                "INSERT INTO policy_authority_transitions VALUES(?,?,?,?,?,?,?,?)",
                (
                    "transition_" + stable_id(policy_id, document_hash)[:32],
                    policy_id,
                    None,
                    "active",
                    approver,
                    "verified policy activation",
                    document_hash,
                    _now(),
                ),
            )
            key_id = str(signer_identity["key_id"])
            self.connection.execute(
                "INSERT INTO policy_signing_keys VALUES(?,?,?,?,?,?,NULL,?) "
                "ON CONFLICT(key_id) DO NOTHING",
                (
                    key_id,
                    approver,
                    "Ed25519",
                    str(signer_identity["public_key"]),
                    str(signer_identity["public_key_fingerprint"]),
                    _now(),
                    _now(),
                ),
            )
            self.connection.execute(
                "INSERT OR IGNORE INTO policy_decision_signatures VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    "signature_" + stable_id(policy_id, key_id, document_hash)[:32],
                    "policy_authority",
                    policy_id,
                    approver,
                    key_id,
                    "Ed25519",
                    document_hash,
                    signature,
                    _now(),
                ),
            )
            event_payload = canonical_json(
                {
                    "policy_id": policy_id,
                    "decision_document_hash": document_hash,
                    "principal": approver,
                    "change_kind": "approved",
                }
            )
            self.connection.execute(
                "INSERT OR IGNORE INTO domain_outbox VALUES(?,?,?,?,?,?,?,?,?,?,NULL)",
                (
                    "event_" + stable_id(policy_id, "PolicyDecisionObserved.v1")[:32],
                    "PolicyDecisionObserved.v1",
                    policy_id,
                    1,
                    event_payload,
                    hashlib.sha256(event_payload.encode("utf-8")).hexdigest(),
                    "policy-approval:" + policy_id,
                    policy_id,
                    document_hash,
                    _now(),
                ),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return policy_id

    def policy(self, policy_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute("SELECT * FROM policy_authority WHERE policy_id=?", (policy_id,))
            .fetchone()
        )
        return _policy_row(row) if row is not None else None

    def approve_policy_quorum(
        self,
        policy: Mapping[str, Any],
        *,
        signatures: Sequence[Mapping[str, str]],
        signer_identities: Sequence[Mapping[str, str]],
        decision_document: Mapping[str, Any],
    ) -> str:
        if len(signatures) != len(signer_identities) or not signer_identities:
            raise PermissionError("Policy approval requires verified signer identities")
        policy_id = self.approve_policy(
            policy,
            approver=str(signer_identities[0]["principal"]),
            signature=str(signatures[0]["signature"]),
            signer_identity=signer_identities[0],
            decision_document=decision_document,
        )
        with self._write_lock, self.connection:
            self._record_signatures(
                "policy_authority",
                policy_id,
                signatures,
                signer_identities,
                decision_document,
            )
        return policy_id

    def approve_experiment(
        self,
        approval: Mapping[str, Any],
        *,
        signatures: Sequence[Mapping[str, str]],
        signer_identities: Sequence[Mapping[str, str]],
        decision_document: Mapping[str, Any],
    ) -> Mapping[str, Any]:
        if len(signatures) != len(signer_identities) or not signer_identities:
            raise PermissionError("experiment approval requires verified signer identities")
        experiment_id = str(approval["experiment_id"])
        document_hash = (
            "sha256:"
            + hashlib.sha256(canonical_json(dict(decision_document)).encode("utf-8")).hexdigest()
        )
        now = _now()
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT * FROM policy_experiment_approvals WHERE experiment_id=?",
                (experiment_id,),
            ).fetchone()
            values = (
                experiment_id,
                str(approval["protocol_hash"]),
                canonical_json(dict(approval["allowed_scope"])),
                int(approval["required_quorum"]),
                str(approval["expires_at"]),
                "approved",
            )
            if existing is None:
                self.connection.execute(
                    "INSERT INTO policy_experiment_approvals VALUES(?,?,?,?,?,?)", values
                )
            elif tuple(existing) != values:
                raise PermissionError("immutable experiment approval already differs")
            policy_id = "experiment-approval-" + experiment_id
            policy_payload = canonical_json(
                {
                    "policy_id": policy_id,
                    "decision_type": "field_experiment_approval",
                    "experiment_id": experiment_id,
                    "protocol_hash": approval["protocol_hash"],
                    "protocol": dict(approval["protocol"]),
                    "allowed_scope": dict(approval["allowed_scope"]),
                    "required_quorum": int(approval["required_quorum"]),
                    "expires_at": approval["expires_at"],
                }
            )
            principal = str(signer_identities[0]["principal"])
            primary_signature = str(signatures[0]["signature"])
            authority = self.connection.execute(
                "SELECT payload_json,approved_by,signature FROM policy_authority WHERE policy_id=?",
                (policy_id,),
            ).fetchone()
            if authority is None:
                self.connection.execute(
                    "INSERT INTO policy_authority VALUES(?,?,?,?,?,?,?,?)",
                    (
                        policy_id,
                        "experiment:" + experiment_id,
                        95,
                        policy_payload,
                        "active",
                        principal,
                        primary_signature,
                        now,
                    ),
                )
                self.connection.execute(
                    "INSERT INTO policy_authority_transitions VALUES(?,?,?,?,?,?,?,?)",
                    (
                        "transition_" + stable_id(policy_id, document_hash)[:32],
                        policy_id,
                        None,
                        "active",
                        principal,
                        "verified field experiment approval",
                        document_hash,
                        now,
                    ),
                )
            elif tuple(authority) != (policy_payload, principal, primary_signature):
                raise PermissionError("immutable experiment Policy authority differs")
            for signed, identity in zip(signatures, signer_identities, strict=True):
                key_id = str(identity["key_id"])
                principal = str(identity["principal"])
                self.connection.execute(
                    "INSERT INTO policy_signing_keys VALUES(?,?,?,?,?,?,NULL,?) "
                    "ON CONFLICT(key_id) DO NOTHING",
                    (
                        key_id,
                        principal,
                        "Ed25519",
                        str(identity["public_key"]),
                        str(identity["public_key_fingerprint"]),
                        now,
                        now,
                    ),
                )
                self.connection.execute(
                    "INSERT OR IGNORE INTO policy_decision_signatures VALUES(?,?,?,?,?,?,?,?,?)",
                    (
                        "signature_" + stable_id(experiment_id, key_id, document_hash)[:32],
                        "policy_experiment_approval",
                        experiment_id,
                        principal,
                        key_id,
                        "Ed25519",
                        document_hash,
                        str(signed["signature"]),
                        now,
                    ),
                )
            event_payload = canonical_json(
                {
                    "experiment_id": experiment_id,
                    "protocol_hash": approval["protocol_hash"],
                    "decision_document_hash": document_hash,
                    "change_kind": "experiment_approved",
                }
            )
            self.connection.execute(
                "INSERT OR IGNORE INTO domain_outbox VALUES(?,?,?,?,?,?,?,?,?,?,NULL)",
                (
                    "event_" + stable_id(experiment_id, "experiment-approved")[:32],
                    "PolicyDecisionObserved.v1",
                    experiment_id,
                    1,
                    event_payload,
                    hashlib.sha256(event_payload.encode("utf-8")).hexdigest(),
                    "experiment-approval:" + experiment_id,
                    experiment_id,
                    document_hash,
                    now,
                ),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            row = self.connection.execute(
                "SELECT * FROM policy_experiment_approvals WHERE experiment_id=?",
                (experiment_id,),
            ).fetchone()
        return dict(row) if row is not None else {}

    def experiment_approval(self, experiment_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute(
                "SELECT * FROM policy_experiment_approvals WHERE experiment_id=?",
                (experiment_id,),
            )
            .fetchone()
        )
        if row is None:
            return None
        result = dict(row)
        result["allowed_scope"] = json.loads(str(result.pop("allowed_scope_json")))
        return result

    def record_experiment_assignment(self, assignment: Mapping[str, Any]) -> Mapping[str, Any]:
        experiment_id = str(assignment["experiment_id"])
        unit_id = str(assignment["assignment_unit_id"])
        values = (
            experiment_id,
            unit_id,
            str(assignment["assignment"]),
            str(assignment["assignment_receipt_hash"]),
            _now(),
        )
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT * FROM policy_experiment_assignments "
                "WHERE experiment_id=? AND assignment_unit_id=?",
                (experiment_id, unit_id),
            ).fetchone()
            if existing is None:
                self.connection.execute(
                    "INSERT INTO policy_experiment_assignments VALUES(?,?,?,?,?)", values
                )
            elif tuple(existing)[:4] != values[:4]:
                raise PermissionError("field assignment identity diverges from its commitment")
            row = self.connection.execute(
                "SELECT * FROM policy_experiment_assignments "
                "WHERE experiment_id=? AND assignment_unit_id=?",
                (experiment_id, unit_id),
            ).fetchone()
        return dict(row) if row is not None else {}

    def experiment_assignment(
        self, experiment_id: str, assignment_unit_id: str
    ) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute(
                "SELECT * FROM policy_experiment_assignments "
                "WHERE experiment_id=? AND assignment_unit_id=?",
                (experiment_id, assignment_unit_id),
            )
            .fetchone()
        )
        return dict(row) if row is not None else None

    def add_safety_constraint(
        self,
        constraint: Mapping[str, Any],
        *,
        signatures: Sequence[Mapping[str, str]],
        signer_identities: Sequence[Mapping[str, str]],
        decision_document: Mapping[str, Any],
    ) -> Mapping[str, Any]:
        if len(signatures) != len(signer_identities) or not signer_identities:
            raise PermissionError("safety constraint requires verified signatures")
        values = (
            str(constraint["constraint_id"]),
            str(constraint["contract_version"]),
            canonical_json(dict(constraint["predicate"])),
            str(constraint["risk_floor"]),
            str(constraint["fail_state"]),
            str(constraint["content_hash"]),
            int(constraint["required_quorum"]),
            str(constraint["valid_from"]),
            constraint.get("valid_to"),
        )
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT * FROM policy_safety_constraints WHERE constraint_id=?", (values[0],)
            ).fetchone()
            if existing is None:
                self.connection.execute(
                    "INSERT INTO policy_safety_constraints VALUES(?,?,?,?,?,?,?,?,?)", values
                )
            elif tuple(existing) != values:
                raise PermissionError("immutable safety constraint already differs")
            self._record_signatures(
                "policy_safety_constraint",
                values[0],
                signatures,
                signer_identities,
                decision_document,
            )
            row = self.connection.execute(
                "SELECT * FROM policy_safety_constraints WHERE constraint_id=?", (values[0],)
            ).fetchone()
        return dict(row) if row is not None else {}

    def safety_constraints(self) -> Sequence[Mapping[str, Any]]:
        rows = (
            self._reader()
            .execute(
                "SELECT * FROM policy_safety_constraints ORDER BY risk_floor DESC,constraint_id"
            )
            .fetchall()
        )
        result: list[Mapping[str, Any]] = []
        for row in rows:
            item = dict(row)
            item["predicate"] = json.loads(str(item.pop("predicate_json")))
            result.append(item)
        return result

    def create_governance_proposal(
        self, proposal_type: str, payload: Mapping[str, Any]
    ) -> Mapping[str, Any]:
        payload_json = canonical_json(dict(payload))
        payload_hash = "sha256:" + hashlib.sha256(payload_json.encode("utf-8")).hexdigest()
        proposal_id = "proposal_" + stable_id(proposal_type, payload_hash)[:32]
        values = (proposal_id, proposal_type, payload_json, payload_hash, "proposed", _now())
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT * FROM policy_governance_proposals WHERE proposal_id=?", (proposal_id,)
            ).fetchone()
            if existing is None:
                self.connection.execute(
                    "INSERT INTO policy_governance_proposals VALUES(?,?,?,?,?,?)", values
                )
            elif tuple(existing)[:5] != values[:5]:
                raise PermissionError("immutable governance proposal already differs")
        return dict(self.governance_proposal(proposal_id) or {})

    def governance_proposal(self, proposal_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute(
                "SELECT * FROM policy_governance_proposals WHERE proposal_id=?", (proposal_id,)
            )
            .fetchone()
        )
        if row is None:
            return None
        result = dict(row)
        result["payload"] = json.loads(str(result.pop("payload_json")))
        return result

    def governance_proposals(self, *, state: str | None = None) -> Sequence[Mapping[str, Any]]:
        query = "SELECT proposal_id FROM policy_governance_proposals"
        values: tuple[Any, ...] = ()
        if state:
            query += " WHERE state=?"
            values = (state,)
        query += " ORDER BY created_at DESC,proposal_id"
        rows = self._reader().execute(query, values).fetchall()
        return [
            item
            for row in rows
            if (item := self.governance_proposal(str(row["proposal_id"]))) is not None
        ]

    def transition_governance_proposal(
        self,
        proposal_id: str,
        *,
        to_state: str,
        actor: str,
        reason: str,
        signatures: Sequence[Mapping[str, str]],
        signer_identities: Sequence[Mapping[str, str]],
        decision_document: Mapping[str, Any],
    ) -> Mapping[str, Any]:
        if to_state not in {"adopted", "rejected", "rolled_back"}:
            raise ValueError(f"invalid governance transition state: {to_state}")
        document_hash = (
            "sha256:"
            + hashlib.sha256(canonical_json(dict(decision_document)).encode("utf-8")).hexdigest()
        )
        transition_id = "transition_" + stable_id(proposal_id, document_hash)[:32]
        with self._write_lock, self.connection:
            current = self.connection.execute(
                "SELECT state FROM policy_governance_proposals WHERE proposal_id=?",
                (proposal_id,),
            ).fetchone()
            if current is None:
                raise KeyError(f"unknown governance proposal: {proposal_id}")
            from_state = str(current["state"])
            allowed = {
                "proposed": {"adopted", "rejected"},
                "adopted": {"rolled_back"},
                "rejected": set(),
                "rolled_back": set(),
            }
            existing = self.connection.execute(
                "SELECT transition_id FROM policy_governance_transitions "
                "WHERE proposal_id=? AND decision_document_hash=?",
                (proposal_id, document_hash),
            ).fetchone()
            if existing is None:
                if to_state not in allowed[from_state]:
                    raise ValueError(f"invalid governance transition: {from_state} -> {to_state}")
                self.connection.execute(
                    "INSERT INTO policy_governance_transitions VALUES(?,?,?,?,?,?,?,?)",
                    (
                        transition_id,
                        proposal_id,
                        from_state,
                        to_state,
                        actor,
                        reason,
                        document_hash,
                        _now(),
                    ),
                )
                self.connection.execute(
                    "UPDATE policy_governance_proposals SET state=? WHERE proposal_id=? AND state=?",
                    (to_state, proposal_id, from_state),
                )
            self._record_signatures(
                "policy_governance_transition",
                transition_id,
                signatures,
                signer_identities,
                decision_document,
            )
        return dict(self.governance_proposal(proposal_id) or {})

    def record_security_snapshot(
        self, snapshot_type: str, payload: Mapping[str, Any]
    ) -> Mapping[str, Any]:
        payload_json = canonical_json(dict(payload))
        payload_hash = "sha256:" + hashlib.sha256(payload_json.encode("utf-8")).hexdigest()
        snapshot_id = "security_" + stable_id(snapshot_type, payload_hash)[:32]
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT OR IGNORE INTO policy_security_snapshots VALUES(?,?,?,?,?)",
                (snapshot_id, snapshot_type, payload_json, payload_hash, _now()),
            )
        return dict(self.security_snapshot(snapshot_id) or {})

    def security_snapshot(self, snapshot_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute("SELECT * FROM policy_security_snapshots WHERE snapshot_id=?", (snapshot_id,))
            .fetchone()
        )
        if row is None:
            return None
        result = dict(row)
        result["payload"] = json.loads(str(result.pop("payload_json")))
        return result

    def security_snapshots(self, *, limit: int = 20) -> Sequence[Mapping[str, Any]]:
        rows = (
            self._reader()
            .execute(
                "SELECT snapshot_id FROM policy_security_snapshots "
                "ORDER BY created_at DESC,snapshot_id DESC LIMIT ?",
                (max(1, min(limit, 1000)),),
            )
            .fetchall()
        )
        return [
            item
            for row in rows
            if (item := self.security_snapshot(str(row["snapshot_id"]))) is not None
        ]

    def issue_autonomy_grant(
        self,
        grant: Mapping[str, Any],
        *,
        signatures: Sequence[Mapping[str, str]],
        signer_identities: Sequence[Mapping[str, str]],
        decision_document: Mapping[str, Any],
    ) -> Mapping[str, Any]:
        if len(signatures) != len(signer_identities) or not signer_identities:
            raise PermissionError("autonomy grant requires verified signatures")
        values = (
            str(grant["grant_id"]),
            str(grant["capability"]),
            str(grant["artifact_version"]),
            canonical_json(dict(grant["scope"])),
            str(grant["maximum_risk"]),
            int(grant["maximum_uses"]),
            str(grant["expires_at"]),
            int(grant["required_quorum"]),
            "active",
            _now(),
        )
        document_hash = (
            "sha256:"
            + hashlib.sha256(canonical_json(dict(decision_document)).encode("utf-8")).hexdigest()
        )
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT * FROM policy_autonomy_grants WHERE grant_id=?", (values[0],)
            ).fetchone()
            if existing is None:
                self.connection.execute(
                    "INSERT INTO policy_autonomy_grants VALUES(?,?,?,?,?,?,?,?,?,?)", values
                )
                self.connection.execute(
                    "INSERT INTO policy_grant_transitions VALUES(?,?,?,?,?,?,?,?)",
                    (
                        "transition_" + stable_id(values[0], document_hash)[:32],
                        values[0],
                        None,
                        "active",
                        str(signer_identities[0]["principal"]),
                        "verified autonomy grant",
                        document_hash,
                        _now(),
                    ),
                )
            elif tuple(existing)[:9] != values[:9]:
                raise PermissionError("immutable autonomy grant already differs")
            self._record_signatures(
                "policy_autonomy_grant",
                values[0],
                signatures,
                signer_identities,
                decision_document,
            )
            row = self.connection.execute(
                "SELECT * FROM policy_autonomy_grants WHERE grant_id=?", (values[0],)
            ).fetchone()
        return dict(row) if row is not None else {}

    def autonomy_grant(self, grant_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute("SELECT * FROM policy_autonomy_grants WHERE grant_id=?", (grant_id,))
            .fetchone()
        )
        if row is None:
            return None
        result = dict(row)
        result["scope"] = json.loads(str(result.pop("scope_json")))
        transition = (
            self._reader()
            .execute(
                "SELECT * FROM policy_grant_transitions WHERE grant_id=? "
                "ORDER BY created_at DESC,transition_id DESC LIMIT 1",
                (grant_id,),
            )
            .fetchone()
        )
        if transition is not None:
            result["state"] = str(transition["to_state"])
            result["latest_transition"] = dict(transition)
        result["uses"] = int(
            _scalar(
                self._reader()
                .execute("SELECT COUNT(*) FROM policy_grant_uses WHERE grant_id=?", (grant_id,))
                .fetchone()
            )
        )
        if str(result["state"]) == "active":
            expires = datetime.fromisoformat(str(result["expires_at"]).replace("Z", "+00:00"))
            if expires.astimezone(timezone.utc) <= datetime.now(timezone.utc):
                result["state"] = "expired"
            elif int(result["uses"]) >= int(result["maximum_uses"]):
                result["state"] = "exhausted"
        return result

    def transition_autonomy_grant(
        self,
        grant_id: str,
        *,
        to_state: str,
        actor: str,
        reason: str,
        signatures: Sequence[Mapping[str, str]],
        signer_identities: Sequence[Mapping[str, str]],
        decision_document: Mapping[str, Any],
    ) -> Mapping[str, Any]:
        if to_state not in {"active", "suspended", "revoked", "expired", "exhausted"}:
            raise ValueError(f"unsupported autonomy grant state: {to_state}")
        if len(signatures) != len(signer_identities) or not signer_identities:
            raise PermissionError("autonomy grant transition requires verified signatures")
        document_hash = (
            "sha256:"
            + hashlib.sha256(canonical_json(dict(decision_document)).encode("utf-8")).hexdigest()
        )
        transition_id = "transition_" + stable_id(grant_id, to_state, document_hash)[:32]
        with self._write_lock, self.connection:
            grant = self.connection.execute(
                "SELECT grant_id FROM policy_autonomy_grants WHERE grant_id=?", (grant_id,)
            ).fetchone()
            if grant is None:
                raise KeyError(f"unknown autonomy grant: {grant_id}")
            latest = self.connection.execute(
                "SELECT to_state FROM policy_grant_transitions WHERE grant_id=? "
                "ORDER BY created_at DESC,transition_id DESC LIMIT 1",
                (grant_id,),
            ).fetchone()
            from_state = str(latest["to_state"]) if latest is not None else None
            allowed = {
                "active": {"suspended", "revoked", "expired", "exhausted"},
                "suspended": {"active", "revoked", "expired"},
                "revoked": set(),
                "expired": set(),
                "exhausted": set(),
            }
            if from_state == to_state:
                existing = self.connection.execute(
                    "SELECT * FROM policy_grant_transitions WHERE transition_id=?",
                    (transition_id,),
                ).fetchone()
                if existing is None:
                    raise ValueError(f"grant is already {to_state}")
            elif to_state not in allowed.get(str(from_state), set()):
                raise ValueError(f"invalid autonomy grant transition: {from_state} -> {to_state}")
            else:
                self.connection.execute(
                    "INSERT INTO policy_grant_transitions VALUES(?,?,?,?,?,?,?,?)",
                    (
                        transition_id,
                        grant_id,
                        from_state,
                        to_state,
                        actor,
                        reason,
                        document_hash,
                        _now(),
                    ),
                )
            self._record_signatures(
                "policy_autonomy_grant_transition",
                transition_id,
                signatures,
                signer_identities,
                decision_document,
            )
        return dict(self.autonomy_grant(grant_id) or {})

    def consume_autonomy_grant(
        self,
        grant_id: str,
        *,
        task_session_id: str,
        capability: str,
        action_hash: str,
    ) -> Mapping[str, Any]:
        with self._write_lock, self.connection:
            grant = self.autonomy_grant(grant_id)
            if grant is None or str(grant["state"]) != "active":
                raise PermissionError("autonomy grant is not active")
            if str(grant["capability"]) != capability:
                raise PermissionError("autonomy grant capability differs")
            uses = int(
                _scalar(
                    self.connection.execute(
                        "SELECT COUNT(*) FROM policy_grant_uses WHERE grant_id=?", (grant_id,)
                    ).fetchone()
                )
            )
            if uses >= int(grant["maximum_uses"]):
                raise PermissionError("autonomy grant use ceiling is exhausted")
            use_id = "grant-use_" + stable_id(grant_id, task_session_id, action_hash)[:32]
            self.connection.execute(
                "INSERT INTO policy_grant_uses VALUES(?,?,?,?,?,?)",
                (use_id, grant_id, task_session_id, capability, action_hash, _now()),
            )
        return dict(self.autonomy_grant(grant_id) or {})

    def _record_signatures(
        self,
        subject_type: str,
        subject_id: str,
        signatures: Sequence[Mapping[str, str]],
        identities: Sequence[Mapping[str, str]],
        document: Mapping[str, Any],
    ) -> None:
        document_hash = (
            "sha256:" + hashlib.sha256(canonical_json(dict(document)).encode("utf-8")).hexdigest()
        )
        for signed, identity in zip(signatures, identities, strict=True):
            key_id = str(identity["key_id"])
            principal = str(identity["principal"])
            self.connection.execute(
                "INSERT INTO policy_signing_keys VALUES(?,?,?,?,?,?,NULL,?) "
                "ON CONFLICT(key_id) DO NOTHING",
                (
                    key_id,
                    principal,
                    "Ed25519",
                    str(identity["public_key"]),
                    str(identity["public_key_fingerprint"]),
                    _now(),
                    _now(),
                ),
            )
            self.connection.execute(
                "INSERT OR IGNORE INTO policy_decision_signatures VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    "signature_" + stable_id(subject_id, key_id, document_hash)[:32],
                    subject_type,
                    subject_id,
                    principal,
                    key_id,
                    "Ed25519",
                    document_hash,
                    str(signed["signature"]),
                    _now(),
                ),
            )

    def policies(
        self, *, status: str | None = None, limit: int = 1000
    ) -> Sequence[Mapping[str, Any]]:
        clauses = []
        values: list[Any] = []
        if status:
            clauses.append("status=?")
            values.append(status)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        values.append(max(1, min(int(limit), 10_000)))
        rows = (
            self._reader()
            .execute(
                "SELECT * FROM policy_authority"
                + where
                + " ORDER BY priority DESC,policy_id LIMIT ?",
                tuple(values),
            )
            .fetchall()
        )
        return [_policy_row(row) for row in rows]

    def set_policy_status(
        self,
        policy_id: str,
        *,
        status: str,
        actor: str,
        reason: str,
        signature: str,
        signer_identity: Mapping[str, str],
        decision_document: Mapping[str, Any],
    ) -> Mapping[str, Any] | None:
        normalized = status.strip().lower()
        if normalized not in {"active", "suspended", "superseded", "expired"}:
            raise ValueError(f"unsupported policy status: {status}")
        if (
            not signature.startswith("ed25519-v2:")
            or str(signer_identity.get("principal")) != actor
        ):
            raise PermissionError("Policy transition requires a verified Ed25519-v2 decision")
        decision_document_hash = (
            "sha256:"
            + hashlib.sha256(canonical_json(dict(decision_document)).encode("utf-8")).hexdigest()
        )
        with self._write_lock, self.connection:
            row = self.connection.execute(
                "SELECT * FROM policy_authority WHERE policy_id=?", (policy_id,)
            ).fetchone()
            if row is None:
                return None
            replay = self.connection.execute(
                "SELECT transition_id FROM policy_authority_transitions "
                "WHERE policy_id=? AND decision_document_hash=?",
                (policy_id, decision_document_hash),
            ).fetchone()
            if replay is not None:
                return _policy_row(row)
            payload = _policy_payload(row)
            payload.update(
                {
                    "status": normalized,
                    "status_changed_at": _now(),
                    "status_changed_by": actor,
                    "status_reason": reason,
                }
            )
            transition_id = (
                "transition_" + stable_id(policy_id, normalized, decision_document_hash)[:32]
            )
            self.connection.execute(
                "INSERT INTO policy_authority_transitions VALUES(?,?,?,?,?,?,?,?)",
                (
                    transition_id,
                    policy_id,
                    str(row["status"]),
                    normalized,
                    actor,
                    reason,
                    decision_document_hash,
                    _now(),
                ),
            )
            self.connection.execute(
                "UPDATE policy_authority SET status=?,payload_json=? WHERE policy_id=?",
                (
                    normalized,
                    json.dumps(payload, sort_keys=True, separators=(",", ":")),
                    policy_id,
                ),
            )
            key_id = str(signer_identity["key_id"])
            self.connection.execute(
                "INSERT INTO policy_signing_keys VALUES(?,?,?,?,?,?,NULL,?) "
                "ON CONFLICT(key_id) DO NOTHING",
                (
                    key_id,
                    actor,
                    "Ed25519",
                    str(signer_identity["public_key"]),
                    str(signer_identity["public_key_fingerprint"]),
                    _now(),
                    _now(),
                ),
            )
            self.connection.execute(
                "INSERT INTO policy_decision_signatures VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    "signature_" + stable_id(policy_id, key_id, decision_document_hash)[:32],
                    "policy_authority_transition",
                    transition_id,
                    actor,
                    key_id,
                    "Ed25519",
                    decision_document_hash,
                    signature,
                    _now(),
                ),
            )
            event_payload = canonical_json(
                {
                    "policy_id": policy_id,
                    "decision_document_hash": decision_document_hash,
                    "principal": actor,
                    "change_kind": normalized,
                }
            )
            sequence = int(
                _scalar(
                    self.connection.execute(
                        "SELECT COUNT(*) FROM policy_authority_transitions WHERE policy_id=?",
                        (policy_id,),
                    ).fetchone()
                )
            )
            self.connection.execute(
                "INSERT INTO domain_outbox VALUES(?,?,?,?,?,?,?,?,?,?,NULL)",
                (
                    "event_" + stable_id(policy_id, normalized, decision_document_hash)[:32],
                    "PolicyDecisionObserved.v1",
                    policy_id,
                    sequence,
                    event_payload,
                    hashlib.sha256(event_payload.encode("utf-8")).hexdigest(),
                    "policy-transition:" + policy_id + ":" + decision_document_hash,
                    policy_id,
                    decision_document_hash,
                    _now(),
                ),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            updated = self.connection.execute(
                "SELECT * FROM policy_authority WHERE policy_id=?", (policy_id,)
            ).fetchone()
        return _policy_row(updated) if updated is not None else None

    def set_policy_status_quorum(
        self,
        policy_id: str,
        *,
        status: str,
        actor: str,
        reason: str,
        signatures: Sequence[Mapping[str, str]],
        signer_identities: Sequence[Mapping[str, str]],
        decision_document: Mapping[str, Any],
    ) -> Mapping[str, Any] | None:
        if len(signatures) != len(signer_identities) or not signer_identities:
            raise PermissionError("Policy transition requires verified signer identities")
        result = self.set_policy_status(
            policy_id,
            status=status,
            actor=actor,
            reason=reason,
            signature=str(signatures[0]["signature"]),
            signer_identity=signer_identities[0],
            decision_document=decision_document,
        )
        document_hash = (
            "sha256:"
            + hashlib.sha256(canonical_json(dict(decision_document)).encode("utf-8")).hexdigest()
        )
        transition_id = (
            "transition_" + stable_id(policy_id, status.strip().lower(), document_hash)[:32]
        )
        with self._write_lock, self.connection:
            self._record_signatures(
                "policy_authority_transition",
                transition_id,
                signatures,
                signer_identities,
                decision_document,
            )
        return result

    def decide_action_proposal(
        self,
        proposal: Mapping[str, Any],
        *,
        decision: str,
        actor: str,
        signature: str,
        reason: str,
        decision_document: Mapping[str, Any] | None = None,
        approvals: Sequence[Mapping[str, str]] = (),
        signer_identities: Sequence[Mapping[str, str]] = (),
    ) -> Mapping[str, Any]:
        """Persist the independent Policy decision and its transactional outbox event."""
        normalized = decision.strip().lower()
        if normalized not in {"approved", "rejected"}:
            raise ValueError("decision must be approved or rejected")
        if not actor or not signature.startswith("ed25519-v2:") or not reason:
            raise PermissionError("Policy decisions require actor, signature, and reason")
        proposal_id = str(proposal["proposal_id"])
        payload = canonical_json(dict(proposal))
        decision_id = "decision_" + stable_id(proposal_id, normalized, signature)[:32]
        now = _now()
        signed_document = dict(decision_document or {})
        document_hash = (
            "sha256:" + hashlib.sha256(canonical_json(signed_document).encode("utf-8")).hexdigest()
        )
        if len(approvals) != len(signer_identities) or not signer_identities:
            raise PermissionError("Policy decision signer identities were not verified")
        event_payload = canonical_json(
            {
                "decision_id": decision_id,
                "proposal_id": proposal_id,
                "decision": normalized,
                "action_class": str(proposal["action_class"]),
                "decided_by": actor,
            }
        )
        event_id = "event_" + stable_id(decision_id, "policy.action_decided.v1")[:32]
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT INTO policy_action_decisions VALUES(?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(proposal_id) DO NOTHING",
                (
                    decision_id,
                    proposal_id,
                    str(proposal["action_class"]),
                    payload,
                    normalized,
                    actor,
                    signature,
                    reason,
                    now,
                ),
            )
            row = self.connection.execute(
                "SELECT * FROM policy_action_decisions WHERE proposal_id=?", (proposal_id,)
            ).fetchone()
            if row is None:
                raise RuntimeError("Policy decision was not persisted")
            actual_id = str(row["decision_id"])
            if actual_id == decision_id:
                for approval, identity in zip(approvals, signer_identities, strict=True):
                    key_id = str(identity["key_id"])
                    principal_id = str(identity["principal"])
                    fingerprint = str(identity["public_key_fingerprint"])
                    self.connection.execute(
                        "INSERT INTO policy_signing_keys VALUES(?,?,?,?,?,?,NULL,?) "
                        "ON CONFLICT(key_id) DO NOTHING",
                        (
                            key_id,
                            principal_id,
                            "Ed25519",
                            str(identity["public_key"]),
                            fingerprint,
                            now,
                            now,
                        ),
                    )
                    self.connection.execute(
                        "INSERT OR IGNORE INTO policy_decision_signatures VALUES(?,?,?,?,?,?,?,?,?)",
                        (
                            "signature_" + stable_id(decision_id, key_id, document_hash)[:32],
                            "policy_action_decision",
                            decision_id,
                            principal_id,
                            key_id,
                            "Ed25519",
                            document_hash,
                            str(approval["signature"]),
                            now,
                        ),
                    )
                self.connection.execute(
                    "INSERT OR IGNORE INTO domain_outbox VALUES(?,?,?,?,?,?,?,?,?,?,NULL)",
                    (
                        event_id,
                        "policy.action_decided.v1",
                        decision_id,
                        1,
                        event_payload,
                        hashlib.sha256(event_payload.encode("utf-8")).hexdigest(),
                        "policy-decision:" + proposal_id,
                        proposal_id,
                        str(proposal.get("capability_record_id") or ""),
                        now,
                    ),
                )
                self.connection.execute(
                    "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
                )
        result = dict(row)
        result["outbox_event_id"] = event_id
        result["outbox_payload_hash"] = hashlib.sha256(event_payload.encode("utf-8")).hexdigest()
        return result

    def action_decision(self, decision_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute("SELECT * FROM policy_action_decisions WHERE decision_id=?", (decision_id,))
            .fetchone()
        )
        return dict(row) if row is not None else None


def _policy_payload(row: Any) -> dict[str, Any]:
    try:
        parsed = json.loads(str(row["payload_json"]))
    except (KeyError, TypeError, json.JSONDecodeError):
        parsed = {}
    return parsed if isinstance(parsed, dict) else {}


def _policy_row(row: Any) -> dict[str, Any]:
    payload = _policy_payload(row)
    return {
        **payload,
        "policy_id": str(row["policy_id"]),
        "scope": str(row["scope"]),
        "priority": int(row["priority"]),
        "status": str(row["status"]),
        "approved_by": str(row["approved_by"]),
        "signature": str(row["signature"]),
        "created_at": str(row["created_at"]),
    }
