from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from ..descriptors import StorageDomain, StoreDescriptor, StoreRole
from .sqlite_base import SQLiteDomainStore, _now
from persistmind.utils import canonical_json, stable_id


class KnowledgeConflict(RuntimeError):
    """A compare-and-swap write lost a concurrent Knowledge update."""

    status = "conflict"


_MEMORY_KIND = "persistmind.knowledge_memory.v1"
_REVISION_KIND = "persistmind.knowledge_memory_revision.v1"
_TRANSITION_KIND = "persistmind.knowledge_memory_transition.v1"


class SQLiteKnowledgeStore(SQLiteDomainStore):
    """Ordinary durable knowledge. It intentionally has no policy mutation API."""

    def __init__(
        self,
        path: Path,
        *,
        descriptor: StoreDescriptor | None = None,
        allow_development_driver: bool = False,
    ) -> None:
        super().__init__(
            path,
            StorageDomain.KNOWLEDGE,
            StoreRole.KNOWLEDGE,
            resource="schemas/knowledge/v1.sql",
            store_id="knowledge-current",
            descriptor=descriptor,
            allow_development_driver=allow_development_driver,
        )

    def evidence(self, record_id: str) -> Sequence[Mapping[str, Any]]:
        records: list[dict[str, Any]] = []
        for row in self._reader().execute(
            "SELECT * FROM knowledge_evidence WHERE record_id=? ORDER BY evidence_id",
            (record_id,),
        ):
            item = dict(row)
            try:
                item["locator"] = json.loads(item.pop("locator_json"))
            except (KeyError, TypeError, json.JSONDecodeError):
                item["locator"] = {}
            records.append(item)
        return records

    def write_claim(
        self,
        claim: Mapping[str, Any],
        *,
        actor: str,
        reason: str,
        expected_revision: int | None = None,
    ) -> Mapping[str, Any]:
        """Create or compare-and-swap a claim with its transition outbox event."""
        claim_id = str(claim["claim_id"])
        payload_json = canonical_json(dict(claim))
        content_hash = hashlib.sha256(payload_json.encode("utf-8")).hexdigest()
        now = _now()
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT * FROM domain_records WHERE record_id=?", (claim_id,)
            ).fetchone()
            from_status = None
            if existing is None:
                if expected_revision not in {None, 0}:
                    raise KnowledgeConflict("claim revision changed")
                revision = 1
                self.connection.execute(
                    "INSERT INTO domain_records VALUES(?,?,?,?,?,?,?,?,?)",
                    (
                        claim_id,
                        "epistemic_claim",
                        str(claim.get("scope") or ""),
                        payload_json,
                        content_hash,
                        revision,
                        now,
                        now,
                        "claim-create:" + claim_id,
                    ),
                )
            else:
                current = self._record(existing)
                current_revision = int(existing["revision"])
                if expected_revision is None or current_revision != expected_revision:
                    raise KnowledgeConflict("claim revision changed")
                from_status = str(current.get("status") or "unknown")
                revision = current_revision + 1
                updated_claim = {**dict(claim), "revision": revision, "transaction_time": now}
                payload_json = canonical_json(updated_claim)
                content_hash = hashlib.sha256(payload_json.encode("utf-8")).hexdigest()
                cursor = self.connection.execute(
                    "UPDATE domain_records SET scope=?,payload_json=?,content_hash=?,"
                    "revision=?,updated_at=? WHERE record_id=? AND revision=?",
                    (
                        str(claim.get("scope") or ""),
                        payload_json,
                        content_hash,
                        revision,
                        now,
                        claim_id,
                        current_revision,
                    ),
                )
                if cursor.rowcount != 1:
                    raise KnowledgeConflict("claim revision changed")
            revision_payload = json.loads(payload_json)
            revision_payload.update(
                {
                    "kind": "epistemic_claim_revision",
                    "claim_id": claim_id,
                    "record_revision": revision,
                    "recorded_at": now,
                }
            )
            revision_json = canonical_json(revision_payload)
            revision_hash = hashlib.sha256(revision_json.encode("utf-8")).hexdigest()
            revision_id = "claim-revision_" + stable_id(claim_id, str(revision))[:32]
            self.connection.execute(
                "INSERT INTO domain_records VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    revision_id,
                    "epistemic_claim_revision",
                    str(claim.get("scope") or ""),
                    revision_json,
                    revision_hash,
                    1,
                    now,
                    now,
                    f"claim-revision:{claim_id}:{revision}",
                ),
            )
            event_payload = canonical_json(
                {
                    "claim_id": claim_id,
                    "from_status": from_status,
                    "to_status": str(claim["status"]),
                    "revision": revision,
                    "content_hash": "sha256:" + content_hash,
                    "actor": actor,
                    "reason": reason,
                }
            )
            event_id = (
                "event_"
                + stable_id("KnowledgeClaimTransitioned.v1", claim_id, str(revision), content_hash)[
                    :32
                ]
            )
            self.connection.execute(
                "INSERT OR IGNORE INTO domain_outbox VALUES(?,?,?,?,?,?,?,?,?,?,NULL)",
                (
                    event_id,
                    "KnowledgeClaimTransitioned.v1",
                    claim_id,
                    revision,
                    event_payload,
                    hashlib.sha256(event_payload.encode("utf-8")).hexdigest(),
                    f"claim-transition:{claim_id}:{revision}",
                    claim_id,
                    None,
                    now,
                ),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            row = self.connection.execute(
                "SELECT * FROM domain_records WHERE record_id=?", (claim_id,)
            ).fetchone()
        if row is None:
            raise RuntimeError("claim write did not persist")
        result = dict(self._record(row))
        result["transition_event_id"] = event_id
        return result

    def claim_revisions(self, claim_id: str) -> Sequence[Mapping[str, Any]]:
        rows = (
            self._reader()
            .execute(
                "SELECT * FROM domain_records WHERE kind='epistemic_claim_revision' "
                "ORDER BY created_at,record_id"
            )
            .fetchall()
        )
        values = [self._record(row) for row in rows]
        return [item for item in values if str(item.get("claim_id")) == claim_id]

    def put_evidence(
        self,
        record_id: str,
        locator: Mapping[str, Any],
        *,
        content_hash: str,
        trust: str,
    ) -> str:
        """Attach immutable, content-addressed evidence to a Knowledge record."""

        locator_json = json.dumps(dict(locator), sort_keys=True, separators=(",", ":"))
        evidence_id = (
            "evidence_"
            + hashlib.sha256(
                "\x1f".join((record_id, locator_json, content_hash, trust)).encode("utf-8")
            ).hexdigest()[:32]
        )
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT evidence_id FROM knowledge_evidence WHERE evidence_id=?",
                (evidence_id,),
            ).fetchone()
            if existing is None:
                self.connection.execute(
                    "INSERT INTO knowledge_evidence("
                    "evidence_id,record_id,locator_json,content_hash,trust,created_at"
                    ") VALUES(?,?,?,?,?,?)",
                    (evidence_id, record_id, locator_json, content_hash, trust, _now()),
                )
                self.connection.execute(
                    "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
                )
        return evidence_id

    def memory_records(
        self,
        *,
        status: str | None = None,
        types: Sequence[str] | None = None,
        limit: int = 1000,
    ) -> Sequence[Mapping[str, Any]]:
        """Return only canonical memory records, never their internal history rows."""

        rows = self._records_with_kind(_MEMORY_KIND, limit=limit)
        allowed_types = {str(item) for item in types or ()}
        return [
            row
            for row in rows
            if (status is None or str(row.get("status")) == status)
            and (not allowed_types or str(row.get("type")) in allowed_types)
        ]

    def memory_revisions(self, record_id: str) -> Sequence[Mapping[str, Any]]:
        rows = self._records_with_kind(_REVISION_KIND, limit=10_000)
        matched = [row for row in rows if str(row.get("record_id")) == record_id]
        return sorted(
            matched,
            key=lambda item: (
                int(item.get("record_revision") or 0),
                str(item.get("recorded_at") or ""),
                str(item.get("revision_id") or ""),
            ),
        )

    def memory_transitions(self, record_id: str) -> Sequence[Mapping[str, Any]]:
        rows = self._records_with_kind(_TRANSITION_KIND, limit=10_000)
        matched = [row for row in rows if str(row.get("record_id")) == record_id]
        return sorted(
            matched,
            key=lambda item: (
                int(item.get("record_revision") or 0),
                str(item.get("recorded_at") or ""),
                str(item.get("transition_id") or ""),
            ),
        )

    def write_memory_record(
        self,
        record: Mapping[str, Any],
        *,
        actor: str,
        reason: str,
        expected_revision: int | None = None,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        """Atomically commit a canonical memory record and its immutable history.

        The Knowledge schema intentionally stays compact.  Canonical rows,
        revisions, and state transitions all use ``domain_records`` with distinct
        kinds, so a fresh PersistMind next-generation workspace does not need a schema rewrite merely
        to gain revision history.  The operation is a single SQLite transaction
        and supports compare-and-swap for callers that carry a record revision.
        """

        document = _without_internal_fields(record)
        record_id = str(document.get("record_id") or "").strip()
        if not record_id:
            raise ValueError("knowledge memory record_id is required")
        document["record_id"] = record_id
        document["kind"] = "memory"
        document.setdefault("schema_version", "persistmind.knowledge_record.v1")
        document.setdefault("created_at", _now())
        document["updated_at"] = _now()
        document_json = json.dumps(document, sort_keys=True, separators=(",", ":"))
        content_hash = hashlib.sha256(document_json.encode("utf-8")).hexdigest()
        scope = str(document.get("scope") or "")
        now = str(document["updated_at"])

        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT * FROM domain_records WHERE record_id=?", (record_id,)
            ).fetchone()
            if existing is not None and str(existing["kind"]) != _MEMORY_KIND:
                raise ValueError(f"record_id belongs to a non-memory Knowledge record: {record_id}")
            current_revision = int(existing["revision"]) if existing is not None else 0
            if expected_revision is not None and expected_revision != current_revision:
                raise KnowledgeConflict(
                    f"stale knowledge memory revision for {record_id}: "
                    f"expected {expected_revision}, current {current_revision}"
                )
            if idempotency_key:
                idempotent = self.connection.execute(
                    "SELECT * FROM domain_records WHERE idempotency_key=?",
                    (idempotency_key,),
                ).fetchone()
                if idempotent is not None:
                    if str(idempotent["record_id"]) != record_id:
                        raise KnowledgeConflict(
                            f"knowledge idempotency key belongs to {idempotent['record_id']}"
                        )
                    return self._record(idempotent)

            next_revision = current_revision + 1
            if existing is None:
                self.connection.execute(
                    "INSERT INTO domain_records("
                    "record_id,kind,scope,payload_json,content_hash,revision,created_at,updated_at,idempotency_key"
                    ") VALUES(?,?,?,?,?,?,?,?,?)",
                    (
                        record_id,
                        _MEMORY_KIND,
                        scope,
                        document_json,
                        content_hash,
                        next_revision,
                        str(document["created_at"]),
                        now,
                        idempotency_key,
                    ),
                )
                previous_document: Mapping[str, Any] | None = None
            else:
                self.connection.execute(
                    "UPDATE domain_records SET scope=?,payload_json=?,content_hash=?,revision=?,updated_at=?,idempotency_key=? "
                    "WHERE record_id=?",
                    (
                        scope,
                        document_json,
                        content_hash,
                        next_revision,
                        now,
                        idempotency_key or existing["idempotency_key"],
                        record_id,
                    ),
                )
                previous_document = self._record(existing)

            revision_id = (
                "knowledge_revision_"
                + hashlib.sha256(
                    "\x1f".join((record_id, str(next_revision), content_hash)).encode("utf-8")
                ).hexdigest()[:32]
            )
            revision_document = {
                "schema_version": "persistmind.knowledge_revision.v1",
                "kind": "memory_revision",
                "revision_id": revision_id,
                "record_id": record_id,
                "record_revision": next_revision,
                "record": document,
                "actor": actor,
                "reason": reason,
                "recorded_at": now,
            }
            self._insert_history_record(
                revision_id,
                _REVISION_KIND,
                scope,
                revision_document,
                now,
            )

            previous_status = (
                str(previous_document.get("status"))
                if previous_document is not None and previous_document.get("status") is not None
                else None
            )
            current_status = str(document.get("status") or "candidate")
            if previous_document is None or previous_status != current_status:
                transition_id = (
                    "knowledge_transition_"
                    + hashlib.sha256(
                        "\x1f".join(
                            (
                                record_id,
                                str(next_revision),
                                previous_status or "",
                                current_status,
                                actor,
                                reason,
                            )
                        ).encode("utf-8")
                    ).hexdigest()[:32]
                )
                transition_document = {
                    "schema_version": "persistmind.knowledge_transition.v1",
                    "kind": "memory_transition",
                    "transition_id": transition_id,
                    "record_id": record_id,
                    "record_revision": next_revision,
                    "from_status": previous_status,
                    "to_status": current_status,
                    "actor": actor,
                    "reason": reason,
                    "recorded_at": now,
                }
                self._insert_history_record(
                    transition_id,
                    _TRANSITION_KIND,
                    scope,
                    transition_document,
                    now,
                )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            row = self.connection.execute(
                "SELECT * FROM domain_records WHERE record_id=?", (record_id,)
            ).fetchone()
        if row is None:  # pragma: no cover - transaction guarantees this.
            raise RuntimeError(f"knowledge memory write did not persist: {record_id}")
        return self._record(row)

    def _records_with_kind(self, kind: str, *, limit: int) -> list[Mapping[str, Any]]:
        rows = (
            self._reader()
            .execute(
                "SELECT * FROM domain_records WHERE kind=? "
                "ORDER BY updated_at DESC,record_id LIMIT ?",
                (kind, max(1, min(int(limit), 10_000))),
            )
            .fetchall()
        )
        return [self._record(row) for row in rows]

    def _insert_history_record(
        self,
        record_id: str,
        kind: str,
        scope: str,
        document: Mapping[str, Any],
        now: str,
    ) -> None:
        payload_json = json.dumps(dict(document), sort_keys=True, separators=(",", ":"))
        content_hash = hashlib.sha256(payload_json.encode("utf-8")).hexdigest()
        self.connection.execute(
            "INSERT OR IGNORE INTO domain_records("
            "record_id,kind,scope,payload_json,content_hash,revision,created_at,updated_at,idempotency_key"
            ") VALUES(?,?,?,?,?,1,?,?,NULL)",
            (record_id, kind, scope, payload_json, content_hash, now, now),
        )


def _without_internal_fields(record: Mapping[str, Any]) -> dict[str, Any]:
    return {
        str(key): value
        for key, value in dict(record).items()
        if key not in {"_revision", "_content_hash"}
    }
