from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from persistmind.utils import canonical_json, stable_id

from ..descriptors import StorageDomain, StoreDescriptor, StoreRole
from .sqlite_base import SQLiteDomainStore, _now


class KnowledgeConflict(RuntimeError):
    """A compare-and-swap write lost a concurrent Knowledge update."""

    status = "conflict"


_MEMORY_KIND = "persistmind.knowledge_memory.v1"
_REVISION_KIND = "persistmind.knowledge_memory_revision.v1"
_TRANSITION_KIND = "persistmind.knowledge_memory_transition.v1"
_MEMORY_EDGE_KINDS = {
    "supersedes",
    "contradicts",
    "derived_from",
    "causes",
    "co_occurs_with",
    "relates_to",
}


class SQLiteKnowledgeStore(SQLiteDomainStore):
    """Ordinary durable knowledge. It intentionally has no policy mutation API."""

    def __init__(
        self,
        path: Path,
        *,
        descriptor: StoreDescriptor | None = None,
        allow_development_driver: bool = False,
    ) -> None:
        super().__init__(
            path,
            StorageDomain.KNOWLEDGE,
            StoreRole.KNOWLEDGE,
            resource="schemas/knowledge/v1.sql",
            store_id="knowledge-current",
            descriptor=descriptor,
            allow_development_driver=allow_development_driver,
        )

    def evidence(self, record_id: str) -> Sequence[Mapping[str, Any]]:
        records: list[dict[str, Any]] = []
        for row in self._reader().execute(
            "SELECT * FROM knowledge_evidence WHERE record_id=? ORDER BY evidence_id",
            (record_id,),
        ):
            item = dict(row)
            try:
                item["locator"] = json.loads(item.pop("locator_json"))
            except (KeyError, TypeError, json.JSONDecodeError):
                item["locator"] = {}
            records.append(item)
        return records

    def write_claim(
        self,
        claim: Mapping[str, Any],
        *,
        actor: str,
        reason: str,
        expected_revision: int | None = None,
    ) -> Mapping[str, Any]:
        """Create or compare-and-swap a claim with its transition outbox event."""
        claim_id = str(claim["claim_id"])
        payload_json = canonical_json(dict(claim))
        content_hash = hashlib.sha256(payload_json.encode("utf-8")).hexdigest()
        now = _now()
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT * FROM domain_records WHERE record_id=?", (claim_id,)
            ).fetchone()
            from_status = None
            if existing is None:
                if expected_revision not in {None, 0}:
                    raise KnowledgeConflict("claim revision changed")
                revision = 1
                self.connection.execute(
                    "INSERT INTO domain_records VALUES(?,?,?,?,?,?,?,?,?)",
                    (
                        claim_id,
                        "epistemic_claim",
                        str(claim.get("scope") or ""),
                        payload_json,
                        content_hash,
                        revision,
                        now,
                        now,
                        "claim-create:" + claim_id,
                    ),
                )
            else:
                current = self._record(existing)
                current_revision = int(existing["revision"])
                if expected_revision is None or current_revision != expected_revision:
                    raise KnowledgeConflict("claim revision changed")
                from_status = str(current.get("status") or "unknown")
                revision = current_revision + 1
                updated_claim = {**dict(claim), "revision": revision, "transaction_time": now}
                payload_json = canonical_json(updated_claim)
                content_hash = hashlib.sha256(payload_json.encode("utf-8")).hexdigest()
                cursor = self.connection.execute(
                    "UPDATE domain_records SET scope=?,payload_json=?,content_hash=?,"
                    "revision=?,updated_at=? WHERE record_id=? AND revision=?",
                    (
                        str(claim.get("scope") or ""),
                        payload_json,
                        content_hash,
                        revision,
                        now,
                        claim_id,
                        current_revision,
                    ),
                )
                if cursor.rowcount != 1:
                    raise KnowledgeConflict("claim revision changed")
            revision_payload = json.loads(payload_json)
            revision_payload.update(
                {
                    "kind": "epistemic_claim_revision",
                    "claim_id": claim_id,
                    "record_revision": revision,
                    "recorded_at": now,
                }
            )
            revision_json = canonical_json(revision_payload)
            revision_hash = hashlib.sha256(revision_json.encode("utf-8")).hexdigest()
            revision_id = "claim-revision_" + stable_id(claim_id, str(revision))[:32]
            self.connection.execute(
                "INSERT INTO domain_records VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    revision_id,
                    "epistemic_claim_revision",
                    str(claim.get("scope") or ""),
                    revision_json,
                    revision_hash,
                    1,
                    now,
                    now,
                    f"claim-revision:{claim_id}:{revision}",
                ),
            )
            event_payload = canonical_json(
                {
                    "claim_id": claim_id,
                    "from_status": from_status,
                    "to_status": str(claim["status"]),
                    "revision": revision,
                    "content_hash": "sha256:" + content_hash,
                    "actor": actor,
                    "reason": reason,
                }
            )
            event_id = (
                "event_"
                + stable_id("KnowledgeClaimTransitioned.v1", claim_id, str(revision), content_hash)[
                    :32
                ]
            )
            self.connection.execute(
                "INSERT OR IGNORE INTO domain_outbox VALUES(?,?,?,?,?,?,?,?,?,?,NULL)",
                (
                    event_id,
                    "KnowledgeClaimTransitioned.v1",
                    claim_id,
                    revision,
                    event_payload,
                    hashlib.sha256(event_payload.encode("utf-8")).hexdigest(),
                    f"claim-transition:{claim_id}:{revision}",
                    claim_id,
                    None,
                    now,
                ),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            row = self.connection.execute(
                "SELECT * FROM domain_records WHERE record_id=?", (claim_id,)
            ).fetchone()
        if row is None:
            raise RuntimeError("claim write did not persist")
        result = dict(self._record(row))
        result["transition_event_id"] = event_id
        return result

    def claim_revisions(self, claim_id: str) -> Sequence[Mapping[str, Any]]:
        rows = (
            self._reader()
            .execute(
                "SELECT * FROM domain_records WHERE kind='epistemic_claim_revision' "
                "ORDER BY created_at,record_id"
            )
            .fetchall()
        )
        values = [self._record(row) for row in rows]
        return [item for item in values if str(item.get("claim_id")) == claim_id]

    def put_evidence(
        self,
        record_id: str,
        locator: Mapping[str, Any],
        *,
        content_hash: str,
        trust: str,
    ) -> str:
        """Attach immutable, content-addressed evidence to a Knowledge record."""

        locator_json = json.dumps(dict(locator), sort_keys=True, separators=(",", ":"))
        evidence_id = (
            "evidence_"
            + hashlib.sha256(
                "\x1f".join((record_id, locator_json, content_hash, trust)).encode("utf-8")
            ).hexdigest()[:32]
        )
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT evidence_id FROM knowledge_evidence WHERE evidence_id=?",
                (evidence_id,),
            ).fetchone()
            if existing is None:
                self.connection.execute(
                    "INSERT INTO knowledge_evidence("
                    "evidence_id,record_id,locator_json,content_hash,trust,created_at"
                    ") VALUES(?,?,?,?,?,?)",
                    (evidence_id, record_id, locator_json, content_hash, trust, _now()),
                )
                self.connection.execute(
                    "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
                )
        return evidence_id

    def memory_records(
        self,
        *,
        status: str | None = None,
        types: Sequence[str] | None = None,
        limit: int = 1000,
    ) -> Sequence[Mapping[str, Any]]:
        """Return only canonical memory records, never their internal history rows."""

        rows = self._memory_record_rows(status=status, types=types, limit=limit)
        return [self._record(row) for row in rows]

    def memory_record_count(
        self,
        *,
        status: str | None = None,
        types: Sequence[str] | None = None,
    ) -> int:
        sql, params = self._memory_record_query(
            status=status,
            types=types,
            select="COUNT(*) AS count",
            order=False,
            limit=None,
        )
        row = self._reader().execute(sql, params).fetchone()
        return int(row["count"] if row is not None else 0)

    def memory_fts_search(
        self,
        query: str,
        *,
        status: str | None = None,
        types: Sequence[str] | None = None,
        limit: int = 100,
    ) -> Sequence[Mapping[str, Any]]:
        terms = _fts_terms(query)
        if not terms:
            return []
        clauses = ["r.kind=?"]
        params: list[Any] = [_MEMORY_KIND]
        if status is not None:
            clauses.append("json_extract(r.payload_json,'$.status')=?")
            params.append(str(status))
        allowed_types = sorted({str(item) for item in types or () if str(item)})
        if allowed_types:
            placeholders = ",".join("?" for _ in allowed_types)
            clauses.append(f"json_extract(r.payload_json,'$.type') IN ({placeholders})")
            params.extend(allowed_types)
        params.extend((_fts_expression(terms), max(1, min(int(limit), 10_000))))
        rows = self._reader().execute(
            "SELECT r.*,bm25(knowledge_memory_fts) AS fts_rank "
            "FROM knowledge_memory_fts "
            "JOIN domain_records r ON r.record_id=knowledge_memory_fts.record_id "
            "WHERE "
            + " AND ".join(clauses)
            + " AND knowledge_memory_fts MATCH ? "
            "ORDER BY fts_rank,r.updated_at DESC,r.record_id LIMIT ?",
            tuple(params),
        ).fetchall()
        records = []
        for row in rows:
            record = self._record(row)
            record["_fts_rank"] = float(row["fts_rank"])
            records.append(record)
        return records

    def memory_edge_create(
        self,
        src_record_id: str,
        dst_record_id: str,
        kind: str,
        *,
        weight: float = 1.0,
        evidence: Sequence[Mapping[str, Any]] | None = None,
    ) -> Mapping[str, Any]:
        kind = str(kind).strip()
        if kind not in _MEMORY_EDGE_KINDS:
            raise ValueError(f"unsupported memory edge kind: {kind}")
        if src_record_id == dst_record_id:
            raise ValueError("memory edge endpoints must be distinct")
        now = _now()
        edge_id = "memory_edge_" + stable_id(src_record_id, dst_record_id, kind)[:32]
        evidence_json = json.dumps(list(evidence or ()), sort_keys=True, separators=(",", ":"))
        bounded_weight = max(0.0, min(float(weight), 1.0))
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT INTO memory_edges("
                "edge_id,src_record_id,dst_record_id,kind,weight,evidence_json,created_at,updated_at"
                ") VALUES(?,?,?,?,?,?,?,?) "
                "ON CONFLICT(src_record_id,dst_record_id,kind) DO UPDATE SET "
                "weight=excluded.weight,evidence_json=excluded.evidence_json,updated_at=excluded.updated_at",
                (
                    edge_id,
                    src_record_id,
                    dst_record_id,
                    kind,
                    bounded_weight,
                    evidence_json,
                    now,
                    now,
                ),
            )
            row = self.connection.execute(
                "SELECT * FROM memory_edges WHERE edge_id=?", (edge_id,)
            ).fetchone()
        return self._memory_edge(row)

    def memory_edges(self, record_id: str | None = None) -> Sequence[Mapping[str, Any]]:
        if record_id:
            rows = self._reader().execute(
                "SELECT * FROM memory_edges WHERE src_record_id=? OR dst_record_id=? "
                "ORDER BY updated_at DESC,edge_id",
                (record_id, record_id),
            )
        else:
            rows = self._reader().execute(
                "SELECT * FROM memory_edges ORDER BY updated_at DESC,edge_id"
            )
        return [self._memory_edge(row) for row in rows.fetchall()]

    def memory_graph_walk(
        self,
        record_id: str,
        *,
        max_hops: int = 2,
        limit: int = 100,
    ) -> Mapping[str, Sequence[Mapping[str, Any]]]:
        max_hops = max(1, min(int(max_hops), 10))
        limit = max(1, min(int(limit), 1000))
        seen = {record_id}
        frontier = {record_id}
        edges: list[Mapping[str, Any]] = []
        for hop in range(max_hops):
            if not frontier or len(seen) >= limit:
                break
            placeholders = ",".join("?" for _ in frontier)
            rows = self._reader().execute(
                "SELECT * FROM memory_edges "
                f"WHERE src_record_id IN ({placeholders}) OR dst_record_id IN ({placeholders}) "
                "ORDER BY weight DESC,updated_at DESC,edge_id",
                tuple(frontier) + tuple(frontier),
            ).fetchall()
            next_frontier: set[str] = set()
            for row in rows:
                edge = self._memory_edge(row)
                edge["hop"] = hop + 1
                edges.append(edge)
                for endpoint in (str(edge["source"]), str(edge["target"])):
                    if endpoint not in seen:
                        seen.add(endpoint)
                        next_frontier.add(endpoint)
                if len(seen) >= limit:
                    break
            frontier = next_frontier
        records = [
            self.get(item)
            for item in sorted(seen)
            if self.get(item) is not None
        ]
        return {"nodes": records[:limit], "edges": edges[:limit]}

    def upsert_memory_conflict(
        self,
        left_record_id: str,
        right_record_id: str,
        *,
        subject_key: str,
        summary: str,
        kind: str = "semantic_conflict",
        severity: str = "medium",
        status: str = "open",
        metadata: Mapping[str, Any] | None = None,
    ) -> Mapping[str, Any]:
        left, right = sorted((left_record_id, right_record_id))
        now = _now()
        conflict_id = "memory_conflict_" + stable_id(left, right, kind)[:32]
        metadata_json = json.dumps(dict(metadata or {}), sort_keys=True, separators=(",", ":"))
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT INTO memory_conflicts("
                "conflict_id,left_record_id,right_record_id,subject_key,kind,summary,severity,"
                "status,detected_at,resolved_at,metadata_json"
                ") VALUES(?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(left_record_id,right_record_id,kind) DO UPDATE SET "
                "subject_key=excluded.subject_key,summary=excluded.summary,severity=excluded.severity,"
                "status=CASE WHEN memory_conflicts.status='resolved' THEN memory_conflicts.status ELSE excluded.status END,"
                "metadata_json=excluded.metadata_json",
                (
                    conflict_id,
                    left,
                    right,
                    subject_key,
                    kind,
                    summary,
                    severity,
                    status,
                    now,
                    None,
                    metadata_json,
                ),
            )
            row = self.connection.execute(
                "SELECT * FROM memory_conflicts WHERE conflict_id=?", (conflict_id,)
            ).fetchone()
        return self._memory_conflict(row)

    def memory_conflicts(self, *, status: str | None = None) -> Sequence[Mapping[str, Any]]:
        if status:
            rows = self._reader().execute(
                "SELECT * FROM memory_conflicts WHERE status=? ORDER BY detected_at DESC,conflict_id",
                (status,),
            ).fetchall()
        else:
            rows = self._reader().execute(
                "SELECT * FROM memory_conflicts ORDER BY detected_at DESC,conflict_id"
            ).fetchall()
        return [self._memory_conflict(row) for row in rows]

    def memory_vector_upsert(
        self,
        record_id: str,
        *,
        model_name: str,
        vector: Sequence[float],
        encoding: str = "json",
    ) -> None:
        values = [float(item) for item in vector]
        blob = json.dumps(values, separators=(",", ":")).encode("utf-8")
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT INTO memory_vectors(record_id,model_name,dims,encoding,vector_blob,updated_at) "
                "VALUES(?,?,?,?,?,?) "
                "ON CONFLICT(record_id,model_name) DO UPDATE SET "
                "dims=excluded.dims,encoding=excluded.encoding,vector_blob=excluded.vector_blob,"
                "updated_at=excluded.updated_at",
                (record_id, model_name, len(values), encoding, blob, _now()),
            )

    def memory_vector(self, record_id: str, *, model_name: str) -> list[float] | None:
        row = self._reader().execute(
            "SELECT vector_blob,encoding FROM memory_vectors WHERE record_id=? AND model_name=?",
            (record_id, model_name),
        ).fetchone()
        if row is None:
            return None
        if str(row["encoding"]) != "json":
            return None
        try:
            return [float(item) for item in json.loads(bytes(row["vector_blob"]).decode("utf-8"))]
        except (TypeError, ValueError, json.JSONDecodeError):
            return None

    def memory_fts_upsert(self, record: Mapping[str, Any]) -> None:
        metadata = json.dumps(dict(record.get("metadata") or {}), sort_keys=True)
        with self._write_lock, self.connection:
            self.connection.execute(
                "DELETE FROM knowledge_memory_fts WHERE record_id=?",
                (str(record["record_id"]),),
            )
            self.connection.execute(
                "INSERT INTO knowledge_memory_fts(record_id,assertion,title,metadata) VALUES(?,?,?,?)",
                (
                    str(record["record_id"]),
                    str(record.get("assertion") or ""),
                    str(record.get("title") or ""),
                    metadata,
                ),
            )

    def working_memory_note_write(
        self,
        note: Mapping[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        del idempotency_key
        now = _now()
        note_id = str(note.get("note_id") or stable_id(canonical_json(dict(note)))[:32])
        metadata_json = json.dumps(
            dict(note.get("metadata") or {}), sort_keys=True, separators=(",", ":")
        )
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT INTO working_memory_notes("
                "note_id,task_session_id,content,salience,metadata_json,superseded_by,"
                "created_at,updated_at,expires_at"
                ") VALUES(?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(note_id) DO UPDATE SET "
                "content=excluded.content,salience=excluded.salience,metadata_json=excluded.metadata_json,"
                "superseded_by=excluded.superseded_by,updated_at=excluded.updated_at,expires_at=excluded.expires_at",
                (
                    note_id,
                    note.get("task_session_id"),
                    str(note.get("content") or ""),
                    max(0.0, min(float(note.get("salience") or 0.5), 1.0)),
                    metadata_json,
                    note.get("superseded_by"),
                    str(note.get("created_at") or now),
                    now,
                    note.get("expires_at"),
                ),
            )
            row = self.connection.execute(
                "SELECT * FROM working_memory_notes WHERE note_id=?", (note_id,)
            ).fetchone()
        return self._working_memory_note(row)

    def working_memory_notes(
        self,
        *,
        task_session_id: str | None = None,
        active_only: bool = True,
        limit: int = 100,
    ) -> Sequence[Mapping[str, Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        if task_session_id:
            clauses.append("task_session_id=?")
            params.append(task_session_id)
        if active_only:
            clauses.append("superseded_by IS NULL")
            clauses.append("(expires_at IS NULL OR expires_at > datetime('now'))")
        sql = "SELECT * FROM working_memory_notes"
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY salience DESC,updated_at DESC,note_id LIMIT ?"
        params.append(max(1, min(int(limit), 1000)))
        rows = self._reader().execute(sql, tuple(params)).fetchall()
        return [self._working_memory_note(row) for row in rows]

    def memory_hard_delete_terminal(
        self,
        *,
        statuses: Sequence[str],
        before: str,
        limit: int = 1000,
    ) -> Sequence[str]:
        allowed = sorted({str(item) for item in statuses if str(item)})
        if not allowed:
            return []
        placeholders = ",".join("?" for _ in allowed)
        with self._write_lock, self.connection:
            rows = self.connection.execute(
                "SELECT record_id FROM domain_records WHERE kind=? "
                f"AND json_extract(payload_json,'$.status') IN ({placeholders}) "
                "AND updated_at < ? ORDER BY updated_at,record_id LIMIT ?",
                (_MEMORY_KIND, *allowed, before, max(1, min(int(limit), 1000))),
            ).fetchall()
            ids = [str(row["record_id"]) for row in rows]
            if ids:
                id_placeholders = ",".join("?" for _ in ids)
                self.connection.execute(
                    f"DELETE FROM domain_records WHERE record_id IN ({id_placeholders})",
                    tuple(ids),
                )
                self.connection.execute(
                    "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
                )
        return ids

    def memory_revisions(self, record_id: str) -> Sequence[Mapping[str, Any]]:
        rows = self._records_with_kind(_REVISION_KIND, limit=10_000)
        matched = [row for row in rows if str(row.get("record_id")) == record_id]
        return sorted(
            matched,
            key=lambda item: (
                int(item.get("record_revision") or 0),
                str(item.get("recorded_at") or ""),
                str(item.get("revision_id") or ""),
            ),
        )

    def memory_transitions(self, record_id: str) -> Sequence[Mapping[str, Any]]:
        rows = self._records_with_kind(_TRANSITION_KIND, limit=10_000)
        matched = [row for row in rows if str(row.get("record_id")) == record_id]
        return sorted(
            matched,
            key=lambda item: (
                int(item.get("record_revision") or 0),
                str(item.get("recorded_at") or ""),
                str(item.get("transition_id") or ""),
            ),
        )

    def write_memory_record(
        self,
        record: Mapping[str, Any],
        *,
        actor: str,
        reason: str,
        expected_revision: int | None = None,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        """Atomically commit a canonical memory record and its immutable history.

        The Knowledge schema intentionally stays compact.  Canonical rows,
        revisions, and state transitions all use ``domain_records`` with distinct
        kinds, so a fresh PersistMind next-generation workspace does not need a schema rewrite merely
        to gain revision history.  The operation is a single SQLite transaction
        and supports compare-and-swap for callers that carry a record revision.
        """

        document = _without_internal_fields(record)
        record_id = str(document.get("record_id") or "").strip()
        if not record_id:
            raise ValueError("knowledge memory record_id is required")
        document["record_id"] = record_id
        document["kind"] = "memory"
        document.setdefault("schema_version", "persistmind.knowledge_record.v1")
        document.setdefault("created_at", _now())
        document["updated_at"] = _now()
        document_json = json.dumps(document, sort_keys=True, separators=(",", ":"))
        content_hash = hashlib.sha256(document_json.encode("utf-8")).hexdigest()
        scope = str(document.get("scope") or "")
        now = str(document["updated_at"])

        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT * FROM domain_records WHERE record_id=?", (record_id,)
            ).fetchone()
            if existing is not None and str(existing["kind"]) != _MEMORY_KIND:
                raise ValueError(f"record_id belongs to a non-memory Knowledge record: {record_id}")
            current_revision = int(existing["revision"]) if existing is not None else 0
            if expected_revision is not None and expected_revision != current_revision:
                raise KnowledgeConflict(
                    f"stale knowledge memory revision for {record_id}: "
                    f"expected {expected_revision}, current {current_revision}"
                )
            if idempotency_key:
                idempotent = self.connection.execute(
                    "SELECT * FROM domain_records WHERE idempotency_key=?",
                    (idempotency_key,),
                ).fetchone()
                if idempotent is not None:
                    if str(idempotent["record_id"]) != record_id:
                        raise KnowledgeConflict(
                            f"knowledge idempotency key belongs to {idempotent['record_id']}"
                        )
                    return self._record(idempotent)

            next_revision = current_revision + 1
            if existing is None:
                self.connection.execute(
                    "INSERT INTO domain_records("
                    "record_id,kind,scope,payload_json,content_hash,revision,created_at,updated_at,idempotency_key"
                    ") VALUES(?,?,?,?,?,?,?,?,?)",
                    (
                        record_id,
                        _MEMORY_KIND,
                        scope,
                        document_json,
                        content_hash,
                        next_revision,
                        str(document["created_at"]),
                        now,
                        idempotency_key,
                    ),
                )
                previous_document: Mapping[str, Any] | None = None
            else:
                self.connection.execute(
                    "UPDATE domain_records SET scope=?,payload_json=?,content_hash=?,revision=?,updated_at=?,idempotency_key=? "
                    "WHERE record_id=?",
                    (
                        scope,
                        document_json,
                        content_hash,
                        next_revision,
                        now,
                        idempotency_key or existing["idempotency_key"],
                        record_id,
                    ),
                )
                previous_document = self._record(existing)

            revision_id = (
                "knowledge_revision_"
                + hashlib.sha256(
                    "\x1f".join((record_id, str(next_revision), content_hash)).encode("utf-8")
                ).hexdigest()[:32]
            )
            revision_document = {
                "schema_version": "persistmind.knowledge_revision.v1",
                "kind": "memory_revision",
                "revision_id": revision_id,
                "record_id": record_id,
                "record_revision": next_revision,
                "record": document,
                "actor": actor,
                "reason": reason,
                "recorded_at": now,
            }
            self._insert_history_record(
                revision_id,
                _REVISION_KIND,
                scope,
                revision_document,
                now,
            )

            previous_status = (
                str(previous_document.get("status"))
                if previous_document is not None and previous_document.get("status") is not None
                else None
            )
            current_status = str(document.get("status") or "candidate")
            if previous_document is None or previous_status != current_status:
                transition_id = (
                    "knowledge_transition_"
                    + hashlib.sha256(
                        "\x1f".join(
                            (
                                record_id,
                                str(next_revision),
                                previous_status or "",
                                current_status,
                                actor,
                                reason,
                            )
                        ).encode("utf-8")
                    ).hexdigest()[:32]
                )
                transition_document = {
                    "schema_version": "persistmind.knowledge_transition.v1",
                    "kind": "memory_transition",
                    "transition_id": transition_id,
                    "record_id": record_id,
                    "record_revision": next_revision,
                    "from_status": previous_status,
                    "to_status": current_status,
                    "actor": actor,
                    "reason": reason,
                    "recorded_at": now,
                }
                self._insert_history_record(
                    transition_id,
                    _TRANSITION_KIND,
                    scope,
                    transition_document,
                    now,
                )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            row = self.connection.execute(
                "SELECT * FROM domain_records WHERE record_id=?", (record_id,)
            ).fetchone()
        if row is None:  # pragma: no cover - transaction guarantees this.
            raise RuntimeError(f"knowledge memory write did not persist: {record_id}")
        return self._record(row)

    def _records_with_kind(self, kind: str, *, limit: int) -> list[Mapping[str, Any]]:
        rows = (
            self._reader()
            .execute(
                "SELECT * FROM domain_records WHERE kind=? "
                "ORDER BY updated_at DESC,record_id LIMIT ?",
                (kind, max(1, min(int(limit), 10_000))),
            )
            .fetchall()
        )
        return [self._record(row) for row in rows]

    def _memory_record_rows(
        self,
        *,
        status: str | None,
        types: Sequence[str] | None,
        limit: int,
    ) -> list[Any]:
        sql, params = self._memory_record_query(
            status=status,
            types=types,
            select="*",
            order=True,
            limit=max(1, min(int(limit), 10_000)),
        )
        return list(self._reader().execute(sql, params).fetchall())

    def _memory_record_query(
        self,
        *,
        status: str | None,
        types: Sequence[str] | None,
        select: str,
        order: bool,
        limit: int | None,
    ) -> tuple[str, tuple[Any, ...]]:
        clauses = ["kind=?"]
        params: list[Any] = [_MEMORY_KIND]
        if status is not None:
            clauses.append("json_extract(payload_json,'$.status')=?")
            params.append(str(status))
        allowed_types = sorted({str(item) for item in types or () if str(item)})
        if allowed_types:
            placeholders = ",".join("?" for _ in allowed_types)
            clauses.append(f"json_extract(payload_json,'$.type') IN ({placeholders})")
            params.extend(allowed_types)
        sql = f"SELECT {select} FROM domain_records WHERE " + " AND ".join(clauses)
        if order:
            sql += " ORDER BY updated_at DESC,record_id"
        if limit is not None:
            sql += " LIMIT ?"
            params.append(limit)
        return sql, tuple(params)

    def _insert_history_record(
        self,
        record_id: str,
        kind: str,
        scope: str,
        document: Mapping[str, Any],
        now: str,
    ) -> None:
        payload_json = json.dumps(dict(document), sort_keys=True, separators=(",", ":"))
        content_hash = hashlib.sha256(payload_json.encode("utf-8")).hexdigest()
        self.connection.execute(
            "INSERT OR IGNORE INTO domain_records("
            "record_id,kind,scope,payload_json,content_hash,revision,created_at,updated_at,idempotency_key"
            ") VALUES(?,?,?,?,?,1,?,?,NULL)",
            (record_id, kind, scope, payload_json, content_hash, now, now),
        )

    @staticmethod
    def _memory_edge(row: Any) -> dict[str, Any]:
        item = dict(row)
        try:
            item["evidence"] = json.loads(item.pop("evidence_json"))
        except (KeyError, TypeError, json.JSONDecodeError):
            item["evidence"] = []
        item["source"] = item.get("src_record_id")
        item["target"] = item.get("dst_record_id")
        return item

    @staticmethod
    def _memory_conflict(row: Any) -> dict[str, Any]:
        item = dict(row)
        try:
            item["metadata"] = json.loads(item.pop("metadata_json"))
        except (KeyError, TypeError, json.JSONDecodeError):
            item["metadata"] = {}
        item["record_ids"] = [item.get("left_record_id"), item.get("right_record_id")]
        item["type"] = item.get("kind")
        return item

    @staticmethod
    def _working_memory_note(row: Any) -> dict[str, Any]:
        item = dict(row)
        try:
            item["metadata"] = json.loads(item.pop("metadata_json"))
        except (KeyError, TypeError, json.JSONDecodeError):
            item["metadata"] = {}
        return item


def _without_internal_fields(record: Mapping[str, Any]) -> dict[str, Any]:
    return {
        str(key): value
        for key, value in dict(record).items()
        if key not in {"_revision", "_content_hash"}
    }


def _fts_terms(query: str) -> list[str]:
    return [term.casefold() for term in str(query).split() if term.strip()][:8]


def _fts_expression(terms: Sequence[str]) -> str:
    escaped = [str(term).replace('"', '""') for term in terms if str(term).strip()]
    return " OR ".join(f'"{term}"' for term in escaped)
