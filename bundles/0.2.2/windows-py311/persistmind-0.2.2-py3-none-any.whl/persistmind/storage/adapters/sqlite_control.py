from __future__ import annotations

import hashlib
import json
import secrets
from collections.abc import Mapping
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from ..descriptors import StorageDomain, StoreDescriptor, StoreRole
from .sqlite_base import SQLiteDomainStore, _now, _scalar


class LeaseConflict(RuntimeError):
    """A live fenced owner already controls the named operation."""


class SQLiteControlStore(SQLiteDomainStore):
    """Coordination authority for topology, leases, jobs, sagas and watermarks."""

    def __init__(
        self,
        path: Path,
        *,
        descriptor: StoreDescriptor | None = None,
        store_id: str | None = None,
        allow_development_driver: bool = False,
    ) -> None:
        super().__init__(
            path,
            StorageDomain.CONTROL,
            StoreRole.CONTROL,
            resource="schemas/control/v1.sql",
            store_id=store_id or "control-current",
            descriptor=descriptor,
            allow_development_driver=allow_development_driver,
        )

    def acquire_lease(
        self,
        lease_name: str,
        *,
        owner_id: str,
        owner_boot_id: str,
        owner_nonce: str | None = None,
        duration_seconds: float = 30.0,
        payload: Mapping[str, Any] | None = None,
    ) -> Mapping[str, Any]:
        if self.descriptor.read_only:
            raise PermissionError("read-only Control runtime cannot acquire leases")
        now = datetime.now(UTC)
        deadline = now + timedelta(seconds=max(1.0, duration_seconds))
        nonce = owner_nonce or secrets.token_hex(16)
        with self._write_lock, self.connection:
            current = self.connection.execute(
                "SELECT * FROM operation_leases WHERE lease_name=?", (lease_name,)
            ).fetchone()
            if current is not None:
                current_deadline = datetime.fromisoformat(
                    str(current["deadline_at"]).replace("Z", "+00:00")
                )
                same_owner = (
                    str(current["owner_id"]) == owner_id
                    and str(current["owner_boot_id"]) == owner_boot_id
                    and str(current["owner_nonce"]) == nonce
                )
                if current_deadline > now and not same_owner:
                    raise LeaseConflict(f"operation lease is active: {lease_name}")
                fencing_token = int(current["fencing_token"]) + (0 if same_owner else 1)
            else:
                fencing_token = 1
            self.connection.execute(
                "INSERT INTO operation_leases(lease_name,owner_id,owner_boot_id,owner_nonce,"
                "fencing_token,acquired_at,heartbeat_at,deadline_at,payload_json) "
                "VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(lease_name) DO UPDATE SET "
                "owner_id=excluded.owner_id,owner_boot_id=excluded.owner_boot_id,"
                "owner_nonce=excluded.owner_nonce,fencing_token=excluded.fencing_token,"
                "acquired_at=excluded.acquired_at,heartbeat_at=excluded.heartbeat_at,"
                "deadline_at=excluded.deadline_at,payload_json=excluded.payload_json",
                (
                    lease_name,
                    owner_id,
                    owner_boot_id,
                    nonce,
                    fencing_token,
                    _now(),
                    _now(),
                    deadline.isoformat().replace("+00:00", "Z"),
                    json.dumps(dict(payload or {}), sort_keys=True, separators=(",", ":")),
                ),
            )
        return {
            "lease_name": lease_name,
            "owner_id": owner_id,
            "owner_boot_id": owner_boot_id,
            "owner_nonce": nonce,
            "fencing_token": fencing_token,
            "deadline_at": deadline.isoformat().replace("+00:00", "Z"),
        }

    def kill_switch_status(self) -> Mapping[str, Any]:
        rows = (
            self._reader()
            .execute("SELECT * FROM domain_records WHERE kind='control_kill_switch_transition'")
            .fetchall()
        )
        transitions = [self._record(row) for row in rows]
        transitions.sort(
            key=lambda item: (int(item.get("sequence") or 0), str(item.get("record_id")))
        )
        if not transitions:
            return {
                "active": False,
                "sequence": 0,
                "scope": "workspace",
                "reason": None,
            }
        return dict(transitions[-1])

    def record_kill_switch_transition(
        self,
        *,
        active: bool,
        scope: str,
        reason: str,
        actor: str,
        signer_identities: list[Mapping[str, str]],
        decision_document_hash: str,
    ) -> Mapping[str, Any]:
        current = self.kill_switch_status()
        if bool(current.get("active")) == active:
            return current
        sequence = int(current.get("sequence") or 0) + 1
        record_id = (
            "control-kill-transition-"
            + hashlib.sha256(
                f"{sequence}\x1f{active}\x1f{decision_document_hash}".encode()
            ).hexdigest()[:32]
        )
        record = {
            "record_id": record_id,
            "kind": "control_kill_switch_transition",
            "scope": scope,
            "sequence": sequence,
            "active": active,
            "reason": reason,
            "actor": actor,
            "signer_identities": [dict(item) for item in signer_identities],
            "decision_document_hash": decision_document_hash,
            "previous_transition_id": current.get("record_id"),
            "created_at": _now(),
        }
        self.put(record, idempotency_key="control-kill:" + decision_document_hash)
        return record

    def heartbeat_lease(
        self,
        lease_name: str,
        *,
        owner_nonce: str,
        fencing_token: int,
        duration_seconds: float = 30.0,
    ) -> bool:
        deadline = datetime.now(UTC) + timedelta(seconds=max(1.0, duration_seconds))
        with self._write_lock, self.connection:
            self.connection.execute(
                "UPDATE operation_leases SET heartbeat_at=?,deadline_at=? "
                "WHERE lease_name=? AND owner_nonce=? AND fencing_token=?",
                (
                    _now(),
                    deadline.isoformat().replace("+00:00", "Z"),
                    lease_name,
                    owner_nonce,
                    fencing_token,
                ),
            )
            return bool(_scalar(self.connection.execute("SELECT changes()").fetchone()))

    def release_lease(self, lease_name: str, *, owner_nonce: str, fencing_token: int) -> bool:
        with self._write_lock, self.connection:
            self.connection.execute(
                "DELETE FROM operation_leases WHERE lease_name=? "
                "AND owner_nonce=? AND fencing_token=?",
                (lease_name, owner_nonce, fencing_token),
            )
            return bool(_scalar(self.connection.execute("SELECT changes()").fetchone()))

    def active_lease(self, lease_name: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute("SELECT * FROM operation_leases WHERE lease_name=?", (lease_name,))
            .fetchone()
        )
        return dict(row) if row is not None else None

    def begin_reconciliation(
        self,
        claim_id: str,
        *,
        owner_id: str,
        owner_boot_id: str,
        payload: Mapping[str, Any],
        duration_seconds: float = 30.0,
    ) -> Mapping[str, Any]:
        previous = (
            self._reader()
            .execute(
                "SELECT state,payload_json FROM operation_runs WHERE operation_id=?",
                (claim_id,),
            )
            .fetchone()
        )
        previous_attempt = 0
        if previous is not None:
            try:
                previous_attempt = int(json.loads(str(previous[1])).get("attempt", 0))
            except (ValueError, TypeError, json.JSONDecodeError):
                previous_attempt = 0
        if previous is not None and str(previous[0]) == "dead_letter":
            raise LeaseConflict(
                f"reconciliation claim is dead-lettered and requires operator review: {claim_id}"
            )
        if previous is not None and str(previous[0]) == "retryable_error":
            try:
                retry_at = datetime.fromisoformat(
                    str(json.loads(str(previous[1])).get("next_retry_at") or "").replace(
                        "Z", "+00:00"
                    )
                )
            except (ValueError, json.JSONDecodeError):
                retry_at = datetime.min.replace(tzinfo=UTC)
            if retry_at > datetime.now(UTC):
                raise LeaseConflict(f"reconciliation backoff is active: {claim_id}")
        lease = self.acquire_lease(
            f"reconcile:{claim_id}",
            owner_id=owner_id,
            owner_boot_id=owner_boot_id,
            duration_seconds=duration_seconds,
            payload=payload,
        )
        encoded = json.dumps(
            {**dict(payload), "attempt": previous_attempt},
            sort_keys=True,
            separators=(",", ":"),
        )
        input_hash = hashlib.sha256(encoded.encode()).hexdigest()
        now = _now()
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT INTO operation_runs(operation_id,operation_type,state,owner_id,"
                "fencing_token,input_hash,payload_json,created_at,updated_at) "
                "VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(operation_id) DO UPDATE SET "
                "state='running',owner_id=excluded.owner_id,fencing_token=excluded.fencing_token,"
                "input_hash=excluded.input_hash,payload_json=excluded.payload_json,"
                "updated_at=excluded.updated_at,completed_at=NULL",
                (
                    claim_id,
                    "reconciliation",
                    "running",
                    owner_id,
                    int(lease["fencing_token"]),
                    input_hash,
                    encoded,
                    now,
                    now,
                ),
            )
        return {**dict(lease), "claim_id": claim_id, "input_hash": input_hash}

    def finish_reconciliation(
        self,
        claim_id: str,
        *,
        owner_nonce: str,
        fencing_token: int,
        result: Mapping[str, Any],
        retryable: bool,
    ) -> None:
        previous = (
            self._reader()
            .execute("SELECT payload_json FROM operation_runs WHERE operation_id=?", (claim_id,))
            .fetchone()
        )
        try:
            attempts = int(json.loads(str(previous[0])).get("attempt", 0)) + 1 if previous else 1
        except (ValueError, TypeError, json.JSONDecodeError):
            attempts = 1
        state = (
            "completed"
            if result.get("ok")
            else "retryable_error"
            if retryable and attempts < 8
            else "dead_letter"
        )
        result_payload = {**dict(result), "attempt": attempts}
        if state == "retryable_error":
            delay = min(3600, 2 ** min(attempts, 10))
            result_payload["next_retry_at"] = (
                (datetime.now(UTC) + timedelta(seconds=delay))
                .isoformat()
                .replace("+00:00", "Z")
            )
        elif state == "dead_letter":
            result_payload["retry_exhausted"] = bool(retryable)
        payload = json.dumps(result_payload, sort_keys=True, separators=(",", ":"), default=str)
        now = _now()
        with self._write_lock, self.connection:
            current = self.connection.execute(
                "SELECT fencing_token FROM operation_runs WHERE operation_id=?",
                (claim_id,),
            ).fetchone()
            if current is None or int(current[0]) != fencing_token:
                raise LeaseConflict(f"stale reconciliation fence: {claim_id}")
            self.connection.execute(
                "UPDATE operation_runs SET state=?,payload_json=?,updated_at=?,completed_at=? "
                "WHERE operation_id=? AND fencing_token=?",
                (
                    state,
                    payload,
                    now,
                    now if state in {"completed", "dead_letter"} else None,
                    claim_id,
                    fencing_token,
                ),
            )
        self.release_lease(
            f"reconcile:{claim_id}",
            owner_nonce=owner_nonce,
            fencing_token=fencing_token,
        )

    def reconciliation_claims(self) -> list[Mapping[str, Any]]:
        return [
            dict(row)
            for row in self._reader()
            .execute(
                "SELECT * FROM operation_runs WHERE operation_type='reconciliation' "
                "ORDER BY updated_at DESC,operation_id"
            )
            .fetchall()
        ]

    def reconciliation_health(self) -> Mapping[str, Any]:
        base = dict(super().reconciliation_health())
        claims = self.reconciliation_claims()
        base.update(
            {
                "ok": bool(base["ok"])
                and not any(item["state"] == "dead_letter" for item in claims),
                "reconciliation_claims": len(claims),
                "retrying": sum(item["state"] == "retryable_error" for item in claims),
                "claim_dead_letters": sum(item["state"] == "dead_letter" for item in claims),
            }
        )
        return base

    def stage_topology(self, topology: Mapping[str, Any]) -> str:
        encoded = json.dumps(dict(topology), sort_keys=True, separators=(",", ":"))
        digest = hashlib.sha256(encoded.encode()).hexdigest()
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT INTO topology_generations("
                "generation,topology_id,manifest_json,manifest_hash,state,created_at) "
                "VALUES(?,?,?,?,?,?) ON CONFLICT(generation) DO UPDATE SET "
                "manifest_json=excluded.manifest_json,manifest_hash=excluded.manifest_hash,"
                "state=CASE WHEN topology_generations.state='active' THEN 'active' ELSE 'staged' END",
                (
                    int(topology["generation"]),
                    str(topology["topology_id"]),
                    encoded,
                    digest,
                    "staged",
                    _now(),
                ),
            )
        return digest

    def activate_topology(self, generation: int) -> None:
        with self._write_lock, self.connection:
            found = self.connection.execute(
                "SELECT 1 FROM topology_generations WHERE generation=? AND state IN ('staged','active')",
                (generation,),
            ).fetchone()
            if found is None:
                raise KeyError(f"Control topology generation is not staged: {generation}")
            self.connection.execute(
                "UPDATE topology_generations SET state='retired' WHERE state='active' AND generation<>?",
                (generation,),
            )
            self.connection.execute(
                "UPDATE topology_generations SET state='active',activated_at=? WHERE generation=?",
                (_now(), generation),
            )
