from __future__ import annotations

import json
import hashlib
from pathlib import Path
from typing import Any, Mapping, Sequence, cast

from ..descriptors import StorageDomain, StoreDescriptor, StoreRole
from .sqlite_base import SQLiteDomainStore, _now


class LearningConflict(RuntimeError):
    """A version or evaluation id was reused with incompatible immutable data."""

    status = "conflict"


class SQLiteLearningStore(SQLiteDomainStore):
    def __init__(
        self,
        path: Path,
        *,
        descriptor: StoreDescriptor | None = None,
        allow_development_driver: bool = False,
    ) -> None:
        super().__init__(
            path,
            StorageDomain.LEARNING,
            StoreRole.LEARNING,
            resource="schemas/learning/v1.sql",
            extra_resources=("schemas/reporting/learning.v1.sql",),
            store_id="learning-current",
            descriptor=descriptor,
            allow_development_driver=allow_development_driver,
        )

    def active_manifest(self) -> Mapping[str, Any]:
        with self._write_lock:
            rows = self.connection.execute(
                "SELECT skill_id,version_id FROM active_skills ORDER BY skill_id"
            ).fetchall()
        return {row["skill_id"]: row["version_id"] for row in rows}

    def register_version(
        self,
        version: Mapping[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        version_id = str(version.get("version_id") or "").strip()
        skill_id = str(version.get("skill_id") or "").strip()
        artifact_ref = str(version.get("artifact_ref") or "").strip()
        benchmark_id = str(version.get("benchmark_id") or "").strip()
        if not version_id or not skill_id or not artifact_ref or not benchmark_id:
            raise ValueError(
                "skill version requires version_id, skill_id, artifact_ref, and benchmark_id"
            )
        status = str(version.get("status") or "candidate")
        if status != "candidate":
            raise ValueError("new skill versions must start as candidate")
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT * FROM skill_versions WHERE version_id=?", (version_id,)
            ).fetchone()
            if existing is not None:
                immutable = ("skill_id", "artifact_ref", "benchmark_id")
                expected = {
                    "skill_id": skill_id,
                    "artifact_ref": artifact_ref,
                    "benchmark_id": benchmark_id,
                }
                if any(str(existing[key]) != expected[key] for key in immutable):
                    raise LearningConflict(
                        f"skill version id conflicts with immutable content: {version_id}"
                    )
                return dict(existing)
            self.connection.execute(
                "INSERT INTO skill_versions VALUES(?,?,?,?,?,?)",
                (version_id, skill_id, artifact_ref, benchmark_id, status, _now()),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            row = self.connection.execute(
                "SELECT * FROM skill_versions WHERE version_id=?", (version_id,)
            ).fetchone()
        if row is None:  # pragma: no cover - committed insert is immediately read.
            raise RuntimeError(f"skill version write did not persist: {version_id}")
        return dict(row)

    def version(self, version_id: str) -> Mapping[str, Any] | None:
        with self._write_lock:
            row = self.connection.execute(
                "SELECT * FROM skill_versions WHERE version_id=?", (version_id,)
            ).fetchone()
        return dict(row) if row is not None else None

    def versions(
        self, *, skill_id: str | None = None, limit: int = 1000
    ) -> Sequence[Mapping[str, Any]]:
        with self._write_lock:
            if skill_id:
                rows = self.connection.execute(
                    "SELECT * FROM skill_versions WHERE skill_id=? "
                    "ORDER BY created_at DESC,version_id LIMIT ?",
                    (skill_id, max(1, min(int(limit), 10_000))),
                ).fetchall()
            else:
                rows = self.connection.execute(
                    "SELECT * FROM skill_versions ORDER BY created_at DESC,version_id LIMIT ?",
                    (max(1, min(int(limit), 10_000)),),
                ).fetchall()
        return [dict(row) for row in rows]

    def record_evaluation(self, evaluation: Mapping[str, Any]) -> Mapping[str, Any]:
        evaluation_id = str(evaluation.get("evaluation_id") or "").strip()
        version_id = str(evaluation.get("version_id") or "").strip()
        split = str(evaluation.get("split") or "").strip()
        metrics = evaluation.get("metrics")
        if not evaluation_id or not version_id or not split or not isinstance(metrics, Mapping):
            raise ValueError(
                "learning evaluation requires evaluation_id, version_id, split, and metrics"
            )
        passed = bool(evaluation.get("passed"))
        metrics_json = json.dumps(dict(metrics), sort_keys=True, separators=(",", ":"))
        with self._write_lock, self.connection:
            if (
                self.connection.execute(
                    "SELECT 1 FROM skill_versions WHERE version_id=?", (version_id,)
                ).fetchone()
                is None
            ):
                raise KeyError(version_id)
            existing = self.connection.execute(
                "SELECT * FROM learning_evaluations WHERE evaluation_id=?", (evaluation_id,)
            ).fetchone()
            if existing is not None:
                if (
                    str(existing["version_id"]) != version_id
                    or str(existing["split"]) != split
                    or str(existing["metrics_json"]) != metrics_json
                    or bool(existing["passed"]) != passed
                ):
                    raise LearningConflict(
                        f"learning evaluation id conflicts with immutable data: {evaluation_id}"
                    )
                return _evaluation_row(cast(Mapping[str, Any], existing))
            self.connection.execute(
                "INSERT INTO learning_evaluations VALUES(?,?,?,?,?,?)",
                (evaluation_id, version_id, split, metrics_json, int(passed), _now()),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            row = self.connection.execute(
                "SELECT * FROM learning_evaluations WHERE evaluation_id=?", (evaluation_id,)
            ).fetchone()
        if row is None:  # pragma: no cover - committed insert is immediately read.
            raise RuntimeError(f"learning evaluation write did not persist: {evaluation_id}")
        return _evaluation_row(cast(Mapping[str, Any], row))

    def evaluations(self, version_id: str) -> Sequence[Mapping[str, Any]]:
        with self._write_lock:
            rows = self.connection.execute(
                "SELECT * FROM learning_evaluations WHERE version_id=? "
                "ORDER BY created_at,evaluation_id",
                (version_id,),
            ).fetchall()
        return [_evaluation_row(cast(Mapping[str, Any], row)) for row in rows]

    def transition_version(
        self,
        version_id: str,
        *,
        to_state: str,
        actor: str,
        reason: str,
    ) -> Mapping[str, Any]:
        if to_state not in {"candidate", "active", "inactive", "rejected", "suspended"}:
            raise ValueError(f"invalid Learning version state: {to_state}")
        with self._write_lock, self.connection:
            row = self.connection.execute(
                "SELECT * FROM skill_versions WHERE version_id=?", (version_id,)
            ).fetchone()
            if row is None:
                raise KeyError(version_id)
            from_state = str(row["status"])
            transition = {
                "record_id": "learning-version-transition-"
                + hashlib.sha256(
                    f"{version_id}\x1f{from_state}\x1f{to_state}\x1f{actor}\x1f{reason}".encode()
                ).hexdigest()[:32],
                "kind": "learning_version_transition",
                "scope": str(row["skill_id"]),
                "version_id": version_id,
                "from_state": from_state,
                "to_state": to_state,
                "actor": actor,
                "reason": reason,
                "created_at": _now(),
            }
            payload = json.dumps(transition, sort_keys=True, separators=(",", ":"))
            digest = hashlib.sha256(payload.encode()).hexdigest()
            self.connection.execute(
                "INSERT OR IGNORE INTO domain_records VALUES(?,?,?,?,?,1,?,?,?)",
                (
                    transition["record_id"],
                    transition["kind"],
                    transition["scope"],
                    payload,
                    digest,
                    transition["created_at"],
                    transition["created_at"],
                    "learning-version-transition:" + str(transition["record_id"]),
                ),
            )
            self.connection.execute(
                "UPDATE skill_versions SET status=? WHERE version_id=?", (to_state, version_id)
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            updated = self.connection.execute(
                "SELECT * FROM skill_versions WHERE version_id=?", (version_id,)
            ).fetchone()
        return dict(updated) if updated is not None else {}

    def promote(self, version_id: str, *, approval: Mapping[str, Any]) -> Mapping[str, Any]:
        if (
            not approval.get("approved_by")
            or not approval.get("benchmark_id")
            or not approval.get("rollback_version")
        ):
            raise PermissionError(
                "skill promotion requires approval, benchmark, and rollback metadata"
            )
        with self._write_lock, self.connection:
            row = self.connection.execute(
                "SELECT skill_id FROM skill_versions WHERE version_id=? AND status='candidate'",
                (version_id,),
            ).fetchone()
            if not row:
                raise KeyError(version_id)
            prior = self.connection.execute(
                "SELECT version_id FROM active_skills WHERE skill_id=?", (row[0],)
            ).fetchone()
            if prior is not None and str(prior[0]) != version_id:
                self.connection.execute(
                    "UPDATE skill_versions SET status='inactive' WHERE version_id=?",
                    (prior[0],),
                )
            self.connection.execute(
                "INSERT OR REPLACE INTO active_skills VALUES(?,?,?,?)",
                (row[0], version_id, json.dumps(dict(approval), sort_keys=True), _now()),
            )
            self.connection.execute(
                "UPDATE skill_versions SET status='active' WHERE version_id=?",
                (version_id,),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return {"ok": True, "version_id": version_id, "active": True}

    def rollback(self, version_id: str, *, approval: Mapping[str, Any]) -> Mapping[str, Any]:
        if not approval.get("approved_by"):
            raise PermissionError("rollback requires approval")
        with self._write_lock, self.connection:
            row = self.connection.execute(
                "SELECT skill_id FROM skill_versions WHERE version_id=?", (version_id,)
            ).fetchone()
            if not row:
                raise KeyError(version_id)
            current = self.connection.execute(
                "SELECT version_id FROM active_skills WHERE skill_id=?", (row[0],)
            ).fetchone()
            self.connection.execute(
                "UPDATE active_skills SET version_id=?,approval_json=?,activated_at=? "
                "WHERE skill_id=?",
                (version_id, json.dumps(dict(approval), sort_keys=True), _now(), row[0]),
            )
            if current is not None and str(current[0]) != version_id:
                self.connection.execute(
                    "UPDATE skill_versions SET status='inactive' WHERE version_id=?",
                    (current[0],),
                )
            self.connection.execute(
                "UPDATE skill_versions SET status='active' WHERE version_id=?",
                (version_id,),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return {"ok": True, "version_id": version_id, "rolled_back": True}


def _evaluation_row(row: Mapping[str, Any]) -> dict[str, Any]:
    try:
        metrics = json.loads(str(row["metrics_json"]))
    except (KeyError, TypeError, json.JSONDecodeError):
        metrics = {}
    return {
        "evaluation_id": str(row["evaluation_id"]),
        "version_id": str(row["version_id"]),
        "split": str(row["split"]),
        "metrics": metrics if isinstance(metrics, dict) else {},
        "passed": bool(row["passed"]),
        "created_at": str(row["created_at"]),
    }
