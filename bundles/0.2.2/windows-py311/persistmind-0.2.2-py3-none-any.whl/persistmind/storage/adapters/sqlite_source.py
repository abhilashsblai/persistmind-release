from __future__ import annotations

import hashlib
import json
import re
import struct
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from ..descriptors import StorageDomain, StoreDescriptor, StoreRole
from .apsw_driver import ApswConnection
from .sqlite_base import SQLiteDomainStore, _now


class SQLiteSourceStore(SQLiteDomainStore):
    """The per-repository Source manifest role, not an unbounded source corpus."""

    def __init__(
        self,
        path: Path,
        *,
        descriptor: StoreDescriptor | None = None,
        allow_development_driver: bool = False,
    ) -> None:
        super().__init__(
            path,
            StorageDomain.SOURCE,
            StoreRole.SOURCE_MANIFEST,
            resource="schemas/source/v1.sql",
            store_id="source-manifest-current",
            descriptor=descriptor,
            allow_development_driver=allow_development_driver,
        )

    def resolve_evidence(self, locator: Mapping[str, Any]) -> Mapping[str, Any] | None:
        content_hash = str(locator.get("content_hash", ""))
        row = (
            self._reader()
            .execute(
                "SELECT * FROM source_evidence WHERE content_hash=? "
                "ORDER BY created_at DESC LIMIT 1",
                (content_hash,),
            )
            .fetchone()
        )
        return dict(row) if row else None

    def rebuild(self, manifest: Mapping[str, Any]) -> Mapping[str, Any]:
        generation_id = str(manifest["generation_id"])
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT OR REPLACE INTO source_generations VALUES(?,?,?,?)",
                (
                    generation_id,
                    str(manifest.get("input_hash", "")),
                    "ready",
                    _now(),
                ),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return {"ok": True, "generation_id": generation_id, "rebuildable": True}

    def generation(self, generation_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute("SELECT * FROM source_generations WHERE generation_id=?", (generation_id,))
            .fetchone()
        )
        return dict(row) if row else None

    def generations(self, *, limit: int = 100) -> list[Mapping[str, Any]]:
        rows = (
            self._reader()
            .execute(
                "SELECT * FROM source_generations ORDER BY created_at DESC,generation_id LIMIT ?",
                (max(1, min(int(limit), 1000)),),
            )
            .fetchall()
        )
        return [dict(row) for row in rows]

    def publish_segment(self, segment: Mapping[str, Any]) -> None:
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT OR REPLACE INTO source_segments VALUES(?,?,?,?,?,?)",
                (
                    str(segment["segment_id"]),
                    str(segment["generation_id"]),
                    str(segment.get("partition_key", "default")),
                    str(segment.get("state", "sealed")),
                    str(segment["content_hash"]),
                    str(segment.get("sealed_at") or _now()),
                ),
            )
            self.connection.execute(
                "UPDATE source_generations SET status='published' WHERE generation_id=?",
                (str(segment["generation_id"]),),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )

    def segments(self, generation_id: str | None = None) -> list[Mapping[str, Any]]:
        if generation_id:
            rows = (
                self._reader()
                .execute(
                    "SELECT * FROM source_segments WHERE generation_id=? "
                    "ORDER BY partition_key,segment_id",
                    (generation_id,),
                )
                .fetchall()
            )
        else:
            rows = (
                self._reader()
                .execute("SELECT * FROM source_segments ORDER BY sealed_at DESC,segment_id")
                .fetchall()
            )
        return [dict(row) for row in rows]

    def delete_generation(self, generation_id: str) -> None:
        with self._write_lock, self.connection:
            self.connection.execute(
                "DELETE FROM source_views WHERE current_generation_id=?", (generation_id,)
            )
            self.connection.execute(
                "DELETE FROM source_generation_files WHERE generation_id=?", (generation_id,)
            )
            self.connection.execute(
                "DELETE FROM source_segments WHERE generation_id=?", (generation_id,)
            )
            self.connection.execute(
                "DELETE FROM source_generations WHERE generation_id=?", (generation_id,)
            )
            self.connection.execute(
                "DELETE FROM domain_records WHERE kind='source_generation_evidence' "
                "AND payload_json LIKE ?",
                (f'%"generation_id":"{generation_id}"%',),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            self._refresh_artifact_ref_counts_locked()

    def artifact(self, artifact_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute("SELECT * FROM source_artifacts WHERE artifact_id=?", (artifact_id,))
            .fetchone()
        )
        return dict(row) if row is not None else None

    def register_artifact(self, artifact: Mapping[str, Any]) -> Mapping[str, Any]:
        artifact_id = str(artifact["artifact_id"])
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT OR IGNORE INTO source_artifacts VALUES(?,?,?,?,?,?,?,?,0,?)",
                (
                    artifact["artifact_id"],
                    artifact["content_hash"],
                    artifact["index_contract"],
                    artifact["model_digest"],
                    artifact["resolver_id"],
                    artifact["segment_id"],
                    artifact["physical_hash"],
                    int(artifact["logical_bytes"]),
                    artifact.get("created_at") or _now(),
                ),
            )
        registered = self.artifact(artifact_id) or {}
        immutable = {
            "content_hash",
            "index_contract",
            "model_digest",
            "resolver_id",
            "segment_id",
            "physical_hash",
            "logical_bytes",
        }
        if any(str(registered.get(key)) != str(artifact.get(key)) for key in immutable):
            raise RuntimeError(f"source artifact identity collision: {artifact_id}")
        return registered

    def bind_generation_files(self, generation_id: str, files: Sequence[Mapping[str, Any]]) -> None:
        with self._write_lock, self.connection:
            for item in files:
                self.connection.execute(
                    "INSERT OR REPLACE INTO source_generation_files VALUES(?,?,?,?,?)",
                    (
                        generation_id,
                        item["path"],
                        item["artifact_id"],
                        item["content_hash"],
                        item["resolver_id"],
                    ),
                )
            self._refresh_artifact_ref_counts_locked()

    def publish_source_view(self, source_view_id: str, generation_id: str) -> None:
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT OR REPLACE INTO source_views VALUES(?,?,?)",
                (source_view_id, generation_id, _now()),
            )

    def publish_generation(self, generation_id: str) -> None:
        with self._write_lock, self.connection:
            self.connection.execute(
                "UPDATE source_generations SET status='published' WHERE generation_id=?",
                (generation_id,),
            )

    def current_generation(self, source_view_id: str | None = None) -> str | None:
        if source_view_id:
            row = (
                self._reader()
                .execute(
                    "SELECT current_generation_id FROM source_views WHERE source_view_id=?",
                    (source_view_id,),
                )
                .fetchone()
            )
            if row is not None:
                return str(row[0])
        row = (
            self._reader()
            .execute(
                "SELECT generation_id FROM source_generations WHERE status='published' "
                "ORDER BY created_at DESC,generation_id LIMIT 1"
            )
            .fetchone()
        )
        return str(row[0]) if row is not None else None

    def generation_files(self, generation_id: str) -> list[Mapping[str, Any]]:
        rows = (
            self._reader()
            .execute(
                "SELECT * FROM source_generation_files WHERE generation_id=? ORDER BY path",
                (generation_id,),
            )
            .fetchall()
        )
        return [dict(row) for row in rows]

    def source_views(self) -> list[Mapping[str, Any]]:
        return [
            dict(row)
            for row in self._reader()
            .execute("SELECT * FROM source_views ORDER BY updated_at DESC,source_view_id")
            .fetchall()
        ]

    def artifacts(self) -> list[Mapping[str, Any]]:
        return [
            dict(row)
            for row in self._reader()
            .execute("SELECT * FROM source_artifacts ORDER BY created_at,artifact_id")
            .fetchall()
        ]

    def register_resolver(
        self, resolver_id: str, version: str, kind: str, configuration_digest: str
    ) -> None:
        with self._write_lock, self.connection:
            existing = self.connection.execute(
                "SELECT * FROM source_resolvers WHERE resolver_id=?", (resolver_id,)
            ).fetchone()
            if existing is not None and (
                str(existing["version"]) != version
                or str(existing["kind"]) != kind
                or str(existing["configuration_digest"]) != configuration_digest
            ):
                raise RuntimeError(f"source resolver identity collision: {resolver_id}")
            self.connection.execute(
                "INSERT OR IGNORE INTO source_resolvers VALUES(?,?,?,?,?)",
                (resolver_id, version, kind, configuration_digest, _now()),
            )

    def resolvers(self) -> list[Mapping[str, Any]]:
        return [
            dict(row)
            for row in self._reader()
            .execute("SELECT * FROM source_resolvers ORDER BY resolver_id")
            .fetchall()
        ]

    def pin_generation(
        self, pin_id: str, generation_id: str, reason: str, expires_at: str | None
    ) -> None:
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT OR REPLACE INTO source_generation_pins VALUES(?,?,?,?,?)",
                (pin_id, generation_id, reason, _now(), expires_at),
            )

    def pins(self) -> list[Mapping[str, Any]]:
        return [
            dict(row)
            for row in self._reader()
            .execute("SELECT * FROM source_generation_pins ORDER BY created_at,pin_id")
            .fetchall()
        ]

    def protected_generations(self) -> set[str]:
        rows = (
            self._reader()
            .execute(
                "SELECT generation_id FROM source_generation_pins "
                "WHERE expires_at IS NULL OR expires_at>?",
                (_now(),),
            )
            .fetchall()
        )
        return {str(row[0]) for row in rows}

    def unreferenced_artifacts(self) -> list[Mapping[str, Any]]:
        return [
            dict(row)
            for row in self._reader()
            .execute(
                "SELECT * FROM source_artifacts WHERE ref_count=0 ORDER BY created_at,artifact_id"
            )
            .fetchall()
        ]

    def delete_artifact(self, artifact_id: str) -> None:
        with self._write_lock, self.connection:
            self.connection.execute(
                "DELETE FROM source_artifacts WHERE artifact_id=? AND ref_count=0",
                (artifact_id,),
            )

    def _refresh_artifact_ref_counts_locked(self) -> None:
        self.connection.execute("UPDATE source_artifacts SET ref_count=0")
        self.connection.execute(
            "UPDATE source_artifacts SET ref_count=(SELECT COUNT(*) FROM source_generation_files f "
            "WHERE f.artifact_id=source_artifacts.artifact_id)"
        )


class SQLiteSourceSegmentStore(SQLiteDomainStore):
    """A generation-scoped derived segment; callers publish it through the catalog."""

    def __init__(
        self,
        path: Path,
        *,
        descriptor: StoreDescriptor | None = None,
        store_id: str = "source-segment-current",
        allow_development_driver: bool = False,
    ) -> None:
        super().__init__(
            path,
            StorageDomain.SOURCE,
            StoreRole.SOURCE_SEGMENT,
            resource="schemas/source_segment/v1.sql",
            store_id=store_id,
            descriptor=descriptor,
            allow_development_driver=allow_development_driver,
        )
        if not self.descriptor.read_only:
            with self._write_lock, self.connection:
                self.connection.execute(
                    "CREATE VIRTUAL TABLE IF NOT EXISTS source_segment_fts USING fts5("
                    "payload_json,content='source_segment_records',content_rowid='rowid')"
                )
                self.vector_capability: dict[str, Any] | None = None
                if isinstance(self.connection, ApswConnection):
                    self.vector_capability = self.connection.load_sqlite_vec()
                    self.connection.execute(
                        "CREATE VIRTUAL TABLE IF NOT EXISTS source_segment_vectors "
                        "USING vec0(record_id TEXT PRIMARY KEY,embedding float[384])"
                    )
        else:
            self.vector_capability = None

    def seal(self) -> Mapping[str, Any]:
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT INTO source_segment_fts(source_segment_fts) VALUES('rebuild')"
            )
            records = _scalar_count(
                self.connection.execute("SELECT COUNT(*) FROM source_segment_records").fetchone()
            )
            indexed = _scalar_count(
                self.connection.execute("SELECT COUNT(*) FROM source_segment_fts").fetchone()
            )
            if records != indexed:
                raise RuntimeError(f"source FTS parity failed: records={records} indexed={indexed}")
            self.connection.execute(
                "UPDATE domain_metadata SET lifecycle_state='sealed', sealed_at=? "
                "WHERE singleton=1",
                (_now(),),
            )
        with self._write_lock:
            self.connection.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        return {"sealed": True, "role": StoreRole.SOURCE_SEGMENT.value}

    def integrity_status(self, *, expected_files: int) -> Mapping[str, Any]:
        reader = self._reader()
        rows = reader.execute(
            "SELECT payload_json FROM source_segment_records ORDER BY record_id"
        ).fetchall()
        file_count = 0
        chunk_count = 0
        signatures: set[tuple[str, int]] = set()
        for row in rows:
            payload = json.loads(str(row["payload_json"]))
            if payload.get("kind") == "source_file":
                file_count += 1
            if payload.get("kind") != "source_chunk":
                continue
            chunk_count += 1
            vector = payload.get("embedding")
            dimensions = len(vector) if isinstance(vector, list) else 384
            signatures.add((str(payload.get("model", "")), dimensions))
        fts = self.fts_status()
        ok = (
            file_count == expected_files
            and bool(fts["ok"])
            and (chunk_count == 0 or len(signatures) == 1)
        )
        return {
            "ok": ok,
            "expected_files": expected_files,
            "indexed_files": file_count,
            "chunks": chunk_count,
            "fts_records": fts["indexed"],
            "record_count": fts["records"],
            "vector_signatures": [list(item) for item in sorted(signatures)],
        }

    def put_source_record(self, record: Mapping[str, Any]) -> str:
        if self.descriptor.read_only:
            raise PermissionError("sealed source segment is read-only")
        document = dict(record)
        vector = document.get("embedding")
        vector_bytes: bytes | None = None
        if self.vector_capability is not None and isinstance(vector, list) and len(vector) == 384:
            vector_bytes = struct.pack("<384f", *(float(value) for value in vector))
            document.pop("embedding", None)
        payload = json.dumps(document, sort_keys=True, separators=(",", ":"))
        content_hash = hashlib.sha256(payload.encode("utf-8")).hexdigest()
        record_id = str(record["record_id"])
        with self._write_lock, self.connection:
            self.connection.execute(
                "INSERT OR REPLACE INTO source_segment_records VALUES(?,?,?,?,?)",
                (record_id, str(record.get("kind", "source_file")), payload, content_hash, _now()),
            )
            self.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
            if vector_bytes is not None:
                count = _scalar_count(
                    self.connection.execute(
                        "SELECT COUNT(*) FROM source_segment_vectors"
                    ).fetchone()
                )
                if count >= 100_000:
                    raise ValueError("sqlite-vec eligible vector scope exceeds 100000")
                self.connection.execute(
                    "INSERT OR REPLACE INTO source_segment_vectors(record_id,embedding) VALUES(?,?)",
                    (record_id, vector_bytes),
                )
        return record_id

    def vector_records(
        self, query_vector: list[float], *, limit: int = 20
    ) -> list[Mapping[str, Any]]:
        if len(query_vector) != 384:
            return []
        reader = self._reader()
        try:
            rows = reader.execute(
                "SELECT v.record_id,v.distance,r.payload_json,r.content_hash "
                "FROM source_segment_vectors v JOIN source_segment_records r "
                "ON r.record_id=v.record_id WHERE v.embedding MATCH ? AND k=? "
                "ORDER BY v.distance",
                (
                    struct.pack("<384f", *(float(value) for value in query_vector)),
                    max(1, min(int(limit), 100)),
                ),
            ).fetchall()
        except Exception:
            return []
        values: list[Mapping[str, Any]] = []
        for row in rows:
            payload = json.loads(str(row["payload_json"]))
            if isinstance(payload, dict):
                payload["_content_hash"] = str(row["content_hash"])
                payload["semantic_score"] = round(1.0 - float(row["distance"]), 6)
                values.append(payload)
        return values

    def source_records(self, query: str = "", *, limit: int = 100) -> list[Mapping[str, Any]]:
        bounded = max(1, min(int(limit), 10_000))
        from persistmind.context_snippets import query_terms
        from persistmind.utils import split_identifier_text

        expanded_query = split_identifier_text(query)
        tokens = [
            token
            for token in query_terms(expanded_query)
            if len(token) > 1 and re.fullmatch(r"[\w-]+", token, flags=re.UNICODE)
        ]
        if tokens:
            rows, match_method = self._source_records_for_expression(
                _fts_expression(tokens, "AND"), bounded
            ), "and"
            if not rows and re.search(r"\s", query):
                rows, match_method = self._source_records_for_expression(
                    _fts_expression(tokens, "OR"), bounded
                ), "or_fallback"
        else:
            rows = (
                self._reader()
                .execute(
                    "SELECT * FROM source_segment_records ORDER BY record_id LIMIT ?",
                    (bounded,),
                )
                .fetchall()
            )
            match_method = "all"
        values: list[Mapping[str, Any]] = []
        for row in rows:
            payload = json.loads(str(row["payload_json"]))
            if isinstance(payload, dict):
                payload["_content_hash"] = str(row["content_hash"])
                payload["retrieval_match_method"] = match_method
                if tokens:
                    searchable = f"{payload.get('path', '')}\n{payload.get('text', '')}".casefold()
                    payload["retrieval_matched_terms"] = [
                        token for token in tokens if token in searchable
                    ]
                values.append(payload)
        return values

    def _source_records_for_expression(self, expression: str, limit: int) -> list[Any]:
        return (
            self._reader()
            .execute(
                "SELECT r.* FROM source_segment_fts f "
                "JOIN source_segment_records r ON r.rowid=f.rowid "
                "WHERE source_segment_fts MATCH ? "
                "ORDER BY bm25(source_segment_fts),r.record_id LIMIT ?",
                (expression, limit),
            )
            .fetchall()
        )

    def records_for_path(self, path: str) -> list[Mapping[str, Any]]:
        """Export one immutable file record-set, including stored vector payloads."""

        reader = self._reader()
        has_vectors = _scalar_count(
            reader.execute(
                "SELECT COUNT(*) FROM sqlite_master "
                "WHERE type='table' AND name='source_segment_vectors'"
            ).fetchone()
        )
        if has_vectors:
            rows = reader.execute(
                "SELECT r.*,v.embedding FROM source_segment_records r "
                "LEFT JOIN source_segment_vectors v ON v.record_id=r.record_id "
                "WHERE json_extract(r.payload_json,'$.path')=? ORDER BY r.record_id",
                (path,),
            ).fetchall()
        else:
            rows = reader.execute(
                "SELECT r.*,NULL AS embedding FROM source_segment_records r "
                "WHERE json_extract(r.payload_json,'$.path')=? ORDER BY r.record_id",
                (path,),
            ).fetchall()
        values: list[Mapping[str, Any]] = []
        for row in rows:
            payload = json.loads(str(row["payload_json"]))
            vector = row["embedding"]
            if isinstance(payload, dict) and vector is not None:
                payload["embedding"] = list(struct.unpack("<384f", bytes(vector)))
            if isinstance(payload, dict):
                values.append(payload)
        return values

    def fts_status(self) -> Mapping[str, Any]:
        reader = self._reader()
        records = _scalar_count(
            reader.execute("SELECT COUNT(*) FROM source_segment_records").fetchone()
        )
        indexed = _scalar_count(
            reader.execute("SELECT COUNT(*) FROM source_segment_fts").fetchone()
        )
        return {"ok": records == indexed, "records": records, "indexed": indexed}


def _scalar_count(row: Any | None) -> int:
    return int(row[0]) if row is not None else 0


def _fts_expression(tokens: Sequence[str], operator: str) -> str:
    joiner = f" {operator} "
    return joiner.join(f'"{token.replace(chr(34), chr(34) * 2)}"' for token in tokens)
