from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from ..descriptors import StorageDomain, StoreDescriptor, StoreRole
from .sqlite_base import SQLiteDomainStore, _now, _scalar


class TaskConflict(RuntimeError):
    """Optimistic task-state write rejected due to a stale revision or key."""

    status = "conflict"


class SQLiteTaskStore(SQLiteDomainStore):
    """Canonical mutable Task State port for workflow, plans, and continuation."""

    def __init__(
        self,
        path: Path,
        *,
        descriptor: StoreDescriptor | None = None,
        allow_development_driver: bool = False,
    ) -> None:
        super().__init__(
            path,
            StorageDomain.TASK,
            StoreRole.TASK_STATE,
            resource="schemas/task/v1.sql",
            store_id="task-state-current",
            descriptor=descriptor,
            allow_development_driver=allow_development_driver,
        )

    def get(self, record_id: str) -> Mapping[str, Any] | None:
        generic = super().get(record_id)
        if generic is not None:
            return generic
        return self.session(record_id)

    def semantic_recovery_report(self) -> dict[str, Any]:
        """Validate Task-owned history invariants on a staged read-only image."""

        tables = {
            "task_sessions": "task_session_id",
            "task_session_transitions": "task_session_id,sequence,transition_id",
            "task_plans": "task_session_id,plan_id",
            "task_plan_revisions": "plan_id,revision,revision_id",
            "task_plan_checkpoints": "task_session_id,plan_id,checkpoint_id",
            "task_verifications": "task_session_id,verification_id",
            "workflow_lifecycle_events": "task_session_id,sequence,event_id",
            "storage_outbox": "aggregate_id,sequence,event_id",
        }
        counts: dict[str, int] = {}
        hashes: dict[str, str] = {}
        for table, order in tables.items():
            rows = [
                dict(row)
                for row in self._reader()
                .execute(f"SELECT * FROM {table} ORDER BY {order}")
                .fetchall()
            ]
            counts[table] = len(rows)
            hashes[table] = hashlib.sha256(
                json.dumps(rows, sort_keys=True, separators=(",", ":"), default=str).encode()
            ).hexdigest()
        checks = {
            "transition_sequence_starts_at_one": int(
                _scalar(
                    self._reader()
                    .execute(
                        "SELECT COUNT(*) FROM (SELECT task_session_id,MIN(sequence) AS first "
                        "FROM task_session_transitions GROUP BY task_session_id) WHERE first<>1"
                    )
                    .fetchone()
                )
            )
            == 0,
            "transition_sequence_contiguous": int(
                _scalar(
                    self._reader()
                    .execute(
                        "SELECT COUNT(*) FROM (SELECT task_session_id,COUNT(*) AS n,MAX(sequence) AS last "
                        "FROM task_session_transitions GROUP BY task_session_id) WHERE n<>last"
                    )
                    .fetchone()
                )
            )
            == 0,
            "transition_chain_linked": int(
                _scalar(
                    self._reader()
                    .execute(
                        "SELECT COUNT(*) FROM task_session_transitions current "
                        "LEFT JOIN task_session_transitions previous ON previous.task_session_id=current.task_session_id "
                        "AND previous.sequence=current.sequence-1 WHERE current.sequence>1 "
                        "AND (previous.transition_id IS NULL OR current.from_state<>previous.to_state)"
                    )
                    .fetchone()
                )
            )
            == 0,
            "plan_current_revision_exists": int(
                _scalar(
                    self._reader()
                    .execute(
                        "SELECT COUNT(*) FROM task_plans plan LEFT JOIN task_plan_revisions revision "
                        "ON revision.plan_id=plan.plan_id AND revision.revision=plan.current_revision "
                        "WHERE revision.revision_id IS NULL"
                    )
                    .fetchone()
                )
            )
            == 0,
            "checkpoint_session_matches_plan": int(
                _scalar(
                    self._reader()
                    .execute(
                        "SELECT COUNT(*) FROM task_plan_checkpoints checkpoint JOIN task_plans plan "
                        "ON plan.plan_id=checkpoint.plan_id "
                        "WHERE checkpoint.task_session_id<>plan.task_session_id"
                    )
                    .fetchone()
                )
            )
            == 0,
            "lifecycle_head_matches_sequence": int(
                _scalar(
                    self._reader()
                    .execute(
                        "SELECT COUNT(*) FROM workflow_lifecycle_heads head LEFT JOIN "
                        "(SELECT task_session_id,MAX(sequence) AS last FROM workflow_lifecycle_events "
                        "GROUP BY task_session_id) event ON event.task_session_id=head.task_session_id "
                        "WHERE COALESCE(event.last,0)<>head.last_sequence"
                    )
                    .fetchone()
                )
            )
            == 0,
        }
        return {
            "ok": all(checks.values()),
            "schema_version": "persistmind.task_recovery_semantics.v1",
            "checks": checks,
            "counts": counts,
            "semantic_hashes": hashes,
        }

    def create_session(
        self,
        task_session_id: str,
        *,
        state: str,
        payload: Mapping[str, Any],
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        encoded = _encoded(payload)
        with self._write_lock, self.connection:
            if idempotency_key:
                existing = self.connection.execute(
                    "SELECT task_session_id FROM task_sessions WHERE idempotency_key=?",
                    (idempotency_key,),
                ).fetchone()
                if existing:
                    return self.session(str(existing[0])) or {}
            existing = self.connection.execute(
                "SELECT task_session_id FROM task_sessions WHERE task_session_id=?",
                (task_session_id,),
            ).fetchone()
            if existing:
                raise TaskConflict(f"task session already exists: {task_session_id}")
            now = _now()
            self.connection.execute(
                "INSERT INTO task_sessions VALUES(?,?,?,?,?,?,?)",
                (task_session_id, state, encoded, 1, idempotency_key, now, now),
            )
            self.connection.execute(
                "INSERT INTO task_session_transitions VALUES(?,?,?,?,?,?,?,?)",
                (
                    f"transition:{task_session_id}:1",
                    task_session_id,
                    1,
                    None,
                    state,
                    encoded,
                    idempotency_key,
                    now,
                ),
            )
            self._advance_revision()
        return self.session(task_session_id) or {}

    def session(self, task_session_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute(
                "SELECT task_session_id,state,payload_json,revision,created_at,updated_at "
                "FROM task_sessions WHERE task_session_id=?",
                (task_session_id,),
            )
            .fetchone()
        )
        return _task_row(row) if row else None

    def transition(
        self,
        task_session_id: str,
        *,
        to_state: str,
        payload: Mapping[str, Any],
        expected_revision: int,
        transition_id: str,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        encoded = _encoded(payload)
        with self._write_lock, self.connection:
            if idempotency_key:
                existing = self.connection.execute(
                    "SELECT task_session_id FROM task_session_transitions WHERE idempotency_key=?",
                    (idempotency_key,),
                ).fetchone()
                if existing:
                    return self.session(str(existing[0])) or {}
            row = self.connection.execute(
                "SELECT state,revision FROM task_sessions WHERE task_session_id=?",
                (task_session_id,),
            ).fetchone()
            if row is None:
                raise KeyError(task_session_id)
            if int(row["revision"]) != expected_revision:
                raise TaskConflict(
                    f"stale task session revision: expected={expected_revision} "
                    f"actual={row['revision']}"
                )
            next_revision = expected_revision + 1
            now = _now()
            cursor = self.connection.execute(
                "UPDATE task_sessions SET state=?,payload_json=?,revision=?,updated_at=? "
                "WHERE task_session_id=? AND revision=?",
                (to_state, encoded, next_revision, now, task_session_id, expected_revision),
            )
            if cursor.rowcount != 1:
                raise TaskConflict("task session compare-and-swap failed")
            self.connection.execute(
                "INSERT INTO task_session_transitions VALUES(?,?,?,?,?,?,?,?)",
                (
                    transition_id,
                    task_session_id,
                    next_revision,
                    str(row["state"]),
                    to_state,
                    encoded,
                    idempotency_key,
                    now,
                ),
            )
            self._advance_revision()
        return self.session(task_session_id) or {}

    def transitions(self, task_session_id: str) -> Sequence[Mapping[str, Any]]:
        return [
            {
                **_decoded(row["payload_json"]),
                "transition_id": str(row["transition_id"]),
                "sequence": int(row["sequence"]),
                "from_state": row["from_state"],
                "to_state": row["to_state"],
                "created_at": row["created_at"],
            }
            for row in self._reader().execute(
                "SELECT * FROM task_session_transitions WHERE task_session_id=? ORDER BY sequence",
                (task_session_id,),
            )
        ]

    def write_plan(
        self,
        plan_id: str,
        *,
        task_session_id: str,
        status: str,
        payload: Mapping[str, Any],
        expected_revision: int | None = None,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        encoded = _encoded(payload)
        with self._write_lock, self.connection:
            if idempotency_key:
                existing = self.connection.execute(
                    "SELECT plan_id FROM task_plans WHERE idempotency_key=?",
                    (idempotency_key,),
                ).fetchone()
                if existing:
                    return self.plan(str(existing[0])) or {}
            current = self.connection.execute(
                "SELECT current_revision FROM task_plans WHERE plan_id=?", (plan_id,)
            ).fetchone()
            now = _now()
            if current is None:
                if expected_revision not in {None, 0}:
                    raise TaskConflict("new plan requires expected revision 0")
                revision = 1
                self.connection.execute(
                    "INSERT INTO task_plans VALUES(?,?,?,?,?,?,?,?)",
                    (
                        plan_id,
                        task_session_id,
                        status,
                        revision,
                        encoded,
                        idempotency_key,
                        now,
                        now,
                    ),
                )
            else:
                actual = int(current[0])
                if expected_revision != actual:
                    raise TaskConflict(
                        f"stale plan revision: expected={expected_revision} actual={actual}"
                    )
                revision = actual + 1
                cursor = self.connection.execute(
                    "UPDATE task_plans SET status=?,current_revision=?,payload_json=?,"
                    "idempotency_key=?,updated_at=? WHERE plan_id=? AND current_revision=?",
                    (
                        status,
                        revision,
                        encoded,
                        idempotency_key,
                        now,
                        plan_id,
                        actual,
                    ),
                )
                if cursor.rowcount != 1:
                    raise TaskConflict("plan compare-and-swap failed")
            self.connection.execute(
                "INSERT INTO task_plan_revisions VALUES(?,?,?,?,?,?)",
                (
                    f"plan-revision:{plan_id}:{revision}",
                    plan_id,
                    revision,
                    encoded,
                    idempotency_key,
                    now,
                ),
            )
            self._advance_revision()
        return self.plan(plan_id) or {}

    def plan(self, plan_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute("SELECT * FROM task_plans WHERE plan_id=?", (plan_id,))
            .fetchone()
        )
        if row is None:
            return None
        return {
            **_decoded(row["payload_json"]),
            "plan_id": str(row["plan_id"]),
            "task_session_id": str(row["task_session_id"]),
            "status": str(row["status"]),
            "revision": int(row["current_revision"]),
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    def latest_plan(self, task_session_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute(
                "SELECT plan_id FROM task_plans WHERE task_session_id=? "
                "ORDER BY updated_at DESC,plan_id DESC LIMIT 1",
                (task_session_id,),
            )
            .fetchone()
        )
        return self.plan(str(row[0])) if row else None

    def plan_revisions(self, plan_id: str) -> Sequence[Mapping[str, Any]]:
        return [
            {
                **_decoded(row["payload_json"]),
                "revision_id": str(row["revision_id"]),
                "revision": int(row["revision"]),
                "created_at": row["created_at"],
            }
            for row in self._reader().execute(
                "SELECT * FROM task_plan_revisions WHERE plan_id=? ORDER BY revision",
                (plan_id,),
            )
        ]

    def create_plan_checkpoint(
        self,
        checkpoint_id: str,
        *,
        plan_id: str,
        task_session_id: str,
        payload: Mapping[str, Any],
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        encoded = _encoded(payload)
        with self._write_lock, self.connection:
            if idempotency_key:
                existing = self.connection.execute(
                    "SELECT checkpoint_id FROM task_plan_checkpoints WHERE idempotency_key=?",
                    (idempotency_key,),
                ).fetchone()
                if existing:
                    return self.checkpoint_record(str(existing[0])) or {}
            self.connection.execute(
                "INSERT INTO task_plan_checkpoints VALUES(?,?,?,?,?,?)",
                (checkpoint_id, plan_id, task_session_id, encoded, idempotency_key, _now()),
            )
            self._advance_revision()
        return self.checkpoint_record(checkpoint_id) or {}

    def checkpoint_record(self, checkpoint_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute("SELECT * FROM task_plan_checkpoints WHERE checkpoint_id=?", (checkpoint_id,))
            .fetchone()
        )
        if row is None:
            return None
        return {
            **_decoded(row["payload_json"]),
            "checkpoint_id": str(row["checkpoint_id"]),
            "plan_id": str(row["plan_id"]),
            "task_session_id": str(row["task_session_id"]),
            "created_at": row["created_at"],
        }

    def checkpoints(self, plan_id: str) -> Sequence[Mapping[str, Any]]:
        rows = self._reader().execute(
            "SELECT checkpoint_id FROM task_plan_checkpoints WHERE plan_id=? "
            "ORDER BY created_at,checkpoint_id",
            (plan_id,),
        )
        return [item for row in rows if (item := self.checkpoint_record(str(row[0]))) is not None]

    def append_verification(
        self,
        verification_id: str,
        *,
        task_session_id: str,
        payload: Mapping[str, Any],
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        encoded = _encoded(payload)
        with self._write_lock, self.connection:
            if idempotency_key:
                existing = self.connection.execute(
                    "SELECT verification_id FROM task_verifications WHERE idempotency_key=?",
                    (idempotency_key,),
                ).fetchone()
                if existing:
                    return self.verification(str(existing[0])) or {}
            self.connection.execute(
                "INSERT INTO task_verifications VALUES(?,?,?,?,?)",
                (verification_id, task_session_id, encoded, idempotency_key, _now()),
            )
            self._advance_revision()
        return self.verification(verification_id) or {}

    def verification(self, verification_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute("SELECT * FROM task_verifications WHERE verification_id=?", (verification_id,))
            .fetchone()
        )
        if row is None:
            return None
        return {
            **_decoded(row["payload_json"]),
            "verification_id": str(row["verification_id"]),
            "task_session_id": str(row["task_session_id"]),
            "created_at": row["created_at"],
        }

    def verifications(self, task_session_id: str) -> Sequence[Mapping[str, Any]]:
        rows = self._reader().execute(
            "SELECT verification_id FROM task_verifications "
            "WHERE task_session_id=? ORDER BY created_at DESC,verification_id DESC",
            (task_session_id,),
        )
        return [item for row in rows if (item := self.verification(str(row[0]))) is not None]

    def save_workflow_snapshot(
        self,
        task_session_id: str,
        *,
        payload: Mapping[str, Any],
        pack_id: str | None = None,
        plan_id: str | None = None,
        expected_revision: int | None = None,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        encoded = _encoded(payload)
        with self._write_lock, self.connection:
            current = self.connection.execute(
                "SELECT revision,pack_id,plan_id FROM task_workflow_snapshots "
                "WHERE task_session_id=?",
                (task_session_id,),
            ).fetchone()
            now = _now()
            if current is None:
                if expected_revision not in {None, 0}:
                    raise TaskConflict("new workflow snapshot requires expected revision 0")
                revision = 1
                self.connection.execute(
                    "INSERT INTO task_workflow_snapshots VALUES(?,?,?,?,?,?,?)",
                    (
                        task_session_id,
                        pack_id,
                        plan_id,
                        encoded,
                        revision,
                        idempotency_key,
                        now,
                    ),
                )
            else:
                actual = int(current["revision"])
                if expected_revision != actual:
                    raise TaskConflict(
                        f"stale workflow snapshot: expected={expected_revision} actual={actual}"
                    )
                revision = actual + 1
                cursor = self.connection.execute(
                    "UPDATE task_workflow_snapshots SET pack_id=?,plan_id=?,payload_json=?,"
                    "revision=?,idempotency_key=?,updated_at=? "
                    "WHERE task_session_id=? AND revision=?",
                    (
                        pack_id if pack_id is not None else current["pack_id"],
                        plan_id if plan_id is not None else current["plan_id"],
                        encoded,
                        revision,
                        idempotency_key,
                        now,
                        task_session_id,
                        actual,
                    ),
                )
                if cursor.rowcount != 1:
                    raise TaskConflict("workflow snapshot compare-and-swap failed")
            self._advance_revision()
        return self.workflow_snapshot(task_session_id) or {}

    def workflow_snapshot(self, task_session_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute(
                "SELECT * FROM task_workflow_snapshots WHERE task_session_id=?",
                (task_session_id,),
            )
            .fetchone()
        )
        if row is None:
            return None
        return {
            **_decoded(row["payload_json"]),
            "task_session_id": str(row["task_session_id"]),
            "pack_id": row["pack_id"],
            "plan_id": row["plan_id"],
            "revision": int(row["revision"]),
            "updated_at": row["updated_at"],
        }

    def rebind_pack(
        self,
        task_session_id: str,
        *,
        pack_id: str,
        expected_revision: int,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        current = self.workflow_snapshot(task_session_id)
        if current is None:
            raise KeyError(task_session_id)
        return self.save_workflow_snapshot(
            task_session_id,
            payload=current,
            pack_id=pack_id,
            plan_id=str(current["plan_id"]) if current.get("plan_id") else None,
            expected_revision=expected_revision,
            idempotency_key=idempotency_key,
        )

    def upsert_continuation(
        self,
        continuation_id: str,
        *,
        task_session_id: str,
        task_hash: str,
        status: str,
        payload: Mapping[str, Any],
        expected_revision: int | None = None,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        encoded = _encoded(payload)
        with self._write_lock, self.connection:
            current = self.connection.execute(
                "SELECT revision FROM task_continuations WHERE continuation_id=?",
                (continuation_id,),
            ).fetchone()
            now = _now()
            if current is None:
                if expected_revision not in {None, 0}:
                    raise TaskConflict("new continuation requires expected revision 0")
                revision = 1
                self.connection.execute(
                    "INSERT INTO task_continuations VALUES(?,?,?,?,?,?,?,?,?)",
                    (
                        continuation_id,
                        task_session_id,
                        task_hash,
                        status,
                        encoded,
                        revision,
                        idempotency_key,
                        now,
                        now,
                    ),
                )
            else:
                actual = int(current[0])
                if expected_revision != actual:
                    raise TaskConflict(
                        f"stale continuation revision: expected={expected_revision} actual={actual}"
                    )
                revision = actual + 1
                cursor = self.connection.execute(
                    "UPDATE task_continuations SET task_session_id=?,task_hash=?,status=?,"
                    "payload_json=?,revision=?,idempotency_key=?,updated_at=? "
                    "WHERE continuation_id=? AND revision=?",
                    (
                        task_session_id,
                        task_hash,
                        status,
                        encoded,
                        revision,
                        idempotency_key,
                        now,
                        continuation_id,
                        actual,
                    ),
                )
                if cursor.rowcount != 1:
                    raise TaskConflict("continuation compare-and-swap failed")
            self._advance_revision()
        return self.continuation(continuation_id) or {}

    def continuation(self, continuation_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute("SELECT * FROM task_continuations WHERE continuation_id=?", (continuation_id,))
            .fetchone()
        )
        return _continuation_row(row) if row else None

    def active_continuation(self, task_session_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute(
                "SELECT * FROM task_continuations WHERE task_session_id=? AND status='active' "
                "ORDER BY updated_at DESC LIMIT 1",
                (task_session_id,),
            )
            .fetchone()
        )
        return _continuation_row(row) if row else None

    def continuations(
        self, *, status: str | None = None, limit: int = 20
    ) -> Sequence[Mapping[str, Any]]:
        clauses = []
        values: list[Any] = []
        if status:
            clauses.append("status=?")
            values.append(status)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        values.append(max(1, min(limit, 1000)))
        return [
            _continuation_row(row)
            for row in self._reader().execute(
                "SELECT * FROM task_continuations"
                + where
                + " ORDER BY updated_at DESC,continuation_id LIMIT ?",
                values,
            )
        ]

    def acquire_lease(
        self,
        lease_name: str,
        *,
        owner: str,
        token: str,
        owner_boot_id: str,
        owner_nonce: str,
        duration_ms: int = 30_000,
        recovery_proof: Mapping[str, Any] | None = None,
    ) -> Mapping[str, Any]:
        """Acquire a fenced task lease without inferring stale ownership.

        Expiration is necessary but never sufficient to replace an owner.  A
        coordinator must provide an explicit monotonic recovery proof, which
        leaves product-runtime identity validation to the broker layer.
        """

        if not lease_name or not owner or not token or not owner_boot_id or not owner_nonce:
            raise ValueError("task lease requires name, owner, token, boot id, and nonce")
        if duration_ms < 1 or duration_ms > 30_000:
            raise ValueError("task lease duration must be between 1 and 30000 milliseconds")
        now = _lease_now()
        now_text = _lease_timestamp(now)
        expires_at = _lease_expiry(now, duration_ms)
        with self._write_lock, self.connection:
            current = self.connection.execute(
                "SELECT * FROM task_leases WHERE lease_name=?", (lease_name,)
            ).fetchone()
            if current is None:
                fence = 1
                self.connection.execute(
                    "INSERT INTO task_leases VALUES(?,?,?,?,?,?,?,?,?)",
                    (
                        lease_name,
                        token,
                        owner,
                        owner_boot_id,
                        owner_nonce,
                        fence,
                        expires_at,
                        now_text,
                        None,
                    ),
                )
            elif str(current["token"]) == token:
                if int(current["fencing_token"]) < 1:
                    raise TaskConflict("invalid task lease fencing token")
                fence = int(current["fencing_token"])
                self.connection.execute(
                    "UPDATE task_leases SET owner=?,owner_boot_id=?,owner_nonce=?,"
                    "expires_at=?,heartbeat_at=? WHERE lease_name=? AND token=?",
                    (
                        owner,
                        owner_boot_id,
                        owner_nonce,
                        expires_at,
                        now_text,
                        lease_name,
                        token,
                    ),
                )
            else:
                if not _lease_is_expired(str(current["expires_at"]), now):
                    raise TaskConflict(f"task lease is held: {lease_name}")
                if not _valid_recovery_proof(recovery_proof, current):
                    raise TaskConflict("expired task lease requires a coordinator recovery proof")
                fence = int(current["fencing_token"]) + 1
                self.connection.execute(
                    "UPDATE task_leases SET token=?,owner=?,owner_boot_id=?,owner_nonce=?,"
                    "fencing_token=?,expires_at=?,heartbeat_at=?,recovery_proof_json=? "
                    "WHERE lease_name=? AND fencing_token=?",
                    (
                        token,
                        owner,
                        owner_boot_id,
                        owner_nonce,
                        fence,
                        expires_at,
                        now_text,
                        _encoded(recovery_proof or {}),
                        lease_name,
                        int(current["fencing_token"]),
                    ),
                )
            self._advance_revision()
        return self.lease(lease_name) or {}

    def heartbeat_lease(
        self,
        lease_name: str,
        *,
        token: str,
        fencing_token: int,
        duration_ms: int = 30_000,
    ) -> Mapping[str, Any]:
        if duration_ms < 1 or duration_ms > 30_000:
            raise ValueError("task lease duration must be between 1 and 30000 milliseconds")
        now = _lease_now()
        now_text = _lease_timestamp(now)
        with self._write_lock, self.connection:
            cursor = self.connection.execute(
                "UPDATE task_leases SET expires_at=?,heartbeat_at=? "
                "WHERE lease_name=? AND token=? AND fencing_token=?",
                (
                    _lease_expiry(now, duration_ms),
                    now_text,
                    lease_name,
                    token,
                    fencing_token,
                ),
            )
            if cursor.rowcount != 1:
                raise TaskConflict("task lease heartbeat rejected by fencing token")
            self._advance_revision()
        return self.lease(lease_name) or {}

    def release_lease(self, lease_name: str, *, token: str, fencing_token: int) -> bool:
        with self._write_lock, self.connection:
            cursor = self.connection.execute(
                "DELETE FROM task_leases WHERE lease_name=? AND token=? AND fencing_token=?",
                (lease_name, token, fencing_token),
            )
            if cursor.rowcount:
                self._advance_revision()
        return cursor.rowcount == 1

    def lease(self, lease_name: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute("SELECT * FROM task_leases WHERE lease_name=?", (lease_name,))
            .fetchone()
        )
        if row is None:
            return None
        return {
            "lease_name": str(row["lease_name"]),
            "token": str(row["token"]),
            "owner": str(row["owner"]),
            "owner_boot_id": str(row["owner_boot_id"]),
            "owner_nonce": str(row["owner_nonce"]),
            "fencing_token": int(row["fencing_token"]),
            "expires_at": str(row["expires_at"]),
            "heartbeat_at": str(row["heartbeat_at"]),
            "recovery_proof": _decoded(str(row["recovery_proof_json"] or "{}")),
        }

    def continuations_for_task_hash(self, task_hash: str) -> Sequence[Mapping[str, Any]]:
        return [
            _continuation_row(row)
            for row in self._reader().execute(
                "SELECT * FROM task_continuations WHERE task_hash=? AND status='active' "
                "ORDER BY updated_at DESC",
                (task_hash,),
            )
        ]

    def freeze_evidence_manifest(
        self,
        manifest_id: str,
        *,
        task_session_id: str,
        payload: Mapping[str, Any],
        state: str = "active",
        expected_revision: int | None = None,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        value = dict(payload)
        declared = {str(item) for item in value.get("declared_paths", [])}
        ambient = {str(item) for item in value.get("ambient_paths", [])}
        if declared & ambient:
            raise ValueError("task evidence declared_paths and ambient_paths must not overlap")
        value["declared_paths"] = sorted(declared)
        value["ambient_paths"] = sorted(ambient)
        encoded = _encoded(value)
        with self._write_lock, self.connection:
            current = self.connection.execute(
                "SELECT task_session_id,state,payload_json,revision,idempotency_key "
                "FROM task_evidence_manifests WHERE manifest_id=?",
                (manifest_id,),
            ).fetchone()
            now = _now()
            if current is None:
                if expected_revision not in {None, 0}:
                    raise TaskConflict("new evidence manifest requires expected revision 0")
                revision = 1
                self.connection.execute(
                    "INSERT INTO task_evidence_manifests VALUES(?,?,?,?,?,?,?,?)",
                    (
                        manifest_id,
                        task_session_id,
                        state,
                        encoded,
                        revision,
                        idempotency_key,
                        now,
                        now,
                    ),
                )
            else:
                actual = int(current["revision"])
                if idempotency_key and str(current["idempotency_key"] or "") == idempotency_key:
                    if (
                        str(current["task_session_id"]) != task_session_id
                        or str(current["state"]) != state
                        or str(current["payload_json"]) != encoded
                    ):
                        raise TaskConflict("task evidence idempotency key was reused with new data")
                    return self.evidence_manifest(manifest_id) or {}
                if expected_revision != actual:
                    raise TaskConflict(
                        f"stale task evidence manifest: expected={expected_revision} actual={actual}"
                    )
                revision = actual + 1
                cursor = self.connection.execute(
                    "UPDATE task_evidence_manifests SET state=?,payload_json=?,revision=?,"
                    "idempotency_key=?,updated_at=? WHERE manifest_id=? AND revision=?",
                    (
                        state,
                        encoded,
                        revision,
                        idempotency_key,
                        now,
                        manifest_id,
                        actual,
                    ),
                )
                if cursor.rowcount != 1:
                    raise TaskConflict("evidence manifest compare-and-swap failed")
            self._advance_revision()
        return self.evidence_manifest(manifest_id) or {}

    def evidence_manifest(self, manifest_id: str) -> Mapping[str, Any] | None:
        row = (
            self._reader()
            .execute("SELECT * FROM task_evidence_manifests WHERE manifest_id=?", (manifest_id,))
            .fetchone()
        )
        if row is None:
            return None
        return {
            **_decoded(row["payload_json"]),
            "manifest_id": str(row["manifest_id"]),
            "task_session_id": str(row["task_session_id"]),
            "state": str(row["state"]),
            "revision": int(row["revision"]),
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    def compare_and_swap(
        self, record_id: str, expected_revision: int, value: Mapping[str, Any]
    ) -> bool:
        payload = _encoded(value)
        digest = hashlib.sha256(payload.encode()).hexdigest()
        with self._write_lock, self.connection:
            cursor = self.connection.execute(
                "UPDATE domain_records SET payload_json=?,content_hash=?,"
                "revision=revision+1,updated_at=? "
                "WHERE record_id=? AND revision=?",
                (payload, digest, _now(), record_id, expected_revision),
            )
            if cursor.rowcount:
                self._advance_revision()
        return cursor.rowcount == 1

    def _advance_revision(self) -> None:
        self.connection.execute("UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1")


def _encoded(value: Mapping[str, Any]) -> str:
    return json.dumps(dict(value), sort_keys=True, separators=(",", ":"), default=str)


def _decoded(value: str) -> dict[str, Any]:
    parsed = json.loads(value)
    return parsed if isinstance(parsed, dict) else {}


def _task_row(row: Any) -> Mapping[str, Any]:
    return {
        **_decoded(str(row["payload_json"])),
        "task_session_id": str(row["task_session_id"]),
        "state": str(row["state"]),
        "revision": int(row["revision"]),
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def _continuation_row(row: Any) -> Mapping[str, Any]:
    return {
        **_decoded(str(row["payload_json"])),
        "continuation_id": str(row["continuation_id"]),
        "task_session_id": str(row["task_session_id"]),
        "task_hash": str(row["task_hash"]),
        "status": str(row["status"]),
        "revision": int(row["revision"]),
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def _lease_now() -> datetime:
    return datetime.now(timezone.utc)


def _lease_expiry(now: datetime, duration_ms: int) -> str:
    return _lease_timestamp(now + timedelta(milliseconds=duration_ms))


def _lease_timestamp(value: datetime) -> str:
    return value.isoformat(timespec="microseconds").replace("+00:00", "Z")


def _lease_is_expired(value: str, now: datetime) -> bool:
    try:
        expiry = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    return expiry <= now


def _valid_recovery_proof(proof: Mapping[str, Any] | None, current: Any) -> bool:
    if not isinstance(proof, Mapping):
        return False
    if proof.get("coordinator") != "storage-runtime":
        return False
    if proof.get("owner_identity_checked") is not True:
        return False
    if int(proof.get("monotonic_elapsed_ms") or 0) < 30_000:
        return False
    return int(proof.get("prior_fencing_token") or -1) == int(current["fencing_token"])
