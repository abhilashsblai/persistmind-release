from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from typing import Any

from persistmind.utils import stable_id


def semantic_projection_records(
    generation_id: str,
    nodes: Sequence[Mapping[str, Any]],
    edges: Sequence[Mapping[str, Any]],
    evidence: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for node in nodes:
        row = dict(node)
        node_id = str(row.get("node_id") or "")
        metadata = row.pop("metadata", {})
        provenance = row.pop("provenance", {})
        row["metadata_json"] = json.dumps(metadata if isinstance(metadata, dict) else {})
        row["provenance_json"] = json.dumps(provenance if isinstance(provenance, dict) else {})
        row.update(
            {
                "record_id": "semantic-node-" + stable_id(generation_id, node_id)[:32],
                "kind": "semantic_node",
                "generation_id": generation_id,
            }
        )
        records.append(row)
    for edge in edges:
        row = dict(edge)
        edge_id = str(row.get("edge_id") or "")
        metadata = row.pop("metadata", {})
        evidence_ids = row.pop("evidence", [])
        row["metadata_json"] = json.dumps(metadata if isinstance(metadata, dict) else {})
        row["evidence_json"] = json.dumps(list(evidence_ids) if isinstance(evidence_ids, list) else [])
        row.update(
            {
                "record_id": "semantic-edge-" + stable_id(generation_id, edge_id)[:32],
                "kind": "semantic_edge",
                "generation_id": generation_id,
            }
        )
        records.append(row)
    for item in evidence:
        row = dict(item)
        evidence_id = str(row.get("evidence_id") or "")
        row.update(
            {
                "record_id": "semantic-evidence-" + stable_id(generation_id, evidence_id)[:32],
                "kind": "semantic_evidence",
                "generation_id": generation_id,
            }
        )
        records.append(row)
    return sorted(records, key=lambda item: str(item.get("record_id") or ""))
