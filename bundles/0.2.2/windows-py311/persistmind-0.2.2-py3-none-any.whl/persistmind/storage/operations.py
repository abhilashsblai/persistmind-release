from __future__ import annotations

from typing import Any

from .resources import load_json, sha256


def resources_status() -> dict[str, Any]:
    manifest = load_json("storage-manifest.v1.json")
    expected = manifest.get("hashes", {})
    resources = {name: sha256(name) for name in manifest.get("resources", [])}
    mismatches = {
        name: {"expected": expected.get(name), "actual": digest}
        for name, digest in resources.items()
        if expected.get(name) != digest
    }
    return {
        "ok": not mismatches,
        "status": "verified" if not mismatches else "integrity_failure",
        "schema_version": "persistmind.storage_resources_status.v1",
        "verified": len(resources),
        "resources": resources,
        "mismatches": mismatches,
    }


def memory_kinds_status() -> dict[str, Any]:
    document = load_json("memory-kinds.v1.json")
    kinds = document.get("kinds", [])
    return {
        "ok": True,
        "schema_version": "persistmind.storage_memory_kinds_status.v1",
        "count": len(kinds),
        "kinds": kinds,
    }
