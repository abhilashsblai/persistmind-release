from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import shutil
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from .adapters.apsw_driver import open_nextgen_connection
from .catalog import FileCatalog
from .descriptors import StoreRole, TopologyManifest
from .lifecycle import OperationFence
from .runtime import StorageNotInitialized, inspect_storage


_REFERENCE = re.compile(r"sha256:[0-9a-f]{64}")


class PrivacyDeletionService:
    """Versioned serving withdrawal and cross-tier erasure state machine."""

    def __init__(self, workspace_root: Path, *, allow_development_driver: bool = False) -> None:
        self.root = workspace_root.resolve()
        self.catalog = FileCatalog(self.root / "catalog")
        self.allow_development_driver = allow_development_driver

    def hold_create(self, scope: str, reason: str) -> dict[str, Any]:
        if not scope.strip() or not reason.strip():
            raise ValueError("legal hold scope and reason are required")
        scope_hash = _scope_hash(scope)
        hold_id = "hold-" + secrets.token_hex(12)
        descriptor = self._authority_store()
        connection = open_nextgen_connection(
            self.catalog.resolve_location(descriptor.location),
            allow_development_driver=self.allow_development_driver,
        )
        try:
            with connection:
                connection.execute(
                    "INSERT INTO domain_legal_holds VALUES(?,?,?,'active',?,NULL)",
                    (hold_id, scope_hash, reason.strip(), _now()),
                )
        finally:
            connection.close()
        return {
            "ok": True,
            "status": "active",
            "schema_version": "persistmind.legal_hold.v1",
            "hold_id": hold_id,
            "scope_hash": scope_hash,
        }

    def hold_release(self, hold_id: str) -> dict[str, Any]:
        descriptor = self._authority_store()
        connection = open_nextgen_connection(
            self.catalog.resolve_location(descriptor.location),
            allow_development_driver=self.allow_development_driver,
        )
        try:
            with connection:
                cursor = connection.execute(
                    "UPDATE domain_legal_holds SET state='released',released_at=? "
                    "WHERE hold_id=? AND state='active'",
                    (_now(), hold_id),
                )
                changed = cursor.rowcount
        finally:
            connection.close()
        if changed != 1:
            raise KeyError(hold_id)
        return {
            "ok": True,
            "status": "released",
            "schema_version": "persistmind.legal_hold.v1",
            "hold_id": hold_id,
        }

    def plan(self, scope: str) -> dict[str, Any]:
        inspection = inspect_storage(self.root)
        if not inspection.initialized or inspection.topology is None:
            raise StorageNotInitialized("persistmind-nextgen-v1 storage is not initialized")
        scope_hash = _scope_hash(scope)
        holds: list[dict[str, Any]] = []
        mutable: list[dict[str, Any]] = []
        sealed: list[dict[str, Any]] = []
        retained_authority: list[dict[str, Any]] = []
        scoped_refs: set[str] = set()
        outside_refs: set[str] = set()
        for descriptor in inspection.topology.stores:
            path = self.catalog.resolve_location(descriptor.location)
            connection = open_nextgen_connection(
                path,
                read_only=True,
                allow_development_driver=self.allow_development_driver,
            )
            try:
                holds.extend(_holds(connection, scope_hash, descriptor.store_id))
                matches, inside, outside = _matches(connection, scope)
                scoped_refs.update(inside)
                outside_refs.update(outside)
                target = {
                    "store_id": descriptor.store_id,
                    "role": descriptor.store_role.value,
                    "path": descriptor.location,
                    "rows": matches,
                }
                if not matches:
                    continue
                if descriptor.store_role in {
                    StoreRole.POLICY,
                    StoreRole.AUDIT_ACTIVE,
                    StoreRole.AUDIT_SEALED,
                }:
                    retained_authority.append(target)
                elif descriptor.read_only:
                    sealed.append(target)
                else:
                    mutable.append(target)
            finally:
                connection.close()
        exclusive_objects = sorted(scoped_refs - outside_refs)
        shared_objects = sorted(scoped_refs & outside_refs)
        backups = sorted(
            item.name for item in (self.root / "backups").glob("bkp-*") if item.is_dir()
        )
        plan: dict[str, Any] = {
            "schema_version": "persistmind.privacy_delete_plan.v1",
            "scope_hash": scope_hash,
            "topology_generation": inspection.topology.generation,
            "holds": holds,
            "mutable": mutable,
            "sealed_rewrites": sealed,
            "retained_authority": retained_authority,
            "exclusive_objects": exclusive_objects,
            "shared_objects": shared_objects,
            "retained_backups": backups,
            "backup_last_eligible_at": (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()
            if backups
            else None,
        }
        plan["plan_hash"] = _document_hash(plan)
        return plan

    def apply(self, scope: str, plan: dict[str, Any]) -> dict[str, Any]:
        expected = self.plan(scope)
        if plan.get("plan_hash") != expected["plan_hash"]:
            raise RuntimeError("privacy deletion plan is stale or modified")
        if plan["holds"]:
            result = self._result(plan, "retained_by_policy", blocker="legal_hold")
            self._record_tombstone(plan, result)
            return result
        with OperationFence(
            self.root,
            "privacy-delete",
            {"plan_hash": plan["plan_hash"], "scope_hash": plan["scope_hash"]},
            scope="privacy",
        ) as fence:
            self._delete_mutable(plan)
            rewritten = self._rewrite_sealed(plan)
            erased_objects = self._erase_objects(plan)
            self._write_backup_tombstone(plan)
            status = (
                "erasure_pending"
                if plan["retained_backups"] or plan["shared_objects"]
                else "erased"
            )
            blocker = (
                "retained_backups"
                if plan["retained_backups"]
                else "shared_objects"
                if plan["shared_objects"]
                else None
            )
            result = self._result(
                plan,
                status,
                blocker=blocker,
                rewritten=rewritten,
                erased_objects=erased_objects,
            )
            self._record_tombstone(plan, result)
            fence.succeed(result)
            return result

    def _delete_mutable(self, plan: dict[str, Any]) -> None:
        for store in plan["mutable"]:
            descriptor = self._descriptor(str(store["store_id"]))
            connection = open_nextgen_connection(
                self.catalog.resolve_location(descriptor.location),
                allow_development_driver=self.allow_development_driver,
            )
            try:
                with connection:
                    for row in store["rows"]:
                        connection.execute(
                            f'DELETE FROM "{_identifier(row["table"])}" WHERE rowid=?',
                            (int(row["rowid"]),),
                        )
                    _rebuild_fts(connection)
            finally:
                connection.close()

    def _rewrite_sealed(self, plan: dict[str, Any]) -> list[str]:
        if not plan["sealed_rewrites"]:
            return []
        topology = self.catalog.current()
        changed: dict[str, str] = {}
        for store in plan["sealed_rewrites"]:
            descriptor = self._descriptor(str(store["store_id"]))
            source = self.catalog.resolve_location(descriptor.location)
            replacement = source.with_suffix(".privacy-rewrite.tmp")
            shutil.copy2(source, replacement)
            connection = open_nextgen_connection(
                replacement,
                allow_development_driver=self.allow_development_driver,
            )
            try:
                with connection:
                    for row in store["rows"]:
                        connection.execute(
                            f'DELETE FROM "{_identifier(row["table"])}" WHERE rowid=?',
                            (int(row["rowid"]),),
                        )
                    _rebuild_fts(connection)
                integrity_row = connection.execute("PRAGMA integrity_check").fetchone()
                if integrity_row is None or str(integrity_row[0]) != "ok":
                    raise RuntimeError("sealed rewrite integrity failure")
            finally:
                connection.close()
            os.replace(replacement, source)
            changed[descriptor.store_id] = _file_hash(source)
        stores = tuple(
            replace(
                item,
                physical_image_hash=changed[item.store_id],
                generation=item.generation + 1,
            )
            if item.store_id in changed
            else item
            for item in topology.stores
        )
        self.catalog.activate(
            TopologyManifest(
                topology_id=topology.topology_id,
                generation=topology.generation + 1,
                profile=topology.profile,
                stores=stores,
                workspace_id=topology.workspace_id,
                contract_hash=topology.contract_hash,
                created_at=topology.created_at,
            ),
            expected_generation=topology.generation,
        )
        return sorted(changed)

    def _erase_objects(self, plan: dict[str, Any]) -> list[str]:
        erased = []
        for reference in plan["exclusive_objects"]:
            digest = reference.removeprefix("sha256:")
            target = self.root / "objects" / "sha256" / digest[:2] / digest
            if target.exists():
                shutil.rmtree(target)
                erased.append(reference)
        return erased

    def _write_backup_tombstone(self, plan: dict[str, Any]) -> None:
        if not plan["retained_backups"]:
            return
        path = self.root / "backups" / "tombstones" / f"{plan['scope_hash']}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(
                {
                    "schema_version": "persistmind.backup_tombstone.v1",
                    "scope_hash": plan["scope_hash"],
                    "backup_ids": plan["retained_backups"],
                    "last_eligible_at": plan["backup_last_eligible_at"],
                },
                sort_keys=True,
                separators=(",", ":"),
            ),
            encoding="utf-8",
        )

    def _record_tombstone(self, plan: dict[str, Any], result: dict[str, Any]) -> None:
        descriptor = self._authority_store()
        connection = open_nextgen_connection(
            self.catalog.resolve_location(descriptor.location),
            allow_development_driver=self.allow_development_driver,
        )
        now = _now()
        tombstone_id = "erase-" + str(plan["scope_hash"])[:24]
        try:
            with connection:
                connection.execute(
                    "INSERT INTO domain_erasure_tombstones VALUES(?,?,?,?,?,?,?,?) "
                    "ON CONFLICT(tombstone_id) DO UPDATE SET state=excluded.state,"
                    "blocker=excluded.blocker,next_eligible_at=excluded.next_eligible_at,"
                    "evidence_hash=excluded.evidence_hash,updated_at=excluded.updated_at",
                    (
                        tombstone_id,
                        plan["scope_hash"],
                        result["status"],
                        result.get("blocker"),
                        plan.get("backup_last_eligible_at"),
                        _document_hash(result),
                        now,
                        now,
                    ),
                )
        finally:
            connection.close()

    def _result(
        self,
        plan: dict[str, Any],
        status: str,
        *,
        blocker: str | None,
        rewritten: list[str] | None = None,
        erased_objects: list[str] | None = None,
    ) -> dict[str, Any]:
        return {
            "ok": status in {"erased", "erasure_pending", "retained_by_policy"},
            "status": status,
            "schema_version": "persistmind.privacy_delete_result.v1",
            "scope_hash": plan["scope_hash"],
            "plan_hash": plan["plan_hash"],
            "serving_withdrawn": True,
            "mutable_rows_deleted": sum(len(item["rows"]) for item in plan["mutable"]),
            "sealed_rewritten": rewritten or [],
            "objects_erased": erased_objects or [],
            "shared_objects": plan["shared_objects"],
            "retained_backups": plan["retained_backups"],
            "next_eligible_at": plan.get("backup_last_eligible_at"),
            "blocker": blocker,
        }

    def _authority_store(self):
        return next(
            item for item in self.catalog.current().stores if item.store_role is StoreRole.POLICY
        )

    def _descriptor(self, store_id: str):
        return next(item for item in self.catalog.current().stores if item.store_id == store_id)


def _matches(connection: Any, scope: str) -> tuple[list[dict[str, Any]], set[str], set[str]]:
    matches: list[dict[str, Any]] = []
    inside: set[str] = set()
    outside: set[str] = set()
    tables = connection.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ).fetchall()
    for table_row in tables:
        table = str(table_row[0])
        if table in {
            "domain_legal_holds",
            "domain_erasure_tombstones",
            "domain_operation_receipts",
        }:
            continue
        quoted = '"' + table.replace('"', '""') + '"'
        try:
            rows = connection.execute(f"SELECT rowid,* FROM {quoted}").fetchall()
        except Exception:
            continue
        for row in rows:
            values = [str(value) for value in row[1:] if value is not None]
            text = "\n".join(values)
            references = set(_REFERENCE.findall(text))
            if scope in text:
                matches.append({"table": table, "rowid": int(row[0])})
                inside.update(references)
            else:
                outside.update(references)
    return matches, inside, outside


def _holds(connection: Any, scope_hash: str, store_id: str) -> list[dict[str, Any]]:
    try:
        rows = connection.execute(
            "SELECT hold_id,reason,created_at FROM domain_legal_holds "
            "WHERE scope_hash=? AND state='active'",
            (scope_hash,),
        ).fetchall()
    except Exception:
        return []
    return [
        {
            "hold_id": str(row[0]),
            "reason": str(row[1]),
            "created_at": str(row[2]),
            "store_id": store_id,
        }
        for row in rows
    ]


def _rebuild_fts(connection: Any) -> None:
    rows = connection.execute(
        "SELECT name,sql FROM sqlite_master WHERE type='table' AND sql LIKE '%VIRTUAL TABLE%FTS5%'"
    ).fetchall()
    for row in rows:
        name = _identifier(str(row[0]))
        try:
            connection.execute(f'INSERT INTO "{name}"("{name}") VALUES(\'rebuild\')')
        except Exception:
            # Contentless indexes are rebuilt by their owning generation service.
            connection.execute(f'DELETE FROM "{name}"')


def _identifier(value: str) -> str:
    if not value or any(
        character not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"
        for character in value
    ):
        raise ValueError("unsafe SQLite identifier")
    return value


def _scope_hash(scope: str) -> str:
    if not scope.strip():
        raise ValueError("privacy scope must be non-empty")
    return hashlib.sha256(scope.encode("utf-8")).hexdigest()


def _document_hash(value: dict[str, Any]) -> str:
    payload = {key: item for key, item in value.items() if key != "plan_hash"}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()
