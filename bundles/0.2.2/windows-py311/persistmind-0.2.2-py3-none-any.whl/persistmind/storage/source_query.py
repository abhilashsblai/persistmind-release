from __future__ import annotations

import json
import struct
from collections.abc import Iterable
from typing import Any


def snapshot_scoped_chunk_search_sql(
    snapshot_id: str, terms: Iterable[str], limit: int
) -> tuple[str, list[Any]]:
    needles = [str(term).casefold() for term in terms if str(term).strip()][:8]
    if not needles:
        return "SELECT c.*, 100.0 AS rank FROM chunks c WHERE 0", []
    sql = """
        SELECT c.*, rank AS rank
        FROM chunks_fts
        JOIN chunks c ON c.chunk_id=chunks_fts.chunk_id
        WHERE c.snapshot_id=? AND text_normalized MATCH ?
        ORDER BY rank,c.path,COALESCE(c.start_line,0),c.chunk_id
        LIMIT ?
    """
    return sql, [snapshot_id, _fts_expression(needles), max(1, int(limit))]


def _fts_expression(terms: Iterable[str]) -> str:
    escaped = [str(term).replace('"', '""') for term in terms][:8]
    return " OR ".join(f'"{term}"' for term in escaped)


def unpack_vector(row: Any) -> list[float]:
    encoding = str(row["encoding"] or "json") if "encoding" in row.keys() else "json"
    blob = row["vector_blob"] if "vector_blob" in row.keys() else None
    dims = int(row["dims"])
    if encoding == "f32" and blob:
        return list(struct.unpack(f"<{dims}f", blob))
    if encoding == "i8" and blob:
        raw = struct.unpack(f"<{dims}b", blob)
        scale = float(row["scale"] or 1.0)
        return [value * scale for value in raw]
    return json.loads(row["vector_json"] or "[]")
