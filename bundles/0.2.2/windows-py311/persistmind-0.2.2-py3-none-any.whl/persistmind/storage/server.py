from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True, slots=True)
class BackendCapabilities:
    backend: str
    transactions: bool
    partitioning: bool
    point_in_time_recovery: bool
    logical_replication: bool
    vector_search: bool
    offline: bool


SQLITE_CAPABILITIES = BackendCapabilities("sqlite", True, False, False, False, True, True)
POSTGRES_CAPABILITIES = BackendCapabilities("postgresql", True, True, True, True, True, False)


def negotiate_backend(requested: str, required: Mapping[str, bool]) -> BackendCapabilities:
    capabilities = {"sqlite": SQLITE_CAPABILITIES, "postgresql": POSTGRES_CAPABILITIES}.get(
        requested
    )
    if capabilities is None:
        raise ValueError(f"unknown storage backend: {requested}")
    missing = [
        name
        for name, needed in required.items()
        if needed and not bool(getattr(capabilities, name, False))
    ]
    if missing:
        raise RuntimeError(
            f"backend {requested} lacks required capabilities: {', '.join(sorted(missing))}"
        )
    return capabilities
