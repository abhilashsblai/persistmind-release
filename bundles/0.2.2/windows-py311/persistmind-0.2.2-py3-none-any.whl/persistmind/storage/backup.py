from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import shutil
import sqlite3
import tempfile
import time
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from persistmind.security.envelope import (
    EnvelopeAuthenticationFailed,
    WorkspaceKeyProvider,
    WrappedDataKey,
    decrypt_chunk,
    encrypt_chunk,
)

from .catalog import FileCatalog
from .descriptors import StoreDescriptor, TopologyManifest
from .runtime import StorageNotInitialized, inspect_storage
from .runtime_policy import (
    SQLiteRuntimeQualification,
    SQLiteRuntimeUnsupported,
    qualify_nextgen_runtime,
)

_BACKUP_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,119}$")
BACKUP_DIRECTORY_GLOB = "bkp-*"


@contextmanager
def _temporary_directory(*, prefix: str) -> Iterator[Path]:
    target = Path(tempfile.mkdtemp(prefix=prefix))
    try:
        yield target
    finally:
        for attempt in range(6):
            try:
                shutil.rmtree(target)
                break
            except FileNotFoundError:
                break
            except OSError:
                if attempt == 5:
                    raise
                time.sleep(0.05 * (attempt + 1))


@dataclass(frozen=True, slots=True)
class AuthorityBackupImage:
    store_id: str
    store_role: str
    location: str
    image: str
    bytes: int
    sha256: str
    revision: int
    schema_head: int


@dataclass(frozen=True, slots=True)
class AuthorityBackupManifest:
    backup_id: str
    created_at: str
    topology_generation: int
    topology_id: str
    images: tuple[AuthorityBackupImage, ...]
    consistency_mode: str
    point_in_time_recovery: bool
    disaster_redundant: bool
    runtime: dict[str, Any]
    object_tree_included: bool
    schema_version: str = "persistmind.backup.v1"


class BackupService:
    """Catalog-native online backups with explicit per-role consistency semantics."""

    def __init__(self, workspace_root: Path) -> None:
        self.workspace_root = workspace_root.resolve()
        self.catalog = FileCatalog(self.workspace_root / "catalog")
        self.backups = self.workspace_root / "backups"

    def create(
        self,
        *,
        backup_id: str | None = None,
        allow_development_driver: bool = False,
    ) -> dict[str, Any]:
        manifest = self._manifest_or_raise()
        qualification = self._require_runtime(allow_development_driver)
        backup_id = backup_id or _new_backup_id()
        _validate_backup_id(backup_id)
        destination = self.backups / backup_id
        if destination.exists():
            raise FileExistsError(f"backup already exists: {backup_id}")
        staging = self.backups / ".staging" / backup_id
        staging.mkdir(parents=True, exist_ok=False)
        try:
            images: list[AuthorityBackupImage] = []
            for descriptor in manifest.stores:
                source = self.catalog.resolve_location(descriptor.location)
                image = staging / "images" / f"{descriptor.store_id}.db"
                image.parent.mkdir(parents=True, exist_ok=True)
                _online_backup(
                    source,
                    image,
                    qualification=qualification,
                    development=allow_development_driver,
                )
                identity = _verify_store_image(
                    image,
                    descriptor,
                    qualification=qualification,
                    development=allow_development_driver,
                )
                images.append(
                    AuthorityBackupImage(
                        store_id=descriptor.store_id,
                        store_role=descriptor.store_role.value,
                        location=descriptor.location,
                        image=(Path("images") / image.name).as_posix(),
                        bytes=image.stat().st_size,
                        sha256=_sha256(image),
                        revision=int(identity["revision"]),
                        schema_head=descriptor.schema_head,
                    )
                )
            _copy_catalog_evidence(self.catalog, staging / "catalog", manifest)
            objects = self.workspace_root / "objects" / "sha256"
            if objects.exists():
                shutil.copytree(objects, staging / "objects" / "sha256")
            backup_manifest = AuthorityBackupManifest(
                backup_id=backup_id,
                created_at=_now(),
                topology_generation=manifest.generation,
                topology_id=manifest.topology_id,
                images=tuple(images),
                consistency_mode="per_role_online_backup",
                point_in_time_recovery=False,
                disaster_redundant=False,
                runtime=qualification.to_dict(),
                object_tree_included=objects.exists(),
            )
            _write_json(staging / "manifest.json", _manifest_dict(backup_manifest))
            self._verify_plain_directory(
                staging,
                allow_development_driver=allow_development_driver,
                expected_topology=manifest,
            )
            self._seal_directory(
                staging,
                _manifest_dict(backup_manifest),
                allow_development_driver=allow_development_driver,
            )
            self._verify_directory(
                staging,
                allow_development_driver=allow_development_driver,
                expected_topology=manifest,
            )
            destination.parent.mkdir(parents=True, exist_ok=True)
            os.replace(staging, destination)
            return {
                "ok": True,
                "status": "verified",
                "schema_version": backup_manifest.schema_version,
                "backup": _manifest_dict(backup_manifest),
            }
        finally:
            if staging.exists():
                shutil.rmtree(staging, ignore_errors=True)

    def verify(self, backup_id: str, *, allow_development_driver: bool = False) -> dict[str, Any]:
        _validate_backup_id(backup_id)
        directory = self.backups / backup_id
        manifest = self._verify_directory(
            directory,
            allow_development_driver=allow_development_driver,
        )
        return {
            "ok": True,
            "status": "verified",
            "schema_version": "persistmind.backup_verification.v1",
            "backup": manifest,
        }

    def restore_stage(
        self,
        backup_id: str,
        *,
        target: Path,
        allow_development_driver: bool = False,
    ) -> dict[str, Any]:
        _validate_backup_id(backup_id)
        encrypted_source = self.backups / backup_id
        manifest_document = self._verify_directory(
            encrypted_source, allow_development_driver=allow_development_driver
        )
        target = target.resolve()
        if target.exists() and any(target.iterdir()):
            raise ValueError("restore target must be a new or empty workspace root")
        temporary = target.with_name(f".{target.name}.restore-{secrets.token_hex(8)}")
        if temporary.exists():
            raise FileExistsError(temporary)
        try:
            with self._plaintext_directory(
                encrypted_source,
                allow_development_driver=allow_development_driver,
            ) as source:
                shutil.copytree(source / "catalog", temporary / "catalog")
                restored_catalog = FileCatalog(temporary / "catalog")
                topology = restored_catalog.current()
                images = {
                    str(item["store_id"]): item
                    for item in manifest_document["images"]
                    if isinstance(item, dict)
                }
                for descriptor in topology.stores:
                    item = images.get(descriptor.store_id)
                    if item is None:
                        raise RuntimeError(f"backup missing catalog store: {descriptor.store_id}")
                    image = source / str(item["image"])
                    destination = restored_catalog.resolve_location(descriptor.location)
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(image, destination)
                if (source / "objects" / "sha256").exists():
                    shutil.copytree(
                        source / "objects" / "sha256",
                        temporary / "objects" / "sha256",
                        dirs_exist_ok=True,
                    )
            self._verify_restored_workspace(
                temporary,
                allow_development_driver=allow_development_driver,
            )
            if target.exists():
                target.rmdir()
            os.replace(temporary, target)
            return {
                "ok": True,
                "status": "staged",
                "schema_version": "persistmind.authority_restore_stage.v1",
                "backup_id": backup_id,
                "target": str(target),
                "activated": False,
            }
        finally:
            if temporary.exists():
                shutil.rmtree(temporary, ignore_errors=True)

    def _manifest_or_raise(self) -> TopologyManifest:
        inspection = inspect_storage(self.workspace_root)
        if not inspection.initialized or inspection.topology is None:
            raise StorageNotInitialized("persistmind-nextgen-v1 storage is not initialized")
        return inspection.topology

    def _require_runtime(self, allow_development_driver: bool) -> SQLiteRuntimeQualification:
        qualification = qualify_nextgen_runtime()
        if not qualification.ok and not allow_development_driver:
            raise SQLiteRuntimeUnsupported(
                "sqlite_runtime_unsupported: " + str(qualification.reason)
            )
        return qualification

    def _verify_directory(
        self,
        directory: Path,
        *,
        allow_development_driver: bool,
        expected_topology: TopologyManifest | None = None,
    ) -> dict[str, Any]:
        try:
            outer = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError("backup manifest is unreadable") from exc
        if not isinstance(outer, dict):
            raise RuntimeError("backup manifest is invalid")
        if outer.get("schema_version") == "persistmind.backup_envelope.v1":
            with self._plaintext_directory(
                directory, allow_development_driver=allow_development_driver
            ) as plaintext:
                return self._verify_plain_directory(
                    plaintext,
                    allow_development_driver=allow_development_driver,
                    expected_topology=expected_topology,
                )
        return self._verify_plain_directory(
            directory,
            allow_development_driver=allow_development_driver,
            expected_topology=expected_topology,
        )

    def _verify_plain_directory(
        self,
        directory: Path,
        *,
        allow_development_driver: bool,
        expected_topology: TopologyManifest | None = None,
    ) -> dict[str, Any]:
        try:
            document = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError("backup manifest is unreadable") from exc
        if (
            not isinstance(document, dict)
            or document.get("schema_version") != "persistmind.backup.v1"
        ):
            raise RuntimeError("backup manifest is invalid")
        topology = expected_topology
        if topology is None:
            backup_catalog = FileCatalog(directory / "catalog")
            topology = backup_catalog.current()
        if (
            document.get("topology_id") != topology.topology_id
            or int(document.get("topology_generation", -1)) != topology.generation
        ):
            raise RuntimeError("backup catalog/topology mismatch")
        qualification = self._require_runtime(allow_development_driver)
        images = document.get("images")
        if not isinstance(images, list) or len(images) != len(topology.stores):
            raise RuntimeError("backup image set does not match catalog")
        by_store = {str(item.get("store_id")): item for item in images if isinstance(item, dict)}
        for descriptor in topology.stores:
            item = by_store.get(descriptor.store_id)
            if item is None:
                raise RuntimeError(f"backup missing image: {descriptor.store_id}")
            image = directory / str(item.get("image") or "")
            if not image.is_file() or image.stat().st_size != int(item.get("bytes", -1)):
                raise RuntimeError(f"backup image size mismatch: {descriptor.store_id}")
            if _sha256(image) != str(item.get("sha256")):
                raise RuntimeError(f"backup image hash mismatch: {descriptor.store_id}")
            _verify_store_image(
                image,
                descriptor,
                qualification=qualification,
                development=allow_development_driver,
            )
        return document

    def _seal_directory(
        self,
        directory: Path,
        backup_manifest: dict[str, Any],
        *,
        allow_development_driver: bool,
    ) -> None:
        keys = WorkspaceKeyProvider(
            self.workspace_root, allow_test_provider=allow_development_driver
        )
        dek, wrapped = keys.wrap_new_dek()
        files: list[dict[str, Any]] = []
        sources = sorted(
            path for path in directory.rglob("*") if path.is_file() and path.name != "manifest.json"
        )
        sealed_root = directory / ".sealed"
        sealed_root.mkdir()
        for index, source in enumerate(sources):
            relative = source.relative_to(directory).as_posix()
            plaintext = source.read_bytes()
            plain_hash = hashlib.sha256(plaintext).hexdigest()
            aad = {
                "contract": "persistmind.backup_envelope.v1",
                "backup_id": backup_manifest["backup_id"],
                "classification": "confidential",
                "chunk_index": index,
                "chunk_count": len(sources) + 1,
                "plaintext_bytes": len(plaintext),
                "plaintext_sha256": plain_hash,
                "key_id": wrapped.key_id,
            }
            ciphertext, metadata = encrypt_chunk(plaintext, dek=dek, aad_fields=aad)
            sealed = sealed_root / f"{index:06d}.bin"
            sealed.write_bytes(ciphertext)
            files.append(
                {
                    "path": relative,
                    "plaintext_bytes": len(plaintext),
                    "plaintext_sha256": plain_hash,
                    "sealed": f"payload/{index:06d}.bin",
                    **metadata,
                }
            )
        inner = {
            "backup": backup_manifest,
            "files": files,
            "schema_version": "persistmind.backup_inner.v1",
        }
        inner_bytes = json.dumps(
            inner, sort_keys=True, separators=(",", ":"), ensure_ascii=False
        ).encode("utf-8")
        inner_aad = {
            "contract": "persistmind.backup_envelope.v1",
            "backup_id": backup_manifest["backup_id"],
            "classification": "confidential",
            "chunk_index": len(sources),
            "chunk_count": len(sources) + 1,
            "plaintext_bytes": len(inner_bytes),
            "plaintext_sha256": hashlib.sha256(inner_bytes).hexdigest(),
            "key_id": wrapped.key_id,
        }
        inner_ciphertext, inner_metadata = encrypt_chunk(inner_bytes, dek=dek, aad_fields=inner_aad)
        (sealed_root / "inner.bin").write_bytes(inner_ciphertext)
        for child in list(directory.iterdir()):
            if child == sealed_root:
                continue
            if child.is_dir():
                shutil.rmtree(child)
            else:
                child.unlink()
        os.replace(sealed_root, directory / "payload")
        outer = {
            "schema_version": "persistmind.backup_envelope.v1",
            "backup_id": backup_manifest["backup_id"],
            "workspace_id_hash": hashlib.sha256(
                str(backup_manifest.get("topology_id", "")).encode("utf-8")
            ).hexdigest(),
            "key_id": wrapped.key_id,
            "wrapping_key_id": wrapped.key_id,
            "wrapped_dek": wrapped.wrapped_dek,
            "created_at": backup_manifest["created_at"],
            "payload_count": len(files),
            "inner": {
                "plaintext_bytes": len(inner_bytes),
                "plaintext_sha256": inner_aad["plaintext_sha256"],
                **inner_metadata,
            },
        }
        _write_json(directory / "manifest.json", outer)

    def _plaintext_directory(
        self,
        directory: Path,
        *,
        allow_development_driver: bool,
    ):  # type annotation omitted to retain Python 3.11 contextmanager compatibility.
        from contextlib import contextmanager

        @contextmanager
        def materialized():
            outer = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
            if outer.get("schema_version") != "persistmind.backup_envelope.v1":
                yield directory
                return
            keys = WorkspaceKeyProvider(
                self.workspace_root, allow_test_provider=allow_development_driver
            )
            wrapped = WrappedDataKey(
                key_id=str(outer.get("wrapping_key_id") or outer["key_id"]),
                wrapped_dek=str(outer["wrapped_dek"]),
            )
            dek = keys.unwrap_dek(wrapped)
            inner_meta = outer["inner"]
            inner_ciphertext = (directory / "payload" / "inner.bin").read_bytes()
            inner_aad = {
                "contract": "persistmind.backup_envelope.v1",
                "backup_id": outer["backup_id"],
                "classification": "confidential",
                "chunk_index": int(outer["payload_count"]),
                "chunk_count": int(outer["payload_count"]) + 1,
                "plaintext_bytes": int(inner_meta["plaintext_bytes"]),
                "plaintext_sha256": inner_meta["plaintext_sha256"],
                "key_id": outer["key_id"],
            }
            try:
                inner_bytes = decrypt_chunk(
                    inner_ciphertext,
                    dek=dek,
                    nonce=str(inner_meta["nonce"]),
                    aad_fields=inner_aad,
                    expected_aad_sha256=str(inner_meta["aad_sha256"]),
                    expected_ciphertext_sha256=str(inner_meta["ciphertext_sha256"]),
                )
                inner = json.loads(inner_bytes)
            except (EnvelopeAuthenticationFailed, json.JSONDecodeError, KeyError) as exc:
                raise RuntimeError("backup envelope authentication failed") from exc
            with _temporary_directory(prefix="persistmind-backup-verify-") as target:
                for index, item in enumerate(inner["files"]):
                    ciphertext = directory / str(item["sealed"])
                    aad = {
                        "contract": "persistmind.backup_envelope.v1",
                        "backup_id": outer["backup_id"],
                        "classification": "confidential",
                        "chunk_index": index,
                        "chunk_count": int(outer["payload_count"]) + 1,
                        "plaintext_bytes": int(item["plaintext_bytes"]),
                        "plaintext_sha256": item["plaintext_sha256"],
                        "key_id": outer["key_id"],
                    }
                    try:
                        plaintext = decrypt_chunk(
                            ciphertext.read_bytes(),
                            dek=dek,
                            nonce=str(item["nonce"]),
                            aad_fields=aad,
                            expected_aad_sha256=str(item["aad_sha256"]),
                            expected_ciphertext_sha256=str(item["ciphertext_sha256"]),
                        )
                    except (OSError, EnvelopeAuthenticationFailed) as exc:
                        raise RuntimeError("backup payload hash mismatch") from exc
                    destination = target / str(item["path"])
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    destination.write_bytes(plaintext)
                _write_json(target / "manifest.json", inner["backup"])
                yield target

        return materialized()

    def _verify_restored_workspace(self, root: Path, *, allow_development_driver: bool) -> None:
        catalog = FileCatalog(root / "catalog")
        manifest = catalog.current()
        qualification = self._require_runtime(allow_development_driver)
        for descriptor in manifest.stores:
            _verify_store_image(
                catalog.resolve_location(descriptor.location),
                descriptor,
                qualification=qualification,
                development=allow_development_driver,
            )


def _online_backup(
    source: Path,
    destination: Path,
    *,
    qualification: SQLiteRuntimeQualification,
    development: bool,
) -> None:
    destination.unlink(missing_ok=True)
    if qualification.ok:
        import apsw  # type: ignore[import-not-found]

        apsw_source = apsw.Connection(str(source), flags=apsw.SQLITE_OPEN_READONLY)
        apsw_target = apsw.Connection(str(destination))
        try:
            backup = apsw_target.backup("main", apsw_source, "main")
            try:
                backup.step(-1)
            finally:
                backup.finish()
        finally:
            apsw_target.close()
            apsw_source.close()
        return
    if not development:
        raise SQLiteRuntimeUnsupported("sqlite_runtime_unsupported")
    sqlite_source = sqlite3.connect(f"file:{source.resolve()}?mode=ro", uri=True)
    sqlite_target = sqlite3.connect(destination)
    try:
        sqlite_source.backup(sqlite_target)
        sqlite_target.commit()
    finally:
        sqlite_target.close()
        sqlite_source.close()


def _verify_store_image(
    path: Path,
    descriptor: StoreDescriptor,
    *,
    qualification: SQLiteRuntimeQualification,
    development: bool,
) -> dict[str, Any]:
    if qualification.ok:
        import apsw  # type: ignore[import-not-found]

        apsw_connection = apsw.Connection(str(path), flags=apsw.SQLITE_OPEN_READONLY)
        try:
            integrity_rows = [
                str(item[0]) for item in apsw_connection.execute("PRAGMA integrity_check")
            ]
            foreign_keys = list(apsw_connection.execute("PRAGMA foreign_key_check"))
            app_id_rows = list(apsw_connection.execute("PRAGMA application_id"))
            app_id = int(app_id_rows[0][0])
            row = apsw_connection.execute(
                "SELECT domain,store_role,store_id,schema_head,revision "
                "FROM domain_metadata WHERE singleton=1"
            ).fetchone()
        finally:
            apsw_connection.close()
    elif development:
        sqlite_connection = sqlite3.connect(f"file:{path.resolve()}?mode=ro", uri=True)
        try:
            integrity_rows = [
                str(item[0]) for item in sqlite_connection.execute("PRAGMA integrity_check")
            ]
            foreign_keys = list(sqlite_connection.execute("PRAGMA foreign_key_check"))
            app_id_rows = list(sqlite_connection.execute("PRAGMA application_id"))
            app_id = int(app_id_rows[0][0])
            row = sqlite_connection.execute(
                "SELECT domain,store_role,store_id,schema_head,revision "
                "FROM domain_metadata WHERE singleton=1"
            ).fetchone()
        finally:
            sqlite_connection.close()
    else:
        raise SQLiteRuntimeUnsupported("sqlite_runtime_unsupported")
    if integrity_rows != ["ok"] or foreign_keys or row is None:
        raise RuntimeError(f"backup integrity failure: {descriptor.store_id}")
    if (
        str(row[0]) != descriptor.domain.value
        or str(row[1]) != descriptor.store_role.value
        or str(row[2]) != descriptor.store_id
        or int(row[3]) != descriptor.schema_head
    ):
        raise RuntimeError(f"backup store identity mismatch: {descriptor.store_id}")
    if app_id <= 0:
        raise RuntimeError(f"backup missing application id: {descriptor.store_id}")
    return {"revision": int(row[4])}


def verify_authority_image(
    path: Path,
    descriptor: StoreDescriptor,
    *,
    allow_development_driver: bool = False,
) -> dict[str, Any]:
    """Verify a staged authority image with the qualified PersistMind runtime."""

    qualification = qualify_nextgen_runtime()
    result = _verify_store_image(
        path.resolve(),
        descriptor,
        qualification=qualification,
        development=allow_development_driver,
    )
    return {
        "ok": True,
        "integrity": ["ok"],
        "foreign_key_violations": [],
        **result,
    }


def _copy_catalog_evidence(catalog: FileCatalog, target: Path, manifest: TopologyManifest) -> None:
    target.mkdir(parents=True, exist_ok=True)
    for source in (
        catalog.current_path,
        catalog.previous_path,
        catalog.generations / f"{manifest.generation:020d}.json",
        catalog.publications / f"{manifest.generation:020d}.json",
    ):
        if not source.exists():
            raise RuntimeError(f"catalog evidence missing: {source}")
        destination = target / source.relative_to(catalog.root)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


def _manifest_dict(value: AuthorityBackupManifest) -> dict[str, Any]:
    result = asdict(value)
    result["images"] = [asdict(item) for item in value.images]
    return result


def _write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, sort_keys=True, separators=(",", ":"))
        handle.flush()
        os.fsync(handle.fileno())


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _new_backup_id() -> str:
    return datetime.now(UTC).strftime("bkp-%Y%m%d-%H%M%S-") + secrets.token_hex(4)


def _validate_backup_id(value: str) -> None:
    if not _BACKUP_ID.fullmatch(value):
        raise ValueError("invalid backup id")


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="microseconds").replace("+00:00", "Z")
