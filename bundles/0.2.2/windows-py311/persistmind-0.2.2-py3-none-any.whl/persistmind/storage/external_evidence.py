from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any

from persistmind.security.redaction import redact_with_summary
from persistmind.utils import utc_now

_SECRET_NAME = re.compile(r"^[A-Z][A-Z0-9_]{2,127}$")
_NAMED_SECRET_ASSIGNMENT = re.compile(
    r"\b([A-Z][A-Z0-9_]*(?:KEY|SECRET|TOKEN|PASSWORD))\s*[:=]\s*([^\s,;]+)"
)
_LIVE_RESULTS = {"configured", "missing", "unknown", "verified", "failed"}
_VALUE_KEYS = {
    "api_key",
    "authorization",
    "credential",
    "credentials",
    "password",
    "secret",
    "secret_value",
    "secret_values",
    "token",
    "value",
    "values",
}


def normalize_verified_fact(
    text: str,
    evidence_refs: Sequence[Any],
) -> dict[str, Any]:
    """Redact and normalize independently verified operational evidence.

    Secret identifiers are useful retrieval keys and are retained. Secret values
    and value-bearing fields are discarded before Task or Knowledge storage.
    """

    assignment_redactions = len(_NAMED_SECRET_ASSIGNMENT.findall(text))
    without_assignments = _NAMED_SECRET_ASSIGNMENT.sub(
        lambda match: f"{match.group(1)}=[REDACTED_SECRET]", text
    )
    assertion, assertion_redaction = redact_with_summary(without_assignments.strip())
    if not assertion:
        raise ValueError("verified fact assertion must be non-empty")

    normalized: list[dict[str, Any]] = []
    removed_value_fields = 0
    identifiers: set[str] = set()
    declared_secret_names: set[str] = set()
    expires_at: str | None = None
    for index, raw in enumerate(evidence_refs):
        if not isinstance(raw, Mapping):
            raise ValueError("verified fact evidence entries must be objects")
        protected_keys = {
            str(value).strip().lower()
            for value in _sequence(raw.get("secret_names"))
            if str(value).strip()
        }
        item, removed = _without_secret_values(raw, protected_keys=protected_keys)
        removed_value_fields += removed

        source = str(item.get("source") or item.get("source_connector") or "").strip()
        receipt_ref = str(item.get("receipt_ref") or item.get("source_ref") or "").strip()
        verified_at = str(item.get("verified_at") or "").strip()
        result = str(item.get("verification_result") or "unknown").strip().lower()
        evidence_scope = str(item.get("evidence_scope") or "live_metadata").strip().lower()
        if result not in _LIVE_RESULTS:
            raise ValueError(f"unsupported verified fact result: {result}")
        if evidence_scope != "live_metadata" and result in {"configured", "missing"}:
            result = "unknown"
        if result in {"configured", "missing", "verified"} and (
            not source or not receipt_ref or not verified_at
        ):
            raise ValueError(
                "verified live-state evidence requires source, receipt_ref, and verified_at"
            )

        secret_names = sorted(
            {
                str(value).strip()
                for value in _sequence(item.get("secret_names"))
                if _SECRET_NAME.fullmatch(str(value).strip())
            }
        )
        project_reference = str(item.get("project_reference") or "").strip() or None
        function_name = str(item.get("function_name") or "").strip() or None
        revalidate_after = (
            str(item.get("revalidate_after") or item.get("expires_at") or "").strip() or None
        )
        if revalidate_after and (expires_at is None or revalidate_after < expires_at):
            expires_at = revalidate_after
        identifiers.update(secret_names)
        declared_secret_names.update(secret_names)
        identifiers.update(
            value for value in (project_reference, function_name) if value is not None
        )

        normalized.append(
            {
                "evidence_kind": "external_tool_receipt",
                "source": source or "unknown",
                "project_reference": project_reference,
                "secret_names": secret_names,
                "function_name": function_name,
                "verified_at": verified_at or None,
                "verification_result": result,
                "evidence_scope": evidence_scope,
                "receipt_ref": receipt_ref or None,
                "revalidate_after": revalidate_after,
                "captured_at": utc_now(),
                "values_persisted": False,
                "redacted_value_fields": removed,
                "index": index,
            }
        )

    if not normalized:
        raise ValueError("verified fact promotion requires structured evidence")
    for secret_name in sorted(declared_secret_names, key=len, reverse=True):
        assignment = re.compile(
            rf"\b({re.escape(secret_name)})\s*[:=]\s*"
            r"(?!\[REDACTED_SECRET\])([^\s,;]+)"
        )
        assertion, count = assignment.subn(
            lambda match: f"{match.group(1)}=[REDACTED_SECRET]", assertion
        )
        assignment_redactions += count
    return {
        "assertion": assertion,
        "evidence": normalized,
        "identifiers": sorted(identifiers),
        "expires_at": expires_at,
        "redaction": {
            **assertion_redaction,
            "named_secret_assignments": assignment_redactions,
            "removed_value_fields": removed_value_fields,
            "values_persisted": False,
        },
    }


def knowledge_evidence(items: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "evidence_kind": "external_tool_receipt",
            "source_ref": item.get("receipt_ref"),
            "metadata": dict(item),
            "trust": "verified",
        }
        for item in items
    ]


def _without_secret_values(
    value: Mapping[str, Any], *, protected_keys: set[str] | None = None
) -> tuple[dict[str, Any], int]:
    cleaned: dict[str, Any] = {}
    removed = 0
    protected = protected_keys or set()
    for key, item in value.items():
        normalized_key = str(key).strip().lower()
        if (
            normalized_key in protected
            or normalized_key in _VALUE_KEYS
            or normalized_key.endswith(("_value", "_values"))
        ):
            removed += 1
            continue
        if isinstance(item, Mapping):
            nested, nested_removed = _without_secret_values(item, protected_keys=protected)
            cleaned[str(key)] = nested
            removed += nested_removed
        elif isinstance(item, Sequence) and not isinstance(item, (str, bytes)):
            values: list[Any] = []
            for entry in item:
                if isinstance(entry, Mapping):
                    nested, nested_removed = _without_secret_values(entry, protected_keys=protected)
                    values.append(nested)
                    removed += nested_removed
                else:
                    values.append(entry)
            cleaned[str(key)] = values
        else:
            cleaned[str(key)] = item
    return cleaned, removed


def _sequence(value: Any) -> list[Any]:
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return list(value)
    return [value] if value is not None else []


__all__ = ["knowledge_evidence", "normalize_verified_fact"]
