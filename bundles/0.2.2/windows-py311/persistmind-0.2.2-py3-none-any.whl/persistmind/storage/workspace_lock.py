from __future__ import annotations

import hashlib
import importlib
import os
import tempfile
from pathlib import Path
from typing import Any, BinaryIO

if os.name == "nt":
    import ctypes
    import msvcrt
    from ctypes import wintypes

    class _Overlapped(ctypes.Structure):
        _fields_ = [
            ("Internal", ctypes.c_size_t),
            ("InternalHigh", ctypes.c_size_t),
            ("Offset", wintypes.DWORD),
            ("OffsetHigh", wintypes.DWORD),
            ("hEvent", wintypes.HANDLE),
        ]

    _LOCKFILE_FAIL_IMMEDIATELY = 0x00000001
    _LOCKFILE_EXCLUSIVE_LOCK = 0x00000002
    _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    _lock_file_ex = _kernel32.LockFileEx
    _lock_file_ex.argtypes = [
        wintypes.HANDLE,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.DWORD,
        ctypes.POINTER(_Overlapped),
    ]
    _lock_file_ex.restype = wintypes.BOOL
    _unlock_file_ex = _kernel32.UnlockFileEx
    _unlock_file_ex.argtypes = [
        wintypes.HANDLE,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.DWORD,
        ctypes.POINTER(_Overlapped),
    ]
    _unlock_file_ex.restype = wintypes.BOOL


class WorkspaceBusy(RuntimeError):
    status = "workspace_busy"


class WorkspaceRuntimeLock:
    """Cross-process shared runtime / exclusive maintenance lock."""

    def __init__(self, workspace_root: Path, *, exclusive: bool) -> None:
        identity = hashlib.sha256(str(workspace_root.resolve()).encode()).hexdigest()
        self.path = Path(tempfile.gettempdir()) / "persistmind-runtime-locks" / f"{identity}.lock"
        self.exclusive = exclusive
        self.handle: BinaryIO | None = None
        self._platform_lock: Any | None = None

    def acquire(self) -> WorkspaceRuntimeLock:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        handle = self.path.open("a+b")
        if self.path.stat().st_size == 0:
            handle.write(b"\0")
            handle.flush()
        handle.seek(0)
        try:
            if os.name == "nt":
                overlapped = _Overlapped()
                flags = _LOCKFILE_FAIL_IMMEDIATELY
                if self.exclusive:
                    flags |= _LOCKFILE_EXCLUSIVE_LOCK
                os_handle = wintypes.HANDLE(msvcrt.get_osfhandle(handle.fileno()))
                if not _lock_file_ex(os_handle, flags, 0, 1, 0, ctypes.byref(overlapped)):
                    raise ctypes.WinError(ctypes.get_last_error())
                self._platform_lock = overlapped
            else:
                fcntl: Any = importlib.import_module("fcntl")

                mode = fcntl.LOCK_EX if self.exclusive else fcntl.LOCK_SH
                fcntl.flock(handle.fileno(), mode | fcntl.LOCK_NB)
        except OSError as exc:
            handle.close()
            raise WorkspaceBusy(
                "workspace has active runtimes"
                if self.exclusive
                else "workspace maintenance is active"
            ) from exc
        self.handle = handle
        return self

    def close(self) -> None:
        handle, self.handle = self.handle, None
        if handle is None:
            return
        try:
            handle.seek(0)
            if os.name == "nt":
                overlapped, self._platform_lock = self._platform_lock, None
                if overlapped is not None:
                    os_handle = wintypes.HANDLE(msvcrt.get_osfhandle(handle.fileno()))
                    if not _unlock_file_ex(os_handle, 0, 1, 0, ctypes.byref(overlapped)):
                        raise ctypes.WinError(ctypes.get_last_error())
            else:
                fcntl: Any = importlib.import_module("fcntl")

                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        finally:
            handle.close()

    def __enter__(self) -> WorkspaceRuntimeLock:
        return self.acquire()

    def __exit__(self, *_: object) -> None:
        self.close()
