"""Backend-neutral storage architecture for PersistMind."""

from .descriptors import (
    ConsistencyWatermark,
    MemoryKindDescriptor,
    MigrationDescriptor,
    StorageDomain,
    StoreCapabilities,
    StoreDescriptor,
    StoreRole,
    TopologyManifest,
)
from .interfaces import RoutePlan
from .router import StorageRouter
from .runtime import StorageInspection, StorageOpenIntent, StorageRuntime, inspect_storage

__all__ = [
    "ConsistencyWatermark",
    "MemoryKindDescriptor",
    "MigrationDescriptor",
    "RoutePlan",
    "StorageDomain",
    "StorageInspection",
    "StorageOpenIntent",
    "StorageRouter",
    "StorageRuntime",
    "StoreCapabilities",
    "StoreDescriptor",
    "StoreRole",
    "TopologyManifest",
    "inspect_storage",
]
