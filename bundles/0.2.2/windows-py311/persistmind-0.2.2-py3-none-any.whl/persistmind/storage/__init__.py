"""Backend-neutral storage architecture for PersistMind."""

from .descriptors import (
    ConsistencyWatermark,
    MemoryKindDescriptor,
    MigrationDescriptor,
    StorageDomain,
    StoreCapabilities,
    StoreDescriptor,
    StoreRole,
    TopologyManifest,
)
from .interfaces import RoutePlan
from .runtime import StorageInspection, StorageOpenIntent, StorageRuntime, inspect_storage
from .router import StorageRouter

__all__ = [
    "ConsistencyWatermark",
    "MemoryKindDescriptor",
    "MigrationDescriptor",
    "StorageDomain",
    "StorageRouter",
    "StoreCapabilities",
    "StoreDescriptor",
    "StoreRole",
    "TopologyManifest",
    "RoutePlan",
    "StorageInspection",
    "StorageOpenIntent",
    "StorageRuntime",
    "inspect_storage",
]
