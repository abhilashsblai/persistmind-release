from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path, PurePosixPath
from typing import Any

from .descriptors import TopologyManifest


class CatalogConflict(RuntimeError):
    pass


class CatalogRecoveryAmbiguous(RuntimeError):
    """Recovery has no committed pointer and must not guess a generation."""


_RESERVED_WINDOWS = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{number}" for number in range(1, 10)),
    *(f"LPT{number}" for number in range(1, 10)),
}
_LOCATION_COMPONENT = re.compile(r"^[a-z0-9][a-z0-9._-]{0,119}$")
_MAX_CATALOG_BYTES = 4 * 1024 * 1024


class FileCatalog:
    """Immutable catalog generations committed solely by an atomic pointer.

    Generation files may exist after a crash before the pointer is published.
    They are deliberately *not* candidates for automatic recovery: selecting
    the largest file would silently turn a prepared topology into live state.
    """

    def __init__(self, root: Path) -> None:
        self.root = root
        self.generations = root / "generations"
        self.publications = root / "publications"
        self.current_path = root / "current.json"
        self.previous_path = root / "previous.json"

    @property
    def workspace_root(self) -> Path:
        return self.root.parent

    def current(self) -> TopologyManifest:
        pointer = self._read_pointer(self.current_path)
        manifest = self._read_generation(int(pointer["generation"]))
        expected = str(pointer.get("manifest_sha256") or "")
        actual = self._manifest_digest(manifest)
        if expected != actual:
            raise CatalogRecoveryAmbiguous("catalog pointer manifest hash mismatch")
        if str(pointer.get("topology_id")) != manifest.topology_id:
            raise CatalogRecoveryAmbiguous("catalog pointer topology mismatch")
        self._validate_manifest(manifest)
        return manifest

    def initialize(self, manifest: TopologyManifest) -> TopologyManifest:
        if self.current_path.exists():
            return self.current()
        if manifest.generation != 1:
            raise ValueError("initial catalog generation must be 1")
        self.activate(manifest, expected_generation=0)
        return manifest

    def activate(self, manifest: TopologyManifest, *, expected_generation: int) -> None:
        self._validate_manifest(manifest)
        current_generation = 0
        current_pointer: dict[str, Any] | None = None
        if self.current_path.exists():
            current_pointer = self._read_pointer(self.current_path)
            current_generation = int(current_pointer["generation"])
            self.current()  # validates the existing commit before replacement
        if current_generation != expected_generation:
            raise CatalogConflict(
                f"catalog generation conflict: expected {expected_generation}, "
                f"found {current_generation}"
            )
        if manifest.generation != expected_generation + 1:
            raise CatalogConflict(
                "catalog generation must advance exactly once: "
                f"expected {expected_generation + 1}, got {manifest.generation}"
            )
        self.generations.mkdir(parents=True, exist_ok=True)
        self.publications.mkdir(parents=True, exist_ok=True)
        generation_path = self.generations / f"{manifest.generation:020d}.json"
        document = manifest.to_dict()
        self._atomic_json(generation_path, document, exclusive=True)
        digest = self._manifest_digest(manifest)
        pointer = {
            "generation": manifest.generation,
            "manifest_sha256": digest,
            "schema_version": "persistmind.catalog_pointer.v1",
            "topology_id": manifest.topology_id,
        }
        # `current.json` is the sole commit point. A receipt is written only
        # afterwards and is diagnostic/idempotent evidence, never a second vote.
        if current_pointer is not None:
            self._atomic_json(self.previous_path, current_pointer)
        elif not self.previous_path.exists():
            self._atomic_json(
                self.previous_path,
                {
                    "generation": 0,
                    "schema_version": "persistmind.catalog_pointer.v1",
                    "topology_id": "none",
                },
            )
        self._atomic_json(self.current_path, pointer)
        self._atomic_json(
            self.publications / f"{manifest.generation:020d}.json",
            {
                "catalog_generation": manifest.generation,
                "manifest_sha256": digest,
                "pointer_sha256": hashlib.sha256(_canonical_bytes(pointer)).hexdigest(),
                "schema_version": "persistmind.catalog_publication_receipt.v1",
            },
        )

    def recover(self) -> TopologyManifest:
        """Recover only from an already committed current/previous pointer.

        A missing pointer with prepared generations is intentionally ambiguous;
        an operator must choose repair/rollback rather than this method guessing
        from filename order or modification time.
        """

        if self.current_path.exists():
            return self.current()
        if self.previous_path.exists():
            previous = self._read_pointer(self.previous_path, allow_sentinel=True)
            if int(previous["generation"]) > 0:
                manifest = self._read_generation(int(previous["generation"]))
                digest = self._manifest_digest(manifest)
                if previous.get("manifest_sha256") == digest:
                    self._validate_manifest(manifest)
                    self._atomic_json(self.current_path, previous)
                    return manifest
        raise CatalogRecoveryAmbiguous(
            "catalog pointer is missing; refusing to promote prepared generations"
        )

    def resolve_location(self, location: str) -> Path:
        normalized = self.validate_relative_location(location)
        target = (self.workspace_root / Path(*PurePosixPath(normalized).parts)).resolve()
        if not target.is_relative_to(self.workspace_root.resolve()):
            raise ValueError(f"store location escapes workspace: {location!r}")
        return target

    @classmethod
    def validate_relative_location(cls, location: str) -> str:
        if not isinstance(location, str) or not location or len(location) > 512:
            raise ValueError("invalid catalog location length")
        if "\\" in location or ":" in location or location.startswith("/"):
            raise ValueError(f"catalog location must be a portable relative path: {location!r}")
        path = PurePosixPath(location)
        if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
            raise ValueError(f"catalog location escapes workspace: {location!r}")
        for component in path.parts:
            if (
                not _LOCATION_COMPONENT.fullmatch(component)
                or component.rstrip(". ").upper() in _RESERVED_WINDOWS
            ):
                raise ValueError(f"invalid catalog path component: {component!r}")
        return path.as_posix()

    def _validate_manifest(self, manifest: TopologyManifest) -> None:
        if manifest.profile != "persistmind-nextgen-v1":
            raise ValueError(
                f"catalog only publishes persistmind-nextgen-v1, got {manifest.profile!r}"
            )
        if len(manifest.stores) > 10_000:
            raise ValueError("catalog descriptor capacity exceeded")
        seen_ids: set[str] = set()
        seen_locations: set[str] = set()
        active_role_scope: set[tuple[str, str, str]] = set()
        for descriptor in manifest.stores:
            if descriptor.store_id in seen_ids:
                raise ValueError(f"duplicate store id: {descriptor.store_id}")
            seen_ids.add(descriptor.store_id)
            normalized = self.validate_relative_location(descriptor.location)
            if normalized.casefold() in seen_locations:
                raise ValueError(f"catalog location collision: {descriptor.location}")
            seen_locations.add(normalized.casefold())
            if descriptor.state == "active" and not descriptor.read_only:
                key = (
                    descriptor.store_role.value,
                    descriptor.authorization_scope,
                    descriptor.shard_key,
                )
                if key in active_role_scope:
                    raise ValueError("duplicate active writable role/scope/shard: " + "/".join(key))
                active_role_scope.add(key)

    def _read_generation(self, generation: int) -> TopologyManifest:
        path = self.generations / f"{generation:020d}.json"
        return TopologyManifest.from_dict(self._read_json(path))

    def _read_pointer(self, path: Path, *, allow_sentinel: bool = False) -> dict[str, Any]:
        pointer = self._read_json(path)
        if pointer.get("schema_version") != "persistmind.catalog_pointer.v1":
            raise CatalogRecoveryAmbiguous("unsupported catalog pointer format")
        generation = pointer.get("generation")
        if not isinstance(generation, int) or generation < 0:
            raise CatalogRecoveryAmbiguous("invalid catalog pointer generation")
        if generation == 0 and allow_sentinel:
            return pointer
        if generation < 1 or not isinstance(pointer.get("manifest_sha256"), str):
            raise CatalogRecoveryAmbiguous("invalid committed catalog pointer")
        return pointer

    @staticmethod
    def _read_json(path: Path) -> dict[str, Any]:
        try:
            payload = path.read_bytes()
        except OSError as exc:
            raise CatalogRecoveryAmbiguous(f"cannot read catalog state: {path}") from exc
        if len(payload) > _MAX_CATALOG_BYTES:
            raise CatalogRecoveryAmbiguous(f"catalog document exceeds limit: {path}")
        try:
            value = json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise CatalogRecoveryAmbiguous(f"invalid catalog JSON: {path}") from exc
        if not isinstance(value, dict):
            raise CatalogRecoveryAmbiguous(f"catalog object expected: {path}")
        return value

    @staticmethod
    def _manifest_digest(manifest: TopologyManifest) -> str:
        return hashlib.sha256(_canonical_bytes(manifest.to_dict())).hexdigest()

    @staticmethod
    def _atomic_json(path: Path, value: dict[str, Any], *, exclusive: bool = False) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        try:
            with os.fdopen(os.open(temporary, flags, 0o600), "wb") as handle:
                handle.write(_canonical_bytes(value))
                handle.flush()
                os.fsync(handle.fileno())
            if exclusive:
                try:
                    os.link(temporary, path)
                except FileExistsError:
                    existing = FileCatalog._read_json(path)
                    if existing != value:
                        raise CatalogConflict(f"immutable catalog generation exists: {path}")
            else:
                os.replace(temporary, path)
            try:
                directory = os.open(path.parent, os.O_RDONLY)
            except OSError:
                directory = None
            if directory is not None:
                try:
                    os.fsync(directory)
                finally:
                    os.close(directory)
        finally:
            temporary.unlink(missing_ok=True)


def _canonical_bytes(value: dict[str, Any]) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode(
        "utf-8"
    )
