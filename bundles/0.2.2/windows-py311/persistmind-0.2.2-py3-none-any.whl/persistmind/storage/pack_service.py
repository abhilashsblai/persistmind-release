from __future__ import annotations

import fnmatch
import hashlib
import json
import time
from pathlib import Path
from typing import Any, Mapping

from persistmind.config import load_settings
from persistmind.application.pack_assembler import assemble_pack
from persistmind.agent_runtime.identity import repository_context
from persistmind.agent_runtime.cache import (
    RuntimeCache,
    build_cache_key,
    cache_scope,
    cache_scope_matches,
)
from persistmind.utils import canonical_json, canonical_repo_path, stable_id, utc_now
from persistmind.verification.scope_assessment import assess_scope_documents
from persistmind.workflow.evidence import build_verification_evidence, current_diff_fingerprint

from .adapters.sqlite_activity import SQLiteActivityStore
from .adapters.sqlite_source import SQLiteSourceSegmentStore, SQLiteSourceStore
from .adapters.sqlite_task import SQLiteTaskStore, TaskConflict
from .descriptors import StoreRole
from .runtime import StorageOpenIntent, StorageRuntime, resolve_runtime_store
from .workflow_lifecycle import WorkflowLifecycleCoordinator


def _stable_verification_report_hash(report: Mapping[str, Any]) -> str:
    stable_report = dict(report)
    performance = stable_report.get("performance")
    if isinstance(performance, Mapping):
        stable_report["performance"] = {
            key: value for key, value in performance.items() if key != "elapsed_ms"
        }
    return hashlib.sha256(canonical_json(stable_report).encode("utf-8")).hexdigest()


class PackService:
    """Bounded context-pack compiler using sealed Source and finalized Activity."""

    def __init__(
        self,
        repo_root: Path,
        *,
        allow_development_driver: bool = False,
        read_only: bool = False,
    ) -> None:
        self.repo_root = repo_root.resolve()
        settings = load_settings(self.repo_root)
        self.settings = settings
        self._read_only = read_only
        self.runtime = StorageRuntime.open(
            self.repo_root / settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=allow_development_driver,
            read_only=read_only,
            required_roles=frozenset(
                {
                    StoreRole.SOURCE_MANIFEST,
                    StoreRole.SOURCE_SEGMENT,
                    StoreRole.TASK_STATE,
                    StoreRole.ACTIVITY_ACTIVE,
                }
            ),
        )
        activity = resolve_runtime_store(
            self.runtime, StoreRole.ACTIVITY_ACTIVE, read_only=read_only
        )
        if not isinstance(activity, SQLiteActivityStore):
            raise RuntimeError("Activity route did not resolve for pack finalization")
        self.activity = activity
        task_store = resolve_runtime_store(self.runtime, StoreRole.TASK_STATE, read_only=read_only)
        if not isinstance(task_store, SQLiteTaskStore):
            raise RuntimeError("Task route did not resolve for pack binding")
        self.task_store = task_store
        self.cache = RuntimeCache(self.runtime.root, read_only=read_only)
        self.lifecycle = WorkflowLifecycleCoordinator(
            self.repo_root,
            allow_development_driver=allow_development_driver,
            runtime=self.runtime,
        )

    def close(self) -> None:
        self.runtime.close()

    def __enter__(self) -> "PackService":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def get_context_pack(
        self,
        task: str | None,
        budget: int | None = None,
        seed_paths: list[str] | None = None,
        *,
        task_session_id: str | None = None,
        seed_from_diff: bool = False,
        **_: Any,
    ) -> dict[str, Any]:
        query = str(task or "").strip()
        if not query:
            raise ValueError("pack requires a non-empty task")
        limit_tokens = max(256, min(int(budget or 8_000), 64_000))
        seeds = {str(path).replace("\\", "/") for path in seed_paths or []}
        if seed_from_diff:
            from persistmind.git_utils import git_changed_paths

            seeds.update(git_changed_paths(self.repo_root))
        bound_task = None
        if task_session_id:
            bound_task = self.task_store.session(task_session_id)
            if bound_task is None:
                raise KeyError(f"task session not found: {task_session_id}")
            if str(bound_task.get("state")) not in {"INTAKE", "PACK"}:
                raise ValueError("context pack can only bind an INTAKE or PACK task")
        candidates: dict[str, dict[str, Any]] = {}
        segment_ids: list[str] = []
        try:
            read_set = self.runtime.router.resolve_read_set(StoreRole.SOURCE_SEGMENT)
        except KeyError:
            read_set = ()
        source_stores = [store for store in read_set if isinstance(store, SQLiteSourceSegmentStore)]
        source_manifest = resolve_runtime_store(
            self.runtime, StoreRole.SOURCE_MANIFEST, read_only=self._read_only
        )
        if not isinstance(source_manifest, SQLiteSourceStore):
            raise RuntimeError("Source manifest route is unavailable for pack generation")
        source_view_id = repository_context(self.repo_root).source_view_id
        current_generation = source_manifest.current_generation(source_view_id)
        cache_key = build_cache_key(
            self.repo_root,
            self.runtime.root,
            source_generation=current_generation or "unpublished",
            request={
                "task": query,
                "task_session_id": task_session_id,
                "task_revision": int(bound_task.get("revision", 0)) if bound_task else 0,
                "seed_paths": sorted(seeds),
            },
            limits={"budget_tokens": limit_tokens},
            algorithm_version="persistmind.context_pack.v3",
        )
        cached = self.cache.get(
            "pack",
            cache_key,
            authorize=lambda value: (
                cache_scope_matches(value, cache_key)
                and source_manifest.current_generation(source_view_id) == current_generation
            ),
        )
        if cached is not None and isinstance(cached.get("result"), Mapping):
            cached_result = dict(cached["result"])
            cached_pack_id = str(cached_result.get("pack_id") or "")
            existing = self.get_pack_manifest(cached_pack_id) if cached_pack_id else {"ok": False}
            if existing.get("ok"):
                lifecycle_event = self._bind_pack_to_task(
                    cached_pack_id, task_session_id, bound_task
                )
                return {**existing, **(lifecycle_event or {}), "nextgen_v1": True}
            self.cache.bypass()
        generation_files = (
            source_manifest.generation_files(current_generation) if current_generation else []
        )
        artifact_ids = {str(item["artifact_id"]) for item in generation_files}
        if artifact_ids:
            stores = [
                store
                for store in source_stores
                if str(store.descriptor.partition_key) in artifact_ids
            ]
        else:
            latest_generation = max(
                (store.descriptor.generation for store in source_stores), default=-1
            )
            stores = [
                store for store in source_stores if store.descriptor.generation == latest_generation
            ]
        source_generation_id: str | None = None
        source_fingerprint: str | None = None
        generation = source_manifest.generation(current_generation) if current_generation else None
        if generation_files and generation is not None:
            source_generation_id = current_generation
            source_fingerprint = str(generation["input_hash"])
        candidate_scores: dict[str, int] = {}
        from persistmind.context_snippets import context_relevance

        for store in stores:
            segment_ids.append(store.descriptor.store_id)
            if not generation_files:
                source_generation_id = store.descriptor.partition_key
                source_fingerprint = store.descriptor.logical_content_hash
            for record in store.source_records("", limit=1000):
                path = str(record.get("path") or "")
                candidate = dict(record)
                score, matched = context_relevance(query, candidate)
                if path in seeds or matched:
                    if path in seeds:
                        score += 10_000
                    if score > candidate_scores.get(path, -1):
                        candidates[path] = candidate
                        candidate_scores[path] = score
        if not segment_ids:
            return {
                "ok": False,
                "status": "source_not_ready",
                "remediation": "persistmind --repo . index",
                "nextgen_v1": True,
            }
        ordered = sorted(
            candidates.values(),
            key=lambda item: (
                str(item.get("path")) not in seeds,
                -candidate_scores.get(str(item.get("path") or ""), 0),
                str(item.get("path")),
            ),
        )
        selected: list[dict[str, Any]] = []
        tokens = 0
        for item in ordered:
            estimate = max(1, len(str(item.get("text") or "")) // 4)
            if selected and tokens + estimate > limit_tokens:
                continue
            selected.append(item)
            tokens += estimate
            if tokens >= limit_tokens:
                break
        manifest = assemble_pack(
            {
                "task": query,
                "task_session_id": task_session_id,
                "source_segments": sorted(segment_ids),
                "snapshot_id": source_generation_id,
                "source_generation_id": source_generation_id,
                "source_index_fingerprint": source_fingerprint,
                "seed_paths": sorted(seeds),
                "items": selected,
                "budget_tokens": limit_tokens,
                "estimated_tokens": tokens,
                "schema_version": "persistmind.context_pack.v3",
            }
        )
        pack_id = manifest["pack_id"]
        existing_manifest = self.get_pack_manifest(pack_id)
        if existing_manifest.get("ok"):
            if existing_manifest.get("task_session_id") != task_session_id:
                raise RuntimeError("finalized pack task binding divergence")
            lifecycle_event = self._bind_pack_to_task(
                pack_id,
                task_session_id,
                bound_task,
            )
            result = {
                **existing_manifest,
                **(lifecycle_event or {}),
                "nextgen_v1": True,
            }
            self.cache.put("pack", cache_key, {"scope": cache_scope(cache_key), "result": result})
            return result
        encoded = canonical_json(manifest).encode("utf-8")
        if len(encoded) > 48 * 1024:
            reference = self.runtime.artifacts.put(encoded, classification="internal")
            persisted: dict[str, Any] = {
                "object_ref": reference,
                "content_hash": reference[7:],
            }
        else:
            persisted = {"manifest": manifest}
        finalized_at = utc_now()
        self.activity.append(
            {
                "event_id": pack_id,
                "event_type": "context_pack.finalized",
                "occurred_at": finalized_at,
                "payload": persisted,
            },
            idempotency_key=f"context-pack:{pack_id}",
        )
        lifecycle_event = self._bind_pack_to_task(pack_id, task_session_id, bound_task)
        result = {
            "ok": True,
            **manifest,
            "created_at": finalized_at,
            "response": {"finalized_at": finalized_at},
            **(lifecycle_event or {}),
            "nextgen_v1": True,
        }
        self.cache.put("pack", cache_key, {"scope": cache_scope(cache_key), "result": result})
        return result

    def verify_paths(
        self,
        pack_id: str,
        paths: list[str],
        *,
        verification_name: str = "check-diff",
        diff: str | None = None,
    ) -> dict[str, Any]:
        """Run a authority-native pack verification and bind it to Task State."""

        if verification_name not in {"check-diff", "impact"}:
            raise ValueError("unsupported pack verification")
        started = time.perf_counter()
        manifest = self.get_pack_manifest(pack_id)
        if not manifest.get("ok"):
            raise KeyError(f"pack not found: {pack_id}")
        normalized_input = sorted(
            {
                canonical_repo_path(path, self.repo_root, reject_outside=True)
                for path in paths
                if str(path).strip()
            }
        )
        excluded = [
            {"path": path, "reason": "matches configured impact ignore_globs"}
            for path in normalized_input
            if any(fnmatch.fnmatch(path, pattern) for pattern in self.settings.ignore_globs)
        ]
        excluded_paths = {str(item["path"]) for item in excluded}
        analyzed = [path for path in normalized_input if path not in excluded_paths]
        pack_paths = {
            canonical_repo_path(str(item.get("path") or ""), self.repo_root)
            for item in manifest.get("items", [])
            if isinstance(item, dict) and item.get("path")
        }
        seed_paths = {
            canonical_repo_path(str(path), self.repo_root)
            for path in manifest.get("seed_paths", [])
            if str(path).strip()
        }
        context_paths = pack_paths | seed_paths
        out_of_pack = sorted(set(analyzed) - context_paths)

        from .source_service import SourceService

        source = SourceService(
            self.repo_root,
            allow_development_driver=self.activity._allow_development_driver,
            runtime=self.runtime,
            read_only=True,
        )
        impact = source.impact(analyzed)
        report = {
            **impact,
            "schema_version": "persistmind.impact_report.v1",
            "input_paths": normalized_input,
            "analyzed_paths": analyzed,
            "excluded_paths": excluded,
            "pack_awareness": {
                "pack_id": pack_id,
                "pack_paths": sorted(pack_paths),
                "seed_paths": sorted(seed_paths),
                "out_of_pack_paths": out_of_pack,
                "uncovered_noncode": [],
                "out_of_impact_paths": [],
            },
            "risk": {
                "score": 0.0 if not out_of_pack else min(10.0, float(len(out_of_pack))),
                "components": {},
                "metrics": {"changed_files": len(analyzed)},
                "untested_paths": [],
                "critical_paths": [],
                "graph_central_paths": [],
            },
            "performance": {
                "mode": "authority_scoped_check_diff"
                if verification_name == "check-diff"
                else "authority_impact",
                "closure_traversal": verification_name == "impact",
                "elapsed_ms": round((time.perf_counter() - started) * 1000, 2),
            },
        }
        task_session_id = str(manifest.get("task_session_id") or "")
        if not task_session_id:
            assessment = assess_scope_documents(
                repo_root=self.repo_root,
                actual_paths=analyzed,
                retrieved_paths=sorted(context_paths),
                task_session_id=None,
                pack_id=pack_id,
                plan_id=None,
                plan_revision_id=None,
                plan_revision_number=None,
                plan_hash=None,
                plan_document={},
                validation={},
                required_verifications=[],
                passed_verifications=[],
                source_view={
                    "snapshot_id": manifest.get("snapshot_id"),
                    "generation_id": manifest.get("source_generation_id"),
                    "fingerprint": manifest.get("source_index_fingerprint"),
                },
                diff=diff,
                incomplete_reasons=["task_session_required", "approved_plan_required"],
            )
            return {
                "ok": False,
                "status": assessment["status"],
                "violations": assessment["violations"],
                "scope_assessment": assessment,
                "impact_report": report,
                "pack_id": pack_id,
                "nextgen_v1": True,
            }
        task = self.task_store.session(task_session_id)
        if task is None:
            raise KeyError(f"task session not found: {task_session_id}")
        if str(task.get("pack_id") or "") != pack_id:
            raise ValueError("verification pack does not match the task-bound pack")
        if str(task.get("state")) not in {"EXECUTE", "PREFLIGHT"}:
            raise ValueError("pack verification requires an EXECUTE or PREFLIGHT task")
        plan = self.task_store.latest_plan(task_session_id)
        if plan is None:
            raise ValueError("pack verification requires an active task plan")
        plan_id = str(plan["plan_id"])
        revisions = list(self.task_store.plan_revisions(plan_id))
        revision = revisions[-1] if revisions else None
        incomplete: list[str] = []
        if revision is None:
            incomplete.append("plan_revision_required")
        elif int(revision.get("revision", 0)) != int(plan.get("revision", 0)):
            incomplete.append("plan_revision_stale")
        if str(plan.get("metadata", {}).get("pack_id") or "") != pack_id:
            incomplete.append("plan_pack_binding_mismatch")
        passed = [
            str(item.get("name"))
            for item in self.task_store.verifications(task_session_id)
            if str(item.get("plan_id") or "") == plan_id
            and str(item.get("status") or "").casefold() in {"pass", "passed", "ok", "success"}
        ]
        assessment = assess_scope_documents(
            repo_root=self.repo_root,
            actual_paths=analyzed,
            retrieved_paths=sorted(context_paths),
            task_session_id=task_session_id,
            pack_id=pack_id,
            plan_id=plan_id,
            plan_revision_id=(str(revision.get("revision_id")) if revision else None),
            plan_revision_number=(int(revision.get("revision", 0)) if revision else None),
            plan_hash=(str(revision.get("plan_hash")) if revision else None),
            plan_document=dict((revision or plan).get("plan") or {}),
            validation=dict((revision or plan).get("validation") or {}),
            required_verifications=[str(item) for item in plan.get("required_verifications", [])],
            passed_verifications=passed,
            source_view={
                "snapshot_id": manifest.get("snapshot_id"),
                "generation_id": manifest.get("source_generation_id"),
                "fingerprint": manifest.get("source_index_fingerprint"),
            },
            diff=diff,
            incomplete_reasons=incomplete,
        )
        violations = list(assessment["violations"])
        response: dict[str, Any] = {
            "ok": bool(assessment["ok"]),
            "status": assessment["status"],
            "violations": violations,
            "scope_assessment": assessment,
            "impact_report": report,
            "pack_id": pack_id,
            "nextgen_v1": True,
        }
        report_hash = _stable_verification_report_hash(report)
        verification_id = (
            "verification_"
            + stable_id(
                verification_name,
                task_session_id,
                pack_id,
                plan_id,
                canonical_json(analyzed),
                hashlib.sha256((diff or "").encode("utf-8")).hexdigest(),
                report_hash,
            )[:32]
        )
        verification_payload: dict[str, Any] = {
            "name": verification_name,
            "pack_id": pack_id,
            "plan_id": plan_id,
            "status": "pass" if response["ok"] else "fail",
            "input_paths": normalized_input,
            "analyzed_paths": analyzed,
            "violations": violations,
            "report_hash": report_hash,
        }
        verification_payload["typed_evidence"] = build_verification_evidence(
            evidence_type="check_diff",
            task_session_id=task_session_id,
            pack_id=pack_id,
            plan_id=plan_id,
            plan_revision_id=str(assessment["plan_revision_id"] or ""),
            plan_revision_number=int(assessment["plan_revision_number"] or 0),
            scope_revision_id=str(assessment["scope_revision_id"] or ""),
            source_view=dict(assessment["source_view"]),
            diff_fingerprint=current_diff_fingerprint(self.repo_root),
            command="persistmind check-diff",
            result=str(verification_payload["status"]),
            artifact=report,
        )
        if self._read_only:
            response.update(
                {
                    "verification_id": verification_id,
                    "recorded": False,
                    "query_guarantee": "no-writer-resolution",
                }
            )
            return response
        self.task_store.append_verification(
            verification_id,
            task_session_id=task_session_id,
            payload=verification_payload,
            idempotency_key=f"task-verification:{verification_id}",
        )
        event = self.lifecycle.emit(
            "VerificationCompleted.v1",
            task_session_id,
            source_operation_key=f"verification:{verification_id}",
            payload={
                "verification_id": verification_id,
                "verification_name": verification_name,
                "pack_id": pack_id,
                "plan_id": plan_id,
                "status": verification_payload["status"],
                "report_hash": verification_payload["report_hash"],
            },
            producer="pack-service",
        )
        for attempt in range(3):
            snapshot = self.task_store.workflow_snapshot(task_session_id)
            snapshot_payload = {
                key: value
                for key, value in dict(snapshot or {}).items()
                if key not in {"task_session_id", "pack_id", "plan_id", "revision", "updated_at"}
            }
            snapshot_payload.update(
                {
                    "verification_id": verification_id,
                    "verification_name": verification_name,
                    "verification_status": verification_payload["status"],
                    "verification_report_hash": verification_payload["report_hash"],
                }
            )
            try:
                self.task_store.save_workflow_snapshot(
                    task_session_id,
                    payload=snapshot_payload,
                    pack_id=pack_id,
                    plan_id=plan_id,
                    expected_revision=(int(snapshot["revision"]) if snapshot is not None else 0),
                )
                break
            except TaskConflict:
                if attempt == 2:
                    raise
                time.sleep(0.01 * (attempt + 1))
        response.update(
            {
                "task_session_id": task_session_id,
                "plan_id": plan_id,
                "lifecycle_event_id": event["event_id"],
                "lifecycle_sequence": event["sequence"],
            }
        )
        return response

    def _bind_pack_to_task(
        self,
        pack_id: str,
        task_session_id: str | None,
        bound_task: Mapping[str, Any] | None,
    ) -> dict[str, Any] | None:
        if bound_task is None or not task_session_id:
            return None
        existing_pack = str(bound_task.get("pack_id") or "")
        if str(bound_task.get("state")) == "INTAKE":
            from .task_service import TaskService

            with TaskService(
                self.repo_root,
                allow_development_driver=self.activity._allow_development_driver,
            ) as tasks:
                transition = tasks.task_transition(
                    task_session_id,
                    "PACK",
                    actor="pack-service",
                    reason="context pack finalized",
                    pack_id=pack_id,
                )
            return {
                "lifecycle_event_id": transition["lifecycle_event_id"],
                "lifecycle_sequence": transition["lifecycle_sequence"],
            }
        if existing_pack != pack_id:
            raise ValueError("PACK task is already bound to a different context pack")
        event = next(
            (
                item
                for item in reversed(self.lifecycle.events(task_session_id))
                if item.get("event_type") == "PackBound.v1"
                and item.get("payload", {}).get("pack_id") == pack_id
            ),
            None,
        )
        if event is None:
            raise RuntimeError("task-bound pack is missing its lifecycle event")
        return {
            "lifecycle_event_id": event["event_id"],
            "lifecycle_sequence": event["sequence"],
        }

    def get_pack_manifest(self, pack_id: str) -> dict[str, Any]:
        event = self.activity.event(pack_id)
        if event is None or event.get("event_type") != "context_pack.finalized":
            return {"ok": False, "status": "not_found", "pack_id": pack_id}
        outer = event.get("payload")
        payload = outer.get("payload") if isinstance(outer, dict) else None
        if not isinstance(payload, dict):
            raise RuntimeError("invalid finalized pack event")
        manifest = payload.get("manifest")
        if isinstance(manifest, dict):
            return {
                "ok": True,
                **manifest,
                "created_at": event["occurred_at"],
                "nextgen_v1": True,
            }
        reference = str(payload.get("object_ref") or "")
        if not reference:
            raise RuntimeError("finalized pack has no manifest reference")
        value = json.loads(self.runtime.artifacts.get(reference))
        if not isinstance(value, dict) or value.get("pack_id") != pack_id:
            raise RuntimeError("finalized pack object identity mismatch")
        return {"ok": True, **value, "created_at": event["occurred_at"], "nextgen_v1": True}

    def reconstruct_pack(self, pack_id: str, task_text: str | None = None) -> dict[str, Any]:
        manifest = self.get_pack_manifest(pack_id)
        if not manifest.get("ok"):
            return manifest
        if task_text is not None and task_text != manifest.get("task"):
            raise ValueError("task text does not match finalized pack")
        immutable = {
            key: value for key, value in manifest.items() if key not in {"ok", "nextgen_v1"}
        }
        return {"ok": True, **immutable, "manifest": immutable, "nextgen_v1": True}
