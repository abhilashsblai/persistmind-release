from __future__ import annotations

import fnmatch
import hashlib
import json
import time
from collections import defaultdict
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from persistmind.agent_runtime.cache import (
    RuntimeCache,
    build_cache_key,
    cache_scope,
    cache_scope_matches,
)
from persistmind.agent_runtime.identity import repository_context
from persistmind.application.pack_assembler import assemble_pack
from persistmind.application.public_surface import task_exposes_public_functionality
from persistmind.config import load_settings
from persistmind.governance.plans import required_contract_items
from persistmind.utils import canonical_json, canonical_repo_path, stable_id, utc_now
from persistmind.verification.scope_assessment import assess_scope_documents
from persistmind.workflow.evidence import build_verification_evidence, current_diff_fingerprint

from .adapters.sqlite_activity import SQLiteActivityStore
from .adapters.sqlite_knowledge import SQLiteKnowledgeStore
from .adapters.sqlite_source import SQLiteSourceSegmentStore, SQLiteSourceStore
from .adapters.sqlite_task import SQLiteTaskStore, TaskConflict
from .descriptors import StoreRole
from .model_bundle import source_embedder
from .public_surface_cache import derive_cached_public_surface_files
from .runtime import StorageOpenIntent, StorageRuntime, resolve_runtime_store
from .workflow_lifecycle import WorkflowLifecycleCoordinator

SEED_GUARANTEED_CHUNKS = 3
SEMANTIC_INCLUSION_THRESHOLD = 0.05


def _stable_verification_report_hash(report: Mapping[str, Any]) -> str:
    stable_report = dict(report)
    performance = stable_report.get("performance")
    if isinstance(performance, Mapping):
        stable_report["performance"] = {
            key: value for key, value in performance.items() if key != "elapsed_ms"
        }
    return hashlib.sha256(canonical_json(stable_report).encode("utf-8")).hexdigest()


def _source_record_provider(stores: list[SQLiteSourceSegmentStore]):
    def source_records(query: str, limit: int) -> list[Mapping[str, Any]]:
        records: list[Mapping[str, Any]] = []
        remaining = max(1, min(int(limit), 10_000))
        for store in stores:
            if remaining <= 0:
                break
            found = list(store.source_records(query, limit=remaining))
            records.extend(found)
            remaining -= len(found)
        return records

    return source_records


def _pack_item(record: dict[str, Any]) -> dict[str, Any]:
    if str(record.get("kind") or "") == "source_chunk":
        record.setdefault("chunk_id", record.get("record_id"))
    if record.get("retrieval_match_method"):
        record["match_method"] = record.get("retrieval_match_method")
    if record.get("retrieval_matched_terms"):
        record["matched_terms"] = list(record.get("retrieval_matched_terms") or [])
    return record


def _memory_pack_item(record: dict[str, Any]) -> dict[str, Any]:
    assertion = str(record.get("assertion") or "")
    metadata = record.get("metadata") if isinstance(record.get("metadata"), Mapping) else {}
    text_parts = [
        f"{record.get('type')}: {assertion}",
        str(record.get("applies_when") or ""),
        str(record.get("avoid_when") or ""),
        str(metadata.get("rationale") or ""),
        str(metadata.get("root_cause") or ""),
        str(metadata.get("resolution") or ""),
    ]
    return {
        "kind": "memory",
        "record_id": str(record.get("record_id") or ""),
        "type": str(record.get("type") or ""),
        "title": str(record.get("title") or assertion[:80]),
        "assertion": assertion,
        "scope": str(record.get("scope") or ""),
        "score": record.get("score"),
        "confidence": record.get("confidence"),
        "decayed_confidence": record.get("decayed_confidence"),
        "match_method": record.get("match_method"),
        "freshness_status": record.get("freshness_status"),
        "requires_revalidation": bool(record.get("requires_revalidation", False)),
        "text": "\n".join(part for part in text_parts if part),
    }


def _history_boost(
    path: str,
    *,
    churn_paths: Mapping[str, float],
    cochange_paths: Mapping[str, float],
    weight: float,
) -> int:
    if weight <= 0:
        return 0
    churn = min(10.0, float(churn_paths.get(path, 0.0)))
    cochange = min(1.0, float(cochange_paths.get(path, 0.0)))
    return int(round(((churn * 3.0) + (cochange * 50.0)) * weight))


class PackService:
    """Bounded context-pack compiler using sealed Source and finalized Activity."""

    REQUIRED_ROLES = frozenset(
        {
            StoreRole.SOURCE_MANIFEST,
            StoreRole.SOURCE_SEGMENT,
            StoreRole.TASK_STATE,
            StoreRole.ACTIVITY_ACTIVE,
            StoreRole.KNOWLEDGE,
        }
    )

    def __init__(
        self,
        repo_root: Path,
        *,
        allow_development_driver: bool = False,
        read_only: bool = False,
    ) -> None:
        self.repo_root = repo_root.resolve()
        settings = load_settings(self.repo_root)
        self.settings = settings
        self._allow_development_driver = allow_development_driver
        self._read_only = read_only
        self.runtime = StorageRuntime.open(
            self.repo_root / settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=allow_development_driver,
            read_only=read_only,
            required_roles=self.REQUIRED_ROLES,
        )
        activity = resolve_runtime_store(
            self.runtime, StoreRole.ACTIVITY_ACTIVE, read_only=read_only
        )
        if not isinstance(activity, SQLiteActivityStore):
            raise RuntimeError("Activity route did not resolve for pack finalization")
        self.activity = activity
        task_store = resolve_runtime_store(self.runtime, StoreRole.TASK_STATE, read_only=read_only)
        if not isinstance(task_store, SQLiteTaskStore):
            raise RuntimeError("Task route did not resolve for pack binding")
        self.task_store = task_store
        self.embedder = source_embedder(self.runtime.root)
        self.cache = RuntimeCache(self.runtime.root, read_only=read_only)
        self.lifecycle = WorkflowLifecycleCoordinator(
            self.repo_root,
            allow_development_driver=allow_development_driver,
            runtime=self.runtime,
        )

    def close(self) -> None:
        self.runtime.close()

    def __enter__(self) -> PackService:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def get_context_pack(
        self,
        task: str | None,
        budget: int | None = None,
        seed_paths: list[str] | None = None,
        *,
        task_session_id: str | None = None,
        seed_from_diff: bool = False,
        **_: Any,
    ) -> dict[str, Any]:
        query = str(task or "").strip()
        if not query:
            raise ValueError("pack requires a non-empty task")
        limit_tokens = max(256, min(int(budget or 8_000), 64_000))
        seeds = {str(path).replace("\\", "/") for path in seed_paths or []}
        if seed_from_diff:
            from persistmind.git_utils import git_changed_paths

            seeds.update(git_changed_paths(self.repo_root))
        bound_task = None
        if task_session_id:
            bound_task = self.task_store.session(task_session_id)
            if bound_task is None:
                raise KeyError(f"task session not found: {task_session_id}")
            if str(bound_task.get("state")) not in {"INTAKE", "PACK"}:
                raise ValueError("context pack can only bind an INTAKE or PACK task")
        candidates: dict[str, dict[str, Any]] = {}
        segment_ids: list[str] = []
        try:
            read_set = self.runtime.router.resolve_read_set(StoreRole.SOURCE_SEGMENT)
        except KeyError:
            read_set = ()
        source_stores = [store for store in read_set if isinstance(store, SQLiteSourceSegmentStore)]
        source_manifest = resolve_runtime_store(
            self.runtime, StoreRole.SOURCE_MANIFEST, read_only=self._read_only
        )
        if not isinstance(source_manifest, SQLiteSourceStore):
            raise RuntimeError("Source manifest route is unavailable for pack generation")
        repo_context = repository_context(self.repo_root)
        source_view_id = repo_context.source_view_id
        current_generation = source_manifest.current_generation(source_view_id)
        generation_files = (
            source_manifest.generation_files(current_generation) if current_generation else []
        )
        artifact_ids = {str(item["artifact_id"]) for item in generation_files}
        if artifact_ids:
            stores = [
                store
                for store in source_stores
                if str(store.descriptor.partition_key) in artifact_ids
            ]
        else:
            latest_generation = max(
                (store.descriptor.generation for store in source_stores), default=-1
            )
            stores = [
                store for store in source_stores if store.descriptor.generation == latest_generation
            ]
        source_generation_id: str | None = None
        source_fingerprint: str | None = None
        generation = source_manifest.generation(current_generation) if current_generation else None
        if generation_files and generation is not None:
            source_generation_id = current_generation
            source_fingerprint = str(generation["input_hash"])
        public_surface_included: set[str] = set()
        if not seeds and task_exposes_public_functionality(query):
            from persistmind.context_snippets import context_relevance

            scored_paths: dict[str, int] = {}
            for store in stores:
                for record in store.source_records("", limit=1000):
                    path = str(record.get("path") or "")
                    if not path:
                        continue
                    score, matched = context_relevance(query, dict(record))
                    if matched and score > scored_paths.get(path, -1):
                        scored_paths[path] = score
            top_n = max(0, int(getattr(self.settings.eval, "public_surface_implicit_seed_top_n", 5)))
            seeds.update(
                path
                for path, _score in sorted(
                    scored_paths.items(), key=lambda item: (-item[1], item[0])
                )[:top_n]
            )
        if seeds and task_exposes_public_functionality(query):
            derived_surfaces = derive_cached_public_surface_files(
                self.repo_root,
                self.runtime.root,
                self.cache,
                paths=seeds,
                source_generation=current_generation,
                current_generation=lambda: source_manifest.current_generation(source_view_id),
                known_paths=[str(item["path"]) for item in generation_files],
                source_records=_source_record_provider(stores),
            )
            public_surface_included.update(derived_surfaces)
            seeds.update(
                derived_surfaces
            )
        cache_key = build_cache_key(
            self.repo_root,
            self.runtime.root,
            source_generation=current_generation or "unpublished",
            request={
                "task": query,
                "task_session_id": task_session_id,
                "task_revision": int(bound_task.get("revision", 0)) if bound_task else 0,
                "seed_paths": sorted(seeds),
                "memory_revision": self._memory_revision(),
            },
            limits={"budget_tokens": limit_tokens},
            algorithm_version="persistmind.context_pack.v7",
        )
        cached = self.cache.get(
            "pack",
            cache_key,
            authorize=lambda value: (
                cache_scope_matches(value, cache_key)
                and source_manifest.current_generation(source_view_id) == current_generation
            ),
        )
        if cached is not None and isinstance(cached.get("result"), Mapping):
            cached_result = dict(cached["result"])
            cached_pack_id = str(cached_result.get("pack_id") or "")
            existing = self.get_pack_manifest(cached_pack_id) if cached_pack_id else {"ok": False}
            if existing.get("ok"):
                lifecycle_event = self._bind_pack_to_task(
                    cached_pack_id, task_session_id, bound_task
                )
                return {**existing, **(lifecycle_event or {}), "nextgen_v1": True}
            self.cache.bypass()
        candidate_scores: dict[str, float] = {}
        retrieval_legs = {
            "lexical": True,
            "vector": "disabled",
            "history": "disabled",
            "memory": "disabled",
        }
        memory_items, memory_tokens = self._memory_pack_items(
            query,
            paths=sorted(seeds),
            limit_tokens=limit_tokens,
        )
        if memory_items:
            retrieval_legs["memory"] = "ready"
        seed_scored: dict[str, list[tuple[int, bool, str, dict[str, Any]]]] = defaultdict(list)
        from persistmind.context_snippets import context_relevance

        query_vector: list[float] = []
        if query:
            query_vector = self.embedder.embed(query)
            retrieval_legs["vector"] = (
                "deterministic_fallback"
                if self.embedder.degraded_reason is not None
                else "ready"
            )
        churn_paths: dict[str, float] = {}
        cochange_paths: dict[str, float] = {}
        for store in stores:
            for record in store.source_records("", limit=10_000):
                kind = str(record.get("kind") or "")
                if kind == "source_churn":
                    path = str(record.get("path") or "")
                    commits = float(record.get("commits") or 0.0)
                    churn_paths[path] = max(churn_paths.get(path, 0.0), commits)
                elif kind == "source_cochange":
                    path = str(record.get("path") or "")
                    related = str(record.get("related_path") or "")
                    jaccard = float(record.get("jaccard") or 0.0)
                    if path in seeds or related in seeds:
                        cochange_paths[related if path in seeds else path] = max(
                            cochange_paths.get(related if path in seeds else path, 0.0),
                            jaccard,
                        )
        if churn_paths or cochange_paths:
            retrieval_legs["history"] = "ready"

        for store in stores:
            segment_ids.append(store.descriptor.store_id)
            if not generation_files:
                source_generation_id = store.descriptor.partition_key
                source_fingerprint = store.descriptor.logical_content_hash
            chunk_records = [
                dict(record)
                for record in store.source_records(query, limit=1000)
                if str(record.get("kind") or "") == "source_chunk"
            ]
            if query_vector:
                vector_records = [
                    dict(record)
                    for record in store.vector_records(query_vector, limit=100)
                    if str(record.get("kind") or "") == "source_chunk"
                ]
                chunk_records.extend(vector_records)
            if seeds:
                chunk_records.extend(
                    dict(record)
                    for record in store.source_records("", limit=5000)
                    if str(record.get("kind") or "") == "source_chunk"
                    and str(record.get("path") or "") in seeds
                )
            for record in chunk_records:
                path = str(record.get("path") or "")
                record_id = str(record.get("record_id") or "")
                candidate = _pack_item(dict(record))
                candidate_key = record_id or stable_id(
                    path, candidate.get("start_line"), candidate.get("end_line")
                )
                score, matched_terms = context_relevance(query, candidate)
                if "semantic_score" in record:
                    score += int(float(record.get("semantic_score") or 0.0) * 100)
                    candidate["retrieval_vector_score"] = record.get("semantic_score")
                history_boost = _history_boost(
                    path,
                    churn_paths=churn_paths,
                    cochange_paths=cochange_paths,
                    weight=float(self.settings.retrieval.history_weight),
                )
                if history_boost:
                    score += history_boost
                    candidate["retrieval_history_boost"] = history_boost
                is_matched = bool(matched_terms)
                semantic_match = (
                    float(record.get("semantic_score") or 0.0) >= SEMANTIC_INCLUSION_THRESHOLD
                )
                if path in seeds:
                    seed_scored[path].append((score, is_matched, candidate_key, candidate))
                elif is_matched or semantic_match:
                    if score > candidate_scores.get(candidate_key, -1):
                        candidates[candidate_key] = candidate
                        candidate_scores[candidate_key] = score
        for path, entries in seed_scored.items():
            deduped: dict[str, tuple[int, bool, str, dict[str, Any]]] = {}
            for score, seed_matched, candidate_key, candidate in entries:
                current = deduped.get(candidate_key)
                if current is None or score > current[0]:
                    deduped[candidate_key] = (score, seed_matched, candidate_key, candidate)
            ordered_seed_entries = sorted(
                deduped.values(),
                key=lambda item: (
                    not item[1],
                    -item[0],
                    str(item[3].get("path") or path),
                    int(item[3].get("start_line") or 0),
                    item[2],
                ),
            )
            for index, (score, seed_matched, candidate_key, candidate) in enumerate(
                ordered_seed_entries
            ):
                if not seed_matched and index >= SEED_GUARANTEED_CHUNKS:
                    continue
                seed_score = score + 10_000
                if seed_score > candidate_scores.get(candidate_key, -1):
                    candidates[candidate_key] = candidate
                    candidate_scores[candidate_key] = seed_score
        if not segment_ids:
            return {
                "ok": False,
                "status": "source_not_ready",
                "remediation": "persistmind --repo . index",
                "nextgen_v1": True,
            }
        ordered = sorted(
            candidates.values(),
            key=lambda item: (
                str(item.get("path")) not in seeds,
                -candidate_scores.get(str(item.get("chunk_id") or item.get("record_id") or ""), 0),
                str(item.get("path")),
                int(item.get("start_line") or 0),
            ),
        )
        selected: list[dict[str, Any]] = []
        tokens = 0
        source_token_budget = max(1, limit_tokens - memory_tokens)
        for item in ordered:
            estimate = max(
                1,
                int(item.get("token_count") or 0) or len(str(item.get("text") or "")) // 4,
            )
            if selected and tokens + estimate > source_token_budget:
                continue
            selected.append(item)
            tokens += estimate
            if tokens >= source_token_budget:
                break
        manifest = assemble_pack(
            {
                "task": query,
                "task_session_id": task_session_id,
                "source_segments": sorted(segment_ids),
                "snapshot_id": source_generation_id,
                "source_generation_id": source_generation_id,
                "source_index_fingerprint": source_fingerprint,
                "seed_paths": sorted(seeds),
                "public_surface_included": sorted(public_surface_included),
                "branch": repo_context.branch,
                "retrieval_legs": retrieval_legs,
                "retrieval_degraded_reason": self.embedder.degraded_reason,
                "items": selected,
                "memory": memory_items,
                "budget_tokens": limit_tokens,
                "estimated_tokens": tokens + memory_tokens,
                "memory_estimated_tokens": memory_tokens,
                "schema_version": "persistmind.context_pack.v3",
            }
        )
        if not manifest.get("items") and not manifest.get("memory"):
            return {
                "ok": False,
                "status": "no_context_found",
                "schema_version": "persistmind.context_pack.empty.v1",
                "task": query,
                "item_count": 0,
                "matched_snippets": [],
                "seed_paths": sorted(seeds),
                "retrieval_legs": retrieval_legs,
                "retrieval_degraded_reason": self.embedder.degraded_reason,
                "low_confidence": True,
                "remediation": (
                    "Re-run with --seed-path, --seed-from-diff, or refresh the source index "
                    "with persistmind --repo . index."
                ),
                "nextgen_v1": True,
            }
        pack_id = manifest["pack_id"]
        existing_manifest = self.get_pack_manifest(pack_id)
        if existing_manifest.get("ok"):
            if existing_manifest.get("task_session_id") != task_session_id:
                raise RuntimeError("finalized pack task binding divergence")
            lifecycle_event = self._bind_pack_to_task(
                pack_id,
                task_session_id,
                bound_task,
            )
            result = {
                **existing_manifest,
                **(lifecycle_event or {}),
                "nextgen_v1": True,
            }
            self.cache.put("pack", cache_key, {"scope": cache_scope(cache_key), "result": result})
            return result
        encoded = canonical_json(manifest).encode("utf-8")
        if len(encoded) > 48 * 1024:
            reference = self.runtime.artifacts.put(encoded, classification="internal")
            persisted: dict[str, Any] = {
                "object_ref": reference,
                "content_hash": reference[7:],
            }
        else:
            persisted = {"manifest": manifest}
        finalized_at = utc_now()
        self.activity.append(
            {
                "event_id": pack_id,
                "event_type": "context_pack.finalized",
                "occurred_at": finalized_at,
                "payload": persisted,
            },
            idempotency_key=f"context-pack:{pack_id}",
        )
        lifecycle_event = self._bind_pack_to_task(pack_id, task_session_id, bound_task)
        result = {
            "ok": True,
            **manifest,
            "created_at": finalized_at,
            "response": {"finalized_at": finalized_at},
            **(lifecycle_event or {}),
            "nextgen_v1": True,
        }
        self.cache.put("pack", cache_key, {"scope": cache_scope(cache_key), "result": result})
        return result

    def _memory_revision(self) -> int:
        try:
            store = resolve_runtime_store(self.runtime, StoreRole.KNOWLEDGE, read_only=True)
        except KeyError:
            return 0
        if not isinstance(store, SQLiteKnowledgeStore):
            return 0
        row = store.connection.execute(
            "SELECT revision FROM domain_metadata WHERE singleton=1"
        ).fetchone()
        return int(row["revision"] if row is not None else 0)

    def _memory_pack_items(
        self,
        task: str,
        *,
        paths: list[str],
        limit_tokens: int,
    ) -> tuple[list[dict[str, Any]], int]:
        if not bool(getattr(self.settings.memory, "episodes_pack_recall_enabled", True)):
            return [], 0
        from persistmind.storage.knowledge_service import KnowledgeService

        configured_limit = max(0, int(getattr(self.settings.memory, "episode_pack_limit", 2)))
        if configured_limit <= 0:
            return [], 0
        with KnowledgeService(
            self.repo_root,
            allow_development_driver=self._allow_development_driver,
            runtime=self.runtime,
            read_only=True,
        ) as knowledge:
            recalled = knowledge.memory_recall(task, paths=paths, limit=max(configured_limit, 5))
        candidates = [
            item for item in recalled.get("records", []) if isinstance(item, Mapping)
        ]
        priority = {
            "architectural_decision": 0,
            "failure_lesson": 1,
            "gotcha": 2,
            "convention": 3,
            "business_rule_candidate": 4,
            "decision": 5,
            "episode": 6,
        }
        candidates.sort(
            key=lambda item: (
                priority.get(str(item.get("type") or ""), 20),
                bool(item.get("recall_generic")),
                -float(item.get("score") or 0.0),
                str(item.get("record_id") or ""),
            )
        )
        selected: list[dict[str, Any]] = []
        tokens = 0
        memory_budget = max(64, min(limit_tokens // 4, 1600))
        for record in candidates:
            item = _memory_pack_item(dict(record))
            estimate = max(1, len(str(item.get("text") or "")) // 4)
            if selected and tokens + estimate > memory_budget:
                continue
            selected.append(item)
            tokens += estimate
            if len(selected) >= configured_limit or tokens >= memory_budget:
                break
        return selected, tokens

    def verify_paths(
        self,
        pack_id: str,
        paths: list[str],
        *,
        verification_name: str = "check-diff",
        diff: str | None = None,
    ) -> dict[str, Any]:
        """Run a authority-native pack verification and bind it to Task State."""

        if verification_name not in {"check-diff", "impact"}:
            raise ValueError("unsupported pack verification")
        started = time.perf_counter()
        manifest = self.get_pack_manifest(pack_id)
        if not manifest.get("ok"):
            raise KeyError(f"pack not found: {pack_id}")
        normalized_input = sorted(
            {
                canonical_repo_path(path, self.repo_root, reject_outside=True)
                for path in paths
                if str(path).strip()
            }
        )
        excluded = [
            {"path": path, "reason": "matches configured impact ignore_globs"}
            for path in normalized_input
            if any(fnmatch.fnmatch(path, pattern) for pattern in self.settings.ignore_globs)
        ]
        excluded_paths = {str(item["path"]) for item in excluded}
        analyzed = [path for path in normalized_input if path not in excluded_paths]
        pack_paths = {
            canonical_repo_path(str(item.get("path") or ""), self.repo_root)
            for item in manifest.get("items", [])
            if isinstance(item, dict) and item.get("path")
        }
        seed_paths = {
            canonical_repo_path(str(path), self.repo_root)
            for path in manifest.get("seed_paths", [])
            if str(path).strip()
        }
        context_paths = pack_paths | seed_paths
        out_of_pack = sorted(set(analyzed) - context_paths)
        public_surface_included = {
            canonical_repo_path(str(path), self.repo_root)
            for path in manifest.get("public_surface_included", [])
            if str(path).strip()
        }

        from .source_service import SourceService

        source = SourceService(
            self.repo_root,
            allow_development_driver=self.activity._allow_development_driver,
            runtime=self.runtime,
            read_only=True,
        )
        impact = source.impact(analyzed)
        report = {
            **impact,
            "schema_version": "persistmind.impact_report.v1",
            "input_paths": normalized_input,
            "analyzed_paths": analyzed,
            "excluded_paths": excluded,
            "pack_awareness": {
                "pack_id": pack_id,
                "pack_paths": sorted(pack_paths),
                "seed_paths": sorted(seed_paths),
                "out_of_pack_paths": out_of_pack,
                "uncovered_noncode": [],
                "out_of_impact_paths": [],
            },
            "risk": {
                "score": 0.0 if not out_of_pack else min(10.0, float(len(out_of_pack))),
                "components": {},
                "metrics": {"changed_files": len(analyzed)},
                "untested_paths": [],
                "critical_paths": [],
                "graph_central_paths": [],
            },
            "performance": {
                "mode": "authority_scoped_check_diff"
                if verification_name == "check-diff"
                else "authority_impact",
                "closure_traversal": verification_name == "impact",
                "elapsed_ms": round((time.perf_counter() - started) * 1000, 2),
            },
        }
        task_session_id = str(manifest.get("task_session_id") or "")
        if not task_session_id:
            assessment = assess_scope_documents(
                repo_root=self.repo_root,
                actual_paths=analyzed,
                retrieved_paths=sorted(context_paths),
                task_session_id=None,
                pack_id=pack_id,
                plan_id=None,
                plan_revision_id=None,
                plan_revision_number=None,
                plan_hash=None,
                plan_document={},
                validation={},
                required_verifications=[],
                passed_verifications=[],
                source_view={
                    "snapshot_id": manifest.get("snapshot_id"),
                    "generation_id": manifest.get("source_generation_id"),
                    "fingerprint": manifest.get("source_index_fingerprint"),
                },
                diff=diff,
                incomplete_reasons=["task_session_required", "approved_plan_required"],
            )
            return {
                "ok": False,
                "status": assessment["status"],
                "incomplete_reasons": assessment.get("incomplete_reasons", []),
                "remediation": _scope_remediation(assessment.get("incomplete_reasons", [])),
                "violations": assessment["violations"],
                "scope_assessment": assessment,
                "impact_report": report,
                "pack_id": pack_id,
                "nextgen_v1": True,
            }
        task = self.task_store.session(task_session_id)
        if task is None:
            raise KeyError(f"task session not found: {task_session_id}")
        if str(task.get("pack_id") or "") != pack_id:
            raise ValueError("verification pack does not match the task-bound pack")
        if str(task.get("state")) not in {"EXECUTE", "PREFLIGHT"}:
            raise ValueError("pack verification requires an EXECUTE or PREFLIGHT task")
        plan = self.task_store.latest_plan(task_session_id)
        if plan is None:
            raise ValueError("pack verification requires an active task plan")
        plan_id = str(plan["plan_id"])
        revisions = list(self.task_store.plan_revisions(plan_id))
        revision = revisions[-1] if revisions else None
        incomplete: list[str] = []
        if revision is None:
            incomplete.append("plan_revision_required")
        elif int(revision.get("revision", 0)) != int(plan.get("revision", 0)):
            incomplete.append("plan_revision_stale")
        if str(plan.get("metadata", {}).get("pack_id") or "") != pack_id:
            incomplete.append("plan_pack_binding_mismatch")
        passed = [
            str(item.get("name"))
            for item in self.task_store.verifications(task_session_id)
            if str(item.get("plan_id") or "") == plan_id
            and str(item.get("status") or "").casefold() in {"pass", "passed", "ok", "success"}
        ]
        assessment = assess_scope_documents(
            repo_root=self.repo_root,
            actual_paths=analyzed,
            retrieved_paths=sorted(context_paths),
            task_session_id=task_session_id,
            pack_id=pack_id,
            plan_id=plan_id,
            plan_revision_id=(str(revision.get("revision_id")) if revision else None),
            plan_revision_number=(int(revision.get("revision", 0)) if revision else None),
            plan_hash=(str(revision.get("plan_hash")) if revision else None),
            plan_document=dict((revision or plan).get("plan") or {}),
            validation=dict((revision or plan).get("validation") or {}),
            acceptance_checklist=required_contract_items(dict((revision or plan).get("plan") or {})),
            required_verifications=[str(item) for item in plan.get("required_verifications", [])],
            passed_verifications=passed,
            source_view={
                "snapshot_id": manifest.get("snapshot_id"),
                "generation_id": manifest.get("source_generation_id"),
                "fingerprint": manifest.get("source_index_fingerprint"),
            },
            diff=diff,
            incomplete_reasons=incomplete,
        )
        facade_violations = _facade_not_extended_violations(
            analyzed=analyzed,
            public_surface_included=public_surface_included,
        )
        violations = [*assessment["violations"], *facade_violations]
        response: dict[str, Any] = {
            "ok": bool(assessment["ok"]) and not facade_violations,
            "status": assessment["status"] if not facade_violations else "fail",
            "incomplete_reasons": assessment.get("incomplete_reasons", []),
            "remediation": _scope_remediation(assessment.get("incomplete_reasons", [])),
            "violations": violations,
            "scope_assessment": assessment,
            "impact_report": report,
            "pack_id": pack_id,
            "nextgen_v1": True,
        }
        report_hash = _stable_verification_report_hash(report)
        verification_id = (
            "verification_"
            + stable_id(
                verification_name,
                task_session_id,
                pack_id,
                plan_id,
                canonical_json(analyzed),
                hashlib.sha256((diff or "").encode("utf-8")).hexdigest(),
                report_hash,
            )[:32]
        )
        verification_payload: dict[str, Any] = {
            "name": verification_name,
            "pack_id": pack_id,
            "plan_id": plan_id,
            "status": "pass" if response["ok"] else "fail",
            "input_paths": normalized_input,
            "analyzed_paths": analyzed,
            "violations": violations,
            "report_hash": report_hash,
        }
        verification_payload["typed_evidence"] = build_verification_evidence(
            evidence_type="check_diff",
            task_session_id=task_session_id,
            pack_id=pack_id,
            plan_id=plan_id,
            plan_revision_id=str(assessment["plan_revision_id"] or ""),
            plan_revision_number=int(assessment["plan_revision_number"] or 0),
            scope_revision_id=str(assessment["scope_revision_id"] or ""),
            source_view=dict(assessment["source_view"]),
            diff_fingerprint=current_diff_fingerprint(self.repo_root),
            command="persistmind check-diff",
            result=str(verification_payload["status"]),
            artifact=report,
        )
        if self._read_only:
            response.update(
                {
                    "verification_id": verification_id,
                    "recorded": False,
                    "query_guarantee": "no-writer-resolution",
                }
            )
            return response
        self.task_store.append_verification(
            verification_id,
            task_session_id=task_session_id,
            payload=verification_payload,
            idempotency_key=f"task-verification:{verification_id}",
        )
        event = self.lifecycle.emit(
            "VerificationCompleted.v1",
            task_session_id,
            source_operation_key=f"verification:{verification_id}",
            payload={
                "verification_id": verification_id,
                "verification_name": verification_name,
                "pack_id": pack_id,
                "plan_id": plan_id,
                "status": verification_payload["status"],
                "report_hash": verification_payload["report_hash"],
            },
            producer="pack-service",
        )
        for attempt in range(3):
            snapshot = self.task_store.workflow_snapshot(task_session_id)
            snapshot_payload = {
                key: value
                for key, value in dict(snapshot or {}).items()
                if key not in {"task_session_id", "pack_id", "plan_id", "revision", "updated_at"}
            }
            snapshot_payload.update(
                {
                    "verification_id": verification_id,
                    "verification_name": verification_name,
                    "verification_status": verification_payload["status"],
                    "verification_report_hash": verification_payload["report_hash"],
                }
            )
            try:
                self.task_store.save_workflow_snapshot(
                    task_session_id,
                    payload=snapshot_payload,
                    pack_id=pack_id,
                    plan_id=plan_id,
                    expected_revision=(int(snapshot["revision"]) if snapshot is not None else 0),
                )
                break
            except TaskConflict:
                if attempt == 2:
                    raise
                time.sleep(0.01 * (attempt + 1))
        response.update(
            {
                "task_session_id": task_session_id,
                "plan_id": plan_id,
                "lifecycle_event_id": event["event_id"],
                "lifecycle_sequence": event["sequence"],
            }
        )
        return response

    def _bind_pack_to_task(
        self,
        pack_id: str,
        task_session_id: str | None,
        bound_task: Mapping[str, Any] | None,
    ) -> dict[str, Any] | None:
        if bound_task is None or not task_session_id:
            return None
        existing_pack = str(bound_task.get("pack_id") or "")
        if str(bound_task.get("state")) == "INTAKE":
            from .task_service import TaskService

            with TaskService(
                self.repo_root,
                allow_development_driver=self.activity._allow_development_driver,
            ) as tasks:
                transition = tasks.task_transition(
                    task_session_id,
                    "PACK",
                    actor="pack-service",
                    reason="context pack finalized",
                    pack_id=pack_id,
                )
            return {
                "lifecycle_event_id": transition["lifecycle_event_id"],
                "lifecycle_sequence": transition["lifecycle_sequence"],
            }
        if existing_pack != pack_id:
            raise ValueError("PACK task is already bound to a different context pack")
        event = next(
            (
                item
                for item in reversed(self.lifecycle.events(task_session_id))
                if item.get("event_type") == "PackBound.v1"
                and item.get("payload", {}).get("pack_id") == pack_id
            ),
            None,
        )
        if event is None:
            raise RuntimeError("task-bound pack is missing its lifecycle event")
        return {
            "lifecycle_event_id": event["event_id"],
            "lifecycle_sequence": event["sequence"],
        }

    def get_pack_manifest(self, pack_id: str) -> dict[str, Any]:
        event = self.activity.event(pack_id)
        if event is None or event.get("event_type") != "context_pack.finalized":
            return {"ok": False, "status": "not_found", "pack_id": pack_id}
        outer = event.get("payload")
        payload = outer.get("payload") if isinstance(outer, dict) else None
        if not isinstance(payload, dict):
            raise RuntimeError("invalid finalized pack event")
        manifest = payload.get("manifest")
        if isinstance(manifest, dict):
            return {
                "ok": True,
                **manifest,
                "created_at": event["occurred_at"],
                "nextgen_v1": True,
            }
        reference = str(payload.get("object_ref") or "")
        if not reference:
            raise RuntimeError("finalized pack has no manifest reference")
        value = json.loads(self.runtime.artifacts.get(reference))
        if not isinstance(value, dict) or value.get("pack_id") != pack_id:
            raise RuntimeError("finalized pack object identity mismatch")
        return {"ok": True, **value, "created_at": event["occurred_at"], "nextgen_v1": True}

    def reconstruct_pack(self, pack_id: str, task_text: str | None = None) -> dict[str, Any]:
        manifest = self.get_pack_manifest(pack_id)
        if not manifest.get("ok"):
            return manifest
        if task_text is not None and task_text != manifest.get("task"):
            raise ValueError("task text does not match finalized pack")
        immutable = {
            key: value for key, value in manifest.items() if key not in {"ok", "nextgen_v1"}
        }
        return {"ok": True, **immutable, "manifest": immutable, "nextgen_v1": True}


def _facade_not_extended_violations(
    *, analyzed: list[str], public_surface_included: set[str]
) -> list[dict[str, Any]]:
    analyzed_set = set(analyzed)
    violations: list[dict[str, Any]] = []
    for path in sorted(analyzed_set):
        if not path.endswith(".py") or path.endswith("__init__.py"):
            continue
        parent = str(Path(path).parent).replace("\\", "/")
        candidate = f"{parent}/__init__.py" if parent != "." else "__init__.py"
        if candidate in public_surface_included and candidate not in analyzed_set:
            violations.append(
                {
                    "kind": "facade_not_extended",
                    "path": path,
                    "facade_path": candidate,
                    "reason": "A public facade was included in the pack but not updated.",
                }
            )
    return violations


def _scope_remediation(reasons: Any) -> str | None:
    reason_set = {str(item) for item in reasons or []}
    if not reason_set:
        return None
    commands = {
        "task_session_required": "persistmind --repo . workflow start --task \"<task>\"",
        "approved_plan_required": "persistmind --repo . plan create --task-session-id <task> --pack-id <pack> --file plan.json",
        "plan_revision_required": "persistmind --repo . plan create --task-session-id <task> --pack-id <pack> --file plan.json",
        "plan_revision_stale": "persistmind --repo . plan create --task-session-id <task> --pack-id <pack> --file plan.json",
        "plan_pack_binding_mismatch": "persistmind --repo . workflow rebind --task-session-id <task> --pack-id <pack>",
        "pre_edit_impact_baseline_required": "persistmind --repo . plan create --task-session-id <task> --pack-id <pack> --file plan.json",
        "verified_source_generation_required": "persistmind --repo . index",
    }
    selected = [commands[reason] for reason in sorted(reason_set) if reason in commands]
    if not selected:
        return "Resolve the reported incomplete_reasons and rerun persistmind check-diff."
    return "Required before check-diff can pass: " + "; ".join(dict.fromkeys(selected))
