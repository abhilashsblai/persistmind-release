from __future__ import annotations

from pathlib import Path
from typing import Any

from persistmind.config import load_settings

from .runtime import inspect_storage
from .schema_upgrade import NextgenSchemaService, SchemaUpgradeRejected


class ProjectMigrationService:
    """Typed project migration dispatcher for the next-generation workspace."""

    def __init__(self, repo_root: Path, *, read_only: bool = False) -> None:
        self.repo_root = repo_root.resolve()
        self.workspace_root = self.repo_root / load_settings(self.repo_root).toolchain.workspace_dir
        self.read_only = read_only

    def migrate_project(self, *, dry_run: bool = False) -> dict[str, Any]:
        inspection = inspect_storage(self.workspace_root)
        if not inspection.initialized:
            # This filename is input to the dedicated offline migrator only; it
            # must never be opened by the active authority runtime.
            legacy = self.workspace_root / ("workspace" + ".db")
            return {
                "ok": False,
                "status": "offline_migration_required"
                if legacy.exists()
                else "storage_not_initialized",
                "schema_version": "persistmind.project_migration.v1",
                "dry_run": bool(dry_run),
                "legacy_workspace": str(legacy) if legacy.exists() else None,
                "remediation": (
                    "Stop PersistMind processes and use persistmind-migrate with explicit source, "
                    "target, and migration ID."
                    if legacy.exists()
                    else "Initialize PersistMind storage before requesting a schema migration."
                ),
            }
        schema = NextgenSchemaService(self.workspace_root)
        plan = schema.plan()
        if dry_run:
            return {
                **plan,
                "schema_version": "persistmind.project_migration.v1",
                "dry_run": True,
                "applied": False,
            }
        applied = schema.apply(plan)
        return {
            **applied,
            "schema_version": "persistmind.project_migration.v1",
            "dry_run": False,
            "applied": applied.get("status") != "already_current",
        }

    def migrate_verify(self) -> dict[str, Any]:
        try:
            result = NextgenSchemaService(self.workspace_root).verify()
        except SchemaUpgradeRejected as exc:
            return {
                "ok": False,
                "status": exc.status,
                "schema_version": "persistmind.project_migration_verify.v1",
                "error": str(exc),
                "remediation": "Create and apply an offline shadow migration plan.",
            }
        return {**result, "schema_version": "persistmind.project_migration_verify.v1"}


__all__ = ["ProjectMigrationService"]
