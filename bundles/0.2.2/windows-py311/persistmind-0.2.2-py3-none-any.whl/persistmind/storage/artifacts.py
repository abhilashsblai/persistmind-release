from __future__ import annotations

import hashlib
import json
import os
import secrets
import shutil
import time
from collections.abc import Callable, Iterable, Iterator, Mapping
from pathlib import Path
from typing import Any

from persistmind.security.encryption import volume_encryption_status
from persistmind.security.envelope import (
    EnvelopeAuthenticationFailed,
    WorkspaceKeyProvider,
    WrappedDataKey,
    decrypt_chunk,
    encrypt_chunk,
)


class ArtifactCorrupt(RuntimeError):
    pass


class ArtifactCapacityExceeded(ValueError):
    pass


_CLASSIFICATION_RANK = {
    "public": 0,
    "internal": 1,
    "confidential": 2,
    "secret": 3,
}
_CHUNK_BYTES = 8 * 1024 * 1024
_MAX_CHUNKS = 512
_MAX_OBJECT_BYTES = 4 * 1024 * 1024 * 1024


class ContentAddressedArtifacts:
    """Streaming content-addressed objects with staged publication and fenced GC."""

    def __init__(
        self,
        root: Path,
        *,
        authorize: Callable[[str, str], bool] | None = None,
        max_object_bytes: int = _MAX_OBJECT_BYTES,
        max_in_memory_bytes: int = 64 * 1024 * 1024,
        allow_test_key_provider: bool = False,
    ) -> None:
        self.root = root.resolve()
        self.quarantine = self.root / "quarantine"
        self._authorize = authorize or (lambda _reference, _action: True)
        self.max_object_bytes = min(max_object_bytes, _MAX_OBJECT_BYTES)
        self.max_in_memory_bytes = max_in_memory_bytes
        self.allow_test_key_provider = allow_test_key_provider
        self._keys = WorkspaceKeyProvider(
            self.root.parent, allow_test_provider=allow_test_key_provider
        )

    def put(self, payload: bytes, *, classification: str = "internal") -> str:
        if len(payload) > self.max_in_memory_bytes:
            raise ArtifactCapacityExceeded(
                "one-call payload exceeds in-memory limit; use put_stream"
            )
        return self.put_stream((payload,), classification=classification)

    def put_stream(
        self,
        payload: Iterable[bytes],
        *,
        classification: str = "internal",
        operation_id: str | None = None,
    ) -> str:
        if classification not in _CLASSIFICATION_RANK:
            raise ValueError(f"unsupported artifact classification: {classification}")
        operation_id = operation_id or f"op_{secrets.token_hex(16)}"
        staging = self.root / ".staging" / operation_id
        chunks_root = staging / "chunks"
        chunks_root.mkdir(parents=True, exist_ok=False)
        digest = hashlib.sha256()
        chunks: list[dict[str, Any]] = []
        size = 0
        pending = b""
        try:
            for source_chunk in payload:
                if not isinstance(source_chunk, bytes):
                    raise TypeError("artifact stream yielded non-bytes payload")
                pending += source_chunk
                while len(pending) >= _CHUNK_BYTES:
                    piece, pending = pending[:_CHUNK_BYTES], pending[_CHUNK_BYTES:]
                    size = self._write_chunk(chunks_root, chunks, digest, piece, size)
            if pending or not chunks:
                size = self._write_chunk(chunks_root, chunks, digest, pending, size)
            object_digest = digest.hexdigest()
            reference = f"sha256:{object_digest}"
            if not self._authorize(reference, "write"):
                raise PermissionError(reference)
            encryption: dict[str, object] | None = None
            if _CLASSIFICATION_RANK[classification] >= _CLASSIFICATION_RANK["confidential"]:
                if not self.allow_test_key_provider and not bool(
                    volume_encryption_status(self.root).get("verified")
                ):
                    raise PermissionError(
                        "confidential artifact staging requires a verified encrypted volume"
                    )
                encryption = self._encrypt_staged_chunks(
                    chunks_root,
                    chunks,
                    reference=reference,
                    classification=classification,
                )
            manifest: dict[str, Any] = {
                "chunks": chunks,
                "classification": classification,
                "encryption": encryption,
                "logical_bytes": size,
                "object_id": reference,
                "schema_version": "persistmind.object.v2",
            }
            self._write_json(staging / "manifest.json", manifest)
            self._verify_directory(staging, reference)
            target = self._directory(reference)
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                self._verify_directory(target, reference)
                self._ensure_classification_not_downgraded(target, classification)
                return reference
            os.replace(staging, target)
            self._fsync_directory(target.parent)
            return reference
        finally:
            if staging.exists():
                shutil.rmtree(staging, ignore_errors=True)

    def get(self, reference: str) -> bytes:
        manifest = self._manifest(reference, action="read")
        total = int(manifest["logical_bytes"])
        if total > self.max_in_memory_bytes:
            raise ArtifactCapacityExceeded(
                "object exceeds one-call in-memory limit; use iter_bytes"
            )
        return b"".join(self.iter_bytes(reference))

    def iter_bytes(self, reference: str) -> Iterator[bytes]:
        manifest = self._manifest(reference, action="read")
        directory = self._directory(reference)
        digest = hashlib.sha256()
        actual_size = 0
        try:
            for chunk in manifest["chunks"]:
                index = int(chunk["index"])
                path = directory / "chunks" / f"{index:06d}.bin"
                expected_size = int(chunk["plaintext_bytes"])
                expected_hash = str(chunk["plaintext_sha256"])
                with path.open("rb") as handle:
                    data = handle.read()
                encryption = manifest.get("encryption")
                if isinstance(encryption, dict):
                    data = self._decrypt_object_chunk(
                        reference,
                        manifest,
                        chunk,
                        data,
                    )
                if len(data) != expected_size or hashlib.sha256(data).hexdigest() != expected_hash:
                    raise ArtifactCorrupt(reference)
                actual_size += len(data)
                digest.update(data)
                yield data
        except (OSError, KeyError, ValueError, ArtifactCorrupt):
            self._quarantine(reference)
            raise ArtifactCorrupt(reference) from None
        if actual_size != int(manifest["logical_bytes"]) or digest.hexdigest() != self._digest(
            reference
        ):
            self._quarantine(reference)
            raise ArtifactCorrupt(reference)

    def verify(self, reference: str) -> bool:
        try:
            for _ in self.iter_bytes(reference):
                pass
        except (OSError, ArtifactCorrupt, PermissionError, ValueError):
            return False
        return True

    def mark(self, live_references: Iterable[str], *, operation_id: str | None = None) -> str:
        """Freeze a GC mark; sweeping must use a mark that survives a grace period."""

        operation_id = operation_id or f"op_{secrets.token_hex(16)}"
        digests = sorted({self._digest(reference) for reference in live_references})
        marker = self.root / "gc-marks" / f"{operation_id}.json"
        marker.parent.mkdir(parents=True, exist_ok=True)
        self._write_json(
            marker,
            {
                "created_monotonic_ns": time.monotonic_ns(),
                "digests": digests,
                "schema_version": "persistmind.object_gc_mark.v1",
            },
        )
        return operation_id

    def sweep(
        self,
        live_references: Iterable[str],
        *,
        grace_seconds: float = 3600,
        revalidate: Callable[[str], bool] | None = None,
    ) -> list[str]:
        """Delete only objects absent from an aged frozen mark and fresh revalidation."""

        current = {self._digest(reference) for reference in live_references}
        marker_id = self.mark(f"sha256:{item}" for item in current)
        del marker_id
        candidates = self._eligible_mark_digests(grace_seconds)
        deleted: list[str] = []
        for digest in sorted(candidates - current):
            reference = f"sha256:{digest}"
            if revalidate is not None and revalidate(reference):
                continue
            if not self._authorize(reference, "delete"):
                continue
            target = self._directory(reference)
            if target.exists():
                # A second manifest verification makes the deletion fence fail
                # closed if another publisher created a conflicting object.
                self._verify_directory(target, reference)
                shutil.rmtree(target)
                deleted.append(reference)
        return deleted

    def _write_chunk(
        self,
        chunks_root: Path,
        chunks: list[dict[str, Any]],
        digest: hashlib._Hash,
        piece: bytes,
        size: int,
    ) -> int:
        if len(chunks) >= _MAX_CHUNKS:
            raise ArtifactCapacityExceeded("artifact exceeds 512 chunk limit")
        if size + len(piece) > self.max_object_bytes:
            raise ArtifactCapacityExceeded("artifact exceeds logical byte limit")
        index = len(chunks)
        path = chunks_root / f"{index:06d}.bin"
        with path.open("xb") as handle:
            handle.write(piece)
            handle.flush()
            os.fsync(handle.fileno())
        piece_hash = hashlib.sha256(piece).hexdigest()
        chunks.append(
            {
                "index": index,
                "plaintext_bytes": len(piece),
                "plaintext_sha256": piece_hash,
                "stored_bytes": len(piece),
                "stored_sha256": piece_hash,
            }
        )
        digest.update(piece)
        return size + len(piece)

    def _manifest(self, reference: str, *, action: str) -> dict[str, Any]:
        if not self._authorize(reference, action):
            raise PermissionError(reference)
        path = self._directory(reference) / "manifest.json"
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ArtifactCorrupt(reference) from exc
        if (
            not isinstance(value, dict)
            or value.get("schema_version") not in {"persistmind.object.v1", "persistmind.object.v2"}
            or value.get("object_id") != reference
            or not isinstance(value.get("chunks"), list)
        ):
            raise ArtifactCorrupt(reference)
        return value

    def _verify_directory(self, directory: Path, reference: str) -> None:
        # Reuse the streaming verification logic without publishing it first.
        manifest_path = directory / "manifest.json"
        value = json.loads(manifest_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict) or value.get("object_id") != reference:
            raise ArtifactCorrupt(reference)
        digest = hashlib.sha256()
        total = 0
        for item in value.get("chunks", []):
            if not isinstance(item, dict):
                raise ArtifactCorrupt(reference)
            path = directory / "chunks" / f"{int(item['index']):06d}.bin"
            data = path.read_bytes()
            if isinstance(value.get("encryption"), dict):
                data = self._decrypt_object_chunk(reference, value, item, data)
            if hashlib.sha256(data).hexdigest() != item.get("plaintext_sha256"):
                raise ArtifactCorrupt(reference)
            digest.update(data)
            total += len(data)
        if digest.hexdigest() != self._digest(reference) or total != value.get("logical_bytes"):
            raise ArtifactCorrupt(reference)

    def _encrypt_staged_chunks(
        self,
        chunks_root: Path,
        chunks: list[dict[str, Any]],
        *,
        reference: str,
        classification: str,
    ) -> dict[str, Any]:
        dek, wrapped = self._keys.wrap_new_dek()
        count = len(chunks)
        for item in chunks:
            index = int(item["index"])
            path = chunks_root / f"{index:06d}.bin"
            plaintext = path.read_bytes()
            aad = self._object_aad(reference, classification, item, wrapped.key_id, count)
            ciphertext, metadata = encrypt_chunk(plaintext, dek=dek, aad_fields=aad)
            path.write_bytes(ciphertext)
            item.update(metadata)
            item["stored_bytes"] = len(ciphertext)
            item["stored_sha256"] = hashlib.sha256(ciphertext).hexdigest()
        return {
            "algorithm": "AES-256-GCM",
            "key_wrap": "RFC3394-AES-256-KW",
            "key_id": wrapped.key_id,
            "wrapping_key_id": wrapped.key_id,
            "wrapped_dek": wrapped.wrapped_dek,
        }

    def _decrypt_object_chunk(
        self,
        reference: str,
        manifest: dict[str, Any],
        item: dict[str, Any],
        ciphertext: bytes,
    ) -> bytes:
        encryption = manifest.get("encryption")
        if not isinstance(encryption, dict):
            return ciphertext
        try:
            wrapped = WrappedDataKey(
                key_id=str(encryption.get("wrapping_key_id") or encryption["key_id"]),
                wrapped_dek=str(encryption["wrapped_dek"]),
            )
            dek = self._keys.unwrap_dek(wrapped)
            chunks = manifest.get("chunks")
            count = len(chunks) if isinstance(chunks, list) else 0
            aad = self._object_aad(
                reference,
                str(manifest["classification"]),
                item,
                str(encryption["key_id"]),
                count,
            )
            return decrypt_chunk(
                ciphertext,
                dek=dek,
                nonce=str(item["nonce"]),
                aad_fields=aad,
                expected_aad_sha256=str(item["aad_sha256"]),
                expected_ciphertext_sha256=str(item["ciphertext_sha256"]),
            )
        except (KeyError, ValueError, EnvelopeAuthenticationFailed) as exc:
            raise ArtifactCorrupt(reference) from exc

    @staticmethod
    def _object_aad(
        reference: str,
        classification: str,
        item: Mapping[str, Any],
        key_id: str,
        chunk_count: int,
    ) -> dict[str, Any]:
        return {
            "contract": "persistmind.object.v2",
            "logical_id": reference,
            "classification": classification,
            "chunk_index": int(item["index"]),
            "chunk_count": chunk_count,
            "plaintext_bytes": int(item["plaintext_bytes"]),
            "plaintext_sha256": str(item["plaintext_sha256"]),
            "key_id": key_id,
        }

    def _ensure_classification_not_downgraded(self, directory: Path, requested: str) -> None:
        value = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
        current = str(value.get("classification", "internal"))
        if _CLASSIFICATION_RANK.get(requested, -1) < _CLASSIFICATION_RANK.get(current, -1):
            raise PermissionError("artifact classification cannot be downgraded")

    def _eligible_mark_digests(self, grace_seconds: float) -> set[str]:
        threshold = time.monotonic_ns() - int(max(0, grace_seconds) * 1_000_000_000)
        eligible: set[str] = set()
        marks = self.root / "gc-marks"
        if not marks.exists():
            return eligible
        for marker in marks.glob("*.json"):
            try:
                value = json.loads(marker.read_text(encoding="utf-8"))
                created = int(value["created_monotonic_ns"])
                digests = value["digests"]
            except (OSError, ValueError, KeyError, json.JSONDecodeError):
                continue
            if created <= threshold and isinstance(digests, list):
                eligible.update(
                    item for item in digests if isinstance(item, str) and re_full_hex(item)
                )
        return eligible

    def _quarantine(self, reference: str) -> None:
        source = self._directory(reference)
        self.quarantine.mkdir(parents=True, exist_ok=True)
        if source.exists():
            destination = self.quarantine / self._digest(reference)
            if destination.exists():
                shutil.rmtree(destination, ignore_errors=True)
            os.replace(source, destination)

    def _directory(self, reference: str) -> Path:
        digest = self._digest(reference)
        return self.root / "sha256" / digest[:2] / digest

    @staticmethod
    def _write_json(path: Path, value: Mapping[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
        try:
            with temporary.open("xb") as handle:
                handle.write(
                    json.dumps(
                        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
                    ).encode("utf-8")
                )
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)

    @staticmethod
    def _fsync_directory(path: Path) -> None:
        try:
            descriptor = os.open(path, os.O_RDONLY)
        except OSError:
            return
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

    @staticmethod
    def _digest(reference: str) -> str:
        algorithm, separator, digest = reference.partition(":")
        if algorithm != "sha256" or not separator or not re_full_hex(digest):
            raise ValueError("invalid artifact reference")
        return digest


def re_full_hex(value: str) -> bool:
    return len(value) == 64 and all(character in "0123456789abcdef" for character in value)
