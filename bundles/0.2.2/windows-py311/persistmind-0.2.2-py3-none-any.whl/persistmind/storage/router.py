from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence

from .descriptors import (
    PRIMARY_ROLE_BY_DOMAIN,
    ROLE_DOMAIN,
    ConsistencyWatermark,
    StorageDomain,
    StoreDescriptor,
    StoreRole,
    TopologyManifest,
)
from .interfaces import DomainStore, RoutePlan

_OPTIONAL_PARTITION_ROLES = frozenset(
    {StoreRole.SOURCE_SEGMENT, StoreRole.ACTIVITY_SEALED, StoreRole.AUDIT_SEALED}
)


class StaleReadError(RuntimeError):
    status = "storage_watermark_stale"

    def __init__(self, message: str, *, required: int, observed: int) -> None:
        self.required = required
        self.observed = observed
        super().__init__(message)


class CorruptAuthorityError(RuntimeError):
    status = "authority_quarantined"

    def __init__(self, role: StoreRole, diagnostics: Mapping[str, object]) -> None:
        self.role = role
        self.diagnostics = dict(diagnostics)
        super().__init__(
            f"authority is logically quarantined and cannot accept writes: {role.value}; "
            f"integrity={diagnostics.get('integrity', 'unavailable')}"
        )


class StorageRouter:
    """Resolve declared roles lazily without exposing paths or cross-store handles."""

    def __init__(
        self,
        topology: TopologyManifest,
        stores: Mapping[str, DomainStore | Callable[[], DomainStore]],
        *,
        allowed_roles: frozenset[StoreRole] | None = None,
        scope_by_role: Mapping[StoreRole, str] | None = None,
        read_only: bool = False,
    ) -> None:
        self.topology = topology
        self._providers = dict(stores)
        self._stores: dict[str, DomainStore] = {}
        self._allowed_roles = allowed_roles
        self._scope_by_role = dict(scope_by_role or {})
        self._read_only = read_only

    def resolve_write_store(self, role: StoreRole | str, scope: str | None = None) -> DomainStore:
        requested = StoreRole(role)
        self._require_allowed(requested)
        if self._read_only:
            raise PermissionError(
                f"read-only storage runtime cannot resolve a writer: {requested.value}"
            )
        candidates = [
            descriptor
            for descriptor in self._matching(requested, scope)
            if descriptor.state == "active" and not descriptor.read_only
        ]
        if len(candidates) != 1:
            raise RuntimeError(
                "write route must resolve exactly one active writable store: "
                f"role={requested.value} scope={scope!r} candidates="
                f"{[item.store_id for item in candidates]}"
            )
        store = self._store(candidates[0])
        try:
            integrity = store.verify_integrity(full=False)
        except Exception as exc:
            raise CorruptAuthorityError(
                requested, {"ok": False, "integrity": str(exc), "probe_failed": True}
            ) from exc
        if not integrity.get("ok"):
            raise CorruptAuthorityError(requested, integrity)
        return store

    def resolve_read_set(
        self,
        role: StoreRole | str,
        scope: str | None = None,
        *,
        watermark: object | None = None,
    ) -> Sequence[DomainStore]:
        """Return deterministic active/sealed read stores for one physical role.

        A supplied watermark is enforced before results are returned.  Routing
        never silently falls back to a writer or a stale topology.
        """

        requested = StoreRole(role)
        self._require_allowed(requested)
        if (
            requested in _OPTIONAL_PARTITION_ROLES
            and scope is None
            and requested not in self._scope_by_role
        ):
            return ()
        try:
            matches = self._matching(requested, scope)
        except KeyError:
            if requested in _OPTIONAL_PARTITION_ROLES:
                return ()
            raise
        descriptors = [item for item in matches if item.state in {"active", "ready", "sealed"}]
        descriptors.sort(
            key=lambda item: (
                0 if item.state == "active" else 1,
                -item.generation,
                item.partition_key,
                item.store_id,
            )
        )
        stores = tuple(self._store(item) for item in descriptors)
        if watermark is not None:
            self._enforce_watermark(requested, stores, watermark)
        return stores

    def resolve_domain_plan(
        self,
        domain: StorageDomain | str,
        operation: str,
        scope: str | None = None,
        *,
        watermark: object | None = None,
    ) -> RoutePlan:
        requested = StorageDomain(domain)
        roles = self._roles_for(requested, operation)
        stores: list[DomainStore] = []
        for role in roles:
            if operation in {"write", "append", "approve", "promote"}:
                stores.append(self.resolve_write_store(role, scope))
            else:
                stores.extend(self.resolve_read_set(role, scope, watermark=watermark))
        return RoutePlan(
            domain=requested,
            operation=operation,
            roles=tuple(roles),
            stores=tuple(stores),
            consistency=(
                "watermarked" if operation in {"pack", "reconstruct"} else "fail_if_stale"
            ),
        )

    def explain_route(
        self,
        role: StoreRole | str,
        *,
        mode: str,
        scope: str | None = None,
    ) -> Mapping[str, object]:
        """Plan a route without resolving a writer or opening a store."""

        requested = StoreRole(role)
        self._require_allowed(requested)
        if (
            requested in _OPTIONAL_PARTITION_ROLES
            and scope is None
            and requested not in self._scope_by_role
        ):
            descriptors = []
        else:
            try:
                descriptors = self._matching(requested, scope)
            except KeyError:
                if requested not in _OPTIONAL_PARTITION_ROLES:
                    raise
                descriptors = []
        normalized = mode.strip().lower()
        if normalized == "declared":
            selected = list(descriptors)
        elif normalized == "query":
            selected = [item for item in descriptors if item.state in {"active", "ready", "sealed"}]
        elif normalized == "command":
            selected = [
                item for item in descriptors if item.state == "active" and not item.read_only
            ]
        else:
            raise ValueError(f"unknown route mode: {mode}")
        return {
            "ok": (
                (
                    bool(selected)
                    or (
                        normalized in {"declared", "query"}
                        and requested in _OPTIONAL_PARTITION_ROLES
                    )
                )
                and (normalized in {"declared", "query"} or len(selected) == 1)
            ),
            "role": requested.value,
            "mode": normalized,
            "scope": scope or self._scope_by_role.get(requested),
            "stores": [item.store_id for item in selected],
            "not_materialized": not selected and requested in _OPTIONAL_PARTITION_ROLES,
            "writer_resolved": False,
        }

    def for_domain(self, domain: StorageDomain | str) -> DomainStore:
        """Return the domain's primary writer within the declared role scope."""

        requested = StorageDomain(domain)
        return self.resolve_write_store(PRIMARY_ROLE_BY_DOMAIN[requested])

    def control(self) -> DomainStore:
        return self.for_domain(StorageDomain.CONTROL)

    def source(self) -> DomainStore:
        return self.for_domain(StorageDomain.SOURCE)

    def task(self) -> DomainStore:
        return self.for_domain(StorageDomain.TASK)

    def activity(self) -> DomainStore:
        return self.for_domain(StorageDomain.ACTIVITY)

    def audit(self) -> DomainStore:
        return self.for_domain(StorageDomain.AUDIT)

    def knowledge(self) -> DomainStore:
        return self.for_domain(StorageDomain.KNOWLEDGE)

    def policy(self) -> DomainStore:
        return self.for_domain(StorageDomain.POLICY)

    def learning(self) -> DomainStore:
        return self.for_domain(StorageDomain.LEARNING)

    def close(self) -> None:
        seen: set[int] = set()
        for store in self._stores.values():
            if id(store) in seen:
                continue
            seen.add(id(store))
            close = getattr(store, "close", None)
            if callable(close):
                close()

    @property
    def stores(self) -> Mapping[str, DomainStore]:
        """Stores opened by this router; unopened roles remain unopened."""

        return dict(self._stores)

    def open_declared(self) -> Mapping[str, DomainStore]:
        """Explicit administrative operation that opens every permitted store."""

        for descriptor in self.topology.stores:
            if descriptor.state in {"active", "ready", "sealed"}:
                if self._allowed_roles is None or descriptor.store_role in self._allowed_roles:
                    self._store(descriptor)
        return self.stores

    def inspect_declared(
        self,
    ) -> tuple[Mapping[str, DomainStore], tuple[Mapping[str, object], ...]]:
        """Open each permitted store independently for fail-closed diagnostics."""

        failures: list[Mapping[str, object]] = []
        for descriptor in self.topology.stores:
            if descriptor.state not in {"active", "ready", "sealed"}:
                continue
            if self._allowed_roles is not None and descriptor.store_role not in self._allowed_roles:
                continue
            try:
                self._store(descriptor)
            except Exception as exc:  # noqa: BLE001 - preserve other authority results.
                failure: dict[str, object] = {
                    "store_id": descriptor.store_id,
                    "role": descriptor.store_role.value,
                    "location": descriptor.location,
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                }
                diagnostics = getattr(exc, "diagnostics", None)
                if callable(diagnostics):
                    failure["diagnostics"] = diagnostics()
                failures.append(failure)
        return self.stores, tuple(failures)

    def _matching(self, role: StoreRole, scope: str | None) -> list[StoreDescriptor]:
        effective_scope = scope or self._scope_by_role.get(role)
        if not effective_scope:
            raise PermissionError(f"storage route requires an authorization scope: {role.value}")
        expected_domain = ROLE_DOMAIN[role]
        matches = [
            item
            for item in self.topology.stores
            if item.store_role is role
            and (expected_domain is None or item.domain is expected_domain)
            and self._scope_matches(item.authorization_scope, effective_scope)
        ]
        if not matches:
            raise KeyError(f"no declared store for role: {role.value}")
        return matches

    @staticmethod
    def _scope_matches(declared: str, requested: str) -> bool:
        return declared in {"", "global", requested}

    def _enforce_watermark(
        self,
        role: StoreRole,
        stores: Sequence[DomainStore],
        watermark: object,
    ) -> None:
        if not isinstance(watermark, ConsistencyWatermark):
            raise TypeError("watermark must be a ConsistencyWatermark")
        if watermark.topology_generation != self.topology.generation:
            raise StaleReadError(
                "storage topology does not satisfy the requested watermark",
                required=watermark.topology_generation,
                observed=self.topology.generation,
            )
        domain = ROLE_DOMAIN[role]
        if domain is None:
            raise RuntimeError(f"storage role has no watermark domain: {role.value}")
        keys = (
            role.value,
            domain.value,
            *(store.descriptor.store_id for store in stores),
        )
        required = max(
            (int(watermark.revisions[key]) for key in keys if key in watermark.revisions), default=0
        )
        observed = max((store.revision() for store in stores), default=0)
        if observed < required:
            raise StaleReadError(
                f"storage read route is stale: role={role.value}",
                required=required,
                observed=observed,
            )

    def _store(self, descriptor: StoreDescriptor) -> DomainStore:
        existing = self._stores.get(descriptor.store_id)
        if existing is not None:
            return existing
        try:
            provider = self._providers[descriptor.store_id]
        except KeyError as exc:
            raise RuntimeError(f"store is declared but unavailable: {descriptor.store_id}") from exc
        store = provider() if callable(provider) else provider
        self._stores[descriptor.store_id] = store
        return store

    def require_role(self, role: StoreRole | str) -> None:
        """Assert that a dynamic store access was declared by the operation."""

        self._require_allowed(StoreRole(role))

    def _require_allowed(self, role: StoreRole) -> None:
        if self._allowed_roles is not None and role not in self._allowed_roles:
            raise PermissionError(f"store role was not declared by this service: {role.value}")

    @staticmethod
    def _roles_for(domain: StorageDomain, operation: str) -> tuple[StoreRole, ...]:
        normalized = operation.strip().lower()
        if domain is StorageDomain.CONTROL:
            return (StoreRole.CONTROL,)
        if domain is StorageDomain.SOURCE:
            return (
                (StoreRole.SOURCE_SEGMENT,)
                if normalized in {"segment", "rebuild", "seal"}
                else (StoreRole.SOURCE_MANIFEST,)
            )
        if domain is StorageDomain.ACTIVITY:
            return (
                (StoreRole.ACTIVITY_ACTIVE,)
                if normalized in {"write", "append", "seal"}
                else (StoreRole.ACTIVITY_ACTIVE, StoreRole.ACTIVITY_SEALED)
            )
        if domain is StorageDomain.AUDIT:
            return (
                (StoreRole.AUDIT_ACTIVE,)
                if normalized in {"write", "append", "anchor", "seal"}
                else (StoreRole.AUDIT_ACTIVE, StoreRole.AUDIT_SEALED)
            )
        return (PRIMARY_ROLE_BY_DOMAIN[domain],)
