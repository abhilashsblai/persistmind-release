from __future__ import annotations

import hashlib
import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Mapping

from .resources import required_event_consumers


@dataclass(frozen=True, slots=True)
class StorageEvent:
    event_id: str
    event_type: str
    aggregate_id: str
    sequence: int
    payload: Mapping[str, Any]
    required_consumers: tuple[str, ...] = ()


class EventLedger:
    """Transactional outbox with a frozen per-event completion electorate."""

    def __init__(self, connection: sqlite3.Connection) -> None:
        self.connection = connection

    def append(self, event: StorageEvent) -> None:
        encoded = json.dumps(event.payload, sort_keys=True, separators=(",", ":"))
        digest = hashlib.sha256(encoded.encode()).hexdigest()
        consumers = tuple(sorted(set(event.required_consumers)))
        registered = required_event_consumers(event.event_type, dict(event.payload))
        if registered is not None and consumers != registered:
            raise ValueError(
                f"event required consumer set differs from registry: {event.event_type} "
                f"expected={registered} actual={consumers}"
            )
        consumers_json = json.dumps(consumers, separators=(",", ":"))
        electorate_hash = hashlib.sha256(consumers_json.encode()).hexdigest()
        existing = self.connection.execute(
            "SELECT payload_hash,required_set_hash FROM storage_outbox WHERE event_id=?",
            (event.event_id,),
        ).fetchone()
        if existing is not None:
            if str(existing[0]) != digest or str(existing[1]) != electorate_hash:
                raise RuntimeError(f"event identity divergence: {event.event_id}")
            return
        self.connection.execute(
            "INSERT INTO storage_outbox VALUES(?,?,?,?,?,?,?,?,?,NULL)",
            (
                event.event_id,
                event.event_type,
                event.aggregate_id,
                event.sequence,
                encoded,
                digest,
                consumers_json,
                electorate_hash,
                _now(),
            ),
        )

    def pending(self, *, limit: int = 100, consumer: str | None = None) -> list[sqlite3.Row]:
        rows = list(
            self.connection.execute(
                "SELECT * FROM storage_outbox WHERE published_at IS NULL "
                "ORDER BY aggregate_id,sequence,created_at,event_id LIMIT ?",
                (max(1, min(limit, 1000)),),
            )
        )
        if consumer is None:
            return rows
        return [row for row in rows if not _required(row) or consumer in _required(row)]

    def receipt(
        self,
        event_id: str,
        consumer: str,
        handler_version: str,
        payload_hash: str,
    ) -> bool:
        existing = self.connection.execute(
            "SELECT handler_version,payload_hash FROM storage_inbox "
            "WHERE event_id=? AND consumer=?",
            (event_id, consumer),
        ).fetchone()
        if existing is not None:
            if str(existing[1]) != payload_hash:
                raise RuntimeError(f"event payload hash divergence: {event_id}/{consumer}")
            if str(existing[0]) == handler_version:
                return False
            self.connection.execute(
                "UPDATE storage_inbox SET handler_version=?,processed_at=? "
                "WHERE event_id=? AND consumer=?",
                (handler_version, _now(), event_id, consumer),
            )
            return True
        self.connection.execute(
            "INSERT INTO storage_inbox VALUES(?,?,?,?,?)",
            (event_id, consumer, handler_version, _now(), payload_hash),
        )
        return True

    def has_receipt(self, event_id: str, consumer: str, payload_hash: str) -> bool:
        existing = self.connection.execute(
            "SELECT payload_hash FROM storage_inbox WHERE event_id=? AND consumer=?",
            (event_id, consumer),
        ).fetchone()
        if existing is None:
            return False
        if str(existing[0]) != payload_hash:
            raise RuntimeError(f"event payload hash divergence: {event_id}/{consumer}")
        return True

    def publish_if_complete(self, event_id: str) -> bool:
        row = self.connection.execute(
            "SELECT required_consumers_json FROM storage_outbox WHERE event_id=?",
            (event_id,),
        ).fetchone()
        if row is None:
            raise KeyError(event_id)
        required = set(json.loads(str(row[0])))
        received = {
            str(item[0])
            for item in self.connection.execute(
                "SELECT consumer FROM storage_inbox WHERE event_id=?", (event_id,)
            )
        }
        if required and not required <= received:
            return False
        self.connection.execute(
            "UPDATE storage_outbox SET published_at=? WHERE event_id=?", (_now(), event_id)
        )
        return True

    def publish(self, event_id: str) -> None:
        """Compatibility alias that still honors the frozen consumer set."""

        self.publish_if_complete(event_id)

    def completion(self, event_id: str) -> dict[str, Any]:
        row = self.connection.execute(
            "SELECT required_consumers_json,required_set_hash,published_at "
            "FROM storage_outbox WHERE event_id=?",
            (event_id,),
        ).fetchone()
        if row is None:
            raise KeyError(event_id)
        required = set(json.loads(str(row[0])))
        received = {
            str(item[0])
            for item in self.connection.execute(
                "SELECT consumer FROM storage_inbox WHERE event_id=?", (event_id,)
            )
        }
        return {
            "event_id": event_id,
            "required_consumers": sorted(required),
            "required_set_hash": str(row[1]),
            "acknowledged_consumers": sorted(received),
            "missing_consumers": sorted(required - received),
            "complete": row[2] is not None,
        }

    def clear_dead_letter(self, event_id: str, consumer: str) -> None:
        self.connection.execute(
            "DELETE FROM storage_dead_letters WHERE event_id=? AND consumer=?",
            (event_id, consumer),
        )

    def dead_letter(self, event_id: str, consumer: str, error: str) -> None:
        self.connection.execute(
            "INSERT INTO storage_dead_letters VALUES(?,?,?,?,?) "
            "ON CONFLICT(event_id,consumer) DO UPDATE SET "
            "error=excluded.error,retries=storage_dead_letters.retries+1,updated_at=excluded.updated_at",
            (event_id, consumer, error[:2000], 1, _now()),
        )


def _required(row: Mapping[str, Any]) -> set[str]:
    try:
        return set(json.loads(str(row["required_consumers_json"])))
    except (KeyError, TypeError, json.JSONDecodeError):
        return set()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()
