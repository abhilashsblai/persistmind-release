from __future__ import annotations

from pathlib import Path
import os
import secrets
from typing import Any

from persistmind.config import load_settings

from .activity_service import ActivityService
from .knowledge_service import KnowledgeService
from .learning_service import LearningService
from .runtime import StorageOpenIntent, StorageRuntime
from .descriptors import StoreRole
from .adapters.sqlite_control import LeaseConflict, SQLiteControlStore
from .source_service import SourceService


class ConsistencyService:
    """Replay every implemented required-consumer projection through one runtime."""

    def __init__(self, repo_root: Path, *, allow_development_driver: bool = False) -> None:
        self.repo_root = repo_root.resolve()
        self.allow_development_driver = allow_development_driver
        settings = load_settings(self.repo_root)
        self.runtime = StorageRuntime.open(
            self.repo_root / settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=allow_development_driver,
            required_roles=frozenset(StoreRole),
        )
        self.activity = ActivityService(
            self.repo_root,
            allow_development_driver=allow_development_driver,
            runtime=self.runtime,
        )
        self.knowledge = KnowledgeService(
            self.repo_root,
            allow_development_driver=allow_development_driver,
            runtime=self.runtime,
        )
        self.learning = LearningService(
            self.repo_root,
            allow_development_driver=allow_development_driver,
            runtime=self.runtime,
        )
        self.source = SourceService(
            self.repo_root,
            allow_development_driver=allow_development_driver,
            runtime=self.runtime,
        )
        control = self.runtime.router.resolve_write_store(StoreRole.CONTROL)
        if not isinstance(control, SQLiteControlStore):
            raise RuntimeError("Control route is unavailable for reconciliation")
        self.control = control
        self.owner_id = f"reconciler:{os.getpid()}"
        self.owner_boot_id = secrets.token_hex(12)

    def close(self) -> None:
        self.runtime.close()

    def __enter__(self) -> "ConsistencyService":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def reconcile(self, *, limit: int = 100) -> dict[str, Any]:
        from .policy_reconciler import PolicyProjectionReconciler

        policy = PolicyProjectionReconciler(
            self.repo_root,
            allow_development_driver=self.allow_development_driver,
        )
        handlers = {
            "task_completed": self.activity.reconcile_outcomes,
            "policy_changed": policy.reconcile,
            "skill_activated": self.learning.reconcile_activation_events,
            "source_published": self.source.reconcile_publications,
        }
        domains: dict[str, dict[str, Any]] = {}
        for name, handler in handlers.items():
            try:
                domains[name] = self._run_claim(name, handler, limit=limit)
            except LeaseConflict as exc:
                domains[name] = {
                    "ok": False,
                    "status": "claim_unavailable",
                    "error": str(exc),
                    "scanned": 0,
                    "applied": 0,
                    "failed": 1,
                }
        return {
            "ok": all(item.get("ok") for item in domains.values()),
            "schema_version": "persistmind.storage_reconcile.v1",
            "domains": domains,
            "scanned": sum(int(item.get("scanned", 0)) for item in domains.values()),
            "applied": sum(int(item.get("applied", 0)) for item in domains.values()),
            "failed": sum(int(item.get("failed", 0)) for item in domains.values()),
            "nextgen_v1": True,
        }

    def _run_claim(self, name: str, handler: Any, *, limit: int) -> dict[str, Any]:
        claim = self.control.begin_reconciliation(
            name,
            owner_id=self.owner_id,
            owner_boot_id=self.owner_boot_id,
            payload={"consumer": name, "limit": limit},
        )
        try:
            result = dict(handler(limit=limit))
        except Exception as exc:
            result = {
                "ok": False,
                "status": "retryable_error",
                "error_type": type(exc).__name__,
                "error": str(exc),
                "scanned": 0,
                "applied": 0,
                "failed": 1,
            }
            self.control.finish_reconciliation(
                name,
                owner_nonce=str(claim["owner_nonce"]),
                fencing_token=int(claim["fencing_token"]),
                result=result,
                retryable=True,
            )
            return result
        self.control.finish_reconciliation(
            name,
            owner_nonce=str(claim["owner_nonce"]),
            fencing_token=int(claim["fencing_token"]),
            result=result,
            retryable=bool(result.get("failed")),
        )
        return result
