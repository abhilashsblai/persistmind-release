from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Mapping

from persistmind.application.execution_scope import OperationExecutionScope, bind_operation_scope
from persistmind.application.registry import OperationMode
from persistmind.config import load_settings
from persistmind.utils import canonical_json, utc_now

from .adapters.sqlite_learning import SQLiteLearningStore
from .descriptors import StoreRole
from .runtime import StorageOpenIntent, StorageRuntime, resolve_runtime_store


class TaskProjectionReconciler:
    CONSUMER_ID = "learning.task_dispatch.v1"

    def __init__(self, repo_root: Path, *, allow_development_driver: bool = False) -> None:
        self.repo_root = repo_root.resolve()
        self.workspace_root = self.repo_root / load_settings(self.repo_root).toolchain.workspace_dir
        self.allow_development_driver = allow_development_driver

    def apply_learning_dispatch(self, event: Mapping[str, Any]) -> dict[str, Any]:
        if str(event.get("event_type")) != "TaskDecisionObserved.v1":
            raise ValueError("Learning dispatch requires TaskDecisionObserved.v1")
        payload = dict(event.get("payload") or {})
        payload_hash = hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()
        expected_event_id = (
            "evt_"
            + hashlib.sha256(
                canonical_json(
                    [
                        str(event["schema_version"]),
                        str(event["aggregate_id"]),
                        int(event["sequence"]),
                        str(event["event_type"]),
                        payload_hash,
                    ]
                ).encode("utf-8")
            ).hexdigest()[:32]
        )
        if expected_event_id != str(event.get("event_id")):
            raise RuntimeError("Task projection event identity does not verify")
        scope = OperationExecutionScope(
            operation_id="task_learning_dispatch_projection",
            mode=OperationMode.COMMAND,
            roles=frozenset({StoreRole.LEARNING.value}),
            scope_policy="workspace",
        )
        with (
            bind_operation_scope(scope),
            StorageRuntime.open(
                self.workspace_root,
                intent=StorageOpenIntent.REQUIRE_INITIALIZED,
                allow_development_driver=self.allow_development_driver,
                required_roles=frozenset({StoreRole.LEARNING}),
            ) as runtime,
        ):
            store = resolve_runtime_store(runtime, StoreRole.LEARNING, read_only=False)
            if not isinstance(store, SQLiteLearningStore):
                raise RuntimeError("Learning projection route is unavailable")
            event_id = str(event["event_id"])
            with store._write_lock, store.connection:
                receipt = store.connection.execute(
                    "SELECT payload_hash FROM domain_consumer_receipts "
                    "WHERE consumer_id=? AND event_id=?",
                    (self.CONSUMER_ID, event_id),
                ).fetchone()
                if receipt is not None:
                    if str(receipt["payload_hash"]) != payload_hash:
                        raise RuntimeError("Task projection receipt payload hash differs")
                    return {"ok": True, "status": "duplicate", "event_id": event_id}
                store.connection.execute(
                    "UPDATE learning_action_proposals SET state='dispatched',task_command_id=?,"
                    "revision=revision+1,updated_at=? WHERE proposal_id=? AND state='approved'",
                    (
                        str(payload["task_session_id"]),
                        utc_now(),
                        str(payload["proposal_id"]),
                    ),
                )
                store.connection.execute(
                    "INSERT INTO domain_consumer_receipts VALUES(?,?,?,?,?,?)",
                    (self.CONSUMER_ID, event_id, payload_hash, "v1", "applied", utc_now()),
                )
                store.connection.execute(
                    "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
                )
        return {"ok": True, "status": "applied", "event_id": str(event["event_id"])}


__all__ = ["TaskProjectionReconciler"]
