from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from persistmind.config import load_settings
from persistmind.security.approvals import require_approval_signature

from .adapters.sqlite_activity import SQLiteActivityStore, SQLiteAuditStore
from .adapters.sqlite_task import SQLiteTaskStore
from .descriptors import StoreRole
from .runtime import StorageOpenIntent, StorageRuntime


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _after(milliseconds: int) -> str:
    return (
        (datetime.now(timezone.utc) + timedelta(milliseconds=milliseconds))
        .isoformat()
        .replace("+00:00", "Z")
    )


def _json(value: Mapping[str, Any] | None) -> str:
    return json.dumps(dict(value or {}), sort_keys=True, separators=(",", ":"), default=str)


def _decode(value: str | None) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


class AgentRuntimeTaskPort:
    def __init__(self, store: SQLiteTaskStore) -> None:
        self.store = store

    def runtime_epoch(self) -> Mapping[str, Any]:
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT OR IGNORE INTO agent_runtime_epoch VALUES(1,1,2,'unknown',?)", (_now(),)
            )
            row = self.store.connection.execute(
                "SELECT epoch,protocol_version,engine_version,activated_at FROM agent_runtime_epoch WHERE singleton=1"
            ).fetchone()
        if row is None:
            raise RuntimeError("agent runtime epoch initialization failed")
        return dict(row)

    def activate_epoch(self, protocol_version: int, engine_version: str) -> Mapping[str, Any]:
        if protocol_version < 1 or not engine_version:
            raise ValueError("runtime epoch requires protocol and engine version")
        with self.store._write_lock, self.store.connection:
            current = self.runtime_epoch()
            epoch = int(current["epoch"]) + 1
            self.store.connection.execute(
                "UPDATE agent_runtime_epoch SET epoch=?,protocol_version=?,engine_version=?,activated_at=? WHERE singleton=1",
                (epoch, protocol_version, engine_version, _now()),
            )
            self.store.connection.execute(
                "UPDATE agent_runtime_jobs SET state='stale_epoch',updated_at=? WHERE state IN ('pending','claimed') AND runtime_epoch<>?",
                (_now(), epoch),
            )
        return self.runtime_epoch()

    def put_protocol_migration(self, migration: Mapping[str, Any]) -> Mapping[str, Any]:
        required = {
            "migration_id",
            "from_version",
            "to_version",
            "backup_id",
            "engine_version",
            "plan_digest",
        }
        if required - migration.keys():
            raise ValueError(f"protocol migration missing {sorted(required - migration.keys())}")
        now = _now()
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT OR REPLACE INTO project_protocol_migrations("
                "migration_id,from_version,to_version,from_epoch,to_epoch,state,backup_id,"
                "engine_version,plan_digest,started_at,activated_at,completed_at,error_text) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    str(migration["migration_id"]),
                    int(migration["from_version"]),
                    int(migration["to_version"]),
                    int(migration.get("from_epoch", 1)),
                    int(migration.get("to_epoch", 2)),
                    str(migration.get("state", "prepared")),
                    str(migration["backup_id"]),
                    str(migration["engine_version"]),
                    str(migration["plan_digest"]),
                    str(migration.get("started_at") or now),
                    migration.get("activated_at"),
                    migration.get("completed_at"),
                    migration.get("error_text"),
                ),
            )
            row = self.store.connection.execute(
                "SELECT * FROM project_protocol_migrations WHERE migration_id=?",
                (str(migration["migration_id"]),),
            ).fetchone()
        if row is None:
            raise RuntimeError("protocol migration persistence failed")
        return dict(row)

    def update_protocol_migration(
        self, migration_id: str, *, state: str, error: str | None = None
    ) -> Mapping[str, Any]:
        if state not in {"prepared", "activated", "complete", "failed", "rolled_back"}:
            raise ValueError("invalid protocol migration state")
        now = _now()
        activated_at = now if state in {"activated", "complete"} else None
        completed_at = now if state in {"complete", "failed", "rolled_back"} else None
        with self.store._write_lock, self.store.connection:
            cursor = self.store.connection.execute(
                "UPDATE project_protocol_migrations SET state=?,"
                "activated_at=COALESCE(activated_at,?),completed_at=COALESCE(completed_at,?),"
                "error_text=? WHERE migration_id=?",
                (state, activated_at, completed_at, error[:4000] if error else None, migration_id),
            )
            if cursor.rowcount != 1:
                raise KeyError(f"unknown protocol migration: {migration_id}")
            row = self.store.connection.execute(
                "SELECT * FROM project_protocol_migrations WHERE migration_id=?", (migration_id,)
            ).fetchone()
        if row is None:
            raise RuntimeError("protocol migration update disappeared")
        return dict(row)

    def enqueue_job(self, job: Mapping[str, Any]) -> Mapping[str, Any]:
        required = {
            "job_id",
            "job_kind",
            "repository_id",
            "workspace_id",
            "source_view_id",
            "payload_digest",
        }
        if required - job.keys():
            raise ValueError(f"runtime job missing {sorted(required - job.keys())}")
        now = _now()
        epoch = int(job.get("runtime_epoch") or self.runtime_epoch()["epoch"])
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT OR IGNORE INTO agent_runtime_jobs("
                "job_id,job_kind,repository_id,workspace_id,source_view_id,payload_json,payload_digest,"
                "state,priority,attempt_count,max_attempts,available_at,runtime_epoch,created_at,updated_at) "
                "VALUES(?,?,?,?,?,?,?,'pending',?,0,?,?,?,?,?)",
                (
                    str(job["job_id"]),
                    str(job["job_kind"]),
                    str(job["repository_id"]),
                    str(job["workspace_id"]),
                    str(job["source_view_id"]),
                    _json(job.get("payload")),
                    str(job["payload_digest"]),
                    int(job.get("priority", 0)),
                    int(job.get("max_attempts", 3)),
                    str(job.get("available_at") or now),
                    epoch,
                    now,
                    now,
                ),
            )
        rows = [item for item in self.jobs(limit=1000) if item["job_id"] == str(job["job_id"])]
        if not rows:
            raise RuntimeError("runtime job enqueue did not produce a durable record")
        return rows[0]

    def claim_jobs(
        self, *, worker_id: str, claim_token_hash: str, limit: int, lease_ms: int
    ) -> Sequence[Mapping[str, Any]]:
        limit = max(1, min(int(limit), 64))
        lease_ms = max(1000, min(int(lease_ms), 30000))
        now = _now()
        epoch = int(self.runtime_epoch()["epoch"])
        claimed: list[str] = []
        with self.store._write_lock, self.store.connection:
            rows = self.store.connection.execute(
                "SELECT job_id FROM agent_runtime_jobs WHERE runtime_epoch=? AND "
                "((state='pending' AND available_at<=?) OR (state='claimed' AND claim_expires_at<=?)) "
                "ORDER BY priority DESC,created_at,job_id LIMIT ?",
                (epoch, now, now, limit),
            ).fetchall()
            for row in rows:
                job_id = str(row[0])
                cursor = self.store.connection.execute(
                    "UPDATE agent_runtime_jobs SET state='claimed',claimed_by=?,claim_token_hash=?,"
                    "claim_expires_at=?,fencing_token=fencing_token+1,attempt_count=attempt_count+1,updated_at=? "
                    "WHERE job_id=? AND runtime_epoch=? AND "
                    "((state='pending' AND available_at<=?) OR (state='claimed' AND claim_expires_at<=?))",
                    (worker_id, claim_token_hash, _after(lease_ms), now, job_id, epoch, now, now),
                )
                if cursor.rowcount == 1:
                    claimed.append(job_id)
        return [item for item in self.jobs(limit=1000) if item["job_id"] in claimed]

    def renew_job(
        self,
        job_id: str,
        *,
        worker_id: str,
        claim_token_hash: str,
        fencing_token: int,
        lease_ms: int,
    ) -> Mapping[str, Any]:
        with self.store._write_lock, self.store.connection:
            cursor = self.store.connection.execute(
                "UPDATE agent_runtime_jobs SET claim_expires_at=?,updated_at=? WHERE job_id=? AND "
                "state='claimed' AND claimed_by=? AND claim_token_hash=? AND fencing_token=?",
                (
                    _after(max(1000, min(lease_ms, 30000))),
                    _now(),
                    job_id,
                    worker_id,
                    claim_token_hash,
                    fencing_token,
                ),
            )
        if cursor.rowcount != 1:
            raise PermissionError("runtime job lease fence rejected")
        return self._job(job_id)

    def finish_job(
        self,
        job_id: str,
        *,
        worker_id: str,
        claim_token_hash: str,
        fencing_token: int,
        state: str,
        result: Mapping[str, Any] | None = None,
        error: str | None = None,
    ) -> Mapping[str, Any]:
        if state not in {"completed", "failed", "cancelled", "pending"}:
            raise ValueError("invalid terminal runtime job state")
        completed = _now() if state in {"completed", "failed", "cancelled"} else None
        with self.store._write_lock, self.store.connection:
            cursor = self.store.connection.execute(
                "UPDATE agent_runtime_jobs SET state=?,result_json=?,error_text=?,claimed_by=NULL,"
                "claim_token_hash=NULL,claim_expires_at=NULL,completed_at=?,updated_at=? WHERE job_id=? "
                "AND state='claimed' AND claimed_by=? AND claim_token_hash=? AND fencing_token=?",
                (
                    state,
                    _json(result) if result is not None else None,
                    (error or "")[:4000] or None,
                    completed,
                    _now(),
                    job_id,
                    worker_id,
                    claim_token_hash,
                    fencing_token,
                ),
            )
        if cursor.rowcount != 1:
            raise PermissionError("runtime job completion fence rejected")
        return self._job(job_id)

    def cancel_job(self, job_id: str) -> Mapping[str, Any]:
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "UPDATE agent_runtime_jobs SET state='cancelled',completed_at=?,updated_at=? "
                "WHERE job_id=? AND state IN ('pending','claimed')",
                (_now(), _now(), job_id),
            )
        return self._job(job_id)

    def jobs(self, *, state: str | None = None, limit: int = 100) -> Sequence[Mapping[str, Any]]:
        where = " WHERE state=?" if state else ""
        values: tuple[Any, ...] = (
            (state, max(1, min(limit, 1000))) if state else (max(1, min(limit, 1000)),)
        )
        rows = self.store.connection.execute(
            "SELECT * FROM agent_runtime_jobs" + where + " ORDER BY created_at DESC,job_id LIMIT ?",
            values,
        ).fetchall()
        return [self._job_row(row) for row in rows]

    def put_grant(self, grant: Mapping[str, Any]) -> Mapping[str, Any]:
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT INTO execution_grants VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    grant["grant_id"],
                    grant["secret_hash"],
                    grant["repository_id"],
                    grant["workspace_id"],
                    grant["source_view_id"],
                    grant["workflow_id"],
                    grant["principal_id"],
                    json.dumps(grant["actions"], sort_keys=True),
                    json.dumps(grant["path_scopes"], sort_keys=True),
                    json.dumps(grant["process_scopes"], sort_keys=True),
                    json.dumps(grant["network_scopes"], sort_keys=True),
                    grant["max_uses"],
                    0,
                    grant["not_before"],
                    grant["expires_at"],
                    grant["runtime_epoch"],
                    "active",
                    grant["created_at"],
                    None,
                ),
            )
        return self.grant(str(grant["grant_id"])) or {}

    def grant(self, grant_id: str) -> Mapping[str, Any] | None:
        row = self.store.connection.execute(
            "SELECT * FROM execution_grants WHERE grant_id=?", (grant_id,)
        ).fetchone()
        if row is None:
            return None
        value = dict(row)
        for key in (
            "actions_json",
            "path_scopes_json",
            "process_scopes_json",
            "network_scopes_json",
        ):
            value[key.removesuffix("_json")] = json.loads(value.pop(key))
        return value

    def consume_grant(self, grant_id: str, *, expected_uses: int) -> bool:
        with self.store._write_lock, self.store.connection:
            cursor = self.store.connection.execute(
                "UPDATE execution_grants SET use_count=use_count+1 WHERE grant_id=? AND status='active' "
                "AND use_count=? AND use_count<max_uses",
                (grant_id, expected_uses),
            )
        return cursor.rowcount == 1

    def revoke_grant(self, grant_id: str) -> bool:
        with self.store._write_lock, self.store.connection:
            cursor = self.store.connection.execute(
                "UPDATE execution_grants SET status='revoked',revoked_at=? WHERE grant_id=? AND status='active'",
                (_now(), grant_id),
            )
        return cursor.rowcount == 1

    def put_external_run(self, run: Mapping[str, Any]) -> Mapping[str, Any]:
        now = _now()
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT OR IGNORE INTO external_agent_runs(run_id,orchestration_id,adapter_id,"
                "adapter_version,worktree_lease_id,execution_grant_id,model_route_id,state,"
                "session_reference,replay_cursor,process_id,result_digest,created_at,updated_at) "
                "VALUES(?,?,?,?,?,?,?,?,?,0,?,?,?,?)",
                (
                    run["run_id"],
                    run["orchestration_id"],
                    run["adapter_id"],
                    run["adapter_version"],
                    run["worktree_lease_id"],
                    run["execution_grant_id"],
                    run.get("model_route_id"),
                    run.get("state", "prepared"),
                    run.get("session_reference"),
                    run.get("process_id"),
                    run.get("result_digest"),
                    now,
                    now,
                ),
            )
        return self.external_run(str(run["run_id"])) or {}

    def external_run(self, run_id: str) -> Mapping[str, Any] | None:
        row = self.store.connection.execute(
            "SELECT * FROM external_agent_runs WHERE run_id=?", (run_id,)
        ).fetchone()
        return dict(row) if row is not None else None

    def external_runs(self, *, limit: int = 100) -> Sequence[Mapping[str, Any]]:
        rows = self.store.connection.execute(
            "SELECT * FROM external_agent_runs ORDER BY created_at DESC,run_id LIMIT ?",
            (max(1, min(int(limit), 1000)),),
        ).fetchall()
        return [dict(row) for row in rows]

    def update_external_run(
        self, run_id: str, *, state: str, values: Mapping[str, Any]
    ) -> Mapping[str, Any]:
        allowed = {"session_reference", "replay_cursor", "process_id", "result_digest"}
        selected = {key: values[key] for key in allowed if key in values}
        assignments = ["state=?", "updated_at=?", *[f"{key}=?" for key in sorted(selected)]]
        parameters: list[Any] = [
            state,
            _now(),
            *[selected[key] for key in sorted(selected)],
            run_id,
        ]
        with self.store._write_lock, self.store.connection:
            cursor = self.store.connection.execute(
                "UPDATE external_agent_runs SET " + ",".join(assignments) + " WHERE run_id=?",
                parameters,
            )
        if cursor.rowcount != 1:
            raise KeyError(f"unknown external agent run: {run_id}")
        return self.external_run(run_id) or {}

    def put_acp_session(self, session: Mapping[str, Any]) -> Mapping[str, Any]:
        now = _now()
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT OR IGNORE INTO acp_sessions(connection_id,orchestration_id,"
                "worktree_lease_id,execution_grant_id,agent_command_digest,protocol_version,"
                "capabilities_json,state,session_reference,replay_cursor,result_digest,created_at,updated_at) "
                "VALUES(?,?,?,?,?,?,?,?,?,0,?,?,?)",
                (
                    session["connection_id"],
                    session["orchestration_id"],
                    session["worktree_lease_id"],
                    session["execution_grant_id"],
                    session["agent_command_digest"],
                    session["protocol_version"],
                    _json(session.get("capabilities")),
                    session.get("state", "initializing"),
                    session.get("session_reference"),
                    session.get("result_digest"),
                    now,
                    now,
                ),
            )
        return self.acp_session(str(session["connection_id"])) or {}

    def acp_session(self, connection_id: str) -> Mapping[str, Any] | None:
        row = self.store.connection.execute(
            "SELECT * FROM acp_sessions WHERE connection_id=?", (connection_id,)
        ).fetchone()
        if row is None:
            return None
        value = dict(row)
        value["capabilities"] = _decode(value.pop("capabilities_json"))
        return value

    def acp_sessions(self, *, limit: int = 100) -> Sequence[Mapping[str, Any]]:
        rows = self.store.connection.execute(
            "SELECT * FROM acp_sessions ORDER BY created_at DESC,connection_id LIMIT ?",
            (max(1, min(int(limit), 1000)),),
        ).fetchall()
        values = []
        for row in rows:
            value = dict(row)
            value["capabilities"] = _decode(value.pop("capabilities_json"))
            values.append(value)
        return values

    def update_acp_session(
        self, connection_id: str, *, state: str, values: Mapping[str, Any]
    ) -> Mapping[str, Any]:
        allowed = {"session_reference", "replay_cursor", "result_digest", "protocol_version"}
        selected = {key: values[key] for key in allowed if key in values}
        assignments = ["state=?", "updated_at=?", *[f"{key}=?" for key in sorted(selected)]]
        parameters: list[Any] = [
            state,
            _now(),
            *[selected[key] for key in sorted(selected)],
            connection_id,
        ]
        with self.store._write_lock, self.store.connection:
            cursor = self.store.connection.execute(
                "UPDATE acp_sessions SET " + ",".join(assignments) + " WHERE connection_id=?",
                parameters,
            )
        if cursor.rowcount != 1:
            raise KeyError(f"unknown ACP connection: {connection_id}")
        return self.acp_session(connection_id) or {}

    def put_acp_terminal(self, terminal: Mapping[str, Any]) -> Mapping[str, Any]:
        now = _now()
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT INTO acp_terminals(terminal_id,connection_id,command_digest,worktree_lease_id,"
                "execution_grant_id,state,output_bytes,created_at,updated_at) VALUES(?,?,?,?,?,?,0,?,?)",
                (
                    terminal["terminal_id"],
                    terminal["connection_id"],
                    terminal["command_digest"],
                    terminal["worktree_lease_id"],
                    terminal["execution_grant_id"],
                    terminal.get("state", "created"),
                    now,
                    now,
                ),
            )
        row = self.store.connection.execute(
            "SELECT * FROM acp_terminals WHERE terminal_id=?", (terminal["terminal_id"],)
        ).fetchone()
        return dict(row) if row is not None else {}

    def update_acp_terminal(
        self, terminal_id: str, *, state: str, output_bytes: int
    ) -> Mapping[str, Any]:
        with self.store._write_lock, self.store.connection:
            cursor = self.store.connection.execute(
                "UPDATE acp_terminals SET state=?,output_bytes=?,updated_at=? WHERE terminal_id=?",
                (state, max(0, min(int(output_bytes), 1048576)), _now(), terminal_id),
            )
        if cursor.rowcount != 1:
            raise KeyError(f"unknown ACP terminal: {terminal_id}")
        row = self.store.connection.execute(
            "SELECT * FROM acp_terminals WHERE terminal_id=?", (terminal_id,)
        ).fetchone()
        return dict(row) if row is not None else {}

    def put_worktree_lease(self, lease: Mapping[str, Any]) -> Mapping[str, Any]:
        now = _now()
        with self.store._write_lock, self.store.connection:
            for row in self.store.connection.execute(
                "SELECT lease_id,metadata_json FROM worktree_leases WHERE state='active'"
            ).fetchall():
                metadata = _decode(row["metadata_json"])
                if metadata.get("path") == (lease.get("metadata") or {}).get("path"):
                    raise RuntimeError(f"writable worktree is already leased by {row['lease_id']}")
            self.store.connection.execute(
                "INSERT INTO worktree_leases(lease_id,repository_id,workspace_id,"
                "source_view_id,owner_session_id,pinned_oid,mode,state,runtime_epoch,expires_at,"
                "metadata_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    lease["lease_id"],
                    lease["repository_id"],
                    lease["workspace_id"],
                    lease["source_view_id"],
                    lease["owner_session_id"],
                    lease["pinned_oid"],
                    lease["mode"],
                    lease.get("state", "active"),
                    lease["runtime_epoch"],
                    lease["expires_at"],
                    _json(lease.get("metadata")),
                    lease.get("created_at", now),
                    now,
                ),
            )
        row = self.store.connection.execute(
            "SELECT * FROM worktree_leases WHERE lease_id=?", (lease["lease_id"],)
        ).fetchone()
        return dict(row) if row is not None else {}

    def worktree_lease(self, lease_id: str) -> Mapping[str, Any] | None:
        row = self.store.connection.execute(
            "SELECT * FROM worktree_leases WHERE lease_id=?", (lease_id,)
        ).fetchone()
        if row is None:
            return None
        value = dict(row)
        value["metadata"] = _decode(value.pop("metadata_json"))
        return value

    def worktree_leases(self, *, limit: int = 100) -> Sequence[Mapping[str, Any]]:
        rows = self.store.connection.execute(
            "SELECT * FROM worktree_leases ORDER BY created_at DESC,lease_id LIMIT ?",
            (max(1, min(int(limit), 1000)),),
        ).fetchall()
        values = []
        for row in rows:
            value = dict(row)
            value["metadata"] = _decode(value.pop("metadata_json"))
            values.append(value)
        return values

    def renew_worktree_lease(
        self,
        lease_id: str,
        *,
        owner_token_hash: str,
        fencing_token: int,
        expires_at: str,
    ) -> Mapping[str, Any]:
        with self.store._write_lock, self.store.connection:
            row = self.store.connection.execute(
                "SELECT metadata_json FROM worktree_leases WHERE lease_id=? AND state='active'",
                (lease_id,),
            ).fetchone()
            if row is None:
                raise RuntimeError("worktree lease is not active")
            metadata = _decode(row["metadata_json"])
            if metadata.get("owner_token_hash") != owner_token_hash or int(
                metadata.get("fencing_token", -1)
            ) != int(fencing_token):
                raise PermissionError("worktree lease owner fence rejected renewal")
            cursor = self.store.connection.execute(
                "UPDATE worktree_leases SET expires_at=?,updated_at=? WHERE lease_id=? AND state='active'",
                (expires_at, _now(), lease_id),
            )
        if cursor.rowcount != 1:
            raise RuntimeError("worktree lease renewal lost its active-state fence")
        return self.worktree_lease(lease_id) or {}

    def update_worktree_lease(
        self,
        lease_id: str,
        *,
        state: str,
        owner_token_hash: str | None = None,
        fencing_token: int | None = None,
    ) -> Mapping[str, Any]:
        with self.store._write_lock, self.store.connection:
            row = self.store.connection.execute(
                "SELECT metadata_json,state FROM worktree_leases WHERE lease_id=?", (lease_id,)
            ).fetchone()
            if row is None:
                raise KeyError(f"unknown worktree lease: {lease_id}")
            if owner_token_hash is not None or fencing_token is not None:
                metadata = _decode(row["metadata_json"])
                if metadata.get("owner_token_hash") != owner_token_hash or int(
                    metadata.get("fencing_token", -1)
                ) != int(fencing_token if fencing_token is not None else -1):
                    raise PermissionError("worktree lease owner fence rejected update")
            cursor = self.store.connection.execute(
                "UPDATE worktree_leases SET state=?,updated_at=? WHERE lease_id=?",
                (state, _now(), lease_id),
            )
        if cursor.rowcount != 1:
            raise KeyError(f"unknown worktree lease: {lease_id}")
        row = self.store.connection.execute(
            "SELECT * FROM worktree_leases WHERE lease_id=?", (lease_id,)
        ).fetchone()
        return dict(row) if row is not None else {}

    def put_model_route_evidence(self, evidence: Mapping[str, Any]) -> Mapping[str, Any]:
        now = _now()
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT OR REPLACE INTO model_route_evidence VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    evidence["route_evidence_id"],
                    evidence["orchestration_id"],
                    evidence["catalog_version"],
                    evidence["policy_revision"],
                    evidence["candidate_digest"],
                    evidence.get("selected_route_id"),
                    evidence.get("fallback_reason"),
                    _json(evidence.get("evidence")),
                    now,
                ),
            )
        row = self.store.connection.execute(
            "SELECT * FROM model_route_evidence WHERE route_evidence_id=?",
            (evidence["route_evidence_id"],),
        ).fetchone()
        return dict(row) if row is not None else {}

    def put_runtime_process(self, process: Mapping[str, Any]) -> Mapping[str, Any]:
        owner_kind = str(process["owner_kind"])
        owner_id = str(process["owner_id"])
        now = _now()
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT INTO runtime_process_registry(owner_kind,owner_id,process_id,started_at,state,updated_at) "
                "VALUES(?,?,?,?,?,?) ON CONFLICT(owner_kind,owner_id) DO UPDATE SET "
                "process_id=excluded.process_id,started_at=excluded.started_at,state=excluded.state,"
                "updated_at=excluded.updated_at",
                (
                    owner_kind,
                    owner_id,
                    int(process["process_id"]),
                    str(process.get("started_at") or now),
                    str(process.get("state") or "running"),
                    now,
                ),
            )
        return self.runtime_process(owner_kind, owner_id) or {}

    def runtime_process(self, owner_kind: str, owner_id: str) -> Mapping[str, Any] | None:
        row = self.store.connection.execute(
            "SELECT * FROM runtime_process_registry WHERE owner_kind=? AND owner_id=?",
            (owner_kind, owner_id),
        ).fetchone()
        return dict(row) if row is not None else None

    def clear_runtime_process(self, owner_kind: str, owner_id: str) -> bool:
        with self.store._write_lock, self.store.connection:
            cursor = self.store.connection.execute(
                "DELETE FROM runtime_process_registry WHERE owner_kind=? AND owner_id=?",
                (owner_kind, owner_id),
            )
        return cursor.rowcount == 1

    def _job(self, job_id: str) -> Mapping[str, Any]:
        row = self.store.connection.execute(
            "SELECT * FROM agent_runtime_jobs WHERE job_id=?", (job_id,)
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown runtime job: {job_id}")
        return self._job_row(row)

    @staticmethod
    def _job_row(row: Any) -> dict[str, Any]:
        value = dict(row)
        value["payload"] = _decode(value.pop("payload_json"))
        value["result"] = _decode(value.pop("result_json")) if value.get("result_json") else None
        value.pop("result_json", None)
        return value


class AgentRuntimeActivityPort:
    def __init__(self, store: SQLiteActivityStore) -> None:
        self.store = store

    def append_agent_event(self, event: Mapping[str, Any]) -> Mapping[str, Any]:
        payload = _json(event.get("payload"))
        if len(payload.encode("utf-8")) > 131072:
            raise ValueError("agent event exceeds 128 KiB payload limit")
        stream = str(event["stream_id"])
        now = _now()
        with self.store._write_lock, self.store.connection:
            existing = self.store.connection.execute(
                "SELECT * FROM agent_event_journal WHERE event_id=?", (event["event_id"],)
            ).fetchone()
            if existing is not None:
                if str(existing["payload_digest"]) != str(event["payload_digest"]):
                    raise ValueError("agent event identity payload divergence")
                return self._event_row(existing)
            self.store.connection.execute(
                "INSERT OR IGNORE INTO agent_event_streams VALUES(?,1,?)", (stream, now)
            )
            sequence_row = self.store.connection.execute(
                "SELECT next_sequence FROM agent_event_streams WHERE stream_id=?", (stream,)
            ).fetchone()
            if sequence_row is None:
                raise RuntimeError("agent event stream initialization failed")
            sequence = int(sequence_row[0])
            self.store.connection.execute(
                "UPDATE agent_event_streams SET next_sequence=next_sequence+1,updated_at=? WHERE stream_id=?",
                (now, stream),
            )
            self.store.connection.execute(
                "INSERT INTO agent_event_journal(event_id,stream_id,sequence,event_type,session_id,"
                "parent_event_id,payload_json,payload_digest,redaction_revision,occurred_at,committed_at) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (
                    event["event_id"],
                    stream,
                    sequence,
                    event["event_type"],
                    event.get("session_id"),
                    event.get("parent_event_id"),
                    payload,
                    event["payload_digest"],
                    event["redaction_revision"],
                    event["occurred_at"],
                    now,
                ),
            )
        return self.agent_event(str(event["event_id"])) or {}

    def agent_event(self, event_id: str) -> Mapping[str, Any] | None:
        row = self.store.connection.execute(
            "SELECT * FROM agent_event_journal WHERE event_id=?", (event_id,)
        ).fetchone()
        return self._event_row(row) if row is not None else None

    def agent_events(
        self, *, stream_id: str | None = None, state: str | None = None, limit: int = 100
    ) -> Sequence[Mapping[str, Any]]:
        clauses: list[str] = []
        values: list[Any] = []
        if stream_id:
            clauses.append("stream_id=?")
            values.append(stream_id)
        if state:
            clauses.append("delivery_state=?")
            values.append(state)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        values.append(max(1, min(limit, 1000)))
        rows = self.store.connection.execute(
            "SELECT * FROM agent_event_journal" + where + " ORDER BY stream_id,sequence LIMIT ?",
            values,
        ).fetchall()
        return [self._event_row(row) for row in rows]

    def claim_agent_events(
        self, *, worker_id: str, limit: int, lease_ms: int
    ) -> Sequence[Mapping[str, Any]]:
        now = _now()
        ids: list[str] = []
        with self.store._write_lock, self.store.connection:
            rows = self.store.connection.execute(
                "SELECT event_id FROM agent_event_journal WHERE "
                "(delivery_state='pending' AND (next_attempt_at IS NULL OR next_attempt_at<=?)) OR "
                "(delivery_state='claimed' AND claim_expires_at<=?) ORDER BY stream_id,sequence LIMIT ?",
                (now, now, max(1, min(limit, 1000))),
            ).fetchall()
            for row in rows:
                event_id = str(row[0])
                cursor = self.store.connection.execute(
                    "UPDATE agent_event_journal SET delivery_state='claimed',claimed_by=?,claim_expires_at=?,"
                    "attempt_count=attempt_count+1 WHERE event_id=? AND ((delivery_state='pending' AND "
                    "(next_attempt_at IS NULL OR next_attempt_at<=?)) OR (delivery_state='claimed' AND claim_expires_at<=?))",
                    (worker_id, _after(max(1000, min(lease_ms, 30000))), event_id, now, now),
                )
                if cursor.rowcount == 1:
                    ids.append(event_id)
        return [event for event in self.agent_events(limit=1000) if event["event_id"] in ids]

    def complete_agent_event(self, event_id: str, *, worker_id: str) -> bool:
        with self.store._write_lock, self.store.connection:
            cursor = self.store.connection.execute(
                "UPDATE agent_event_journal SET delivery_state='complete',claimed_by=NULL,claim_expires_at=NULL "
                "WHERE event_id=? AND delivery_state='claimed' AND claimed_by=?",
                (event_id, worker_id),
            )
        return cursor.rowcount == 1

    def fail_agent_event(
        self,
        event_id: str,
        *,
        worker_id: str,
        error: str,
        retry_at: str | None,
        dead_letter: bool,
    ) -> bool:
        target = "dead_letter" if dead_letter else "pending"
        now = _now()
        with self.store._write_lock, self.store.connection:
            row = self.store.connection.execute(
                "SELECT * FROM agent_event_journal WHERE event_id=? AND delivery_state='claimed' AND claimed_by=?",
                (event_id, worker_id),
            ).fetchone()
            if row is None:
                return False
            self.store.connection.execute(
                "UPDATE agent_event_journal SET delivery_state=?,next_attempt_at=?,claimed_by=NULL,"
                "claim_expires_at=NULL,last_error=? WHERE event_id=?",
                (target, retry_at, error[:4000], event_id),
            )
            if dead_letter:
                self.store.connection.execute(
                    "INSERT OR REPLACE INTO agent_event_dead_letters VALUES(?,?,?,?,?,?,?,?)",
                    (
                        event_id,
                        row["stream_id"],
                        row["sequence"],
                        row["payload_digest"],
                        error[:4000],
                        row["attempt_count"],
                        now,
                        (datetime.now(timezone.utc) + timedelta(days=90))
                        .isoformat()
                        .replace("+00:00", "Z"),
                    ),
                )
        return True

    def dead_letters(self, *, limit: int = 100) -> Sequence[Mapping[str, Any]]:
        return [
            dict(row)
            for row in self.store.connection.execute(
                "SELECT * FROM agent_event_dead_letters ORDER BY created_at DESC,event_id LIMIT ?",
                (max(1, min(limit, 1000)),),
            ).fetchall()
        ]

    def requeue_dead_letters(
        self, *, event_ids: Sequence[str] = (), limit: int = 100
    ) -> Sequence[str]:
        bounded = max(1, min(int(limit), 1000))
        selected = [str(item) for item in event_ids if item]
        with self.store._write_lock, self.store.connection:
            if selected:
                placeholders = ",".join("?" for _ in selected[:bounded])
                rows = self.store.connection.execute(
                    f"SELECT event_id FROM agent_event_dead_letters WHERE event_id IN ({placeholders}) LIMIT ?",
                    (*selected[:bounded], bounded),
                ).fetchall()
            else:
                rows = self.store.connection.execute(
                    "SELECT event_id FROM agent_event_dead_letters ORDER BY created_at,event_id LIMIT ?",
                    (bounded,),
                ).fetchall()
            ids = [str(row[0]) for row in rows]
            for event_id in ids:
                cursor = self.store.connection.execute(
                    "UPDATE agent_event_journal SET delivery_state='pending',attempt_count=0,"
                    "next_attempt_at=NULL,claimed_by=NULL,claim_expires_at=NULL,last_error=NULL "
                    "WHERE event_id=? AND delivery_state='dead_letter'",
                    (event_id,),
                )
                if cursor.rowcount == 1:
                    self.store.connection.execute(
                        "DELETE FROM agent_event_dead_letters WHERE event_id=?", (event_id,)
                    )
        return ids

    def unsettled_agent_event_count(self) -> int:
        row = self.store.connection.execute(
            "SELECT COUNT(*) FROM agent_event_journal WHERE delivery_state IN ('pending','claimed')"
        ).fetchone()
        return int(row[0]) if row is not None else 0

    @staticmethod
    def _event_row(row: Any) -> dict[str, Any]:
        value = dict(row)
        value["payload"] = _decode(value.pop("payload_json"))
        return value


class AgentRuntimeAuditPort:
    def __init__(self, store: SQLiteAuditStore) -> None:
        self.store = store

    def append_agent_security_projection(
        self, record: Mapping[str, Any], *, idempotency_key: str
    ) -> str:
        return self.store.append_audit(record, idempotency_key=idempotency_key)


class PolicyPluginTrustPort:
    """Expose plugin trust as signed Policy decisions, never generic Policy writes."""

    def __init__(
        self,
        store: Any,
        workspace_root: Path,
        *,
        allow_development_driver: bool,
    ) -> None:
        self.store = store
        self.workspace_root = workspace_root
        self.allow_development_driver = allow_development_driver

    def get(self, record_id: str) -> Mapping[str, Any] | None:
        record = self.store.policy(record_id)
        if record is None or record.get("decision_type") != "plugin_trust":
            return None
        state = str(record.get("status") or "")
        return {
            **record,
            "status": "trusted" if state == "active" else "revoked",
        }

    def put(self, record: Mapping[str, Any], *, idempotency_key: str | None = None) -> str:
        del idempotency_key
        payload = dict(record)
        approval = payload.pop("_approval", None)
        if not isinstance(approval, Mapping):
            raise PermissionError("plugin trust mutation requires a signed Policy approval")
        actor = str(approval.get("actor") or "").strip()
        if actor != str(payload.get("principal") or ""):
            raise PermissionError("plugin trust signer must match the authorized OS principal")
        signature = str(approval.get("signature") or "")
        document = approval.get("document")
        if not isinstance(document, Mapping):
            raise PermissionError("plugin trust approval requires the full decision document")
        expected = {
            "schema_version": "persistmind.policy_decision_document.v1",
            "action": "plugin_trust" if payload.get("status") == "trusted" else "plugin_revoke",
            "plugin_id": str(payload["plugin_id"]),
            "root": str(payload["root"]),
            "manifest_digest": str(payload["manifest_digest"]),
            "version": str(payload["version"]),
            "capabilities": sorted(str(item) for item in payload.get("capabilities") or []),
            "execution_closure_digest": str(payload["execution_closure_digest"]),
            "actor": actor,
            "reason": str(payload.get("reason") or "verified plugin trust activation"),
        }
        if dict(document) != expected:
            raise PermissionError("plugin trust approval document does not match the exact action")
        identity = require_approval_signature(
            self.workspace_root,
            signature,
            expected,
            expected_principal=actor,
            allow_test_provider=self.allow_development_driver,
        )
        policy_id = str(payload["record_id"])
        existing = self.store.policy(policy_id)
        if payload.get("status") == "trusted":
            policy = {
                **payload,
                "policy_id": policy_id,
                "decision_type": "plugin_trust",
                "scope": "plugin:" + str(payload["plugin_id"]),
                "priority": 90,
            }
            self.store.approve_policy(
                policy,
                approver=actor,
                signature=signature,
                signer_identity=identity,
                decision_document=expected,
            )
        else:
            if existing is None:
                raise KeyError(f"unknown plugin trust decision: {policy_id}")
            self.store.set_policy_status(
                policy_id,
                status="suspended",
                actor=actor,
                reason=str(payload.get("reason") or "operator revoked"),
                signature=signature,
                signer_identity=identity,
                decision_document=expected,
            )
        return policy_id


class AgentRuntimePorts:
    def __init__(
        self,
        repo_root: Path,
        *,
        allow_development_driver: bool = False,
        require_protocol_v2: bool = True,
    ) -> None:
        root = Path(repo_root).resolve()
        settings = load_settings(root)
        from persistmind.agent_runtime.protocol import require_nextgen_protocol_v2
        from persistmind.branding import resolve_project_state

        if require_protocol_v2:
            require_nextgen_protocol_v2(resolve_project_state(root))
        self.runtime = StorageRuntime.open(
            root / settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=allow_development_driver,
            required_roles=frozenset(
                {
                    StoreRole.TASK_STATE,
                    StoreRole.ACTIVITY_ACTIVE,
                    StoreRole.AUDIT_ACTIVE,
                    StoreRole.POLICY,
                }
            ),
        )
        task = self.runtime.router.resolve_write_store(StoreRole.TASK_STATE)
        activity = self.runtime.router.resolve_write_store(StoreRole.ACTIVITY_ACTIVE)
        audit = self.runtime.router.resolve_write_store(StoreRole.AUDIT_ACTIVE)
        policy = self.runtime.router.resolve_write_store(StoreRole.POLICY)
        if (
            not isinstance(task, SQLiteTaskStore)
            or not isinstance(activity, SQLiteActivityStore)
            or not isinstance(audit, SQLiteAuditStore)
        ):
            self.runtime.close()
            raise RuntimeError("agent runtime role routing is unavailable")
        self.task = AgentRuntimeTaskPort(task)
        self.activity = AgentRuntimeActivityPort(activity)
        self.audit = AgentRuntimeAuditPort(audit)
        self.plugin_trust = PolicyPluginTrustPort(
            policy,
            self.runtime.root,
            allow_development_driver=allow_development_driver,
        )

    def close(self) -> None:
        self.runtime.close()

    def __enter__(self) -> "AgentRuntimePorts":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


__all__ = [
    "AgentRuntimeActivityPort",
    "AgentRuntimeAuditPort",
    "AgentRuntimePorts",
    "AgentRuntimeTaskPort",
    "PolicyPluginTrustPort",
]
