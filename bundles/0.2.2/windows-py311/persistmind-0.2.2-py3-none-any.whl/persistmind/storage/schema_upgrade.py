from __future__ import annotations

import hashlib
import json
import time
from dataclasses import replace
from pathlib import Path
from pathlib import PurePosixPath
from typing import Any, Mapping, cast

from .bootstrap import validate_nextgen_manifest
from .catalog import FileCatalog
from .descriptors import StoreRole, TopologyManifest
from .adapters.apsw_driver import copy_nextgen_database, open_nextgen_connection
from .adapters.sqlite_base import schema_resource_hash, schema_upgrade_resources
from .adapters.sqlite_control import SQLiteControlStore
from .resources import read_bytes, sha256
from .runtime import StorageNotInitialized, inspect_storage
from .workspace_lock import WorkspaceRuntimeLock


TARGET_HEADS = {
    StoreRole.CONTROL: 1,
    StoreRole.SOURCE_MANIFEST: 4,
    StoreRole.SOURCE_SEGMENT: 1,
    StoreRole.TASK_STATE: 8,
    StoreRole.ACTIVITY_ACTIVE: 4,
    StoreRole.ACTIVITY_SEALED: 4,
    StoreRole.AUDIT_ACTIVE: 3,
    StoreRole.AUDIT_SEALED: 3,
    StoreRole.KNOWLEDGE: 4,
    StoreRole.POLICY: 4,
    StoreRole.LEARNING: 4,
}


class SchemaUpgradeRejected(RuntimeError):
    status = "schema_upgrade_rejected"


class NextgenSchemaService:
    """Prepare, verify, and atomically publish additive authority schema heads."""

    def __init__(self, workspace_root: Path) -> None:
        self.root = workspace_root.resolve()
        self.catalog = FileCatalog(self.root / "catalog")

    def plan(self) -> dict[str, Any]:
        topology = self._topology()
        steps = []
        for descriptor in topology.stores:
            target = TARGET_HEADS[descriptor.store_role]
            if descriptor.schema_head != target:
                if descriptor.schema_head > target:
                    raise SchemaUpgradeRejected(
                        f"schema downgrade is forbidden for {descriptor.store_role.value}: "
                        f"{descriptor.schema_head} -> {target}"
                    )
                resources = [
                    {
                        "version": version,
                        "resource": resource,
                        "sha256": sha256(resource),
                    }
                    for version, resource in schema_upgrade_resources(
                        descriptor.store_role, descriptor.schema_head, target
                    )
                ]
                steps.append(
                    {
                        "store_id": descriptor.store_id,
                        "role": descriptor.store_role.value,
                        "from_head": descriptor.schema_head,
                        "to_head": target,
                        "source_location": descriptor.location,
                        "target_location": _shadow_location(
                            descriptor.location,
                            generation=topology.generation + 1,
                            schema_head=target,
                        ),
                        "target_resource_hash": schema_resource_hash(descriptor.store_role, target),
                        "resources": resources,
                        "mode": "prepare_copy_verify_atomic_pointer_switch",
                    }
                )
        plan_identity = {
            "from_generation": topology.generation,
            "to_generation": topology.generation + (1 if steps else 0),
            "steps": steps,
        }
        payload = json.dumps(plan_identity, sort_keys=True, separators=(",", ":"))
        return {
            "ok": not steps,
            "status": "current" if not steps else "schema_upgrade_ready",
            "schema_version": "persistmind.schema_plan.v2",
            "topology_generation": topology.generation,
            "target_topology_generation": topology.generation + (1 if steps else 0),
            "steps": steps,
            "plan_hash": hashlib.sha256(payload.encode()).hexdigest(),
        }

    def apply(
        self,
        plan: Mapping[str, Any],
        *,
        allow_development_driver: bool = False,
    ) -> dict[str, Any]:
        supplied_identity = {
            "from_generation": int(plan.get("topology_generation", -1)),
            "to_generation": int(plan.get("target_topology_generation", -1)),
            "steps": list(plan.get("steps") or ()),
        }
        supplied_hash = hashlib.sha256(
            json.dumps(supplied_identity, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        if str(plan.get("plan_hash")) != supplied_hash:
            raise SchemaUpgradeRejected("schema plan hash mismatch")
        current = self.plan()
        if str(plan.get("plan_hash")) != current["plan_hash"]:
            raise SchemaUpgradeRejected("schema plan changed before application")
        topology = self._topology()
        if not current["steps"]:
            return {
                **current,
                "ok": True,
                "status": "already_current",
                "from_generation": topology.generation,
                "generation": topology.generation,
                "upgraded": [],
            }

        prepared: list[Path] = []
        published = False
        with WorkspaceRuntimeLock(self.root, exclusive=True):
            # Re-read after acquiring the maintenance fence. A runtime may have
            # published a generation between plan validation and lock acquisition.
            locked = self.plan()
            if locked["plan_hash"] != current["plan_hash"]:
                raise SchemaUpgradeRejected("schema plan changed while acquiring maintenance")
            topology = self._topology()
            descriptors = {item.store_id: item for item in topology.stores}
            replacements = {}
            try:
                for step in locked["steps"]:
                    descriptor = descriptors[str(step["store_id"])]
                    target = self.catalog.resolve_location(str(step["target_location"]))
                    if target.exists() or _sqlite_companions(target):
                        raise SchemaUpgradeRejected(
                            f"prepared schema target already exists: {target}"
                        )
                    target.parent.mkdir(parents=True, exist_ok=True)
                    self._prepare_shadow(
                        descriptor=descriptor,
                        step=step,
                        target=target,
                        generation=topology.generation + 1,
                        allow_development_driver=allow_development_driver,
                    )
                    prepared.append(target)
                    replacements[descriptor.store_id] = replace(
                        descriptor,
                        location=str(step["target_location"]),
                        schema_head=int(step["to_head"]),
                        generation=topology.generation + 1,
                        resource_hash=str(step["target_resource_hash"]),
                    )

                target_topology = TopologyManifest(
                    topology_id=topology.topology_id,
                    generation=topology.generation + 1,
                    profile=topology.profile,
                    stores=tuple(replacements.get(item.store_id, item) for item in topology.stores),
                    workspace_id=topology.workspace_id,
                    contract_hash=topology.contract_hash,
                    created_at=_now(),
                    schema_version=topology.schema_version,
                )
                validate_nextgen_manifest(target_topology)
                self._publish(
                    topology,
                    target_topology,
                    allow_development_driver=allow_development_driver,
                )
                published = True
            finally:
                if not published:
                    for target in prepared:
                        _remove_prepared_image(target)

        return {
            **locked,
            "ok": True,
            "status": "upgraded",
            "from_generation": topology.generation,
            "generation": topology.generation + 1,
            "upgraded": [str(step["role"]) for step in locked["steps"]],
        }

    def verify(self) -> dict[str, Any]:
        plan = self.plan()
        if plan["steps"]:
            raise SchemaUpgradeRejected("authority schema heads are not current")
        return {**plan, "ok": True, "status": "verified"}

    def _topology(self):
        inspection = inspect_storage(self.root)
        if not inspection.initialized or inspection.topology is None:
            raise StorageNotInitialized("PersistMind storage is not initialized")
        validate_nextgen_manifest(inspection.topology)
        return inspection.topology

    def _prepare_shadow(
        self,
        *,
        descriptor: Any,
        step: Mapping[str, Any],
        target: Path,
        generation: int,
        allow_development_driver: bool,
    ) -> None:
        source = self.catalog.resolve_location(str(step["source_location"]))
        source_connection = open_nextgen_connection(
            source,
            read_only=True,
            allow_development_driver=allow_development_driver,
        )
        try:
            copy_nextgen_database(
                source_connection,
                target,
                allow_development_driver=allow_development_driver,
            )
        finally:
            source_connection.close()

        connection = open_nextgen_connection(
            target,
            allow_development_driver=allow_development_driver,
        )
        try:
            statements = ["BEGIN IMMEDIATE;"]
            for resource in step["resources"]:
                resource_name = str(resource["resource"])
                expected = str(resource["sha256"])
                if sha256(resource_name) != expected:
                    raise SchemaUpgradeRejected(
                        f"schema resource changed after planning: {resource_name}"
                    )
                statements.append(read_bytes(resource_name).decode("utf-8"))
                statements.append(
                    "INSERT INTO domain_schema_migrations(version,resource,checksum,applied_at) "
                    f"VALUES({int(resource['version'])},{_sql(resource_name)},"
                    f"{_sql(expected)},{_sql(_now())});"
                )
            statements.extend(
                [
                    "UPDATE domain_metadata SET "
                    f"schema_head={int(step['to_head'])},generation={generation},"
                    f"resource_hash={_sql(str(step['target_resource_hash']))} "
                    "WHERE singleton=1;",
                    f"PRAGMA user_version={int(step['to_head'])};",
                    "COMMIT;",
                ]
            )
            connection.executescript("\n".join(statements))
            integrity = [str(row[0]) for row in connection.execute("PRAGMA quick_check").fetchall()]
            foreign_keys = connection.execute("PRAGMA foreign_key_check").fetchall()
            metadata = connection.execute(
                "SELECT store_id,schema_head,generation,resource_hash "
                "FROM domain_metadata WHERE singleton=1"
            ).fetchone()
            if integrity != ["ok"] or foreign_keys:
                raise SchemaUpgradeRejected(
                    f"prepared schema image failed integrity verification: {descriptor.store_id}"
                )
            expected_metadata = (
                descriptor.store_id,
                int(step["to_head"]),
                generation,
                str(step["target_resource_hash"]),
            )
            if metadata is None or tuple(metadata) != expected_metadata:
                raise SchemaUpgradeRejected(
                    f"prepared schema image identity mismatch: {descriptor.store_id}"
                )
            for resource in step["resources"]:
                row = connection.execute(
                    "SELECT resource,checksum FROM domain_schema_migrations WHERE version=?",
                    (int(resource["version"]),),
                ).fetchone()
                if row is None or tuple(row) != (
                    str(resource["resource"]),
                    str(resource["sha256"]),
                ):
                    raise SchemaUpgradeRejected(
                        f"prepared schema migration receipt mismatch: {descriptor.store_id}"
                    )
        finally:
            connection.close()

    def _publish(
        self,
        current: TopologyManifest,
        target: TopologyManifest,
        *,
        allow_development_driver: bool,
    ) -> None:
        control_descriptor = next(
            item for item in current.stores if item.store_role is StoreRole.CONTROL
        )
        with SQLiteControlStore(
            self.catalog.resolve_location(control_descriptor.location),
            descriptor=control_descriptor,
            allow_development_driver=allow_development_driver,
        ) as control:
            control_store = cast(SQLiteControlStore, control)
            control_store.stage_topology(target.to_dict())
            self.catalog.activate(target, expected_generation=current.generation)
            published = self.catalog.current()
            control_store.activate_topology(published.generation)


def _shadow_location(location: str, *, generation: int, schema_head: int) -> str:
    path = PurePosixPath(location)
    filename = f"{path.stem}.catalog-g{generation}.h{schema_head}{path.suffix}"
    return str(path.with_name(filename))


def _sql(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _sqlite_companions(path: Path) -> tuple[Path, ...]:
    return tuple(
        item for item in (Path(str(path) + "-wal"), Path(str(path) + "-shm")) if item.exists()
    )


def _remove_prepared_image(path: Path) -> None:
    for item in (Path(str(path) + "-wal"), Path(str(path) + "-shm"), path):
        item.unlink(missing_ok=True)
