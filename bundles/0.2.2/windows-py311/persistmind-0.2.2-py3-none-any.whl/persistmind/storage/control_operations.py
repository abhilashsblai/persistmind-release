from __future__ import annotations

import hashlib
import json
import subprocess
import time
from collections.abc import Mapping
from pathlib import Path
from types import SimpleNamespace
from typing import Any

from persistmind.ci.annotations import github_annotations, gitlab_annotations
from persistmind.ci.policy import deleted_paths_from_diff, paths_from_diff
from persistmind.config import load_settings
from persistmind.git_hooks import install_git_hooks
from persistmind.governance.policy import CapabilityPolicy
from persistmind.registry import ProjectRegistry
from persistmind.release.completion import (
    load_gap_register,
    validate_gap_register,
    write_default_gap_register,
)
from persistmind.release.validation import ReleaseValidator
from persistmind.runtime_invocation import runtime_invocation
from persistmind.utils import canonical_json, stable_id, utc_now

from .adapters.sqlite_base import _scalar
from .adapters.sqlite_control import SQLiteControlStore
from .control import StorageControlPlane
from .descriptors import StoreRole
from .runtime import StorageOpenIntent, StorageRuntime, resolve_runtime_store


class ControlOperations:
    """Control-owned operational coordination with no retired product-store dependency."""

    def __init__(self, repo_root: Path, *, read_only: bool = False) -> None:
        self.repo_root = repo_root.resolve()
        settings = load_settings(self.repo_root)
        self.runtime = StorageRuntime.open(
            self.repo_root / settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            read_only=read_only,
            required_roles=frozenset({StoreRole.CONTROL}),
        )
        store = resolve_runtime_store(self.runtime, StoreRole.CONTROL, read_only=read_only)
        if not isinstance(store, SQLiteControlStore):
            raise RuntimeError("Control route is invalid")
        self.store = store

    def close(self) -> None:
        self.runtime.close()

    def ci_check(
        self, base: str = "origin/main", head: str = "HEAD", pack_id: str | None = None
    ) -> dict[str, Any]:
        process = subprocess.run(
            ["git", "diff", "--no-ext-diff", "--unified=0", base, head],
            cwd=self.repo_root,
            capture_output=True,
            text=True,
            check=False,
        )
        if process.returncode:
            raise RuntimeError(process.stderr.strip() or "git diff failed")
        paths = paths_from_diff(process.stdout)
        policy = CapabilityPolicy(self.repo_root, load_settings(self.repo_root)).check_paths(
            paths,
            deleted_paths=deleted_paths_from_diff(process.stdout),
            for_ci=True,
        )
        violations = list(policy["violations"])
        settings = load_settings(self.repo_root)
        if settings.ci.require_pack and paths and not pack_id:
            violations.append(
                {
                    "type": "missing_pack",
                    "path": "",
                    "severity": "high",
                    "reason": "CI policy requires an exact context pack.",
                }
            )
        blocked = any(item.get("severity") == "high" for item in violations)
        return {
            "ok": not blocked,
            "status": "pass" if not blocked else "fail",
            "schema_version": "persistmind.ci_check.v1",
            "base": base,
            "head": head,
            "paths": paths,
            "pack_id": pack_id,
            "violations": violations,
            "selected_tests": [],
        }

    def ci_explain(
        self, base: str = "origin/main", head: str = "HEAD", pack_id: str | None = None
    ) -> dict[str, Any]:
        report = self.ci_check(base, head, pack_id)
        return {
            **report,
            "schema_version": "persistmind.ci_explain.v1",
            "explanations": [
                {
                    "path": item.get("path"),
                    "decision": "blocked" if item.get("severity") == "high" else "warning",
                    "reason": item.get("reason"),
                }
                for item in report["violations"]
            ],
        }

    def ci_emit_github(self, report: Mapping[str, Any] | None = None) -> dict[str, Any]:
        report = report or self.ci_check()
        return self._record_ci_emission("github", github_annotations(dict(report)))

    def ci_emit_gitlab(self, report: Mapping[str, Any] | None = None) -> dict[str, Any]:
        report = report or self.ci_check()
        return self._record_ci_emission("gitlab", gitlab_annotations(dict(report)))

    def _record_ci_emission(self, provider: str, payload: Any) -> dict[str, Any]:
        document = {"provider": provider, "payload": payload, "created_at": utc_now()}
        record_id = "ci-emission_" + stable_id(canonical_json(document))[:32]
        self.store.put(
            {
                "record_id": record_id,
                "kind": "ci_emission",
                "scope": provider,
                **document,
            },
            idempotency_key="ci-emission:" + stable_id(provider, canonical_json(payload)),
        )
        return {
            "ok": True,
            "status": "emitted",
            "schema_version": f"persistmind.ci_{provider}_emission.v1",
            "record_id": record_id,
            "payload": payload,
        }

    def install_post_commit_hook(self) -> dict[str, Any]:
        result = install_git_hooks(self.repo_root, runtime_invocation())
        return {
            "ok": True,
            "status": "installed",
            "schema_version": "persistmind.git_hook_install.v1",
            "hooks": result,
        }

    def registry_health(
        self,
        *,
        include_temp: bool = False,
        path_root: str | None = None,
        include_rollup: bool = False,
        output: str | None = None,
    ) -> dict[str, Any]:
        del include_temp, path_root, include_rollup, output
        registry = ProjectRegistry()
        rows = registry.list()
        missing = [item["path"] for item in rows if not Path(str(item["path"])).is_dir()]
        removed = registry.prune()
        return {
            "ok": not missing,
            "status": "healthy" if not missing else "repaired",
            "schema_version": "persistmind.registry_health.v1",
            "missing": missing,
            "removed": removed,
        }

    def registry_list(self) -> dict[str, Any]:
        rows = ProjectRegistry().list()
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.registry_list.v1",
            "projects": rows,
        }

    def registry_prune(self) -> dict[str, Any]:
        removed = ProjectRegistry().prune()
        return {
            "ok": True,
            "status": "pruned",
            "schema_version": "persistmind.registry_prune.v1",
            "removed": removed,
        }

    def registry_register(self, path: str | None = None, **metadata: Any) -> dict[str, Any]:
        path = path or str(self.repo_root)
        record = ProjectRegistry().register(path, **metadata)
        return {
            "ok": True,
            "status": "registered",
            "schema_version": "persistmind.registry_register.v1",
            "project": record,
        }

    def registry_remove(self, path: str) -> dict[str, Any]:
        removed = ProjectRegistry().remove(path)
        return {
            "ok": removed,
            "status": "removed" if removed else "unidentifiable",
            "schema_version": "persistmind.registry_remove.v1",
            "path": str(Path(path).resolve()),
        }

    def create_incident(self, **request: Any) -> dict[str, Any]:
        title = str(request.get("title") or request.get("summary") or "").strip()
        if not title:
            raise ValueError("incident requires a title or summary")
        payload = {**request, "title": title, "created_at": utc_now(), "state": "open"}
        incident_id = "incident_" + stable_id(canonical_json(payload))[:32]
        self.store.put(
            {
                "record_id": incident_id,
                "kind": "control_incident",
                "scope": str(request.get("scope") or "workspace"),
                **payload,
            },
            idempotency_key="incident:" + incident_id,
        )
        return {
            "ok": True,
            "status": "recorded",
            "schema_version": "persistmind.incident.v1",
            "incident_id": incident_id,
        }

    def create_from_file(self, path: str | Path) -> dict[str, Any]:
        source = Path(path)
        if not source.is_absolute():
            source = self.repo_root / source
        source = source.resolve()
        if not source.is_relative_to(self.repo_root):
            raise ValueError("incident input must stay inside the repository")
        payload = json.loads(source.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("incident input must be a JSON object")
        return self.create_incident(
            **payload, source_file=source.relative_to(self.repo_root).as_posix()
        )

    def import_legacy(self, path: str | Path) -> dict[str, Any]:
        source = Path(path).resolve()
        payload = json.loads(source.read_text(encoding="utf-8"))
        rows = payload if isinstance(payload, list) else payload.get("incidents", [])
        if not isinstance(rows, list):
            raise ValueError("legacy incident document must contain an incidents array")
        imported = []
        for ordinal, row in enumerate(rows):
            if not isinstance(row, dict):
                continue
            result = self.create_incident(
                **row,
                legacy_source=str(source),
                legacy_ordinal=ordinal,
            )
            imported.append(result["incident_id"])
        return {
            "ok": True,
            "status": "imported",
            "schema_version": "persistmind.incident_legacy_import.v1",
            "source": str(source),
            "incident_ids": imported,
        }

    def export(
        self,
        scope: str = "incidents",
        *,
        output: str | Path | None = None,
        **metadata: Any,
    ) -> dict[str, Any]:
        del metadata
        output = output or f".persistmind/exports/{scope}.json"
        target = self._repo_output(output)
        rows = [
            dict(item)
            for item in self.store.search('"kind":"control_incident"', limit=10_000)
            if scope in {"incidents", "all", str(item.get("scope"))}
        ]
        document = {
            "schema_version": "persistmind.incident_export.v1",
            "scope": scope,
            "records": rows,
        }
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(document, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return {"ok": True, "status": "exported", "path": str(target), "records": len(rows)}

    def erase(self, incident_id: str, *, confirm: bool = False) -> dict[str, Any]:
        if not confirm:
            raise PermissionError("incident erasure requires explicit confirmation")
        existing = self.store.get(incident_id)
        if existing is None or existing.get("kind") != "control_incident":
            raise KeyError(f"unknown incident: {incident_id}")
        tombstone = {
            "record_id": incident_id,
            "kind": "control_incident",
            "scope": str(existing.get("scope") or "workspace"),
            "state": "erased",
            "erased_at": utc_now(),
            "prior_content_hash": existing.get("_content_hash"),
        }
        self.store.put(tombstone)
        return {
            "ok": True,
            "status": "erased",
            "schema_version": "persistmind.incident_erasure.v1",
            "incident_id": incident_id,
        }

    def db_stats(self) -> dict[str, Any]:
        page_count = int(_scalar(self.store.connection.execute("PRAGMA page_count").fetchone()))
        page_size = int(_scalar(self.store.connection.execute("PRAGMA page_size").fetchone()))
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.db_stats.v1",
            "store_id": self.store.descriptor.store_id,
            "page_count": page_count,
            "page_size": page_size,
            "bytes": page_count * page_size,
            "revision": self.store.revision(),
        }

    def db_bench(
        self,
        iterations: int = 1000,
        *,
        history: bool | None = None,
        limit: int | None = None,
        corpus: str | None = None,
    ) -> dict[str, Any]:
        del history, corpus
        if limit is not None:
            iterations = limit
        bounded = max(1, min(int(iterations), 100_000))
        started = time.perf_counter_ns()
        for _ in range(bounded):
            self.store.connection.execute(
                "SELECT revision FROM domain_metadata WHERE singleton=1"
            ).fetchone()
        elapsed = time.perf_counter_ns() - started
        result = {
            "iterations": bounded,
            "elapsed_ns": elapsed,
            "ns_per_query": elapsed // bounded,
        }
        record_id = "db-bench_" + stable_id(canonical_json(result))[:32]
        self.store.put(
            {"record_id": record_id, "kind": "control_db_benchmark", "scope": "control", **result},
            idempotency_key="db-bench:" + record_id,
        )
        return {
            "ok": True,
            "status": "recorded",
            "schema_version": "persistmind.db_benchmark.v1",
            **result,
        }

    def retention_show(self) -> dict[str, Any]:
        record = self.store.get("control-retention-policy")
        return {
            "ok": True,
            "status": "configured" if record else "default",
            "schema_version": "persistmind.retention_show.v1",
            "policy": record or {"keep_days": 30},
        }

    def retention_set(
        self,
        keep_days: int = 30,
        *,
        target: str | None = None,
        preset: str | None = None,
        keep_full_days: int | None = None,
        keep_summary_days: int | None = None,
        max_rows: int | None = None,
        scope: str | None = None,
    ) -> dict[str, Any]:
        if keep_full_days is not None:
            keep_days = keep_full_days
        if keep_days < 1:
            raise ValueError("retention keep_days must be positive")
        self.store.put(
            {
                "record_id": "control-retention-policy",
                "kind": "control_retention_policy",
                "scope": "workspace",
                "keep_days": int(keep_days),
                "target": target,
                "preset": preset,
                "keep_summary_days": keep_summary_days,
                "max_rows": max_rows,
                "requested_scope": scope,
                "updated_at": utc_now(),
            }
        )
        return {**self.retention_show(), "status": "updated"}

    def maintenance_run(self, full: bool = True, trigger: str = "manual") -> dict[str, Any]:
        plane = StorageControlPlane(self.repo_root)
        repair = plane.repair(dry_run=True)
        gc = plane.gc(dry_run=True)
        keep_days = int((self.store.get("control-retention-policy") or {}).get("keep_days", 30))
        retention = plane.retention(dry_run=True, keep_days=keep_days)
        result = {
            "full": bool(full),
            "trigger": trigger,
            "repair": repair,
            "gc": gc,
            "retention": retention,
            "created_at": utc_now(),
        }
        record_id = "maintenance_" + stable_id(canonical_json(result))[:32]
        self.store.put(
            {"record_id": record_id, "kind": "control_maintenance", "scope": "workspace", **result},
            idempotency_key="maintenance:" + record_id,
        )
        return {
            "ok": bool(repair["ok"] and gc["ok"] and retention["ok"]),
            "status": "clean" if repair["ok"] else "action_required",
            "schema_version": "persistmind.maintenance_run.v1",
            "record_id": record_id,
            **result,
        }

    def maintenance_tick(self, full: bool = True) -> dict[str, Any]:
        return self.maintenance_run(full=full, trigger="tick")

    def maintenance_history(self, limit: int = 50) -> dict[str, Any]:
        rows = [
            dict(item) for item in self.store.search('"kind":"control_maintenance"', limit=limit)
        ]
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.maintenance_history.v1",
            "runs": rows,
        }

    def release_gap_register(self) -> dict[str, Any]:
        return load_gap_register(self.repo_root)

    def release_gap_validate(self) -> dict[str, Any]:
        return validate_gap_register(self.repo_root)

    def release_gap_write(self, output: str | Path | None = None) -> dict[str, Any]:
        return write_default_gap_register(
            self.repo_root, path=Path(output) if output is not None else None
        )

    def release_dead_code_inventory_write(self, output: str | Path | None = None) -> dict[str, Any]:
        validator: Any = SimpleNamespace(repo_root=self.repo_root)
        payload = ReleaseValidator.dead_code_inventory_payload(validator)
        target = self._repo_output(output or "plan/dead-code-inventory.json")
        return self._write_release_artifact(target, payload)

    def release_no_v0_checklist_write(self, output: str | Path | None = None) -> dict[str, Any]:
        gap = validate_gap_register(self.repo_root)
        dead_code = self.repo_root / "plan" / "dead-code-inventory.json"
        checks = [
            {
                "name": "gap_register_present",
                "ok": bool(gap.get("path")),
                "evidence": gap.get("path"),
            },
            {"name": "gap_register_resolved", "ok": bool(gap["ok"]), "evidence": gap},
            {
                "name": "dead_code_inventory_present",
                "ok": dead_code.is_file(),
                "evidence": str(dead_code),
            },
        ]
        payload = {
            "schema_version": "persistmind.no_v0_release_checklist.v1",
            "generated_at": utc_now(),
            "checks": checks,
            "summary": {"checks": len(checks), "passed": sum(bool(item["ok"]) for item in checks)},
        }
        target = self._repo_output(output or "plan/no-v0-release-checklist.json")
        return self._write_release_artifact(target, payload)

    def release_benchmark_artifacts_write(self, output: str | Path | None = None) -> dict[str, Any]:
        roots = [
            self.repo_root / "plan" / "qualification-evidence",
            self.repo_root / ".persistmind" / "reports",
        ]
        entries = []
        for root in roots:
            if not root.is_dir():
                continue
            for path in sorted(root.rglob("*")):
                if path.is_file():
                    entries.append(
                        {
                            "path": path.relative_to(self.repo_root).as_posix(),
                            "bytes": path.stat().st_size,
                            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                        }
                    )
        payload = {
            "schema_version": "persistmind.benchmark_artifacts.v1",
            "generated_at": utc_now(),
            "artifacts": entries,
        }
        return self._write_release_artifact(
            self._repo_output(output or "plan/benchmark-artifacts.json"), payload
        )

    def release_compare(
        self,
        current: Mapping[str, Any] | str | Path,
        *,
        baseline_path: str | Path | None = None,
    ) -> dict[str, Any]:
        if baseline_path is None:
            baseline_path = current if isinstance(current, (str, Path)) else ""
        if not baseline_path:
            raise ValueError("release comparison requires a baseline path")
        baseline_file = Path(baseline_path)
        if not baseline_file.is_absolute():
            baseline_file = self.repo_root / baseline_file
        baseline_file = baseline_file.resolve()
        if not baseline_file.is_relative_to(self.repo_root):
            raise ValueError("release comparison baseline must be inside the repository")
        baseline = json.loads(baseline_file.read_text(encoding="utf-8"))
        current_metrics = current if isinstance(current, Mapping) else {}
        keys = sorted(set(current_metrics) & set(baseline))
        deltas = {
            key: float(current_metrics[key]) - float(baseline[key])
            for key in keys
            if isinstance(current_metrics[key], (int, float))
            and isinstance(baseline[key], (int, float))
        }
        return {
            "ok": True,
            "status": "compared",
            "schema_version": "persistmind.release_compare.v1",
            "baseline": str(baseline_file),
            "deltas": deltas,
        }

    def release_report(self) -> dict[str, Any]:
        artifacts = {}
        for name in (
            "gap-audit-register.json",
            "dead-code-inventory.json",
            "no-v0-release-checklist.json",
            "benchmark-artifacts.json",
        ):
            path = self.repo_root / "plan" / name
            artifacts[name] = {
                "present": path.is_file(),
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None,
            }
        valid = validate_gap_register(self.repo_root)
        return {
            "ok": bool(valid["ok"] and all(item["present"] for item in artifacts.values())),
            "status": "ready" if valid["ok"] else "incomplete",
            "schema_version": "persistmind.release_report.v1",
            "gap_register": valid,
            "artifacts": artifacts,
        }

    def _repo_output(self, path: str | Path) -> Path:
        target = Path(path)
        if not target.is_absolute():
            target = self.repo_root / target
        target = target.resolve()
        if not target.is_relative_to(self.repo_root):
            raise ValueError("Control artifact output must stay inside the repository")
        return target

    def _write_release_artifact(self, target: Path, payload: Mapping[str, Any]) -> dict[str, Any]:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(dict(payload), indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        return {
            "ok": True,
            "status": "written",
            "schema_version": "persistmind.release_artifact_write.v1",
            "path": str(target),
            "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
            "artifact": dict(payload),
        }
