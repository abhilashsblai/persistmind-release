from __future__ import annotations

import hashlib
import os
import secrets
import subprocess
from collections import OrderedDict
from collections.abc import Sequence
from dataclasses import replace
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Protocol, cast

from persistmind.config import is_ignored, load_settings
from persistmind.application.execution_scope import current_operation_scope
from persistmind.parsing.extractors import parse_file
from persistmind.retrieval.chunker import chunk_file
from persistmind.retrieval.embedder import cosine
from persistmind.utils import canonical_json, stable_id, utc_now
from persistmind.agent_runtime.identity import repository_context
from persistmind.agent_runtime.cache import (
    RuntimeCache,
    build_cache_key,
    cache_scope,
    cache_scope_matches,
)

from .adapters.sqlite_source import SQLiteSourceSegmentStore, SQLiteSourceStore
from .adapters.sqlite_activity import SQLiteActivityStore
from .adapters.sqlite_control import SQLiteControlStore
from .descriptors import StorageDomain, StoreCapabilities, StoreDescriptor, StoreRole
from .runtime import StorageOpenIntent, StorageRuntime
from .events import EventLedger, StorageEvent
from .lifecycle import OperationFence
from .model_bundle import source_embedder
from .topology_service import publish_topology
from .reconcile import reconcile


class SourceService:
    """Rebuildable Git/worktree source generations with catalog-published segments."""

    MAX_FILES = 20_000
    MAX_FILE_BYTES = 1_048_576
    MAX_GENERATION_BYTES = 64 * 1024 * 1024
    MAX_GENERATION_RECORDS = 200_000
    MAX_OPEN_SEGMENTS = 8
    INDEX_CONTRACT_VERSION = "persistmind.source_index.v2"

    def __init__(
        self,
        repo_root: Path,
        *,
        allow_development_driver: bool = False,
        runtime: StorageRuntime | None = None,
        read_only: bool = False,
    ) -> None:
        self.repo_root = repo_root.resolve()
        settings = load_settings(self.repo_root)
        self.settings = settings
        self._allow_development_driver = allow_development_driver
        self._read_only = read_only
        self._owns_runtime = runtime is None
        operation_scope = current_operation_scope()
        required_roles = (
            frozenset(StoreRole(role) for role in operation_scope.roles)
            if operation_scope is not None
            else frozenset(
                {StoreRole.SOURCE_MANIFEST, StoreRole.SOURCE_SEGMENT}
                if read_only
                else {
                    StoreRole.CONTROL,
                    StoreRole.SOURCE_MANIFEST,
                    StoreRole.SOURCE_SEGMENT,
                    StoreRole.ACTIVITY_ACTIVE,
                }
            )
        ) | {StoreRole.SOURCE_MANIFEST}
        self.runtime = runtime or StorageRuntime.open(
            self.repo_root / settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=allow_development_driver,
            read_only=read_only,
            required_roles=required_roles,
        )
        store = (
            self.runtime.router.resolve_read_set(StoreRole.SOURCE_MANIFEST)[0]
            if read_only
            else self.runtime.router.resolve_write_store(StoreRole.SOURCE_MANIFEST)
        )
        if not isinstance(store, SQLiteSourceStore):
            raise RuntimeError("Source route did not resolve to SQLiteSourceStore")
        self.store = store
        self.activity: SQLiteActivityStore | None = None
        self.control: SQLiteControlStore | None = None
        if not read_only and StoreRole.ACTIVITY_ACTIVE in required_roles:
            activity = self.runtime.router.resolve_write_store(StoreRole.ACTIVITY_ACTIVE)
            if not isinstance(activity, SQLiteActivityStore):
                raise RuntimeError("Activity route did not resolve for Source publication")
            self.activity = activity
        if not read_only and StoreRole.CONTROL in required_roles:
            control = self.runtime.router.resolve_write_store(StoreRole.CONTROL)
            if not isinstance(control, SQLiteControlStore):
                raise RuntimeError("Control route did not resolve for Source build fencing")
            self.control = control
        self.embedder = source_embedder(self.runtime.root)
        self.cache = RuntimeCache(self.runtime.root, read_only=read_only)
        self._outbox: EventLedger | None = None
        self._dynamic_segments: OrderedDict[str, SQLiteSourceSegmentStore] = OrderedDict()

    def close(self) -> None:
        for segment in self._dynamic_segments.values():
            segment.close()
        self._dynamic_segments.clear()
        if self._owns_runtime:
            self.runtime.close()

    @property
    def outbox(self) -> EventLedger:
        if self._outbox is None:
            self._outbox = EventLedger(cast(Any, self.store.connection))
        return self._outbox

    def __enter__(self) -> "SourceService":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def build(self) -> dict[str, Any]:
        if self._read_only:
            raise PermissionError("source build requires a command runtime")
        self.runtime.router.require_role(StoreRole.SOURCE_SEGMENT)
        if self.control is None:
            raise RuntimeError("source build requires the Control command port")
        nonce = secrets.token_hex(16)
        lease = self.control.acquire_lease(
            "source-build:default",
            owner_id=f"pid:{os.getpid()}",
            owner_boot_id=stable_id(str(self.repo_root), str(os.getpid()))[:24],
            owner_nonce=nonce,
            duration_seconds=120.0,
            payload={"repository": str(self.repo_root)},
        )
        try:
            result = self._build_under_lease()
            result["fencing_token"] = lease["fencing_token"]
            return result
        finally:
            self.control.release_lease(
                "source-build:default",
                owner_nonce=nonce,
                fencing_token=int(lease["fencing_token"]),
            )

    def _build_under_lease(self) -> dict[str, Any]:
        files, skipped = self._read_inputs()
        git_evidence = self._git_evidence()
        input_manifest = [
            {"path": path, "sha256": hashlib.sha256(data).hexdigest()} for path, data in files
        ]
        source_identity = _embedding_identity(self.embedder)
        input_hash = hashlib.sha256(
            canonical_json(
                {
                    "files": input_manifest,
                    "embedding": source_identity,
                    "index_contract": self.INDEX_CONTRACT_VERSION,
                }
            ).encode("utf-8")
        ).hexdigest()
        generation_id = "source-" + input_hash[:24]
        source_view_id = repository_context(self.repo_root).source_view_id
        existing = self.store.generation(generation_id)
        if existing and str(existing.get("status")) == "published":
            self.store.publish_source_view(source_view_id, generation_id)
            result = self._build_result(
                generation_id,
                input_hash,
                len(files),
                sum(len(data) for _, data in files),
                skipped,
                reused=True,
            )
            result["embedding"] = source_identity
            result["git_evidence"] = git_evidence
            result["convergence"] = self.reconcile_publications()
            return result

        reused_files = 0
        parsed_files = 0
        embedded_files = 0
        new_descriptors: list[StoreDescriptor] = []
        artifact_rows: list[dict[str, Any]] = []
        new_publications: list[tuple[dict[str, Any], StoreDescriptor]] = []
        bindings: list[dict[str, Any]] = []
        segment_ids: list[str] = []
        segment_hashes: list[str] = []
        integrity_rows: list[Mapping[str, Any]] = []
        created_paths: list[Path] = []
        model_digest = hashlib.sha256(canonical_json(source_identity).encode("utf-8")).hexdigest()
        catalog_topology = self.runtime.catalog.current()
        try:
            record_count = 0
            for source_path, data in files:
                content_hash = hashlib.sha256(data).hexdigest()
                resolver = source_resolver(source_path)
                resolver_id = resolver.resolver_id
                self.store.register_resolver(
                    resolver_id,
                    resolver.version,
                    resolver.kind,
                    resolver.configuration_digest,
                )
                artifact_digest = hashlib.sha256(
                    canonical_json(
                        resolver.artifact_identity(
                            path=source_path,
                            content_hash=content_hash,
                            index_contract=self.INDEX_CONTRACT_VERSION,
                            model_digest=model_digest,
                        )
                    ).encode("utf-8")
                ).hexdigest()
                artifact_id = "source-artifact-" + artifact_digest
                segment_id = "source-object-" + artifact_digest[:32]
                relative = f"objects/sha256/{artifact_digest[:2]}/{artifact_digest}.db"
                path = self.runtime.catalog.resolve_location(relative)
                bindings.append(
                    {
                        "path": source_path,
                        "artifact_id": artifact_id,
                        "content_hash": content_hash,
                        "resolver_id": resolver_id,
                    }
                )
                existing_artifact = self.store.artifact(artifact_id)
                descriptor = next(
                    (
                        item
                        for item in catalog_topology.stores
                        if item.store_id == segment_id
                        and item.store_role is StoreRole.SOURCE_SEGMENT
                    ),
                    None,
                )
                if existing_artifact is not None:
                    expected = {
                        "content_hash": content_hash,
                        "index_contract": self.INDEX_CONTRACT_VERSION,
                        "model_digest": model_digest,
                        "resolver_id": resolver_id,
                        "segment_id": segment_id,
                    }
                    if any(
                        str(existing_artifact.get(key)) != str(value)
                        for key, value in expected.items()
                    ):
                        raise RuntimeError(f"source artifact identity collision: {artifact_id}")
                    if not path.is_file() or _file_hash(path) != str(
                        existing_artifact["physical_hash"]
                    ):
                        raise RuntimeError(
                            f"source artifact image is missing or corrupt: {artifact_id}"
                        )
                    if descriptor is None:
                        descriptor = _artifact_descriptor(
                            catalog_generation=catalog_topology.generation,
                            segment_id=segment_id,
                            artifact_id=artifact_id,
                            source_path=source_path,
                            relative=relative,
                            artifact_digest=artifact_digest,
                            physical_hash=str(existing_artifact["physical_hash"]),
                        )
                        new_descriptors.append(descriptor)
                        new_publications.append((dict(existing_artifact), descriptor))
                    reused_files += 1
                    segment_ids.append(segment_id)
                    segment_hashes.append(str(existing_artifact["physical_hash"]))
                    continue
                if path.exists():
                    if descriptor is None:
                        physical_hash = _file_hash(path)
                        descriptor = _artifact_descriptor(
                            catalog_generation=catalog_topology.generation,
                            segment_id=segment_id,
                            artifact_id=artifact_id,
                            source_path=source_path,
                            relative=relative,
                            artifact_digest=artifact_digest,
                            physical_hash=physical_hash,
                        )
                        recovered_store = SQLiteSourceSegmentStore(
                            path,
                            descriptor=descriptor,
                            allow_development_driver=self._allow_development_driver,
                        )
                        try:
                            recovered_integrity = recovered_store.integrity_status(expected_files=1)
                            if not recovered_integrity["ok"]:
                                raise RuntimeError(
                                    "unpublished source artifact failed recovery parity"
                                )
                        finally:
                            recovered_store.close()
                        new_descriptors.append(descriptor)
                    else:
                        physical_hash = _file_hash(path)
                        if descriptor.physical_image_hash != physical_hash:
                            raise RuntimeError(
                                f"catalog source artifact image is corrupt: {artifact_id}"
                            )
                    recovered = {
                        "artifact_id": artifact_id,
                        "content_hash": content_hash,
                        "index_contract": self.INDEX_CONTRACT_VERSION,
                        "model_digest": model_digest,
                        "resolver_id": resolver_id,
                        "segment_id": segment_id,
                        "physical_hash": physical_hash,
                        "logical_bytes": len(data),
                        "created_at": utc_now(),
                    }
                    artifact_rows.append(recovered)
                    new_publications.append((recovered, descriptor))
                    reused_files += 1
                    segment_ids.append(segment_id)
                    segment_hashes.append(physical_hash)
                    continue
                path.parent.mkdir(parents=True, exist_ok=True)
                created_paths.append(path)
                segment = SQLiteSourceSegmentStore(
                    path,
                    store_id=segment_id,
                    allow_development_driver=self._allow_development_driver,
                )
                try:
                    text = data.decode("utf-8")
                    records = _source_records(
                        artifact_id,
                        source_path,
                        text,
                        content_hash,
                        self.embedder,
                        index_contract=self.INDEX_CONTRACT_VERSION,
                    )
                    parsed_files += 1
                    embedded_files += 1
                    record_count += len(records)
                    if record_count > self.MAX_GENERATION_RECORDS:
                        raise ValueError(
                            "source generation exceeds "
                            f"{self.MAX_GENERATION_RECORDS} structural record limit"
                        )
                    for record in records:
                        segment.put_source_record(record)
                    segment.seal()
                    integrity = segment.integrity_status(expected_files=1)
                    if not integrity["ok"]:
                        raise RuntimeError(f"source artifact parity failed: {integrity}")
                    integrity_rows.append(integrity)
                finally:
                    segment.close()
                physical_hash = _file_hash(path)
                descriptor = _artifact_descriptor(
                    catalog_generation=catalog_topology.generation,
                    segment_id=segment_id,
                    artifact_id=artifact_id,
                    source_path=source_path,
                    relative=relative,
                    artifact_digest=artifact_digest,
                    physical_hash=physical_hash,
                )
                new_descriptors.append(descriptor)
                artifact = {
                    "artifact_id": artifact_id,
                    "content_hash": content_hash,
                    "index_contract": self.INDEX_CONTRACT_VERSION,
                    "model_digest": model_digest,
                    "resolver_id": resolver_id,
                    "segment_id": segment_id,
                    "physical_hash": physical_hash,
                    "logical_bytes": len(data),
                    "created_at": utc_now(),
                }
                artifact_rows.append(artifact)
                new_publications.append((artifact, descriptor))
                segment_ids.append(segment_id)
                segment_hashes.append(physical_hash)
        except BaseException:
            for path in created_paths:
                path.unlink(missing_ok=True)
                Path(f"{path}-wal").unlink(missing_ok=True)
                Path(f"{path}-shm").unlink(missing_ok=True)
            raise
        self.store.rebuild({"generation_id": generation_id, "input_hash": input_hash})
        self.store.put(
            {
                "record_id": "source-evidence-" + generation_id,
                "kind": "source_generation_evidence",
                "generation_id": generation_id,
                "input_hash": input_hash,
                "files": input_manifest,
                "embedding": source_identity,
                "git": git_evidence,
            },
            idempotency_key="source-evidence:" + generation_id,
        )
        # Register immutable objects before catalog publication. A crash here leaves
        # only ref-counted, recoverable objects; the current source-view pointer is
        # unchanged until every catalog descriptor is durable.
        for artifact in artifact_rows:
            self.store.register_artifact(artifact)
        self.store.bind_generation_files(generation_id, bindings)
        current = self.runtime.catalog.current()
        published = replace(
            current,
            generation=current.generation + 1,
            stores=(*current.stores, *new_descriptors),
            created_at=utc_now(),
        )
        publish_topology(self.runtime, published, expected_generation=current.generation)
        for artifact, descriptor in new_publications:
            self.store.publish_segment(
                {
                    "segment_id": artifact["segment_id"],
                    "generation_id": generation_id,
                    "content_hash": artifact["content_hash"],
                    "state": "sealed",
                    "sealed_at": descriptor.sealed_at,
                }
            )
        self.store.publish_generation(generation_id)
        self.store.publish_source_view(source_view_id, generation_id)
        event = StorageEvent(
            event_id="evt_" + stable_id("SourceGenerationPublished.v1", generation_id)[:32],
            event_type="SourceGenerationPublished.v1",
            aggregate_id=str(self.repo_root),
            sequence=published.generation,
            payload={
                "generation_id": generation_id,
                "input_hash": input_hash,
                "segment_ids": segment_ids,
                "segment_hashes": segment_hashes,
                "source_view_id": source_view_id,
                "catalog_generation": published.generation,
                "published_at": utc_now(),
            },
            required_consumers=("activity.ledger.v1",),
        )
        self.outbox.append(event)
        self.store.connection.commit()
        result = self._build_result(
            generation_id,
            input_hash,
            len(files),
            sum(len(data) for _, data in files),
            skipped,
            reused=False,
        )
        result["git_evidence"] = git_evidence
        result["storage_event_id"] = event.event_id
        result["embedding"] = source_identity
        result["incremental"] = {
            "index_contract": self.INDEX_CONTRACT_VERSION,
            "reused_files": reused_files,
            "parsed_files": parsed_files,
            "embedded_files": embedded_files,
            "unchanged_parse_count": 0 if reused_files else None,
            "unchanged_embed_count": 0 if reused_files else None,
        }
        result["integrity"] = {
            "ok": all(bool(item.get("ok")) for item in integrity_rows),
            "artifacts_checked": len(integrity_rows),
            "reused_artifacts": reused_files,
        }
        result["source_view_id"] = source_view_id
        result["artifact_layout"] = "content-addressed-resolved-file-v1"
        result["convergence"] = self.reconcile_publications()
        return result

    def status(self) -> dict[str, Any]:
        return {
            "ok": True,
            "schema_version": "persistmind.source_status.v1",
            "generations": [dict(item) for item in self.store.generations()],
            "segments": [dict(item) for item in self.store.segments()],
            "source_views": [dict(item) for item in self.store.source_views()],
            "artifacts": [dict(item) for item in self.store.artifacts()],
            "resolvers": [dict(item) for item in self.store.resolvers()],
            "reader_protection": "immutable-generation-grace-period",
            "pins": [dict(item) for item in self.store.pins()],
            "catalog_generation": self.runtime.topology.generation,
            "nextgen_v1": True,
        }

    def snapshot_current(self) -> dict[str, Any]:
        """Return the real published Source generation for this repository."""

        context = repository_context(self.repo_root)
        generation_id = self.store.current_generation(context.source_view_id)
        generation = self.store.generation(generation_id) if generation_id else None
        return {
            "ok": True,
            "status": "published" if generation is not None else "index_required",
            "schema_version": "persistmind.source_snapshot_current.v2",
            "source_view_id": context.source_view_id,
            "snapshot_id": generation_id,
            "generation": dict(generation) if generation is not None else None,
            "catalog_generation": self.runtime.topology.generation,
            "read_only": self._read_only,
            "nextgen_v1": True,
        }

    def snapshot_lineage(
        self, snapshot_id: str | None = None, *, limit: int = 50
    ) -> dict[str, Any]:
        """Return published Source generations newest first without mutation."""

        bounded = max(1, min(int(limit), 1000))
        generations = [dict(item) for item in self.store.generations(limit=bounded)]
        if snapshot_id is not None:
            generations = [
                item for item in generations if str(item.get("generation_id")) == snapshot_id
            ]
        return {
            "ok": True,
            "status": "ok" if generations or snapshot_id is None else "not_found",
            "schema_version": "persistmind.source_snapshot_lineage.v2",
            "snapshot_id": snapshot_id,
            "generations": generations,
            "count": len(generations),
            "catalog_generation": self.runtime.topology.generation,
            "read_only": self._read_only,
            "nextgen_v1": True,
        }

    def prune_generations(
        self, *, keep: int = 3, pinned: list[str] | None = None, dry_run: bool = True
    ) -> dict[str, Any]:
        if keep < 1:
            raise ValueError("source generation retention must keep at least one generation")
        pinned_set = {item for item in (pinned or []) if item}
        known_generations = {
            str(item["generation_id"]) for item in self.store.generations(limit=1000)
        }
        for generation_id in sorted(pinned_set):
            if generation_id not in known_generations:
                raise ValueError(f"cannot pin unknown source generation: {generation_id}")
            self.store.pin_generation(
                "source-pin-" + stable_id(generation_id, "retention")[:32],
                generation_id,
                "operator-retention",
                None,
            )
        generations = [dict(item) for item in self.store.generations(limit=1000)]
        retained = (
            {str(item["generation_id"]) for item in generations[:keep]}
            | pinned_set
            | self.store.protected_generations()
        )
        candidates = [
            str(item["generation_id"])
            for item in generations
            if str(item["generation_id"]) not in retained
        ]
        plan = {
            "keep": keep,
            "pinned": sorted(pinned_set),
            "candidates": candidates,
            "catalog_generation": self.runtime.catalog.current().generation,
        }
        if dry_run or not candidates:
            return {
                "ok": True,
                "status": "plan_ready" if dry_run else "clean",
                "schema_version": "persistmind.source_retention.v1",
                **plan,
                "deleted": [],
            }
        with OperationFence(self.runtime.root, "source-retention", plan, scope="source") as fence:
            current = self.runtime.catalog.current()
            for generation_id in candidates:
                self.store.delete_generation(generation_id)
            unreferenced = [dict(item) for item in self.store.unreferenced_artifacts()]
            unreferenced_ids = {str(item["artifact_id"]) for item in unreferenced}
            removed = [
                item
                for item in current.stores
                if item.store_role is StoreRole.SOURCE_SEGMENT
                and item.partition_key in unreferenced_ids
            ]
            published = replace(
                current,
                generation=current.generation + 1,
                stores=tuple(item for item in current.stores if item not in removed),
                created_at=utc_now(),
            )
            publish_topology(self.runtime, published, expected_generation=current.generation)
            deleted = []
            for descriptor in removed:
                opened = self.runtime.router.stores.get(descriptor.store_id)
                if opened is not None:
                    opened.close()
                path = self.runtime.catalog.resolve_location(descriptor.location)
                path.unlink(missing_ok=True)
                Path(f"{path}-wal").unlink(missing_ok=True)
                Path(f"{path}-shm").unlink(missing_ok=True)
                deleted.append(descriptor.store_id)
                self.store.delete_artifact(str(descriptor.partition_key))
            result = {
                "ok": True,
                "status": "applied",
                "schema_version": "persistmind.source_retention.v1",
                **plan,
                "catalog_generation": published.generation,
                "deleted": deleted,
            }
            fence.succeed(result)
            return result

    def search(self, query: str, *, limit: int = 20) -> dict[str, Any]:
        query = query.strip()
        if not query:
            raise ValueError("source search query must be non-empty")
        context = repository_context(self.repo_root)
        generation_id = self.store.current_generation(context.source_view_id) or "unpublished"
        key = build_cache_key(
            self.repo_root,
            self.runtime.root,
            source_generation=generation_id,
            request={"query": query},
            limits={"limit": max(1, min(int(limit), 1000))},
            algorithm_version=self.INDEX_CONTRACT_VERSION + ":search-v1",
            model_digest=hashlib.sha256(
                canonical_json(_embedding_identity(self.embedder)).encode("utf-8")
            ).hexdigest(),
        )
        cached = self.cache.get(
            "search",
            key,
            authorize=lambda value: (
                cache_scope_matches(value, key)
                and self.store.current_generation(context.source_view_id) == generation_id
            ),
        )
        if cached is not None and isinstance(cached.get("result"), Mapping):
            return {**dict(cached["result"]), "query": query}
        result = self._search_uncached(query, limit=limit)
        if not self._read_only:
            self.cache.put(
                "search",
                key,
                {"scope": cache_scope(key), "result": result},
            )
        return result

    def _search_uncached(self, query: str, *, limit: int = 20) -> dict[str, Any]:
        results: list[dict[str, Any]] = []
        query_vector = self.embedder.embed(query)
        coverage = {
            "eligible_count": 0,
            "scanned_count": 0,
            "truncated": False,
            "degraded": False,
            "strategy": "sqlite-vec",
        }
        fallback_bound = self.settings.retrieval.vector_fallback_limit
        exact_candidates: list[dict[str, Any]] = []
        used_vector_index = False
        generation_id = self.store.current_generation(
            repository_context(self.repo_root).source_view_id
        )
        if generation_id is None:
            raise KeyError("no published source generation; run `persistmind index`")
        stores = self._latest_source_stores(generation_id=generation_id)
        for store in stores:
            vector_results = store.vector_records(query_vector, limit=limit)
            used_vector_index = used_vector_index or bool(vector_results)
            results.extend(dict(item) for item in vector_results)
            lexical_results = store.source_records(query, limit=limit)
            if not vector_results:
                exact_candidates.extend(
                    dict(item)
                    for item in store.source_records("", limit=fallback_bound + 1)
                    if item.get("kind") == "source_chunk"
                )
            for item in lexical_results:
                result = dict(item)
                if any(
                    existing.get("record_id") == result.get("record_id") for existing in results
                ):
                    continue
                result.pop("embedding", None)
                result.setdefault("semantic_score", 0.0)
                results.append(result)
        coverage["eligible_count"] = len(exact_candidates)
        if exact_candidates and len(exact_candidates) > fallback_bound:
            coverage.update(
                {
                    "scanned_count": 0,
                    "degraded": True,
                    "strategy": "disabled",
                    "degradation_reason": "exact_scan_bound_exceeded",
                    "exact_scan_bound": fallback_bound,
                }
            )
        elif exact_candidates:
            coverage["strategy"] = "bounded-exact-cosine"
            coverage["scanned_count"] = len(exact_candidates)
            for result in exact_candidates:
                vector = result.pop("embedding", None)
                score = round(cosine(query_vector, vector if isinstance(vector, list) else []), 6)
                if score >= (0.5 if self.embedder.degraded_reason else 0.000001):
                    result["semantic_score"] = score
                    results.append(result)
        elif used_vector_index:
            coverage["scanned_count"] = len(results)
        deduped: dict[str, dict[str, Any]] = {}
        for item in results:
            key = str(item.get("record_id"))
            current = deduped.get(key)
            if current is None or float(item.get("semantic_score", 0.0)) > float(
                current.get("semantic_score", 0.0)
            ):
                deduped[key] = item
        results = list(deduped.values())
        for result in results:
            result["generation_id"] = generation_id
        results.sort(
            key=lambda item: (
                -float(item.get("semantic_score", 0.0)),
                str(item.get("path", "")),
                str(item.get("record_id", "")),
            )
        )
        return {
            "ok": True,
            "schema_version": "persistmind.source_search.v1",
            "query": query,
            "source_generation_id": generation_id,
            "results": results[:limit],
            "count": min(len(results), limit),
            "degraded": self.embedder.degraded_reason is not None or coverage["degraded"],
            "degradation_reason": self.embedder.degraded_reason
            or coverage.get("degradation_reason"),
            "coverage": coverage,
            "backend": (
                "fts5_external_content+sqlite_vec_flat"
                if len(query_vector) == 384
                else "fts5_external_content+exact_cosine"
            ),
            "model": self.embedder.model_name,
            "embedding": _embedding_identity(self.embedder),
            "nextgen_v1": True,
        }

    def impact(self, paths: list[str], *, limit: int = 1000) -> dict[str, Any]:
        normalized = sorted({item.replace("\\", "/") for item in paths if item})
        context = repository_context(self.repo_root)
        generation_id = self.store.current_generation(context.source_view_id) or "unpublished"
        key = build_cache_key(
            self.repo_root,
            self.runtime.root,
            source_generation=generation_id,
            request={"paths": normalized},
            limits={"limit": max(1, min(int(limit), 10000))},
            algorithm_version=self.INDEX_CONTRACT_VERSION + ":impact-v1",
        )
        cached = self.cache.get(
            "impact",
            key,
            authorize=lambda value: (
                cache_scope_matches(value, key)
                and self.store.current_generation(context.source_view_id) == generation_id
            ),
        )
        if cached is not None and isinstance(cached.get("result"), Mapping):
            return dict(cached["result"])
        result = self._impact_uncached(normalized, limit=limit)
        if not self._read_only:
            self.cache.put(
                "impact",
                key,
                {"scope": cache_scope(key), "result": result},
            )
        return result

    def _impact_uncached(self, normalized: list[str], *, limit: int = 1000) -> dict[str, Any]:
        impacted = set(normalized)
        edges: list[dict[str, Any]] = []
        generation_id = self.store.current_generation(
            repository_context(self.repo_root).source_view_id
        )
        try:
            if generation_id is None:
                raise KeyError("no published source generation")
            stores = self._latest_source_stores(generation_id=generation_id)
            for store in stores:
                if not isinstance(store, SQLiteSourceSegmentStore):
                    continue
                for item in store.source_records("", limit=limit):
                    if item.get("kind") != "source_edge":
                        continue
                    edge = dict(item)
                    edges.append(edge)
                    if str(edge.get("target")) in normalized:
                        impacted.add(str(edge.get("path")))
        except KeyError:
            stores = []
        generation = self.store.generation(generation_id) if generation_id else None
        return {
            "ok": True,
            "schema_version": "persistmind.source_impact.v1",
            "input_paths": normalized,
            "impacted_paths": sorted(impacted),
            "snapshot_id": generation_id,
            "source_generation_id": generation_id,
            "source_index_fingerprint": (
                str(generation["input_hash"]) if generation is not None else None
            ),
            "edges": edges[:limit],
            "tests": sorted(
                path for path in impacted if path.startswith("tests/") or "/test" in path
            ),
            "authoritative": True,
            "nextgen_v1": True,
        }

    def _latest_source_stores(
        self, *, generation_id: str | None = None
    ) -> list[SQLiteSourceSegmentStore]:
        self.runtime.router.require_role(StoreRole.SOURCE_SEGMENT)
        source_view_id = repository_context(self.repo_root).source_view_id
        selected_generation = generation_id or self.store.current_generation(source_view_id)
        generation_files = (
            self.store.generation_files(selected_generation) if selected_generation else []
        )
        artifact_ids = {str(item["artifact_id"]) for item in generation_files}
        legacy_segments = self.store.segments(selected_generation) if selected_generation else []
        legacy_segment_ids = {str(item["segment_id"]) for item in legacy_segments}
        uses_artifact_layout = bool(selected_generation) and (
            bool(generation_files) or not legacy_segments
        )
        descriptors = [
            item
            for item in self.runtime.catalog.current().stores
            if item.store_role is StoreRole.SOURCE_SEGMENT
            and item.state in {"active", "ready", "sealed"}
            and (
                (not uses_artifact_layout and item.store_id in legacy_segment_ids)
                or str(item.partition_key) in artifact_ids
            )
        ]
        stores: list[SQLiteSourceSegmentStore] = []
        routed = self.runtime.router.stores
        for descriptor in descriptors:
            existing = routed.get(descriptor.store_id) or self._dynamic_segments.get(
                descriptor.store_id
            )
            if existing is None:
                existing = SQLiteSourceSegmentStore(
                    self.runtime.catalog.resolve_location(descriptor.location),
                    descriptor=descriptor,
                    allow_development_driver=self._allow_development_driver,
                )
                self._dynamic_segments[descriptor.store_id] = existing
                while len(self._dynamic_segments) > self.MAX_OPEN_SEGMENTS:
                    _, expired = self._dynamic_segments.popitem(last=False)
                    expired.close()
            elif descriptor.store_id in self._dynamic_segments:
                self._dynamic_segments.move_to_end(descriptor.store_id)
            if isinstance(existing, SQLiteSourceSegmentStore):
                stores.append(existing)
        return stores

    def behavior_check(
        self,
        paths: Sequence[str] | None = None,
        *,
        diff: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        source_view_id = repository_context(self.repo_root).source_view_id
        generation_id = self.store.current_generation(source_view_id)
        generation = self.store.generation(generation_id) if generation_id else None
        git = self._git_evidence()
        ready = generation is not None and str(generation.get("status")) == "published"
        return {
            "ok": ready,
            "status": "verified" if ready else "source_not_ready",
            "schema_version": "persistmind.source_behavior_check.v1",
            "source_view_id": source_view_id,
            "generation": dict(generation) if generation is not None else None,
            "git_evidence": git,
            "request": {
                "paths": list(paths or ()),
                "diff_supplied": bool(diff),
                "pack_id": pack_id,
            },
        }

    def living_graph_query(
        self, query: str = "", *, kind: str | None = None, limit: int = 100
    ) -> dict[str, Any]:
        records = self._graph_records(query, limit=limit)
        if kind:
            records = [item for item in records if item.get("kind") == kind]
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.living_graph_query.v1",
            "generation_id": self._current_generation_id(),
            "records": records[: max(1, min(int(limit), 1000))],
        }

    def living_graph_neighbors(
        self,
        node_id: str,
        *,
        direction: str = "both",
        limit: int = 100,
        graph_version_id: str | None = None,
    ) -> dict[str, Any]:
        if direction not in {"incoming", "outgoing", "both"}:
            raise ValueError("graph direction must be incoming, outgoing, or both")
        records = self._graph_records("", limit=10_000)
        nodes = {str(item.get("record_id")): item for item in records}
        edges = []
        neighbors: dict[str, Mapping[str, Any]] = {}
        for item in records:
            if item.get("kind") != "source_edge":
                continue
            source = str(item.get("source") or item.get("path") or "")
            target = str(item.get("target") or "")
            outgoing = source == node_id or str(item.get("record_id")) == node_id
            incoming = target == node_id
            if (outgoing and direction in {"outgoing", "both"}) or (
                incoming and direction in {"incoming", "both"}
            ):
                edges.append(item)
                neighbor_id = target if outgoing else source
                neighbors[neighbor_id] = nodes.get(neighbor_id, {"record_id": neighbor_id})
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.living_graph_neighbors.v1",
            "node_id": node_id,
            "neighbors": list(neighbors.values())[:limit],
            "edges": edges[:limit],
            "requested_generation_id": graph_version_id,
        }

    def graph_node(self, node_id: str, graph_version_id: str | None = None) -> dict[str, Any]:
        row = next(
            (
                item
                for item in self._graph_records(node_id, limit=1000)
                if str(item.get("record_id")) == node_id
                or str(item.get("symbol")) == node_id
                or str(item.get("path")) == node_id
            ),
            None,
        )
        return {
            "ok": row is not None,
            "status": "ok" if row is not None else "unidentifiable",
            "schema_version": "persistmind.graph_node.v1",
            "node": row,
            "requested_generation_id": graph_version_id,
        }

    def graph_provenance(self, node_id: str, graph_version_id: str | None = None) -> dict[str, Any]:
        shown = self.graph_node(node_id)
        node = shown.get("node") or {}
        generation_id = str(node.get("generation_id") or self._current_generation_id())
        generation = self.store.generation(generation_id)
        return {
            "ok": bool(shown["ok"] and generation is not None),
            "status": "verified" if shown["ok"] and generation is not None else "unidentifiable",
            "schema_version": "persistmind.graph_provenance.v1",
            "node": node,
            "generation": dict(generation) if generation is not None else None,
            "content_hash": node.get("_content_hash"),
            "requested_generation_id": graph_version_id,
        }

    def graph_stats(self) -> dict[str, Any]:
        records = self._graph_records("", limit=10_000)
        counts: dict[str, int] = {}
        for item in records:
            kind = str(item.get("kind") or "unknown")
            counts[kind] = counts.get(kind, 0) + 1
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.graph_stats.v1",
            "generation_id": self._current_generation_id(),
            "counts": counts,
            "records": len(records),
        }

    def graph_validate(self, graph_version_id: str | None = None) -> dict[str, Any]:
        records = self._graph_records("", limit=10_000)
        paths = {str(item.get("path")) for item in records if item.get("path")}
        invalid = []
        for item in records:
            if item.get("kind") != "source_edge":
                continue
            target = str(item.get("target") or "")
            if not target or ".." in PurePosixPath(target).parts:
                invalid.append({"record_id": item.get("record_id"), "reason": "invalid_target"})
            elif bool(item.get("resolved")) and target not in paths:
                invalid.append({"record_id": item.get("record_id"), "reason": "missing_target"})
        return {
            "ok": not invalid,
            "status": "verified" if not invalid else "validation_failed",
            "schema_version": "persistmind.graph_validation.v1",
            "generation_id": self._current_generation_id(),
            "invalid_edges": invalid,
            "requested_generation_id": graph_version_id,
        }

    def living_graph_status(self) -> dict[str, Any]:
        status = self.status()
        return {
            **status,
            "schema_version": "persistmind.living_graph_status.v1",
            "graph": self.graph_stats(),
            "validation": self.graph_validate(),
        }

    def living_graph_update(self) -> dict[str, Any]:
        result = self.build()
        return {**result, "schema_version": "persistmind.living_graph_update.v1"}

    def living_graph_fork(self, fork_id: str | None = None) -> dict[str, Any]:
        generation_id = self._current_generation_id()
        source_view_id = fork_id or "source-view-fork-" + stable_id(generation_id, utc_now())[:24]
        self.store.publish_source_view(source_view_id, generation_id)
        return {
            "ok": True,
            "status": "forked",
            "schema_version": "persistmind.living_graph_fork.v1",
            "source_view_id": source_view_id,
            "generation_id": generation_id,
        }

    def living_graph_merge_review(
        self, base_generation_id: str, candidate_generation_id: str
    ) -> dict[str, Any]:
        base = self.store.generation(base_generation_id)
        candidate = self.store.generation(candidate_generation_id)
        if base is None or candidate is None:
            raise KeyError("merge review requires two known source generations")
        base_files = {
            item["path"]: item for item in self.store.generation_files(base_generation_id)
        }
        candidate_files = {
            item["path"]: item for item in self.store.generation_files(candidate_generation_id)
        }
        changed = sorted(
            path
            for path in set(base_files) | set(candidate_files)
            if base_files.get(path) != candidate_files.get(path)
        )
        review_hash = hashlib.sha256(
            canonical_json(
                {
                    "base": base_generation_id,
                    "candidate": candidate_generation_id,
                    "changed": changed,
                }
            ).encode("utf-8")
        ).hexdigest()
        return {
            "ok": True,
            "status": "candidate",
            "schema_version": "persistmind.living_graph_merge_review.v1",
            "base_generation_id": base_generation_id,
            "candidate_generation_id": candidate_generation_id,
            "changed_paths": changed,
            "review_hash": "sha256:" + review_hash,
        }

    def graph_merge_decide(
        self,
        base_generation_id: str,
        candidate_generation_id: str,
        *,
        decision: str,
        actor: str = "local-user",
        reason: str = "graph merge reviewed",
    ) -> dict[str, Any]:
        normalized = decision.strip().lower()
        if normalized not in {"accepted", "rejected"}:
            raise ValueError("graph merge decision must be accepted or rejected")
        review = self.living_graph_merge_review(base_generation_id, candidate_generation_id)
        decision_id = (
            "graph-merge_" + stable_id(review["review_hash"], normalized, actor, reason)[:32]
        )
        self.store.put(
            {
                "record_id": decision_id,
                "kind": "source_graph_merge_decision",
                "scope": repository_context(self.repo_root).source_view_id,
                "decision": normalized,
                "actor": actor,
                "reason": reason,
                "review": review,
                "created_at": utc_now(),
            },
            idempotency_key="source-graph-merge:" + decision_id,
        )
        if normalized == "accepted":
            self.store.publish_source_view(
                repository_context(self.repo_root).source_view_id, candidate_generation_id
            )
        return {
            "ok": True,
            "status": normalized,
            "schema_version": "persistmind.graph_merge_decision.v1",
            "decision_id": decision_id,
            "review": review,
        }

    def _current_generation_id(self) -> str:
        generation_id = self.store.current_generation(
            repository_context(self.repo_root).source_view_id
        )
        if generation_id is None:
            raise KeyError("no published source generation")
        return generation_id

    def _graph_records(self, query: str, *, limit: int) -> list[dict[str, Any]]:
        generation_id = self._current_generation_id()
        records = [
            dict(item)
            for store in self._latest_source_stores(generation_id=generation_id)
            for item in store.source_records(query, limit=limit)
            if item.get("kind") in {"source_file", "source_symbol", "source_edge"}
        ]
        records.sort(key=lambda item: str(item.get("record_id") or ""))
        return records[: max(1, min(int(limit), 10_000))]

    def reconcile_publications(self, *, limit: int = 100) -> dict[str, Any]:
        result = reconcile(
            self.outbox,
            "activity.ledger.v1",
            "v1",
            self._project_publication,
            limit=limit,
        )
        return {
            "ok": result.failed == 0,
            "scanned": result.scanned,
            "applied": result.applied,
            "duplicates": result.duplicates,
            "failed": result.failed,
            "errors": list(result.errors),
        }

    def _project_publication(self, event: StorageEvent) -> None:
        if event.event_type != "SourceGenerationPublished.v1":
            return
        if self.activity is None:
            raise RuntimeError("Source publication requires the Activity command port")
        segment_ids = [str(item) for item in event.payload.get("segment_ids") or []]
        segment_hashes = [str(item) for item in event.payload.get("segment_hashes") or []]
        segment_manifest_sha256 = hashlib.sha256(
            canonical_json(
                {
                    "segment_ids": segment_ids,
                    "segment_hashes": segment_hashes,
                }
            ).encode("utf-8")
        ).hexdigest()
        self.activity.append(
            {
                "event_id": event.event_id,
                "event_type": "source.generation_published",
                "occurred_at": event.payload.get("published_at"),
                # The Source authority retains the complete immutable segment
                # manifest. Activity records a bounded timeline projection so a
                # large repository cannot exceed the ledger's inline event limit.
                "payload": {
                    "schema_version": "persistmind.source_publication_activity.v1",
                    "generation_id": event.payload.get("generation_id"),
                    "input_hash": event.payload.get("input_hash"),
                    "source_view_id": event.payload.get("source_view_id"),
                    "catalog_generation": event.payload.get("catalog_generation"),
                    "published_at": event.payload.get("published_at"),
                    "segment_count": max(len(segment_ids), len(segment_hashes)),
                    "segment_manifest_sha256": segment_manifest_sha256,
                    "source_event_id": event.event_id,
                },
            },
            idempotency_key=f"source-publication:{event.event_id}",
        )

    def _read_inputs(self) -> tuple[list[tuple[str, bytes]], list[dict[str, Any]]]:
        completed = subprocess.run(
            ["git", "ls-files", "-co", "--exclude-standard", "-z"],
            cwd=self.repo_root,
            check=True,
            capture_output=True,
        )
        discovered: set[str] = set()
        for item in completed.stdout.split(b"\0"):
            if not item:
                continue
            name = item.decode("utf-8").replace("\\", "/")
            if not is_ignored(name, self.settings):
                discovered.add(name)
        names = sorted(discovered)
        if len(names) > self.MAX_FILES:
            raise ValueError(f"source generation exceeds {self.MAX_FILES} file limit")
        files: list[tuple[str, bytes]] = []
        skipped: list[dict[str, Any]] = []
        total = 0
        for name in names:
            if name in {".persistmind"} or name.startswith((".persistmind/",)):
                continue
            candidate = self.repo_root / name
            try:
                target = candidate.resolve(strict=True)
            except OSError as exc:
                skipped.append({"path": name, "reason": "unreadable", "error": type(exc).__name__})
                continue
            if not target.is_relative_to(self.repo_root):
                skipped.append({"path": name, "reason": "outside_repository"})
                continue
            if not target.is_file():
                skipped.append({"path": name, "reason": "unsupported_file_type"})
                continue
            try:
                before = target.stat()
            except OSError as exc:
                skipped.append({"path": name, "reason": "unreadable", "error": type(exc).__name__})
                continue
            size = before.st_size
            if size > self.MAX_FILE_BYTES:
                skipped.append({"path": name, "reason": "file_too_large", "bytes": size})
                continue
            try:
                data = target.read_bytes()
                after = target.stat()
            except OSError as exc:
                skipped.append({"path": name, "reason": "unreadable", "error": type(exc).__name__})
                continue
            if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
                after.st_dev,
                after.st_ino,
                after.st_size,
                after.st_mtime_ns,
            ):
                skipped.append({"path": name, "reason": "changed_during_read"})
                continue
            if b"\0" in data:
                skipped.append({"path": name, "reason": "binary"})
                continue
            try:
                data.decode("utf-8")
            except UnicodeDecodeError:
                skipped.append({"path": name, "reason": "encoding_failed"})
                continue
            total += len(data)
            if total > self.MAX_GENERATION_BYTES:
                raise ValueError("source generation exceeds 64 MiB text budget")
            files.append((name.replace("\\", "/"), data))
        return files, skipped

    def _git_evidence(self) -> dict[str, Any]:
        head = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=self.repo_root,
            check=False,
            capture_output=True,
        )
        status = subprocess.run(
            ["git", "status", "--porcelain=v2", "-z", "--untracked-files=all"],
            cwd=self.repo_root,
            check=True,
            capture_output=True,
        ).stdout
        return {
            "head": head.stdout.decode("ascii", errors="replace").strip()
            if head.returncode == 0
            else None,
            "dirty": bool(status),
            "status_sha256": hashlib.sha256(status).hexdigest(),
            "status_bytes": len(status),
            "content_frozen_by": "sorted_path_sha256_manifest",
        }

    @staticmethod
    def _build_result(
        generation_id: str,
        input_hash: str,
        files: int,
        logical_bytes: int,
        skipped: list[dict[str, Any]],
        *,
        reused: bool,
    ) -> dict[str, Any]:
        return {
            "ok": True,
            "schema_version": "persistmind.source_build.v1",
            "generation_id": generation_id,
            "input_hash": input_hash,
            "files": files,
            "logical_bytes": logical_bytes,
            "skipped": skipped,
            "reused": reused,
            "nextgen_v1": True,
        }


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _artifact_descriptor(
    *,
    catalog_generation: int,
    segment_id: str,
    artifact_id: str,
    source_path: str,
    relative: str,
    artifact_digest: str,
    physical_hash: str,
) -> StoreDescriptor:
    now = utc_now()
    return StoreDescriptor(
        store_id=segment_id,
        domain=StorageDomain.SOURCE,
        store_role=StoreRole.SOURCE_SEGMENT,
        backend="sqlite",
        location=relative,
        schema_head=1,
        authorization_scope="repository",
        generation=catalog_generation + 1,
        state="sealed",
        read_only=True,
        shard_key="default",
        partition_key=artifact_id,
        created_at=now,
        sealed_at=now,
        min_key=source_path,
        max_key=source_path,
        logical_content_hash=artifact_digest,
        physical_image_hash=physical_hash,
        capabilities=StoreCapabilities(partitioning=True, online_backup=True, full_text=True),
    )


class SourceResolver(Protocol):
    resolver_id: str
    version: str
    kind: str
    configuration_digest: str

    def artifact_identity(
        self,
        *,
        path: str,
        content_hash: str,
        index_contract: str,
        model_digest: str,
    ) -> Mapping[str, str]: ...


class BuiltinPathResolver:
    resolver_id = "builtin-path-v1"
    version = "1"
    kind = "path-and-import-resolution"
    configuration_digest = "builtin"

    def artifact_identity(
        self,
        *,
        path: str,
        content_hash: str,
        index_contract: str,
        model_digest: str,
    ) -> Mapping[str, str]:
        return {
            "content_hash": content_hash,
            "path": path,
            "index_contract": index_contract,
            "model_digest": model_digest,
            "resolver_id": self.resolver_id,
            "resolver_version": self.version,
        }


_SOURCE_RESOLVERS: dict[str, SourceResolver] = {"default": BuiltinPathResolver()}


def register_source_resolver(name: str, resolver: SourceResolver) -> None:
    key = name.casefold().lstrip(".")
    if (
        not key
        or not resolver.resolver_id
        or not resolver.version
        or not resolver.kind
        or not resolver.configuration_digest
    ):
        raise ValueError("source resolver registration is incomplete")
    _SOURCE_RESOLVERS[key] = resolver


def source_resolver(path: str) -> SourceResolver:
    suffix = PurePosixPath(path).suffix.casefold().lstrip(".")
    return _SOURCE_RESOLVERS.get(suffix, _SOURCE_RESOLVERS["default"])


def _embedding_identity(embedder: Any) -> dict[str, Any]:
    return {
        "requested_backend": embedder.requested_backend,
        "effective_backend": embedder.backend,
        "model": embedder.model_name,
        "dimensions": embedder.dims,
        "encoding": embedder.encoding,
        "implementation_signature": embedder.implementation_signature,
        "degraded_reason": embedder.degraded_reason,
    }


def _source_records(
    generation_id: str,
    path: str,
    text: str,
    content_hash: str,
    embedder: Any,
    *,
    index_contract: str = "persistmind.source_index.v2",
) -> list[dict[str, Any]]:
    extracted = parse_file(path, text, backend="auto")
    records: list[dict[str, Any]] = [
        {
            "record_id": "source-file-" + stable_id(generation_id, path)[:32],
            "kind": "source_file",
            "generation_id": generation_id,
            "path": path,
            "text": text,
            "content_hash": content_hash,
            "index_contract": index_contract,
            "line_count": text.count("\n") + (1 if text else 0),
            "requested_parser_backend": extracted.requested_backend,
            "effective_parser_backend": extracted.effective_backend,
            "support_tier": extracted.support_tier,
            "parser_diagnostics": list(extracted.diagnostics),
        }
    ]
    symbol_ids = {
        symbol.qualname: "source-symbol-"
        + stable_id(generation_id, path, symbol.qualname, symbol.start_line)[:32]
        for symbol in extracted.symbols
    }
    chunks = chunk_file(
        snapshot_id=generation_id,
        repo_id=generation_id,
        path=path,
        text=text,
        extracted=extracted,
        symbol_ids=symbol_ids,
    )
    for chunk in chunks:
        records.append(
            {
                "record_id": chunk.chunk_id,
                "kind": "source_chunk",
                "generation_id": generation_id,
                "path": path,
                "start_line": chunk.start_line,
                "end_line": chunk.end_line,
                "text": chunk.text,
                "category": chunk.category,
                "symbol_identity_id": chunk.symbol_identity_id,
                "embedding": embedder.embed(chunk.text_normalized),
                "model": embedder.model_name,
            }
        )
    for symbol in extracted.symbols:
        if not (1 <= symbol.start_line <= symbol.end_line <= max(1, len(text.splitlines()))):
            continue
        records.append(
            {
                "record_id": symbol_ids[symbol.qualname],
                "kind": "source_symbol",
                "generation_id": generation_id,
                "path": path,
                "symbol": symbol.qualname,
                "symbol_kind": symbol.kind,
                "start_line": symbol.start_line,
                "end_line": symbol.end_line,
                "authoritative": extracted.symbols_authoritative,
            }
        )
    for observation in extracted.imports:
        target = _import_hint_target(path, observation.module)
        records.append(
            {
                "record_id": "source-edge-"
                + stable_id(generation_id, path, target, observation.line)[:32],
                "kind": "source_edge",
                "generation_id": generation_id,
                "path": path,
                "edge_kind": "import_hint",
                "target": target,
                "line": observation.line,
                "resolved": False,
            }
        )
    return records


def _reusable_source_records(
    records: list[Mapping[str, Any]],
    *,
    generation_id: str,
    path: str,
    content_hash: str,
    embedder: Any,
    index_contract: str,
) -> list[dict[str, Any]]:
    source_file = next((item for item in records if item.get("kind") == "source_file"), None)
    chunks = [item for item in records if item.get("kind") == "source_chunk"]
    if (
        source_file is None
        or source_file.get("content_hash") != content_hash
        or source_file.get("index_contract") != index_contract
        or any(item.get("model") != embedder.model_name for item in chunks)
        or any(not isinstance(item.get("embedding"), list) for item in chunks)
    ):
        return []
    symbol_ids: dict[str, str] = {}
    old_to_new: dict[str, str] = {}
    for item in records:
        if item.get("kind") != "source_symbol":
            continue
        symbol = str(item.get("symbol") or "")
        start = int(item.get("start_line") or 0)
        identifier = "source-symbol-" + stable_id(generation_id, path, symbol, start)[:32]
        symbol_ids[symbol] = identifier
        old_to_new[str(item.get("record_id"))] = identifier
    output: list[dict[str, Any]] = []
    for raw in records:
        item = dict(raw)
        kind = str(item.get("kind"))
        item["generation_id"] = generation_id
        item["path"] = path
        if kind == "source_file":
            item["record_id"] = "source-file-" + stable_id(generation_id, path)[:32]
        elif kind == "source_symbol":
            item["record_id"] = symbol_ids[str(item.get("symbol") or "")]
        elif kind == "source_chunk":
            old_symbol = str(item.get("symbol_identity_id") or "")
            new_symbol = old_to_new.get(old_symbol)
            item["symbol_identity_id"] = new_symbol
            item["record_id"] = stable_id(
                generation_id,
                generation_id,
                path,
                new_symbol or "",
                item.get("start_line"),
                item.get("end_line"),
                item.get("text"),
            )
        else:
            continue
        output.append(item)
    return output


def _import_hint_target(path: str, module: str) -> str:
    if module.startswith("."):
        candidate = PurePosixPath(path).parent.joinpath(module)
        parts: list[str] = []
        for part in candidate.parts:
            if part in {"", "."}:
                continue
            if part == "..":
                if parts:
                    parts.pop()
                continue
            parts.append(part)
        return "/".join(parts)
    return module.replace(".", "/")
