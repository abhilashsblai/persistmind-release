from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from .events import EventLedger, StorageEvent


@dataclass(frozen=True, slots=True)
class ReconcileResult:
    scanned: int
    applied: int
    duplicates: int
    failed: int
    errors: tuple[dict[str, Any], ...] = field(default_factory=tuple)


def reconcile(
    ledger: EventLedger,
    consumer: str,
    handler_version: str,
    handler: Callable[[StorageEvent], None],
    *,
    limit: int = 100,
    receipt_validator: Callable[[StorageEvent], bool] | None = None,
) -> ReconcileResult:
    scanned = applied = duplicates = failed = 0
    errors: list[dict[str, Any]] = []
    for row in ledger.pending(limit=limit, consumer=consumer):
        scanned += 1
        event = StorageEvent(
            row["event_id"],
            row["event_type"],
            row["aggregate_id"],
            int(row["sequence"]),
            __import__("json").loads(row["payload_json"]),
        )
        if ledger.has_receipt(event.event_id, consumer, row["payload_hash"]):
            if receipt_validator is not None and not receipt_validator(event):
                failed += 1
                errors.append(
                    {
                        "event_id": event.event_id,
                        "consumer": consumer,
                        "error_type": "MissingConsumerEffect",
                        "error": "receipt exists but the consumer effect is missing",
                    }
                )
                ledger.dead_letter(
                    event.event_id,
                    consumer,
                    "receipt exists but the consumer effect is missing",
                )
                continue
            duplicates += 1
            ledger.publish_if_complete(event.event_id)
            continue
        try:
            handler(event)
            ledger.receipt(event.event_id, consumer, handler_version, row["payload_hash"])
        except Exception as exc:  # consumer failure stays visible and retryable
            failed += 1
            errors.append(
                {
                    "event_id": event.event_id,
                    "consumer": consumer,
                    "error_type": type(exc).__name__,
                    "error": str(exc)[:2000],
                }
            )
            ledger.dead_letter(event.event_id, consumer, str(exc))
        else:
            applied += 1
            ledger.clear_dead_letter(event.event_id, consumer)
            ledger.publish_if_complete(event.event_id)
    ledger.connection.commit()
    return ReconcileResult(scanned, applied, duplicates, failed, tuple(errors))
