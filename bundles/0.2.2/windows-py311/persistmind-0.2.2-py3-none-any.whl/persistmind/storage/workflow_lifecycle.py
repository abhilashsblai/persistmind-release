from __future__ import annotations

import hashlib
import json
import secrets
from collections.abc import Mapping, Sequence
from contextlib import contextmanager
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, cast

from persistmind.config import load_settings
from persistmind.identifiers import WorkflowIdKind, parse_workflow_id
from persistmind.utils import canonical_json, utc_now

from .adapters.sqlite_task import SQLiteTaskStore
from .descriptors import StoreRole
from .runtime import StorageOpenIntent, StorageRuntime, resolve_runtime_store
from .workflow_identity import WorkflowIdentity

WORKFLOW_EVENT_SCHEMA = "persistmind.workflow_event.v1"

_CONSUMERS = (
    "workflow.agent-session.v1",
    "workflow.audit.v1",
    "workflow.compatibility.v1",
    "workflow.continuation.v1",
    "workflow.teacher-runtime.v1",
)

_ROUTE_EVENTS = {
    "task.start": {"TaskStarted.v1"},
    "task.transition": {"TaskTransitioned.v1", "PackBound.v1"},
    "pack": {"PackBound.v1"},
    "codex.preflight": {"WritePreflightCompleted.v1"},
    "workflow.start": {"WritePreflightCompleted.v1"},
    "workflow.rebind": {"PackBound.v1"},
    "plan.create": {"PlanActivated.v1"},
    "plan.amend": {"PlanActivated.v1"},
    "plan.checkpoint": {"PlanCheckpointed.v1"},
    "check_diff": {"VerificationCompleted.v1"},
    "impact": {"VerificationCompleted.v1"},
    "outcome": {"OutcomeRecorded.v1"},
}


class WorkflowLifecycleCoordinator:
    """Canonical lifecycle ledger and Task-readiness projection.

    The coordinator intentionally owns only Task State writes. Product/host
    projections consume its returned event and remain retryable, while the
    canonical identity and ordered event sequence stay in one role-owned DB.
    """

    def __init__(
        self,
        repo_root: Path,
        *,
        allow_development_driver: bool = False,
        runtime: StorageRuntime | None = None,
        read_only: bool = False,
    ) -> None:
        self.repo_root = repo_root.resolve()
        settings = load_settings(self.repo_root)
        self._owns_runtime = runtime is None
        self.runtime = runtime or StorageRuntime.open(
            self.repo_root / settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=allow_development_driver,
            read_only=read_only,
            required_roles=frozenset({StoreRole.TASK_STATE}),
        )
        self._read_only = bool(self.runtime.read_only)
        store = resolve_runtime_store(
            self.runtime,
            StoreRole.TASK_STATE,
            read_only=self._read_only,
        )
        if not isinstance(store, SQLiteTaskStore):
            raise RuntimeError("Task State route is unavailable for lifecycle events")
        self.store = store

    def close(self) -> None:
        if self._owns_runtime:
            self.runtime.close()

    @contextmanager
    def _immediate_transaction(self) -> Any:
        if self._read_only:
            raise PermissionError("read-only lifecycle coordinator cannot mutate task state")
        connection = self.store.connection
        try:
            connection.execute("BEGIN IMMEDIATE")
        except Exception as exc:
            raise RuntimeError("workflow_contention") from exc
        try:
            yield
        except BaseException:
            connection.execute("ROLLBACK")
            raise
        else:
            connection.execute("COMMIT")

    def __enter__(self) -> WorkflowLifecycleCoordinator:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def emit(
        self,
        event_type: str,
        task_session_id: str,
        *,
        source_operation_key: str,
        payload: Mapping[str, Any],
        producer: str,
        required_consumers: tuple[str, ...] = _CONSUMERS,
    ) -> dict[str, Any]:
        parse_workflow_id(WorkflowIdKind.TASK, task_session_id, allow_legacy=False)
        if self.store.session(task_session_id) is None:
            raise KeyError(f"task session not found: {task_session_id}")
        normalized_consumers = tuple(sorted(set(required_consumers)))
        consumer_set_hash = hashlib.sha256(
            canonical_json(normalized_consumers).encode("utf-8")
        ).hexdigest()
        body = dict(payload)
        if body.get("task_session_id") not in {None, task_session_id}:
            raise ValueError("lifecycle payload task does not match aggregate")
        body["task_session_id"] = task_session_id
        connection = self.store.connection
        with self.store._write_lock, self._immediate_transaction():
            existing = connection.execute(
                "SELECT envelope_json FROM workflow_lifecycle_events WHERE source_operation_key=?",
                (source_operation_key,),
            ).fetchone()
            if existing is not None:
                envelope = json.loads(str(existing[0]))
                if envelope.get("event_type") != event_type or envelope.get("payload") != body:
                    raise RuntimeError("lifecycle source operation divergence")
                return envelope
            guard = connection.execute(
                "SELECT * FROM workflow_terminal_guards WHERE task_session_id=?",
                (task_session_id,),
            ).fetchone()
            canonical_outcome_id = (
                str(guard["canonical_outcome_id"])
                if guard is not None and guard["canonical_outcome_id"]
                else None
            )
            terminal_event_id = (
                str(guard["terminal_event_id"])
                if guard is not None and guard["terminal_event_id"]
                else None
            )
            if terminal_event_id is not None:
                raise RuntimeError("workflow is terminal")
            if event_type == "TaskCompleted.v1":
                raise RuntimeError("completion_barrier_required")
            if event_type == "OutcomeRecorded.v1":
                outcome_id = str(body.get("outcome_id") or "")
                if not outcome_id:
                    raise ValueError("OutcomeRecorded.v1 requires outcome_id")
                if canonical_outcome_id not in {None, outcome_id}:
                    raise RuntimeError("canonical outcome already recorded")
            elif canonical_outcome_id is not None:
                raise RuntimeError("outcome_completion_pending")
            if event_type in {"TaskFailed.v1", "TaskClosed.v1"} and canonical_outcome_id is not None:
                raise RuntimeError("task closure is forbidden after outcome")
            head = connection.execute(
                "SELECT last_sequence FROM workflow_lifecycle_heads WHERE task_session_id=?",
                (task_session_id,),
            ).fetchone()
            sequence = int(head[0]) + 1 if head is not None else 1
            payload_hash = hashlib.sha256(canonical_json(body).encode("utf-8")).hexdigest()
            event_id = (
                "evt_"
                + hashlib.sha256(
                    canonical_json(
                        [
                            WORKFLOW_EVENT_SCHEMA,
                            task_session_id,
                            sequence,
                            event_type,
                            payload_hash,
                        ]
                    ).encode("utf-8")
                ).hexdigest()[:32]
            )
            now = utc_now()
            envelope = {
                "schema_version": WORKFLOW_EVENT_SCHEMA,
                "event_id": event_id,
                "event_type": event_type,
                "aggregate_id": task_session_id,
                "sequence": sequence,
                "source_operation_key": source_operation_key,
                "occurred_at": now,
                "producer": producer,
                "required_consumers": list(normalized_consumers),
                "consumer_set_hash": consumer_set_hash,
                "payload": body,
            }
            connection.execute(
                "INSERT INTO workflow_lifecycle_events VALUES(?,?,?,?,?,?,?,?)",
                (
                    event_id,
                    task_session_id,
                    sequence,
                    event_type,
                    source_operation_key,
                    canonical_json(envelope),
                    consumer_set_hash,
                    now,
                ),
            )
            connection.execute(
                "INSERT INTO workflow_lifecycle_heads VALUES(?,?,?,?) "
                "ON CONFLICT(task_session_id) DO UPDATE SET "
                "last_sequence=excluded.last_sequence,last_event_id=excluded.last_event_id,"
                "updated_at=excluded.updated_at",
                (task_session_id, sequence, event_id, now),
            )
            if event_type == "OutcomeRecorded.v1":
                connection.execute(
                    "INSERT INTO workflow_terminal_guards VALUES(?,?,?,?,?,?) "
                    "ON CONFLICT(task_session_id) DO UPDATE SET "
                    "canonical_outcome_id=excluded.canonical_outcome_id,"
                    "outcome_sequence=excluded.outcome_sequence,updated_at=excluded.updated_at",
                    (
                        task_session_id,
                        str(body["outcome_id"]),
                        sequence,
                        None,
                        None,
                        now,
                    ),
                )
                self._set_outcome_pending_snapshot_locked(
                    task_session_id,
                    outcome_id=str(body["outcome_id"]),
                    outcome_sequence=sequence,
                )
            elif event_type in {"TaskFailed.v1", "TaskClosed.v1"}:
                terminal_status = str(body.get("result") or body.get("terminal_status") or "")
                if terminal_status not in {"fail", "partial", "cancelled", "blocked"}:
                    terminal_status = "fail" if event_type == "TaskFailed.v1" else "blocked"
                connection.execute(
                    "INSERT INTO workflow_terminal_guards VALUES(?,?,?,?,?,?) "
                    "ON CONFLICT(task_session_id) DO UPDATE SET "
                    "terminal_event_id=excluded.terminal_event_id,"
                    "terminal_status=excluded.terminal_status,updated_at=excluded.updated_at",
                    (
                        task_session_id,
                        None,
                        None,
                        event_id,
                        terminal_status,
                        now,
                    ),
                )
                self._set_terminal_snapshot_locked(
                    task_session_id,
                    event_id=event_id,
                    terminal_status=terminal_status,
                    outcome_id=None,
                )
            self.store._advance_revision()
        return envelope

    def receipt(
        self,
        event_id: str,
        consumer: str,
        *,
        status: str = "success",
        handler_version: str = "v1",
        error: str | None = None,
    ) -> dict[str, Any]:
        if status == "failed":
            status = "retryable_error"
        if status not in {"success", "retryable_error", "permanent_error"}:
            raise ValueError("invalid lifecycle receipt status")
        with self.store._write_lock, self._immediate_transaction():
            event = self.event(event_id)
            if event is None:
                raise KeyError(event_id)
            required = set(event["required_consumers"])
            if consumer not in required:
                raise ValueError("consumer is not in the frozen electorate")
            payload_hash = hashlib.sha256(
                canonical_json(event["payload"]).encode("utf-8")
            ).hexdigest()
            existing = self.store.connection.execute(
                "SELECT * FROM workflow_lifecycle_receipts WHERE event_id=? AND consumer=?",
                (event_id, consumer),
            ).fetchone()
            if existing is not None and str(existing["payload_hash"]) != payload_hash:
                raise RuntimeError("lifecycle receipt payload divergence")
            now = utc_now()
            self.store.connection.execute(
                "INSERT INTO workflow_lifecycle_receipts("
                "event_id,consumer,status,handler_version,payload_hash,error,"
                "claim_token,lease_expires_at,retry_count,updated_at) "
                "VALUES(?,?,?,?,?,?,NULL,NULL,?,?) "
                "ON CONFLICT(event_id,consumer) DO UPDATE SET "
                "status=excluded.status,handler_version=excluded.handler_version,"
                "error=excluded.error,claim_token=NULL,lease_expires_at=NULL,"
                "retry_count=workflow_lifecycle_receipts.retry_count+1,"
                "updated_at=excluded.updated_at",
                (
                    event_id,
                    consumer,
                    status,
                    handler_version,
                    payload_hash,
                    error[:2000] if error else None,
                    1,
                    now,
                ),
            )
            if status == "success":
                cursor = self._cursor_locked(str(event["aggregate_id"]), consumer)
                if int(cursor["last_contiguous_sequence"]) + 1 == int(event["sequence"]):
                    self._advance_cursor_locked(
                        str(event["aggregate_id"]),
                        consumer,
                        sequence=int(event["sequence"]),
                        event_id=event_id,
                    )
            self.store._advance_revision()
        return self.completion(event_id)

    def claim_next(
        self,
        task_session_id: str,
        consumer: str,
        *,
        lease_seconds: int = 30,
    ) -> dict[str, Any]:
        with self.store._write_lock, self._immediate_transaction():
            cursor = self._cursor_locked(task_session_id, consumer)
            while True:
                sequence = int(cursor["last_contiguous_sequence"]) + 1
                row = self.store.connection.execute(
                    "SELECT envelope_json FROM workflow_lifecycle_events "
                    "WHERE task_session_id=? AND sequence=?",
                    (task_session_id, sequence),
                ).fetchone()
                if row is None:
                    return {
                        "ok": True,
                        "status": "caught_up",
                        "task_session_id": task_session_id,
                        "consumer": consumer,
                        "last_contiguous_sequence": sequence - 1,
                    }
                event = json.loads(str(row["envelope_json"]))
                if consumer not in set(event["required_consumers"]):
                    self._mark_not_elected_locked(event, consumer)
                    self._advance_cursor_locked(
                        task_session_id,
                        consumer,
                        sequence=sequence,
                        event_id=str(event["event_id"]),
                    )
                    cursor = self._cursor_locked(task_session_id, consumer)
                    continue
                existing = self.store.connection.execute(
                    "SELECT * FROM workflow_lifecycle_receipts WHERE event_id=? AND consumer=?",
                    (event["event_id"], consumer),
                ).fetchone()
                if existing is not None and existing["status"] == "success":
                    self._advance_cursor_locked(
                        task_session_id,
                        consumer,
                        sequence=sequence,
                        event_id=str(event["event_id"]),
                    )
                    cursor = self._cursor_locked(task_session_id, consumer)
                    continue
                if existing is not None and existing["status"] == "permanent_error":
                    return {
                        "ok": False,
                        "status": "permanent_error",
                        "event": event,
                        "error": existing["error"],
                    }
                if (
                    existing is not None
                    and existing["status"] == "processing"
                    and existing["lease_expires_at"]
                    and _parse_utc(str(existing["lease_expires_at"])) > datetime.now(UTC)
                ):
                    return {
                        "ok": False,
                        "status": "leased",
                        "event_id": event["event_id"],
                    }
                token = "claim_" + secrets.token_hex(16)
                lease_expires = (
                    datetime.now(UTC) + timedelta(seconds=max(1, lease_seconds))
                ).isoformat()
                payload_hash = hashlib.sha256(
                    canonical_json(event["payload"]).encode("utf-8")
                ).hexdigest()
                self.store.connection.execute(
                    "INSERT INTO workflow_lifecycle_receipts("
                    "event_id,consumer,status,handler_version,payload_hash,error,"
                    "claim_token,lease_expires_at,retry_count,updated_at) "
                    "VALUES(?,?,'processing','v1',?,NULL,?,?,1,?) "
                    "ON CONFLICT(event_id,consumer) DO UPDATE SET "
                    "status='processing',claim_token=excluded.claim_token,"
                    "lease_expires_at=excluded.lease_expires_at,"
                    "retry_count=workflow_lifecycle_receipts.retry_count+1,"
                    "updated_at=excluded.updated_at",
                    (
                        event["event_id"],
                        consumer,
                        payload_hash,
                        token,
                        lease_expires,
                        utc_now(),
                    ),
                )
                self.store._advance_revision()
                return {
                    "ok": True,
                    "status": "claimed",
                    "claim_token": token,
                    "lease_expires_at": lease_expires,
                    "event": event,
                }

    def complete_delivery(
        self,
        event_id: str,
        consumer: str,
        claim_token: str,
        *,
        status: str = "success",
        error: str | None = None,
    ) -> dict[str, Any]:
        if status not in {"success", "retryable_error", "permanent_error"}:
            raise ValueError("invalid delivery completion status")
        with self.store._write_lock, self._immediate_transaction():
            event = self.event(event_id)
            if event is None:
                raise KeyError(event_id)
            row = self.store.connection.execute(
                "SELECT * FROM workflow_lifecycle_receipts WHERE event_id=? AND consumer=?",
                (event_id, consumer),
            ).fetchone()
            if (
                row is None
                or row["status"] != "processing"
                or str(row["claim_token"] or "") != claim_token
            ):
                raise RuntimeError("stale_lifecycle_claim")
            self.store.connection.execute(
                "UPDATE workflow_lifecycle_receipts SET status=?,error=?,"
                "claim_token=NULL,lease_expires_at=NULL,updated_at=? "
                "WHERE event_id=? AND consumer=? AND claim_token=?",
                (
                    status,
                    error[:2000] if error else None,
                    utc_now(),
                    event_id,
                    consumer,
                    claim_token,
                ),
            )
            if status == "success":
                self._advance_cursor_locked(
                    str(event["aggregate_id"]),
                    consumer,
                    sequence=int(event["sequence"]),
                    event_id=event_id,
                )
            self.store._advance_revision()
        return self.completion(event_id)

    def completion(self, event_id: str) -> dict[str, Any]:
        event = self.event(event_id)
        if event is None:
            raise KeyError(event_id)
        rows = self.store.connection.execute(
            "SELECT consumer,status,handler_version,payload_hash,error,updated_at "
            "FROM workflow_lifecycle_receipts WHERE event_id=? ORDER BY consumer",
            (event_id,),
        ).fetchall()
        by_consumer = {str(row["consumer"]): dict(row) for row in rows}
        required = list(event["required_consumers"])
        missing = [item for item in required if item not in by_consumer]
        failed = [
            item
            for item in required
            if item in by_consumer and by_consumer[item]["status"] != "success"
        ]
        return {
            "event_id": event_id,
            "required_consumers": required,
            "consumer_set_hash": event["consumer_set_hash"],
            "receipts": [by_consumer[item] for item in sorted(by_consumer)],
            "missing_consumers": missing,
            "failed_consumers": failed,
            "complete": not missing and not failed,
        }

    def complete_outcome(
        self,
        task_session_id: str,
        *,
        outcome_id: str,
        result: str,
    ) -> dict[str, Any]:
        with self.store._write_lock, self._immediate_transaction():
            guard = self.store.connection.execute(
                "SELECT * FROM workflow_terminal_guards WHERE task_session_id=?",
                (task_session_id,),
            ).fetchone()
            if guard is None or str(guard["canonical_outcome_id"] or "") != outcome_id:
                raise RuntimeError("canonical outcome guard mismatch")
            if guard["terminal_event_id"]:
                event = self.event(str(guard["terminal_event_id"]))
                if event is None:
                    raise RuntimeError("terminal event is missing")
                return event
            outcome_sequence = int(guard["outcome_sequence"])
            head = self.store.connection.execute(
                "SELECT last_sequence FROM workflow_lifecycle_heads WHERE task_session_id=?",
                (task_session_id,),
            ).fetchone()
            if head is None or int(head["last_sequence"]) != outcome_sequence:
                raise RuntimeError("outcome no longer owns the completion sequence")
            outcome_row = self.store.connection.execute(
                "SELECT envelope_json FROM workflow_lifecycle_events "
                "WHERE task_session_id=? AND sequence=?",
                (task_session_id, outcome_sequence),
            ).fetchone()
            if outcome_row is None:
                raise RuntimeError("canonical outcome event is missing")
            outcome_event = json.loads(str(outcome_row["envelope_json"]))
            if (
                outcome_event["event_type"] != "OutcomeRecorded.v1"
                or outcome_event["payload"].get("outcome_id") != outcome_id
            ):
                raise RuntimeError("canonical outcome event mismatch")
            completion = self.completion(outcome_event["event_id"])
            if not completion["complete"]:
                raise RuntimeError("outcome consumer receipts are incomplete")
            receipt_set_hash = hashlib.sha256(
                canonical_json(completion["receipts"]).encode("utf-8")
            ).hexdigest()
            sequence = outcome_sequence + 1
            payload = {
                "task_session_id": task_session_id,
                "outcome_id": outcome_id,
                "result": result,
                "outcome_sequence": outcome_sequence,
                "completed_receipt_set_hash": receipt_set_hash,
                "terminal_status": result,
            }
            event = self._append_event_locked(
                "TaskCompleted.v1",
                task_session_id,
                sequence=sequence,
                source_operation_key=f"task-complete:{outcome_id}",
                payload=payload,
                producer="activity-service",
                required_consumers=("workflow.audit.v1", "workflow.compatibility.v1"),
            )
            now = utc_now()
            self.store.connection.execute(
                "UPDATE workflow_terminal_guards SET terminal_event_id=?,"
                "terminal_status=?,updated_at=? WHERE task_session_id=? "
                "AND terminal_event_id IS NULL AND canonical_outcome_id=?",
                (event["event_id"], result, now, task_session_id, outcome_id),
            )
            self._set_terminal_snapshot_locked(
                task_session_id,
                event_id=event["event_id"],
                terminal_status=result,
                outcome_id=outcome_id,
            )
            self.store._advance_revision()
            return event

    def fail_task(
        self,
        task_session_id: str,
        *,
        failure_id: str,
        error_code: str,
        remediation_code: str,
        result: str = "fail",
        reason: str | None = None,
        blocking_gate_id: str | None = None,
        attempt_ids: Sequence[str] = (),
        attempts: Sequence[Mapping[str, Any]] = (),
    ) -> dict[str, Any]:
        task = self.store.session(task_session_id)
        if task is None:
            raise KeyError(task_session_id)
        normalized = result.strip().lower()
        if normalized not in {"fail", "partial", "cancelled", "blocked"}:
            raise ValueError("terminal close result must be fail, partial, cancelled, or blocked")
        event_type = "TaskFailed.v1" if normalized == "fail" else "TaskClosed.v1"
        return self.emit(
            event_type,
            task_session_id,
            source_operation_key=f"task-failed:{failure_id}",
            payload={
                "failure_id": failure_id,
                "last_state": task["state"],
                "result": normalized,
                "terminal_status": normalized,
                "terminal_kind": "failure" if normalized == "fail" else "non_pass_close",
                "reason": reason,
                "blocking_gate_id": blocking_gate_id,
                "attempt_ids": list(attempt_ids),
                "attempts": [dict(item) for item in attempts],
                "error_code": error_code,
                "retryable": False,
                "remediation_code": remediation_code,
            },
            producer="workflow-lifecycle-coordinator",
        )

    def _cursor_locked(
        self,
        task_session_id: str,
        consumer: str,
    ) -> Mapping[str, Any]:
        row = self.store.connection.execute(
            "SELECT * FROM workflow_lifecycle_cursors WHERE task_session_id=? AND consumer=?",
            (task_session_id, consumer),
        ).fetchone()
        if row is not None:
            return cast(Mapping[str, Any], row)
        now = utc_now()
        self.store.connection.execute(
            "INSERT INTO workflow_lifecycle_cursors VALUES(?,?,0,NULL,?)",
            (task_session_id, consumer, now),
        )
        row = self.store.connection.execute(
            "SELECT * FROM workflow_lifecycle_cursors WHERE task_session_id=? AND consumer=?",
            (task_session_id, consumer),
        ).fetchone()
        if row is None:
            raise RuntimeError("workflow lifecycle cursor insert did not persist")
        return cast(Mapping[str, Any], row)

    def _advance_consumer_gap_locked(
        self,
        task_session_id: str,
        consumer: str,
        *,
        target_sequence: int,
    ) -> None:
        cursor = self._cursor_locked(task_session_id, consumer)
        sequence = int(cursor["last_contiguous_sequence"]) + 1
        while sequence < target_sequence:
            row = self.store.connection.execute(
                "SELECT envelope_json FROM workflow_lifecycle_events "
                "WHERE task_session_id=? AND sequence=?",
                (task_session_id, sequence),
            ).fetchone()
            if row is None:
                raise RuntimeError("lifecycle_sequence_gap")
            event = json.loads(str(row["envelope_json"]))
            receipt = self.store.connection.execute(
                "SELECT status FROM workflow_lifecycle_receipts WHERE event_id=? AND consumer=?",
                (event["event_id"], consumer),
            ).fetchone()
            if consumer in set(event["required_consumers"]):
                if receipt is None or receipt["status"] != "success":
                    raise RuntimeError("lifecycle_consumer_gap")
            else:
                self._mark_not_elected_locked(event, consumer)
            self._advance_cursor_locked(
                task_session_id,
                consumer,
                sequence=sequence,
                event_id=str(event["event_id"]),
            )
            sequence += 1
        if sequence > target_sequence:
            raise RuntimeError("lifecycle_delivery_replay_behind_cursor")

    def _mark_not_elected_locked(
        self,
        event: Mapping[str, Any],
        consumer: str,
    ) -> None:
        payload_hash = hashlib.sha256(canonical_json(event["payload"]).encode("utf-8")).hexdigest()
        self.store.connection.execute(
            "INSERT INTO workflow_lifecycle_receipts("
            "event_id,consumer,status,handler_version,payload_hash,error,"
            "claim_token,lease_expires_at,retry_count,updated_at) "
            "VALUES(?,?,'not_elected','v1',?,NULL,NULL,NULL,0,?) "
            "ON CONFLICT(event_id,consumer) DO NOTHING",
            (event["event_id"], consumer, payload_hash, utc_now()),
        )

    def _advance_cursor_locked(
        self,
        task_session_id: str,
        consumer: str,
        *,
        sequence: int,
        event_id: str,
    ) -> None:
        cursor = self._cursor_locked(task_session_id, consumer)
        current = int(cursor["last_contiguous_sequence"])
        if current == sequence:
            return
        if current + 1 != sequence:
            raise RuntimeError("lifecycle_cursor_gap")
        updated = self.store.connection.execute(
            "UPDATE workflow_lifecycle_cursors SET last_contiguous_sequence=?,"
            "last_event_id=?,updated_at=? WHERE task_session_id=? AND consumer=? "
            "AND last_contiguous_sequence=?",
            (sequence, event_id, utc_now(), task_session_id, consumer, current),
        )
        if updated.rowcount != 1:
            raise RuntimeError("lifecycle_cursor_contention")

    def _append_event_locked(
        self,
        event_type: str,
        task_session_id: str,
        *,
        sequence: int,
        source_operation_key: str,
        payload: Mapping[str, Any],
        producer: str,
        required_consumers: tuple[str, ...],
    ) -> dict[str, Any]:
        body = dict(payload)
        body["task_session_id"] = task_session_id
        normalized_consumers = tuple(sorted(set(required_consumers)))
        consumer_set_hash = hashlib.sha256(
            canonical_json(normalized_consumers).encode("utf-8")
        ).hexdigest()
        payload_hash = hashlib.sha256(canonical_json(body).encode("utf-8")).hexdigest()
        event_id = (
            "evt_"
            + hashlib.sha256(
                canonical_json(
                    [
                        WORKFLOW_EVENT_SCHEMA,
                        task_session_id,
                        sequence,
                        event_type,
                        payload_hash,
                    ]
                ).encode("utf-8")
            ).hexdigest()[:32]
        )
        now = utc_now()
        envelope = {
            "schema_version": WORKFLOW_EVENT_SCHEMA,
            "event_id": event_id,
            "event_type": event_type,
            "aggregate_id": task_session_id,
            "sequence": sequence,
            "source_operation_key": source_operation_key,
            "occurred_at": now,
            "producer": producer,
            "required_consumers": list(normalized_consumers),
            "consumer_set_hash": consumer_set_hash,
            "payload": body,
        }
        self.store.connection.execute(
            "INSERT INTO workflow_lifecycle_events VALUES(?,?,?,?,?,?,?,?)",
            (
                event_id,
                task_session_id,
                sequence,
                event_type,
                source_operation_key,
                canonical_json(envelope),
                consumer_set_hash,
                now,
            ),
        )
        self.store.connection.execute(
            "UPDATE workflow_lifecycle_heads SET last_sequence=?,last_event_id=?,"
            "updated_at=? WHERE task_session_id=? AND last_sequence=?",
            (sequence, event_id, now, task_session_id, sequence - 1),
        )
        return envelope

    def _set_terminal_snapshot_locked(
        self,
        task_session_id: str,
        *,
        event_id: str,
        terminal_status: str,
        outcome_id: str | None,
    ) -> None:
        row = self.store.connection.execute(
            "SELECT payload_json,revision FROM task_workflow_snapshots WHERE task_session_id=?",
            (task_session_id,),
        ).fetchone()
        if row is None:
            return
        payload = json.loads(str(row["payload_json"]))
        payload.update(
            {
                "preflight_ready": False,
                "terminal_event_id": event_id,
                "terminal_status": terminal_status,
                "outcome_id": outcome_id,
            }
        )
        self.store.connection.execute(
            "UPDATE task_workflow_snapshots SET payload_json=?,revision=?,updated_at=? "
            "WHERE task_session_id=? AND revision=?",
            (
                canonical_json(payload),
                int(row["revision"]) + 1,
                utc_now(),
                task_session_id,
                int(row["revision"]),
            ),
        )

    def _set_outcome_pending_snapshot_locked(
        self,
        task_session_id: str,
        *,
        outcome_id: str,
        outcome_sequence: int,
    ) -> None:
        row = self.store.connection.execute(
            "SELECT payload_json,revision FROM task_workflow_snapshots WHERE task_session_id=?",
            (task_session_id,),
        ).fetchone()
        if row is None:
            return
        payload = json.loads(str(row["payload_json"]))
        payload.update(
            {
                "preflight_ready": False,
                "canonical_outcome_id": outcome_id,
                "outcome_sequence": outcome_sequence,
            }
        )
        self.store.connection.execute(
            "UPDATE task_workflow_snapshots SET payload_json=?,revision=?,updated_at=? "
            "WHERE task_session_id=? AND revision=?",
            (
                canonical_json(payload),
                int(row["revision"]) + 1,
                utc_now(),
                task_session_id,
                int(row["revision"]),
            ),
        )

    def project_hook_binding(
        self,
        route: str,
        identity: WorkflowIdentity,
        *,
        identifiers: Mapping[str, str],
        host_agent_session_id: str,
        lifecycle_event_id: str | None,
        lifecycle_sequence: int | None,
    ) -> dict[str, Any]:
        if self._read_only:
            raise PermissionError("read-only lifecycle coordinator cannot project hook state")
        validation = self.validate_hook_event(
            route,
            identity,
            identifiers=identifiers,
            lifecycle_event_id=lifecycle_event_id,
            lifecycle_sequence=lifecycle_sequence,
        )
        if not validation["ok"]:
            return {"projected": False, "reason": validation["reason"]}
        event = dict(validation["event"])
        current = self.store.workflow_snapshot(identity.task_session_id)
        projected = {
            key: value
            for key, value in dict(current or {}).items()
            if key
            not in {
                "task_session_id",
                "pack_id",
                "plan_id",
                "revision",
                "updated_at",
            }
        }
        projected.update(
            {
                "last_lifecycle_event_id": event["event_id"],
                "last_lifecycle_sequence": event["sequence"],
                "host_agent_session_id": host_agent_session_id,
                "governance_revision": identity.governance_revision,
            }
        )
        if route in {"codex.preflight", "workflow.start"}:
            projected.update(
                {
                    "preflight_ready": True,
                    "preflight_governance_revision": identity.governance_revision,
                }
            )
        if route in {"outcome"}:
            projected.update(
                {
                    "preflight_ready": False,
                    "terminal_status": identity.terminal_status or "completed",
                    "terminal_event_id": identity.terminal_event_id,
                }
            )
        snapshot = self.store.save_workflow_snapshot(
            identity.task_session_id,
            payload=projected,
            pack_id=identity.pack_id,
            plan_id=identity.plan_id,
            expected_revision=int(current["revision"]) if current is not None else 0,
            idempotency_key=None,
        )
        return {"projected": True, "event": event, "snapshot": dict(snapshot)}

    def validate_hook_event(
        self,
        route: str,
        identity: WorkflowIdentity,
        *,
        identifiers: Mapping[str, str],
        lifecycle_event_id: str | None,
        lifecycle_sequence: int | None,
    ) -> dict[str, Any]:
        event_types = _ROUTE_EVENTS.get(route)
        if event_types is None:
            return {"ok": False, "reason": "route_not_mutating"}
        if lifecycle_event_id is None or lifecycle_sequence is None:
            return {"ok": False, "reason": "missing_lifecycle_event"}
        event = self.event(lifecycle_event_id)
        if event is None:
            return {"ok": False, "reason": "lifecycle_event_not_found"}
        if (
            event["event_type"] not in event_types
            or event["aggregate_id"] != identity.task_session_id
            or int(event["sequence"]) != lifecycle_sequence
        ):
            return {"ok": False, "reason": "lifecycle_event_mismatch"}
        event_payload = dict(event.get("payload") or {})
        if any(
            event_payload.get(key) not in {None, value}
            for key, value in identifiers.items()
            if key != "agent_session_id"
        ):
            return {"ok": False, "reason": "lifecycle_identifier_mismatch"}
        return {"ok": True, "reason": "ok", "event": event}

    def event(self, event_id: str) -> dict[str, Any] | None:
        row = self.store.connection.execute(
            "SELECT envelope_json FROM workflow_lifecycle_events WHERE event_id=?",
            (event_id,),
        ).fetchone()
        return json.loads(str(row[0])) if row is not None else None

    def events(self, task_session_id: str) -> list[dict[str, Any]]:
        return [
            json.loads(str(row[0]))
            for row in self.store.connection.execute(
                "SELECT envelope_json FROM workflow_lifecycle_events "
                "WHERE task_session_id=? ORDER BY sequence",
                (task_session_id,),
            ).fetchall()
        ]


__all__ = ["WORKFLOW_EVENT_SCHEMA", "WorkflowLifecycleCoordinator"]


def _parse_utc(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)
