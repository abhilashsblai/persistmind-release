from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from persistmind.utils import canonical_json, sha256_text


def transition_hash(
    task_session_id: str,
    from_state: str | None,
    to_state: str,
    actor: str,
    reason: str | None,
    pack_id: str | None,
    constitution_hash: str | None,
    previous_hash: str,
) -> str:
    """Hash the complete durable transition identity."""

    return sha256_text(
        canonical_json(
            {
                "actor": actor,
                "constitution_hash": constitution_hash,
                "from_state": from_state,
                "pack_id": pack_id,
                "prev_hash": previous_hash,
                "reason": reason,
                "task_session_id": task_session_id,
                "to_state": to_state,
            }
        )
    )


def verify_transition_chain(
    task_session_id: str,
    transitions: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Verify sequence, state, and hashes with a bounded legacy compatibility rule.

    Older writers persisted an inherited pack ID but hashed ``None`` when the
    caller omitted ``--pack-id``. That exact, recognizable encoding remains
    readable without rewriting history; every new transition uses the canonical
    effective pack ID.
    """

    previous_state: str | None = None
    previous_hash = ""
    previous_pack_id: str | None = None
    compatibility: list[dict[str, str]] = []
    for expected_sequence, transition in enumerate(transitions, start=1):
        sequence = int(transition.get("sequence") or 0)
        from_state = transition.get("from_state")
        to_state = str(transition.get("to_state") or "")
        actor = str(transition.get("last_actor") or "system")
        reason = transition.get("last_reason")
        pack_id = str(transition.get("pack_id") or "") or None
        constitution_hash = transition.get("constitution_hash")
        observed_hash = str(transition.get("transition_hash") or "")
        expected_hash = transition_hash(
            task_session_id,
            from_state,
            to_state,
            actor,
            reason,
            pack_id,
            constitution_hash,
            previous_hash,
        )
        legacy_hash = None
        if expected_sequence > 1 and pack_id and pack_id == previous_pack_id:
            legacy_hash = transition_hash(
                task_session_id,
                from_state,
                to_state,
                actor,
                reason,
                None,
                constitution_hash,
                previous_hash,
            )
        hash_mode = (
            "canonical"
            if observed_hash == expected_hash
            else "inherited_pack_omission_v1"
            if legacy_hash and observed_hash == legacy_hash
            else "invalid"
        )
        state_valid = (expected_sequence == 1 and from_state is None) or (
            expected_sequence > 1 and from_state == previous_state
        )
        link_valid = transition.get("prev_hash") == previous_hash
        if (
            sequence != expected_sequence
            or not state_valid
            or not link_valid
            or hash_mode == "invalid"
        ):
            return {
                "ok": False,
                "task_session_id": task_session_id,
                "transition_id": transition.get("transition_id"),
                "expected_sequence": expected_sequence,
                "observed_sequence": sequence,
                "expected_from_state": previous_state,
                "observed_from_state": from_state,
                "hash_link_valid": link_valid,
                "transition_hash_valid": hash_mode != "invalid",
            }
        if hash_mode != "canonical":
            compatibility.append(
                {
                    "transition_id": str(transition.get("transition_id") or ""),
                    "mode": hash_mode,
                }
            )
        previous_state = to_state
        previous_hash = observed_hash
        previous_pack_id = pack_id
    return {
        "ok": True,
        "kind": "sequence_state_and_hash_linkage",
        "rows": len(transitions),
        "tip": previous_hash,
        "compatibility": compatibility,
    }


__all__ = ["transition_hash", "verify_transition_chain"]
