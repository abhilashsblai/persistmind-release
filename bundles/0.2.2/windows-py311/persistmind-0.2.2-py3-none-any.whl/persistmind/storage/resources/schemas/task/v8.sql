CREATE TABLE IF NOT EXISTS task_envelopes(
    task_session_id TEXT NOT NULL REFERENCES task_sessions(task_session_id),
    revision INTEGER NOT NULL CHECK(revision > 0),
    envelope_json TEXT NOT NULL,
    envelope_hash TEXT NOT NULL UNIQUE CHECK(envelope_hash GLOB 'sha256:[0-9a-f]*' AND length(envelope_hash) = 71),
    actor TEXT NOT NULL CHECK(length(actor) > 0),
    frozen_at TEXT,
    created_at TEXT NOT NULL,
    PRIMARY KEY(task_session_id,revision)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_task_envelopes_one_frozen ON task_envelopes(task_session_id) WHERE frozen_at IS NOT NULL;

CREATE TABLE IF NOT EXISTS task_hypotheses(
    hypothesis_id TEXT PRIMARY KEY CHECK(length(hypothesis_id) > 0),
    task_session_id TEXT NOT NULL REFERENCES task_sessions(task_session_id),
    proposition_hash TEXT NOT NULL CHECK(proposition_hash GLOB 'sha256:[0-9a-f]*' AND length(proposition_hash) = 71),
    state TEXT NOT NULL CHECK(state IN ('proposed','supported','refuted','contested','unknown','superseded')),
    support_json TEXT NOT NULL,
    assumptions_json TEXT NOT NULL,
    revision INTEGER NOT NULL CHECK(revision > 0),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_task_hypotheses_session ON task_hypotheses(task_session_id,state,updated_at DESC);

CREATE TABLE IF NOT EXISTS task_uncertainty_snapshots(
    snapshot_id TEXT PRIMARY KEY CHECK(length(snapshot_id) > 0),
    task_session_id TEXT NOT NULL REFERENCES task_sessions(task_session_id),
    phase TEXT NOT NULL CHECK(length(phase) > 0),
    metrics_json TEXT NOT NULL,
    recommended_resolution TEXT NOT NULL CHECK(recommended_resolution IN ('unsafe','not_authorized','contradictory','underspecified','external_dependency','not_computable','intractable','unidentifiable','unknown','candidate','bounded_approximation','verified')),
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_task_uncertainty_session ON task_uncertainty_snapshots(task_session_id,created_at DESC);

CREATE TABLE IF NOT EXISTS task_decision_points(
    decision_id TEXT PRIMARY KEY CHECK(length(decision_id) > 0),
    task_session_id TEXT NOT NULL REFERENCES task_sessions(task_session_id),
    action_set_hash TEXT NOT NULL CHECK(action_set_hash GLOB 'sha256:[0-9a-f]*' AND length(action_set_hash) = 71),
    chosen_action TEXT NOT NULL CHECK(length(chosen_action) > 0),
    utility_json TEXT NOT NULL,
    risk_json TEXT NOT NULL,
    policy_decision_id TEXT,
    policy_decision_hash TEXT CHECK(policy_decision_hash IS NULL OR (policy_decision_hash GLOB 'sha256:[0-9a-f]*' AND length(policy_decision_hash) = 71)),
    created_at TEXT NOT NULL,
    CHECK((policy_decision_id IS NULL) = (policy_decision_hash IS NULL))
);
CREATE INDEX IF NOT EXISTS idx_task_decisions_session ON task_decision_points(task_session_id,created_at DESC);
