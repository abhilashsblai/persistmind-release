CREATE TABLE IF NOT EXISTS incident_occurrences (
  occurrence_id TEXT PRIMARY KEY,
  kind TEXT NOT NULL CHECK(kind IN ('incident','feedback')),
  status TEXT NOT NULL CHECK(status IN ('new','reviewed','exported','submitted','closed')),
  severity TEXT NOT NULL,
  category TEXT NOT NULL,
  cie_domain TEXT NOT NULL,
  source TEXT NOT NULL,
  created_at TEXT NOT NULL,
  relative_path TEXT NOT NULL UNIQUE,
  content_digest TEXT NOT NULL,
  content_size INTEGER NOT NULL CHECK(content_size >= 0),
  repo_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL,
  operation_id TEXT,
  correlation_id TEXT,
  pack_id TEXT,
  snapshot_id TEXT,
  generation_id TEXT,
  automatic_trigger TEXT,
  error_fingerprint TEXT,
  exported_at TEXT,
  submitted_at TEXT,
  UNIQUE(operation_id, automatic_trigger, error_fingerprint)
);
CREATE INDEX IF NOT EXISTS idx_incident_occurrences_query ON incident_occurrences(kind,status,severity,category,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_incident_occurrences_operation ON incident_occurrences(operation_id,pack_id,error_fingerprint);
CREATE TABLE IF NOT EXISTS incident_exports (
  export_id TEXT PRIMARY KEY,
  occurrence_id TEXT NOT NULL REFERENCES incident_occurrences(occurrence_id),
  package_path TEXT NOT NULL,
  package_digest TEXT NOT NULL UNIQUE,
  package_size INTEGER NOT NULL CHECK(package_size >= 0),
  sanitizer_version TEXT NOT NULL,
  privacy_verdict TEXT NOT NULL CHECK(privacy_verdict IN ('pass','warning','blocked')),
  reviewer TEXT NOT NULL,
  warnings_acknowledged INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_incident_exports_occurrence ON incident_exports(occurrence_id,created_at DESC);
CREATE TABLE IF NOT EXISTS incident_submission_receipts (
  receipt_id TEXT PRIMARY KEY,
  export_id TEXT NOT NULL REFERENCES incident_exports(export_id),
  collector TEXT NOT NULL,
  idempotency_key TEXT NOT NULL UNIQUE,
  package_digest TEXT NOT NULL,
  status TEXT NOT NULL,
  remote_occurrence_id TEXT,
  receipt_json TEXT NOT NULL,
  submitted_at TEXT NOT NULL
);
