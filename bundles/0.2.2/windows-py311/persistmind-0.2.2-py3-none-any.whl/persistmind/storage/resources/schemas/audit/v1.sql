CREATE TABLE IF NOT EXISTS audit_records(audit_id TEXT PRIMARY KEY,partition_id TEXT,sequence INTEGER NOT NULL,event_hash TEXT NOT NULL,prev_hash TEXT NOT NULL,principal TEXT NOT NULL,payload_json TEXT NOT NULL,idempotency_key TEXT NOT NULL UNIQUE,created_at TEXT NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS idx_audit_records_sequence ON audit_records(sequence);
CREATE TABLE IF NOT EXISTS audit_partitions(partition_id TEXT PRIMARY KEY,state TEXT NOT NULL,record_count INTEGER NOT NULL,root_hash TEXT NOT NULL,sealed_at TEXT NOT NULL,anchor_id TEXT);
CREATE TABLE IF NOT EXISTS audit_anchors(anchor_id TEXT PRIMARY KEY,partition_id TEXT NOT NULL,root_hash TEXT NOT NULL,signature TEXT NOT NULL,principal TEXT NOT NULL,anchored_at TEXT NOT NULL);
