CREATE TABLE IF NOT EXISTS runtime_process_registry (
  owner_kind TEXT NOT NULL,
  owner_id TEXT NOT NULL,
  process_id INTEGER NOT NULL,
  started_at TEXT NOT NULL,
  state TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY(owner_kind, owner_id)
);

CREATE INDEX IF NOT EXISTS idx_runtime_process_registry_state
  ON runtime_process_registry(state, updated_at);
