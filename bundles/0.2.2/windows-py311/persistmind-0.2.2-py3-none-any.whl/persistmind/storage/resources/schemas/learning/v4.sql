CREATE TABLE IF NOT EXISTS learning_field_experiments(
    experiment_id TEXT PRIMARY KEY CHECK(length(experiment_id) > 0),
    protocol_hash TEXT NOT NULL CHECK(protocol_hash GLOB 'sha256:[0-9a-f]*' AND length(protocol_hash) = 71),
    status TEXT NOT NULL CHECK(status IN ('proposed','approved','running','frozen','decided','rejected','suspended','completed')),
    baseline_version TEXT NOT NULL,
    candidate_version TEXT NOT NULL,
    assignment_key_id TEXT NOT NULL,
    metric_version TEXT NOT NULL,
    policy_approval_id TEXT NOT NULL,
    policy_approval_hash TEXT NOT NULL CHECK(policy_approval_hash GLOB 'sha256:[0-9a-f]*' AND length(policy_approval_hash) = 71),
    started_at TEXT,
    frozen_at TEXT,
    decided_at TEXT,
    CHECK(status IN ('proposed','approved') OR started_at IS NOT NULL),
    CHECK(status NOT IN ('frozen','decided','completed') OR frozen_at IS NOT NULL),
    CHECK(status NOT IN ('decided','completed') OR decided_at IS NOT NULL)
);

CREATE TABLE IF NOT EXISTS learning_field_observations(
    observation_id TEXT PRIMARY KEY CHECK(length(observation_id) > 0),
    experiment_id TEXT NOT NULL REFERENCES learning_field_experiments(experiment_id),
    assignment_unit_type TEXT NOT NULL CHECK(assignment_unit_type IN ('root','memory_cluster')),
    assignment_unit_id TEXT NOT NULL,
    root_task_id TEXT,
    task_session_id TEXT,
    task_envelope_hash TEXT,
    outcome_membership_hash TEXT NOT NULL CHECK(outcome_membership_hash GLOB 'sha256:[0-9a-f]*' AND length(outcome_membership_hash) = 71),
    assignment TEXT NOT NULL CHECK(assignment IN ('baseline','candidate')),
    stratum TEXT NOT NULL,
    metrics_json TEXT NOT NULL,
    artifact_identity_json TEXT NOT NULL,
    outcome_deadline TEXT NOT NULL,
    field_outcome_event_id TEXT NOT NULL,
    field_outcome_payload_hash TEXT NOT NULL CHECK(field_outcome_payload_hash GLOB 'sha256:[0-9a-f]*' AND length(field_outcome_payload_hash) = 71),
    observation_hash TEXT NOT NULL UNIQUE CHECK(observation_hash GLOB 'sha256:[0-9a-f]*' AND length(observation_hash) = 71),
    observed_at TEXT NOT NULL,
    enrollment_sequence INTEGER NOT NULL CHECK(enrollment_sequence > 0),
    UNIQUE(experiment_id,assignment_unit_id),
    UNIQUE(experiment_id,enrollment_sequence),
    CHECK((assignment_unit_type='root' AND root_task_id IS NOT NULL AND task_session_id IS NOT NULL AND task_envelope_hash IS NOT NULL) OR (assignment_unit_type='memory_cluster' AND root_task_id IS NULL AND task_session_id IS NULL AND task_envelope_hash IS NULL))
);
CREATE INDEX IF NOT EXISTS idx_learning_observations_stratum ON learning_field_observations(experiment_id,stratum,assignment,observed_at);

CREATE TABLE IF NOT EXISTS learning_candidate_lineage(
    edge_id TEXT PRIMARY KEY CHECK(length(edge_id) > 0),
    version_id TEXT NOT NULL REFERENCES skill_versions(version_id),
    parent_version_id TEXT NOT NULL REFERENCES skill_versions(version_id),
    relation TEXT NOT NULL CHECK(relation IN ('mutation','merge','refinement','rollback','import')),
    mutation_hash TEXT NOT NULL CHECK(mutation_hash GLOB 'sha256:[0-9a-f]*' AND length(mutation_hash) = 71),
    proposer_identity TEXT NOT NULL,
    protected_surface_hash TEXT NOT NULL CHECK(protected_surface_hash GLOB 'sha256:[0-9a-f]*' AND length(protected_surface_hash) = 71),
    created_at TEXT NOT NULL,
    CHECK(version_id <> parent_version_id),
    UNIQUE(version_id,parent_version_id,relation)
);
CREATE INDEX IF NOT EXISTS idx_learning_lineage_parent ON learning_candidate_lineage(parent_version_id,version_id);

CREATE TABLE IF NOT EXISTS learning_promotion_decisions(
    decision_id TEXT PRIMARY KEY CHECK(length(decision_id) > 0),
    version_id TEXT NOT NULL REFERENCES skill_versions(version_id),
    experiment_id TEXT NOT NULL REFERENCES learning_field_experiments(experiment_id),
    statistics_json TEXT NOT NULL,
    policy_decision_id TEXT NOT NULL,
    policy_decision_hash TEXT NOT NULL CHECK(policy_decision_hash GLOB 'sha256:[0-9a-f]*' AND length(policy_decision_hash) = 71),
    state TEXT NOT NULL CHECK(state IN ('approved','rejected','canary','active','suspended','rolled_back')),
    rollback_version_id TEXT REFERENCES skill_versions(version_id),
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_learning_promotion_version ON learning_promotion_decisions(version_id,created_at DESC);
