CREATE TABLE IF NOT EXISTS domain_operation_receipts(
    operation_id TEXT PRIMARY KEY,
    operation_type TEXT NOT NULL,
    plan_hash TEXT NOT NULL,
    state TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_domain_operation_receipts_state
    ON domain_operation_receipts(state,updated_at,operation_id);
CREATE TABLE IF NOT EXISTS domain_legal_holds(
    hold_id TEXT PRIMARY KEY,
    scope_hash TEXT NOT NULL,
    reason TEXT NOT NULL,
    state TEXT NOT NULL CHECK(state IN ('active','released')),
    created_at TEXT NOT NULL,
    released_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_domain_legal_holds_scope
    ON domain_legal_holds(scope_hash,state);
CREATE TABLE IF NOT EXISTS domain_erasure_tombstones(
    tombstone_id TEXT PRIMARY KEY,
    scope_hash TEXT NOT NULL,
    state TEXT NOT NULL,
    blocker TEXT,
    next_eligible_at TEXT,
    evidence_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_domain_erasure_tombstones_scope
    ON domain_erasure_tombstones(scope_hash,state);
