CREATE TABLE IF NOT EXISTS knowledge_claim_relations(
    relation_id TEXT PRIMARY KEY CHECK(length(relation_id) > 0),
    subject_id TEXT NOT NULL REFERENCES domain_records(record_id),
    predicate TEXT NOT NULL CHECK(length(predicate) > 0),
    object_id TEXT NOT NULL REFERENCES domain_records(record_id),
    evidence_id TEXT REFERENCES knowledge_evidence(evidence_id),
    support_score REAL CHECK(support_score IS NULL OR (support_score >= 0 AND support_score <= 1)),
    valid_from TEXT NOT NULL,
    valid_to TEXT,
    created_at TEXT NOT NULL,
    CHECK(valid_to IS NULL OR valid_to >= valid_from)
);
CREATE INDEX IF NOT EXISTS idx_knowledge_relations_subject ON knowledge_claim_relations(subject_id,predicate,valid_from);
CREATE INDEX IF NOT EXISTS idx_knowledge_relations_object ON knowledge_claim_relations(object_id,predicate,valid_from);
CREATE INDEX IF NOT EXISTS idx_knowledge_relations_predicate ON knowledge_claim_relations(predicate,valid_to,relation_id);

CREATE TABLE IF NOT EXISTS knowledge_forecasts(
    forecast_id TEXT PRIMARY KEY CHECK(length(forecast_id) > 0),
    claim_id TEXT NOT NULL REFERENCES domain_records(record_id),
    probability REAL NOT NULL CHECK(probability >= 0 AND probability <= 1),
    support_score REAL CHECK(support_score IS NULL OR (support_score >= 0 AND support_score <= 1)),
    calibrator_id TEXT NOT NULL CHECK(length(calibrator_id) > 0),
    stratum TEXT NOT NULL CHECK(length(stratum) > 0),
    context_hash TEXT NOT NULL CHECK(context_hash GLOB 'sha256:[0-9a-f]*' AND length(context_hash) = 71),
    predicted_at TEXT NOT NULL,
    resolves_by TEXT NOT NULL CHECK(resolves_by >= predicted_at)
);
CREATE INDEX IF NOT EXISTS idx_knowledge_forecasts_claim ON knowledge_forecasts(claim_id,predicted_at DESC);
CREATE INDEX IF NOT EXISTS idx_knowledge_forecasts_stratum ON knowledge_forecasts(stratum,predicted_at,forecast_id);
CREATE INDEX IF NOT EXISTS idx_knowledge_forecasts_unresolved ON knowledge_forecasts(resolves_by,forecast_id);

CREATE TABLE IF NOT EXISTS knowledge_forecast_outcomes(
    forecast_id TEXT PRIMARY KEY REFERENCES knowledge_forecasts(forecast_id),
    outcome INTEGER NOT NULL CHECK(outcome IN (0,1)),
    evidence_id TEXT NOT NULL REFERENCES knowledge_evidence(evidence_id),
    observed_at TEXT NOT NULL
);
CREATE TRIGGER IF NOT EXISTS trg_knowledge_forecast_outcome_time
BEFORE INSERT ON knowledge_forecast_outcomes
BEGIN
  SELECT CASE WHEN NEW.observed_at < (SELECT predicted_at FROM knowledge_forecasts WHERE forecast_id=NEW.forecast_id)
    THEN RAISE(ABORT,'forecast outcome precedes prediction') END;
END;
