CREATE TABLE IF NOT EXISTS knowledge_claim_relations(
    relation_id TEXT PRIMARY KEY CHECK(length(relation_id) > 0),
    subject_id TEXT NOT NULL REFERENCES domain_records(record_id),
    predicate TEXT NOT NULL CHECK(length(predicate) > 0),
    object_id TEXT NOT NULL REFERENCES domain_records(record_id),
    evidence_id TEXT REFERENCES knowledge_evidence(evidence_id),
    support_score REAL CHECK(support_score IS NULL OR (support_score >= 0 AND support_score <= 1)),
    valid_from TEXT NOT NULL,
    valid_to TEXT,
    created_at TEXT NOT NULL,
    CHECK(valid_to IS NULL OR valid_to >= valid_from)
);
CREATE INDEX IF NOT EXISTS idx_knowledge_relations_subject ON knowledge_claim_relations(subject_id,predicate,valid_from);
CREATE INDEX IF NOT EXISTS idx_knowledge_relations_object ON knowledge_claim_relations(object_id,predicate,valid_from);
CREATE INDEX IF NOT EXISTS idx_knowledge_relations_predicate ON knowledge_claim_relations(predicate,valid_to,relation_id);

CREATE INDEX IF NOT EXISTS idx_knowledge_memory_status_type_updated
    ON domain_records(
        kind,
        json_extract(payload_json,'$.status'),
        json_extract(payload_json,'$.type'),
        updated_at DESC,
        record_id
    )
    WHERE kind='persistmind.knowledge_memory.v1';

CREATE TABLE IF NOT EXISTS memory_edges(
    edge_id TEXT PRIMARY KEY CHECK(length(edge_id) > 0),
    src_record_id TEXT NOT NULL REFERENCES domain_records(record_id) ON DELETE CASCADE,
    dst_record_id TEXT NOT NULL REFERENCES domain_records(record_id) ON DELETE CASCADE,
    kind TEXT NOT NULL CHECK(kind IN (
        'supersedes',
        'contradicts',
        'derived_from',
        'causes',
        'co_occurs_with',
        'relates_to'
    )),
    weight REAL NOT NULL DEFAULT 1.0 CHECK(weight >= 0 AND weight <= 1),
    evidence_json TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(src_record_id,dst_record_id,kind)
);
CREATE INDEX IF NOT EXISTS idx_memory_edges_src ON memory_edges(src_record_id,kind,dst_record_id);
CREATE INDEX IF NOT EXISTS idx_memory_edges_dst ON memory_edges(dst_record_id,kind,src_record_id);

CREATE TABLE IF NOT EXISTS memory_conflicts(
    conflict_id TEXT PRIMARY KEY CHECK(length(conflict_id) > 0),
    left_record_id TEXT NOT NULL REFERENCES domain_records(record_id) ON DELETE CASCADE,
    right_record_id TEXT NOT NULL REFERENCES domain_records(record_id) ON DELETE CASCADE,
    subject_key TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT 'semantic_conflict',
    summary TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT 'medium',
    status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','resolved','ignored')),
    detected_at TEXT NOT NULL,
    resolved_at TEXT,
    metadata_json TEXT NOT NULL DEFAULT '{}',
    UNIQUE(left_record_id,right_record_id,kind)
);
CREATE INDEX IF NOT EXISTS idx_memory_conflicts_status ON memory_conflicts(status,subject_key,detected_at DESC);

CREATE TABLE IF NOT EXISTS memory_vectors(
    record_id TEXT NOT NULL REFERENCES domain_records(record_id) ON DELETE CASCADE,
    model_name TEXT NOT NULL,
    dims INTEGER NOT NULL CHECK(dims > 0),
    encoding TEXT NOT NULL DEFAULT 'json',
    vector_blob BLOB NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(record_id,model_name)
);
CREATE INDEX IF NOT EXISTS idx_memory_vectors_updated ON memory_vectors(updated_at DESC,record_id);

CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_memory_fts USING fts5(
    record_id UNINDEXED,
    assertion,
    title,
    metadata,
    tokenize='unicode61'
);

CREATE TABLE IF NOT EXISTS working_memory_notes(
    note_id TEXT PRIMARY KEY CHECK(length(note_id) > 0),
    task_session_id TEXT,
    content TEXT NOT NULL,
    salience REAL NOT NULL DEFAULT 0.5 CHECK(salience >= 0 AND salience <= 1),
    metadata_json TEXT NOT NULL DEFAULT '{}',
    superseded_by TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    expires_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_working_memory_active
    ON working_memory_notes(superseded_by,expires_at,updated_at DESC,note_id);

CREATE TABLE IF NOT EXISTS knowledge_forecasts(
    forecast_id TEXT PRIMARY KEY CHECK(length(forecast_id) > 0),
    claim_id TEXT NOT NULL REFERENCES domain_records(record_id),
    probability REAL NOT NULL CHECK(probability >= 0 AND probability <= 1),
    support_score REAL CHECK(support_score IS NULL OR (support_score >= 0 AND support_score <= 1)),
    calibrator_id TEXT NOT NULL CHECK(length(calibrator_id) > 0),
    stratum TEXT NOT NULL CHECK(length(stratum) > 0),
    context_hash TEXT NOT NULL CHECK(context_hash GLOB 'sha256:[0-9a-f]*' AND length(context_hash) = 71),
    predicted_at TEXT NOT NULL,
    resolves_by TEXT NOT NULL CHECK(resolves_by >= predicted_at)
);
CREATE INDEX IF NOT EXISTS idx_knowledge_forecasts_claim ON knowledge_forecasts(claim_id,predicted_at DESC);
CREATE INDEX IF NOT EXISTS idx_knowledge_forecasts_stratum ON knowledge_forecasts(stratum,predicted_at,forecast_id);
CREATE INDEX IF NOT EXISTS idx_knowledge_forecasts_unresolved ON knowledge_forecasts(resolves_by,forecast_id);

CREATE TABLE IF NOT EXISTS knowledge_forecast_outcomes(
    forecast_id TEXT PRIMARY KEY REFERENCES knowledge_forecasts(forecast_id),
    outcome INTEGER NOT NULL CHECK(outcome IN (0,1)),
    evidence_id TEXT NOT NULL REFERENCES knowledge_evidence(evidence_id),
    observed_at TEXT NOT NULL
);
CREATE TRIGGER IF NOT EXISTS trg_knowledge_forecast_outcome_time
BEFORE INSERT ON knowledge_forecast_outcomes
BEGIN
  SELECT CASE WHEN NEW.observed_at < (SELECT predicted_at FROM knowledge_forecasts WHERE forecast_id=NEW.forecast_id)
    THEN RAISE(ABORT,'forecast outcome precedes prediction') END;
END;
