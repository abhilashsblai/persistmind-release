CREATE TABLE IF NOT EXISTS activity_events(event_id TEXT PRIMARY KEY,event_type TEXT NOT NULL,payload_json TEXT NOT NULL,idempotency_key TEXT NOT NULL UNIQUE,occurred_at TEXT NOT NULL,committed_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_activity_events_time ON activity_events(committed_at,event_type,event_id);
CREATE TABLE IF NOT EXISTS activity_partitions(partition_id TEXT PRIMARY KEY,state TEXT NOT NULL,min_created_at TEXT,max_created_at TEXT,event_count INTEGER NOT NULL DEFAULT 0,content_hash TEXT,sealed_at TEXT);
