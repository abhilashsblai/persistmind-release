CREATE TABLE IF NOT EXISTS policy_safety_constraints(
    constraint_id TEXT PRIMARY KEY CHECK(length(constraint_id) > 0),
    contract_version TEXT NOT NULL,
    predicate_json TEXT NOT NULL,
    risk_floor TEXT NOT NULL CHECK(risk_floor IN ('low','medium','high','critical')),
    fail_state TEXT NOT NULL CHECK(fail_state IN ('not_authorized','unsafe','unknown')),
    content_hash TEXT NOT NULL UNIQUE CHECK(content_hash GLOB 'sha256:[0-9a-f]*' AND length(content_hash) = 71),
    required_quorum INTEGER NOT NULL CHECK(required_quorum IN (1,2)),
    valid_from TEXT NOT NULL,
    valid_to TEXT,
    CHECK(valid_to IS NULL OR valid_to >= valid_from),
    CHECK(risk_floor <> 'critical' OR required_quorum = 2)
);

CREATE TABLE IF NOT EXISTS policy_autonomy_grants(
    grant_id TEXT PRIMARY KEY CHECK(length(grant_id) > 0),
    capability TEXT NOT NULL CHECK(capability NOT IN ('policy','audit','evaluator','release_signing','key_management','kill_switch')),
    artifact_version TEXT NOT NULL,
    scope_json TEXT NOT NULL,
    maximum_risk TEXT NOT NULL CHECK(maximum_risk IN ('low','medium','high','critical')),
    maximum_uses INTEGER NOT NULL CHECK(maximum_uses > 0),
    expires_at TEXT NOT NULL,
    required_quorum INTEGER NOT NULL CHECK(required_quorum IN (1,2)),
    state TEXT NOT NULL CHECK(state IN ('proposed','active','suspended','revoked','expired','exhausted')),
    created_at TEXT NOT NULL,
    CHECK(maximum_risk <> 'critical' OR required_quorum = 2)
);

CREATE TABLE IF NOT EXISTS policy_experiment_approvals(
    experiment_id TEXT PRIMARY KEY CHECK(length(experiment_id) > 0),
    protocol_hash TEXT NOT NULL CHECK(protocol_hash GLOB 'sha256:[0-9a-f]*' AND length(protocol_hash) = 71),
    allowed_scope_json TEXT NOT NULL,
    required_quorum INTEGER NOT NULL CHECK(required_quorum IN (1,2)),
    expires_at TEXT NOT NULL,
    state TEXT NOT NULL CHECK(state IN ('approved','suspended','revoked','expired'))
);

CREATE TABLE IF NOT EXISTS policy_experiment_assignments(
    experiment_id TEXT NOT NULL REFERENCES policy_experiment_approvals(experiment_id),
    assignment_unit_id TEXT NOT NULL,
    assignment TEXT NOT NULL CHECK(assignment IN ('baseline','candidate')),
    assignment_receipt_hash TEXT NOT NULL UNIQUE CHECK(assignment_receipt_hash GLOB 'sha256:[0-9a-f]*' AND length(assignment_receipt_hash) = 71),
    committed_at TEXT NOT NULL,
    PRIMARY KEY(experiment_id,assignment_unit_id)
);

CREATE TABLE IF NOT EXISTS policy_signing_keys(
    key_id TEXT PRIMARY KEY CHECK(length(key_id) > 0),
    principal_id TEXT NOT NULL CHECK(length(principal_id) > 0),
    algorithm TEXT NOT NULL CHECK(algorithm='Ed25519'),
    public_key TEXT NOT NULL,
    fingerprint TEXT NOT NULL UNIQUE,
    valid_from TEXT NOT NULL,
    valid_to TEXT,
    created_at TEXT NOT NULL,
    CHECK(valid_to IS NULL OR valid_to >= valid_from)
);

CREATE TABLE IF NOT EXISTS policy_decision_signatures(
    signature_id TEXT PRIMARY KEY CHECK(length(signature_id) > 0),
    subject_type TEXT NOT NULL,
    subject_id TEXT NOT NULL,
    principal_id TEXT NOT NULL,
    key_id TEXT NOT NULL REFERENCES policy_signing_keys(key_id),
    algorithm TEXT NOT NULL CHECK(algorithm='Ed25519'),
    document_hash TEXT NOT NULL CHECK(document_hash GLOB 'sha256:[0-9a-f]*' AND length(document_hash) = 71),
    signature TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(subject_type,subject_id,key_id)
);

CREATE TABLE IF NOT EXISTS policy_signing_key_transitions(
    transition_id TEXT PRIMARY KEY CHECK(length(transition_id) > 0),
    key_id TEXT NOT NULL REFERENCES policy_signing_keys(key_id),
    from_state TEXT,
    to_state TEXT NOT NULL CHECK(to_state IN ('active','suspended','revoked','expired')),
    reason TEXT NOT NULL,
    authorized_decision_id TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS policy_grant_transitions(
    transition_id TEXT PRIMARY KEY CHECK(length(transition_id) > 0),
    grant_id TEXT NOT NULL REFERENCES policy_autonomy_grants(grant_id),
    from_state TEXT,
    to_state TEXT NOT NULL CHECK(to_state IN ('active','suspended','revoked','expired','exhausted')),
    actor TEXT NOT NULL,
    reason TEXT NOT NULL,
    decision_document_hash TEXT NOT NULL CHECK(decision_document_hash GLOB 'sha256:[0-9a-f]*' AND length(decision_document_hash) = 71),
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS policy_grant_uses(
    use_id TEXT PRIMARY KEY,
    grant_id TEXT NOT NULL REFERENCES policy_autonomy_grants(grant_id),
    task_session_id TEXT NOT NULL,
    capability TEXT NOT NULL,
    action_hash TEXT NOT NULL CHECK(action_hash GLOB 'sha256:[0-9a-f]*' AND length(action_hash) = 71),
    used_at TEXT NOT NULL,
    UNIQUE(grant_id,task_session_id,action_hash)
);

CREATE TABLE IF NOT EXISTS policy_governance_proposals(
    proposal_id TEXT PRIMARY KEY,
    proposal_type TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    payload_hash TEXT NOT NULL UNIQUE CHECK(payload_hash GLOB 'sha256:[0-9a-f]*' AND length(payload_hash) = 71),
    state TEXT NOT NULL CHECK(state IN ('proposed','adopted','rejected','rolled_back')),
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS policy_governance_transitions(
    transition_id TEXT PRIMARY KEY,
    proposal_id TEXT NOT NULL REFERENCES policy_governance_proposals(proposal_id),
    from_state TEXT NOT NULL,
    to_state TEXT NOT NULL CHECK(to_state IN ('adopted','rejected','rolled_back')),
    actor TEXT NOT NULL,
    reason TEXT NOT NULL,
    decision_document_hash TEXT NOT NULL CHECK(decision_document_hash GLOB 'sha256:[0-9a-f]*' AND length(decision_document_hash) = 71),
    created_at TEXT NOT NULL,
    UNIQUE(proposal_id,decision_document_hash)
);

CREATE TABLE IF NOT EXISTS policy_security_snapshots(
    snapshot_id TEXT PRIMARY KEY,
    snapshot_type TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    payload_hash TEXT NOT NULL UNIQUE CHECK(payload_hash GLOB 'sha256:[0-9a-f]*' AND length(payload_hash) = 71),
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS policy_authority_transitions(
    transition_id TEXT PRIMARY KEY,
    policy_id TEXT NOT NULL REFERENCES policy_authority(policy_id),
    from_state TEXT,
    to_state TEXT NOT NULL CHECK(to_state IN ('active','suspended','superseded','expired')),
    actor TEXT NOT NULL,
    reason TEXT NOT NULL,
    decision_document_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(policy_id,decision_document_hash)
);

CREATE TABLE IF NOT EXISTS policy_legacy_evidence(
    evidence_id TEXT PRIMARY KEY,
    source_policy_id TEXT NOT NULL,
    source_bytes TEXT NOT NULL,
    source_hash TEXT NOT NULL UNIQUE,
    verification_state TEXT NOT NULL CHECK(verification_state IN ('verified_legacy','legacy_unverified')),
    migrated_at TEXT NOT NULL
);
