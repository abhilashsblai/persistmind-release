CREATE TABLE IF NOT EXISTS agent_runtime_epoch (
  singleton INTEGER PRIMARY KEY CHECK(singleton=1),
  epoch INTEGER NOT NULL CHECK(epoch >= 1),
  protocol_version INTEGER NOT NULL CHECK(protocol_version >= 1),
  engine_version TEXT NOT NULL,
  activated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS agent_runtime_jobs (
  job_id TEXT PRIMARY KEY,
  job_kind TEXT NOT NULL,
  repository_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL,
  source_view_id TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  payload_digest TEXT NOT NULL,
  state TEXT NOT NULL,
  priority INTEGER NOT NULL DEFAULT 0,
  attempt_count INTEGER NOT NULL DEFAULT 0,
  max_attempts INTEGER NOT NULL DEFAULT 3,
  available_at TEXT NOT NULL,
  claimed_by TEXT,
  claim_token_hash TEXT,
  claim_expires_at TEXT,
  fencing_token INTEGER NOT NULL DEFAULT 0,
  runtime_epoch INTEGER NOT NULL,
  result_json TEXT,
  error_text TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  completed_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_agent_runtime_jobs_claim
  ON agent_runtime_jobs(state, available_at, priority DESC, created_at);

CREATE TABLE IF NOT EXISTS execution_grants (
  grant_id TEXT PRIMARY KEY,
  secret_hash TEXT NOT NULL,
  repository_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL,
  source_view_id TEXT NOT NULL,
  workflow_id TEXT NOT NULL,
  principal_id TEXT NOT NULL,
  actions_json TEXT NOT NULL,
  path_scopes_json TEXT NOT NULL,
  process_scopes_json TEXT NOT NULL,
  network_scopes_json TEXT NOT NULL,
  max_uses INTEGER NOT NULL,
  use_count INTEGER NOT NULL DEFAULT 0,
  not_before TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  runtime_epoch INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL,
  revoked_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_execution_grants_scope_status
  ON execution_grants(repository_id, workspace_id, status, expires_at);

CREATE TABLE IF NOT EXISTS project_protocol_migrations (
  migration_id TEXT PRIMARY KEY,
  from_version INTEGER NOT NULL,
  to_version INTEGER NOT NULL,
  from_epoch INTEGER NOT NULL,
  to_epoch INTEGER NOT NULL,
  state TEXT NOT NULL,
  backup_id TEXT NOT NULL,
  engine_version TEXT NOT NULL,
  plan_digest TEXT NOT NULL,
  started_at TEXT NOT NULL,
  activated_at TEXT,
  completed_at TEXT,
  error_text TEXT
);

CREATE TABLE IF NOT EXISTS external_agent_runs (
  run_id TEXT PRIMARY KEY,
  orchestration_id TEXT NOT NULL,
  adapter_id TEXT NOT NULL,
  adapter_version TEXT NOT NULL,
  worktree_lease_id TEXT NOT NULL,
  execution_grant_id TEXT NOT NULL,
  model_route_id TEXT,
  state TEXT NOT NULL,
  session_reference TEXT,
  replay_cursor INTEGER NOT NULL DEFAULT 0,
  process_id INTEGER,
  result_digest TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
