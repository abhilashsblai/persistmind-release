CREATE TABLE IF NOT EXISTS domain_outbox(
    event_id TEXT PRIMARY KEY,
    event_type TEXT NOT NULL,
    aggregate_id TEXT NOT NULL,
    aggregate_revision INTEGER NOT NULL,
    payload_json TEXT NOT NULL,
    payload_hash TEXT NOT NULL,
    idempotency_key TEXT NOT NULL UNIQUE,
    correlation_id TEXT,
    causation_id TEXT,
    occurred_at TEXT NOT NULL,
    published_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_domain_outbox_pending
    ON domain_outbox(published_at,occurred_at,event_id);

CREATE TABLE IF NOT EXISTS domain_consumer_receipts(
    consumer_id TEXT NOT NULL,
    event_id TEXT NOT NULL,
    payload_hash TEXT NOT NULL,
    handler_version TEXT NOT NULL,
    status TEXT NOT NULL,
    processed_at TEXT NOT NULL,
    PRIMARY KEY(consumer_id,event_id)
);

CREATE TABLE IF NOT EXISTS domain_idempotency_receipts(
    idempotency_key TEXT PRIMARY KEY,
    operation TEXT NOT NULL,
    request_hash TEXT NOT NULL,
    aggregate_id TEXT,
    aggregate_revision INTEGER,
    result_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS migration_archive_records(
    migration_id TEXT NOT NULL,
    source_format TEXT NOT NULL,
    source_table TEXT NOT NULL,
    row_ordinal INTEGER NOT NULL,
    record_json TEXT NOT NULL,
    record_hash TEXT NOT NULL,
    archived_at TEXT NOT NULL,
    PRIMARY KEY(migration_id,source_table,row_ordinal)
);
CREATE INDEX IF NOT EXISTS idx_migration_archive_source
    ON migration_archive_records(source_table,row_ordinal);

CREATE TABLE IF NOT EXISTS storage_outbox(
    event_id TEXT PRIMARY KEY,
    event_type TEXT NOT NULL,
    aggregate_id TEXT NOT NULL,
    sequence INTEGER NOT NULL,
    payload_json TEXT NOT NULL,
    payload_hash TEXT NOT NULL,
    required_consumers_json TEXT NOT NULL DEFAULT '[]',
    required_set_hash TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    published_at TEXT,
    UNIQUE(aggregate_id,sequence)
);
CREATE TABLE IF NOT EXISTS storage_inbox(
    event_id TEXT NOT NULL,
    consumer TEXT NOT NULL,
    handler_version TEXT NOT NULL,
    processed_at TEXT NOT NULL,
    payload_hash TEXT NOT NULL,
    PRIMARY KEY(event_id,consumer)
);
CREATE TABLE IF NOT EXISTS storage_dead_letters(
    event_id TEXT NOT NULL,
    consumer TEXT NOT NULL,
    error TEXT NOT NULL,
    retries INTEGER NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(event_id,consumer)
);

CREATE TABLE IF NOT EXISTS authority_feature_records(
    record_id TEXT PRIMARY KEY,
    operation TEXT NOT NULL,
    contract_version TEXT NOT NULL,
    state TEXT NOT NULL,
    request_json TEXT NOT NULL,
    result_json TEXT NOT NULL,
    evidence_json TEXT NOT NULL,
    revision INTEGER NOT NULL DEFAULT 1,
    idempotency_key TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_authority_feature_operation
    ON authority_feature_records(operation,updated_at DESC,record_id);
