CREATE TABLE IF NOT EXISTS agent_event_streams (
  stream_id TEXT PRIMARY KEY,
  next_sequence INTEGER NOT NULL DEFAULT 1 CHECK(next_sequence >= 1),
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS agent_event_journal (
  event_id TEXT PRIMARY KEY,
  stream_id TEXT NOT NULL,
  sequence INTEGER NOT NULL CHECK(sequence >= 1),
  event_type TEXT NOT NULL,
  session_id TEXT,
  parent_event_id TEXT,
  payload_json TEXT NOT NULL,
  payload_digest TEXT NOT NULL,
  redaction_revision TEXT NOT NULL,
  occurred_at TEXT NOT NULL,
  committed_at TEXT NOT NULL,
  delivery_state TEXT NOT NULL DEFAULT 'pending',
  attempt_count INTEGER NOT NULL DEFAULT 0,
  next_attempt_at TEXT,
  claimed_by TEXT,
  claim_expires_at TEXT,
  last_error TEXT,
  UNIQUE(stream_id, sequence)
);

CREATE INDEX IF NOT EXISTS idx_agent_event_journal_delivery
  ON agent_event_journal(delivery_state, next_attempt_at, sequence);
CREATE INDEX IF NOT EXISTS idx_agent_event_journal_session
  ON agent_event_journal(session_id, sequence);

CREATE TABLE IF NOT EXISTS agent_event_dead_letters (
  event_id TEXT PRIMARY KEY,
  stream_id TEXT NOT NULL,
  sequence INTEGER NOT NULL,
  payload_digest TEXT NOT NULL,
  reason TEXT NOT NULL,
  attempts INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);
