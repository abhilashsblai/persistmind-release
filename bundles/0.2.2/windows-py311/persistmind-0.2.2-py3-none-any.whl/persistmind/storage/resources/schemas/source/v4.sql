CREATE TABLE IF NOT EXISTS source_views(source_view_id TEXT PRIMARY KEY,current_generation_id TEXT NOT NULL REFERENCES source_generations(generation_id),updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS source_generation_files(generation_id TEXT NOT NULL REFERENCES source_generations(generation_id) ON DELETE CASCADE,path TEXT NOT NULL,artifact_id TEXT NOT NULL,content_hash TEXT NOT NULL,resolver_id TEXT NOT NULL,PRIMARY KEY(generation_id,path));
CREATE INDEX IF NOT EXISTS idx_source_generation_files_artifact ON source_generation_files(artifact_id,generation_id);
CREATE TABLE IF NOT EXISTS source_artifacts(artifact_id TEXT PRIMARY KEY,content_hash TEXT NOT NULL,index_contract TEXT NOT NULL,model_digest TEXT NOT NULL,resolver_id TEXT NOT NULL,segment_id TEXT NOT NULL UNIQUE,physical_hash TEXT NOT NULL,logical_bytes INTEGER NOT NULL,ref_count INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_source_artifacts_content ON source_artifacts(content_hash,index_contract,model_digest,resolver_id);
CREATE TABLE IF NOT EXISTS source_generation_pins(pin_id TEXT PRIMARY KEY,generation_id TEXT NOT NULL REFERENCES source_generations(generation_id),reason TEXT NOT NULL,created_at TEXT NOT NULL,expires_at TEXT);
CREATE INDEX IF NOT EXISTS idx_source_generation_pins_generation ON source_generation_pins(generation_id,expires_at);
CREATE TABLE IF NOT EXISTS source_resolvers(resolver_id TEXT PRIMARY KEY,version TEXT NOT NULL,kind TEXT NOT NULL,configuration_digest TEXT NOT NULL,created_at TEXT NOT NULL);
INSERT OR IGNORE INTO source_resolvers VALUES('builtin-path-v1','1','path-and-import-resolution','builtin',strftime('%Y-%m-%dT%H:%M:%fZ','now'));
