CREATE TABLE IF NOT EXISTS acp_sessions (
  connection_id TEXT PRIMARY KEY,
  orchestration_id TEXT NOT NULL,
  worktree_lease_id TEXT NOT NULL,
  execution_grant_id TEXT NOT NULL,
  agent_command_digest TEXT NOT NULL,
  protocol_version TEXT NOT NULL,
  capabilities_json TEXT NOT NULL,
  state TEXT NOT NULL,
  session_reference TEXT,
  replay_cursor INTEGER NOT NULL DEFAULT 0,
  result_digest TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_acp_sessions_orchestration
  ON acp_sessions(orchestration_id, created_at);

CREATE TABLE IF NOT EXISTS acp_terminals (
  terminal_id TEXT PRIMARY KEY,
  connection_id TEXT NOT NULL REFERENCES acp_sessions(connection_id),
  command_digest TEXT NOT NULL,
  worktree_lease_id TEXT NOT NULL,
  execution_grant_id TEXT NOT NULL,
  state TEXT NOT NULL,
  output_bytes INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS worktree_leases (
  lease_id TEXT PRIMARY KEY,
  repository_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL,
  source_view_id TEXT NOT NULL,
  owner_session_id TEXT NOT NULL,
  pinned_oid TEXT NOT NULL,
  mode TEXT NOT NULL,
  state TEXT NOT NULL,
  runtime_epoch INTEGER NOT NULL,
  expires_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_worktree_leases_state_expiry
  ON worktree_leases(state, expires_at);

CREATE TABLE IF NOT EXISTS model_route_evidence (
  route_evidence_id TEXT PRIMARY KEY,
  orchestration_id TEXT NOT NULL,
  catalog_version TEXT NOT NULL,
  policy_revision TEXT NOT NULL,
  candidate_digest TEXT NOT NULL,
  selected_route_id TEXT,
  fallback_reason TEXT,
  evidence_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);
