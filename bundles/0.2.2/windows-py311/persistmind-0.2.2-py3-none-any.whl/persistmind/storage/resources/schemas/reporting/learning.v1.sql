CREATE TABLE IF NOT EXISTS feedback_ingest_runs (
  ingest_run_id TEXT PRIMARY KEY, source TEXT NOT NULL, package_digest TEXT NOT NULL UNIQUE,
  validator_version TEXT NOT NULL, state TEXT NOT NULL,
  occurrence_id TEXT, artifact_ref TEXT, reason TEXT,
  counts_json TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL, completed_at TEXT
);
CREATE TABLE IF NOT EXISTS canonical_issues (
  canonical_issue_id TEXT PRIMARY KEY, component TEXT NOT NULL,
  normalized_fingerprint TEXT NOT NULL, fingerprint_version TEXT NOT NULL,
  severity TEXT NOT NULL, status TEXT NOT NULL, first_seen_release TEXT,
  last_seen_release TEXT, resolution_json TEXT NOT NULL DEFAULT '{}',
  regression_json TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL, UNIQUE(normalized_fingerprint,fingerprint_version)
);
CREATE INDEX IF NOT EXISTS idx_canonical_issues_status ON canonical_issues(status,severity,updated_at DESC);
CREATE TABLE IF NOT EXISTS canonical_issue_occurrences (
  canonical_issue_id TEXT NOT NULL REFERENCES canonical_issues(canonical_issue_id),
  occurrence_id TEXT NOT NULL, match_method TEXT NOT NULL, confidence REAL NOT NULL,
  decision TEXT NOT NULL, reviewer TEXT, decided_at TEXT, active INTEGER NOT NULL DEFAULT 1,
  audit_json TEXT NOT NULL DEFAULT '{}', PRIMARY KEY(canonical_issue_id,occurrence_id)
);
CREATE INDEX IF NOT EXISTS idx_canonical_issue_occurrences_occurrence ON canonical_issue_occurrences(occurrence_id,active,decision);
CREATE TABLE IF NOT EXISTS incident_fingerprint_aliases (
  alias_fingerprint TEXT NOT NULL, alias_version TEXT NOT NULL,
  canonical_fingerprint TEXT NOT NULL, canonical_version TEXT NOT NULL,
  reason TEXT NOT NULL, approved_by TEXT NOT NULL, created_at TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1, PRIMARY KEY(alias_fingerprint,alias_version)
);
