CREATE TABLE IF NOT EXISTS source_segment_records(record_id TEXT PRIMARY KEY,kind TEXT NOT NULL,payload_json TEXT NOT NULL,content_hash TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_source_segment_records_kind ON source_segment_records(kind,record_id);
