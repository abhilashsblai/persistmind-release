CREATE TABLE IF NOT EXISTS knowledge_evidence(evidence_id TEXT PRIMARY KEY,record_id TEXT NOT NULL,locator_json TEXT NOT NULL,content_hash TEXT NOT NULL,trust TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_knowledge_evidence_record ON knowledge_evidence(record_id,evidence_id);
CREATE TABLE IF NOT EXISTS knowledge_aliases(legacy_id TEXT PRIMARY KEY,record_id TEXT NOT NULL,kind TEXT NOT NULL);
