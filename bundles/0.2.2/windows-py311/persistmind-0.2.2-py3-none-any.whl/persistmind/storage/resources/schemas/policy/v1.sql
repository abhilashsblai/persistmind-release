CREATE TABLE IF NOT EXISTS policy_authority(policy_id TEXT PRIMARY KEY,scope TEXT NOT NULL,priority INTEGER NOT NULL,payload_json TEXT NOT NULL,status TEXT NOT NULL,approved_by TEXT NOT NULL,signature TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_policy_authority_scope ON policy_authority(status,scope,priority DESC,policy_id);
CREATE TABLE IF NOT EXISTS policy_action_decisions(
    decision_id TEXT PRIMARY KEY,
    proposal_id TEXT NOT NULL UNIQUE,
    action_class TEXT NOT NULL,
    proposal_json TEXT NOT NULL,
    decision TEXT NOT NULL,
    decided_by TEXT NOT NULL,
    signature TEXT NOT NULL,
    reason TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_policy_action_decisions_state
    ON policy_action_decisions(decision,created_at DESC,decision_id);
