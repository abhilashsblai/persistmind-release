CREATE TABLE IF NOT EXISTS topology_generations(
    generation INTEGER PRIMARY KEY,
    topology_id TEXT NOT NULL,
    manifest_json TEXT NOT NULL,
    manifest_hash TEXT NOT NULL UNIQUE,
    state TEXT NOT NULL CHECK(state IN ('staged','active','retired')),
    created_at TEXT NOT NULL,
    activated_at TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_topology_active
    ON topology_generations(state) WHERE state='active';

CREATE TABLE IF NOT EXISTS operation_leases(
    lease_name TEXT PRIMARY KEY,
    owner_id TEXT NOT NULL,
    owner_boot_id TEXT NOT NULL,
    owner_nonce TEXT NOT NULL,
    fencing_token INTEGER NOT NULL,
    acquired_at TEXT NOT NULL,
    heartbeat_at TEXT NOT NULL,
    deadline_at TEXT NOT NULL,
    payload_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS operation_runs(
    operation_id TEXT PRIMARY KEY,
    operation_type TEXT NOT NULL,
    state TEXT NOT NULL,
    owner_id TEXT,
    fencing_token INTEGER,
    input_hash TEXT NOT NULL,
    payload_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    completed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_operation_runs_type_state
    ON operation_runs(operation_type,state,updated_at);

CREATE TABLE IF NOT EXISTS migration_runs(
    migration_id TEXT PRIMARY KEY,
    source_fingerprint TEXT NOT NULL,
    target_topology TEXT NOT NULL,
    phase TEXT NOT NULL,
    state TEXT NOT NULL,
    report_ref TEXT,
    started_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    completed_at TEXT
);

CREATE TABLE IF NOT EXISTS durable_jobs(
    job_id TEXT PRIMARY KEY,
    job_type TEXT NOT NULL,
    state TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    idempotency_key TEXT NOT NULL UNIQUE,
    claimed_by TEXT,
    fencing_token INTEGER,
    available_at TEXT NOT NULL,
    claimed_at TEXT,
    heartbeat_at TEXT,
    completed_at TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_durable_jobs_claim
    ON durable_jobs(state,available_at,created_at);

CREATE TABLE IF NOT EXISTS idempotency_receipts(
    idempotency_key TEXT PRIMARY KEY,
    operation_type TEXT NOT NULL,
    request_hash TEXT NOT NULL,
    result_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    expires_at TEXT
);

CREATE TABLE IF NOT EXISTS saga_instances(
    saga_id TEXT PRIMARY KEY,
    saga_type TEXT NOT NULL,
    state TEXT NOT NULL,
    revision INTEGER NOT NULL DEFAULT 1,
    payload_json TEXT NOT NULL,
    last_error TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS consumer_watermarks(
    consumer_id TEXT NOT NULL,
    producer_role TEXT NOT NULL,
    position INTEGER NOT NULL,
    event_id TEXT,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(consumer_id,producer_role)
);

CREATE TABLE IF NOT EXISTS consistency_watermarks(
    watermark_id TEXT PRIMARY KEY,
    topology_generation INTEGER NOT NULL,
    revisions_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS backup_checkpoints(
    backup_id TEXT NOT NULL,
    store_role TEXT NOT NULL,
    store_revision INTEGER NOT NULL,
    image_hash TEXT NOT NULL,
    verified_at TEXT,
    PRIMARY KEY(backup_id,store_role)
);

CREATE TABLE IF NOT EXISTS control_outbox(
    event_id TEXT PRIMARY KEY,
    event_type TEXT NOT NULL,
    aggregate_id TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    idempotency_key TEXT NOT NULL UNIQUE,
    occurred_at TEXT NOT NULL,
    published_at TEXT
);
