from __future__ import annotations

import json
from typing import Any

from persistmind.utils import canonical_json, stable_id, utc_now


class SemanticGraphStoreAdapter:
    def __init__(self, service: Any, generation_id: str):
        self.service = service
        self.generation_id = generation_id

    def snapshot_files(self, snapshot_id: str) -> list[dict[str, Any]]:
        _ = snapshot_id
        return [
            {
                "path": str(row.get("path") or ""),
                "file_version_id": str(row.get("content_hash") or row.get("_content_hash") or ""),
                "content_hash": str(row.get("content_hash") or row.get("_content_hash") or ""),
            }
            for row in self._records("source_file")
            if row.get("path")
        ]

    def semantic_file_index(self, repo_id: str) -> list[dict[str, Any]]:
        _ = repo_id
        return self.snapshot_files(self.generation_id)

    def semantic_nodes(self, repo_id: str) -> list[dict[str, Any]]:
        overrides = {
            str(row["node_id"]): row
            for row in self._records("semantic_repair_node")
            if row.get("repo_id") == repo_id
        }
        nodes: dict[str, dict[str, Any]] = {
            str(row["node_id"]): dict(row)
            for row in self._records("semantic_node")
            if row.get("repo_id") == repo_id
        }
        for node_id, override in overrides.items():
            if override.get("deleted"):
                nodes.pop(node_id, None)
            elif node_id in nodes:
                nodes[node_id].update(
                    {
                        "metadata_json": override["metadata_json"],
                        "confidence": override["confidence"],
                    }
                )
        return list(nodes.values())

    def semantic_edges(self, repo_id: str) -> list[dict[str, Any]]:
        nodes = {str(row.get("node_id")): row for row in self.semantic_nodes(repo_id)}
        rows: list[dict[str, Any]] = []
        overrides = {
            str(row["edge_id"]): row
            for row in self._records("semantic_repair_edge")
            if row.get("repo_id") == repo_id
        }
        for edge in self._records("semantic_edge"):
            override = overrides.get(str(edge.get("edge_id")))
            if override is not None and override.get("deleted"):
                continue
            src = nodes.get(str(edge.get("src_node_id")))
            dst = nodes.get(str(edge.get("dst_node_id")))
            if src is None or dst is None:
                continue
            item = dict(edge)
            if override is not None:
                item.update(
                    {
                        "metadata_json": override["metadata_json"],
                        "confidence": override["confidence"],
                    }
                )
            item.setdefault("src_type", src.get("node_type"))
            item.setdefault("src_name", src.get("name"))
            item.setdefault("dst_type", dst.get("node_type"))
            item.setdefault("dst_name", dst.get("name"))
            item.setdefault("src_trust_tier", src.get("trust_tier"))
            item.setdefault("dst_trust_tier", dst.get("trust_tier"))
            item.setdefault("src_status", src.get("status"))
            item.setdefault("dst_status", dst.get("status"))
            rows.append(item)
        return rows

    def semantic_evidence(self, *, node_id: str | None = None) -> list[dict[str, Any]]:
        rows = self._records("semantic_evidence")
        if node_id is not None:
            rows = [row for row in rows if row.get("node_id") == node_id]
        return rows

    def semantic_node(self, node_id: str) -> dict[str, Any] | None:
        for row in self._records("semantic_node"):
            if row.get("node_id") == node_id:
                return row
        return None

    def logical_edges(self, where: str, params: tuple[str, ...]) -> list[dict[str, Any]]:
        _ = where
        src_repo_id = params[0] if len(params) >= 1 else None
        dst_repo_id = params[1] if len(params) >= 2 else None
        rows: list[dict[str, Any]] = []
        for record in self._records("source_edge"):
            edge_kind = str(record.get("edge_kind") or "")
            if edge_kind not in {"import_hint", "calls"}:
                continue
            kind = "imports" if edge_kind == "import_hint" else edge_kind
            repo_id = str(record.get("repo_id") or src_repo_id or "")
            if src_repo_id and repo_id != src_repo_id:
                continue
            if dst_repo_id and repo_id != dst_repo_id:
                continue
            rows.append(
                {
                    "src_repo_id": repo_id,
                    "dst_repo_id": repo_id,
                    "src_node_type": "file",
                    "dst_node_type": "file",
                    "src_node_id": str(record.get("path") or ""),
                    "dst_node_id": str(record.get("target") or ""),
                    "kind": kind,
                    "confidence": float(record.get("confidence") or 0.0),
                }
            )
        return rows

    def write_semantic_drift_findings(
        self, *, repo_id: str, snapshot_id: str, findings: list[dict[str, Any]]
    ) -> list[str]:
        ids = [
            "semantic-drift-" + stable_id(repo_id, snapshot_id, canonical_json(finding))[:32]
            for finding in findings
        ]
        records = []
        for finding_id, finding in zip(ids, findings, strict=False):
            records.append(
                {
                    "record_id": finding_id,
                    "kind": "semantic_drift_finding",
                    "generation_id": self.generation_id,
                    "finding_id": finding_id,
                    "repo_id": repo_id,
                    "snapshot_id": snapshot_id,
                    "finding": dict(finding),
                    "created_at": utc_now(),
                }
            )
        if records:
            self.service._publish_projection_records(
                records,
                projection="semantic-drift",
                source_path=".persistmind/semantic/drift-findings.json",
                resolver_id="semantic-drift-projection-v1",
                resolver_kind="semantic-drift-projection",
            )
        return ids

    def semantic_drift_findings(
        self, repo_id: str, *, status: str | None = "open", limit: int = 100
    ) -> list[dict[str, Any]]:
        decisions = {
            str(row["finding_id"]): row
            for row in self._records("semantic_repair_decision")
            if row.get("repo_id") == repo_id
        }
        findings: list[dict[str, Any]] = []
        for row in self._records("semantic_drift_finding"):
            if row.get("repo_id") != repo_id:
                continue
            finding = dict(row.get("finding") or {})
            finding_id = str(row.get("finding_id") or row.get("record_id") or "")
            decision = decisions.get(finding_id, {})
            item = {
                "finding_id": finding_id,
                "repo_id": repo_id,
                "snapshot_id": str(row.get("snapshot_id") or ""),
                "finding_type": str(finding.get("finding_type") or "low_confidence"),
                "severity": str(finding.get("severity") or "warning"),
                "node_id": finding.get("node_id"),
                "edge_id": finding.get("edge_id"),
                "paths_json": json.dumps(finding.get("paths") or []),
                "detail": str(finding.get("detail") or ""),
                "confidence": float(finding.get("confidence") or 0.0),
                "status": str(decision.get("status") or "open"),
                "detected_at": str(row.get("created_at") or ""),
                "resolved_at": decision.get("resolved_at"),
                "audit_hash": decision.get("audit_hash"),
                "prev_audit_hash": decision.get("prev_audit_hash"),
            }
            if status is None or item["status"] == status:
                findings.append(item)
        findings.sort(key=lambda item: (str(item["detected_at"]), str(item["finding_id"])), reverse=True)
        return findings[: max(1, min(int(limit), 1_000))]

    def semantic_drift_finding(self, finding_id: str) -> dict[str, Any] | None:
        for row in self.semantic_drift_findings_for_all_statuses():
            if row["finding_id"] == finding_id:
                return row
        return None

    def semantic_drift_findings_for_all_statuses(self) -> list[dict[str, Any]]:
        repo_ids = {str(row.get("repo_id") or "") for row in self._records("semantic_drift_finding")}
        return [item for repo_id in repo_ids if repo_id for item in self.semantic_drift_findings(repo_id, status=None, limit=1_000)]

    def delete_semantic_node(self, node_id: str) -> bool:
        node = next((row for row in self._records("semantic_node") if row.get("node_id") == node_id), None)
        if node is None:
            return False
        self._write_override(
            "semantic_repair_node",
            ".persistmind/semantic/repair-nodes.json",
            {"node_id": node_id, "repo_id": node["repo_id"], "deleted": True, "metadata_json": "{}", "confidence": 0.0},
        )
        return True

    def update_semantic_node_metadata(
        self, node_id: str, metadata: dict[str, Any], *, confidence: float
    ) -> None:
        node = next((row for row in self._records("semantic_node") if row.get("node_id") == node_id), None)
        if node is None:
            raise KeyError(f"semantic node not found: {node_id}")
        self._write_override(
            "semantic_repair_node",
            ".persistmind/semantic/repair-nodes.json",
            {"node_id": node_id, "repo_id": node["repo_id"], "deleted": False, "metadata_json": canonical_json(metadata), "confidence": confidence},
        )

    def update_semantic_edge_metadata(
        self, edge_id: str, metadata: dict[str, Any], *, confidence: float
    ) -> None:
        edge = next((row for row in self._records("semantic_edge") if row.get("edge_id") == edge_id), None)
        if edge is None:
            raise KeyError(f"semantic edge not found: {edge_id}")
        self._write_override(
            "semantic_repair_edge",
            ".persistmind/semantic/repair-edges.json",
            {"edge_id": edge_id, "repo_id": edge["repo_id"], "deleted": False, "metadata_json": canonical_json(metadata), "confidence": confidence},
        )

    def update_semantic_drift_finding(
        self, finding_id: str, *, status: str, audit_hash: str, prev_audit_hash: str
    ) -> None:
        finding = self.semantic_drift_finding(finding_id)
        if finding is None:
            raise KeyError(f"semantic drift finding not found: {finding_id}")
        self._write_override(
            "semantic_repair_decision",
            ".persistmind/semantic/repair-decisions.json",
            {"finding_id": finding_id, "repo_id": finding["repo_id"], "status": status, "audit_hash": audit_hash, "prev_audit_hash": prev_audit_hash, "resolved_at": utc_now()},
        )

    def _write_override(self, kind: str, source_path: str, value: dict[str, Any]) -> None:
        key = "node_id" if kind == "semantic_repair_node" else "edge_id" if kind == "semantic_repair_edge" else "finding_id"
        rows = [dict(row) for row in self._records(kind) if row.get(key) != value[key]]
        rows.append(
            {
                "record_id": f"{kind.replace('_', '-')}--" + stable_id(value[key])[:32],
                "kind": kind,
                "generation_id": self.generation_id,
                **value,
            }
        )
        self.service._publish_projection_records(
            rows,
            projection=kind,
            source_path=source_path,
            resolver_id=f"{kind}-v1",
            resolver_kind=kind,
        )

    def _records(self, kind: str) -> list[dict[str, Any]]:
        return self.service._records_by_kind(kind, generation_id=self.generation_id)
