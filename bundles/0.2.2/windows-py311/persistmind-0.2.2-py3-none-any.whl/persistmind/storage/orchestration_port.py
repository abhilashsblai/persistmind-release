from __future__ import annotations

from typing import Any, Sequence


class SQLiteOrchestrationTaskPort:
    """Compatibility Task service for orchestration tables pending authority boundary."""

    def __init__(self, connection: Any) -> None:
        self.connection = connection

    def __enter__(self) -> "SQLiteOrchestrationTaskPort":
        self.connection.__enter__()
        return self

    def __exit__(self, *args: object) -> None:
        self.connection.__exit__(*args)

    def execute(self, statement: str, parameters: Sequence[Any] = ()) -> Any:
        return self.connection.execute(statement, parameters)


__all__ = ["SQLiteOrchestrationTaskPort"]
