from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import StrEnum
from typing import Any, Mapping


LATEST_AUTHORITY_SCHEMA_REVISION = 7


class StorageDomain(StrEnum):
    """Logical product ownership boundaries.

    Every writable authority is a first-class domain.  Composite workflows may
    reference another authority by immutable identifier, but never borrow its
    transaction or infer ownership from a filename.
    """

    CONTROL = "control"
    SOURCE = "source"
    TASK = "task"
    ACTIVITY = "activity"
    AUDIT = "audit"
    KNOWLEDGE = "knowledge"
    POLICY = "policy"
    LEARNING = "learning"


class StoreRole(StrEnum):
    """Physical PersistMind next-generation store roles."""

    CONTROL = "control"
    SOURCE_MANIFEST = "source_manifest"
    SOURCE_SEGMENT = "source_segment"
    TASK_STATE = "task_state"
    ACTIVITY_ACTIVE = "activity_active"
    ACTIVITY_SEALED = "activity_sealed"
    AUDIT_ACTIVE = "audit_active"
    AUDIT_SEALED = "audit_sealed"
    KNOWLEDGE = "knowledge"
    POLICY = "policy"
    LEARNING = "learning"


ROLE_DOMAIN: dict[StoreRole, StorageDomain | None] = {
    StoreRole.CONTROL: StorageDomain.CONTROL,
    StoreRole.SOURCE_MANIFEST: StorageDomain.SOURCE,
    StoreRole.SOURCE_SEGMENT: StorageDomain.SOURCE,
    StoreRole.TASK_STATE: StorageDomain.TASK,
    StoreRole.ACTIVITY_ACTIVE: StorageDomain.ACTIVITY,
    StoreRole.ACTIVITY_SEALED: StorageDomain.ACTIVITY,
    StoreRole.AUDIT_ACTIVE: StorageDomain.AUDIT,
    StoreRole.AUDIT_SEALED: StorageDomain.AUDIT,
    StoreRole.KNOWLEDGE: StorageDomain.KNOWLEDGE,
    StoreRole.POLICY: StorageDomain.POLICY,
    StoreRole.LEARNING: StorageDomain.LEARNING,
}

PRIMARY_ROLE_BY_DOMAIN: dict[StorageDomain, StoreRole] = {
    StorageDomain.CONTROL: StoreRole.CONTROL,
    StorageDomain.SOURCE: StoreRole.SOURCE_MANIFEST,
    StorageDomain.TASK: StoreRole.TASK_STATE,
    StorageDomain.ACTIVITY: StoreRole.ACTIVITY_ACTIVE,
    StorageDomain.AUDIT: StoreRole.AUDIT_ACTIVE,
    StorageDomain.KNOWLEDGE: StoreRole.KNOWLEDGE,
    StorageDomain.POLICY: StoreRole.POLICY,
    StorageDomain.LEARNING: StoreRole.LEARNING,
}

SEALED_ROLES = frozenset({StoreRole.ACTIVITY_SEALED, StoreRole.AUDIT_SEALED})


@dataclass(frozen=True, slots=True)
class StoreCapabilities:
    """Capabilities proven by conformance checks, never inferred from schema shape."""

    transactions: bool = True
    compare_and_swap: bool = True
    full_text: bool = False
    vector_search: bool = False
    online_backup: bool = False
    point_in_time_recovery: bool = False
    partitioning: bool = False
    encryption: bool = False
    server: bool = False


@dataclass(frozen=True, slots=True)
class StoreDescriptor:
    store_id: str
    domain: StorageDomain
    store_role: StoreRole
    backend: str
    location: str
    schema_head: int
    authorization_scope: str = "workspace"
    generation: int = 1
    state: str = "active"
    read_only: bool = False
    shard_key: str = "default"
    partition_key: str = "current"
    created_at: str | None = None
    sealed_at: str | None = None
    min_key: str | None = None
    max_key: str | None = None
    logical_content_hash: str | None = None
    physical_image_hash: str | None = None
    resource_hash: str | None = None
    profile_hash: str | None = None
    capabilities: StoreCapabilities = field(default_factory=StoreCapabilities)

    def __post_init__(self) -> None:
        expected_domain = ROLE_DOMAIN[self.store_role]
        if expected_domain is not None and expected_domain is not self.domain:
            raise ValueError(
                "store role/domain mismatch: "
                f"{self.store_role.value} belongs to {expected_domain.value}, "
                f"not {self.domain.value}"
            )
        if self.store_role in SEALED_ROLES and not self.read_only:
            raise ValueError(f"sealed role must be read-only: {self.store_role.value}")
        if not self.store_id or not self.location:
            raise ValueError("store_id and location are required")
        if self.generation < 1 or self.schema_head < 1:
            raise ValueError("store generation and schema head must be positive")

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "StoreDescriptor":
        data = dict(value)
        data["domain"] = StorageDomain(data["domain"])
        role = data.get("store_role")
        if role is None:
            role = PRIMARY_ROLE_BY_DOMAIN[data["domain"]]
        data["store_role"] = StoreRole(role)
        data["capabilities"] = StoreCapabilities(**data.get("capabilities", {}))
        return cls(**data)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class TopologyManifest:
    topology_id: str
    generation: int
    profile: str
    stores: tuple[StoreDescriptor, ...]
    workspace_id: str | None = None
    contract_hash: str | None = None
    created_at: str | None = None
    schema_version: str = "persistmind.storage_topology.v1"

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "TopologyManifest":
        return cls(
            topology_id=str(value["topology_id"]),
            generation=int(value["generation"]),
            profile=str(value["profile"]),
            stores=tuple(StoreDescriptor.from_dict(item) for item in value["stores"]),
            workspace_id=(
                str(value["workspace_id"]) if value.get("workspace_id") is not None else None
            ),
            contract_hash=(
                str(value["contract_hash"]) if value.get("contract_hash") is not None else None
            ),
            created_at=(str(value["created_at"]) if value.get("created_at") is not None else None),
            schema_version=str(value.get("schema_version", "persistmind.storage_topology.v1")),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class MigrationDescriptor:
    migration_id: str
    domain: StorageDomain
    from_version: int
    to_version: int
    checksum: str
    reversible: bool = False


@dataclass(frozen=True, slots=True)
class ConsistencyWatermark:
    topology_generation: int
    revisions: Mapping[str, int]
    outbox_positions: Mapping[str, int] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class MemoryKindDescriptor:
    kind: str
    domain: StorageDomain
    authority: str
    store_role: StoreRole | None = None
    schema_version: int = 1
    executable: bool = False
    plugin: str | None = None

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "MemoryKindDescriptor":
        data = dict(value)
        data["domain"] = StorageDomain(data["domain"])
        if data.get("store_role") is not None:
            data["store_role"] = StoreRole(data["store_role"])
        return cls(**data)
