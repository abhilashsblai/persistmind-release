from __future__ import annotations

import sqlite3
import threading
from collections.abc import Callable, Iterable, Sequence
from concurrent.futures import ThreadPoolExecutor, wait
from pathlib import Path
from typing import Any, TypeVar

from persistmind.runtime.operations import Deadline, OperationTimeoutError

T = TypeVar("T")


class SQLiteReadPool:
    """Small read-only pool with cooperative deadlines and bounded cleanup."""

    def __init__(
        self,
        db_path: Path,
        *,
        max_workers: int = 4,
        timeout: float = 5.0,
        deadline: Deadline | None = None,
        cleanup_seconds: float = 5.0,
    ) -> None:
        self.db_path = db_path
        self.max_workers = max(1, int(max_workers))
        self.timeout = timeout
        self.deadline = deadline or Deadline(60.0, operation="sqlite_read_pool")
        self.cleanup_seconds = max(0.0, float(cleanup_seconds))
        self._executor: ThreadPoolExecutor | None = None
        self._connections: set[sqlite3.Connection] = set()
        self._connection_lock = threading.Lock()

    def __enter__(self) -> SQLiteReadPool:
        self.deadline.check("read_pool_start")
        self._executor = ThreadPoolExecutor(
            max_workers=self.max_workers, thread_name_prefix="persistmind-sqlite-read"
        )
        return self

    def __exit__(self, *_exc: object) -> None:
        executor = self._executor
        if executor is None:
            return
        self._interrupt_connections()
        executor.shutdown(wait=False, cancel_futures=True)
        self._executor = None

    def query_all(self, sql: str, params: Sequence[Any] | None = None) -> list[dict[str, Any]]:
        self.deadline.check("sqlite_read")
        conn = self._connect()
        self._register(conn)
        try:
            rows = conn.execute(sql, params or ()).fetchall()
            self.deadline.check("sqlite_read")
            return [dict(row) for row in rows]
        except sqlite3.OperationalError as exc:
            if self.deadline.expired() or "interrupted" in str(exc).lower():
                elapsed = self.deadline.limit - self.deadline.remaining()
                raise OperationTimeoutError("sqlite_read", elapsed, self.deadline.limit) from exc
            raise
        finally:
            self._unregister(conn)
            conn.close()

    def parallel_map(self, calls: Iterable[Callable[[SQLiteReadPool], T]]) -> list[T]:
        call_list = list(calls)
        if not call_list:
            return []
        self.deadline.check("read_pool_dispatch")
        if self._executor is None or self.max_workers <= 1 or len(call_list) == 1:
            return [call(self) for call in call_list]
        futures = [self._executor.submit(call, self) for call in call_list]
        done, pending = wait(futures, timeout=self.deadline.remaining())
        if pending:
            self.deadline.cancel("read_pool_timeout")
            self._interrupt_connections()
            for future in pending:
                future.cancel()
            wait(pending, timeout=min(self.cleanup_seconds, self.deadline.cleanup_allowance))
            elapsed = self.deadline.limit - self.deadline.remaining()
            raise OperationTimeoutError("sqlite_read_pool", elapsed, self.deadline.limit)
        return [future.result() for future in futures]

    def _connect(self) -> sqlite3.Connection:
        uri = f"{self.db_path.resolve().as_uri()}?mode=ro&cache=shared"
        conn = sqlite3.connect(
            uri,
            uri=True,
            timeout=min(self.timeout, max(0.1, self.deadline.remaining())),
            check_same_thread=False,
        )
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA query_only=ON")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute(
            f"PRAGMA busy_timeout={max(1, int(min(self.timeout, self.deadline.remaining()) * 1000))}"
        )
        conn.execute("PRAGMA temp_store=MEMORY")
        conn.execute("PRAGMA cache_size=-32768")
        conn.execute("PRAGMA mmap_size=268435456")
        conn.set_progress_handler(self.deadline.sqlite_progress_handler("sqlite_read"), 1_000)
        return conn

    def _register(self, conn: sqlite3.Connection) -> None:
        with self._connection_lock:
            self._connections.add(conn)

    def _unregister(self, conn: sqlite3.Connection) -> None:
        with self._connection_lock:
            self._connections.discard(conn)

    def _interrupt_connections(self) -> None:
        with self._connection_lock:
            connections = list(self._connections)
        for conn in connections:
            try:
                conn.interrupt()
            except sqlite3.Error:
                continue
