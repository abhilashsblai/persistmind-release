from __future__ import annotations

import hashlib
import json
import os
import secrets
from contextlib import AbstractContextManager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


class OperationConflict(RuntimeError):
    status = "storage_operation_conflict"


class OperationFence(AbstractContextManager["OperationFence"]):
    """Crash-visible, mutually exclusive fence for destructive storage operations."""

    def __init__(
        self,
        workspace_root: Path,
        operation: str,
        plan: dict[str, Any],
        *,
        scope: str = "workspace",
    ) -> None:
        self.root = workspace_root.resolve()
        self.operation = operation
        self.scope = scope
        self.plan = plan
        canonical = json.dumps(plan, sort_keys=True, separators=(",", ":")).encode()
        self.plan_hash = hashlib.sha256(canonical).hexdigest()
        self.operation_id = (
            f"{operation}-{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}-"
            f"{secrets.token_hex(4)}"
        )
        self.lock = self.root / "locks" / f"lifecycle-{scope}.lock"
        self.record = self.root / "operations" / f"{self.operation_id}.json"
        self._descriptor: int | None = None

    def __enter__(self) -> OperationFence:
        self.lock.parent.mkdir(parents=True, exist_ok=True)
        try:
            self._descriptor = os.open(self.lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError as exc:
            raise OperationConflict(f"another lifecycle operation owns scope {self.scope}") from exc
        token = secrets.token_hex(16)
        os.write(self._descriptor, token.encode("ascii"))
        os.fsync(self._descriptor)
        self._write("running")
        return self

    def succeed(self, result: dict[str, Any] | None = None) -> None:
        self._write("succeeded", result=result)

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        try:
            if exc is not None:
                self._write(
                    "failed_safe",
                    result={"error_type": type(exc).__name__, "error": str(exc)[:2000]},
                )
        finally:
            if self._descriptor is not None:
                os.close(self._descriptor)
                self._descriptor = None
            self.lock.unlink(missing_ok=True)

    def _write(self, state: str, *, result: dict[str, Any] | None = None) -> None:
        self.record.parent.mkdir(parents=True, exist_ok=True)
        value = {
            "schema_version": "persistmind.storage_operation.v1",
            "operation_id": self.operation_id,
            "operation": self.operation,
            "scope": self.scope,
            "plan_hash": self.plan_hash,
            "state": state,
            "updated_at": datetime.now(UTC).isoformat(),
            "result": result,
        }
        temporary = self.record.with_suffix(".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(value, handle, sort_keys=True, separators=(",", ":"))
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, self.record)
