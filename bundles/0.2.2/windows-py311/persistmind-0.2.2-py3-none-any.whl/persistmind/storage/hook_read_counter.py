from __future__ import annotations

import sqlite3
from datetime import UTC, datetime, timedelta
from pathlib import Path

from persistmind.branding import resolve_project_state


def record_path_reads(repo: Path, *, task_session_id: str, paths: list[str]) -> int:
    if not task_session_id:
        return 0
    workspace = resolve_project_state(Path(repo).resolve())
    db_path = workspace / "runtime" / "session-read-counter.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    normalized = sorted({path for path in paths if path}) or ["<repository-read>"]
    with sqlite3.connect(db_path, timeout=30.0) as connection:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute(
            "CREATE TABLE IF NOT EXISTS session_read_paths("
            "task_session_id TEXT NOT NULL,"
            "path TEXT NOT NULL,"
            "first_seen TEXT NOT NULL,"
            "last_seen TEXT NOT NULL,"
            "count INTEGER NOT NULL DEFAULT 1,"
            "PRIMARY KEY(task_session_id,path))"
        )
        now = datetime.now(UTC).isoformat().replace("+00:00", "Z")
        for path in normalized:
            connection.execute(
                "INSERT INTO session_read_paths(task_session_id,path,first_seen,last_seen,count) "
                "VALUES(?,?,?,?,1) "
                "ON CONFLICT(task_session_id,path) DO UPDATE SET "
                "last_seen=excluded.last_seen,count=session_read_paths.count+1",
                (task_session_id, path, now, now),
            )
        row = connection.execute(
            "SELECT COUNT(*) FROM session_read_paths "
            "WHERE task_session_id=? OR task_session_id LIKE ?",
            (task_session_id, f"{task_session_id}:%"),
        ).fetchone()
    return int(row[0]) if row else 0


def current_path_read_count(repo: Path, *, task_session_id: str) -> int:
    db_path = resolve_project_state(Path(repo).resolve()) / "runtime" / "session-read-counter.db"
    if not db_path.is_file():
        return 0
    with sqlite3.connect(db_path, timeout=30.0) as connection:
        row = connection.execute(
            "SELECT COUNT(*) FROM session_read_paths "
            "WHERE task_session_id=? OR task_session_id LIKE ?",
            (task_session_id, f"{task_session_id}:%"),
        ).fetchone()
    return int(row[0]) if row else 0


def prune_path_read_counts(repo: Path, *, older_than_days: int = 14) -> int:
    db_path = resolve_project_state(Path(repo).resolve()) / "runtime" / "session-read-counter.db"
    if not db_path.is_file():
        return 0
    cutoff = (
        datetime.now(UTC) - timedelta(days=max(1, int(older_than_days)))
    ).isoformat().replace("+00:00", "Z")
    with sqlite3.connect(db_path, timeout=30.0) as connection:
        connection.execute(
            "CREATE TABLE IF NOT EXISTS session_read_paths("
            "task_session_id TEXT NOT NULL,"
            "path TEXT NOT NULL,"
            "first_seen TEXT NOT NULL,"
            "last_seen TEXT NOT NULL,"
            "count INTEGER NOT NULL DEFAULT 1,"
            "PRIMARY KEY(task_session_id,path))"
        )
        cursor = connection.execute(
            "DELETE FROM session_read_paths WHERE last_seen < ?",
            (cutoff,),
        )
        return int(cursor.rowcount or 0)
