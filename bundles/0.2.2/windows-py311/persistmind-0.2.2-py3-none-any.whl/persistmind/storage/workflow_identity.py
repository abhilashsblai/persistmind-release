from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping

from persistmind.config import load_settings
from persistmind.identifiers import WorkflowIdKind, parse_workflow_id

from .adapters.sqlite_activity import SQLiteActivityStore
from .adapters.sqlite_task import SQLiteTaskStore
from .descriptors import StoreRole
from .runtime import StorageOpenIntent, StorageRuntime, inspect_storage


class WorkflowIdentityError(ValueError):
    def __init__(self, reason: str, message: str | None = None) -> None:
        super().__init__(message or reason)
        self.reason = reason


@dataclass(frozen=True, slots=True)
class WorkflowIdentity:
    task_session_id: str
    pack_id: str | None
    plan_id: str | None
    task_owned_agent_session_id: str | None
    host_agent_session_id: str | None
    current_state: str
    state_revision: int
    governance_revision: int
    governance_input_hash: str | None
    terminal_status: str | None
    terminal_event_id: str | None
    plan_revision: int | None
    active_step_id: str | None
    preflight_ready: bool
    preflight_governance_revision: int | None
    preflight_input_hash: str | None
    verification_id: str | None
    source: str
    consistency_watermark: Mapping[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class WorkflowIdentityResolver:
    """Resolve workflow identity from canonical authority stores before projections."""

    def __init__(
        self,
        repo_root: Path,
        *,
        compatibility_store: Any | None = None,
        allow_development_driver: bool = False,
    ) -> None:
        self.repo_root = repo_root.resolve()
        self.settings = load_settings(self.repo_root)
        self.workspace_root = self.repo_root / self.settings.toolchain.workspace_dir
        self.compatibility_store = compatibility_store
        self._allow_development_driver = allow_development_driver

    def resolve(
        self,
        *,
        task_session_id: str | None = None,
        pack_id: str | None = None,
        plan_id: str | None = None,
        checkpoint_id: str | None = None,
        outcome_id: str | None = None,
        host_agent_session_id: str | None = None,
    ) -> WorkflowIdentity:
        identifiers = {
            "task_session_id": task_session_id,
            "pack_id": pack_id,
            "plan_id": plan_id,
            "checkpoint_id": checkpoint_id,
            "outcome_id": outcome_id,
        }
        parsed = {
            key: parse_workflow_id(kind, value, allow_legacy=True)
            for key, kind, value in (
                ("task_session_id", WorkflowIdKind.TASK, task_session_id),
                ("pack_id", WorkflowIdKind.PACK, pack_id),
                ("plan_id", WorkflowIdKind.PLAN, plan_id),
                ("checkpoint_id", WorkflowIdKind.CHECKPOINT, checkpoint_id),
                ("outcome_id", WorkflowIdKind.OUTCOME, outcome_id),
            )
            if value
        }
        canonical_requested = any(item.canonical for item in parsed.values())
        if canonical_requested:
            if not inspect_storage(self.workspace_root).initialized:
                raise WorkflowIdentityError("canonical_storage_not_initialized")
            return self._resolve_split(
                identifiers,
                parsed,
                host_agent_session_id=host_agent_session_id,
            )
        return self._resolve_compatibility(identifiers, host_agent_session_id=host_agent_session_id)

    def _resolve_split(
        self,
        identifiers: Mapping[str, str | None],
        parsed: Mapping[str, Any],
        *,
        host_agent_session_id: str | None,
    ) -> WorkflowIdentity:
        runtime = StorageRuntime.open(
            self.workspace_root,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=self._allow_development_driver,
            read_only=True,
            required_roles=frozenset({StoreRole.TASK_STATE, StoreRole.ACTIVITY_ACTIVE}),
        )
        try:
            task_set = runtime.router.resolve_read_set(StoreRole.TASK_STATE)
            activity_set = runtime.router.resolve_read_set(StoreRole.ACTIVITY_ACTIVE)
            task_store = task_set[0] if task_set else None
            activity = activity_set[0] if activity_set else None
            if not isinstance(task_store, SQLiteTaskStore) or not isinstance(
                activity, SQLiteActivityStore
            ):
                raise WorkflowIdentityError("canonical_store_unavailable")

            task_id = identifiers.get("task_session_id")
            plan_id = identifiers.get("plan_id")
            checkpoint_id = identifiers.get("checkpoint_id")
            checkpoint = task_store.checkpoint_record(str(checkpoint_id)) if checkpoint_id else None
            if checkpoint_id and checkpoint is None:
                raise WorkflowIdentityError("checkpoint_not_found")
            if checkpoint is not None:
                plan_id = plan_id or str(checkpoint["plan_id"])
                task_id = task_id or str(checkpoint["task_session_id"])
            outcome_id = identifiers.get("outcome_id")
            outcome = activity.event(str(outcome_id)) if outcome_id else None
            if outcome_id and outcome is None:
                raise WorkflowIdentityError("outcome_not_found")
            outcome_payload = _event_payload(outcome) if outcome is not None else {}
            if task_id is None and outcome_payload.get("task_session_id"):
                task_id = str(outcome_payload["task_session_id"])
            if identifiers.get("pack_id") is None and outcome_payload.get("pack_id"):
                identifiers = {**identifiers, "pack_id": str(outcome_payload["pack_id"])}
            plan = task_store.plan(str(plan_id)) if plan_id else None
            if plan_id and plan is None:
                raise WorkflowIdentityError("plan_not_found")
            if task_id is None and plan is not None:
                task_id = str(plan["task_session_id"])

            pack_id = identifiers.get("pack_id")
            pack_manifest = self._nextgen_pack_manifest(activity, str(pack_id)) if pack_id else None
            if pack_id and pack_manifest is None:
                raise WorkflowIdentityError("pack_not_found")
            if task_id is None and pack_manifest and pack_manifest.get("task_session_id"):
                task_id = str(pack_manifest["task_session_id"])
            if task_id is None:
                raise WorkflowIdentityError("missing_task_identifier")
            task = task_store.session(str(task_id))
            if task is None:
                raise WorkflowIdentityError("task_not_found")

            task_pack = str(task.get("pack_id") or "") or None
            if pack_id is None:
                pack_id = task_pack
            elif task_pack and str(pack_id) != task_pack:
                raise WorkflowIdentityError("binding_mismatch", "pack does not belong to task")
            if pack_manifest and pack_manifest.get("task_session_id") not in {None, task_id}:
                raise WorkflowIdentityError(
                    "binding_mismatch", "pack manifest belongs to another task"
                )

            if plan is None:
                plan = task_store.latest_plan(str(task_id))
                plan_id = str(plan["plan_id"]) if plan is not None else None
            elif str(plan["task_session_id"]) != str(task_id):
                raise WorkflowIdentityError("binding_mismatch", "plan belongs to another task")
            if plan is not None:
                plan_pack = str((plan.get("metadata") or {}).get("pack_id") or "") or None
                if pack_id is None:
                    pack_id = plan_pack
                elif plan_pack and plan_pack != str(pack_id):
                    raise WorkflowIdentityError("binding_mismatch", "plan belongs to another pack")

            if checkpoint_id:
                if (
                    plan is None
                    or checkpoint is None
                    or str(checkpoint["plan_id"]) != str(plan["plan_id"])
                ):
                    raise WorkflowIdentityError(
                        "binding_mismatch", "checkpoint belongs to another plan"
                    )

            if outcome_id:
                if outcome_payload.get("task_session_id") not in {None, task_id}:
                    raise WorkflowIdentityError(
                        "binding_mismatch", "outcome belongs to another task"
                    )

            snapshot = task_store.workflow_snapshot(str(task_id)) or {}
            definition = dict(plan.get("plan") or {}) if plan is not None else {}
            checkpoints = (
                list(task_store.checkpoints(str(plan["plan_id"]))) if plan is not None else []
            )
            passing = {
                str(item.get("step_id")) for item in checkpoints if item.get("status") == "pass"
            }
            active_step = next(
                (
                    str(step.get("id") or step.get("title"))
                    for step in definition.get("steps", [])
                    if isinstance(step, Mapping)
                    and str(step.get("id") or step.get("title")) not in passing
                ),
                None,
            )
            terminal_status = str(snapshot.get("terminal_status") or "") or None
            governance_revision = int(
                snapshot.get("governance_revision") or task.get("governance_revision") or 1
            )
            preflight_revision = snapshot.get("preflight_governance_revision")
            projected_ready = snapshot.get("preflight_ready")
            preflight_ready = (
                bool(
                    projected_ready if projected_ready is not None else task is not None and pack_id
                )
                and terminal_status is None
            )
            return WorkflowIdentity(
                task_session_id=str(task_id),
                pack_id=str(pack_id) if pack_id else None,
                plan_id=str(plan["plan_id"]) if plan is not None else None,
                task_owned_agent_session_id=(
                    str(snapshot.get("task_owned_agent_session_id"))
                    if snapshot.get("task_owned_agent_session_id")
                    else None
                ),
                host_agent_session_id=host_agent_session_id,
                current_state=str(task["state"]),
                state_revision=int(task["revision"]),
                governance_revision=governance_revision,
                governance_input_hash=(
                    str(snapshot.get("governance_input_hash"))
                    if snapshot.get("governance_input_hash")
                    else None
                ),
                terminal_status=terminal_status,
                terminal_event_id=(
                    str(snapshot.get("terminal_event_id"))
                    if snapshot.get("terminal_event_id")
                    else None
                ),
                plan_revision=int(plan["revision"]) if plan is not None else None,
                active_step_id=active_step,
                preflight_ready=preflight_ready,
                preflight_governance_revision=(
                    int(preflight_revision) if preflight_revision is not None else None
                ),
                preflight_input_hash=(
                    str(snapshot.get("preflight_input_hash"))
                    if snapshot.get("preflight_input_hash")
                    else None
                ),
                verification_id=(
                    str(snapshot.get("verification_id"))
                    if snapshot.get("verification_id")
                    else None
                ),
                source="canonical_split",
                consistency_watermark={
                    "catalog_generation": int(runtime.topology.generation),
                    "task_store_revision": int(task_store.revision()),
                    "snapshot_revision": int(snapshot.get("revision") or 0),
                },
            )
        finally:
            runtime.close()

    def _resolve_compatibility(
        self,
        identifiers: Mapping[str, str | None],
        *,
        host_agent_session_id: str | None,
    ) -> WorkflowIdentity:
        store = self.compatibility_store
        if store is None:
            raise WorkflowIdentityError("compatibility_store_unavailable")
        task_id = identifiers.get("task_session_id")
        plan_id = identifiers.get("plan_id")
        plan = store.task_plan(plan_id) if plan_id and hasattr(store, "task_plan") else None
        if task_id is None and plan is not None:
            task_id = str(plan["task_session_id"])
        if task_id is None:
            raise WorkflowIdentityError("missing_task_identifier")
        task = store.task_session(task_id)
        if task is None:
            raise WorkflowIdentityError("task_not_found")
        pack_id = identifiers.get("pack_id") or task["pack_id"]
        if identifiers.get("pack_id") and task["pack_id"] and str(task["pack_id"]) != str(pack_id):
            raise WorkflowIdentityError("binding_mismatch")
        if plan is None and hasattr(store, "latest_task_plan_for_session"):
            plan = store.latest_task_plan_for_session(task_id)
        if plan is not None and str(plan["task_session_id"]) != str(task_id):
            raise WorkflowIdentityError("binding_mismatch")
        plan_id = str(plan["plan_id"]) if plan is not None else None
        transitions = (
            store.task_session_transitions(task_id)
            if hasattr(store, "task_session_transitions")
            else []
        )
        state_revision = max(1, len(transitions))
        plan_revision_row = (
            store.latest_task_plan_revision(plan_id)
            if plan_id and hasattr(store, "latest_task_plan_revision")
            else None
        )
        return WorkflowIdentity(
            task_session_id=str(task_id),
            pack_id=str(pack_id) if pack_id else None,
            plan_id=plan_id,
            task_owned_agent_session_id=None,
            host_agent_session_id=host_agent_session_id,
            current_state=str(task["current_state"]),
            state_revision=state_revision,
            governance_revision=state_revision,
            governance_input_hash=None,
            terminal_status=None,
            terminal_event_id=None,
            plan_revision=(
                int(plan_revision_row["revision_number"]) if plan_revision_row is not None else None
            ),
            active_step_id="legacy-active"
            if plan is not None and str(plan["status"]) == "active"
            else None,
            preflight_ready=bool(pack_id),
            preflight_governance_revision=None,
            preflight_input_hash=None,
            verification_id=None,
            source="compatibility_projection",
            consistency_watermark={"task_revision": state_revision},
        )

    @staticmethod
    def _nextgen_pack_manifest(
        activity: SQLiteActivityStore, pack_id: str
    ) -> Mapping[str, Any] | None:
        event = activity.event(pack_id)
        if event is None or event.get("event_type") != "context_pack.finalized":
            return None
        payload = _event_payload(event)
        manifest = payload.get("manifest")
        return manifest if isinstance(manifest, Mapping) else payload


def _event_payload(event: Mapping[str, Any]) -> dict[str, Any]:
    value: Any = event.get("payload")
    if isinstance(value, Mapping) and isinstance(value.get("payload"), Mapping):
        value = value["payload"]
    return dict(value) if isinstance(value, Mapping) else {}


__all__ = [
    "WorkflowIdentity",
    "WorkflowIdentityError",
    "WorkflowIdentityResolver",
]
