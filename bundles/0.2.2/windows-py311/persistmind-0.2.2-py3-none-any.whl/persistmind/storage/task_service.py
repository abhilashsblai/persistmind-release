from __future__ import annotations

import fnmatch
import json
import re
import secrets
import subprocess
from collections.abc import Iterable, Mapping, Sequence
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from persistmind.application.execution_scope import current_operation_scope
from persistmind.application.task_envelope import (
    ResolutionStatus,
    TaskEnvelope,
    resolution_satisfies_gate,
    resolve_status,
)
from persistmind.cie.checklists import checklist_preview
from persistmind.cie.contract_extraction import extract_named_symbols
from persistmind.config import load_settings
from persistmind.git_utils import git_changed_paths
from persistmind.governance.plans import (
    _apply_governed_defaults,
    intended_files,
    normalize_plan,
    plan_hash,
    required_contract_items,
    required_verification_names,
)
from persistmind.governance.policy import CapabilityPolicy
from persistmind.utils import (
    canonical_json,
    canonical_repo_scope,
    normalize_repo_relative_path,
    repo_path_matches_scope,
    sha256_text,
    stable_id,
    utc_now,
)
from persistmind.verification.scope_assessment import assess_scope_documents
from persistmind.workflow.evidence import (
    build_verification_evidence,
    current_diff_fingerprint,
    evidence_qualifies,
)
from persistmind.workflow.playbook import GATE_KINDS

from .adapters.sqlite_activity import SQLiteActivityStore
from .adapters.sqlite_knowledge import SQLiteKnowledgeStore
from .adapters.sqlite_learning import SQLiteLearningStore
from .adapters.sqlite_policy import SQLitePolicyStore
from .adapters.sqlite_source import SQLiteSourceStore
from .adapters.sqlite_task import SQLiteTaskStore, TaskConflict
from .descriptors import StoreRole
from .external_evidence import knowledge_evidence, normalize_verified_fact
from .runtime import StorageOpenIntent, StorageRuntime
from .task_chain import transition_hash as _transition_hash
from .task_chain import verify_transition_chain as _verify_transition_chain
from .workflow_lifecycle import WorkflowLifecycleCoordinator

TASK_STATES = ("INTAKE", "PACK", "PLAN", "EXECUTE", "PREFLIGHT", "OUTCOME")
TASK_CLOSE_RESULTS = ("fail", "partial", "cancelled", "blocked")


class TaskService:
    """Task/plan application port backed only by the Task State role.

    It depends only on declared authority ports and cannot open undeclared storage.
    Task, plan, continuation, intent, goal, reasoning, experience, working
    memory, Policy, Learning, Source, and Knowledge promotion all resolve via
    role-owned role ports.
    """

    def __init__(
        self,
        repo_root: Path,
        *,
        allow_development_driver: bool = False,
        read_only: bool = False,
    ) -> None:
        self.repo_root = repo_root.resolve()
        self._allow_development_driver = allow_development_driver
        self.settings = load_settings(self.repo_root)
        self.workspace_id = stable_id(str(self.repo_root))[:16]
        self.repo_id = self.workspace_id
        self._read_only = read_only
        operation_scope = current_operation_scope()
        required_roles = (
            frozenset(StoreRole(role) for role in operation_scope.roles)
            if operation_scope is not None
            else frozenset(
                {
                    StoreRole.TASK_STATE,
                    StoreRole.ACTIVITY_ACTIVE,
                    StoreRole.LEARNING,
                    StoreRole.POLICY,
                    StoreRole.SOURCE_MANIFEST,
                    StoreRole.KNOWLEDGE,
                }
            )
        ) | {StoreRole.TASK_STATE}
        self.runtime = StorageRuntime.open(
            self.repo_root / self.settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=allow_development_driver,
            read_only=read_only,
            required_roles=required_roles,
        )
        store = self._role(StoreRole.TASK_STATE)
        if not isinstance(store, SQLiteTaskStore):
            raise RuntimeError("task-state route did not resolve to SQLiteTaskStore")
        self.store = store
        self._activity: SQLiteActivityStore | None = None
        self._learning: SQLiteLearningStore | None = None
        self._policy: SQLitePolicyStore | None = None
        self._source: SQLiteSourceStore | None = None
        self._knowledge: SQLiteKnowledgeStore | None = None
        self.lifecycle = WorkflowLifecycleCoordinator(
            self.repo_root,
            allow_development_driver=allow_development_driver,
            runtime=self.runtime,
        )

    def close(self) -> None:
        self.runtime.close()

    def __enter__(self) -> TaskService:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def _role(self, role: StoreRole) -> Any:
        if self._read_only or role is not StoreRole.TASK_STATE:
            stores = self.runtime.router.resolve_read_set(role)
            if not stores:
                raise RuntimeError(f"read route is unavailable: {role.value}")
            return stores[0]
        return self.runtime.router.resolve_write_store(role)

    @property
    def activity(self) -> SQLiteActivityStore:
        if self._activity is None:
            value = self._role(StoreRole.ACTIVITY_ACTIVE)
            if not isinstance(value, SQLiteActivityStore):
                raise RuntimeError("Activity route did not resolve")
            self._activity = value
        return self._activity

    @property
    def learning(self) -> SQLiteLearningStore:
        if self._learning is None:
            value = self._role(StoreRole.LEARNING)
            if not isinstance(value, SQLiteLearningStore):
                raise RuntimeError("Learning route did not resolve")
            self._learning = value
        return self._learning

    @property
    def policy(self) -> SQLitePolicyStore:
        if self._policy is None:
            value = self._role(StoreRole.POLICY)
            if not isinstance(value, SQLitePolicyStore):
                raise RuntimeError("Policy route did not resolve")
            self._policy = value
        return self._policy

    @property
    def source(self) -> SQLiteSourceStore:
        if self._source is None:
            value = self._role(StoreRole.SOURCE_MANIFEST)
            if not isinstance(value, SQLiteSourceStore):
                raise RuntimeError("Source route did not resolve")
            self._source = value
        return self._source

    @property
    def knowledge(self) -> SQLiteKnowledgeStore:
        if self._knowledge is None:
            value = self._role(StoreRole.KNOWLEDGE)
            if not isinstance(value, SQLiteKnowledgeStore):
                raise RuntimeError("Knowledge route did not resolve")
            self._knowledge = value
        return self._knowledge

    def task_start(self, task: str) -> dict[str, Any]:
        task = task.strip()
        if not task:
            raise ValueError("task must be non-empty")
        task_session_id = "task_" + stable_id(self.workspace_id, self.repo_id, sha256_text(task))
        existing = self.store.session(task_session_id)
        if existing is not None:
            self._ensure_task_envelope(existing, task=task, actor="system")
            event = next(
                (
                    item
                    for item in self.lifecycle.events(task_session_id)
                    if item.get("event_type") == "TaskStarted.v1"
                ),
                None,
            )
            if event is None:
                event = self.lifecycle.emit(
                    "TaskStarted.v1",
                    task_session_id,
                    source_operation_key=f"task-start:{task_session_id}",
                    payload={
                        "initial_state": "INTAKE",
                        "state_revision": 1,
                        "governance_revision": 1,
                        "task_text_hash": str(existing.get("task_text_hash") or ""),
                    },
                    producer="task-service",
                )
            agent_session_id = self._ensure_task_owned_agent_session(
                existing,
                lifecycle_event=event,
            )
            return self._task_start_response(
                existing,
                created=False,
                lifecycle_event=event,
                agent_session_id=agent_session_id,
            )
        payload = {
            "workspace_id": self.workspace_id,
            "repo_id": self.repo_id,
            "task_text_hash": sha256_text(task),
            "metadata": {"objective": task, "task": task},
            "constitution_hash": None,
            "current_state": "INTAKE",
            "last_actor": "system",
            "last_reason": "task_start",
            "pack_id": None,
            "policy_authority": "not_routed",
            "prev_hash": "",
        }
        payload["transition_hash"] = _transition_hash(
            task_session_id,
            None,
            "INTAKE",
            "system",
            "task_start",
            None,
            None,
            "",
        )
        created = self.store.create_session(
            task_session_id,
            state="INTAKE",
            payload=payload,
            idempotency_key=f"task-start:{task_session_id}",
        )
        self._ensure_task_envelope(created, task=task, actor="system")
        self._upsert_continuation(
            created,
            event="task_start",
            state="intake",
            next_action="Request or serve a PersistMind context pack for this task.",
        )
        event = self.lifecycle.emit(
            "TaskStarted.v1",
            task_session_id,
            source_operation_key=f"task-start:{task_session_id}",
            payload={
                "initial_state": "INTAKE",
                "state_revision": int(created["revision"]),
                "governance_revision": 1,
                "task_text_hash": str(created.get("task_text_hash") or ""),
            },
            producer="task-service",
        )
        agent_session_id = self._ensure_task_owned_agent_session(
            created,
            lifecycle_event=event,
        )
        return self._task_start_response(
            created,
            created=True,
            lifecycle_event=event,
            agent_session_id=agent_session_id,
        )

    def execute_policy_decision(self, decision_id: str) -> dict[str, Any]:
        """Turn an approved Policy decision into a Task command, never direct execution."""
        decision = self.policy.action_decision(decision_id)
        if decision is None:
            raise KeyError(f"unknown Policy decision: {decision_id}")
        if str(decision["decision"]) != "approved":
            raise PermissionError("only approved Policy decisions may create Task commands")
        proposal = json.loads(str(decision["proposal_json"]))
        payload = json.loads(str(proposal["payload_json"]))
        objective = str(
            payload.get("task")
            or payload.get("objective")
            or payload.get("rationale")
            or proposal["action_class"]
        ).strip()
        started = self.task_start(objective)
        proposal_id = str(decision["proposal_id"])
        event = self.lifecycle.emit(
            "TaskDecisionObserved.v1",
            str(started["task_session_id"]),
            source_operation_key=f"policy-task-dispatch:{decision_id}",
            payload={
                "decision_id": decision_id,
                "proposal_id": proposal_id,
                "task_session_id": started["task_session_id"],
                "principal": "task-service",
            },
            producer="task-service",
            required_consumers=("learning.task_dispatch.v1",),
        )
        from .task_reconciler import TaskProjectionReconciler

        projection = TaskProjectionReconciler(
            self.repo_root,
            allow_development_driver=self._allow_development_driver,
        ).apply_learning_dispatch(event)
        return {
            "ok": True,
            "schema_version": "persistmind.policy_task_dispatch.v1",
            "decision_id": decision_id,
            "proposal_id": proposal_id,
            "task_session_id": started["task_session_id"],
            "state": "dispatched",
            "execution_authority": "task",
            "learning_projection": projection,
        }

    def codex_preflight(
        self,
        task: str,
        *,
        paths: list[str] | None = None,
        mode: str = "write",
        probe: bool = False,
        task_session_id: str | None = None,
    ) -> dict[str, Any]:
        """Serve preflight from the same Task and pack authorities."""

        task = task.strip()
        if not task:
            raise ValueError("codex preflight requires a non-empty task")
        if task_session_id:
            session = self._session_or_raise(task_session_id)
            if str(session.get("task_text_hash") or "") != sha256_text(task):
                raise ValueError("task session does not match the requested preflight task")
        else:
            started = self.task_start(task)
            task_session_id = str(started["task_session_id"])
            session = self._session_or_raise(task_session_id)

        bound_pack_id = str(session.get("pack_id") or "")
        active_plan = self.store.latest_plan(task_session_id)
        active_plan_id = str((active_plan or {}).get("plan_id") or "") or None
        if probe:
            return {
                "ok": True,
                "status": "ready" if bound_pack_id else "pack_required",
                "probe_only": True,
                "preflight_ready": bool(bound_pack_id),
                "task_session_id": task_session_id,
                "pack_id": bound_pack_id or None,
                "plan_id": active_plan_id,
                "mode": mode,
                "nextgen_v1": True,
            }
        if (
            not bound_pack_id
            and _task_lifecycle_lightweight(self.settings, self.repo_root, paths or [])
        ):
            return {
                "ok": True,
                "status": "pack_required",
                "probe_only": True,
                "lightweight": True,
                "preflight_ready": False,
                "task_session_id": task_session_id,
                "pack_id": None,
                "plan_id": active_plan_id,
                "mode": mode,
                "nextgen_v1": True,
            }

        from .pack_service import PackService

        with PackService(
            self.repo_root,
            allow_development_driver=self._allow_development_driver,
        ) as packs:
            if bound_pack_id:
                pack = packs.get_pack_manifest(bound_pack_id)
                if not pack.get("ok"):
                    return {
                        "ok": False,
                        "status": "pack_unusable",
                        "preflight_ready": False,
                        "task_session_id": task_session_id,
                        "pack_id": bound_pack_id,
                        "plan_id": active_plan_id,
                        "remediation": "Create and bind a fresh persistmind-nextgen-v1 context pack.",
                        "nextgen_v1": True,
                    }
            else:
                pack = packs.get_context_pack(
                    task,
                    seed_paths=paths or [],
                    task_session_id=task_session_id,
                )
        if not pack.get("ok"):
            return {
                **pack,
                "preflight_ready": False,
                "task_session_id": task_session_id,
                "plan_id": active_plan_id,
                "nextgen_v1": True,
            }
        evidence_record_id: str | None = None
        evidence_error: str | None = None
        try:
            from .pack_evidence import record_pack_manifest_evidence

            evidence_record_id = record_pack_manifest_evidence(
                self.repo_root,
                task_session_id=task_session_id,
                pack_id=str(pack["pack_id"]),
                manifest=pack,
                allow_development_driver=self._allow_development_driver,
            )
        except Exception as exc:
            evidence_error = type(exc).__name__
        from persistmind.context_snippets import matched_snippet_previews
        from persistmind.storage.knowledge_service import KnowledgeService

        with KnowledgeService(
            self.repo_root,
            allow_development_driver=self._allow_development_driver,
            read_only=True,
        ) as knowledge:
            recall = _recall_preflight_durable_facts(
                knowledge,
                task,
                paths=paths or [],
                limit=20,
            )
        acceptance_checklist = extract_named_symbols(task)
        checklist_token_estimate = max(0, len(canonical_json(acceptance_checklist)) // 4)
        dynamic_checklist = checklist_preview(task, paths or [])
        from persistmind.metacognition.controller import MetacognitiveController

        metacognitive_advisory = MetacognitiveController(self.settings.metacognition).tick(
            task=task,
            checkpoint="codex_preflight",
            signals={
                "path_count": len(paths or []),
                "memory_recall_count": len(recall["records"]),
                "stale_memory_count": len(recall["stale_records"]),
                "pack_item_count": len(pack.get("items", [])),
            },
            task_session_id=task_session_id,
        )
        metacognitive_advisory["advisory_only"] = True
        metacognitive_advisory["authoritative"] = False
        hook_coverage: dict[str, Any] | None = None
        if mode.strip().casefold() == "write" and self.settings.governance.require_hook_coverage:
            from persistmind.agent_runtime.hooks import hook_coverage_status

            hook_coverage = hook_coverage_status(self.repo_root)
            if not hook_coverage.get("covered"):
                return {
                    "ok": False,
                    "status": "hook_coverage_required",
                    "preflight_ready": False,
                    "task_session_id": task_session_id,
                    "pack_id": pack["pack_id"],
                    "plan_id": active_plan_id,
                    "mode": mode,
                    "hook_coverage": hook_coverage,
                    "nextgen_v1": True,
                }

        return {
            "ok": True,
            "status": "ready",
            "preflight_ready": True,
            "task_session_id": task_session_id,
            "pack_id": pack["pack_id"],
            "plan_id": active_plan_id,
            "pack_path_count": len(
                {
                    str(item.get("path"))
                    for item in pack.get("items", [])
                    if isinstance(item, dict) and item.get("path")
                }
            ),
            "snapshot_id": pack.get("snapshot_id"),
            "source_generation_id": pack.get("source_generation_id"),
            "matched_snippets": matched_snippet_previews(pack),
            "memory_recall": recall,
            "durable_facts": recall["records"],
            "stale_durable_facts": recall["stale_records"],
            "acceptance_checklist": acceptance_checklist,
            "checklist_token_estimate": checklist_token_estimate,
            "checklist_status": "populated" if acceptance_checklist else "empty",
            "checklist_preview": dynamic_checklist.to_dict(),
            "metacognitive_advisory": metacognitive_advisory,
            "mode": mode,
            **({"hook_coverage": hook_coverage} if hook_coverage is not None else {}),
            "pack_manifest_evidence_record_id": evidence_record_id,
            "pack_manifest_evidence_status": "recorded"
            if evidence_record_id
            else "record_failed",
            **(
                {"pack_manifest_evidence_error": evidence_error}
                if evidence_error is not None
                else {}
            ),
            "nextgen_v1": True,
        }

    def task_transition(
        self,
        task_session_id: str,
        state: str,
        *,
        actor: str = "local-user",
        reason: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        current = self._session_or_raise(task_session_id)
        target = state.strip().upper()
        if target not in TASK_STATES:
            raise ValueError(f"unknown task state: {target}")
        current_state = str(current["state"])
        if not _allowed_transition(current_state, target):
            raise ValueError(f"invalid task transition: {current_state} -> {target}")
        plan_for_lightweight = self.store.latest_plan(task_session_id)
        lightweight = _task_lifecycle_lightweight(
            self.settings,
            self.repo_root,
            plan_document=dict(plan_for_lightweight.get("plan") or {})
            if isinstance(plan_for_lightweight, Mapping)
            else None,
        )
        if target in {"PLAN", "EXECUTE"} and not lightweight:
            phase = "planning" if target == "PLAN" else "pre_action"
            latest_uncertainty = self._latest_uncertainty(task_session_id)
            if latest_uncertainty is None or str(latest_uncertainty["phase"]) != phase:
                latest_uncertainty = self.uncertainty_record(
                    task_session_id,
                    phase=phase,
                    conditions=(ResolutionStatus.CANDIDATE,),
                    metrics={"reason": "awaiting phase-specific evidence"},
                )
            if target == "EXECUTE" and str(
                latest_uncertainty.get("primary_status")
                or latest_uncertainty.get("recommended_resolution")
            ) in {
                "unsafe",
                "not_authorized",
                "contradictory",
                "underspecified",
                "external_dependency",
                "not_computable",
            }:
                raise PermissionError(
                    "task cannot enter execution while a blocking resolution condition is active"
                )
        terminal_resolution = None
        if target == "OUTCOME":
            self._require_current_check_diff_for_outcome(task_session_id)
            resolution_id = "resolution_" + stable_id(task_session_id)[:32]
            terminal_resolution = self.store.get(resolution_id)
            if terminal_resolution is None:
                terminal_resolution = self.task_resolve(
                    task_session_id,
                    conditions=(ResolutionStatus.UNKNOWN,),
                    evidence=[],
                    limitations=["No terminal verifier evidence was recorded."],
                )
        transitions = self.store.transitions(task_session_id)
        previous_hash = str(transitions[-1].get("transition_hash") or "") if transitions else ""
        effective_pack_id = str(pack_id or current.get("pack_id") or "") or None
        transition_id = "transition_" + stable_id(
            task_session_id,
            current["revision"],
            target,
            actor,
            reason or "",
            effective_pack_id or "",
        )
        payload = {
            **_payload(current),
            "current_state": target,
            "pack_id": effective_pack_id,
            "last_actor": actor,
            "last_reason": reason,
            "prev_hash": previous_hash,
        }
        if terminal_resolution is not None:
            payload["terminal_status"] = terminal_resolution["primary_status"]
            payload["terminal_resolution_id"] = terminal_resolution["record_id"]
        payload["transition_hash"] = _transition_hash(
            task_session_id,
            current_state,
            target,
            actor,
            reason,
            effective_pack_id,
            payload.get("constitution_hash"),
            previous_hash,
        )
        updated = self.store.transition(
            task_session_id,
            to_state=target,
            payload=payload,
            expected_revision=int(current["revision"]),
            transition_id=transition_id,
            idempotency_key=f"task-transition:{transition_id}",
        )
        self._upsert_continuation(
            updated,
            event="task_transition",
            state=_continuation_state(target),
            reason=reason,
        )
        event_type = (
            "PackBound.v1" if target == "PACK" and payload.get("pack_id") else "TaskTransitioned.v1"
        )
        source_key = (
            f"pack-bind:{task_session_id}:{payload['pack_id']}"
            if event_type == "PackBound.v1"
            else f"task-transition:{task_session_id}:{current_state}:{target}:{current['revision']}"
        )
        event_payload = {
            "transition_id": transition_id,
            "from_state": current_state,
            "to_state": target,
            "state_revision": int(updated["revision"]),
        }
        if payload.get("pack_id"):
            event_payload["pack_id"] = str(payload["pack_id"])
        event = self.lifecycle.emit(
            event_type,
            task_session_id,
            source_operation_key=source_key,
            payload=event_payload,
            producer="task-service",
        )
        envelope = None
        if target == "EXECUTE" and not lightweight:
            envelope = self.freeze_task_envelope(task_session_id, actor=actor)
        return {
            "ok": True,
            "schema_version": "persistmind.task_transition.v1",
            "task_session_id": task_session_id,
            "transition_id": transition_id,
            "from_state": current_state,
            "to_state": target,
            "revision": updated["revision"],
            "agent_session_id": None,
            "nextgen_v1": True,
            "lifecycle_event_id": event["event_id"],
            "lifecycle_sequence": event["sequence"],
            "task_envelope": envelope,
            "resolution": terminal_resolution,
        }

    def task_action_authorize(
        self,
        task_session_id: str,
        *,
        grant_id: str,
        capability: str,
        artifact_version: str,
        risk_class: str,
        action: Mapping[str, Any],
        context: Mapping[str, Any],
        utility: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Perform and consume the Policy check immediately before one bounded action."""
        session = self._session_or_raise(task_session_id)
        if str(session["state"]) not in {"EXECUTE", "PREFLIGHT"}:
            raise PermissionError("actions require an EXECUTE or PREFLIGHT task state")
        action_value = dict(action)
        action_name = str(action_value.get("action") or action_value.get("id") or "").strip()
        if not action_name:
            raise ValueError("bounded action requires an action or id field")
        from .policy_service import PolicyService

        with PolicyService(
            self.repo_root,
            allow_development_driver=self._allow_development_driver,
        ) as policy:
            authorization = policy.autonomy_grant_consume(
                grant_id,
                task_session_id=task_session_id,
                capability=capability,
                artifact_version=artifact_version,
                risk_class=risk_class,
                action=action_value,
                context={**dict(context), "action": action_name},
            )
        grant = dict(authorization["grant"])
        policy_hash = "sha256:" + sha256_text(canonical_json(grant))
        decision = self.decision_record(
            task_session_id,
            actions=[action_value],
            chosen_action=action_name,
            utility=dict(utility or {}),
            risk={"risk_class": risk_class, "pre_action_authorization": authorization},
            policy_decision_id=grant_id,
            policy_decision_hash=policy_hash,
        )
        event = self.lifecycle.emit(
            "TaskDecisionObserved.v1",
            task_session_id,
            source_operation_key=f"task-action:{decision['decision_id']}",
            payload={
                "decision_id": decision["decision_id"],
                "grant_id": grant_id,
                "action_hash": authorization["action_hash"],
                "risk_class": risk_class,
                "policy_decision_hash": policy_hash,
            },
            producer="task-service",
            required_consumers=("activity.task_decision.v1", "audit.task_decision.v1"),
        )
        return {
            "ok": True,
            "status": "authorized",
            "schema_version": "persistmind.task_action_authorization.v1",
            "task_session_id": task_session_id,
            "decision": decision,
            "authorization": authorization,
            "event": event,
        }

    def task_action_observe(
        self,
        task_session_id: str,
        *,
        action_hash: str,
        conditions: Iterable[str | ResolutionStatus],
        metrics: Mapping[str, Any],
    ) -> dict[str, Any]:
        snapshot = self.uncertainty_record(
            task_session_id,
            phase="post_observation",
            conditions=conditions,
            metrics={**dict(metrics), "action_hash": action_hash},
        )
        return {
            "ok": True,
            "status": snapshot["primary_status"],
            "schema_version": "persistmind.task_action_observation.v1",
            "uncertainty": snapshot,
        }

    def task_show(self, task_session_id: str) -> dict[str, Any]:
        session = self.store.session(task_session_id)
        if session is None:
            return {
                "ok": False,
                "error": "task session not found",
                "task_session_id": task_session_id,
            }
        transitions = [dict(item) for item in self.store.transitions(task_session_id)]
        payload = _payload(session)
        chain = _verify_transition_chain(task_session_id, transitions)
        envelope = self.task_envelope(task_session_id)
        closure = self._terminal_closure(task_session_id)
        return {
            "ok": bool(chain["ok"]),
            "status": "ok" if chain["ok"] else "task_history_invalid",
            "schema_version": "persistmind.task_show.v1",
            "session": {
                **dict(session),
                "current_state": session["state"],
                "metadata": dict(payload.get("metadata") or {}),
            },
            "transitions": transitions,
            "chain": chain,
            "task_envelope": envelope,
            "terminal_closure": closure,
            "nextgen_v1": True,
        }

    def task_envelope(self, task_session_id: str) -> dict[str, Any] | None:
        row = (
            self.store._reader()
            .execute(
                "SELECT * FROM task_envelopes WHERE task_session_id=? "
                "ORDER BY revision DESC LIMIT 1",
                (task_session_id,),
            )
            .fetchone()
        )
        if row is None:
            return None
        result = dict(row)
        result["envelope"] = json.loads(str(result.pop("envelope_json")))
        return result

    def amend_task_envelope(
        self,
        task_session_id: str,
        envelope: Mapping[str, Any],
        *,
        actor: str,
        rationale: str,
    ) -> dict[str, Any]:
        current = self.task_envelope(task_session_id)
        if current is None:
            raise KeyError(f"task envelope not found: {task_session_id}")
        if current.get("frozen_at"):
            raise PermissionError("TaskEnvelope.v1 is immutable after execution starts")
        document = dict(envelope)
        document.update(
            {
                "schema_version": "TaskEnvelope.v1",
                "actor": actor,
                "rationale": rationale,
                "prior_envelope_hash": str(current["envelope_hash"]),
            }
        )
        normalized = TaskEnvelope.from_mapping(document)
        revision = int(current["revision"]) + 1
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT INTO task_envelopes VALUES(?,?,?,?,?,NULL,?)",
                (
                    task_session_id,
                    revision,
                    canonical_json(normalized.document()),
                    normalized.envelope_hash,
                    actor,
                    utc_now(),
                ),
            )
            self.store.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return dict(self.task_envelope(task_session_id) or {})

    def freeze_task_envelope(self, task_session_id: str, *, actor: str) -> dict[str, Any]:
        current = self.task_envelope(task_session_id)
        if current is None:
            raise KeyError(f"task envelope not found: {task_session_id}")
        if current.get("frozen_at"):
            return current
        frozen_at = utc_now()
        with self.store._write_lock, self.store.connection:
            cursor = self.store.connection.execute(
                "UPDATE task_envelopes SET frozen_at=? WHERE task_session_id=? "
                "AND revision=? AND frozen_at IS NULL",
                (frozen_at, task_session_id, int(current["revision"])),
            )
            if cursor.rowcount != 1:
                raise RuntimeError("TaskEnvelope.v1 freeze lost a concurrent transition")
            self.store.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        event = self.lifecycle.emit(
            "TaskEnvelopeFrozen.v1",
            task_session_id,
            source_operation_key=f"task-envelope-freeze:{task_session_id}:{current['revision']}",
            payload={
                "envelope_hash": current["envelope_hash"],
                "revision": current["revision"],
                "actor": actor,
                "frozen_at": frozen_at,
            },
            producer="task-service",
        )
        result = dict(self.task_envelope(task_session_id) or {})
        result["event_id"] = event["event_id"]
        return result

    def hypothesis_create(
        self,
        task_session_id: str,
        proposition: str,
        *,
        assumptions: list[Mapping[str, Any]] | None = None,
        support: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        self._session_or_raise(task_session_id)
        normalized = proposition.strip()
        if not normalized:
            raise ValueError("hypothesis proposition is required")
        proposition_hash = "sha256:" + sha256_text(canonical_json(normalized))
        hypothesis_id = "hypothesis_" + stable_id(task_session_id, proposition_hash)[:32]
        now = utc_now()
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT INTO task_hypotheses VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    hypothesis_id,
                    task_session_id,
                    proposition_hash,
                    "proposed",
                    canonical_json(dict(support or {})),
                    canonical_json(list(assumptions or [])),
                    1,
                    now,
                    now,
                ),
            )
            self.store.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return dict(self.hypothesis_show(hypothesis_id))

    def hypothesis_transition(
        self,
        hypothesis_id: str,
        *,
        state: str,
        support: Mapping[str, Any],
        expected_revision: int,
    ) -> dict[str, Any]:
        normalized = state.strip().lower()
        if normalized not in {
            "proposed",
            "supported",
            "refuted",
            "contested",
            "unknown",
            "superseded",
        }:
            raise ValueError(f"unsupported hypothesis state: {state}")
        with self.store._write_lock, self.store.connection:
            cursor = self.store.connection.execute(
                "UPDATE task_hypotheses SET state=?,support_json=?,revision=revision+1,"
                "updated_at=? WHERE hypothesis_id=? AND revision=?",
                (
                    normalized,
                    canonical_json(dict(support)),
                    utc_now(),
                    hypothesis_id,
                    expected_revision,
                ),
            )
            if cursor.rowcount != 1:
                raise TaskConflict("hypothesis revision changed")
            self.store.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return dict(self.hypothesis_show(hypothesis_id))

    def hypothesis_show(self, hypothesis_id: str) -> dict[str, Any]:
        row = (
            self.store._reader()
            .execute("SELECT * FROM task_hypotheses WHERE hypothesis_id=?", (hypothesis_id,))
            .fetchone()
        )
        if row is None:
            raise KeyError(f"hypothesis not found: {hypothesis_id}")
        result = dict(row)
        result["support"] = json.loads(str(result.pop("support_json")))
        result["assumptions"] = json.loads(str(result.pop("assumptions_json")))
        return result

    def uncertainty_record(
        self,
        task_session_id: str,
        *,
        phase: str,
        conditions: Iterable[str | ResolutionStatus],
        metrics: Mapping[str, Any],
    ) -> dict[str, Any]:
        self._session_or_raise(task_session_id)
        primary, secondary = resolve_status(conditions)
        snapshot_id = (
            "uncertainty_" + stable_id(task_session_id, phase, utc_now(), primary.value)[:32]
        )
        document = {
            **dict(metrics),
            "primary_status": primary.value,
            "secondary_reasons": [item.value for item in secondary],
        }
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT INTO task_uncertainty_snapshots VALUES(?,?,?,?,?,?)",
                (
                    snapshot_id,
                    task_session_id,
                    phase,
                    canonical_json(document),
                    primary.value,
                    utc_now(),
                ),
            )
            self.store.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return {
            "snapshot_id": snapshot_id,
            "task_session_id": task_session_id,
            "phase": phase,
            "primary_status": primary.value,
            "secondary_reasons": [item.value for item in secondary],
            "metrics": dict(metrics),
        }

    def _latest_uncertainty(self, task_session_id: str) -> dict[str, Any] | None:
        row = (
            self.store._reader()
            .execute(
                "SELECT * FROM task_uncertainty_snapshots WHERE task_session_id=? "
                "ORDER BY created_at DESC,snapshot_id DESC LIMIT 1",
                (task_session_id,),
            )
            .fetchone()
        )
        if row is None:
            return None
        result = dict(row)
        result["metrics"] = json.loads(str(result.pop("metrics_json")))
        result["primary_status"] = result["recommended_resolution"]
        return result

    def decision_record(
        self,
        task_session_id: str,
        *,
        actions: list[Mapping[str, Any]],
        chosen_action: str,
        utility: Mapping[str, Any],
        risk: Mapping[str, Any],
        policy_decision_id: str | None = None,
        policy_decision_hash: str | None = None,
    ) -> dict[str, Any]:
        self._session_or_raise(task_session_id)
        if bool(policy_decision_id) != bool(policy_decision_hash):
            raise ValueError("Policy decision id and hash must be supplied together")
        normalized_actions = [dict(item) for item in actions]
        action_names = {str(item.get("action") or item.get("id") or "") for item in actions}
        if chosen_action not in action_names:
            raise ValueError("chosen action is not in the declared action set")
        action_set_hash = "sha256:" + sha256_text(canonical_json(normalized_actions))
        decision_id = "decision_" + stable_id(task_session_id, action_set_hash, chosen_action)[:32]
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT INTO task_decision_points VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    decision_id,
                    task_session_id,
                    action_set_hash,
                    chosen_action,
                    canonical_json(dict(utility)),
                    canonical_json(dict(risk)),
                    policy_decision_id,
                    policy_decision_hash,
                    utc_now(),
                ),
            )
            self.store.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return {
            "ok": True,
            "schema_version": "persistmind.task_decision_point.v1",
            "decision_id": decision_id,
            "action_set_hash": action_set_hash,
            "chosen_action": chosen_action,
        }

    def task_resolve(
        self,
        task_session_id: str,
        *,
        conditions: Iterable[str | ResolutionStatus],
        evidence: list[Mapping[str, Any]],
        limitations: list[str] | None = None,
        approximation_bound: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        self._session_or_raise(task_session_id)
        primary, secondary = resolve_status(conditions)
        if primary is ResolutionStatus.VERIFIED and not evidence:
            raise ValueError("verified resolution requires verifier evidence")
        if primary is ResolutionStatus.BOUNDED_APPROXIMATION and not approximation_bound:
            raise ValueError("bounded approximation requires an explicit error/resource bound")
        record_id = "resolution_" + stable_id(task_session_id)[:32]
        document = {
            "record_id": record_id,
            "kind": "task_resolution",
            "scope": task_session_id,
            "task_session_id": task_session_id,
            "primary_status": primary.value,
            "secondary_reasons": [item.value for item in secondary],
            "evidence": [dict(item) for item in evidence],
            "limitations": list(limitations or []),
            "approximation_bound": dict(approximation_bound or {}),
            "resolved_at": utc_now(),
        }
        self.store.put(document, idempotency_key="task-resolution:" + task_session_id)
        return {"ok": True, "schema_version": "persistmind.task_resolution.v1", **document}

    def capability_negotiate(
        self,
        task_session_id: str,
        *,
        required: Iterable[str],
        available: Iterable[str],
        authorized: Iterable[str],
        physically_possible: Iterable[str],
    ) -> dict[str, Any]:
        self._session_or_raise(task_session_id)
        required_set = {str(item) for item in required}
        available_set = {str(item) for item in available}
        authorized_set = {str(item) for item in authorized}
        possible_set = {str(item) for item in physically_possible}
        permitted = available_set & authorized_set & possible_set
        missing = sorted(required_set - permitted)
        unavailable = sorted(required_set - available_set)
        unauthorized = sorted((required_set & available_set) - authorized_set)
        impossible = sorted((required_set & available_set & authorized_set) - possible_set)
        conditions = []
        if unauthorized:
            conditions.append(ResolutionStatus.NOT_AUTHORIZED)
        if impossible:
            conditions.append(ResolutionStatus.UNSAFE)
        if unavailable:
            conditions.append(ResolutionStatus.EXTERNAL_DEPENDENCY)
        if not conditions:
            conditions.append(ResolutionStatus.CANDIDATE)
        primary, secondary = resolve_status(conditions)
        if missing:
            self.state_create(
                "capability_continuation",
                {
                    "task_session_id": task_session_id,
                    "missing": missing,
                    "unavailable": unavailable,
                    "unauthorized": unauthorized,
                    "impossible": impossible,
                    "status": primary.value,
                },
            )
        return {
            "ok": not missing,
            "schema_version": "persistmind.capability_negotiation.v1",
            "permitted": sorted(permitted),
            "missing": missing,
            "primary_status": primary.value,
            "secondary_reasons": [item.value for item in secondary],
        }

    def _ensure_task_envelope(
        self, session: Mapping[str, Any], *, task: str, actor: str
    ) -> dict[str, Any]:
        task_session_id = str(session["task_session_id"])
        current = self.task_envelope(task_session_id)
        if current is not None:
            return current
        source_rows = list(self.source.generations(limit=1))
        source_generation = dict(source_rows[0]) if source_rows else {}
        envelope = TaskEnvelope.from_mapping(
            {
                "schema_version": "TaskEnvelope.v1",
                "goals": [{"predicate": task, "priority": 1}],
                "constraints": {"hard": [], "soft": [], "non_goals": []},
                "source_state": {
                    "workspace_id": self.workspace_id,
                    "repository_id": self.repo_id,
                    "generation_id": source_generation.get("generation_id"),
                    "generation_hash": source_generation.get("content_hash"),
                },
                "evidence": [],
                "actions": [],
                "budgets": {
                    "time_seconds": None,
                    "tokens": None,
                    "money": None,
                    "storage_bytes": None,
                    "network_calls": 0,
                    "retries": 0,
                },
                "risk": {"static_floor": "low", "upper_bound": None},
                "horizon": {"stop_conditions": ["goal_verified", "unsafe", "not_authorized"]},
                "verifier": {"predicates": [], "outcome_observation": "required"},
                "actor": actor,
                "rationale": "task intake normalization",
            }
        )
        with self.store._write_lock, self.store.connection:
            self.store.connection.execute(
                "INSERT OR IGNORE INTO task_envelopes VALUES(?,?,?,?,?,NULL,?)",
                (
                    task_session_id,
                    1,
                    canonical_json(envelope.document()),
                    envelope.envelope_hash,
                    actor,
                    utc_now(),
                ),
            )
            self.store.connection.execute(
                "UPDATE domain_metadata SET revision=revision+1 WHERE singleton=1"
            )
        return dict(self.task_envelope(task_session_id) or {})

    def _advance_task_state(
        self,
        task_session_id: str,
        target_state: str,
        *,
        reason: str,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        current = self._session_or_raise(task_session_id)
        state = str(current["state"]).upper()
        target = target_state.strip().upper()
        if state not in TASK_STATES or target not in TASK_STATES:
            raise ValueError(f"unknown task state transition: {state} -> {target}")
        transitions: list[dict[str, Any]] = []
        while TASK_STATES.index(state) < TASK_STATES.index(target):
            next_state = TASK_STATES[TASK_STATES.index(state) + 1]
            transitions.append(
                self.task_transition(
                    task_session_id,
                    next_state,
                    actor="persistmind",
                    reason=reason,
                    pack_id=pack_id,
                )
            )
            state = next_state
        return {
            "task_session_id": task_session_id,
            "current_state": state,
            "transition_ids": [item["transition_id"] for item in transitions],
        }

    def _plan_checkpoint_readiness(self, plan: Mapping[str, Any]) -> dict[str, Any]:
        required_steps = [
            str(step.get("id") or step.get("title"))
            for step in dict(plan.get("plan") or {}).get("steps", [])
            if isinstance(step, Mapping) and (step.get("id") or step.get("title"))
        ]
        latest: dict[str, str] = {}
        for checkpoint in self.store.checkpoints(str(plan["plan_id"])):
            step_id = checkpoint.get("step_id")
            if step_id:
                latest[str(step_id)] = str(checkpoint.get("status") or "")
        missing = [step_id for step_id in required_steps if step_id not in latest]
        failing = [
            step_id for step_id in required_steps if step_id in latest and latest[step_id] != "pass"
        ]
        return {
            "ready": bool(required_steps) and not missing and not failing,
            "required_steps": required_steps,
            "missing_steps": missing,
            "failing_steps": failing,
        }

    def workflow_start(
        self,
        task: str,
        *,
        mode: str = "write",
        paths: list[str] | None = None,
        capabilities: list[str] | None = None,
        intent_id: str | None = None,
        goal_id: str | None = None,
    ) -> dict[str, Any]:
        """Start a workflow entirely on the canonical PersistMind next-generation storage ports."""

        from persistmind.storage.knowledge_service import KnowledgeService
        from persistmind.storage.pack_service import PackService
        from persistmind.storage.source_service import SourceService
        from persistmind.workflow import WorkflowRouter

        seed_paths = sorted({path.replace("\\", "/") for path in paths or [] if path})
        task_result = self.task_start(task)
        task_session_id = str(task_result["task_session_id"])
        try:
            with PackService(
                self.repo_root,
                allow_development_driver=self._allow_development_driver,
            ) as packs:
                pack = packs.get_context_pack(
                    task,
                    seed_paths=seed_paths,
                    task_session_id=task_session_id,
                )
        except KeyError as exc:
            if "source_segment" not in str(exc):
                raise
            pack = {"ok": False, "status": "source_not_ready"}
        if pack.get("status") == "source_not_ready":
            return {
                "ok": False,
                "status": "index_required",
                "schema_version": "persistmind.workflow_start.v1",
                "task_session_id": task_session_id,
                "preflight_ready": False,
                "remediation": "Run persistmind index explicitly, then retry workflow start.",
                "nextgen_v1": True,
            }
        with SourceService(
            self.repo_root,
            allow_development_driver=self._allow_development_driver,
            read_only=True,
        ) as source:
            impact = source.impact(seed_paths)
        with KnowledgeService(
            self.repo_root,
            allow_development_driver=self._allow_development_driver,
            read_only=True,
        ) as knowledge:
            recall = knowledge.memory_recall(task, paths=seed_paths, limit=20)
        continuation = self.continuation_resume(task)
        recommendation = WorkflowRouter().recommend(
            task=task,
            mode=mode,
            paths=seed_paths,
            capabilities=capabilities or [],
            intent_id=intent_id,
            goal_id=goal_id,
            impact_report=impact,
            task_session_id=task_session_id,
            pack_id=str(pack["pack_id"]),
        )
        current = self.store.workflow_snapshot(task_session_id) or {}
        snapshot_payload = {
            key: value
            for key, value in dict(current).items()
            if key
            not in {
                "task_session_id",
                "pack_id",
                "plan_id",
                "revision",
                "updated_at",
            }
        }
        snapshot_payload.update(
            {
                "workflow_recommendation": recommendation,
                "workflow_schema_version": "persistmind.workflow_start.v1",
            }
        )
        self.store.save_workflow_snapshot(
            task_session_id,
            payload=snapshot_payload,
            pack_id=str(pack["pack_id"]),
            plan_id=str(current.get("plan_id") or "") or None,
            expected_revision=int(current.get("revision") or 0),
        )
        gates = self._workflow_gate_status(task_session_id, recommendation)
        pending = [
            gate_id
            for gate_id in _workflow_gate_ids(recommendation)
            if gates[gate_id]["status"] != "pass"
        ]
        next_action = _workflow_next_action(recommendation, gates, pending)
        return {
            "ok": True,
            "schema_version": "persistmind.workflow_start.v1",
            "task": task,
            "mode": mode,
            "task_session_id": task_session_id,
            "pack_id": pack["pack_id"],
            "agent_session_id": task_result.get("agent_session_id"),
            "task_types": recommendation["task_types"],
            "recommendation": recommendation,
            "next_action": next_action,
            "remediation": [],
            "continuation_matches": continuation.get("matches", []),
            "memory": recall.get("records", []),
            "memory_recall_count": len(recall.get("records", [])),
            "impact_report_id": impact.get("impact_report_id"),
            "nextgen_v1": True,
            "lifecycle_event_id": pack.get("lifecycle_event_id")
            or task_result.get("lifecycle_event_id"),
            "lifecycle_sequence": pack.get("lifecycle_sequence")
            or task_result.get("lifecycle_sequence"),
        }

    def workflow_brief(
        self,
        task: str | None,
        *,
        paths: list[str] | None = None,
        mode: str = "auto",
        task_session_id: str | None = None,
    ) -> dict[str, Any]:
        """Return authority workflow guidance without constructing or refreshing an index."""

        from persistmind.workflow import WorkflowRouter

        session = self.store.session(task_session_id) if task_session_id else None
        if task_session_id and session is None:
            raise ValueError("workflow brief task session was not found")
        payload = _payload(session or {})
        raw_metadata = payload.get("metadata")
        metadata = raw_metadata if isinstance(raw_metadata, Mapping) else {}
        resolved_task = str(
            (task or "").strip() or metadata.get("objective") or metadata.get("task") or ""
        ).strip()
        if not resolved_task:
            raise ValueError("workflow brief requires --task or a valid --task-session-id")
        normalized_paths = sorted({path.replace("\\", "/") for path in paths or [] if path})
        snapshot = self.store.workflow_snapshot(task_session_id) if task_session_id else None
        pack_id = (
            str((snapshot or {}).get("pack_id") or (session or {}).get("pack_id") or "") or None
        )
        recommendation = WorkflowRouter().recommend(
            task=resolved_task,
            mode=mode,
            paths=normalized_paths,
            capabilities=[],
            impact_report={"input_paths": normalized_paths, "risk": {"score": 0.0}},
            task_session_id=task_session_id,
            pack_id=pack_id,
        )
        gates = (
            self._workflow_gate_status(task_session_id, recommendation) if task_session_id else {}
        )
        pending = [
            gate_id
            for gate_id in _workflow_gate_ids(recommendation)
            if gates.get(gate_id, {}).get("status") != "pass"
        ]
        from persistmind.storage.knowledge_service import KnowledgeService

        with KnowledgeService(
            self.repo_root,
            allow_development_driver=self._allow_development_driver,
            read_only=True,
        ) as knowledge:
            recall = knowledge.memory_recall(resolved_task, paths=normalized_paths, limit=20)
        return {
            "ok": True,
            "schema_version": "persistmind.pack_governance.v1",
            "task": resolved_task,
            "task_session_id": task_session_id,
            "pack_id": pack_id,
            "mode": recommendation.get("mode"),
            "task_types": recommendation.get("task_types", []),
            "recommendation": recommendation,
            "gates": gates,
            "pending_gates": pending,
            "next_action": _workflow_next_action(recommendation, gates, pending),
            "memory": recall.get("records", []),
            "memory_recall_count": len(recall.get("records", [])),
            "nextgen_v1": True,
        }

    def workflow_next(self, task_session_id: str) -> dict[str, Any]:
        session = self.store.session(task_session_id)
        snapshot = self.store.workflow_snapshot(task_session_id)
        if session is None:
            return {
                "ok": False,
                "schema_version": "persistmind.workflow_next.v1",
                "task_session_id": task_session_id,
                "blocked": True,
                "reason": "task session not found",
                "nextgen_v1": True,
            }
        snapshot = snapshot or {}
        recommendation = snapshot.get("workflow_recommendation")
        reclassified = False
        if not isinstance(recommendation, dict):
            recommendation, snapshot = self._recover_workflow_recommendation(
                task_session_id, session=session, snapshot=snapshot
            )
            reclassified = True
        gates = self._workflow_gate_status(task_session_id, recommendation)
        pending = [
            gate_id
            for gate_id in _workflow_gate_ids(recommendation)
            if gates[gate_id]["status"] != "pass"
        ]
        next_action = _workflow_next_action(recommendation, gates, pending)
        closure = self._terminal_closure(task_session_id)
        return {
            "ok": True,
            "schema_version": "persistmind.workflow_next.v1",
            "task_session_id": task_session_id,
            "pack_id": snapshot.get("pack_id"),
            "plan_id": snapshot.get("plan_id"),
            "reclassified": reclassified,
            "gates": gates,
            "pending_gates": pending,
            "next_action": next_action,
            "complete": not pending and next_action is None,
            "blocked": _workflow_has_blocking_gate(gates),
            "terminal_closure": closure,
            "terminal_status": closure.get("terminal_status"),
            "closure_receipt_id": closure.get("closure_receipt_id"),
            "durable_fact_accounting": self._durable_fact_accounting(task_session_id),
            "nextgen_v1": True,
        }

    def _recover_workflow_recommendation(
        self,
        task_session_id: str,
        *,
        session: Mapping[str, Any],
        snapshot: Mapping[str, Any],
    ) -> tuple[dict[str, Any], Mapping[str, Any]]:
        """Create the missing recommendation for the documented manual lifecycle."""

        from persistmind.workflow import WorkflowRouter, infer_mode

        payload = _payload(session)
        raw_metadata = payload.get("metadata")
        metadata = raw_metadata if isinstance(raw_metadata, Mapping) else {}
        task = str(metadata.get("objective") or metadata.get("task") or "").strip()
        if not task:
            raise ValueError("task session lacks recoverable task text")
        plan = self.store.latest_plan(task_session_id)
        plan_definition = dict(plan.get("plan") or {}) if plan else {}
        paths = intended_files(plan_definition) if plan_definition else []
        capabilities = sorted(
            {
                str(capability)
                for step in plan_definition.get("steps", [])
                if isinstance(step, Mapping)
                for capability in step.get("capabilities", [])
                if str(capability).strip()
            }
        )
        impact = dict(plan.get("validation", {}).get("impact_report") or {}) if plan else None
        pack_id = str(session.get("pack_id") or snapshot.get("pack_id") or "") or None
        recommendation = WorkflowRouter().recommend(
            task=task,
            mode=infer_mode(task, "auto"),
            paths=paths,
            capabilities=capabilities,
            impact_report=impact,
            task_session_id=task_session_id,
            pack_id=pack_id,
        )
        snapshot_payload = {
            key: value
            for key, value in dict(snapshot).items()
            if key not in {"task_session_id", "pack_id", "plan_id", "revision", "updated_at"}
        }
        snapshot_payload.update(
            {
                "workflow_recommendation": recommendation,
                "workflow_schema_version": "persistmind.workflow_recovered.v1",
                "workflow_recovered_from_manual_lifecycle": True,
            }
        )
        saved = self.store.save_workflow_snapshot(
            task_session_id,
            payload=snapshot_payload,
            pack_id=pack_id,
            plan_id=str(plan.get("plan_id") or "") or None if plan else None,
            expected_revision=int(snapshot.get("revision") or 0),
        )
        return recommendation, saved

    def _workflow_gate_status(
        self, task_session_id: str, recommendation: Mapping[str, Any]
    ) -> dict[str, dict[str, Any]]:
        session = self._session_or_raise(task_session_id)
        plan = self.store.latest_plan(task_session_id)
        checkpoints = self.store.checkpoints(str(plan["plan_id"])) if plan else []
        verifications = self.store.verifications(task_session_id)
        snapshot = self.store.workflow_snapshot(task_session_id) or {}
        revision = list(self.store.plan_revisions(str(plan["plan_id"])))[-1] if plan else None
        diff_fingerprint = current_diff_fingerprint(self.repo_root)
        results: dict[str, dict[str, Any]] = {}
        for gate_id in _workflow_gate_ids(recommendation):
            if gate_id not in GATE_KINDS:
                raise ValueError(f"unknown workflow gate: {gate_id}")
            status = "pending"
            source = "task_state"
            evidence: list[str] = []
            rejected_evidence: list[dict[str, Any]] = []
            if gate_id == "preflight_ready":
                status = "pass" if session.get("pack_id") else "pending"
                source = "context_pack"
                evidence = [str(session["pack_id"])] if session.get("pack_id") else []
            elif gate_id == "plan_active":
                status = "pass" if plan else "pending"
                source = "task_plan"
                evidence = [str(plan["plan_id"])] if plan else []
            elif gate_id == "checkpoints_present":
                required = {
                    str(item.get("id") or item.get("title"))
                    for item in (plan or {}).get("plan", {}).get("steps", [])
                    if isinstance(item, Mapping)
                }
                passed = {
                    str(item.get("step_id")): str(item.get("checkpoint_id"))
                    for item in checkpoints
                    if item.get("status") == "pass"
                    and revision
                    and str(item.get("created_at")) >= str(revision.get("created_at"))
                }
                missing = sorted(required - set(passed))
                status = "pass" if required and not missing else "pending"
                source = "task_plan_checkpoints"
                evidence = sorted(passed.values()) if not missing else []
            elif gate_id in {"check_diff_clean", "dirty_set_in_scope"}:
                status, evidence, rejected_evidence = _typed_verification_gate_status(
                    verifications,
                    expected_type="check_diff",
                    task_session_id=task_session_id,
                    session=session,
                    plan=plan,
                    revision=revision,
                    diff_fingerprint=diff_fingerprint,
                )
                source = "task_verifications"
            elif gate_id == "tests_pass":
                status, evidence, rejected_evidence = _typed_verification_gate_status(
                    verifications,
                    expected_type="tests",
                    task_session_id=task_session_id,
                    session=session,
                    plan=plan,
                    revision=revision,
                    diff_fingerprint=diff_fingerprint,
                )
                source = "task_verifications"
            elif gate_id == "security_scan_pass":
                status, evidence, rejected_evidence = _typed_verification_gate_status(
                    verifications,
                    expected_type="security_scan",
                    task_session_id=task_session_id,
                    session=session,
                    plan=plan,
                    revision=revision,
                    diff_fingerprint=diff_fingerprint,
                )
                source = "task_verifications"
            elif gate_id == "release_validated":
                status, evidence, rejected_evidence = _typed_verification_gate_status(
                    verifications,
                    expected_type="release_validation",
                    task_session_id=task_session_id,
                    session=session,
                    plan=plan,
                    revision=revision,
                    diff_fingerprint=diff_fingerprint,
                )
                source = "task_verifications"
            elif gate_id == "outcome_recorded":
                outcome_evidence = snapshot.get("outcome_id") or snapshot.get(
                    "terminal_event_id"
                )
                pack_matches = str(snapshot.get("pack_id") or "") == str(
                    session.get("pack_id") or ""
                )
                plan_matches = plan is not None and str(snapshot.get("plan_id") or "") == str(
                    plan.get("plan_id") or ""
                )
                terminal_status = snapshot.get("terminal_status") or session.get(
                    "terminal_status"
                )
                terminal_verified = any(
                    resolution_satisfies_gate(value)
                    for value in (
                        snapshot.get("terminal_status"),
                        session.get("terminal_status"),
                    )
                )
                if outcome_evidence and pack_matches and plan_matches and terminal_verified:
                    status = "pass"
                elif outcome_evidence or terminal_status or str(session.get("state")) == "OUTCOME":
                    status = "unverified"
                else:
                    status = "pending"
                source = "workflow_snapshot"
                evidence = [str(outcome_evidence)] if outcome_evidence else []
                if session.get("terminal_resolution_id"):
                    evidence.append(str(session["terminal_resolution_id"]))
            results[gate_id] = {
                "status": status,
                "raw_status": status,
                "source": source,
                "qualifying_evidence_ids": evidence,
            }
            if rejected_evidence:
                results[gate_id]["rejected_evidence"] = rejected_evidence
        return results

    def task_learning_report(self, task_session_id: str) -> dict[str, Any]:
        task = self._session_or_raise(task_session_id)
        closure = self._terminal_closure(task_session_id)
        active = dict(self.learning.active_manifest())
        versions = []
        for skill_id, version_id in sorted(active.items()):
            version = self.learning.version(str(version_id))
            if version is not None:
                versions.append(dict(version))
        return {
            "ok": True,
            "schema_version": "persistmind.task_learning_report.v1",
            "task_session_id": task_session_id,
            "task_state": task["state"],
            "terminal_closure": closure,
            "active_manifest": active,
            "active_versions": versions,
            "nextgen_v1": True,
        }

    def _require_current_check_diff_for_outcome(self, task_session_id: str) -> None:
        gates = self._workflow_gate_status(
            task_session_id,
            {"gates": [{"gate_id": "check_diff_clean"}]},
        )
        gate = gates.get("check_diff_clean", {})
        if gate.get("status") == "pass":
            return
        error = ValueError(
            "task cannot enter OUTCOME until check_diff_clean passes; "
            "run persistmind --repo . check-diff and resolve its violations first"
        )
        error.status = "validation_failed"  # type: ignore[attr-defined]
        error.remediation = (  # type: ignore[attr-defined]
            "Run persistmind --repo . check-diff --pack-id <pack_id> while the task is in "
            "PREFLIGHT, resolve any violations, then transition to OUTCOME."
        )
        raise error

    def state_create(
        self, kind: str, payload: Mapping[str, Any], *, record_id: str | None = None
    ) -> dict[str, Any]:
        document = dict(payload)
        identifier = record_id or f"{kind}_" + stable_id(kind, canonical_json(document))[:32]
        document.update({"record_id": identifier, "kind": kind, "scope": self.workspace_id})
        self.store.put(document, idempotency_key=f"{kind}:{identifier}")
        return {"ok": True, kind: document, "record_id": identifier, "nextgen_v1": True}

    def state_show(self, record_id: str) -> dict[str, Any]:
        record = self.store.get(record_id)
        return (
            {"ok": True, "record": dict(record), "nextgen_v1": True}
            if record
            else {"ok": False, "record_id": record_id, "error": "record not found"}
        )

    def state_list(
        self, kind: str, *, status: str | None = None, limit: int = 50
    ) -> dict[str, Any]:
        records = [
            dict(item)
            for item in self.store.search("", limit=max(1, min(limit * 4, 1000)))
            if str(item.get("kind")) == kind
            and (status is None or str(item.get("status")) == status)
        ]
        return {
            "ok": True,
            "kind": kind,
            "records": records[:limit],
            "count": min(len(records), limit),
            "nextgen_v1": True,
        }

    def state_update(
        self,
        record_id: str,
        patch: Mapping[str, Any],
        *,
        expected_revision: int | None = None,
    ) -> dict[str, Any]:
        current = self.store.get(record_id)
        if current is None:
            return {"ok": False, "record_id": record_id, "error": "record not found"}
        document = {key: value for key, value in dict(current).items() if not key.startswith("_")}
        document.update(dict(patch))
        revision = int(current.get("_revision") or 0)
        if expected_revision is not None and expected_revision != revision:
            raise TaskConflict(
                f"task record revision conflict: expected {expected_revision}, current {revision}"
            )
        if not self.store.compare_and_swap(record_id, revision, document):
            raise TaskConflict("task record changed during compare-and-swap")
        return {"ok": True, "record": dict(self.store.get(record_id) or {}), "nextgen_v1": True}

    def intent_start(self, problem: str, *, llm_propose: bool = False) -> dict[str, Any]:
        if not problem.strip():
            raise ValueError("intent problem must be non-empty")
        return self.state_create(
            "intent",
            {
                "problem": problem.strip(),
                "status": "active",
                "evidence": [],
                "selected_goal_id": None,
                "llm_propose_requested": bool(llm_propose),
            },
        )

    def goal_evaluate(
        self, intent_id: str, *, candidate_goal_id: str | None = None, mode: str | None = None
    ) -> dict[str, Any]:
        intent = self.store.get(intent_id)
        if intent is None or intent.get("kind") != "intent":
            raise KeyError(f"intent not found: {intent_id}")
        result = self.state_create(
            "goal",
            {
                "intent_id": intent_id,
                "objective": intent.get("problem"),
                "status": "accepted",
                "mode": mode or "warn",
                "candidate_goal_id": candidate_goal_id,
            },
        )
        self.state_update(intent_id, {"selected_goal_id": result["record_id"]})
        return result

    def reasoning_record(
        self,
        task: str,
        *,
        checkpoint: str,
        paths: list[str],
        task_session_id: str | None = None,
        surprise: float | None = None,
    ) -> dict[str, Any]:
        return self.state_create(
            "reasoning",
            {
                "task": task,
                "checkpoint": checkpoint,
                "paths": sorted(set(paths)),
                "task_session_id": task_session_id,
                "surprise": surprise,
                "status": "recorded",
            },
        )

    def experience_record(
        self,
        task: str,
        *,
        paths: list[str],
        surprise: float,
        trigger: str,
        evidence: list[dict[str, Any]],
    ) -> dict[str, Any]:
        return self.state_create(
            "experience",
            {
                "task": task,
                "paths": sorted(set(paths)),
                "surprise": surprise,
                "trigger": trigger,
                "evidence": evidence,
                "status": "active",
            },
        )

    def working_memory_promote(
        self, note_id: str, *, actor: str, validator: str | None = None
    ) -> dict[str, Any]:
        note = self.store.get(note_id)
        if note is None or note.get("kind") != "working_memory":
            raise KeyError(f"working-memory note not found: {note_id}")
        note_kind = str(note.get("note_kind") or "observation")
        proposed_record_id = "memory_" + stable_id("working-memory", note_id)[:32]
        proposal = self.state_create(
            "knowledge_promotion_proposal",
            {
                "note_id": note_id,
                "proposed_record_id": proposed_record_id,
                "record_type": "fact" if note_kind == "verified_fact" else "episode",
                "assertion": note.get("text"),
                "salience_support_score": note.get("salience", 0.5),
                "actor": actor,
                "validator": validator,
                "status": "knowledge_pending",
            },
        )
        self.state_update(
            note_id,
            {"status": "promotion_pending", "promotion_proposal_id": proposal["record_id"]},
        )
        from persistmind.storage.knowledge_service import KnowledgeService

        try:
            evidence_refs = list(note.get("evidence_refs") or [])
            metadata: dict[str, Any] = {
                "working_memory_note_id": note_id,
                "task_session_id": note.get("task_session_id"),
                "salience_support_score": note.get("salience", 0.5),
            }
            assertion = str(note.get("text") or "")
            evidence: list[dict[str, Any]] = []
            source_kind = "working_memory"
            expires_at = note.get("expires_at")
            if note_kind == "verified_fact":
                normalized = normalize_verified_fact(assertion, evidence_refs)
                assertion = str(normalized["assertion"])
                metadata.update(
                    {
                        "external_evidence": normalized["evidence"],
                        "identifiers": normalized["identifiers"],
                        "redaction": normalized["redaction"],
                        "live_state": True,
                    }
                )
                evidence = knowledge_evidence(normalized["evidence"])
                expires_at = normalized["expires_at"] or expires_at
                source_kind = "external_tool_verified"
            with KnowledgeService(
                self.repo_root,
                allow_development_driver=self._allow_development_driver,
                runtime=self.runtime,
            ) as knowledge:
                created = knowledge.memory_create_typed(
                    {
                        "record_id": proposed_record_id,
                        "type": "fact" if note_kind == "verified_fact" else "episode",
                        "assertion": assertion,
                        "source_kind": source_kind,
                        "status": "active",
                        "trust": "active",
                        "expires_at": expires_at,
                        "metadata": metadata,
                        "evidence": evidence,
                        "actor": actor,
                        "provenance": {
                            "generator": "working-memory-promotion",
                            "validator": validator or "human:working-memory",
                            "source_connector": (
                                "external_tool" if note_kind == "verified_fact" else None
                            ),
                            "approved_external": note_kind == "verified_fact",
                        },
                    }
                )
            record = created["record"]
        except (KeyError, RuntimeError, TypeError, ValueError) as exc:
            rejected = self.state_update(
                proposal["record_id"],
                {"status": "rejected", "rejection_reason": str(exc)},
            )
            self.state_update(
                note_id,
                {
                    "status": "promotion_rejected",
                    "promotion_proposal_id": proposal["record_id"],
                },
            )
            return {
                "ok": False,
                "status": "rejected",
                "proposal": rejected["record"],
                "note_id": note_id,
                "error": str(exc),
                "nextgen_v1": True,
            }
        applied = self.state_update(
            proposal["record_id"],
            {
                "status": "applied",
                "knowledge_record_id": record["record_id"],
                "applied_at": utc_now(),
            },
        )
        self.state_update(
            note_id,
            {
                "status": "promoted",
                "promotion_proposal_id": proposal["record_id"],
                "knowledge_record_id": record["record_id"],
            },
        )
        return {
            "ok": True,
            "status": "applied",
            "proposal": applied["record"],
            "note_id": note_id,
            "knowledge_record_id": record["record_id"],
            "record": record,
            "nextgen_v1": True,
        }

    def working_memory_decline(
        self, note_id: str, *, actor: str = "local-user", reason: str
    ) -> dict[str, Any]:
        note = self.store.get(note_id)
        if note is None or note.get("kind") != "working_memory":
            raise KeyError(f"working-memory note not found: {note_id}")
        if not reason.strip():
            raise ValueError("working-memory decline requires a reason")
        updated = self.state_update(
            note_id,
            {
                "status": "not_promotable",
                "declined_by": actor,
                "declined_at": utc_now(),
                "decline_reason": reason.strip(),
            },
        )
        return {
            "ok": True,
            "status": "not_promotable",
            "note_id": note_id,
            "record": updated["record"],
            "nextgen_v1": True,
        }

    def remediation_attempt_record(
        self,
        task_session_id: str,
        *,
        gate_id: str,
        approach: str,
        outcome: str,
        command_or_tool: str | None = None,
        error: str | None = None,
        waited_seconds: int | None = None,
        backoff_strategy: str | None = None,
        transient_recovery: str | None = None,
        actor: str = "local-user",
    ) -> dict[str, Any]:
        self._session_or_raise(task_session_id)
        gate_id = gate_id.strip()
        approach = approach.strip()
        outcome = outcome.strip()
        command_or_tool = (command_or_tool or "").strip() or None
        error = (error or "").strip() or None
        backoff_strategy = (backoff_strategy or "").strip() or None
        transient_recovery = (transient_recovery or "").strip() or None
        waited = max(0, int(waited_seconds or 0))
        if not gate_id or not approach or not outcome:
            raise ValueError("remediation attempt requires gate, approach, and outcome")
        retry_qualifier = ""
        if waited or backoff_strategy or transient_recovery:
            retry_qualifier = stable_id(
                "remediation-retry-qualifier",
                waited,
                backoff_strategy or "",
                transient_recovery or "",
                outcome.casefold(),
                error or "",
            )
        approach_hash = stable_id(
            "remediation-attempt",
            task_session_id,
            gate_id,
            approach.casefold(),
            str(command_or_tool or "").casefold(),
            retry_qualifier,
        )
        metadata = {
            "gate_id": gate_id,
            "approach": approach,
            "outcome": outcome,
            "command_or_tool": command_or_tool,
            "error": error,
            "waited_seconds": waited,
            "backoff_strategy": backoff_strategy,
            "transient_recovery": transient_recovery,
            "retry_qualifier": retry_qualifier or None,
            "recorded_at": utc_now(),
            "approach_hash": approach_hash,
            "actor": actor,
        }
        note = self.working_memory_capture(
            f"Remediation attempt for {gate_id}: {approach} -> {outcome}",
            task_session_id=task_session_id,
            salience=0.65,
            kind="remediation_attempt",
            evidence_refs=[metadata],
        )
        return {
            "ok": True,
            "status": "recorded",
            "attempt_id": note["record_id"],
            "attempt": metadata,
            "record": note.get("working_memory"),
            "nextgen_v1": True,
        }

    def task_close(
        self,
        task_session_id: str,
        *,
        result: str,
        reason: str,
        blocking_gate_id: str | None = None,
        actor: str = "local-user",
    ) -> dict[str, Any]:
        session = self._session_or_raise(task_session_id)
        normalized = result.strip().lower()
        if normalized == "pass":
            raise ValueError("task close cannot record pass; use the outcome path")
        if normalized not in TASK_CLOSE_RESULTS:
            raise ValueError("task close result must be fail, partial, cancelled, or blocked")
        if not reason.strip():
            raise ValueError("task close requires a reason")
        existing = self._terminal_closure(task_session_id)
        if existing.get("closed"):
            return {
                "ok": False,
                "status": "already_closed",
                "task_session_id": task_session_id,
                "terminal_closure": existing,
                "nextgen_v1": True,
            }
        durable = self._durable_fact_accounting(task_session_id)
        if normalized != "cancelled" and durable["unresolved"]:
            return {
                "ok": False,
                "status": "durable_fact_unresolved",
                "task_session_id": task_session_id,
                "durable_fact_accounting": durable,
                "remediation": (
                    "Promote or decline verified/high-salience working-memory facts before "
                    "closing this task."
                ),
                "nextgen_v1": True,
            }
        gate_report: dict[str, Any] = {"required": False}
        accepted_attempts: list[dict[str, Any]] = []
        rejected_attempts: list[dict[str, Any]] = []
        if normalized in {"blocked", "fail"}:
            if not blocking_gate_id:
                raise ValueError(f"task close result {normalized} requires --blocking-gate")
            gate_report = self._validate_close_gate(task_session_id, blocking_gate_id)
            if not gate_report["ok"]:
                return {
                    "ok": False,
                    "status": "blocking_gate_invalid",
                    "task_session_id": task_session_id,
                    "gate": gate_report,
                    "nextgen_v1": True,
                }
            attempts = self._remediation_attempt_report(task_session_id, blocking_gate_id)
            accepted_attempts = attempts["accepted"]
            rejected_attempts = attempts["rejected"]
            required = 2 if normalized == "blocked" else 1
            if len(accepted_attempts) < required:
                return {
                    "ok": False,
                    "status": "remediation_attempts_required",
                    "task_session_id": task_session_id,
                    "result": normalized,
                    "blocking_gate_id": blocking_gate_id,
                    "required_attempts": required,
                    "accepted_attempts": accepted_attempts,
                    "rejected_attempts": rejected_attempts,
                    "nextgen_v1": True,
                }
        failure_id = "closure_" + stable_id(
            "task-close",
            task_session_id,
            normalized,
            reason.strip(),
            blocking_gate_id or "",
        )[:32]
        try:
            event = self.lifecycle.fail_task(
                task_session_id,
                failure_id=failure_id,
                error_code=f"task_{normalized}",
                remediation_code=blocking_gate_id or "user_closed",
                result=normalized,
                reason=reason.strip(),
                blocking_gate_id=blocking_gate_id,
                attempt_ids=[str(item["record_id"]) for item in accepted_attempts],
                attempts=accepted_attempts,
            )
        except RuntimeError as exc:
            if "workflow is terminal" in str(exc):
                return {
                    "ok": False,
                    "status": "already_closed",
                    "task_session_id": task_session_id,
                    "error": str(exc),
                    "terminal_closure": self._terminal_closure(task_session_id),
                    "nextgen_v1": True,
                }
            raise
        closure = self._terminal_closure(task_session_id)
        return {
            "ok": True,
            "status": "closed",
            "schema_version": "persistmind.task_close.v1",
            "task_session_id": task_session_id,
            "state": session["state"],
            "result": normalized,
            "reason": reason.strip(),
            "blocking_gate_id": blocking_gate_id,
            "event": event,
            "closure_receipt_id": event["event_id"],
            "terminal_closure": closure,
            "gate": gate_report,
            "accepted_attempts": accepted_attempts,
            "rejected_attempts": rejected_attempts,
            "durable_fact_accounting": durable,
            "nextgen_v1": True,
        }

    def agent_preflight(self, task: str, **request: Any) -> dict[str, Any]:
        return self.codex_preflight(task, **request)

    def agent_route(
        self,
        task_session_id: str,
        *,
        candidates: Sequence[Mapping[str, Any]] = (),
        required_capabilities: Sequence[str] = (),
        risk_class: str = "low",
        risk_score: float | None = None,
        capabilities: Sequence[str] | None = None,
        remote_review_enabled: bool = False,
    ) -> dict[str, Any]:
        if self.store.session(task_session_id) is None:
            task_session_id = str(self.task_start(task_session_id)["task_session_id"])
        required = set(required_capabilities or capabilities or ())
        if risk_score is not None:
            risk_class = "high" if risk_score >= 0.75 else "medium" if risk_score >= 0.4 else "low"
        candidate_values = list(candidates)
        if not candidate_values and remote_review_enabled:
            candidate_values = [
                {
                    "adapter_id": "remote-review",
                    "capabilities": sorted(required),
                    "maximum_risk": "high",
                    "priority": 100,
                }
            ]
        eligible = []
        for candidate in candidate_values:
            candidate_capabilities = set(str(item) for item in candidate.get("capabilities", []))
            maximum_risk = str(candidate.get("maximum_risk") or "low")
            if required <= candidate_capabilities and _task_risk_index(
                maximum_risk
            ) >= _task_risk_index(risk_class):
                eligible.append(dict(candidate))
        eligible.sort(
            key=lambda item: (
                int(item.get("priority") or 1000),
                str(item.get("adapter_id") or item.get("id") or ""),
            )
        )
        selected = eligible[0] if eligible else None
        record = self.state_create(
            "agent_route",
            {
                "task_session_id": task_session_id,
                "required_capabilities": sorted(required),
                "risk_class": risk_class,
                "eligible": eligible,
                "selected": selected,
                "status": "selected" if selected else "external_dependency",
            },
        )
        return {
            "ok": selected is not None,
            "status": "selected" if selected else "external_dependency",
            "schema_version": "persistmind.agent_route.v1",
            "route": record,
            "selected": selected,
        }

    def clarify_open(
        self,
        question: str,
        *,
        task_session_id: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        if not question.strip():
            raise ValueError("clarification question must be non-empty")
        if task_session_id:
            self._session_or_raise(task_session_id)
        return self.state_create(
            "clarification",
            {
                "question": question.strip(),
                "task_session_id": task_session_id,
                "pack_id": pack_id,
                "status": "open",
                "opened_at": utc_now(),
            },
        )

    def clarify_answer(self, request_id: str, answer: str) -> dict[str, Any]:
        if not answer.strip():
            raise ValueError("clarification answer must be non-empty")
        request = self.store.get(request_id)
        if request is None or request.get("kind") != "clarification":
            raise KeyError(f"clarification not found: {request_id}")
        if request.get("status") != "open":
            raise ValueError("only an open clarification can be answered")
        return self.state_update(
            request_id,
            {"answer": answer.strip(), "status": "answered", "answered_at": utc_now()},
        )

    def clarify_list(
        self,
        task_session_id: str | None = None,
        status: str | None = "open",
        limit: int = 50,
    ) -> dict[str, Any]:
        result = self.state_list("clarification", status=status, limit=limit)
        if task_session_id:
            result["records"] = [
                item for item in result["records"] if item.get("task_session_id") == task_session_id
            ]
            result["count"] = len(result["records"])
        return result

    def clarify_withdraw(self, request_id: str, reason: str | None = None) -> dict[str, Any]:
        request = self.store.get(request_id)
        if request is None or request.get("kind") != "clarification":
            raise KeyError(f"clarification not found: {request_id}")
        if request.get("status") != "open":
            raise ValueError("only an open clarification can be withdrawn")
        return self.state_update(
            request_id,
            {"status": "withdrawn", "reason": reason, "withdrawn_at": utc_now()},
        )

    def intent_list(self, status: str | None = None, limit: int = 50) -> dict[str, Any]:
        return self.state_list("intent", status=status, limit=limit)

    def intent_show(self, intent_id: str) -> dict[str, Any]:
        return self.state_show(intent_id)

    def intent_refine(
        self,
        intent_id: str,
        problem: str | None = None,
        *,
        evidence: Any = None,
        select_goal: str | None = None,
    ) -> dict[str, Any]:
        current = self.store.get(intent_id)
        if current is None or current.get("kind") != "intent":
            raise KeyError(f"intent not found: {intent_id}")
        problem = problem or str(current.get("problem") or "")
        if not problem.strip():
            raise ValueError("refined intent must be non-empty")
        return self.state_update(
            intent_id,
            {
                "problem": problem.strip(),
                "evidence": evidence,
                "selected_goal_id": select_goal or current.get("selected_goal_id"),
                "refined_at": utc_now(),
                "status": "active",
            },
        )

    def goal_list(self, status: str | None = None, limit: int = 50) -> dict[str, Any]:
        return self.state_list("goal", status=status, limit=limit)

    def goal_show(self, goal_id: str) -> dict[str, Any]:
        return self.state_show(goal_id)

    def goal_challenge(
        self,
        goal_id: str,
        *,
        rationale: str = "goal challenged",
        actor: str = "local-user",
    ) -> dict[str, Any]:
        return self.state_update(
            goal_id,
            {
                "status": "challenged",
                "challenge": {"rationale": rationale, "actor": actor, "created_at": utc_now()},
            },
        )

    def goal_reevaluate(
        self,
        goal_id: str,
        *,
        objective: str | None = None,
        mode: str | None = None,
        trigger: str | None = None,
    ) -> dict[str, Any]:
        patch: dict[str, Any] = {"status": "accepted", "reevaluated_at": utc_now()}
        if objective is not None:
            patch["objective"] = objective
        if mode is not None:
            patch["mode"] = mode
        if trigger is not None:
            patch["trigger"] = trigger
        return self.state_update(goal_id, patch)

    def goal_accept_alternative(
        self, goal_id: str, *, alternative: str, actor: str = "local-user"
    ) -> dict[str, Any]:
        return self.state_update(
            goal_id,
            {
                "objective": alternative,
                "status": "accepted",
                "alternative_decision": {"decision": "accepted", "actor": actor},
            },
        )

    def goal_reject_alternative(
        self, goal_id: str, *, alternative: str, reason: str
    ) -> dict[str, Any]:
        current = self.store.get(goal_id)
        if current is None or current.get("kind") != "goal":
            raise KeyError(f"goal not found: {goal_id}")
        rejected = list(current.get("rejected_alternatives") or [])
        rejected.append({"alternative": alternative, "reason": reason, "at": utc_now()})
        return self.state_update(goal_id, {"rejected_alternatives": rejected})

    def reasoning_checkpoint(
        self,
        task_session_id: str | None = None,
        *,
        proposition: str | None = None,
        evidence: Sequence[Mapping[str, Any]] = (),
        conditions: Sequence[str] = ("candidate",),
        task: str | None = None,
        checkpoint: str | None = None,
        paths: Sequence[str] = (),
        surprise: float | None = None,
    ) -> dict[str, Any]:
        proposition = proposition or checkpoint or task or "reasoning checkpoint"
        if task_session_id and self.store.session(task_session_id) is None:
            task_session_id = str(self.task_start(task or proposition)["task_session_id"])
        if not task_session_id:
            return self.reasoning_record(
                task or proposition,
                checkpoint=checkpoint or proposition,
                paths=list(paths),
                surprise=surprise,
            )
        uncertainty = self.uncertainty_record(
            task_session_id,
            phase="reasoning_checkpoint",
            conditions=conditions,
            metrics={"proposition": proposition, "evidence": list(evidence)},
        )
        return self.state_create(
            "reasoning_checkpoint",
            {
                "task_session_id": task_session_id,
                "proposition": proposition,
                "evidence": list(evidence),
                "uncertainty_snapshot_id": uncertainty["snapshot_id"],
                "status": uncertainty["primary_status"],
            },
        )

    def reasoning_route(
        self,
        task_session_id: str | None = None,
        *,
        routes: Sequence[Mapping[str, Any]] = (),
        task: str | None = None,
        paths: Sequence[str] = (),
    ) -> dict[str, Any]:
        if not task_session_id:
            task_session_id = str(self.task_start(task or "reasoning route")["task_session_id"])
        elif self.store.session(task_session_id) is None:
            task_session_id = str(self.task_start(task_session_id)["task_session_id"])
        normalized = [dict(item) for item in routes]
        if not normalized and paths:
            normalized = [{"route_id": path, "support_score": 0.0, "risk": 0.5} for path in paths]
        normalized.sort(
            key=lambda item: (
                -float(item.get("support_score") or 0.0),
                float(item.get("risk") or 1.0),
                str(item.get("route_id") or ""),
            )
        )
        selected = normalized[0] if normalized else None
        return self.state_create(
            "reasoning_route",
            {
                "task_session_id": task_session_id,
                "routes": normalized,
                "selected": selected,
                "status": "candidate" if selected else "underspecified",
            },
        )

    def experience_list(
        self,
        status: str | None = None,
        limit: int = 50,
        *,
        task: str | None = None,
        paths: Sequence[str] = (),
    ) -> dict[str, Any]:
        result = self.state_list("experience", status=status, limit=limit)
        if task:
            result["records"] = [item for item in result["records"] if item.get("task") == task]
        if paths:
            requested = set(paths)
            result["records"] = [
                item for item in result["records"] if requested & set(item.get("paths") or [])
            ]
        result["count"] = len(result["records"])
        return result

    def working_memory_capture(
        self,
        text: str,
        *,
        task_session_id: str | None = None,
        salience: float = 0.5,
        expires_at: str | None = None,
        cycle_id: str | None = None,
        kind: str | None = None,
        evidence_refs: Sequence[Any] = (),
    ) -> dict[str, Any]:
        if not bool(getattr(self.settings.reasoning, "working_memory_enabled", True)):
            raise RuntimeError("working memory is disabled by configuration")
        if not text.strip():
            raise ValueError("working-memory note must be non-empty")
        if not 0 <= salience <= 1:
            raise ValueError("working-memory salience must be between zero and one")
        if task_session_id:
            self._session_or_raise(task_session_id)
        normalized_text = text.strip()
        normalized_evidence = list(evidence_refs)
        effective_expires_at = expires_at
        if kind == "verified_fact":
            normalized = normalize_verified_fact(normalized_text, normalized_evidence)
            normalized_text = str(normalized["assertion"])
            normalized_evidence = list(normalized["evidence"])
            effective_expires_at = normalized["expires_at"] or expires_at
        created = self.state_create(
            "working_memory",
            {
                "text": normalized_text,
                "task_session_id": task_session_id,
                "salience": salience,
                "expires_at": effective_expires_at,
                "cycle_id": cycle_id,
                "note_kind": kind,
                "evidence_refs": normalized_evidence,
                "status": "active",
                "captured_at": utc_now(),
            },
        )
        self._mirror_working_memory_note(created["working_memory"])
        self._enforce_working_memory_limit(task_session_id)
        return created

    def working_memory_list(
        self,
        task_session_id: str | None = None,
        status: str | None = "active",
        limit: int = 50,
        *,
        cycle_id: str | None = None,
    ) -> dict[str, Any]:
        result = self.state_list("working_memory", status=status, limit=limit)
        if task_session_id:
            result["records"] = [
                item for item in result["records"] if item.get("task_session_id") == task_session_id
            ]
            result["count"] = len(result["records"])
        if cycle_id:
            result["records"] = [
                item for item in result["records"] if item.get("cycle_id") == cycle_id
            ]
            result["count"] = len(result["records"])
        max_notes = max(1, int(getattr(self.settings.reasoning, "working_memory_max_notes", 64)))
        result["records"].sort(
            key=lambda item: (
                -float(item.get("salience") or 0.0),
                str(item.get("captured_at") or ""),
                str(item.get("record_id") or ""),
            )
        )
        result["records"] = result["records"][: min(limit, max_notes)]
        result["count"] = len(result["records"])
        return result

    def runtime_ingest(
        self, adapters: Sequence[Mapping[str, Any]], *, source: str = "runtime"
    ) -> dict[str, Any]:
        results = []
        for adapter in adapters:
            document = dict(adapter)
            adapter_id = str(document.get("adapter_id") or document.get("id") or "").strip()
            if not adapter_id:
                raise ValueError("runtime adapter requires an adapter_id")
            document.update({"source": source, "status": "available", "observed_at": utc_now()})
            results.append(
                self.state_create("runtime_candidate", document, record_id="runtime_" + adapter_id)
            )
        return {
            "ok": True,
            "status": "ingested",
            "schema_version": "persistmind.runtime_ingest.v1",
            "candidates": results,
        }

    def runtime_candidates(self, status: str | None = "available") -> dict[str, Any]:
        return self.state_list("runtime_candidate", status=status, limit=1000)

    def runtime_link_errors(
        self,
        adapter_id: str = "runtime-link",
        errors: Sequence[Mapping[str, Any]] = (),
    ) -> dict[str, Any]:
        return self.state_update(
            "runtime_" + adapter_id,
            {
                "errors": [dict(item) for item in errors],
                "status": "degraded" if errors else "available",
            },
        )

    def session_start(
        self,
        task_session_id: str,
        *,
        owner: str,
        owner_boot_id: str = "local-boot",
        duration_ms: int = 30_000,
    ) -> dict[str, Any]:
        if self.store.session(task_session_id) is None:
            task_session_id = str(self.task_start(task_session_id)["task_session_id"])
        session_id = "session_" + stable_id(task_session_id, owner, owner_boot_id)[:32]
        token = secrets.token_hex(32)
        nonce = secrets.token_hex(16)
        lease = self.store.acquire_lease(
            "session:" + session_id,
            owner=owner,
            token=token,
            owner_boot_id=owner_boot_id,
            owner_nonce=nonce,
            duration_ms=duration_ms,
        )
        record = self.state_create(
            "agent_session",
            {
                "session_id": session_id,
                "task_session_id": task_session_id,
                "owner": owner,
                "owner_boot_id": owner_boot_id,
                "lease_name": lease["lease_name"],
                "lease_token": token,
                "fencing_token": lease["fencing_token"],
                "status": "active",
                "started_at": utc_now(),
            },
            record_id=session_id,
        )
        return {**record, "lease": dict(lease), "schema_version": "persistmind.session_start.v1"}

    def session_finish(self, session_id: str, *, result: str = "completed") -> dict[str, Any]:
        session = self.store.get(session_id)
        if session is None or session.get("kind") != "agent_session":
            raise KeyError(f"session not found: {session_id}")
        released = self.store.release_lease(
            str(session["lease_name"]),
            token=str(session["lease_token"]),
            fencing_token=int(session["fencing_token"]),
        )
        updated = self.state_update(
            session_id,
            {"status": "finished", "result": result, "finished_at": utc_now()},
        )
        return {**updated, "lease_released": released}

    def session_event(
        self, session_id: str, *, event_type: str, payload: Mapping[str, Any]
    ) -> dict[str, Any]:
        session = self.store.get(session_id)
        if session is None or session.get("kind") != "agent_session":
            raise KeyError(f"session not found: {session_id}")
        return self.state_create(
            "session_event",
            {
                "session_id": session_id,
                "task_session_id": session.get("task_session_id"),
                "event_type": event_type,
                "payload": dict(payload),
                "created_at": utc_now(),
            },
        )

    def session_declare_impact(
        self,
        session_id: str,
        *,
        paths: Sequence[str],
        actions: Sequence[str] = ("write",),
    ) -> dict[str, Any]:
        return self.state_update(
            session_id,
            {"impact": {"paths": sorted(set(paths)), "actions": sorted(set(actions))}},
        )

    def session_explain(self, session_id: str) -> dict[str, Any]:
        task_session = self.store.session(session_id)
        if task_session is not None:
            snapshot = self.store.workflow_snapshot(session_id) or {}
            closure = self._terminal_closure(session_id)
            task_owned_agent_session_id = str(snapshot.get("task_owned_agent_session_id") or "") or None
            task_owned_agent_session = (
                self.store.get(task_owned_agent_session_id) if task_owned_agent_session_id else None
            )
            return {
                "ok": True,
                "status": str(task_session.get("state") or ""),
                "schema_version": "persistmind.session_explain.v1",
                "id_kind": "task_session",
                "session": None,
                "task_session": dict(task_session),
                "workflow_snapshot": dict(snapshot),
                "terminal_closure": closure,
                "terminal_status": closure.get("terminal_status"),
                "closure_receipt_id": closure.get("closure_receipt_id"),
                "task_owned_agent_session_id": task_owned_agent_session_id,
                "task_owned_agent_session": (
                    dict(task_owned_agent_session)
                    if task_owned_agent_session is not None
                    and task_owned_agent_session.get("kind") == "agent_session"
                    else None
                ),
                "agent_session_explainable": bool(
                    task_owned_agent_session is not None
                    and task_owned_agent_session.get("kind") == "agent_session"
                ),
                "events": self.lifecycle.events(session_id),
                "lease": (
                    self.store.lease(str(task_owned_agent_session.get("lease_name") or ""))
                    if task_owned_agent_session is not None
                    and task_owned_agent_session.get("kind") == "agent_session"
                    else None
                ),
            }
        session = self.store.get(session_id)
        if session is None:
            task_owned = self._task_session_for_task_owned_agent_session(session_id)
            if task_owned is not None:
                task_session_id = str(task_owned["task_session_id"])
                explained = self.session_explain(task_session_id)
                explained.update(
                    {
                        "id_kind": "task_owned_agent_session",
                        "status": "snapshot_only",
                        "session_id": session_id,
                        "agent_session_explainable": False,
                        "remediation": (
                            "Use task_session_id for workflow evidence, or start an explicit "
                            "agent session before recording session events."
                        ),
                    }
                )
                return explained
        if session is None or session.get("kind") != "agent_session":
            raise KeyError(f"session not found: {session_id}")
        events = [
            item
            for item in self.state_list("session_event", limit=1000)["records"]
            if item.get("session_id") == session_id
        ]
        return {
            "ok": True,
            "status": str(session.get("status")),
            "schema_version": "persistmind.session_explain.v1",
            "session": dict(session),
            "terminal_closure": self._terminal_closure(str(session.get("task_session_id") or "")),
            "events": events,
            "lease": self.store.lease(str(session.get("lease_name") or "")),
        }

    def _terminal_closure(self, task_session_id: str) -> dict[str, Any]:
        if not task_session_id:
            return {"closed": False}
        row = (
            self.store._reader()
            .execute(
                "SELECT * FROM workflow_terminal_guards WHERE task_session_id=?",
                (task_session_id,),
            )
            .fetchone()
        )
        if row is None:
            return {"closed": False, "task_session_id": task_session_id}
        canonical_outcome_id = str(row["canonical_outcome_id"] or "") or None
        terminal_event_id = str(row["terminal_event_id"] or "") or None
        terminal_status = str(row["terminal_status"] or "") or None
        closure_receipt_id = terminal_event_id or canonical_outcome_id
        event = self.lifecycle.event(terminal_event_id) if terminal_event_id else None
        return {
            "closed": bool(closure_receipt_id),
            "task_session_id": task_session_id,
            "canonical_outcome_id": canonical_outcome_id,
            "terminal_event_id": terminal_event_id,
            "terminal_status": terminal_status or ("outcome_pending" if canonical_outcome_id else None),
            "closure_receipt_id": closure_receipt_id,
            "outcome_sequence": row["outcome_sequence"],
            "updated_at": row["updated_at"],
            "event_type": event.get("event_type") if event else None,
            "payload": event.get("payload") if event else None,
            "accepted_attempts": self._attempt_details_from_closure_event(event),
        }

    def _validate_close_gate(self, task_session_id: str, gate_id: str) -> dict[str, Any]:
        gate_id = gate_id.strip()
        workflow = self.workflow_next(task_session_id)
        gates = workflow.get("gates") if isinstance(workflow, Mapping) else {}
        gate = dict(gates.get(gate_id) or {}) if isinstance(gates, Mapping) else {}
        pending = set(workflow.get("pending_gates") or [])
        next_action = workflow.get("next_action") if isinstance(workflow, Mapping) else None
        actionable = isinstance(next_action, Mapping) and next_action.get("gate_id") == gate_id
        status = str(gate.get("status") or "")
        ok = gate_id in pending and (actionable or status in {"fail", "unverified", "pending", "stale"})
        return {
            "ok": ok,
            "gate_id": gate_id,
            "gate_status": gate,
            "pending_gates": sorted(pending),
            "next_action": dict(next_action) if isinstance(next_action, Mapping) else None,
            "reason": None if ok else "blocking gate is not currently pending for this task",
        }

    def _remediation_attempt_report(
        self, task_session_id: str, gate_id: str
    ) -> dict[str, list[dict[str, Any]]]:
        records = [
            dict(item)
            for item in self.store.search("", limit=1000)
            if item.get("kind") == "working_memory"
            and item.get("task_session_id") == task_session_id
            and item.get("note_kind") == "remediation_attempt"
        ]
        records.sort(
            key=lambda item: (
                str(item.get("captured_at") or item.get("created_at") or ""),
                str(item.get("record_id") or ""),
            )
        )
        accepted: list[dict[str, Any]] = []
        rejected: list[dict[str, Any]] = []
        seen_hashes: set[str] = set()
        for record in records:
            metadata = _remediation_attempt_metadata(record)
            record_id = str(record.get("record_id") or "")
            if metadata.get("gate_id") != gate_id:
                rejected.append({"record_id": record_id, "reason": "gate_mismatch"})
                continue
            approach_hash = str(metadata.get("approach_hash") or "")
            if not approach_hash:
                approach_hash = stable_id(
                    "remediation-attempt",
                    gate_id,
                    str(metadata.get("approach") or record.get("text") or "").casefold(),
                    str(metadata.get("command_or_tool") or "").casefold(),
                )
            if approach_hash in seen_hashes:
                rejected.append(
                    {
                        "record_id": record_id,
                        "reason": "duplicate_approach",
                        "approach": metadata.get("approach"),
                        "command_or_tool": metadata.get("command_or_tool"),
                    }
                )
                continue
            if not str(metadata.get("approach") or "").strip():
                rejected.append({"record_id": record_id, "reason": "missing_approach"})
                continue
            if not (
                str(metadata.get("command_or_tool") or "").strip()
                or str(metadata.get("outcome") or "").strip()
                or str(metadata.get("error") or "").strip()
            ):
                rejected.append({"record_id": record_id, "reason": "missing_observed_result"})
                continue
            seen_hashes.add(approach_hash)
            accepted.append(
                {
                    "record_id": record_id,
                    "gate_id": gate_id,
                    "approach": metadata.get("approach"),
                    "outcome": metadata.get("outcome"),
                    "command_or_tool": metadata.get("command_or_tool"),
                    "error": metadata.get("error"),
                    "waited_seconds": metadata.get("waited_seconds"),
                    "backoff_strategy": metadata.get("backoff_strategy"),
                    "transient_recovery": metadata.get("transient_recovery"),
                    "approach_hash": approach_hash,
                    "recorded_at": metadata.get("recorded_at") or record.get("captured_at"),
                }
            )
        return {"accepted": accepted, "rejected": rejected}

    @staticmethod
    def _attempt_details_from_closure_event(event: Mapping[str, Any] | None) -> list[dict[str, Any]]:
        if not isinstance(event, Mapping):
            return []
        payload = event.get("payload")
        if not isinstance(payload, Mapping):
            return []
        attempts = payload.get("attempts")
        if not isinstance(attempts, Sequence) or isinstance(attempts, (str, bytes)):
            return []
        return [dict(item) for item in attempts if isinstance(item, Mapping)]

    def _durable_fact_accounting(self, task_session_id: str) -> dict[str, list[dict[str, Any]]]:
        promoted: list[dict[str, Any]] = []
        declined: list[dict[str, Any]] = []
        unresolved: list[dict[str, Any]] = []
        for raw in self.store.search("", limit=1000):
            record = dict(raw)
            if (
                record.get("kind") != "working_memory"
                or record.get("task_session_id") != task_session_id
            ):
                continue
            note_kind = str(record.get("note_kind") or "")
            salience = float(record.get("salience") or 0.0)
            if note_kind != "verified_fact" and salience < 0.9:
                continue
            item = {
                "record_id": record.get("record_id"),
                "note_kind": note_kind,
                "status": record.get("status"),
                "knowledge_record_id": record.get("knowledge_record_id"),
                "decline_reason": record.get("decline_reason"),
            }
            if record.get("status") == "promoted":
                promoted.append(item)
            elif record.get("status") == "not_promotable":
                declined.append(item)
            else:
                unresolved.append(item)
        return {"promoted": promoted, "declined": declined, "unresolved": unresolved}

    def _task_session_for_task_owned_agent_session(
        self, agent_session_id: str
    ) -> Mapping[str, Any] | None:
        row = (
            self.store._reader()
            .execute("SELECT * FROM task_workflow_snapshots ORDER BY updated_at DESC")
            .fetchall()
        )
        for item in row:
            snapshot = {
                **json.loads(str(item["payload_json"] or "{}")),
                "task_session_id": str(item["task_session_id"]),
                "pack_id": item["pack_id"],
                "plan_id": item["plan_id"],
                "revision": int(item["revision"]),
                "updated_at": item["updated_at"],
            }
            if str(snapshot.get("task_owned_agent_session_id") or "") == agent_session_id:
                return snapshot
        return None

    def session_leases(self, *, status: str | None = None) -> dict[str, Any]:
        rows = (
            self.store._reader()
            .execute("SELECT lease_name FROM task_leases ORDER BY lease_name")
            .fetchall()
        )
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.session_leases.v1",
            "leases": [
                dict(value)
                for row in rows
                if (value := self.store.lease(str(row["lease_name"]))) is not None
                and (status is None or str(value.get("status") or "active") == status)
            ],
        }

    def session_conflicts(
        self, session_id: str | None = None, *, status: str | None = None
    ) -> dict[str, Any]:
        result = self.state_list("session_conflict", limit=1000)
        if session_id:
            result["records"] = [
                item for item in result["records"] if item.get("session_id") == session_id
            ]
            result["count"] = len(result["records"])
        if status:
            result["records"] = [item for item in result["records"] if item.get("status") == status]
            result["count"] = len(result["records"])
        return result

    def session_conflict_update(
        self,
        session_id: str,
        status_or_paths: str | Sequence[str] | None = None,
        *,
        paths: Sequence[str] = (),
        reason: str = "conflict updated",
        severity: str = "medium",
    ) -> dict[str, Any]:
        current = self.store.get(session_id)
        if (
            current is not None
            and current.get("kind") == "session_conflict"
            and isinstance(status_or_paths, str)
        ):
            return self.state_update(session_id, {"status": status_or_paths, "reason": reason})
        if status_or_paths is not None and not paths and not isinstance(status_or_paths, str):
            paths = status_or_paths
        return self.state_create(
            "session_conflict",
            {
                "session_id": session_id,
                "paths": sorted(set(paths)),
                "reason": reason,
                "severity": severity,
                "status": "open",
                "created_at": utc_now(),
            },
        )

    def session_conflict_ack(
        self, conflict_id: str, *, actor: str = "local-user"
    ) -> dict[str, Any]:
        return self.state_update(
            conflict_id,
            {"status": "acknowledged", "acknowledged_by": actor, "acknowledged_at": utc_now()},
        )

    def session_conflict_resolve(
        self, conflict_id: str, *, resolution: str, actor: str = "local-user"
    ) -> dict[str, Any]:
        return self.state_update(
            conflict_id,
            {
                "status": "resolved",
                "resolution": resolution,
                "resolved_by": actor,
                "resolved_at": utc_now(),
            },
        )

    def orchestration_create(
        self,
        task_session_id: str,
        objective: str | None = None,
        tasks: Sequence[Mapping[str, Any]] | None = None,
        *,
        nodes: Sequence[Mapping[str, Any]] = (),
        integration_owner: str = "local-user",
        budgets: Mapping[str, Any] | None = None,
        dependencies: Sequence[Mapping[str, Any]] = (),
        strategy: str = "parallel",
        budget: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        if self.store.session(task_session_id) is None:
            task_session_id = str(self.task_start(objective or task_session_id)["task_session_id"])
        normalized = [dict(item) for item in (nodes or tasks or ())]
        dependency_map: dict[str, list[str]] = {}
        for item in dependencies:
            value = dict(item)
            child = str(value.get("node_id") or value.get("task_id") or value.get("child") or "")
            parent = str(value.get("depends_on") or value.get("parent") or "")
            if child and parent:
                dependency_map.setdefault(child, []).append(parent)
        for index, node in enumerate(normalized):
            node_id = str(node.get("node_id") or node.get("task_id") or f"node-{index + 1}")
            node.setdefault("node_id", node_id)
            node.setdefault("role", str(node.get("agent") or "worker"))
            node.setdefault("action", str(node.get("task") or node.get("objective") or node_id))
            node.setdefault("dependencies", dependency_map.get(node_id, []))
        _validate_task_dag(normalized)
        for node in normalized:
            required = {"node_id", "role", "action", "dependencies"}
            missing = sorted(required - set(node))
            if missing:
                raise ValueError(f"orchestration node lacks fields: {missing}")
            node.setdefault("path_budget", [])
            node.setdefault("tool_budget", [])
            node.setdefault("network_budget", [])
            node.setdefault("status", "pending")
        return self.state_create(
            "orchestration",
            {
                "task_session_id": task_session_id,
                "nodes": normalized,
                "integration_owner": integration_owner,
                "objective": objective,
                "strategy": strategy,
                "budgets": dict(budgets or budget or {}),
                "status": "planned",
                "revision": 1,
            },
        )

    def orchestration_status(self, orchestration_id: str) -> dict[str, Any]:
        return self.state_show(orchestration_id)

    def orchestration_transition(
        self, orchestration_id: str, *, status: str, expected_revision: int | None = None
    ) -> dict[str, Any]:
        allowed = {"planned", "running", "integrating", "completed", "cancelled", "failed"}
        if status not in allowed:
            raise ValueError("invalid orchestration status")
        return self.state_update(
            orchestration_id,
            {"status": status, "transitioned_at": utc_now()},
            expected_revision=expected_revision,
        )

    def orchestration_child_start(
        self,
        orchestration_id: str,
        node_id: str | None = None,
        *,
        owner: str = "local-agent",
        owner_boot_id: str = "local-boot",
    ) -> dict[str, Any]:
        orchestration = self.store.get(orchestration_id)
        if orchestration is None or orchestration.get("kind") != "orchestration":
            raise KeyError(f"orchestration not found: {orchestration_id}")
        nodes = [dict(item) for item in orchestration.get("nodes", [])]
        if node_id is None:
            node_id = next(
                (str(item.get("node_id")) for item in nodes if item.get("status") == "pending"),
                None,
            )
        if node_id is None:
            raise ValueError("orchestration has no pending child node")
        node = next((item for item in nodes if item.get("node_id") == node_id), None)
        if node is None:
            raise KeyError(f"orchestration node not found: {node_id}")
        completed = {str(item["node_id"]) for item in nodes if item.get("status") == "completed"}
        if not set(node.get("dependencies", [])) <= completed:
            raise PermissionError("orchestration dependencies are not complete")
        token = secrets.token_hex(32)
        nonce = secrets.token_hex(16)
        lease = self.store.acquire_lease(
            f"orchestration:{orchestration_id}:{node_id}",
            owner=owner,
            token=token,
            owner_boot_id=owner_boot_id,
            owner_nonce=nonce,
        )
        node.update(
            {
                "status": "running",
                "owner": owner,
                "lease_token": token,
                "fencing_token": lease["fencing_token"],
            }
        )
        self.state_update(orchestration_id, {"nodes": nodes, "status": "running"})
        return {
            "ok": True,
            "status": "running",
            "schema_version": "persistmind.orchestration_child_start.v1",
            "node": node,
            "lease": dict(lease),
        }

    def orchestration_child_stop(
        self,
        orchestration_id: str,
        node_id: str,
        *,
        status: str = "cancelled",
        changed_files: Sequence[str] = (),
        tests_run: Sequence[str] = (),
        blockers: Sequence[str] = (),
    ) -> dict[str, Any]:
        orchestration = self.store.get(orchestration_id)
        if orchestration is None or orchestration.get("kind") != "orchestration":
            raise KeyError(f"orchestration not found: {orchestration_id}")
        nodes = [dict(item) for item in orchestration.get("nodes", [])]
        node = next((item for item in nodes if item.get("node_id") == node_id), None)
        if node is None:
            raise KeyError(f"orchestration node not found: {node_id}")
        lease_name = f"orchestration:{orchestration_id}:{node_id}"
        released = self.store.release_lease(
            lease_name,
            token=str(node.get("lease_token") or ""),
            fencing_token=int(node.get("fencing_token") or 0),
        )
        node.update(
            {
                "status": status,
                "changed_files": list(changed_files),
                "tests_run": list(tests_run),
                "blockers": list(blockers),
            }
        )
        self.state_update(orchestration_id, {"nodes": nodes})
        return {
            "ok": True,
            "status": status,
            "schema_version": "persistmind.orchestration_child_stop.v1",
            "node": node,
            "lease_released": released,
        }

    def orchestration_output(
        self,
        orchestration_id: str,
        node_id: str,
        *,
        output: Mapping[str, Any],
        evidence: Sequence[Mapping[str, Any]] = (),
        role_id: str | None = None,
    ) -> dict[str, Any]:
        orchestration = self.store.get(orchestration_id)
        if orchestration is None or orchestration.get("kind") != "orchestration":
            raise KeyError(f"orchestration not found: {orchestration_id}")
        nodes = [dict(item) for item in orchestration.get("nodes", [])]
        node = next((item for item in nodes if item.get("node_id") == node_id), None)
        if node is None:
            raise KeyError(f"orchestration node not found: {node_id}")
        if not evidence and not role_id:
            raise ValueError("orchestration output requires independent evidence")
        node.update(
            {
                "status": "completed",
                "output": dict(output),
                "evidence": list(evidence),
                "role_id": role_id,
            }
        )
        self.state_update(orchestration_id, {"nodes": nodes})
        return {
            "ok": True,
            "status": "completed",
            "schema_version": "persistmind.orchestration_output.v1",
            "node": node,
        }

    def orchestration_checkpoint(
        self,
        orchestration_id: str,
        *,
        role_id: str | None = None,
        changed_files: Sequence[str] = (),
        tests: Sequence[str] = (),
        blockers: Sequence[str] = (),
    ) -> dict[str, Any]:
        orchestration = self.store.get(orchestration_id)
        if orchestration is None or orchestration.get("kind") != "orchestration":
            raise KeyError(f"orchestration not found: {orchestration_id}")
        return self.state_create(
            "orchestration_checkpoint",
            {
                "orchestration_id": orchestration_id,
                "orchestration_hash": "sha256:"
                + sha256_text(canonical_json(_payload(orchestration))),
                "status": orchestration.get("status"),
                "role_id": role_id,
                "changed_files": list(changed_files),
                "tests": list(tests),
                "blockers": list(blockers),
                "created_at": utc_now(),
            },
        )

    def orchestration_integrate(
        self,
        orchestration_id: str,
        output_id: str | None = None,
        decision: str | None = None,
        actor: str | None = None,
        *,
        evidence: Sequence[Mapping[str, Any]] = (),
        verifier_status: str | None = None,
        rationale: str | None = None,
    ) -> dict[str, Any]:
        orchestration = self.store.get(orchestration_id)
        if orchestration is None or orchestration.get("kind") != "orchestration":
            raise KeyError(f"orchestration not found: {orchestration_id}")
        actor = actor or str(orchestration.get("integration_owner") or "local-user")
        if actor != orchestration.get("integration_owner"):
            raise PermissionError("only the declared integration owner may integrate outputs")
        nodes = list(orchestration.get("nodes", []))
        if not nodes or any(item.get("status") != "completed" for item in nodes):
            raise PermissionError("all orchestration nodes must complete before integration")
        compatibility_evidence = list(evidence)
        if not compatibility_evidence and (output_id or verifier_status):
            compatibility_evidence = [
                {
                    "output_id": output_id,
                    "decision": decision,
                    "verifier_status": verifier_status,
                    "rationale": rationale,
                }
            ]
        if not compatibility_evidence:
            raise ValueError("integration requires verifier evidence")
        return self.state_update(
            orchestration_id,
            {
                "status": "completed",
                "integration_evidence": compatibility_evidence,
                "integrated_at": utc_now(),
            },
        )

    def orchestration_child_pack(
        self, orchestration_id: str, node_id: str, *, probe: bool = False
    ) -> dict[str, Any]:
        orchestration = self.store.get(orchestration_id)
        if orchestration is None or orchestration.get("kind") != "orchestration":
            raise KeyError(f"orchestration not found: {orchestration_id}")
        node = next(
            (item for item in orchestration.get("nodes", []) if item.get("node_id") == node_id),
            None,
        )
        if node is None:
            raise KeyError(f"orchestration node not found: {node_id}")
        child_task = str(node.get("action") or node_id)
        result = self.codex_preflight(
            child_task,
            paths=list(node.get("path_budget") or []),
            probe=probe,
        )
        return {
            **result,
            "schema_version": "persistmind.orchestration_child_pack.v1",
            "orchestration_id": orchestration_id,
            "node_id": node_id,
        }

    def task_execute(
        self,
        task_session_id: str,
        *,
        grant_id: str,
        capability: str,
        artifact_version: str,
        risk_class: str,
        action: Mapping[str, Any],
        context: Mapping[str, Any],
        utility: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        return self.task_action_authorize(
            task_session_id,
            grant_id=grant_id,
            capability=capability,
            artifact_version=artifact_version,
            risk_class=risk_class,
            action=action,
            context=context,
            utility=utility,
        )

    def task_pack_rebind(
        self,
        task_session_id: str,
        *,
        pack_id: str,
        expected_revision: int | None = None,
    ) -> dict[str, Any]:
        session = self._session_or_raise(task_session_id)
        snapshot = self.store.workflow_snapshot(task_session_id)
        if snapshot is None:
            raise KeyError(f"workflow snapshot not found: {task_session_id}")
        revision = int(snapshot["revision"])
        if expected_revision is not None and expected_revision != revision:
            raise TaskConflict("workflow snapshot revision differs")
        updated = self.store.rebind_pack(
            task_session_id,
            pack_id=pack_id,
            expected_revision=revision,
            idempotency_key=f"task-pack-rebind:{task_session_id}:{revision}:{pack_id}",
        )
        self.store.transition(
            task_session_id,
            to_state=str(session["state"]),
            payload={**_payload(session), "pack_id": pack_id},
            expected_revision=int(session["revision"]),
            transition_id="transition_" + stable_id(task_session_id, "pack-rebind", pack_id)[:32],
            idempotency_key=f"task-pack-state:{task_session_id}:{pack_id}",
        )
        event = self.lifecycle.emit(
            "PackBound.v1",
            task_session_id,
            source_operation_key=f"task-pack-rebind:{task_session_id}:{pack_id}",
            payload={"pack_id": pack_id, "snapshot_revision": updated["revision"]},
            producer="task-service",
            required_consumers=("activity.pack_rebind.v1",),
        )
        return {
            "ok": True,
            "status": "rebound",
            "schema_version": "persistmind.task_pack_rebind.v1",
            "snapshot": dict(updated),
            "event": event,
        }

    def workflow_lint(self) -> dict[str, Any]:
        sessions = [
            dict(item)
            for item in self.store._reader()
            .execute("SELECT task_session_id FROM task_sessions ORDER BY task_session_id")
            .fetchall()
        ]
        violations = []
        for item in sessions:
            task_session_id = str(item["task_session_id"])
            session = self.store.session(task_session_id)
            transitions = self.store.transitions(task_session_id)
            chain = _verify_transition_chain(task_session_id, transitions)
            if not chain["ok"]:
                violations.append({"task_session_id": task_session_id, "chain": chain})
            if (
                session
                and session.get("state") == "OUTCOME"
                and not self.store.verifications(task_session_id)
            ):
                violations.append(
                    {"task_session_id": task_session_id, "reason": "outcome_without_verification"}
                )
        return {
            "ok": not violations,
            "status": "verified" if not violations else "validation_failed",
            "schema_version": "persistmind.workflow_lint.v1",
            "violations": violations,
        }

    def workflow_recommend(
        self,
        task_session_id: str | None = None,
        *,
        mode: str | None = None,
        paths: Sequence[str] = (),
        capabilities: Sequence[str] = (),
        intent_id: str | None = None,
        goal_id: str | None = None,
    ) -> dict[str, Any]:
        if task_session_id:
            task = self.store.session(task_session_id)
            if task is None:
                return {
                    "ok": True,
                    "status": "candidate",
                    "schema_version": "persistmind.workflow_recommend.v1",
                    "task": task_session_id,
                    "mode": mode,
                    "paths": list(paths),
                    "capabilities": list(capabilities),
                    "intent_id": intent_id,
                    "goal_id": goal_id,
                    "recommended_state": "INTAKE",
                }
            state = str(task["state"])
            next_state = TASK_STATES[min(TASK_STATES.index(state) + 1, len(TASK_STATES) - 1)]
            return {
                "ok": True,
                "status": "candidate",
                "schema_version": "persistmind.workflow_recommend.v1",
                "task_session_id": task_session_id,
                "current_state": state,
                "recommended_state": next_state,
            }
        lint = self.workflow_lint()
        return {
            "ok": True,
            "status": "candidate",
            "schema_version": "persistmind.workflow_recommend.v1",
            "recommendations": lint["violations"],
        }

    def plan_validate(
        self,
        plan: dict[str, Any],
        *,
        task_session_id: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        plan = self._with_task_acceptance_checklist(plan, task_session_id)
        normalized, schema_errors = normalize_plan(plan)
        if pack_id:
            session = self.store.session(task_session_id) if task_session_id else None
            bound_pack_id = str((session or {}).get("pack_id") or "")
            event = self.activity.event(pack_id)
            if event is None or str(event.get("event_type") or "") != "context_pack.finalized":
                schema_errors.append(
                    {
                        "type": "schema_error",
                        "path": "pack_id",
                        "message": "pack_id is not finalized in the authoritative authority pack store",
                        "blocking": True,
                    }
                )
            if not bound_pack_id or bound_pack_id != pack_id:
                schema_errors.append(
                    {
                        "type": "schema_error",
                        "path": "pack_id",
                        "message": "pack_id does not match the task-bound authority pack",
                        "blocking": True,
                    }
                )
        normalized = _apply_governed_defaults(normalized, self.settings)
        scope_errors = _canonicalize_plan_scopes(normalized, self.repo_root, source_plan=plan)
        schema_errors.extend(scope_errors)
        if scope_errors:
            return {
                "ok": False,
                "status": "validation_failed",
                "error_code": "plan_path_outside_repository",
                "schema_version": "persistmind.task_plan_validation.v1",
                "schema_errors": schema_errors,
                "policy": {
                    "ok": False,
                    "violations": [],
                    "skipped_reason": "invalid_repository_scope",
                },
                "impact_report": {
                    "ok": False,
                    "schema_version": "persistmind.source_impact.v1",
                    "input_paths": [],
                    "impacted_paths": [],
                    "skipped_reason": "invalid_repository_scope",
                },
                "behavior_report": {
                    "ok": False,
                    "applicable_directives": 0,
                    "skipped_reason": "invalid_repository_scope",
                },
                "warnings": [],
                "applicable_guardrails": {
                    "enabled": False,
                    "reason": "invalid_repository_scope",
                    "steps": [],
                },
                "plan_hash": None,
                "task_session_id": task_session_id,
                "pack_id": pack_id,
                "constitution_hash": None,
                "normalized_plan": normalized,
                "remediation": (
                    "Remove the external path from the PersistMind plan and manage the "
                    "explicitly authorized Codex memory action separately."
                ),
            }
        policy = CapabilityPolicy(self.repo_root, self.settings).check_paths(
            intended_files(normalized),
            task_session_id=task_session_id,
            for_ci=True,
        )
        constitution_hash = None
        if task_session_id:
            session = self.store.session(task_session_id)
            constitution_hash = (
                _payload(session).get("constitution_hash") if session is not None else None
            )
        paths = intended_files(normalized)
        directives = list(self.policy.applicable_policy({"scope": "global"}))
        applicable = [item for item in directives if _policy_applies(item, paths)]
        generations = self.source.generations(limit=1)
        if generations:
            from .source_service import SourceService

            with SourceService(
                self.repo_root,
                allow_development_driver=self._allow_development_driver,
                read_only=True,
            ) as source:
                source_report = source.impact(paths)
        else:
            source_report = {
                "ok": False,
                "schema_version": "persistmind.source_impact.v1",
                "input_paths": paths,
                "impacted_paths": [],
            }
        valid = not schema_errors and bool(policy["ok"])
        return {
            "ok": valid,
            "status": "ok" if valid else "validation_failed",
            "schema_version": "persistmind.task_plan_validation.v1",
            "schema_errors": schema_errors,
            "policy": policy,
            "impact_report": source_report,
            "behavior_report": {"ok": True, "applicable_directives": len(applicable)},
            "warnings": []
            if generations
            else [
                {
                    "type": "source_index_missing",
                    "reason": "run persistmind index before plan execution",
                }
            ],
            "applicable_guardrails": {
                "enabled": bool(applicable),
                "reason": "authoritative Policy evaluation",
                "steps": applicable,
            },
            "plan_hash": plan_hash(normalized),
            "task_session_id": task_session_id,
            "pack_id": pack_id,
            "constitution_hash": constitution_hash,
            "normalized_plan": normalized,
        }

    def plan_create(
        self,
        task_session_id: str,
        plan: dict[str, Any],
        *,
        pack_id: str | None = None,
        author: str = "local-user",
    ) -> dict[str, Any]:
        self._session_or_raise(task_session_id)
        validation = self.plan_validate(plan, task_session_id=task_session_id, pack_id=pack_id)
        if not validation["ok"]:
            return {
                "ok": False,
                "status": str(validation.get("status") or "validation_failed"),
                "error_code": validation.get("error_code"),
                "remediation": validation.get("remediation"),
                "task_session_id": task_session_id,
                "pack_id": pack_id,
                "validation": _public_validation(validation),
            }
        normalized = validation["normalized_plan"]
        identifier = "plan_" + stable_id(
            self.workspace_id, self.repo_id, task_session_id, validation["plan_hash"]
        )
        existing = self.store.plan(identifier)
        if existing is not None:
            response = self._plan_response(existing, validation, previous_plan_hash=None)
            response["task_state"] = self._advance_task_state(
                task_session_id,
                "PLAN",
                reason=f"structured plan active: {identifier}",
                pack_id=pack_id,
            )
            return response
        saved = self.store.write_plan(
            identifier,
            task_session_id=task_session_id,
            status="active",
            payload=self._plan_payload(
                task_session_id,
                normalized,
                validation,
                pack_id=pack_id,
                author=author,
            ),
            expected_revision=0,
            idempotency_key=f"plan-create:{identifier}",
        )
        self._upsert_continuation(
            self._session_or_raise(task_session_id),
            event="plan_created",
            state="planned",
            reason=f"plan created: {identifier}",
        )
        event = self.lifecycle.emit(
            "PlanActivated.v1",
            task_session_id,
            source_operation_key=f"plan-activate:{identifier}:{saved['revision']}",
            payload={
                "pack_id": pack_id,
                "plan_id": identifier,
                "plan_revision": int(saved["revision"]),
                "plan_hash": str(saved.get("plan_hash") or ""),
                "active_step_id": str(
                    normalized["steps"][0].get("id") or normalized["steps"][0].get("title")
                ),
            },
            producer="task-service",
        )
        response = self._plan_response(
            saved,
            validation,
            previous_plan_hash=None,
            lifecycle_event=event,
        )
        response["task_state"] = self._advance_task_state(
            task_session_id,
            "PLAN",
            reason=f"structured plan created: {identifier}",
            pack_id=pack_id,
        )
        return response

    def plan_amend(
        self,
        plan_id: str,
        plan: dict[str, Any],
        *,
        author: str = "local-user",
        reason: str | None = None,
    ) -> dict[str, Any]:
        current = self.store.plan(plan_id)
        if current is None:
            raise KeyError(f"task plan not found: {plan_id}")
        validation = self.plan_validate(plan, task_session_id=str(current["task_session_id"]))
        if not validation["ok"]:
            return {
                "ok": False,
                "status": str(validation.get("status") or "validation_failed"),
                "error_code": validation.get("error_code"),
                "remediation": validation.get("remediation"),
                "plan_id": plan_id,
                "validation": _public_validation(validation),
            }
        saved = self.store.write_plan(
            plan_id,
            task_session_id=str(current["task_session_id"]),
            status=str(current["status"]),
            payload=self._plan_payload(
                str(current["task_session_id"]),
                validation["normalized_plan"],
                validation,
                pack_id=str(current.get("metadata", {}).get("pack_id") or "") or None,
                author=author,
                reason=reason,
            ),
            expected_revision=int(current["revision"]),
            idempotency_key=None,
        )
        self._upsert_continuation(
            self._session_or_raise(str(current["task_session_id"])),
            event="plan_amended",
            state="planned",
            reason=reason or f"plan amended: {plan_id}",
        )
        event = self.lifecycle.emit(
            "PlanActivated.v1",
            str(current["task_session_id"]),
            source_operation_key=f"plan-activate:{plan_id}:{saved['revision']}",
            payload={
                "pack_id": str(current.get("metadata", {}).get("pack_id") or "") or None,
                "plan_id": plan_id,
                "plan_revision": int(saved["revision"]),
                "plan_hash": str(saved.get("plan_hash") or ""),
                "active_step_id": str(
                    validation["normalized_plan"]["steps"][0].get("id")
                    or validation["normalized_plan"]["steps"][0].get("title")
                ),
            },
            producer="task-service",
        )
        return self._plan_response(
            saved,
            validation,
            previous_plan_hash=str(current.get("plan_hash") or "") or None,
            lifecycle_event=event,
        )

    def plan_show(self, plan_id: str) -> dict[str, Any]:
        plan = self.store.plan(plan_id)
        if plan is None:
            return {"ok": False, "error": "task plan not found", "plan_id": plan_id}
        return {
            "ok": True,
            "schema_version": "persistmind.task_plan_show.v1",
            "plan": plan,
            "revisions": list(self.store.plan_revisions(plan_id)),
            "checkpoints": list(self.store.checkpoints(plan_id)),
            "nextgen_v1": True,
        }

    def verification_record(
        self,
        task_session_id: str,
        *,
        evidence_type: str,
        verification_name: str | None = None,
        command: str,
        result: str,
        artifact: Mapping[str, Any],
    ) -> dict[str, Any]:
        session = self._session_or_raise(task_session_id)
        plan = self.store.latest_plan(task_session_id)
        revisions = list(self.store.plan_revisions(str(plan["plan_id"]))) if plan else []
        revision = revisions[-1] if revisions else None
        pack_id = str(session.get("pack_id") or "")
        if plan is None or revision is None or not pack_id:
            raise ValueError("typed verification requires a bound pack and active plan revision")
        if str(plan.get("metadata", {}).get("pack_id") or "") != pack_id:
            raise ValueError("typed verification plan does not bind the current pack")
        impact = dict(revision.get("validation", {}).get("impact_report") or {})
        source_view = {
            "snapshot_id": impact.get("snapshot_id"),
            "generation_id": impact.get("source_generation_id"),
            "fingerprint": impact.get("source_index_fingerprint"),
        }
        normalized_result = "pass" if result.casefold() == "pass" else "fail"
        typed = build_verification_evidence(
            evidence_type=evidence_type,
            task_session_id=task_session_id,
            pack_id=pack_id,
            plan_id=str(plan["plan_id"]),
            plan_revision_id=str(revision["revision_id"]),
            plan_revision_number=int(revision["revision"]),
            scope_revision_id=str(revision["revision_id"]),
            source_view=source_view,
            diff_fingerprint=current_diff_fingerprint(self.repo_root),
            command=command,
            result=normalized_result,
            artifact=artifact,
        )
        verification_id = "verification_" + stable_id(typed["evidence_id"])[0:32]
        saved = self.store.append_verification(
            verification_id,
            task_session_id=task_session_id,
            payload={
                "name": verification_name or evidence_type,
                "evidence_type": evidence_type,
                "pack_id": pack_id,
                "plan_id": str(plan["plan_id"]),
                "status": normalized_result,
                "command": command,
                "artifact_hash": typed["artifact_hash"],
                "typed_evidence": typed,
            },
            idempotency_key=f"typed-verification:{typed['evidence_id']}",
        )
        event = self.lifecycle.emit(
            "VerificationCompleted.v1",
            task_session_id,
            source_operation_key=f"verification:{verification_id}",
            payload={
                "verification_id": verification_id,
                "verification_name": verification_name or evidence_type,
                "evidence_type": evidence_type,
                "pack_id": pack_id,
                "plan_id": str(plan["plan_id"]),
                "status": normalized_result,
                "report_hash": str(typed["artifact_hash"]),
            },
            producer="task-service",
        )
        snapshot = self.store.workflow_snapshot(task_session_id)
        snapshot_payload = {
            key: value
            for key, value in dict(snapshot or {}).items()
            if key not in {"task_session_id", "pack_id", "plan_id", "revision", "updated_at"}
        }
        snapshot_payload.update(
            {
                "verification_id": verification_id,
                "verification_name": evidence_type,
                "verification_status": normalized_result,
                "verification_report_hash": str(typed["artifact_hash"]),
                "last_lifecycle_event_id": event["event_id"],
                "last_lifecycle_sequence": event["sequence"],
            }
        )
        self.store.save_workflow_snapshot(
            task_session_id,
            payload=snapshot_payload,
            pack_id=pack_id,
            plan_id=str(plan["plan_id"]),
            expected_revision=int((snapshot or {}).get("revision") or 0),
        )
        return {
            "ok": normalized_result == "pass",
            "verification": saved,
            "nextgen_v1": True,
            "lifecycle_event_id": event["event_id"],
            "lifecycle_sequence": event["sequence"],
        }

    def verify_run(
        self,
        commands: list[str],
        *,
        pack_id: str | None = None,
        plan_id: str | None = None,
        name: str | None = None,
        retry_budget: int = 0,
        timeout: int = 120,
    ) -> dict[str, Any]:
        """Execute governed commands against the plan-bound Source view.

        Verification validates the current diff separately through its typed
        fingerprint. It must not create a new source generation merely because
        the worktree changed after the context pack was served.
        """

        from persistmind.snapshot import SnapshotInfo
        from persistmind.verification.runner import VerificationRunner
        from persistmind.workflow.evidence import evidence_type_for_name

        if not commands:
            raise ValueError("verify run requires at least one command")
        if not plan_id:
            raise ValueError("verify run requires --plan-id")
        plan = self.store.plan(plan_id)
        if plan is None:
            raise KeyError(f"task plan not found: {plan_id}")
        task_session_id = str(plan["task_session_id"])
        session = self._session_or_raise(task_session_id)
        bound_pack_id = str(plan.get("metadata", {}).get("pack_id") or session.get("pack_id") or "")
        if not pack_id:
            pack_id = bound_pack_id or None
        if not pack_id:
            raise ValueError("verify run requires a plan-bound pack")
        if bound_pack_id and pack_id != bound_pack_id:
            raise ValueError("verification pack does not match the active task plan")
        if str(session["state"]) not in {"EXECUTE", "PREFLIGHT"}:
            raise ValueError("verification requires an EXECUTE or PREFLIGHT task")
        impact = dict(plan.get("validation", {}).get("impact_report") or {})
        snapshot_id = str(impact.get("snapshot_id") or pack_id)
        snapshot = SnapshotInfo(
            repo_id=self.repo_id,
            snapshot_id=snapshot_id,
            base_commit_sha="",
            tree_digest="",
            dirty_digest="",
            worktree_state="plan-bound",
            branch_hint=None,
        )
        task_metadata = _payload(session).get("metadata") or {}
        task_text = str(task_metadata.get("objective") or task_metadata.get("task") or "repair")
        result = VerificationRunner(
            self.repo_root,
            _RepairCompiler(
                self.repo_root,
                allow_development_driver=self._allow_development_driver,
                task_text=task_text,
            ),
        ).run(
            snapshot=snapshot,
            commands=commands,
            pack_id=pack_id,
            retry_budget=retry_budget,
            timeout=timeout,
        )
        verification_name = name or "tests"
        evidence_type = evidence_type_for_name(verification_name) or "tests"
        recorded = self.verification_record(
            task_session_id,
            evidence_type=evidence_type,
            verification_name=verification_name,
            command=" && ".join(commands),
            result="pass" if result.get("ok") else "fail",
            artifact=result,
        )
        saved = dict(recorded["verification"])
        result["typed_evidence"] = saved.get("typed_evidence")
        result["task_verification"] = saved
        result["plan_id"] = plan_id
        result["task_session_id"] = task_session_id
        result["nextgen_v1"] = True
        result["lifecycle_event_id"] = recorded["lifecycle_event_id"]
        result["lifecycle_sequence"] = recorded["lifecycle_sequence"]
        if result.get("ok"):
            contract_assessment = self._contract_scope_assessment(
                plan=dict(plan),
                pack_id=pack_id,
                task_session_id=task_session_id,
            )
            missing_contract_items = list(contract_assessment.get("missing_contract_items", []))
            contract_scope = {
                "checklist_status": contract_assessment.get("checklist_status", "empty"),
                "checklist_item_count": len(contract_assessment.get("acceptance_checklist", [])),
                "satisfied_count": len(contract_assessment.get("satisfied_contract_items", [])),
                "missing_items": missing_contract_items,
                "advisory_items": list(contract_assessment.get("advisory_contract_items", [])),
            }
            result["contract_scope"] = contract_scope
            typed_evidence = saved.get("typed_evidence")
            terminal_evidence = {
                "kind": "terminal_verifier",
                "verification_id": saved.get("verification_id"),
                "verification_name": verification_name,
                "result": "pass",
                "commands": list(commands),
                "contract_scope": contract_scope,
            }
            if isinstance(typed_evidence, Mapping):
                terminal_evidence["evidence_id"] = typed_evidence.get("evidence_id")
                terminal_evidence["artifact_hash"] = typed_evidence.get("artifact_hash")
            if missing_contract_items:
                terminal_resolution = self.task_resolve(
                    task_session_id,
                    conditions=(ResolutionStatus.CANDIDATE,),
                    evidence=[terminal_evidence],
                    limitations=["Verification commands passed but contract coverage is incomplete."],
                )
                result["ok"] = False
                result["status"] = "contract_coverage_incomplete"
                result["missing_contract_items"] = missing_contract_items
            else:
                terminal_resolution = self.task_resolve(
                    task_session_id,
                    conditions=(ResolutionStatus.VERIFIED,),
                    evidence=[terminal_evidence],
                )
            workflow_snapshot = self.store.workflow_snapshot(task_session_id) or {}
            snapshot_payload = {
                key: value
                for key, value in dict(workflow_snapshot).items()
                if key not in {"revision", "updated_at"}
            }
            snapshot_payload.update(
                {
                    "terminal_status": terminal_resolution["primary_status"],
                    "terminal_resolution_id": terminal_resolution["record_id"],
                    "contract_scope": contract_scope,
                }
            )
            self.store.save_workflow_snapshot(
                task_session_id,
                payload=snapshot_payload,
                pack_id=pack_id,
                plan_id=plan_id,
                expected_revision=int(workflow_snapshot.get("revision") or 0),
            )
            result["terminal_resolution"] = terminal_resolution
        checkpoint_readiness = self._plan_checkpoint_readiness(plan)
        result["checkpoint_readiness"] = checkpoint_readiness
        if result.get("ok") and checkpoint_readiness["ready"]:
            result["task_state"] = self._advance_task_state(
                task_session_id,
                "PREFLIGHT",
                reason=f"verification passed: {verification_name}",
                pack_id=pack_id,
            )
        elif result.get("ok"):
            result["workflow_ready"] = False
        return result

    def _contract_scope_assessment(
        self, *, plan: dict[str, Any], pack_id: str, task_session_id: str
    ) -> dict[str, Any]:
        manifest = self._pack_manifest_from_activity(pack_id)
        retrieved_paths = [
            str(item.get("path"))
            for item in manifest.get("items", [])
            if isinstance(item, Mapping) and item.get("path")
        ]
        retrieved_paths.extend(str(path) for path in manifest.get("seed_paths", []) if path)
        plan_id = str(plan.get("plan_id") or "")
        actual_paths = git_changed_paths(self.repo_root)
        if not actual_paths and plan_id:
            actual_paths = sorted(
                {
                    str(path)
                    for checkpoint in self.store.checkpoints(plan_id)
                    for path in checkpoint.get("changed_paths", [])
                    if path
                }
            )
        return assess_scope_documents(
            repo_root=self.repo_root,
            actual_paths=actual_paths,
            retrieved_paths=sorted(set(retrieved_paths)),
            task_session_id=task_session_id,
            pack_id=pack_id,
            plan_id=plan_id,
            plan_revision_id=None,
            plan_revision_number=int(plan.get("revision") or 0),
            plan_hash=str(plan.get("plan_hash") or ""),
            plan_document=dict(plan.get("plan") or {}),
            validation=dict(plan.get("validation") or {}),
            acceptance_checklist=required_contract_items(dict(plan.get("plan") or {})),
            required_verifications=[str(item) for item in plan.get("required_verifications", [])],
            passed_verifications=[
                str(item.get("name"))
                for item in self.store.verifications(task_session_id)
                if str(item.get("plan_id") or "") == str(plan.get("plan_id") or "")
                and str(item.get("status") or "").casefold() in {"pass", "passed", "ok", "success"}
            ],
            source_view={
                "snapshot_id": manifest.get("snapshot_id"),
                "generation_id": manifest.get("source_generation_id"),
                "fingerprint": manifest.get("source_index_fingerprint"),
            },
            diff=None,
            incomplete_reasons=[],
        )

    def _pack_manifest_from_activity(self, pack_id: str) -> dict[str, Any]:
        event = self.activity.event(pack_id)
        if event is None or str(event.get("event_type") or "") != "context_pack.finalized":
            return {}
        outer = event.get("payload")
        payload = outer.get("payload") if isinstance(outer, Mapping) else None
        if not isinstance(payload, Mapping):
            return {}
        manifest = payload.get("manifest")
        if isinstance(manifest, dict):
            return manifest
        object_ref = str(payload.get("object_ref") or "")
        if object_ref:
            try:
                value = json.loads(self.runtime.artifacts.get(object_ref))
            except (TypeError, ValueError, KeyError):
                return {}
            return value if isinstance(value, dict) else {}
        return {}

    def plan_checkpoint(
        self,
        plan_id: str,
        step_id: str,
        *,
        paths: list[str] | None = None,
        staged: bool | None = None,
    ) -> dict[str, Any]:
        plan = self.store.plan(plan_id)
        if plan is None:
            raise KeyError(f"task plan not found: {plan_id}")
        definition = dict(plan.get("plan") or {})
        step = next(
            (
                item
                for item in definition.get("steps", [])
                if isinstance(item, dict) and item.get("id") == step_id
            ),
            None,
        )
        changed_paths = sorted(
            {
                normalize_repo_relative_path(path)
                for path in (paths or [])
                if normalize_repo_relative_path(path)
            }
        )
        declared = list(step.get("intended_files", [])) if isinstance(step, dict) else []
        violations: list[dict[str, Any]] = []
        if step is None:
            violations.append(
                {
                    "type": "unknown_step",
                    "step_id": step_id,
                    "blocking": True,
                    "reason": "Checkpoint step is not declared in the active task plan.",
                }
            )
        else:
            for path in changed_paths:
                if not any(
                    repo_path_matches_scope(path, item, self.repo_root) for item in declared
                ):
                    violations.append(
                        {
                            "type": "out_of_step_edit",
                            "step_id": step_id,
                            "path": path,
                            "blocking": True,
                            "reason": "Changed path is outside this step's intended_files.",
                            "declared_files": declared,
                        }
                    )
        policy = CapabilityPolicy(self.repo_root, self.settings).check_paths(
            changed_paths,
            task_session_id=str(plan["task_session_id"]),
            for_ci=False,
        )
        violations.extend(policy["violations"])
        status = "pass" if not any(item.get("blocking") for item in violations) else "fail"
        checkpoint_id = "checkpoint_" + stable_id(
            plan_id, step_id, canonical_json(changed_paths), str(plan["revision"])
        )
        checkpoint = self.store.create_plan_checkpoint(
            checkpoint_id,
            plan_id=plan_id,
            task_session_id=str(plan["task_session_id"]),
            payload={
                "step_id": step_id,
                "status": status,
                "changed_paths": changed_paths,
                "declared_files": declared,
                "violations": violations,
                "staged": staged,
            },
            idempotency_key=f"plan-checkpoint:{checkpoint_id}",
        )
        declared_changes = {
            path
            for path in changed_paths
            if any(repo_path_matches_scope(path, item, self.repo_root) for item in declared)
        }
        ambient_paths = sorted(set(changed_paths) - declared_changes)
        manifest_id = "evidence_" + stable_id(checkpoint_id)
        self.store.freeze_evidence_manifest(
            manifest_id,
            task_session_id=str(plan["task_session_id"]),
            payload={
                "plan_id": plan_id,
                "checkpoint_id": checkpoint_id,
                "declared_paths": declared,
                "ambient_paths": ambient_paths,
                "verification_refs": [],
            },
            expected_revision=0,
            idempotency_key=f"evidence:{checkpoint_id}",
        )
        self._upsert_continuation(
            self._session_or_raise(str(plan["task_session_id"])),
            event="plan_checkpoint",
            state="editing" if status == "pass" else "blocked",
            blockers=(
                []
                if status == "pass"
                else [f"Checkpoint {step_id} failed with {len(violations)} violation(s)."]
            ),
            reason=f"checkpoint {status}: {step_id}",
        )
        event = self.lifecycle.emit(
            "PlanCheckpointed.v1",
            str(plan["task_session_id"]),
            source_operation_key=f"checkpoint:{checkpoint_id}",
            payload={
                "plan_id": plan_id,
                "plan_revision": int(plan["revision"]),
                "checkpoint_id": checkpoint_id,
                "step_id": step_id,
                "status": status,
                "evidence_manifest_id": manifest_id,
                "changed_paths_hash": sha256_text(canonical_json(changed_paths)),
            },
            producer="task-service",
        )
        response = {
            "ok": status == "pass",
            "checkpoint_id": checkpoint["checkpoint_id"],
            "plan_id": plan_id,
            "task_session_id": str(plan["task_session_id"]),
            "pack_id": str(plan.get("metadata", {}).get("pack_id") or "") or None,
            "step_id": step_id,
            "status": status,
            "changed_paths": changed_paths,
            "declared_files": declared,
            "violations": violations,
            "policy": policy,
            "evidence_manifest_id": manifest_id,
            "nextgen_v1": True,
            "lifecycle_event_id": event["event_id"],
            "lifecycle_sequence": event["sequence"],
        }
        if status == "pass":
            response["task_state"] = self._advance_task_state(
                str(plan["task_session_id"]),
                "EXECUTE",
                reason=f"plan checkpoint passed: {step_id}",
                pack_id=str(plan.get("metadata", {}).get("pack_id") or "") or None,
            )
        return response

    def continuation_list(self, status: str | None = None, limit: int = 20) -> dict[str, Any]:
        return {
            "ok": True,
            "schema_version": "persistmind.continuation_list.v1",
            "continuations": [
                self._public_continuation(item)
                for item in self.store.continuations(status=status, limit=limit)
            ],
            "nextgen_v1": True,
        }

    def continuation_show(self, continuation_id: str) -> dict[str, Any]:
        row = self.store.continuation(continuation_id)
        if row is None:
            return {
                "ok": False,
                "error": "continuation not found",
                "continuation_id": continuation_id,
            }
        return {
            "ok": True,
            "schema_version": "persistmind.continuation_show.v1",
            "continuation": self._public_continuation(row),
            "revisions": [
                {
                    "revision": row["revision"],
                    "updated_at": row["updated_at"],
                    "reason": row.get("reason"),
                }
            ],
            "nextgen_v1": True,
        }

    def continuation_update(
        self,
        continuation_id: str,
        *,
        state: str | None = None,
        next_action: str | None = None,
        blockers: list[str] | None = None,
        reason: str = "manual continuation update",
    ) -> dict[str, Any]:
        current = self.store.continuation(continuation_id)
        if current is None:
            return {
                "ok": False,
                "error": "continuation not found",
                "continuation_id": continuation_id,
            }
        payload = _continuation_payload(current)
        if state:
            payload["current_state"] = state
        if next_action is not None:
            payload["next_action"] = next_action
        if blockers is not None:
            payload["blockers"] = list(blockers)
        payload["reason"] = reason
        status = "active" if payload["current_state"] in _ACTIVE_CONTINUATION_STATES else "expired"
        updated = self.store.upsert_continuation(
            continuation_id,
            task_session_id=str(current["task_session_id"]),
            task_hash=str(current["task_hash"]),
            status=status,
            payload=payload,
            expected_revision=int(current["revision"]),
            idempotency_key=None,
        )
        return {"ok": True, "continuation": self._public_continuation(updated), "nextgen_v1": True}

    def continuation_resume(self, task: str, limit: int = 3) -> dict[str, Any]:
        matches = [
            self._public_continuation(item)
            for item in self.store.continuations_for_task_hash(sha256_text(task))[:limit]
        ]
        return {
            "ok": True,
            "task_text_hash": sha256_text(task),
            "continuations": matches,
            "matches": matches,
            "nextgen_v1": True,
        }

    def continuation_abandon(self, continuation_id: str, reason: str) -> dict[str, Any]:
        return self.continuation_update(
            continuation_id,
            state="abandoned",
            next_action="No resume action; task was abandoned.",
            blockers=[reason],
            reason=reason,
        )

    def _public_continuation(self, value: Mapping[str, Any]) -> dict[str, Any]:
        projected = _public_continuation(value)
        diagnostics = _continuation_staleness(self.repo_root, projected)
        projected.update(diagnostics)
        if (
            projected["status"] == "active"
            and diagnostics["staleness_state"] in {"stale", "expired"}
        ):
            projected["status"] = "stale"
        return projected

    def _task_start_response(
        self,
        session: Mapping[str, Any],
        *,
        created: bool,
        lifecycle_event: Mapping[str, Any] | None = None,
        agent_session_id: str | None = None,
    ) -> dict[str, Any]:
        payload = _payload(session)
        return {
            "ok": True,
            "schema_version": "persistmind.task_start.v1",
            "task_session_id": session["task_session_id"],
            "state": session["state"],
            "constitution_hash": payload.get("constitution_hash"),
            "agent_session_id": agent_session_id,
            "created": created,
            "nextgen_v1": True,
            "lifecycle_event_id": (lifecycle_event.get("event_id") if lifecycle_event else None),
            "lifecycle_sequence": (lifecycle_event.get("sequence") if lifecycle_event else None),
        }

    def _session_or_raise(self, task_session_id: str) -> Mapping[str, Any]:
        session = self.store.session(task_session_id)
        if session is None:
            raise KeyError(f"task session not found: {task_session_id}")
        return session

    def _plan_payload(
        self,
        task_session_id: str,
        normalized: Mapping[str, Any],
        validation: Mapping[str, Any],
        *,
        pack_id: str | None,
        author: str,
        reason: str | None = None,
    ) -> dict[str, Any]:
        return {
            "workspace_id": self.workspace_id,
            "repo_id": self.repo_id,
            "task_session_id": task_session_id,
            "plan_hash": validation["plan_hash"],
            "plan": dict(normalized),
            "validation": _public_validation(validation),
            "metadata": {"pack_id": pack_id} if pack_id else {},
            "author": author,
            "reason": reason,
            "required_verifications": required_verification_names(dict(normalized)),
            "required_contract_items": required_contract_items(dict(normalized)),
            "governed_class": normalized.get("governed_class"),
        }

    def _with_task_acceptance_checklist(
        self, plan: dict[str, Any], task_session_id: str | None
    ) -> dict[str, Any]:
        if plan.get("acceptance_checklist") is not None:
            return plan
        task_text = str(plan.get("objective") or "")
        if task_session_id:
            session = self.store.session(task_session_id)
            metadata = _payload(session).get("metadata") if session is not None else {}
            if isinstance(metadata, Mapping):
                task_text = str(metadata.get("objective") or metadata.get("task") or task_text)
        checklist = extract_named_symbols(task_text)
        checklist_token_estimate = max(0, len(canonical_json(checklist)) // 4)
        if not checklist:
            return {
                **plan,
                "acceptance_checklist": [],
                "checklist_status": "empty",
                "checklist_token_estimate": checklist_token_estimate,
            }
        return {
            **plan,
            "acceptance_checklist": checklist,
            "checklist_status": "populated",
            "checklist_token_estimate": checklist_token_estimate,
        }

    def _upsert_continuation(
        self,
        session: Mapping[str, Any],
        *,
        event: str,
        state: str | None = None,
        next_action: str | None = None,
        blockers: list[str] | None = None,
        reason: str | None = None,
    ) -> dict[str, Any]:
        task_session_id = str(session["task_session_id"])
        payload = _payload(session)
        plan = self.store.latest_plan(task_session_id)
        plan_definition = dict(plan.get("plan") or {}) if plan is not None else {}
        checkpoints = list(self.store.checkpoints(str(plan["plan_id"]))) if plan else []
        completed = [
            str(item.get("step_id"))
            for item in checkpoints
            if item.get("status") == "pass" and item.get("step_id")
        ]
        declared = intended_files(plan_definition) if plan_definition else []
        remaining = [
            str(item.get("id") or item.get("title"))
            for item in plan_definition.get("steps", [])
            if isinstance(item, dict)
            and str(item.get("id") or item.get("title")) not in set(completed)
        ]
        continuation_id = "continuation_" + stable_id(
            self.workspace_id, self.repo_id, task_session_id
        )
        existing = self.store.continuation(continuation_id)
        current_state = state or _continuation_state(str(session["state"]))
        capsule = {
            "continuation_id": continuation_id,
            "task_session_id": task_session_id,
            "objective": (payload.get("metadata") or {}).get("objective")
            or (payload.get("metadata") or {}).get("task")
            or f"Task {task_session_id}",
            "current_state": current_state,
            "plan_id": plan.get("plan_id") if plan else None,
            "pack_id": payload.get("pack_id"),
            "active_step_id": remaining[0] if remaining else None,
            "completed_steps": completed,
            "remaining_steps": remaining,
            "intended_files": declared,
            "changed_files": sorted(
                {
                    str(path)
                    for checkpoint in checkpoints
                    for path in checkpoint.get("changed_paths", [])
                }
            )
            or git_changed_paths(self.repo_root),
            "tests_planned": sorted(
                {
                    str(test)
                    for step in plan_definition.get("steps", [])
                    if isinstance(step, dict)
                    for test in step.get("intended_tests", [])
                }
            ),
            "blockers": list(blockers or []),
            "next_action": next_action
            or (f"Continue step {remaining[0]}." if remaining else "Review task state."),
            "reason": reason or event,
            "source_kind": f"continuation:{event}",
            "base_commit": _git_head(self.repo_root),
            "missing_paths": _missing_paths(self.repo_root, declared),
            "intended_path_hashes_at_write": _path_hashes(self.repo_root, declared),
            "changed_paths_since_base": git_changed_paths(self.repo_root),
            "diff_fingerprint": current_diff_fingerprint(self.repo_root),
            "expires_at": _continuation_expires_at(current_state),
            "staleness": "fresh",
        }
        continuation_status = (
            "active" if current_state in _ACTIVE_CONTINUATION_STATES else "expired"
        )
        return dict(
            self.store.upsert_continuation(
                continuation_id,
                task_session_id=task_session_id,
                task_hash=str(payload.get("task_text_hash") or ""),
                status=continuation_status,
                payload=capsule,
                expected_revision=(int(existing["revision"]) if existing else 0),
                idempotency_key=f"continuation:{event}:{task_session_id}",
            )
        )

    def _mirror_working_memory_note(self, note: Mapping[str, Any]) -> None:
        try:
            self.knowledge.working_memory_note_write(
                {
                    "note_id": str(note["record_id"]),
                    "task_session_id": note.get("task_session_id"),
                    "content": str(note.get("text") or ""),
                    "salience": float(note.get("salience") or 0.5),
                    "metadata": {
                        "cycle_id": note.get("cycle_id"),
                        "note_kind": note.get("note_kind"),
                        "evidence_refs": list(note.get("evidence_refs") or []),
                    },
                    "superseded_by": note.get("superseded_by"),
                    "created_at": note.get("captured_at") or utc_now(),
                    "expires_at": note.get("expires_at"),
                }
            )
        except Exception:
            return

    def _enforce_working_memory_limit(self, task_session_id: str | None) -> None:
        max_notes = max(1, int(getattr(self.settings.reasoning, "working_memory_max_notes", 64)))
        result = self.state_list("working_memory", status="active", limit=1000)
        records = [
            dict(item)
            for item in result.get("records", [])
            if not task_session_id or item.get("task_session_id") == task_session_id
        ]
        if len(records) <= max_notes:
            return
        records.sort(
            key=lambda item: (
                float(item.get("salience") or 0.0),
                str(item.get("captured_at") or ""),
                str(item.get("record_id") or ""),
            )
        )
        for item in records[: len(records) - max_notes]:
            item["status"] = "superseded"
            item["superseded_by"] = "working_memory_limit"
            self.store.put(item, idempotency_key=f"working_memory:supersede:{item['record_id']}")
            self._mirror_working_memory_note(item)

    @staticmethod
    def _plan_response(
        plan: Mapping[str, Any],
        validation: Mapping[str, Any],
        *,
        previous_plan_hash: str | None,
        lifecycle_event: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        return {
            "ok": True,
            "schema_version": "persistmind.task_plan.v1",
            "plan_id": plan["plan_id"],
            "revision_id": f"plan-revision:{plan['plan_id']}:{plan['revision']}",
            "revision_number": plan["revision"],
            "plan_hash": plan.get("plan_hash"),
            "previous_plan_hash": previous_plan_hash,
            "task_session_id": plan["task_session_id"],
            "validation": _public_validation(validation),
            "plan": plan.get("plan", {}),
            "nextgen_v1": True,
            "lifecycle_event_id": (lifecycle_event.get("event_id") if lifecycle_event else None),
            "lifecycle_sequence": (lifecycle_event.get("sequence") if lifecycle_event else None),
        }

    def _ensure_task_owned_agent_session(
        self,
        session: Mapping[str, Any],
        *,
        lifecycle_event: Mapping[str, Any],
    ) -> str:
        """Bind the canonical task-owned session identity without a legacy mirror."""

        task_session_id = str(session["task_session_id"])
        snapshot = self.store.workflow_snapshot(task_session_id)
        agent_session_id = str(
            (snapshot or {}).get("task_owned_agent_session_id")
            or stable_id("persistmind-task-agent-session", task_session_id)
        )
        if not snapshot or not snapshot.get("task_owned_agent_session_id"):
            snapshot_payload = {
                key: value
                for key, value in dict(snapshot or {}).items()
                if key
                not in {
                    "task_session_id",
                    "pack_id",
                    "plan_id",
                    "revision",
                    "updated_at",
                }
            }
            snapshot_payload["task_owned_agent_session_id"] = agent_session_id
            snapshot_payload["task_owned_session_event_id"] = lifecycle_event["event_id"]
            self.store.save_workflow_snapshot(
                task_session_id,
                payload=snapshot_payload,
                pack_id=str((snapshot or {}).get("pack_id") or "") or None,
                plan_id=str((snapshot or {}).get("plan_id") or "") or None,
                expected_revision=int((snapshot or {}).get("revision") or 0),
            )
        return agent_session_id


def _payload(session: Mapping[str, Any] | None) -> dict[str, Any]:
    if session is None:
        return {}
    return {
        key: value
        for key, value in dict(session).items()
        if key not in {"task_session_id", "state", "revision", "created_at", "updated_at"}
    }


def _remediation_attempt_metadata(record: Mapping[str, Any]) -> dict[str, Any]:
    evidence_refs = record.get("evidence_refs")
    if isinstance(evidence_refs, Sequence) and not isinstance(evidence_refs, (str, bytes)):
        for item in evidence_refs:
            if isinstance(item, Mapping):
                return dict(item)
    evidence = record.get("evidence")
    if isinstance(evidence, Sequence) and not isinstance(evidence, (str, bytes)):
        for item in evidence:
            if isinstance(item, Mapping):
                return dict(item)
    return {
        "gate_id": record.get("gate_id"),
        "approach": record.get("approach") or record.get("text"),
        "outcome": record.get("outcome"),
        "command_or_tool": record.get("command_or_tool"),
        "error": record.get("error"),
        "recorded_at": record.get("captured_at"),
        "approach_hash": record.get("approach_hash"),
    }


def _recall_preflight_durable_facts(
    knowledge: Any,
    task: str,
    *,
    paths: Sequence[str],
    limit: int,
) -> dict[str, Any]:
    queries = _preflight_memory_queries(task, paths)
    primary = knowledge.memory_recall(queries[0], paths=paths, limit=limit)
    merged_records = _merge_recall_records(primary.get("records") or [])
    merged_stale = _merge_recall_records(primary.get("stale_records") or [])
    recall_errors: list[dict[str, str]] = []
    for query in queries[1:]:
        try:
            result = knowledge.memory_recall(query, paths=paths, limit=limit)
        except Exception as exc:
            recall_errors.append({"query": query, "error": str(exc)})
            continue
        merged_records = _merge_recall_records(
            [*merged_records.values(), *(result.get("records") or [])]
        )
        merged_stale = _merge_recall_records(
            [*merged_stale.values(), *(result.get("stale_records") or [])]
        )
    selected = sorted(
        merged_records.values(),
        key=lambda item: (-float(item.get("score") or 0.0), str(item.get("record_id") or "")),
    )[: max(1, min(limit, 1000))]
    stale = sorted(
        merged_stale.values(),
        key=lambda item: (-float(item.get("score") or 0.0), str(item.get("record_id") or "")),
    )[: max(1, min(limit, 1000))]
    return {
        **primary,
        "records": selected,
        "items": selected,
        "stale_records": stale,
        "expanded_queries": queries,
        **({"recall_expansion_errors": recall_errors} if recall_errors else {}),
    }


def _merge_recall_records(records: Sequence[Mapping[str, Any]]) -> dict[str, dict[str, Any]]:
    merged: dict[str, dict[str, Any]] = {}
    for record in records:
        record_id = str(record.get("record_id") or "")
        if not record_id:
            continue
        current = merged.get(record_id)
        if current is None or float(record.get("score") or 0.0) > float(
            current.get("score") or 0.0
        ):
            merged[record_id] = dict(record)
    return merged


def _preflight_memory_queries(task: str, paths: Sequence[str]) -> list[str]:
    candidates: list[str] = [task.strip()]
    candidates.extend(_quoted_memory_fragments(task))
    candidates.extend(_identifier_memory_fragments(task))
    candidates.extend(_error_memory_fragments(task))
    for path in paths:
        name = Path(path).name
        stem = Path(path).stem
        if name:
            candidates.append(name)
        if stem and stem != name:
            candidates.append(stem)
    seen: set[str] = set()
    result: list[str] = []
    for candidate in candidates:
        normalized = " ".join(str(candidate).strip().split())
        if len(normalized) < 4:
            continue
        key = normalized.casefold()
        if key in seen:
            continue
        seen.add(key)
        result.append(normalized)
    return result or [task.strip()]


def _quoted_memory_fragments(text: str) -> list[str]:
    fragments: list[str] = []
    for pattern in (r"`([^`]{4,160})`", r'"([^"]{4,160})"', r"'([^']{4,160})'"):
        fragments.extend(match.group(1) for match in re.finditer(pattern, text))
    return fragments


def _identifier_memory_fragments(text: str) -> list[str]:
    return [
        match.group(0)
        for match in re.finditer(
            r"\b[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+\b|"
            r"\b[A-Za-z_][A-Za-z0-9_]{3,}\(\s*\)",
            text,
        )
    ]


def _error_memory_fragments(text: str) -> list[str]:
    fragments: list[str] = []
    pattern = re.compile(
        r"\b(?:error|message|shows|showing|says|still shows)\s+"
        r"([A-Z][A-Za-z0-9_ .,'/-]{8,120})",
        re.IGNORECASE,
    )
    for match in pattern.finditer(text):
        fragment = re.split(r"[.;\n]", match.group(1), maxsplit=1)[0].strip(" ,")
        if fragment:
            fragments.append(fragment)
    return fragments


class _RepairCompiler:
    """Adapt authority pack compilation to VerificationRunner's repair contract."""

    def __init__(
        self,
        repo_root: Path,
        *,
        allow_development_driver: bool,
        task_text: str,
    ) -> None:
        self.repo_root = repo_root
        self.allow_development_driver = allow_development_driver
        self.task_text = task_text

    def compile(
        self,
        *,
        snapshot: Any,
        task: str,
        seed_paths: list[str],
        write: bool,
    ) -> dict[str, Any]:
        del snapshot, write
        from persistmind.storage.pack_service import PackService

        with PackService(
            self.repo_root,
            allow_development_driver=self.allow_development_driver,
        ) as packs:
            return packs.get_context_pack(
                f"{self.task_text}\n\n{task}",
                seed_paths=seed_paths,
            )


def _workflow_gate_ids(recommendation: Mapping[str, Any]) -> list[str]:
    return [
        str(item.get("gate_id") if isinstance(item, Mapping) else item)
        for item in recommendation.get("gates", [])
    ]


def _typed_verification_gate_status(
    verifications: Iterable[Mapping[str, Any]],
    *,
    expected_type: str,
    task_session_id: str,
    session: Mapping[str, Any],
    plan: Mapping[str, Any] | None,
    revision: Mapping[str, Any] | None,
    diff_fingerprint: Mapping[str, Any],
) -> tuple[str, list[str], list[dict[str, Any]]]:
    if plan is None or revision is None or not session.get("pack_id"):
        return "pending", [], []
    validation = dict(revision.get("validation") or {})
    impact = dict(validation.get("impact_report") or {})
    source_view = {
        "snapshot_id": impact.get("snapshot_id"),
        "generation_id": impact.get("source_generation_id"),
        "fingerprint": impact.get("source_index_fingerprint"),
    }
    rejected: list[dict[str, Any]] = []
    for item in verifications:
        typed = item.get("typed_evidence")
        qualifies, reason = evidence_qualifies(
            typed if isinstance(typed, Mapping) else None,
            expected_type=expected_type,
            task_session_id=task_session_id,
            pack_id=str(session["pack_id"]),
            plan_id=str(plan["plan_id"]),
            plan_revision_id=str(revision["revision_id"]),
            scope_revision_id=str(revision["revision_id"]),
            source_view=source_view,
            diff_fingerprint=diff_fingerprint,
        )
        if qualifies and isinstance(typed, Mapping):
            return "pass", [str(typed["evidence_id"])], rejected
        if isinstance(typed, Mapping):
            rejected.append(
                {
                    "verification_id": item.get("verification_id"),
                    "evidence_id": typed.get("evidence_id"),
                    "evidence_type": typed.get("evidence_type"),
                    "reason": reason,
                }
            )
    return ("stale" if rejected else "pending"), [], rejected


def _workflow_next_action(
    recommendation: Mapping[str, Any],
    gate_status: Mapping[str, Mapping[str, Any]],
    pending: list[str],
) -> dict[str, Any] | None:
    if not pending:
        return None
    gate_id = pending[0]
    feature_id = {
        "preflight_ready": "pack",
        "plan_active": "plan",
        "checkpoints_present": "checkpoint",
        "check_diff_clean": "check_diff",
        "dirty_set_in_scope": "check_diff",
        "tests_pass": "tests",
        "outcome_recorded": "outcome",
        "security_scan_pass": "security_scan",
        "release_validated": "release_validate",
    }.get(gate_id, gate_id)
    features = list(recommendation.get("required_features", [])) + list(
        recommendation.get("optional_features", [])
    )
    for feature in features:
        if isinstance(feature, Mapping) and feature.get("feature_id") == feature_id:
            action = dict(feature)
            action.update(
                {
                    "gate_id": gate_id,
                    "gate_status": dict(gate_status.get(gate_id, {})),
                    "blocked": gate_status.get(gate_id, {}).get("status")
                    in {"fail", "unverified"},
                }
            )
            return action
    return {
        "feature_id": feature_id,
        "gate_id": gate_id,
        "command": None,
        "why": f"Resolve pending gate {gate_id}",
        "gate_status": dict(gate_status.get(gate_id, {})),
        "blocked": gate_status.get(gate_id, {}).get("status") in {"fail", "unverified"},
    }


def _workflow_has_blocking_gate(gate_status: Mapping[str, Mapping[str, Any]]) -> bool:
    return any(
        gate.get("status") in {"fail", "unverified"}
        for gate in gate_status.values()
        if isinstance(gate, Mapping)
    )


def _task_lifecycle_lightweight(
    settings: Any,
    repo_root: Path,
    explicit_paths: Sequence[str] | None = None,
    plan_document: Mapping[str, Any] | None = None,
) -> bool:
    config = getattr(settings, "task_lifecycle", None)
    if str(getattr(config, "mode", "full")) != "lightweight":
        return False
    paths = {str(path).replace("\\", "/") for path in explicit_paths or [] if str(path).strip()}
    if not paths:
        try:
            from persistmind.git_utils import git_changed_paths

            paths = {str(path).replace("\\", "/") for path in git_changed_paths(repo_root)}
        except Exception:
            paths = set()
    steps = [
        dict(step)
        for step in (plan_document or {}).get("steps", [])
        if isinstance(step, Mapping)
    ]
    risks = tuple(str(step.get("risk") or "").strip().lower() for step in steps)
    permits = getattr(config, "permits_lightweight", None)
    if callable(permits):
        return bool(
            permits(
                changed_paths_count=len(paths),
                step_count=len(steps),
                step_risks=risks,
            )
        )
    threshold = max(0, int(getattr(config, "lightweight_max_changed_paths", 1)))
    return len(paths) <= threshold


def _allowed_transition(current: str, target: str) -> bool:
    return current == target or TASK_STATES.index(target) == TASK_STATES.index(current) + 1


_ACTIVE_CONTINUATION_STATES = {
    "intake",
    "packed",
    "planned",
    "editing",
    "checking",
    "blocked",
    "ready_to_resume",
}


def _continuation_state(task_state: str) -> str:
    return {
        "INTAKE": "intake",
        "PACK": "packed",
        "PLAN": "planned",
        "EXECUTE": "editing",
        "PREFLIGHT": "checking",
        "OUTCOME": "completed",
    }.get(task_state, "ready_to_resume")


def _git_head(repo_root: Path) -> str | None:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_root,
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=5,
        )
    except (subprocess.SubprocessError, FileNotFoundError):
        return None
    return result.stdout.strip() or None


def _missing_paths(repo_root: Path, paths: Sequence[str]) -> list[str]:
    missing: list[str] = []
    for raw in paths:
        path = str(raw).replace("\\", "/").lstrip("./")
        if path and not (repo_root / path).exists():
            missing.append(path)
    return sorted(missing)


def _continuation_expires_at(current_state: str) -> str | None:
    if current_state in _ACTIVE_CONTINUATION_STATES:
        return None
    return utc_now()


def _continuation_payload(value: Mapping[str, Any]) -> dict[str, Any]:
    return {
        key: item
        for key, item in dict(value).items()
        if key
        not in {
            "continuation_id",
            "task_session_id",
            "task_hash",
            "status",
            "revision",
            "created_at",
            "updated_at",
        }
    }


def _public_continuation(value: Mapping[str, Any]) -> dict[str, Any]:
    return {
        **_continuation_payload(value),
        "continuation_id": value["continuation_id"],
        "record_id": value["continuation_id"],
        "task_session_id": value["task_session_id"],
        "status": value["status"],
        "revision": value["revision"],
        "score": 1.0,
    }


def _continuation_staleness(repo_root: Path, continuation: Mapping[str, Any]) -> dict[str, Any]:
    missing_paths = _missing_paths(repo_root, _as_string_list(continuation.get("intended_files")))
    current_changed_paths = git_changed_paths(repo_root)
    relevant_paths = set(_as_string_list(continuation.get("intended_files"))) | set(
        _as_string_list(continuation.get("changed_files"))
    )
    relevant_changed_paths = (
        [path for path in current_changed_paths if path in relevant_paths]
        if relevant_paths
        else current_changed_paths
    )
    current_diff = current_diff_fingerprint(repo_root)
    stored_diff = continuation.get("diff_fingerprint")
    stored_diff_key = canonical_json(stored_diff) if stored_diff else ""
    current_diff_key = canonical_json(current_diff) if current_diff else ""
    changed_since_write = sorted(
        set(current_changed_paths)
        - set(_as_string_list(continuation.get("changed_paths_since_base")))
    )
    reasons: list[str] = []
    expires_at = _parse_iso_time(continuation.get("expires_at"))
    now = _parse_iso_time(utc_now())
    if expires_at and now and expires_at <= now:
        reasons.append("ttl_expired")
    if missing_paths:
        reasons.append("intended_file_deleted")
    stored_hashes = {
        str(key): str(value)
        for key, value in dict(continuation.get("intended_path_hashes_at_write") or {}).items()
    }
    current_hashes = _path_hashes(repo_root, stored_hashes.keys())
    changed_hash_paths = sorted(
        path
        for path, stored_hash in stored_hashes.items()
        if current_hashes.get(path) not in {None, stored_hash}
    )
    if changed_hash_paths:
        reasons.append("intended_file_changed")
    if stored_diff_key and current_diff_key and stored_diff_key != current_diff_key and relevant_changed_paths:
        reasons.append("working_tree_changed")
    if changed_since_write:
        reasons.append("changed_paths_since_write")
    state = "fresh"
    if "ttl_expired" in reasons:
        state = "expired"
    elif reasons:
        state = "stale"
    return {
        "staleness": state,
        "staleness_state": state,
        "staleness_reasons": sorted(set(reasons)),
        "staleness_diagnostics": {
            "base_commit": continuation.get("base_commit"),
            "current_head": _git_head(repo_root),
            "stored_diff_fingerprint": stored_diff or None,
            "current_diff_fingerprint": current_diff,
            "missing_paths": missing_paths,
            "changed_intended_files": changed_hash_paths,
            "intended_path_hashes_at_write": stored_hashes,
            "intended_path_hashes_current": current_hashes,
            "changed_paths_since_base": current_changed_paths,
            "relevant_changed_paths": relevant_changed_paths,
            "changed_paths_since_write": changed_since_write,
            "expires_at": continuation.get("expires_at"),
        },
        "missing_paths": missing_paths,
        "changed_paths_since_base": current_changed_paths,
        "diff_fingerprint": current_diff,
    }


def _parse_iso_time(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed


def _as_string_list(value: Any) -> list[str]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Iterable):
        return []
    return [str(item).replace("\\", "/").lstrip("./") for item in value if str(item).strip()]


def _path_hashes(repo_root: Path, paths: Iterable[str]) -> dict[str, str]:
    hashes: dict[str, str] = {}
    for raw_path in paths:
        normalized = str(raw_path).replace("\\", "/").lstrip("./")
        if not normalized:
            continue
        candidate = (repo_root / normalized).resolve()
        try:
            candidate.relative_to(repo_root)
        except ValueError:
            continue
        try:
            hashes[normalized] = sha256_text(candidate.read_text(encoding="utf-8", errors="replace"))
        except OSError:
            hashes[normalized] = "missing"
    return hashes


def _public_validation(value: Mapping[str, Any]) -> dict[str, Any]:
    return {key: item for key, item in value.items() if key != "normalized_plan"}


def _canonicalize_plan_scopes(
    plan: dict[str, Any],
    repo_root: Path,
    *,
    source_plan: Mapping[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Canonicalize plan paths before any authority subsystem can inspect them."""

    errors: list[dict[str, Any]] = []
    for step_index, step in enumerate(plan.get("steps", [])):
        if not isinstance(step, dict):
            continue
        accepted: list[str] = []
        scopes = step.get("intended_files", [])
        if not isinstance(scopes, list):
            continue
        for scope_index, scope in enumerate(scopes):
            field = (
                _source_scope_field(source_plan, step_index=step_index, normalized_scope=str(scope))
                or f"steps[{step_index}].intended_files[{scope_index}]"
            )
            try:
                canonical, is_directory = canonical_repo_scope(str(scope), repo_root)
            except ValueError:
                errors.append(
                    {
                        "type": "schema_error",
                        "code": "plan_path_outside_repository",
                        "path": field,
                        "message": "path is outside the governed repository",
                        "blocking": True,
                    }
                )
                continue
            accepted.append(f"{canonical}/" if is_directory else canonical)
        step["intended_files"] = sorted(set(accepted))
    return errors


def _source_scope_field(
    source_plan: Mapping[str, Any] | None,
    *,
    step_index: int,
    normalized_scope: str,
) -> str | None:
    if not isinstance(source_plan, Mapping):
        return None
    source_steps = source_plan.get("steps")
    if not isinstance(source_steps, list) or step_index >= len(source_steps):
        return None
    source_step = source_steps[step_index]
    if not isinstance(source_step, Mapping):
        return None
    field_name = (
        "intended_files"
        if "intended_files" in source_step
        else "files"
        if "files" in source_step
        else ""
    )
    source_scopes = source_step.get(field_name) if field_name else None
    if not isinstance(source_scopes, list):
        return None
    for scope_index, source_scope in enumerate(source_scopes):
        if (
            isinstance(source_scope, str)
            and normalize_repo_relative_path(source_scope) == normalized_scope
        ):
            return f"steps[{step_index}].{field_name}[{scope_index}]"
    return None


def _policy_applies(policy: Mapping[str, Any], paths: list[str]) -> bool:
    patterns = policy.get("path_globs") or policy.get("scope_refs") or ["**"]
    if isinstance(patterns, str):
        patterns = [patterns]
    if not paths:
        return True
    return any(
        fnmatch.fnmatch(path.replace("\\", "/"), str(pattern).replace("\\", "/"))
        for path in paths
        for pattern in patterns
    )


def _task_risk_index(value: str) -> int:
    risks = ("low", "medium", "high", "critical")
    normalized = value.strip().lower()
    if normalized not in risks:
        raise ValueError(f"invalid task risk class: {value}")
    return risks.index(normalized)


def _validate_task_dag(nodes: Sequence[Mapping[str, Any]]) -> None:
    identifiers = [str(item.get("node_id") or "") for item in nodes]
    if not identifiers or any(not item for item in identifiers):
        raise ValueError("orchestration requires non-empty node identifiers")
    if len(set(identifiers)) != len(identifiers):
        raise ValueError("orchestration node identifiers must be unique")
    known = set(identifiers)
    dependencies = {
        str(item["node_id"]): {str(value) for value in item.get("dependencies", [])}
        for item in nodes
    }
    unknown = sorted(
        {dependency for values in dependencies.values() for dependency in values} - known
    )
    if unknown:
        raise ValueError(f"orchestration dependencies are unknown: {unknown}")
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(node_id: str) -> None:
        if node_id in visiting:
            raise ValueError("orchestration graph contains a dependency cycle")
        if node_id in visited:
            return
        visiting.add(node_id)
        for dependency in dependencies[node_id]:
            visit(dependency)
        visiting.remove(node_id)
        visited.add(node_id)

    for identifier in identifiers:
        visit(identifier)


__all__ = ["TASK_STATES", "TaskConflict", "TaskService"]
