from __future__ import annotations

import ctypes
import os
import stat
from dataclasses import dataclass
from pathlib import Path


_WINDOWS_DRIVE_TYPES = {2: "removable", 3: "fixed", 4: "network", 5: "optical", 6: "ramdisk"}
_LOCAL_LINUX_FILESYSTEMS = frozenset(
    {"btrfs", "ext2", "ext3", "ext4", "f2fs", "overlay", "tmpfs", "xfs", "zfs"}
)
_REMOTE_LINUX_FILESYSTEMS = frozenset(
    {"9p", "afs", "cifs", "fuse.sshfs", "gcsfuse", "nfs", "nfs4", "smb3"}
)


@dataclass(frozen=True, slots=True)
class LocalPathClassification:
    path: Path
    classification: str
    filesystem: str
    safe_for_live_state: bool
    reason: str


def require_local_live_state_path(path: Path) -> LocalPathClassification:
    result = classify_live_state_path(path)
    if not result.safe_for_live_state:
        raise ValueError(
            f"live PersistMind state requires a verified local path: {result.path} "
            f"({result.classification}: {result.reason}). Move or rebind the workspace to a "
            "local fixed/removable volume; use the current path only as an export destination."
        )
    return result


def classify_live_state_path(path: Path) -> LocalPathClassification:
    candidate = Path(path).absolute()
    lexical = str(candidate).replace("\\", "/")
    if lexical.startswith("//"):
        return _result(candidate, "network", "unc", False, "UNC paths are remote")
    synced = _synchronized_root(candidate)
    if synced:
        return _result(candidate, "cloud_synchronized", "sync-root", False, synced)
    current = candidate
    while not current.exists() and current != current.parent:
        current = current.parent
    try:
        resolved = current.resolve(strict=True)
    except OSError as exc:
        return _result(candidate, "unknown", "unresolved", False, str(exc))
    for ancestor in (resolved, *resolved.parents):
        try:
            details = ancestor.lstat()
        except OSError as exc:
            return _result(candidate, "unknown", "unresolved", False, str(exc))
        attributes = int(getattr(details, "st_file_attributes", 0))
        reparse = int(getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
        if stat.S_ISLNK(details.st_mode) or attributes & reparse:
            return _result(
                candidate,
                "redirected",
                "symlink-or-reparse",
                False,
                f"path ancestor is redirected: {ancestor}",
            )
    if os.name == "nt":
        root = Path(candidate.anchor or resolved.anchor)
        drive_type = int(ctypes.windll.kernel32.GetDriveTypeW(str(root)))  # type: ignore[attr-defined]
        name = _WINDOWS_DRIVE_TYPES.get(drive_type, "unknown")
        safe = name in {"fixed", "removable", "ramdisk"}
        return _result(
            candidate,
            name if safe else "network" if name == "network" else "unknown",
            name,
            safe,
            "verified Windows volume type" if safe else "unsupported Windows volume type",
        )
    filesystem = _linux_filesystem(resolved)
    if filesystem in _REMOTE_LINUX_FILESYSTEMS:
        return _result(candidate, "network", filesystem, False, "remote filesystem type")
    if filesystem in _LOCAL_LINUX_FILESYSTEMS:
        return _result(candidate, "local", filesystem, True, "verified local filesystem type")
    return _result(candidate, "unknown", filesystem or "unknown", False, "unclassified filesystem")


def _synchronized_root(path: Path) -> str | None:
    roots = []
    for name in ("OneDrive", "OneDriveCommercial", "OneDriveConsumer", "GOOGLE_DRIVE", "DROPBOX"):
        value = os.environ.get(name)
        if value:
            roots.append((name, Path(value).absolute()))
    for name, root in roots:
        try:
            if path.is_relative_to(root):
                return f"path is under {name}"
        except (OSError, ValueError):
            return f"unable to verify synchronization boundary for {name}"
    folded = "/" + str(path).replace("\\", "/").casefold().strip("/") + "/"
    for marker in ("/google drive/", "/my drive/", "/onedrive/", "/dropbox/"):
        if marker in folded:
            return f"path contains known synchronized-root marker {marker.strip('/')}"
    return None


def _linux_filesystem(path: Path) -> str | None:
    mountinfo = Path("/proc/self/mountinfo")
    if not mountinfo.is_file():
        return None
    best: tuple[int, str] | None = None
    for line in mountinfo.read_text(encoding="utf-8", errors="replace").splitlines():
        fields = line.split()
        if "-" not in fields:
            continue
        separator = fields.index("-")
        if separator + 1 >= len(fields) or len(fields) < 5:
            continue
        mount = Path(fields[4].replace("\\040", " "))
        try:
            if path.is_relative_to(mount):
                choice = (len(str(mount)), fields[separator + 1])
                if best is None or choice[0] > best[0]:
                    best = choice
        except ValueError:
            continue
    return best[1] if best else None


def _result(
    path: Path, classification: str, filesystem: str, safe: bool, reason: str
) -> LocalPathClassification:
    return LocalPathClassification(path, classification, filesystem, safe, reason)


__all__ = [
    "LocalPathClassification",
    "classify_live_state_path",
    "require_local_live_state_path",
]
