from __future__ import annotations

import time
from collections import OrderedDict
from collections.abc import Hashable
from dataclasses import dataclass
from typing import Generic, TypeVar

T = TypeVar("T")


@dataclass(slots=True)
class _Entry(Generic[T]):
    value: T
    revision: Hashable
    expires_at: float


class RevisionCache(Generic[T]):
    def __init__(self, *, max_entries: int = 256, ttl_seconds: float = 5.0) -> None:
        self.max_entries, self.ttl_seconds = max_entries, ttl_seconds
        self._entries: OrderedDict[Hashable, _Entry[T]] = OrderedDict()

    def get(self, key: Hashable, *, revision: Hashable) -> T | None:
        entry = self._entries.get(key)
        if not entry or entry.revision != revision or entry.expires_at < time.monotonic():
            self._entries.pop(key, None)
            return None
        self._entries.move_to_end(key)
        return entry.value

    def put(self, key: Hashable, value: T, *, revision: Hashable) -> None:
        self._entries[key] = _Entry(value, revision, time.monotonic() + self.ttl_seconds)
        self._entries.move_to_end(key)
        while len(self._entries) > self.max_entries:
            self._entries.popitem(last=False)

    def invalidate(self) -> None:
        self._entries.clear()
