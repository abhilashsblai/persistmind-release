from __future__ import annotations

import json
import hashlib
import os
import secrets
import time
from contextlib import contextmanager
from pathlib import Path

from .adapters.sqlite_activity import SQLiteActivityStore, SQLiteAuditStore
from .adapters.sqlite_control import SQLiteControlStore
from .adapters.sqlite_knowledge import SQLiteKnowledgeStore
from .adapters.sqlite_learning import SQLiteLearningStore
from .adapters.sqlite_policy import SQLitePolicyStore
from .adapters.sqlite_source import SQLiteSourceStore
from .adapters.sqlite_task import SQLiteTaskStore
from .catalog import FileCatalog
from .descriptors import StoreRole, TopologyManifest
from .resources import load_topology


_REQUIRED_ACTIVE_ROLES = frozenset(
    {
        StoreRole.SOURCE_MANIFEST,
        StoreRole.CONTROL,
        StoreRole.TASK_STATE,
        StoreRole.ACTIVITY_ACTIVE,
        StoreRole.AUDIT_ACTIVE,
        StoreRole.KNOWLEDGE,
        StoreRole.POLICY,
        StoreRole.LEARNING,
    }
)


def bootstrap_nextgen(
    root: Path,
    *,
    activate: bool = False,
    allow_development_driver: bool = False,
    project_state_protocol: int = 1,
) -> TopologyManifest:
    """Initialize the normative PersistMind next-generation layout.

    Bootstrap is intentionally the only operation here that creates directories
    or files.  Discovery/status paths use ``FileCatalog`` directly and must not
    call this function.
    """

    if project_state_protocol not in {1, 2}:
        raise ValueError("authority bootstrap supports project-state protocol 1 or 2")
    root = root.resolve()
    catalog = FileCatalog(root / "catalog")
    if catalog.current_path.exists():
        manifest = catalog.current()
        validate_nextgen_manifest(manifest)
        return manifest
    root.mkdir(parents=True, exist_ok=True)
    with _bootstrap_lock(root):
        # A concurrent bootstrap may have committed while this process waited.
        if catalog.current_path.exists():
            manifest = catalog.current()
            validate_nextgen_manifest(manifest)
            return manifest
        template = load_topology("persistmind-nextgen-v1")
        validate_nextgen_manifest(template)
        _materialize_layout(root)
        for descriptor in template.stores:
            adapter = _ADAPTERS[descriptor.store_role]
            with adapter(
                catalog.resolve_location(descriptor.location),
                descriptor=descriptor,
                allow_development_driver=allow_development_driver,
            ) as store:
                if descriptor.store_role is StoreRole.CONTROL:
                    manifest_json = json.dumps(
                        template.to_dict(),
                        sort_keys=True,
                        separators=(",", ":"),
                    )
                    store.connection.execute(
                        "INSERT OR IGNORE INTO topology_generations("
                        "generation,topology_id,manifest_json,manifest_hash,state,"
                        "created_at,activated_at) VALUES(?,?,?,?,?,?,?)",
                        (
                            template.generation,
                            template.topology_id,
                            manifest_json,
                            hashlib.sha256(manifest_json.encode()).hexdigest(),
                            "active",
                            time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                            time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                        ),
                    )
        if activate:
            catalog.initialize(template)
            if project_state_protocol == 2:
                (root / "protocol.json").write_text(
                    json.dumps(
                        {
                            "schema_version": "persistmind.project_state_protocol.v2",
                            "protocol_version": 2,
                            "engine_version": "fresh-bootstrap",
                            "migration_id": "fresh-bootstrap",
                            "activated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                        },
                        sort_keys=True,
                        separators=(",", ":"),
                    ),
                    encoding="utf-8",
                )
        else:
            # Dark bootstrap remains inspectable only as files; it has no catalog
            # pointer and therefore cannot accidentally become a runtime target.
            (root / "operations" / "bootstrap-prepared.json").write_text(
                json.dumps(
                    {
                        "schema_version": "persistmind.bootstrap_prepared.v1",
                        "topology_id": template.topology_id,
                    },
                    sort_keys=True,
                    separators=(",", ":"),
                ),
                encoding="utf-8",
            )
        return template


def validate_nextgen_manifest(manifest: TopologyManifest) -> None:
    if (
        manifest.profile != "persistmind-nextgen-v1"
        or manifest.topology_id != "persistmind-nextgen-v1"
    ):
        raise ValueError("bootstrap requires the PersistMind next-generation topology")
    active = [item for item in manifest.stores if item.state == "active" and not item.read_only]
    roles = [item.store_role for item in active]
    if len(active) != 8 or set(roles) != _REQUIRED_ACTIVE_ROLES or len(set(roles)) != 8:
        raise ValueError(
            "PersistMind next-generation storage requires exactly eight writable roles; got "
            + ", ".join(sorted(role.value for role in roles))
        )
    for descriptor in active:
        if descriptor.store_role not in _ADAPTERS:
            raise ValueError(f"no adapter for role: {descriptor.store_role.value}")


_ADAPTERS = {
    StoreRole.CONTROL: SQLiteControlStore,
    StoreRole.SOURCE_MANIFEST: SQLiteSourceStore,
    StoreRole.TASK_STATE: SQLiteTaskStore,
    StoreRole.ACTIVITY_ACTIVE: SQLiteActivityStore,
    StoreRole.AUDIT_ACTIVE: SQLiteAuditStore,
    StoreRole.KNOWLEDGE: SQLiteKnowledgeStore,
    StoreRole.POLICY: SQLitePolicyStore,
    StoreRole.LEARNING: SQLiteLearningStore,
}


def _materialize_layout(root: Path) -> None:
    for relative in (
        "catalog/generations",
        "catalog/publications",
        "operations",
        "locks",
        "runtime",
        "anchors/audit",
        "objects/.staging",
        "objects/sha256",
        "quarantine",
        "backups/.staging",
        "stores/source/default/segments",
        "stores/control",
        "stores/task",
        "stores/knowledge",
        "stores/learning",
        "stores/audit/sealed",
        "stores/policy",
        "stores/activity/sealed",
    ):
        (root / relative).mkdir(parents=True, exist_ok=True)


@contextmanager
def _bootstrap_lock(root: Path, *, timeout_seconds: float = 10.0):
    """A creation lock that never guesses staleness from mtime or PID age."""

    path = root / "locks" / "bootstrap.lock"
    path.parent.mkdir(parents=True, exist_ok=True)
    deadline = time.monotonic() + timeout_seconds
    descriptor: int | None = None
    while descriptor is None:
        try:
            descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    f"authority bootstrap lock is held; refusing to infer stale ownership: {path}"
                )
            time.sleep(0.05)
    try:
        record = {
            "nonce": secrets.token_hex(32),
            "operation": "bootstrap",
            "pid": os.getpid(),
            "schema_version": "persistmind.storage_lock.v1",
        }
        os.write(descriptor, json.dumps(record, sort_keys=True).encode("utf-8"))
        os.fsync(descriptor)
        yield
    finally:
        os.close(descriptor)
        path.unlink(missing_ok=True)
