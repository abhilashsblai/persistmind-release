from __future__ import annotations

import hashlib
import json
import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from persistmind.retrieval.embedder import LocalHashEmbedder, SentenceTransformerEmbedder

MODEL_ID = "sentence-transformers/all-MiniLM-L6-v2"
MODEL_REVISION = "c9745ed1d9f207416be6d2e6f8de32d1f16199bf"
MODEL_DIMENSIONS = 384


@dataclass(frozen=True, slots=True)
class VerifiedModelBundle:
    root: Path
    manifest: dict[str, Any]
    fingerprint: str


def bundle_path(workspace_root: Path) -> Path:
    return workspace_root.resolve() / "models" / "all-MiniLM-L6-v2" / MODEL_REVISION


def verify_model_bundle(root: Path) -> VerifiedModelBundle:
    root = root.resolve()
    try:
        manifest_bytes = (root / "manifest.json").read_bytes()
        manifest = json.loads(manifest_bytes)
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError("MiniLM bundle manifest is unreadable") from exc
    if (
        not isinstance(manifest, dict)
        or manifest.get("schema_version") != "persistmind.model_bundle.v1"
        or manifest.get("model_id") != MODEL_ID
        or manifest.get("revision") != MODEL_REVISION
        or int(manifest.get("dimensions", 0)) != MODEL_DIMENSIONS
        or not isinstance(manifest.get("files"), list)
    ):
        raise RuntimeError("MiniLM bundle identity is invalid")
    verified = []
    for item in manifest["files"]:
        if not isinstance(item, dict):
            raise RuntimeError("MiniLM bundle file manifest is invalid")
        relative = Path(str(item.get("path", "")))
        path = (root / relative).resolve()
        if not relative.parts or path == root or not path.is_relative_to(root):
            raise RuntimeError("MiniLM bundle path escapes its root")
        if path.is_symlink() or not path.is_file():
            raise RuntimeError(f"MiniLM bundle file is missing: {relative.as_posix()}")
        digest = _sha256(path)
        if digest != item.get("sha256") or path.stat().st_size != int(item.get("bytes", -1)):
            raise RuntimeError(f"MiniLM bundle file checksum mismatch: {relative.as_posix()}")
        verified.append((relative.as_posix(), digest))
    fingerprint = hashlib.sha256(json.dumps(verified, separators=(",", ":")).encode()).hexdigest()
    if manifest.get("bundle_fingerprint") != fingerprint:
        raise RuntimeError("MiniLM bundle fingerprint mismatch")
    return VerifiedModelBundle(root=root, manifest=manifest, fingerprint=fingerprint)


def install_model_bundle(workspace_root: Path, source: Path) -> VerifiedModelBundle:
    verified = verify_model_bundle(source)
    target = bundle_path(workspace_root)
    if target.exists():
        current = verify_model_bundle(target)
        if current.fingerprint == verified.fingerprint:
            return current
        raise FileExistsError("a different MiniLM bundle is already installed")
    staging = target.with_name(f".{target.name}.staging-{os.getpid()}")
    try:
        staging.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(verified.root, staging)
        installed = verify_model_bundle(staging)
        os.replace(staging, target)
        return VerifiedModelBundle(target, installed.manifest, installed.fingerprint)
    finally:
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)


def source_embedder(workspace_root: Path):
    try:
        bundle = verify_model_bundle(bundle_path(workspace_root))
    except RuntimeError:
        return LocalHashEmbedder(
            model_name="local-fallback-for:" + MODEL_ID,
            requested_backend="auto",
            degraded_reason="pinned_minilm_bundle_unavailable",
        )
    try:
        return SentenceTransformerEmbedder(
            model_name=MODEL_ID + "@" + MODEL_REVISION,
            model_path=bundle.root,
            requested_backend="auto",
        )
    except RuntimeError:
        return LocalHashEmbedder(
            model_name="local-fallback-for:" + MODEL_ID,
            requested_backend="auto",
            degraded_reason="pinned_minilm_runtime_unavailable",
        )


def model_status(workspace_root: Path) -> dict[str, Any]:
    try:
        bundle = verify_model_bundle(bundle_path(workspace_root))
    except RuntimeError as exc:
        return {
            "installed": False,
            "verified": False,
            "model_id": MODEL_ID,
            "revision": MODEL_REVISION,
            "dimensions": MODEL_DIMENSIONS,
            "reason": str(exc),
        }
    return {
        "installed": True,
        "verified": True,
        "model_id": MODEL_ID,
        "revision": MODEL_REVISION,
        "dimensions": MODEL_DIMENSIONS,
        "fingerprint": bundle.fingerprint,
        "path": str(bundle.root),
    }


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()
