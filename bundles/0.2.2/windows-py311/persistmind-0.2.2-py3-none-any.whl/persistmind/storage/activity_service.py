from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any, cast

from persistmind.application.task_envelope import resolution_satisfies_gate
from persistmind.config import load_settings
from persistmind.telemetry.token_accounting import (
    AGENT_LEG,
    TOKEN_USAGE_EVENT_TYPE,
    build_token_report,
    read_host_transcript_usage,
    render_token_report,
    served_entry,
    token_entry,
)
from persistmind.utils import canonical_json, stable_id, utc_now

from .adapters.sqlite_activity import SQLiteActivityStore, SQLiteAuditStore, _redact
from .adapters.sqlite_task import SQLiteTaskStore
from .descriptors import StoreCapabilities, StoreDescriptor, StoreRole
from .events import EventLedger, StorageEvent
from .reconcile import reconcile
from .runtime import StorageOpenIntent, StorageRuntime, resolve_runtime_store
from .topology_service import publish_topology
from .workflow_lifecycle import WorkflowLifecycleCoordinator

OUTCOME_RESULTS = ("pass", "fail", "partial", "cancelled")


class ActivityService:
    """Typed operational events and task-backed outcomes for persistmind-nextgen-v1."""

    def __init__(
        self,
        repo_root: Path,
        *,
        allow_development_driver: bool = False,
        runtime: StorageRuntime | None = None,
        read_only: bool = False,
    ) -> None:
        self.repo_root = repo_root.resolve()
        settings = load_settings(self.repo_root)
        self._owns_runtime = runtime is None
        self.runtime = runtime or StorageRuntime.open(
            self.repo_root / settings.toolchain.workspace_dir,
            intent=StorageOpenIntent.REQUIRE_INITIALIZED,
            allow_development_driver=allow_development_driver,
            read_only=read_only,
            required_roles=frozenset(
                {
                    StoreRole.ACTIVITY_ACTIVE,
                    StoreRole.ACTIVITY_SEALED,
                    StoreRole.TASK_STATE,
                    StoreRole.AUDIT_ACTIVE,
                    StoreRole.KNOWLEDGE,
                    StoreRole.POLICY,
                    StoreRole.LEARNING,
                    *(() if read_only else (StoreRole.CONTROL,)),
                }
            ),
        )
        activity = resolve_runtime_store(
            self.runtime, StoreRole.ACTIVITY_ACTIVE, read_only=read_only
        )
        task = resolve_runtime_store(self.runtime, StoreRole.TASK_STATE, read_only=read_only)
        audit = resolve_runtime_store(self.runtime, StoreRole.AUDIT_ACTIVE, read_only=read_only)
        if (
            not isinstance(activity, SQLiteActivityStore)
            or not isinstance(task, SQLiteTaskStore)
            or not isinstance(audit, SQLiteAuditStore)
        ):
            raise RuntimeError("Activity routes did not resolve to role-scoped SQLite stores")
        self.store = activity
        self.task_store = task
        self.audit_store = audit
        self._outbox: EventLedger | None = None
        self.lifecycle = WorkflowLifecycleCoordinator(
            self.repo_root,
            allow_development_driver=allow_development_driver,
            runtime=self.runtime,
        )

    def close(self) -> None:
        if self._owns_runtime:
            self.runtime.close()

    @property
    def outbox(self) -> EventLedger:
        if self._outbox is None:
            self._outbox = EventLedger(cast(Any, self.task_store.connection))
        return self._outbox

    def __enter__(self) -> ActivityService:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def append_event(
        self,
        event_type: str,
        payload: Mapping[str, Any],
        *,
        idempotency_key: str | None = None,
        event_id: str | None = None,
        occurred_at: str | None = None,
        classification: str = "internal",
    ) -> dict[str, Any]:
        normalized_type = event_type.strip().lower().replace(" ", "_")
        if not normalized_type or len(normalized_type) > 128:
            raise ValueError("activity event_type is required and limited to 128 characters")
        redacted = _redact(dict(payload))
        encoded = canonical_json(redacted).encode("utf-8")
        stored_payload: dict[str, Any]
        object_ref: str | None = None
        if len(encoded) > 48 * 1024:
            object_ref = self.runtime.artifacts.put(encoded, classification=classification)
            stored_payload = {
                "object_ref": object_ref,
                "logical_bytes": len(encoded),
                "content_hash": object_ref.removeprefix("sha256:"),
            }
        else:
            stored_payload = redacted
        identity = (
            event_id
            or "event_"
            + stable_id(
                "activity", normalized_type, occurred_at or "", canonical_json(stored_payload)
            )[:32]
        )
        key = idempotency_key or f"activity:{identity}"
        stored = self.store.append(
            {
                "event_id": identity,
                "event_type": normalized_type,
                "occurred_at": occurred_at or utc_now(),
                "payload": stored_payload,
            },
            idempotency_key=key,
        )
        return {
            "ok": True,
            "schema_version": "persistmind.activity_event.v1",
            "event_id": stored,
            "event_type": normalized_type,
            "object_ref": object_ref,
            "nextgen_v1": True,
        }

    def event(self, event_id: str, *, hydrate: bool = False) -> dict[str, Any]:
        event = max(
            (
                value
                for store in self._read_stores()
                if (value := store.event(event_id)) is not None
            ),
            key=lambda item: (
                str(item.get("committed_at") or item.get("occurred_at") or ""),
                str(item.get("event_id") or ""),
            ),
            default=None,
        )
        if event is None:
            return {"ok": False, "status": "not_found", "event_id": event_id}
        result = dict(event)
        payload = result.get("payload")
        nested = payload.get("payload") if isinstance(payload, dict) else None
        reference = nested.get("object_ref") if isinstance(nested, dict) else None
        if hydrate and isinstance(reference, str):
            result["hydrated_payload"] = json.loads(self.runtime.artifacts.get(reference))
        return {
            "ok": True,
            "schema_version": "persistmind.activity_event_show.v1",
            "event": result,
            "nextgen_v1": True,
        }

    def events(
        self, *, event_type: str | None = None, since: str | None = None, limit: int = 100
    ) -> dict[str, Any]:
        events = [
            dict(item)
            for store in self._read_stores()
            for item in store.events(event_type=event_type, since=since, limit=limit)
        ]
        events.sort(
            key=lambda item: (str(item["committed_at"]), str(item["event_id"])),
            reverse=True,
        )
        events = events[: max(1, min(int(limit), 1000))]
        return {
            "ok": True,
            "schema_version": "persistmind.activity_events.v1",
            "events": events,
            "count": len(events),
            "nextgen_v1": True,
        }

    def token_usage_record(
        self,
        *,
        activity: str,
        leg: str = AGENT_LEG,
        tokens: Mapping[str, Any] | None = None,
        task_session_id: str | None = None,
        measurement: str = "measured",
        source: str = "reported",
        transcript_path: str | None = None,
        detail: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Append one token-accounting entry to the activity ledger.

        Either supply ``tokens`` directly, or point at a host transcript and let
        PersistMind read the measured provider counts out of it.
        """

        transcript: dict[str, Any] | None = None
        if transcript_path:
            transcript = read_host_transcript_usage(transcript_path)
            if not transcript["ok"]:
                return {
                    "ok": False,
                    "status": transcript["status"],
                    "schema_version": "persistmind.token_usage_record.v1",
                    "transcript_path": transcript["transcript_path"],
                    "remediation": "pass --transcript pointing at a readable host transcript",
                    "nextgen_v1": True,
                }
            # A transcript is a cumulative source: every read reports the whole
            # session. Record only what is new, so repeated reads (one per Stop
            # hook, say) do not multiply the same tokens into the ledger.
            tokens = self._transcript_delta(transcript, task_session_id=task_session_id)
            if not any(tokens.values()):
                return {
                    "ok": True,
                    "status": "no_new_usage",
                    "schema_version": "persistmind.token_usage_record.v1",
                    "transcript_path": transcript["transcript_path"],
                    "nextgen_v1": True,
                }
        entry = token_entry(
            activity=activity,
            leg=leg,
            measurement=measurement,
            tokens=tokens or {},
            task_session_id=task_session_id,
            source=source,
            detail={
                **dict(detail or {}),
                **(
                    {
                        "transcript_path": transcript["transcript_path"],
                        "transcript_message_count": transcript["message_count"],
                        "transcript_models": transcript["models"],
                    }
                    if transcript
                    else {}
                ),
            },
        )
        appended = self.append_event(
            TOKEN_USAGE_EVENT_TYPE,
            entry,
            idempotency_key=f"token_usage:{entry['entry_id']}",
        )
        return {
            "ok": True,
            "status": "ok",
            "schema_version": "persistmind.token_usage_record.v1",
            "event_id": appended["event_id"],
            "entry": entry,
            "nextgen_v1": True,
        }

    def token_usage_report(
        self,
        task_session_id: str | None = None,
        *,
        limit: int = 1000,
    ) -> dict[str, Any]:
        """Aggregate the token ledger for one task session, or the whole workspace."""

        events = self.events(event_type=TOKEN_USAGE_EVENT_TYPE, limit=limit)
        entries = []
        for event in events.get("events", []):
            payload = self._event_payload(event)
            if not isinstance(payload, Mapping):
                continue
            if task_session_id and str(payload.get("task_session_id") or "") != task_session_id:
                continue
            entries.append(payload)
        entries.extend(self._served_pack_entries(task_session_id, limit=limit))
        task_text: str | None = None
        if task_session_id:
            session = self.task_store.session(task_session_id)
            if session is not None:
                metadata = json.loads(str(session.get("payload_json") or "{}")).get("metadata", {})
                task_text = str(metadata.get("objective") or metadata.get("task") or "") or None
        report = build_token_report(entries, task_session_id=task_session_id, task=task_text)
        report["summary_text"] = render_token_report(report)
        report["nextgen_v1"] = True
        return report

    def _transcript_delta(
        self, transcript: Mapping[str, Any], *, task_session_id: str | None
    ) -> dict[str, int]:
        path = str(transcript["transcript_path"])
        recorded = {field: 0 for field in ("input", "cache_read", "cache_write", "output")}
        for event in self.events(event_type=TOKEN_USAGE_EVENT_TYPE, limit=1000).get("events", []):
            payload = self._event_payload(event)
            if not isinstance(payload, Mapping):
                continue
            detail = payload.get("detail")
            if not isinstance(detail, Mapping) or str(detail.get("transcript_path") or "") != path:
                continue
            if task_session_id and str(payload.get("task_session_id") or "") != task_session_id:
                continue
            tokens = payload.get("tokens")
            if isinstance(tokens, Mapping):
                for field in recorded:
                    recorded[field] += max(0, int(tokens.get(field) or 0))
        cumulative = transcript["tokens"]
        return {
            field: max(0, int(cumulative.get(field) or 0) - recorded[field]) for field in recorded
        }

    def _event_payload(self, event: Mapping[str, Any]) -> Mapping[str, Any] | None:
        payload = event.get("payload")
        if isinstance(payload, Mapping) and isinstance(payload.get("payload"), Mapping):
            payload = payload["payload"]
        if not isinstance(payload, Mapping):
            return None
        reference = payload.get("object_ref")
        if isinstance(reference, str) and reference:
            hydrated = json.loads(self.runtime.artifacts.get(reference))
            return hydrated if isinstance(hydrated, Mapping) else None
        return payload

    def _served_pack_entries(
        self, task_session_id: str | None, *, limit: int
    ) -> list[dict[str, Any]]:
        """Derive served-leg entries from the durable finalized-pack manifests.

        Reading the packs is preferred over writing a ledger entry when a pack is
        compiled: the manifest is already the authoritative record of what
        PersistMind put in front of the agent, and deriving avoids a
        cross-authority write from the Source/Knowledge pack path into Activity.
        """

        events = self.events(event_type="context_pack.finalized", limit=limit)
        manifests: list[tuple[str, Mapping[str, Any]]] = []
        for event in events.get("events", []):
            manifest = self._event_payload(event)
            if isinstance(manifest, Mapping) and isinstance(manifest.get("manifest"), Mapping):
                manifest = manifest["manifest"]
            if not isinstance(manifest, Mapping):
                continue
            if task_session_id and str(manifest.get("task_session_id") or "") != task_session_id:
                continue
            manifests.append((str(event.get("occurred_at") or ""), manifest))
        manifests.sort(key=lambda item: item[0])
        served_hashes: set[str] = set()
        entries: list[dict[str, Any]] = []
        for occurred_at, manifest in manifests:
            for activity, key in (("pack_context", "items"), ("pack_memory", "memory")):
                items = manifest.get(key)
                if not isinstance(items, list) or not items:
                    continue
                entry = served_entry(
                    activity=activity,
                    items=[item for item in items if isinstance(item, Mapping)],
                    task_session_id=str(manifest.get("task_session_id") or "") or None,
                    source="persistmind.pack_manifest",
                    detail={"pack_id": manifest.get("pack_id"), "occurred_at": occurred_at},
                    previously_served_hashes=served_hashes,
                )
                served_hashes.update(entry.pop("served_hashes", []))
                entries.append(entry)
        return entries

    def record_outcome(
        self,
        task_session_id: str,
        result: str,
        *,
        pack_id: str | None = None,
        files_changed: list[str] | None = None,
        summary: str | None = None,
        actor: str = "local-user",
        episode_eligible: bool | None = None,
        evaluation_version_id: str | None = None,
    ) -> dict[str, Any]:
        task = self.task_store.session(task_session_id)
        if task is None:
            raise KeyError(f"task session not found: {task_session_id}")
        if str(task.get("state")) != "OUTCOME":
            raise ValueError("outcome recording requires the task to reach OUTCOME state")
        bound_pack = str(task.get("pack_id") or "")
        if not bound_pack:
            raise ValueError("outcome requires an exact task-bound pack")
        if pack_id and bound_pack and pack_id != bound_pack:
            raise ValueError("outcome pack_id does not match the task-bound pack")
        effective_pack = pack_id or bound_pack
        normalized = result.strip().lower()
        if normalized not in OUTCOME_RESULTS:
            raise ValueError("outcome result must be pass, fail, partial, or cancelled")
        snapshot = self.task_store.workflow_snapshot(task_session_id) or {}
        if normalized == "pass" and not any(
            resolution_satisfies_gate(value)
            for value in (
                snapshot.get("terminal_status"),
                task.get("terminal_status"),
            )
        ):
            raise ValueError("outcome cannot record pass without a verified terminal resolution")
        plan = self.task_store.latest_plan(task_session_id)
        if plan is None:
            raise ValueError("outcome requires an active task plan")
        if str(plan.get("metadata", {}).get("pack_id") or "") != effective_pack:
            raise ValueError("outcome plan does not bind the task-bound pack")
        if normalized == "pass":
            if (
                str(snapshot.get("verification_name") or "") in {"check-diff", "check_diff"}
                and str(snapshot.get("verification_status") or "").casefold()
                in {"pass", "passed", "ok", "success"}
            ):
                check_diff_gate = {"ok": True, "violations": []}
            else:
                check_diff_gate = _latest_check_diff_gate(
                    self.task_store.verifications(task_session_id),
                    plan_id=str(plan.get("plan_id") or ""),
                )
            if not check_diff_gate.get("ok"):
                return {
                    "ok": False,
                    "status": "unverified",
                    "schema_version": "persistmind.task_outcome.v1",
                    "task_session_id": task_session_id,
                    "pack_id": effective_pack,
                    "plan_id": str(plan.get("plan_id") or ""),
                    "result": "unverified",
                    "blocking_gate": "check_diff_clean",
                    "blocking_violations": check_diff_gate.get("violations", []),
                    "remediation": (
                        "Run persistmind --repo . check-diff --pack-id "
                        f"{effective_pack} and resolve its violations before recording pass."
                    ),
                    "nextgen_v1": True,
                }
        from persistmind.memory_quality import actionable_memory_content

        effective_episode_eligible = (
            bool(episode_eligible)
            if episode_eligible is not None
            else actionable_memory_content(summary=summary)
        )
        payload = {
            "task_session_id": task_session_id,
            "pack_id": effective_pack,
            "plan_id": str(plan.get("plan_id") or "") if plan else None,
            "result": normalized,
            "files_changed": sorted(set(files_changed or [])),
            "summary": summary,
            "actor": actor,
            "task_revision": task.get("revision"),
            "episode_eligible": effective_episode_eligible,
            "evaluation_requested": bool(evaluation_version_id),
            "evaluation_version_id": evaluation_version_id,
        }
        outcome_id = (
            "outcome_" + stable_id("task-outcome", task_session_id, canonical_json(payload))[:32]
        )
        outcome_event = self.lifecycle.emit(
            "OutcomeRecorded.v1",
            task_session_id,
            source_operation_key=f"outcome:{outcome_id}",
            payload={
                "pack_id": effective_pack,
                "plan_id": plan.get("plan_id") if plan else None,
                "outcome_id": outcome_id,
                "result": normalized,
                "files_changed_hash": stable_id(canonical_json(payload["files_changed"])),
            },
            producer="activity-service",
            required_consumers=tuple(
                sorted(
                    {
                        "workflow.agent-session.v1",
                        "workflow.audit.v1",
                        "workflow.compatibility.v1",
                        "workflow.continuation.v1",
                        "workflow.teacher-runtime.v1",
                        "activity.outcome.v1",
                        *(["knowledge.episode.v1"] if effective_episode_eligible else []),
                        *(["learning.evaluator.v1"] if evaluation_version_id else []),
                    }
                )
            ),
        )
        storage_event = StorageEvent(
            event_id="evt_" + stable_id("OutcomeProjectionRequested.v1", outcome_id)[:32],
            event_type="OutcomeProjectionRequested.v1",
            aggregate_id=task_session_id,
            sequence=int(task.get("revision") or 0),
            payload={"outcome_id": outcome_id, **payload},
            required_consumers=tuple(
                ["activity.outcome.v1"]
                + (["knowledge.episode.v1"] if effective_episode_eligible else [])
                + (["learning.evaluator.v1"] if evaluation_version_id else [])
            ),
        )
        self.outbox.append(storage_event)
        self.task_store.connection.commit()
        convergence = self.reconcile_outcomes(limit=100)
        if convergence["failed"]:
            return {
                "ok": False,
                "status": "projection_pending",
                "outcome_id": outcome_id,
                "storage_event_id": storage_event.event_id,
                "convergence": convergence,
                "nextgen_v1": True,
            }
        consumer_projection = self._project_outcome_consumers(
            outcome_event,
            storage_event_id=storage_event.event_id,
        )
        if not consumer_projection["ok"]:
            return {
                "ok": False,
                "status": "projection_pending",
                "outcome_id": outcome_id,
                "storage_event_id": storage_event.event_id,
                "convergence": convergence,
                "lifecycle_completion": consumer_projection["completion"],
                "nextgen_v1": True,
            }
        completed_event = self.lifecycle.complete_outcome(
            task_session_id,
            outcome_id=outcome_id,
            result=normalized,
        )
        projection = self._project_terminal_workflow(
            task_session_id,
            outcome_id=outcome_id,
            result=normalized,
            outcome_event=outcome_event,
            completed_event=completed_event,
        )
        self._project_completion_consumers(completed_event)
        return {
            "ok": True,
            "schema_version": "persistmind.task_outcome.v1",
            "outcome_id": outcome_id,
            "event_id": outcome_id,
            "storage_event_id": storage_event.event_id,
            "task_session_id": task_session_id,
            "pack_id": effective_pack,
            "plan_id": str(plan.get("plan_id") or "") if plan else None,
            "result": normalized,
            "convergence": convergence,
            "lifecycle_event_id": outcome_event["event_id"],
            "lifecycle_sequence": outcome_event["sequence"],
            "terminal_event_id": completed_event["event_id"],
            "workflow_projection": projection,
            "lifecycle_completion": consumer_projection["completion"],
            "token_usage": self.token_usage_report(task_session_id),
            "nextgen_v1": True,
        }

    def _project_outcome_consumers(
        self,
        outcome_event: Mapping[str, Any],
        *,
        storage_event_id: str,
    ) -> dict[str, Any]:
        event_id = str(outcome_event["event_id"])
        payload = dict(outcome_event["payload"])
        outbox_completion = self.outbox.completion(storage_event_id)
        acknowledged = set(outbox_completion["acknowledged_consumers"])
        projections: dict[str, Any] = {}

        def apply(consumer: str, operation: Any) -> None:
            try:
                projections[consumer] = operation()
                self.lifecycle.receipt(event_id, consumer, status="success")
            except Exception as exc:  # bounded failure becomes projection_pending
                projections[consumer] = {"ok": False, "error": str(exc)}
                self.lifecycle.receipt(
                    event_id,
                    consumer,
                    status="failed",
                    error=str(exc),
                )

        apply("workflow.agent-session.v1", lambda: self._project_outcome_sessions(payload))
        apply(
            "workflow.teacher-runtime.v1", lambda: self._project_outcome_teacher(payload, event_id)
        )
        apply("workflow.continuation.v1", lambda: self._project_outcome_continuation(payload))
        apply("workflow.compatibility.v1", lambda: self._project_compatibility_outcome(payload))
        apply("workflow.audit.v1", lambda: self._project_lifecycle_audit(outcome_event))
        for consumer in (
            "activity.outcome.v1",
            "knowledge.episode.v1",
            "learning.evaluator.v1",
        ):
            if consumer not in set(outcome_event["required_consumers"]):
                continue
            apply(
                consumer,
                lambda consumer=consumer: (
                    {"ok": True, "outbox_receipt": consumer}
                    if consumer in acknowledged
                    else (_raise_projection_missing(consumer))
                ),
            )
        completion = self.lifecycle.completion(event_id)
        return {
            "ok": completion["complete"],
            "projections": projections,
            "completion": completion,
        }

    def _project_outcome_sessions(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        snapshot = self.task_store.workflow_snapshot(str(payload["task_session_id"])) or {}
        return {
            "ok": True,
            "session_count": 1 if snapshot.get("task_owned_agent_session_id") else 0,
            "projection": "canonical-task-snapshot",
        }

    def _project_outcome_teacher(
        self,
        payload: Mapping[str, Any],
        event_id: str,
    ) -> dict[str, Any]:
        return {
            "ok": True,
            "not_applicable": "teacher_runtime_not_in_core_profile",
            "task_session_id": payload["task_session_id"],
            "event_id": event_id,
        }

    def _project_outcome_continuation(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        task_session_id = str(payload["task_session_id"])
        continuation = self.task_store.active_continuation(task_session_id)
        if continuation is None:
            return {"ok": True, "not_applicable": "continuation_missing"}
        document = {
            key: value
            for key, value in dict(continuation).items()
            if key
            not in {
                "continuation_id",
                "task_session_id",
                "task_hash",
                "status",
                "revision",
                "created_at",
                "updated_at",
            }
        }
        document.update(
            {
                "current_state": "outcome_recorded",
                "next_action": "Await lifecycle projection completion.",
                "outcome_id": payload["outcome_id"],
            }
        )
        updated = self.task_store.upsert_continuation(
            str(continuation["continuation_id"]),
            task_session_id=task_session_id,
            task_hash=str(continuation["task_hash"]),
            status=str(continuation["status"]),
            payload=document,
            expected_revision=int(continuation["revision"]),
        )
        return {"ok": True, "revision": updated["revision"]}

    def _project_compatibility_outcome(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        outcome_id = str(payload["outcome_id"])
        existing = self.task_store.get(outcome_id)
        if existing is not None and str(existing.get("result")) != str(payload["result"]):
            raise RuntimeError("canonical outcome divergence")
        self.task_store.put(
            {"record_id": outcome_id, "kind": "workflow-outcome", **dict(payload)},
            idempotency_key=f"workflow-outcome:{outcome_id}",
        )
        return {"ok": True, "outcome_id": outcome_id, "projection": "task-domain"}

    def _project_lifecycle_audit(self, event: Mapping[str, Any]) -> dict[str, Any]:
        audit_id = self.audit_store.append_audit(
            {
                "audit_id": str(event["event_id"]),
                "correlation_id": str(event["aggregate_id"]),
                "kind": str(event["event_type"]),
                "principal": str(event["producer"]),
                "payload": dict(event["payload"]),
            },
            idempotency_key=f"workflow-lifecycle:{event['event_id']}",
        )
        return {"ok": True, "audit_id": audit_id}

    def _project_completion_consumers(self, event: Mapping[str, Any]) -> None:
        self._project_lifecycle_audit(event)
        self.lifecycle.receipt(str(event["event_id"]), "workflow.audit.v1")
        self.lifecycle.receipt(str(event["event_id"]), "workflow.compatibility.v1")

    def _project_terminal_workflow(
        self,
        task_session_id: str,
        *,
        outcome_id: str,
        result: str,
        outcome_event: Mapping[str, Any],
        completed_event: Mapping[str, Any],
    ) -> dict[str, Any]:
        current = self.task_store.workflow_snapshot(task_session_id)
        payload = {
            key: value
            for key, value in dict(current or {}).items()
            if key
            not in {
                "task_session_id",
                "pack_id",
                "plan_id",
                "revision",
                "updated_at",
            }
        }
        payload.update(
            {
                "preflight_ready": False,
                "terminal_status": result,
                "terminal_event_id": completed_event["event_id"],
                "outcome_id": outcome_id,
            }
        )
        task = self.task_store.session(task_session_id) or {}
        plan = self.task_store.latest_plan(task_session_id)
        snapshot = self.task_store.save_workflow_snapshot(
            task_session_id,
            payload=payload,
            pack_id=str(task.get("pack_id") or "") or None,
            plan_id=str(plan.get("plan_id") or "") if plan else None,
            expected_revision=int(current["revision"]) if current is not None else 0,
        )
        continuation = self.task_store.active_continuation(task_session_id)
        if continuation is not None:
            continuation_payload = {
                key: value
                for key, value in dict(continuation).items()
                if key
                not in {
                    "continuation_id",
                    "task_session_id",
                    "task_hash",
                    "status",
                    "revision",
                    "created_at",
                    "updated_at",
                }
            }
            continuation_payload.update(
                {
                    "current_state": "completed" if result == "pass" else result,
                    "next_action": None,
                    "blockers": [] if result == "pass" else [f"Outcome result: {result}"],
                    "reason": f"outcome recorded: {result}",
                    "outcome_id": outcome_id,
                }
            )
            self.task_store.upsert_continuation(
                str(continuation["continuation_id"]),
                task_session_id=task_session_id,
                task_hash=str(continuation["task_hash"]),
                status="expired",
                payload=continuation_payload,
                expected_revision=int(continuation["revision"]),
            )
        product_projection = self._project_product_runtime(
            task_session_id,
            outcome_event=outcome_event,
            completed_event=completed_event,
        )
        return {
            "snapshot_revision": snapshot.get("revision"),
            "teacher_runtime": product_projection,
        }

    def _project_product_runtime(
        self,
        task_session_id: str,
        *,
        outcome_event: Mapping[str, Any],
        completed_event: Mapping[str, Any],
    ) -> dict[str, Any] | None:
        snapshot = self.task_store.workflow_snapshot(task_session_id) or {}
        result = str(completed_event["payload"].get("result") or "")
        terminal_status = {
            "pass": "completed",
            "fail": "failed",
            "partial": "partial",
            "cancelled": "cancelled",
        }.get(result, result or "completed")
        return {
            "not_applicable": "teacher_runtime_not_in_core_profile",
            "agent_session_projection": {
                "task_owned_agent_session_id": snapshot.get("task_owned_agent_session_id"),
                "task_owned_status": terminal_status,
                "host_sessions_notified": 0,
                "terminal_event_id": completed_event["event_id"],
                "outcome_id": outcome_event["payload"]["outcome_id"],
            },
        }

    def reconcile_outcomes(self, *, limit: int = 100) -> dict[str, Any]:
        activity = reconcile(
            self.outbox,
            "activity.outcome.v1",
            "v1",
            self._project_task_completed,
            limit=limit,
            receipt_validator=self._task_outcome_effect_exists,
        )
        knowledge = reconcile(
            self.outbox,
            "knowledge.episode.v1",
            "v1",
            self._project_episode,
            limit=limit,
        )
        learning = reconcile(
            self.outbox,
            "learning.evaluator.v1",
            "v1",
            self._project_learning_evaluation,
            limit=limit,
        )
        return {
            "ok": activity.failed + knowledge.failed + learning.failed == 0,
            "schema_version": "persistmind.activity_outcome_reconcile.v1",
            "scanned": activity.scanned + knowledge.scanned + learning.scanned,
            "applied": activity.applied + knowledge.applied + learning.applied,
            "duplicates": activity.duplicates + knowledge.duplicates + learning.duplicates,
            "failed": activity.failed + knowledge.failed + learning.failed,
            "consumers": {
                "activity.outcome.v1": asdict(activity),
                "knowledge.episode.v1": asdict(knowledge),
                "learning.evaluator.v1": asdict(learning),
            },
            "nextgen_v1": True,
        }

    def _project_task_completed(self, event: StorageEvent) -> None:
        if event.event_type != "OutcomeProjectionRequested.v1":
            return
        outcome_id = str(event.payload["outcome_id"])
        self.append_event(
            "task.outcome_recorded",
            dict(event.payload),
            event_id=outcome_id,
            idempotency_key=f"task-outcome:{outcome_id}",
        )

    def _task_outcome_effect_exists(self, event: StorageEvent) -> bool:
        if event.event_type != "OutcomeProjectionRequested.v1":
            return True
        outcome_id = str(event.payload.get("outcome_id") or "")
        return any(store.event(outcome_id) is not None for store in self._read_stores())

    def _project_episode(self, event: StorageEvent) -> None:
        if event.event_type != "OutcomeProjectionRequested.v1" or not event.payload.get(
            "episode_eligible"
        ):
            return
        from .knowledge_service import KnowledgeService

        with KnowledgeService(
            self.repo_root,
            allow_development_driver=self.store._allow_development_driver,
            runtime=self.runtime,
        ) as knowledge:
            knowledge.memory_create_typed(
                {
                    "record_id": "episode_"
                    + stable_id("task-episode", str(event.payload["outcome_id"]))[:32],
                    "type": "episode",
                    "assertion": str(
                        event.payload.get("summary")
                        or f"Task {event.aggregate_id} completed with {event.payload.get('result')}"
                    ),
                    "source_kind": "OutcomeProjectionRequested.v1",
                    "status": "active",
                    "trust": "active",
                    "scope_refs": list(event.payload.get("files_changed") or []),
                    "metadata": {
                        "task_session_id": event.aggregate_id,
                        "outcome_id": event.payload["outcome_id"],
                        "pack_id": event.payload.get("pack_id"),
                        "title": str(
                            event.payload.get("title") or f"Task {event.aggregate_id} outcome"
                        ),
                        "lesson": str(
                            event.payload.get("lesson")
                            or event.payload.get("summary")
                            or event.payload.get("result")
                            or "Outcome recorded without a separate lesson."
                        ),
                        "future_use": str(
                            event.payload.get("future_use")
                            or event.payload.get("next_action")
                            or "Recall this episode for similar task outcomes."
                        ),
                        "result": event.payload.get("result"),
                        "files_changed": list(event.payload.get("files_changed") or []),
                        "verification": list(event.payload.get("verification") or []),
                    },
                    "provenance": {
                        "generator": "activity-outcome-projector",
                        "validator": "task-manifest",
                    },
                }
            )

    def _project_learning_evaluation(self, event: StorageEvent) -> None:
        version_id = str(event.payload.get("evaluation_version_id") or "")
        if event.event_type != "OutcomeProjectionRequested.v1" or not version_id:
            return
        from .learning_service import LearningService

        with LearningService(
            self.repo_root,
            allow_development_driver=self.store._allow_development_driver,
            runtime=self.runtime,
        ) as learning:
            passed = str(event.payload.get("result")) == "pass"
            learning.evaluation_record(
                version_id,
                metrics={"task_outcome_pass": 1.0 if passed else 0.0},
                passed=passed,
            )

    def rotate_partition(self) -> dict[str, Any]:
        """Publish one sealed Activity image and a fresh writable generation."""

        unsettled_row = self.store.connection.execute(
            "SELECT COUNT(*) FROM agent_event_journal WHERE delivery_state IN ('pending','claimed')"
        ).fetchone()
        unsettled = int(cast(Sequence[Any], unsettled_row)[0]) if unsettled_row else 0
        if unsettled:
            raise RuntimeError(
                "activity_rotation_blocked: agent event deliveries must be settled before rotation "
                f"(unsettled={unsettled})"
            )

        current = self.runtime.topology
        next_generation = current.generation + 1
        proof = dict(self.store.seal_partition())
        partition_id = str(proof["partition_id"])
        sealed_relative = f"stores/activity/sealed/{partition_id}.db"
        sealed_path = self.runtime.catalog.resolve_location(sealed_relative)
        sealed = dict(self.store.seal_partition(sealed_path, sealed_store_id=partition_id))
        active_store_id = f"activity-active-g{next_generation}"
        active_relative = f"stores/activity/active-g{next_generation}.db"
        active_path = self.runtime.catalog.resolve_location(active_relative)
        old = next(
            item
            for item in current.stores
            if item.store_role is StoreRole.ACTIVITY_ACTIVE and item.state == "active"
        )
        sealed_descriptor = replace(
            old,
            store_id=partition_id,
            store_role=StoreRole.ACTIVITY_SEALED,
            location=sealed_relative,
            generation=next_generation,
            state="sealed",
            read_only=True,
            partition_key=partition_id,
            sealed_at=utc_now(),
            min_key=str(sealed.get("min_committed_at") or "") or None,
            max_key=str(sealed.get("max_committed_at") or "") or None,
            logical_content_hash=str(sealed["logical_content_hash"]),
            physical_image_hash=str(sealed["physical_image_hash"]),
            capabilities=StoreCapabilities(partitioning=True, online_backup=True),
        )
        active_descriptor = StoreDescriptor(
            store_id=active_store_id,
            domain=old.domain,
            store_role=StoreRole.ACTIVITY_ACTIVE,
            backend="sqlite",
            location=active_relative,
            schema_head=old.schema_head,
            authorization_scope=old.authorization_scope,
            generation=next_generation,
            state="active",
            shard_key=old.shard_key,
            partition_key="current",
            created_at=utc_now(),
            capabilities=StoreCapabilities(partitioning=True, online_backup=True),
        )
        replacement = SQLiteActivityStore(
            active_path,
            descriptor=active_descriptor,
            allow_development_driver=self.store._allow_development_driver,
        )
        replacement.close()
        stores = tuple(item for item in current.stores if item.store_id != old.store_id) + (
            active_descriptor,
            sealed_descriptor,
        )
        publish_topology(
            self.runtime,
            replace(current, generation=next_generation, stores=stores, created_at=utc_now()),
            expected_generation=current.generation,
        )
        return {
            "ok": True,
            "schema_version": "persistmind.activity_rotation.v1",
            "catalog_generation": next_generation,
            "sealed": sealed,
            "active_store_id": active_store_id,
            "requires_reopen": True,
            "nextgen_v1": True,
        }

    def _read_stores(self) -> list[SQLiteActivityStore]:
        stores: list[SQLiteActivityStore] = []
        for role in (StoreRole.ACTIVITY_ACTIVE, StoreRole.ACTIVITY_SEALED):
            try:
                resolved = self.runtime.router.resolve_read_set(role)
            except KeyError:
                continue
            stores.extend(store for store in resolved if isinstance(store, SQLiteActivityStore))
        return stores


def _raise_projection_missing(consumer: str) -> dict[str, Any]:
    raise RuntimeError(f"required outbox receipt is missing: {consumer}")


def _latest_check_diff_gate(verifications: Any, *, plan_id: str) -> dict[str, Any]:
    latest: Mapping[str, Any] | None = None
    for item in verifications or []:
        if str(item.get("plan_id") or "") != plan_id:
            continue
        name = str(item.get("name") or "")
        evidence_type = str(item.get("evidence_type") or "")
        if name not in {"check-diff", "check_diff"} and evidence_type != "check_diff":
            continue
        latest = item
        break
    if latest is None:
        return {"ok": False, "violations": [{"kind": "check_diff_missing"}]}
    ok = str(latest.get("status") or "").casefold() in {"pass", "passed", "ok", "success"}
    return {
        "ok": ok,
        "verification_id": latest.get("verification_id"),
        "violations": list(latest.get("violations") or []),
    }
