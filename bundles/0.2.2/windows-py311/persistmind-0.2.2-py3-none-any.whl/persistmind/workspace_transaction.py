from __future__ import annotations

import hashlib
import json
import os
import secrets
import shutil
import stat
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from persistmind.updater.atomic import write_json
from persistmind.utils import utc_now
from persistmind.workspace_path_policy import WorkspacePathPolicy


OWNER_MARKER = ".persistmind-install-owner.json"
TRANSACTION_SCHEMA = "persistmind.workspace_transaction.v2"
OWNER_SCHEMA = "persistmind.workspace_owner.v1"

_OWNED_ROOT_ENTRIES = frozenset(
    {
        OWNER_MARKER,
        "anchors",
        "artifacts",
        "backups",
        "blobs",
        "catalog",
        "claude",
        "codex",
        "diagnostics",
        "exports",
        "feedback",
        "git-hooks",
        "incidents",
        "installation.json",
        "locks",
        "mcp",
        "migration",
        "operations",
        "protocol.json",
        "objects",
        "quarantine",
        "reports",
        "runtime",
        "setup-profile.json",
        "stores",
        "updates",
        "workspace.cold.db",
        "workspace.cold.db-shm",
        "workspace.cold.db-wal",
    }
)
_OWNERSHIP_EVIDENCE = frozenset(
    {OWNER_MARKER, "installation.json", "setup-profile.json", "catalog", "stores"}
)


@dataclass
class WorkspaceTransaction:
    policy: WorkspacePathPolicy
    transaction_id: str
    nonce: str
    journal_path: Path
    created_root: bool
    backup_root: Path
    baseline: dict[str, dict[str, Any]] = field(default_factory=dict)
    owned_entries: dict[str, dict[str, Any]] = field(default_factory=dict)
    phases: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def begin(
        cls,
        policy: WorkspacePathPolicy,
        control_root: Path,
        transaction_id: str,
    ) -> "WorkspaceTransaction":
        """Begin the durable journal before taking any workspace snapshot."""

        policy.recheck_parent()
        workspace = policy.workspace
        existed = workspace.exists() or workspace.is_symlink()
        nonce = secrets.token_hex(32)
        journal_path = Path(control_root).resolve() / transaction_id / "transaction.json"
        journal_path.parent.mkdir(parents=True, exist_ok=False)
        transaction = cls(
            policy=policy,
            transaction_id=transaction_id,
            nonce=nonce,
            journal_path=journal_path,
            created_root=not existed,
            backup_root=journal_path.parent / "workspace-backup",
        )
        # This is deliberately the first durable transaction record. Validation
        # and backup failures therefore leave a recovery artifact.
        transaction._write_journal("preparing")

        if existed:
            _validate_existing_workspace(workspace)
            transaction.baseline = _inventory(workspace)
            transaction._write_journal("snapshotting")
            transaction._snapshot_baseline()
            transaction._write_journal("prepared")
            return transaction

        try:
            policy.recheck_parent()
            workspace.mkdir()
            write_json(workspace / OWNER_MARKER, transaction._marker("active"))
            transaction.record_phase("transaction_begin")
            return transaction
        except Exception:
            # Only exact, known empty entries created above may be removed here.
            marker = workspace / OWNER_MARKER
            if marker.is_file():
                marker.unlink()
            if workspace.is_dir():
                workspace.rmdir()
            transaction._write_journal("prepare_failed")
            raise

    def record_phase(self, phase: str) -> dict[str, Any]:
        """Record every path created by a completed installer phase.

        Rollback never infers ownership from a parent directory or a filename.
        A path must appear in this durable set before it can be removed.
        """

        self.policy.recheck_parent()
        current = _inventory(self.policy.workspace)
        created = sorted(set(current) - set(self.baseline))
        for relative in created:
            self.owned_entries[relative] = current[relative]
        phase_record = {
            "phase": phase,
            "recorded_at": utc_now(),
            "created_entries": created,
        }
        self.phases.append(phase_record)
        self._write_journal("active")
        return phase_record

    def refresh_owned_entries(self, phase: str) -> dict[str, Any]:
        """Refresh fingerprints for already-owned paths without claiming new ones."""

        self.policy.recheck_parent()
        current = _inventory(self.policy.workspace)
        refreshed = sorted(set(current) & set(self.owned_entries))
        for relative in refreshed:
            self.owned_entries[relative] = current[relative]
        phase_record = {
            "phase": phase,
            "recorded_at": utc_now(),
            "created_entries": [],
            "refreshed_entries": refreshed,
        }
        self.phases.append(phase_record)
        self._write_journal("active")
        return phase_record

    def commit(self) -> dict[str, Any]:
        if self.created_root:
            self.policy.recheck_parent()
            marker = self._read_matching_marker()
            marker["status"] = "committed"
            marker["committed_at"] = utc_now()
            write_json(self.policy.workspace / OWNER_MARKER, marker)
        self._write_journal("committed")
        return {
            "ok": True,
            "status": "committed",
            "transaction_id": self.transaction_id,
            "nonce": self.nonce,
            "journal": str(self.journal_path),
            "marker": str(self.policy.workspace / OWNER_MARKER),
            "created_root": self.created_root,
        }

    def rollback(self) -> dict[str, Any]:
        removed: list[str] = []
        restored: list[str] = []
        try:
            self.policy.recheck_parent()
            workspace = self.policy.workspace
            if not workspace.is_dir() or workspace.is_symlink():
                raise RuntimeError("workspace identity changed during the transaction")
            if self.created_root:
                self._read_matching_marker()

            current = _inventory(workspace)
            removed_companions = _remove_empty_sqlite_companions(
                workspace,
                current,
                known_entries=set(self.baseline) | set(self.owned_entries),
            )
            if removed_companions:
                current = _inventory(workspace)
            unknown = sorted(set(current) - set(self.baseline) - set(self.owned_entries))
            if unknown:
                raise RuntimeError("workspace contains unjournaled entries: " + ", ".join(unknown))

            changed_owned = sorted(
                relative
                for relative, recorded in self.owned_entries.items()
                if relative in current and current[relative] != recorded
            )
            if changed_owned:
                raise RuntimeError(
                    "journaled workspace entries changed after their phase: "
                    + ", ".join(changed_owned)
                )

            self._write_journal(
                "rollback_ready",
                observed_entries=sorted(current),
                removed_sqlite_companions=removed_companions,
            )
            for relative in _reverse_paths(self.owned_entries):
                path = workspace / Path(relative)
                if not path.exists() and not path.is_symlink():
                    continue
                self.policy.recheck_parent()
                observed = _entry(path, workspace)
                if observed != self.owned_entries[relative]:
                    raise RuntimeError(f"workspace entry changed before removal: {relative}")
                if observed["kind"] == "file":
                    path.unlink()
                else:
                    path.rmdir()
                removed.append(relative)

            if self.baseline:
                restored = self._restore_baseline()
            elif self.created_root:
                self.policy.recheck_parent()
                workspace.rmdir()

            self._write_journal(
                "rolled_back",
                removed_entries=removed,
                restored_entries=restored,
            )
            return {
                "ok": True,
                "status": "rolled_back",
                "journal": str(self.journal_path),
                "removed_entries": removed,
                "restored_entries": restored,
            }
        except (OSError, RuntimeError, ValueError) as exc:
            self._write_journal(
                "recovery_required",
                error=str(exc),
                removed_entries=removed,
                restored_entries=restored,
            )
            return {
                "ok": False,
                "status": "recovery_required",
                "journal": str(self.journal_path),
                "error": str(exc),
                "removed_entries": removed,
                "restored_entries": restored,
            }

    def _snapshot_baseline(self) -> None:
        for index, relative in enumerate(sorted(self.baseline)):
            record = self.baseline[relative]
            if record["kind"] != "file":
                continue
            source = self.policy.workspace / Path(relative)
            backup = self.backup_root / f"{index:08d}.backup"
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, backup)
            record["backup"] = str(backup)
        self._write_journal("snapshotted")

    def _restore_baseline(self) -> list[str]:
        workspace = self.policy.workspace
        restored: list[str] = []
        for relative in sorted(
            (key for key, value in self.baseline.items() if value["kind"] == "directory"),
            key=lambda value: (len(Path(value).parts), value),
        ):
            path = workspace / Path(relative)
            if path.exists() and not path.is_dir():
                raise RuntimeError(f"baseline directory changed type: {relative}")
            path.mkdir(exist_ok=True)
        for relative, record in sorted(self.baseline.items()):
            if record["kind"] != "file":
                continue
            path = workspace / Path(relative)
            if path.exists() and not path.is_file():
                raise RuntimeError(f"baseline file changed type: {relative}")
            backup = Path(str(record["backup"]))
            if not backup.is_file() or _sha256(backup) != record["sha256"]:
                raise RuntimeError(f"baseline backup is missing or corrupt: {relative}")
            path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(backup, path)
            os.chmod(path, int(record["mode"]))
            restored.append(relative)
        return restored

    def _marker(self, status: str) -> dict[str, Any]:
        return {
            "schema_version": OWNER_SCHEMA,
            "transaction_id": self.transaction_id,
            "nonce": self.nonce,
            "workspace": str(self.policy.workspace),
            "repo_root": str(self.policy.repo_root),
            "parent_identity": list(self.policy.parent_identity),
            "status": status,
            "created_at": utc_now(),
        }

    def _read_matching_marker(self) -> dict[str, Any]:
        path = self.policy.workspace / OWNER_MARKER
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise RuntimeError("workspace ownership marker is missing or invalid") from exc
        expected = {
            "schema_version": OWNER_SCHEMA,
            "transaction_id": self.transaction_id,
            "nonce": self.nonce,
            "workspace": str(self.policy.workspace),
            "repo_root": str(self.policy.repo_root),
            "parent_identity": list(self.policy.parent_identity),
        }
        if not isinstance(value, dict) or any(
            value.get(key) != item for key, item in expected.items()
        ):
            raise RuntimeError("workspace ownership marker does not match the transaction")
        return value

    def _write_journal(self, status: str, **extra: Any) -> None:
        current: dict[str, Any] = {}
        if self.journal_path.exists():
            try:
                value = json.loads(self.journal_path.read_text(encoding="utf-8"))
                current = value if isinstance(value, dict) else {}
            except (OSError, UnicodeError, json.JSONDecodeError):
                current = {}
        current.update(
            {
                "schema_version": TRANSACTION_SCHEMA,
                "transaction_id": self.transaction_id,
                "nonce": self.nonce,
                "repo_root": str(self.policy.repo_root),
                "workspace": str(self.policy.workspace),
                "parent_identity": list(self.policy.parent_identity),
                "created_root": self.created_root,
                "status": status,
                "baseline": self.baseline,
                "owned_entries": self.owned_entries,
                "phases": self.phases,
                "updated_at": utc_now(),
                **extra,
            }
        )
        write_json(self.journal_path, current)


def _validate_existing_workspace(workspace: Path) -> None:
    if workspace.is_symlink() or not workspace.is_dir():
        raise RuntimeError("existing workspace is not a safe directory")
    names = {item.name for item in workspace.iterdir()}
    if not names:
        return
    if not names.intersection(_OWNERSHIP_EVIDENCE):
        raise RuntimeError("existing workspace is not recognized as PersistMind-owned")
    unknown = sorted(names - _OWNED_ROOT_ENTRIES)
    if unknown:
        raise RuntimeError("existing workspace contains unowned entries: " + ", ".join(unknown))


def _inventory(workspace: Path) -> dict[str, dict[str, Any]]:
    if not workspace.is_dir() or workspace.is_symlink():
        raise RuntimeError("workspace is not a safe directory")
    inventory: dict[str, dict[str, Any]] = {}
    pending = [workspace]
    while pending:
        parent = pending.pop()
        for path in parent.iterdir():
            relative = path.relative_to(workspace).as_posix()
            record = _entry(path, workspace)
            inventory[relative] = record
            if record["kind"] == "directory":
                pending.append(path)
    return dict(sorted(inventory.items()))


def _entry(path: Path, workspace: Path) -> dict[str, Any]:
    try:
        info = path.lstat()
    except OSError as exc:
        raise RuntimeError(f"cannot inspect workspace entry: {path}") from exc
    attributes = int(getattr(info, "st_file_attributes", 0))
    reparse_flag = int(getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
    if stat.S_ISLNK(info.st_mode) or attributes & reparse_flag:
        relative = path.relative_to(workspace).as_posix()
        raise RuntimeError(f"workspace contains a symlink or reparse point: {relative}")
    if stat.S_ISDIR(info.st_mode):
        return {"kind": "directory", "mode": stat.S_IMODE(info.st_mode)}
    if stat.S_ISREG(info.st_mode):
        return {
            "kind": "file",
            "mode": stat.S_IMODE(info.st_mode),
            "size": info.st_size,
            "sha256": _sha256(path),
        }
    relative = path.relative_to(workspace).as_posix()
    raise RuntimeError(f"workspace contains an unsupported filesystem entry: {relative}")


def _reverse_paths(entries: dict[str, dict[str, Any]]) -> list[str]:
    return sorted(entries, key=lambda value: (len(Path(value).parts), value), reverse=True)


def _remove_empty_sqlite_companions(
    workspace: Path,
    current: dict[str, dict[str, Any]],
    *,
    known_entries: set[str],
) -> list[str]:
    """Remove only unjournaled SQLite sidecars that cannot contain WAL data."""

    unknown = set(current) - known_entries
    removable: list[str] = []
    for relative in sorted(unknown):
        if not relative.endswith((".db-wal", ".db-shm")):
            continue
        base = relative[:-4]
        if base not in known_entries or current.get(base, {}).get("kind") != "file":
            continue
        wal = f"{base}-wal"
        wal_record = current.get(wal)
        if wal_record is not None and (
            wal_record.get("kind") != "file" or int(wal_record.get("size", -1)) != 0
        ):
            continue
        removable.append(relative)
    for relative in sorted(removable, key=lambda value: value.endswith("-shm")):
        (workspace / Path(relative)).unlink()
    return removable


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()
