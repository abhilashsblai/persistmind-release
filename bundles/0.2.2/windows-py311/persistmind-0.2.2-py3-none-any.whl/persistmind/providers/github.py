from __future__ import annotations

from persistmind.eval.providers import fetch_provider_prs
from persistmind.providers.base import HarvestedTask


def harvest(repo: str, limit: int = 200) -> list[HarvestedTask]:
    prs = fetch_provider_prs("github", repo, limit)
    return [
        HarvestedTask("github", sha, pr.title, pr.body, pr.merge_commit_sha)
        for sha, pr in sorted(prs.items())
    ]
