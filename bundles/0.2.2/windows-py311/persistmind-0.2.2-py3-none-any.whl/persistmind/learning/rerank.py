from __future__ import annotations

import json
from typing import Any

from persistmind.learning.judge import deterministic_first_judge
from persistmind.learning.provider import AgentProvider
from persistmind.utils import canonical_json, stable_id

RERANK_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["items"],
    "properties": {
        "items": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["id", "rank", "rationale"],
                "properties": {
                    "id": {"type": "string"},
                    "rank": {"type": "integer", "minimum": 1},
                    "rationale": {"type": "string"},
                    "risk_note": {"type": "string"},
                },
                "additionalProperties": False,
            },
        }
    },
    "additionalProperties": False,
}


class BoundedReranker:
    def __init__(
        self,
        *,
        store: Any,
        provider: AgentProvider,
        model_family: str | None = None,
        budget_tokens: int | None = None,
        order_only: bool = True,
        require_judge: bool = False,
        judge_provider: AgentProvider | None = None,
        judge_model_family: str | None = None,
        judge_votes: int = 1,
        judge_min_pass_rate: float = 1.0,
        fail_closed_on_disagreement: bool = False,
        max_disagreement: float = 0.5,
    ):
        self.store = store
        self.provider = provider
        self.model_family = model_family
        self.budget_tokens = budget_tokens
        self.order_only = order_only
        self.require_judge = require_judge
        self.judge_provider = judge_provider
        self.judge_model_family = judge_model_family
        self.judge_votes = judge_votes
        self.judge_min_pass_rate = judge_min_pass_rate
        self.fail_closed_on_disagreement = fail_closed_on_disagreement
        self.max_disagreement = max_disagreement

    def rerank(
        self,
        *,
        repo_id: str,
        task: str,
        candidates: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        if not candidates:
            return candidates
        decision_values = _decision_value_scores(self.store, candidates)
        indexed = [
            {
                "id": candidate_id(item, index),
                "index": index,
                "path": item.get("path"),
                "category": item.get("category"),
                "start_line": item.get("start_line"),
                "end_line": item.get("end_line"),
                "score": round(float(item.get("score") or 0.0), 6),
                "provenance": sorted(
                    str(value) for value in item.get("provenance", []) if value is not None
                ),
                "decision_value_score": decision_values[index]["score"],
                "decision_value_samples": decision_values[index]["samples"],
                "text_preview": _preview(str(item.get("text") or "")),
            }
            for index, item in enumerate(candidates)
        ]
        raw = self.provider.complete(
            prompt=rerank_prompt(task, indexed, order_only=self.order_only),
            role="reranker",
            schema=RERANK_SCHEMA,
            model_family=self.model_family,
            budget_tokens=self.budget_tokens,
        )
        if raw is None:
            return candidates
        validation = validate_rerank(raw, [str(item["id"]) for item in indexed])
        if not validation["ok"]:
            self._event(
                "rerank_rejected",
                repo_id,
                {
                    "reason": validation["reason"],
                    "candidate_count": len(indexed),
                    "output_count": validation.get("output_count"),
                },
            )
            return candidates
        safety = _safety_floor(raw, indexed, candidates)
        provenance_record = {
            "rerank_id": stable_id(repo_id, task, canonical_json([item["id"] for item in indexed])),
            "candidate_pool": [item["id"] for item in indexed],
            "permutation_valid": bool(validation["ok"]),
            "order_only": self.order_only,
            "safety_floor_held": safety["ok"],
            "safety_violations": safety["violations"],
            "boosts_applied": _boosts(candidates, decision_values),
            "judge": None,
        }
        if not safety["ok"]:
            self._event(
                "rerank_rejected",
                repo_id,
                {
                    "reason": "safety_floor_violation",
                    "candidate_count": len(indexed),
                    "rerank_provenance": provenance_record,
                },
            )
            return candidates

        judge = None
        if self.require_judge:
            judge = deterministic_first_judge(
                name="rerank_order",
                deterministic={"ok": True, "reason": "permutation_valid", **validation},
                provider=self.judge_provider or self.provider,
                prompt_payload={
                    "task": task,
                    "order_only": self.order_only,
                    "input_candidates": indexed,
                    "proposed_order": raw,
                },
                model_family=self.judge_model_family,
                budget_tokens=self.budget_tokens,
                votes=self.judge_votes,
                min_pass_rate=self.judge_min_pass_rate,
                fail_closed_on_disagreement=self.fail_closed_on_disagreement,
                max_disagreement=self.max_disagreement,
            )
            if not judge["ok"]:
                self._event(
                    "rerank_judge_rejected",
                    repo_id,
                    {
                        "candidate_count": len(indexed),
                        "judge": judge,
                    },
                )
                return candidates
        provenance_record["judge"] = judge

        rank_by_id = {
            item["id"]: (int(item["rank"]), order) for order, item in enumerate(raw["items"])
        }
        rationale_by_id = {
            item["id"]: _one_line(item.get("rationale", "")) for item in raw["items"]
        }
        risk_note_by_id = {
            item["id"]: _one_line(item.get("risk_note", ""))
            for item in raw["items"]
            if item.get("risk_note")
        }
        ordered = sorted(indexed, key=lambda item: (*rank_by_id[item["id"]], item["index"]))
        result: list[dict[str, Any]] = []
        for order, descriptor in enumerate(ordered):
            descriptor_index = descriptor.get("index")
            original = candidates[int(descriptor_index) if isinstance(descriptor_index, int) else 0]
            clone = dict(original)
            provenance = set(str(value) for value in clone.get("provenance", []))
            provenance.add("rerank:agent")
            clone["provenance"] = sorted(provenance)
            clone["rerank_order"] = order
            clone["rerank_id"] = descriptor["id"]
            clone["rerank_rationale"] = rationale_by_id.get(descriptor["id"], "")
            clone["rerank_provenance"] = provenance_record
            risk_note = risk_note_by_id.get(descriptor["id"])
            if risk_note:
                clone["rerank_risk_note"] = risk_note
            result.append(clone)
        self._event(
            "rerank_accepted",
            repo_id,
            {
                "candidate_count": len(indexed),
                "order_only": self.order_only,
                "first_ids": [item["id"] for item in ordered[:5]],
                "judge": judge,
                "rerank_provenance": provenance_record,
            },
        )
        self._event(
            "rerank_safety_floor_held",
            repo_id,
            {
                "candidate_count": len(indexed),
                "rerank_id": provenance_record["rerank_id"],
                "safety_floor_held": True,
            },
        )
        return result

    def _event(self, kind: str, ref: str | None, payload: dict[str, Any]) -> None:
        self.store.write_learning_event(phase="phase3", kind=kind, ref=ref, payload=payload)


def rerank_prompt(
    task: str,
    candidates: list[dict[str, Any]],
    *,
    order_only: bool = True,
) -> str:
    rules = [
        "Reorder the candidate ids for this coding task.",
        "Return strict JSON only with an items array.",
        "Use every input id exactly once. Do not add, remove, rename, or edit candidates.",
        "Attach one short rationale per id.",
        "Optionally attach risk_note when the rank depends on uncertain or risky context.",
    ]
    if order_only:
        rules.append("Only ranking may change; scores and candidate contents are fixed.")
    return "\n".join(
        [
            *rules,
            canonical_json({"task": task, "candidates": candidates}),
        ]
    )


def validate_rerank(raw: Any, expected_ids: list[str]) -> dict[str, Any]:
    if not isinstance(raw, dict):
        return {"ok": False, "reason": "non_object", "output_count": None}
    items = raw.get("items")
    if not isinstance(items, list):
        return {"ok": False, "reason": "missing_items", "output_count": None}
    output_ids = [item.get("id") for item in items if isinstance(item, dict)]
    if len(output_ids) != len(items):
        return {"ok": False, "reason": "invalid_item", "output_count": len(items)}
    if len(set(output_ids)) != len(output_ids):
        return {"ok": False, "reason": "duplicate_id", "output_count": len(output_ids)}
    if set(output_ids) != set(expected_ids):
        return {"ok": False, "reason": "set_mismatch", "output_count": len(output_ids)}
    ranks = [item.get("rank") for item in items if isinstance(item, dict)]
    if any(not isinstance(rank, int) or isinstance(rank, bool) or rank < 1 for rank in ranks):
        return {"ok": False, "reason": "invalid_rank", "output_count": len(output_ids)}
    for item in items:
        if (
            isinstance(item, dict)
            and "risk_note" in item
            and not isinstance(item["risk_note"], str)
        ):
            return {
                "ok": False,
                "reason": "invalid_risk_note",
                "output_count": len(output_ids),
            }
    return {"ok": True, "reason": "accepted", "output_count": len(output_ids)}


def candidate_id(item: dict[str, Any], index: int) -> str:
    return stable_id(
        "rerank",
        index,
        item.get("path") or "",
        item.get("category") or "",
        item.get("start_line") or 0,
        item.get("end_line") or 0,
    )


def _safety_floor(
    raw: dict[str, Any],
    indexed: list[dict[str, Any]],
    candidates: list[dict[str, Any]],
) -> dict[str, Any]:
    unsafe = {
        indexed[index]["id"]
        for index, candidate in enumerate(candidates)
        if _unsafe_candidate(candidate)
    }
    if not unsafe:
        return {"ok": True, "violations": []}
    clean = {item["id"] for item in indexed if item["id"] not in unsafe}
    ordered_ids = [
        item["id"]
        for item in sorted(raw["items"], key=lambda item: (int(item["rank"]), item["id"]))
    ]
    first_clean = min((ordered_ids.index(item_id) for item_id in clean), default=None)
    violations = []
    if first_clean is not None:
        for item_id in unsafe:
            unsafe_rank = ordered_ids.index(item_id)
            if unsafe_rank < first_clean:
                violations.append(
                    {
                        "candidate_id": item_id,
                        "rule": "unsafe_candidate_above_clean",
                        "reason": "learned rerank cannot promote quarantined, unsafe, or external non-authoritative context",
                    }
                )
    return {"ok": not violations, "violations": violations}


def _unsafe_candidate(item: dict[str, Any]) -> bool:
    status = str(item.get("status") or "").lower()
    trust = str(item.get("trust") or item.get("trust_tier") or "").lower()
    provenance = {str(value).lower() for value in item.get("provenance", []) or []}
    metadata = item.get("metadata") if isinstance(item.get("metadata"), dict) else {}
    defense = (
        metadata.get("defense_result") or metadata.get("memory_defense")
        if isinstance(metadata, dict)
        else {}
    )
    return bool(
        status in {"quarantined", "rejected", "expired", "needs_review"}
        or trust in {"unsafe", "untrusted"}
        or "unsafe" in provenance
        or "quarantined" in provenance
        or "external:non_authoritative" in provenance
        or (isinstance(defense, dict) and defense.get("serve_authoritative") is False)
    )


def _boosts(
    candidates: list[dict[str, Any]], decision_values: dict[int, dict[str, float]]
) -> dict[str, float]:
    memory = any("rerank:memory" in set(item.get("provenance", []) or []) for item in candidates)
    linked = [item for item in decision_values.values() if item["samples"] > 0]
    outcome_score = sum(item["score"] for item in linked) / len(linked) if linked else 0.0
    return {
        "outcome_boost": round(outcome_score, 6),
        "decision_value_samples": float(sum(item["samples"] for item in linked)),
        "memory_boost": 1.0 if memory else 0.0,
    }


def _decision_value_scores(store: Any, candidates: list[dict[str, Any]]) -> dict[int, dict[str, float]]:
    stats = {index: {"pass": 0.0, "fail": 0.0} for index in range(len(candidates))}
    events = _learning_events(store)
    for event in events:
        outcome = _event_outcome(event)
        if outcome is None:
            continue
        refs = _event_refs(event)
        for index, candidate in enumerate(candidates):
            if _candidate_matches_event(candidate, refs):
                stats[index][outcome] += 1.0
    scores: dict[int, dict[str, float]] = {}
    for index, value in stats.items():
        samples = value["pass"] + value["fail"]
        score = (value["pass"] / samples) if samples else 0.0
        scores[index] = {"score": round(score, 6), "samples": samples}
    return scores


def _learning_events(store: Any) -> list[dict[str, Any]]:
    reader = getattr(store, "learning_events", None)
    if not callable(reader):
        return []
    try:
        rows = reader(limit=1_000)
    except (AttributeError, KeyError, TypeError, RuntimeError, OSError):
        return []
    return [dict(row) for row in rows if isinstance(row, dict)]


def _event_outcome(event: dict[str, Any]) -> str | None:
    payload = _payload(event)
    text = " ".join(
        str(value)
        for value in (
            event.get("kind"),
            payload.get("result"),
            payload.get("status"),
            payload.get("outcome_result"),
            payload.get("terminal_status"),
        )
        if value is not None
    ).casefold()
    if any(token in text for token in ("pass", "passed", "success", "verified", "promoted")):
        return "pass"
    if any(token in text for token in ("fail", "failed", "reject", "rejected", "cancelled")):
        return "fail"
    return None


def _event_refs(event: dict[str, Any]) -> set[str]:
    payload = _payload(event)
    refs = {str(event.get("ref") or "")}
    for key in (
        "record_id",
        "memory_record_id",
        "outcome_id",
        "pack_id",
        "path",
    ):
        if payload.get(key):
            refs.add(str(payload[key]))
    for key in ("record_ids", "memory_record_ids", "recalled_memory_ids", "paths", "files_changed"):
        value = payload.get(key)
        if isinstance(value, list):
            refs.update(str(item) for item in value if item)
    return {item for item in refs if item}


def _candidate_matches_event(candidate: dict[str, Any], refs: set[str]) -> bool:
    candidate_refs = {
        str(candidate.get(key) or "")
        for key in ("id", "record_id", "memory_record_id", "path", "pack_id", "outcome_id")
    }
    metadata = candidate.get("metadata") if isinstance(candidate.get("metadata"), dict) else {}
    candidate_refs.update(str(metadata.get(key) or "") for key in ("record_id", "memory_record_id"))
    return bool(refs.intersection({item for item in candidate_refs if item}))


def _payload(event: dict[str, Any]) -> dict[str, Any]:
    payload = event.get("payload")
    if isinstance(payload, dict):
        return payload
    raw = event.get("payload_json")
    if not isinstance(raw, str):
        return {}
    try:
        parsed = json.loads(raw)
    except ValueError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _preview(text: str, limit: int = 500) -> str:
    return _one_line(text)[:limit]


def _one_line(text: str, limit: int = 200) -> str:
    return " ".join(str(text or "").strip().split())[:limit]
