from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

# Contrastive strategy distillation + usage-signal reweighting for memory.
#
# ReasoningBank/ExpeL show that distilling strategy memory from SUCCESS-vs-FAILURE pairs beats
# success-only routines (arXiv:2509.25140; ExpeL, AAAI 2024). Cognee's `memify` reinforces
# memories by how often/usefully they are retrieved, not just by time decay. Both are pure
# functions here; everything they emit is a candidate (generator != validator).


def contrastive_lessons(
    *,
    successes: Iterable[Mapping[str, Any]],
    failures: Iterable[Mapping[str, Any]],
    signal_key: str = "signals",
) -> dict[str, Any]:
    """Distill candidate strategy lessons by contrasting success and failure trajectories.

    Each trajectory exposes a set of discrete ``signals`` (e.g. files inspected, steps taken,
    checks run). Signals that appear in successes but rarely in failures become "do" lessons;
    signals frequent in failures but absent from successes become "avoid" lessons.
    """
    succ = [set(item.get(signal_key) or []) for item in successes]
    fail = [set(item.get(signal_key) or []) for item in failures]
    n_succ = len(succ) or 1
    n_fail = len(fail) or 1

    succ_freq: dict[str, int] = {}
    fail_freq: dict[str, int] = {}
    for s in succ:
        for sig in s:
            succ_freq[sig] = succ_freq.get(sig, 0) + 1
    for f in fail:
        for sig in f:
            fail_freq[sig] = fail_freq.get(sig, 0) + 1

    lessons: list[dict[str, Any]] = []
    for sig in sorted(set(succ_freq) | set(fail_freq)):
        sr = succ_freq.get(sig, 0) / n_succ
        fr = fail_freq.get(sig, 0) / n_fail
        lift = round(sr - fr, 4)
        if lift >= 0.5:
            lessons.append({"signal": sig, "polarity": "do", "lift": lift, "trust": "candidate"})
        elif lift <= -0.5:
            lessons.append({"signal": sig, "polarity": "avoid", "lift": lift, "trust": "candidate"})
    return {
        "ok": True,
        "schema_version": "persistmind.contrastive_lessons.v1",
        "successes": len(succ),
        "failures": len(fail),
        "lessons": lessons,
    }


def usage_reweight(
    *,
    base_confidence: float,
    retrievals: int,
    useful_uses: int,
    max_boost: float = 0.3,
) -> float:
    """Reinforce a memory's confidence by how usefully it has been retrieved (memify).

    Confidence rises with the ratio of useful uses to retrievals, capped at ``max_boost`` so
    usage can strengthen but never override the human/outcome-grounded base confidence.
    """
    base = max(0.0, min(1.0, float(base_confidence)))
    if retrievals <= 0:
        return round(base, 6)
    usefulness = max(0.0, min(1.0, useful_uses / retrievals))
    boost = max(0.0, max_boost) * usefulness
    return round(min(1.0, base + boost), 6)
