from __future__ import annotations

import fnmatch
import json
import subprocess
import tempfile
from collections.abc import Callable
from dataclasses import dataclass, replace
from pathlib import Path, PurePosixPath
from typing import Any

from persistmind.branding import PROTECTED_GOVERNANCE_PATHS
from persistmind.config import Settings
from persistmind.governance import CapabilityPolicy
from persistmind.learning._shell import run_shell
from persistmind.learning.judge import deterministic_first_judge
from persistmind.learning.provider import AgentProvider
from persistmind.utils import utc_now

PATCH_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["target", "diff", "rationale"],
    "properties": {
        "target": {"type": "string"},
        "diff": {"type": "string"},
        "rationale": {"type": "string"},
        "ancestor_run_id": {"type": "string"},
    },
    "additionalProperties": False,
}

DEFAULT_SELF_MOD_ALLOWLIST = [
    "src/persistmind/architecture/**",
    "src/persistmind/behavior/**",
    "src/persistmind/agents/routing.py",
    "src/persistmind/storage/source_service.py",
]

EXCLUDED_PATTERNS = [
    ".github/**",
    "migrations/**",
    "**/migrations/**",
    "src/persistmind/audit/**",
    "src/persistmind/eval/**",
    "src/persistmind/governance/**",
    "src/persistmind/learning/**",
    "src/persistmind/storage/resources/schemas/**",
    *sorted(PROTECTED_GOVERNANCE_PATHS),
]

SelfModValidator = Callable[[Path, str, str], dict[str, Any]]


@dataclass(frozen=True)
class SelfModPatch:
    target: str
    diff: str
    rationale: str
    touched_path: str
    source: str = "provider"
    ancestor_run_id: str | None = None


class SelfModEngine:
    def __init__(
        self,
        *,
        repo_root: Path,
        store: Any,
        settings: Settings,
        provider: AgentProvider | None = None,
        validator: SelfModValidator | None = None,
        model_family: str | None = None,
        budget_tokens: int | None = None,
    ):
        self.repo_root = repo_root
        self.store = store
        self.settings = settings
        self.provider = provider
        self.validator = validator
        self.model_family = model_family
        self.budget_tokens = budget_tokens

    def propose(
        self,
        *,
        target: str,
        weakness: str = "",
        patch: dict[str, Any] | None = None,
        ancestor_run_id: str | None = None,
    ) -> dict[str, Any]:
        selected_ancestor_run_id = ancestor_run_id or self._select_archive_ancestor(target)
        payload = patch or self._provider_patch(
            target=target,
            weakness=weakness,
            ancestor_run_id=selected_ancestor_run_id,
        )
        if payload is None:
            return {"ok": False, "reason": "no_patch_proposed", "target": target}
        normalized = normalize_patch(
            payload,
            allowlist=self.settings.learning.selfmod.allowlist,
            expected_target=target,
        )
        if not normalized["ok"]:
            run_id = self._archive_rejected(
                target=target,
                payload=payload,
                reason=normalized["reason"],
                details=normalized,
            )
            return {
                "ok": False,
                "reason": normalized["reason"],
                "run_id": run_id,
                "validation": normalized,
            }
        candidate: SelfModPatch = normalized["patch"]
        if selected_ancestor_run_id and not candidate.ancestor_run_id:
            candidate = replace(candidate, ancestor_run_id=selected_ancestor_run_id)
        validation = self.validate(candidate)
        gate = selfmod_gate(validation)
        run_id = self.store.write_learning_run(
            target=candidate.touched_path,
            kind="selfmod_variant",
            before={
                "target": candidate.touched_path,
                "base_commit": git_head(self.repo_root),
                "ancestor_run_id": candidate.ancestor_run_id,
            },
            after={
                "diff": candidate.diff,
                "rationale": candidate.rationale,
                "source": candidate.source,
                "touched_path": candidate.touched_path,
                "validation": validation,
            },
            train_metrics=validation.get("train_metrics", {}),
            holdout_metrics={
                "metrics": validation.get("holdout_metrics", {}),
                "gate": gate,
            },
            gate_pass=gate["pass"],
            archived=True,
            promoted=False,
        )
        self._event(
            "selfmod_variant",
            run_id,
            {
                "target": candidate.touched_path,
                "gate_pass": gate["pass"],
                "reason": gate.get("reason"),
                "ancestor_run_id": candidate.ancestor_run_id,
            },
        )
        return {
            "ok": True,
            "run_id": run_id,
            "target": candidate.touched_path,
            "gate": gate,
            "validation": validation,
            "diff": candidate.diff,
            "rationale": candidate.rationale,
        }

    def validate(self, candidate: SelfModPatch) -> dict[str, Any]:
        capacity = self._worktree_capacity()
        if not capacity["ok"]:
            return capacity
        with tempfile.TemporaryDirectory(prefix="persistmind-selfmod-") as tmp:
            worktree = Path(tmp) / "worktree"
            added = _run_git(
                self.repo_root,
                ["worktree", "add", "--detach", "--quiet", str(worktree), "HEAD"],
            )
            if added["exit_code"] != 0:
                return {"ok": False, "reason": "worktree_add_failed", "worktree": added}
            try:
                checked = _git_apply(worktree, candidate.diff, check=True)
                if checked["exit_code"] != 0:
                    return {
                        "ok": False,
                        "reason": "patch_apply_check_failed",
                        "apply": checked,
                    }
                applied = _git_apply(worktree, candidate.diff, check=False)
                if applied["exit_code"] != 0:
                    return {
                        "ok": False,
                        "reason": "patch_apply_failed",
                        "apply": applied,
                    }
                # Reward-hacking canary: reject diffs that game metrics (weaken assertions,
                # delete/skip tests, short-circuit gates) regardless of validation scores.
                from persistmind.eval.canaries import check_selfmod_canaries

                canary = check_selfmod_canaries(self.repo_root, candidate.diff)
                if not canary["ok"]:
                    return {
                        "ok": False,
                        "gate_pass": False,
                        "reason": "reward_hacking_canary_triggered",
                        "canary": canary,
                    }
                if self.validator is not None:
                    validation = self.validator(worktree, candidate.touched_path, candidate.diff)
                else:
                    validation = default_validate_worktree(
                        worktree=worktree,
                        target=candidate.touched_path,
                        settings=self.settings,
                    )
                validation.setdefault(
                    "ok", bool(validation.get("gate_pass", validation.get("ok", False)))
                )
                validation.setdefault(
                    "reason", "validated" if validation["ok"] else "validation_failed"
                )
                validation = self._judge_validation(candidate, validation)
                return validation
            finally:
                _run_git(self.repo_root, ["worktree", "remove", "--force", str(worktree)])

    def adopt(self, run_id: str, *, approved_by: str = "local-user") -> dict[str, Any]:
        row = self.store.learning_run(run_id)
        if row is None:
            raise KeyError(f"learning run not found: {run_id}")
        if row["kind"] != "selfmod_variant":
            raise ValueError("learning run is not a self-mod variant")
        if not bool(row["gate_pass"]):
            raise ValueError("cannot adopt self-mod run that failed validation gate")
        # Tamper tripwire: if a gating baseline was recorded, refuse to adopt when the gating
        # path (eval cases, judge, capabilities) changed out-of-band since that baseline.
        from persistmind.audit.chain import AuditLog

        integrity = AuditLog(self.store).verify_gating_integrity(self.repo_root)
        if integrity.get("reason") == "gating_fingerprint_mismatch":
            raise ValueError(
                "gating path changed since baseline; refusing self-mod adoption (possible tamper)"
            )
        before = parse_json(row["before_json"])
        after = parse_json(row["after_json"])
        if after.get("rejected_at"):
            raise ValueError("cannot adopt rejected self-mod run")
        normalized = normalize_patch(
            {
                "target": row["target"],
                "diff": after.get("diff", ""),
                "rationale": after.get("rationale", ""),
                "ancestor_run_id": before.get("ancestor_run_id") or "",
            },
            allowlist=self.settings.learning.selfmod.allowlist,
            expected_target=row["target"],
        )
        if not normalized["ok"]:
            raise ValueError(
                f"self-mod patch no longer passes safety checks: {normalized['reason']}"
            )
        target = normalized["patch"].touched_path
        target_path = self.repo_root / target
        pre_adopt_text = target_path.read_text(encoding="utf-8") if target_path.exists() else None
        checked = _git_apply(self.repo_root, normalized["patch"].diff, check=True)
        if checked["exit_code"] != 0:
            raise ValueError(f"self-mod patch no longer applies: {checked['stderr']}")
        applied = _git_apply(self.repo_root, normalized["patch"].diff, check=False)
        if applied["exit_code"] != 0:
            raise ValueError(f"self-mod patch apply failed: {applied['stderr']}")
        before = {
            **before,
            "pre_adopt_text": pre_adopt_text,
            "pre_adopt_recorded_at": utc_now(),
        }
        after = {
            **after,
            "adopted_by": approved_by,
            "adopted_at": utc_now(),
        }
        self.store.write_learning_run(
            run_id=run_id,
            target=row["target"],
            kind=row["kind"],
            before=before,
            after=after,
            train_metrics=parse_json(row["train_metrics_json"]),
            holdout_metrics=parse_json(row["holdout_metrics_json"]),
            gate_pass=True,
            archived=True,
            promoted=True,
        )
        self._event("selfmod_adopted", run_id, {"target": target, "approved_by": approved_by})
        return {
            "ok": True,
            "run_id": run_id,
            "target": target,
            "approved_by": approved_by,
        }

    def revert(self, run_id: str) -> dict[str, Any]:
        row = self.store.learning_run(run_id)
        if row is None:
            raise KeyError(f"learning run not found: {run_id}")
        if row["kind"] != "selfmod_variant":
            raise ValueError("learning run is not a self-mod variant")
        before = parse_json(row["before_json"])
        target = _normalize_path(row["target"])
        target_path = self.repo_root / target
        if "pre_adopt_text" in before:
            pre_adopt_text = before["pre_adopt_text"]
            if pre_adopt_text is None:
                if target_path.exists():
                    target_path.unlink()
            else:
                target_path.parent.mkdir(parents=True, exist_ok=True)
                target_path.write_text(str(pre_adopt_text), encoding="utf-8")
        else:
            after = parse_json(row["after_json"])
            reverted = _git_apply(
                self.repo_root, str(after.get("diff", "")), check=False, reverse=True
            )
            if reverted["exit_code"] != 0:
                raise ValueError(f"self-mod reverse apply failed: {reverted['stderr']}")
        self.store.unpromote_learning_run(run_id)
        self._event("selfmod_reverted", run_id, {"target": target})
        return {"ok": True, "run_id": run_id, "target": target}

    def reject(
        self,
        run_id: str,
        *,
        reason: str = "human rejected",
        rejected_by: str = "local-user",
    ) -> dict[str, Any]:
        row = self.store.learning_run(run_id)
        if row is None:
            raise KeyError(f"learning run not found: {run_id}")
        if row["kind"] != "selfmod_variant":
            raise ValueError("learning run is not a self-mod variant")
        before = parse_json(row["before_json"])
        after = {
            **parse_json(row["after_json"]),
            "rejected_by": rejected_by,
            "rejected_at": utc_now(),
            "rejection_reason": reason,
        }
        self.store.write_learning_run(
            run_id=run_id,
            target=row["target"],
            kind=row["kind"],
            before=before,
            after=after,
            train_metrics=parse_json(row["train_metrics_json"]),
            holdout_metrics=parse_json(row["holdout_metrics_json"]),
            gate_pass=bool(row["gate_pass"]),
            archived=True,
            promoted=False,
        )
        self._event(
            "selfmod_rejected",
            run_id,
            {"target": row["target"], "reason": reason, "rejected_by": rejected_by},
        )
        return {
            "ok": True,
            "run_id": run_id,
            "target": _normalize_path(row["target"]),
            "reason": reason,
            "rejected_by": rejected_by,
        }

    def _provider_patch(
        self,
        *,
        target: str,
        weakness: str,
        ancestor_run_id: str | None,
    ) -> dict[str, Any] | None:
        if self.provider is None:
            return None
        prompt = selfmod_prompt(
            target=target,
            weakness=weakness,
            allowlist=self.settings.learning.selfmod.allowlist,
            ancestor_run_id=ancestor_run_id,
            ancestor_context=self._ancestor_context(ancestor_run_id),
        )
        return self.provider.complete(
            prompt=prompt,
            role="selfmod",
            schema=PATCH_SCHEMA,
            model_family=self.model_family,
            budget_tokens=self.budget_tokens,
        )

    def _select_archive_ancestor(self, target: str) -> str | None:
        rows = self.store.learning_runs(target=target, kind="selfmod_variant", limit=20)
        for row in rows:
            if bool(row["archived"]) and bool(row["gate_pass"]):
                return row["run_id"]
        return None

    def _ancestor_context(self, run_id: str | None) -> dict[str, Any]:
        if not run_id:
            return {}
        row = self.store.learning_run(run_id)
        if row is None or row["kind"] != "selfmod_variant":
            return {"run_id": run_id, "available": False}
        before = parse_json(row["before_json"])
        after = parse_json(row["after_json"])
        return {
            "run_id": row["run_id"],
            "available": True,
            "target": row["target"],
            "gate_pass": bool(row["gate_pass"]),
            "promoted": bool(row["promoted"]),
            "ancestor_run_id": before.get("ancestor_run_id"),
            "rationale": str(after.get("rationale") or "")[:2000],
            "diff": str(after.get("diff") or "")[:12000],
            "validation": after.get("validation", {}),
        }

    def _judge_validation(
        self,
        candidate: SelfModPatch,
        validation: dict[str, Any],
    ) -> dict[str, Any]:
        if not self.settings.learning.selfmod.require_judge_gate:
            return validation
        if not validation.get("ok", False):
            return validation
        if self.provider is None:
            return {
                **validation,
                "ok": False,
                "gate_pass": False,
                "reason": "judge_provider_not_configured",
                "judge": {"ok": False, "reason": "judge_provider_not_configured"},
            }
        judge = deterministic_first_judge(
            name="selfmod_validation",
            deterministic={"ok": True, "reason": "selfmod_deterministic_gate_passed"},
            provider=self.provider,
            prompt_payload={
                "target": candidate.touched_path,
                "ancestor_run_id": candidate.ancestor_run_id,
                "rationale": candidate.rationale,
                "diff": candidate.diff[:12000],
                "validation": validation,
            },
            model_family=self.settings.learning.judge_model_family,
            budget_tokens=self.budget_tokens,
            votes=self.settings.learning.selfmod.judge_votes,
            min_pass_rate=self.settings.learning.selfmod.judge_min_pass_rate,
            fail_closed_on_disagreement=(
                self.settings.learning.selfmod.fail_closed_on_disagreement
            ),
            max_disagreement=self.settings.learning.selfmod.max_disagreement,
        )
        if judge["ok"]:
            return {**validation, "judge": judge}
        return {
            **validation,
            "ok": False,
            "gate_pass": False,
            "reason": "judge_gate_failed",
            "judge": judge,
            "holdout_metrics": {
                **validation.get("holdout_metrics", {}),
                "judge_ok": False,
                "success_rate_delta": -1.0,
            },
        }

    def _archive_rejected(
        self,
        *,
        target: str,
        payload: dict[str, Any],
        reason: str,
        details: dict[str, Any],
    ) -> str:
        run_id = self.store.write_learning_run(
            target=target,
            kind="selfmod_variant",
            before={"target": target, "base_commit": git_head(self.repo_root)},
            after={"proposal": payload, "rejection": details},
            train_metrics={},
            holdout_metrics={"gate": {"pass": False, "reason": reason}},
            gate_pass=False,
            archived=True,
            promoted=False,
        )
        self._event("selfmod_rejected", run_id, {"target": target, "reason": reason})
        return run_id

    def _event(self, kind: str, ref: str | None, payload: dict[str, Any]) -> None:
        self.store.write_learning_event(phase="phase5", kind=kind, ref=ref, payload=payload)

    def _worktree_capacity(self) -> dict[str, Any]:
        max_worktrees = int(self.settings.learning.selfmod.max_worktrees)
        active = self._active_validation_worktrees()
        if not active["ok"]:
            return active
        if active["count"] >= max_worktrees:
            return {
                "ok": False,
                "reason": "selfmod_worktree_cap_reached",
                "active_worktrees": active["count"],
                "max_worktrees": max_worktrees,
                "worktrees": active["worktrees"],
            }
        return {
            "ok": True,
            "active_worktrees": active["count"],
            "max_worktrees": max_worktrees,
        }

    def _active_validation_worktrees(self) -> dict[str, Any]:
        listed = _run_git(self.repo_root, ["worktree", "list", "--porcelain"])
        if listed["exit_code"] != 0:
            return {"ok": False, "reason": "worktree_list_failed", "worktree": listed}
        worktrees = []
        for line in listed["stdout"].splitlines():
            if not line.startswith("worktree "):
                continue
            path = line.removeprefix("worktree ").replace("\\", "/")
            if "persistmind-selfmod-" in path:
                worktrees.append(path)
        return {"ok": True, "count": len(worktrees), "worktrees": sorted(worktrees)}


def normalize_patch(
    payload: dict[str, Any],
    *,
    allowlist: list[str] | None = None,
    expected_target: str | None = None,
) -> dict[str, Any]:
    errors = _schema_errors(payload)
    if errors:
        return {"ok": False, "reason": "schema_validation", "errors": errors}
    target = _normalize_path(str(payload["target"]))
    if expected_target and target != _normalize_path(expected_target):
        return {
            "ok": False,
            "reason": "target_mismatch",
            "target": target,
            "expected_target": _normalize_path(expected_target),
        }
    diff = str(payload["diff"])
    touched = sorted(diff_touched_paths(diff))
    if not touched:
        return {"ok": False, "reason": "no_touched_paths"}
    if len(touched) != 1:
        return {"ok": False, "reason": "single_file_required", "touched_paths": touched}
    touched_path = touched[0]
    if touched_path != target:
        return {
            "ok": False,
            "reason": "target_mismatch",
            "target": target,
            "touched_path": touched_path,
        }
    if is_excluded_path(touched_path):
        return {"ok": False, "reason": "excluded_path", "path": touched_path}
    allowed = allowlist or DEFAULT_SELF_MOD_ALLOWLIST
    if not is_allowed_path(touched_path, allowed):
        return {
            "ok": False,
            "reason": "out_of_scope_path",
            "path": touched_path,
            "allowlist": allowed,
        }
    return {
        "ok": True,
        "patch": SelfModPatch(
            target=target,
            diff=diff,
            rationale=str(payload["rationale"]),
            touched_path=touched_path,
            ancestor_run_id=str(payload.get("ancestor_run_id") or "") or None,
        ),
        "touched_paths": touched,
    }


def diff_touched_paths(diff: str) -> set[str]:
    paths: set[str] = set()
    for raw in diff.splitlines():
        line = raw.strip()
        if line.startswith("diff --git "):
            parts = line.split()
            if len(parts) >= 4:
                for item in parts[2:4]:
                    path = _safe_normalize_diff_path(item)
                    if path:
                        paths.add(path)
        elif line.startswith("--- ") or line.startswith("+++ "):
            item = line[4:].split("\t", 1)[0].strip()
            path = _safe_normalize_diff_path(item)
            if path:
                paths.add(path)
    return paths


def is_allowed_path(path: str, allowlist: list[str]) -> bool:
    normalized = _normalize_path(path)
    return any(fnmatch.fnmatch(normalized, pattern.replace("\\", "/")) for pattern in allowlist)


def is_excluded_path(path: str) -> bool:
    normalized = _normalize_path(path)
    return any(fnmatch.fnmatch(normalized, pattern) for pattern in EXCLUDED_PATTERNS)


def selfmod_gate(validation: dict[str, Any]) -> dict[str, Any]:
    if not validation.get("ok", False):
        return {"pass": False, "reason": validation.get("reason", "validation_failed")}
    if validation.get("gate_pass") is False:
        return {"pass": False, "reason": "validator_gate_failed"}
    holdout = validation.get("holdout_metrics", {})
    if holdout.get("ok") is False or holdout.get("status") == "fail":
        return {"pass": False, "reason": "holdout_failed"}
    delta = holdout.get("success_rate_delta")
    if isinstance(delta, (int, float)) and delta < 0:
        return {"pass": False, "reason": "holdout_regression"}
    before = holdout.get("baseline_success_rate")
    after = holdout.get("success_rate")
    if isinstance(before, (int, float)) and isinstance(after, (int, float)) and after < before:
        return {"pass": False, "reason": "holdout_regression"}
    return {"pass": True, "reason": "holdout_passed"}


def default_validate_worktree(
    *,
    worktree: Path,
    target: str,
    settings: Settings,
) -> dict[str, Any]:
    command_results = [
        run_shell(
            command,
            cwd=worktree,
            timeout=settings.learning.selfmod.validation_timeout_seconds,
        )
        for command in settings.learning.selfmod.validation_commands
    ]
    tests_ok = all(result["exit_code"] == 0 for result in command_results)
    changed_paths = _git_changed_paths(worktree) or [target]
    policy = CapabilityPolicy(worktree, settings).check_paths(changed_paths)
    constitution_ok = policy["ok"] or not settings.learning.selfmod.require_constitution_gate
    constitution = {
        "ok": constitution_ok,
        "required": settings.learning.selfmod.require_constitution_gate,
        "changed_paths": changed_paths,
        "policy": policy,
    }
    benchmark = _benchmark_gate(worktree, settings)
    ok = tests_ok and constitution_ok and benchmark["ok"]
    tests_pass_rate = 1.0 if tests_ok else 0.0
    return {
        "ok": ok,
        "reason": "validated" if ok else "validation_failed",
        "commands": command_results,
        "policy": policy,
        "constitution": constitution,
        "benchmark": benchmark,
        "train_metrics": {"tests_pass_rate": tests_pass_rate},
        "holdout_metrics": {
            "ok": ok,
            "tests_pass_rate": tests_pass_rate,
            "constitution_ok": constitution_ok,
            "benchmark_ok": benchmark["ok"],
            "success_rate_delta": 0.0 if ok else -1.0,
        },
        "gate_pass": ok,
    }


def _benchmark_gate(worktree: Path, settings: Settings) -> dict[str, Any]:
    command = settings.learning.selfmod.benchmark_command.strip()
    required = settings.learning.selfmod.require_benchmark_gate
    if not command:
        return {
            "ok": not required,
            "required": required,
            "configured": False,
            "reason": (
                "benchmark_not_configured" if required else "benchmark_not_configured_optional"
            ),
        }
    result = run_shell(
        command,
        cwd=worktree,
        timeout=settings.learning.selfmod.benchmark_timeout_seconds,
    )
    report = parse_json(result.get("stdout", ""))
    gate_value = report.get("gate")
    gate: dict[str, Any] = gate_value if isinstance(gate_value, dict) else {}
    gate_status = str(gate.get("status") or gate.get("result") or "").lower()
    explicit_pass = gate.get("pass")
    report_ok = report.get("ok")
    ok = (
        result["exit_code"] == 0
        and explicit_pass is not False
        and report_ok is not False
        and gate_status not in {"fail", "failed", "regression"}
    )
    return {
        "ok": ok,
        "required": required,
        "configured": True,
        "reason": "benchmark_passed" if ok else "benchmark_failed",
        "command": result,
        "report": report,
        "gate": gate,
    }


def selfmod_prompt(
    *,
    target: str,
    weakness: str,
    allowlist: list[str],
    ancestor_run_id: str | None,
    ancestor_context: dict[str, Any] | None = None,
) -> str:
    return (
        "Propose one unified diff for a PersistMind experimental heuristic.\n"
        f"Target: {target}\n"
        f"Weakness signal: {weakness or 'unspecified'}\n"
        f"Allowed paths: {allowlist}\n"
        f"Ancestor run: {ancestor_run_id or 'none'}\n"
        f"Ancestor context: {json.dumps(ancestor_context or {}, sort_keys=True)}\n"
        "Return JSON matching PATCH_SCHEMA. The diff must touch exactly the target file."
    )


def parse_json(text: str) -> dict[str, Any]:
    try:
        value = json.loads(text or "{}")
    except Exception:
        return {}
    return value if isinstance(value, dict) else {}


def git_head(repo_root: Path) -> str | None:
    result = _run_git(repo_root, ["rev-parse", "HEAD"])
    return result["stdout"].strip() if result["exit_code"] == 0 else None


def _schema_errors(payload: Any) -> list[dict[str, str]]:
    errors: list[dict[str, str]] = []
    if not isinstance(payload, dict):
        return [{"path": "$", "message": "expected object"}]
    allowed = set(PATCH_SCHEMA["properties"])
    for key in PATCH_SCHEMA["required"]:
        if key not in payload:
            errors.append({"path": key, "message": "required field missing"})
    for key in payload:
        if key not in allowed:
            errors.append({"path": key, "message": "additional property not allowed"})
    for key in ["target", "diff", "rationale"]:
        if key in payload and not isinstance(payload[key], str):
            errors.append({"path": key, "message": "expected string"})
    return errors


def _safe_normalize_diff_path(path: str) -> str | None:
    path = path.strip().strip('"')
    if not path or path == "/dev/null":
        return None
    try:
        return _normalize_path(path)
    except ValueError:
        return None


def _normalize_path(path: str) -> str:
    normalized = path.replace("\\", "/").strip()
    if normalized.startswith("a/") or normalized.startswith("b/"):
        normalized = normalized[2:]
    pure = PurePosixPath(normalized)
    if pure.is_absolute() or any(part in {"", ".", ".."} for part in pure.parts):
        raise ValueError(f"unsafe path: {path}")
    return pure.as_posix()


def _git_apply(repo_root: Path, diff: str, *, check: bool, reverse: bool = False) -> dict[str, Any]:
    args = ["apply", "--whitespace=nowarn"]
    if check:
        args.append("--check")
    if reverse:
        args.append("-R")
    return _run_git(repo_root, args, stdin=diff)


def _git_changed_paths(repo_root: Path) -> list[str]:
    status = _run_git(repo_root, ["status", "--porcelain"])
    if status["exit_code"] != 0:
        return []
    paths: set[str] = set()
    for line in status["stdout"].splitlines():
        if not line.strip() or len(line) < 4:
            continue
        path = line[3:].strip()
        if " -> " in path:
            paths.update(part.strip() for part in path.split(" -> ", 1) if part.strip())
        elif path:
            paths.add(path)
    normalized = []
    for path in paths:
        if _is_tool_workspace_path(path):
            continue
        try:
            normalized.append(_normalize_path(path))
        except ValueError:
            continue
    return sorted(set(normalized))


def _is_tool_workspace_path(path: str) -> bool:
    normalized = path.replace("\\", "/")
    while normalized.startswith("./"):
        normalized = normalized[2:]
    return normalized in {".persistmind"} or normalized.startswith((".persistmind/",))


def _run_git(repo_root: Path, args: list[str], stdin: str | None = None) -> dict[str, Any]:
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=repo_root,
            input=stdin,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=120,
            check=False,
        )
        return {
            "command": ["git", *args],
            "exit_code": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "command": ["git", *args],
            "exit_code": 124,
            "stdout": exc.stdout or "",
            "stderr": exc.stderr or "timed out",
        }
