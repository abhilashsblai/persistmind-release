from __future__ import annotations

from pathlib import Path
from typing import Any

from persistmind.runtime.command_spec import CommandSpec


def run_shell(
    command: str | None,
    *,
    cwd: Path,
    timeout: int,
    env: dict[str, str] | None = None,
) -> dict[str, Any]:
    if not command:
        return {
            "command": "",
            "exit_code": 0,
            "timed_out": False,
            "stdout": "",
            "stderr": "",
        }
    result = CommandSpec.from_local_command(
        command,
        cwd=cwd,
        timeout=timeout,
        environment=env,
    ).run()
    return {"command": command, **result}


def format_command(command: str, values: dict[str, str]) -> str:
    quoted = {key: shell_quote(value) for key, value in values.items()}
    return command.format_map(_DefaultFormatMap(quoted))


def shell_quote(value: str) -> str:
    # Placeholders are parsed by CommandSpec with POSIX token rules on every
    # platform, so use one deterministic quoting scheme.
    import shlex

    return shlex.quote(value)


def trim(value: str | bytes, limit: int = 4000) -> str:
    if isinstance(value, bytes):
        value = value.decode("utf-8", errors="replace")
    if len(value) <= limit:
        return value
    return value[:limit] + "\n...[truncated]"


class _DefaultFormatMap(dict[str, str]):
    def __missing__(self, key: str) -> str:
        return "{" + key + "}"
