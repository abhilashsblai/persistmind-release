from __future__ import annotations

import json
from typing import Any

RUN_SCHEMA = "persistmind.self_improve_run.v1"
AUDIT_SCHEMA = "persistmind.self_improve_audit.v1"
BRIEF_SCHEMA = "persistmind.self_improve_brief.v1"
PROPOSAL_SCHEMA = "persistmind.self_improve_proposal.v1"
EVAL_SCHEMA = "persistmind.self_improve_eval.v1"
OVERSEER_SCHEMA = "persistmind.self_improve_overseer.v1"
LINEAGE_SCHEMA = "persistmind.self_improve_lineage.v1"


def json_value(value: str | None, fallback: Any) -> Any:
    try:
        return json.loads(value or "")
    except (TypeError, json.JSONDecodeError):
        return fallback


def run_row(row: Any | None) -> dict[str, Any] | None:
    if row is None:
        return None
    return {
        "schema_version": RUN_SCHEMA,
        "run_id": row["id"],
        "repo_id": row["repo_id"],
        "run_day": row["run_day"],
        "mode": row["mode"],
        "audit": json_value(row["audit_json"], {}),
        "brief_hash": row["brief_hash"],
        "status": row["status"],
        "created_at": row["created_at"],
    }


def proposal_row(row: Any | None) -> dict[str, Any] | None:
    if row is None:
        return None
    return {
        "schema_version": PROPOSAL_SCHEMA,
        "proposal_id": row["id"],
        "run_id": row["run_id"],
        "parent_id": row["parent_id"],
        "title": row["title"],
        "rationale": row["rationale"],
        "evidence": json_value(row["evidence_json"], {}),
        "target_files": json_value(row["target_files"], []),
        "predicted_effect": json_value(row["predicted_effect"], {}),
        "capability_verdict": row["capability_verdict"],
        "eval": json_value(row["eval_json"], None),
        "overseer": json_value(row["overseer_json"], None),
        "status": row["status"],
        "reward": {
            "run_id": row["reward_run_id"],
            "benchmark_version": row["benchmark_version"],
            "config_hash": row["config_hash"],
            "before": row["reward_before"],
            "after": row["reward_after"],
            "delta": row["reward_delta"],
            "retention_status": row["retention_status"],
            "safety_verified": bool(row["safety_verified"])
            if row["safety_verified"] is not None
            else False,
        },
        "created_at": row["created_at"],
        "decided_at": row["decided_at"],
    }


def flag_row(row: Any) -> dict[str, Any]:
    return {
        "flag_id": row["id"],
        "proposal_id": row["proposal_id"],
        "run_id": row["run_id"],
        "kind": row["kind"],
        "severity": row["severity"],
        "detail": row["detail"],
        "created_at": row["created_at"],
    }


def lineage_row(row: Any) -> dict[str, Any]:
    return {
        "schema_version": LINEAGE_SCHEMA,
        "lineage_id": row["id"],
        "proposal_id": row["proposal_id"],
        "parent_id": row["parent_id"],
        "clade_root": row["clade_root"],
        "before_metrics": json_value(row["before_metrics"], {}),
        "after_metrics": json_value(row["after_metrics"], {}),
        "clade_productivity": row["clade_productivity"],
        "effectiveness": json_value(row["effectiveness_json"], {}),
        "superseded_by": row["superseded_by"],
        "created_at": row["created_at"],
    }
