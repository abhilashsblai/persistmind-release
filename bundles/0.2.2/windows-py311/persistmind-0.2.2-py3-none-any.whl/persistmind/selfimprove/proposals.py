from __future__ import annotations

from typing import Any

from persistmind.governance import CapabilityPolicy


def capability_verdict(repo_root: Any, settings: Any, target_files: list[str]) -> dict[str, Any]:
    policy = CapabilityPolicy(repo_root, settings).check_paths(target_files)
    blocking = [item for item in policy.get("violations", []) if item.get("blocking")]
    warnings = [item for item in policy.get("violations", []) if not item.get("blocking")]
    verdict = "block" if blocking else "warn" if warnings else "allow"
    return {"verdict": verdict, "policy": policy}


def proposal_payload(
    *,
    title: str,
    rationale: str,
    target_files: list[str],
    evidence: dict[str, Any] | None = None,
    predicted_effect: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "title": title.strip(),
        "rationale": rationale.strip(),
        "target_files": sorted({path.replace("\\", "/") for path in target_files if path}),
        "evidence": evidence or {},
        "predicted_effect": predicted_effect or {},
    }
