from __future__ import annotations

from typing import Any

from persistmind.selfimprove.contracts import BRIEF_SCHEMA
from persistmind.utils import canonical_json, stable_id


def build_improvement_brief(audit: dict[str, Any], *, top_n: int = 5) -> dict[str, Any]:
    signals = audit.get("signals", {})
    doctor = signals.get("doctor", {})
    items = _rank_items(audit)[:top_n]
    lines = [
        "# PersistMind Self-Improvement Brief",
        "",
        f"Run day: {audit.get('run_day')}",
        f"Snapshot: {audit.get('snapshot_id')}",
        f"Doctor: status={doctor.get('status')} ready={doctor.get('ready_for_work')} setup={doctor.get('setup_status')}",
        "",
        "Focus areas:",
    ]
    if items:
        lines.extend(f"- {item['title']}: {item['detail']}" for item in items)
    else:
        lines.append("- No deterministic self-improvement findings above threshold.")
    text = "\n".join(lines) + "\n"
    return {
        "schema_version": BRIEF_SCHEMA,
        "brief_hash": stable_id(canonical_json(audit), text),
        "text": text,
        "items": items,
        "audit_hash": stable_id(canonical_json(audit)),
    }


def _rank_items(audit: dict[str, Any]) -> list[dict[str, Any]]:
    signals = audit.get("signals", {})
    doctor = signals.get("doctor", {})
    items: list[dict[str, Any]] = []
    if not doctor.get("ready_for_work", True):
        items.append(
            {
                "rank": 1,
                "kind": "doctor_not_ready",
                "title": "Resolve blocking doctor readiness",
                "detail": f"doctor status is {doctor.get('status')}",
                "evidence": {"doctor": doctor},
            }
        )
    if doctor.get("setup_status") == "advisory_incomplete":
        items.append(
            {
                "rank": 2,
                "kind": "setup_advisory_incomplete",
                "title": "Reduce setup ambiguity",
                "detail": "setup is operational but not complete",
                "evidence": {"doctor": doctor},
            }
        )
    for regression in audit.get("regressions", []):
        items.append(
            {
                "rank": 3,
                "kind": regression.get("kind"),
                "title": "Investigate regression",
                "detail": regression.get("kind", "unknown regression"),
                "evidence": regression,
            }
        )
    if int(signals.get("changed_path_count") or 0) > 20:
        items.append(
            {
                "rank": 4,
                "kind": "large_dirty_tree",
                "title": "Keep CTX validation scoped",
                "detail": f"{signals.get('changed_path_count')} changed paths are present",
                "evidence": {"changed_paths": signals.get("changed_paths", [])},
            }
        )
    return sorted(items, key=lambda item: int(item["rank"]))
