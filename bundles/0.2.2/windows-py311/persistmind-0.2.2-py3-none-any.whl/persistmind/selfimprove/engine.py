from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Callable

from persistmind.selfimprove.audit import collect_self_audit
from persistmind.selfimprove.brief import build_improvement_brief
from persistmind.selfimprove.contracts import (
    flag_row,
    json_value,
    lineage_row,
    proposal_row,
    run_row,
)
from persistmind.selfimprove.evaluate import evaluate_proposal, probe_sandbox_evaluation
from persistmind.selfimprove.lineage import clade_productivity, lineage_metrics
from persistmind.selfimprove.overseer import inspect_proposal
from persistmind.selfimprove.proposals import capability_verdict, proposal_payload
from persistmind.selfimprove.search import run_archive_search
from persistmind.selfimprove.trigger import maybe_run_daily
from persistmind.utils import stable_id, utc_now


class SelfImproveEngine:
    def __init__(self, service: Any, *, clock: Callable[[], str] | None = None):
        self.service = service
        self.repo_root = service.repo_root
        self.store = service.store
        self.settings = service.settings
        self.config = service.settings.learning.self_improve
        self._clock = clock or utc_now

    def status(self) -> dict[str, Any]:
        repo_id = self._repo_id()
        today = run_row(
            self.store.self_improve_run_for_day(
                repo_id=repo_id,
                run_day=self._run_day(),
            )
        )
        latest_row = self.store.latest_self_improve_run(repo_id)
        latest = run_row(latest_row)
        run_id = (today or latest or {}).get("run_id")
        proposals = self.store.self_improve_proposals(run_id=run_id, limit=100) if run_id else []
        flags = self.store.self_improve_flags(run_id=run_id) if run_id else []
        return {
            "ok": True,
            "enabled": bool(self.config.enabled),
            "mode": self.config.mode,
            "full_auto": bool(self.config.full_auto),
            "cadence": self.config.cadence,
            "today": today,
            "latest": latest,
            "lock": self._current_lock(_run_lock_dict(latest_row)),
            "proposal_counts": _counts(row["status"] for row in proposals),
            "blocking_flags": sum(1 for row in flags if row["severity"] == "block"),
            "prerequisites": self.prerequisites_ready(),
            "storage": self.service.db_backend_status(),
        }

    def audit(self, *, force: bool = False) -> dict[str, Any]:
        if not self.config.enabled:
            return {"ok": False, "reason": "self_improve_disabled"}
        if not force:
            existing = self._today_run()
            if existing is not None:
                audit = json_value(existing["audit_json"], {})
                return {
                    "ok": True,
                    "ran": False,
                    "run": run_row(existing),
                    "audit": audit,
                }
        previous = run_row(self.store.latest_self_improve_run(self._repo_id()))
        audit = collect_self_audit(
            self.service,
            now=self._clock(),
            previous=(previous or {}).get("audit"),
        )
        brief = build_improvement_brief(audit, top_n=self.config.brief_top_n)
        run_id = self.store.upsert_self_improve_run(
            repo_id=audit["repo_id"],
            run_day=audit["run_day"],
            mode=self.config.mode,
            audit=audit,
            brief_hash=brief["brief_hash"],
            status="audited",
        )
        self._event(
            "self_improve_audit",
            {
                "run_id": run_id,
                "brief_hash": brief["brief_hash"],
                "signals": audit.get("signals", {}),
            },
        )
        return {
            "ok": True,
            "ran": True,
            "run": run_row(self.store.self_improve_run(run_id)),
            "audit": audit,
        }

    def brief(self, *, force: bool = False) -> dict[str, Any]:
        audit_result = self.audit(force=force)
        if not audit_result.get("ok"):
            return audit_result
        audit = audit_result["audit"]
        brief = build_improvement_brief(audit, top_n=self.config.brief_top_n)
        run = audit_result["run"]
        if run:
            self.store.update_self_improve_run_status(run["run_id"], "briefed")
            run = run_row(self.store.self_improve_run(run["run_id"]))
        self._event(
            "self_improve_brief",
            {
                "run_id": (run or {}).get("run_id"),
                "brief_hash": brief["brief_hash"],
                "item_count": len(brief["items"]),
            },
        )
        return {
            "ok": True,
            "ran": audit_result.get("ran", False),
            "run": run,
            "brief": brief,
        }

    def maybe_run(self) -> dict[str, Any]:
        if not self.config.enabled:
            return {"ok": True, "ran": False, "reason": "self_improve_disabled"}
        if self.config.cadence != "daily":
            return {
                "ok": True,
                "ran": False,
                "reason": f"cadence_{self.config.cadence}_not_scheduled",
            }
        return maybe_run_daily(self)

    def capture(
        self,
        *,
        title: str,
        rationale: str,
        target_files: list[str],
        evidence: dict[str, Any] | None = None,
        predicted_effect: dict[str, Any] | None = None,
        parent_id: str | None = None,
    ) -> dict[str, Any]:
        payload = proposal_payload(
            title=title,
            rationale=rationale,
            target_files=target_files,
            evidence=evidence,
            predicted_effect=predicted_effect,
        )
        if not payload["title"] or not payload["rationale"]:
            raise ValueError("selfimprove propose requires --title and --rationale")
        run = self._ensure_run()
        capability = capability_verdict(self.repo_root, self.settings, payload["target_files"])
        has_diff = bool(str(payload["evidence"].get("diff") or "").strip())
        status = (
            "blocked"
            if capability["verdict"] == "block"
            else "captured"
            if has_diff
            else "needs_patch"
        )
        proposal_id = self.store.write_self_improve_proposal(
            run_id=run["run_id"],
            title=payload["title"],
            rationale=payload["rationale"],
            evidence=payload["evidence"],
            target_files=payload["target_files"],
            predicted_effect=payload["predicted_effect"],
            capability_verdict=capability["verdict"],
            parent_id=parent_id,
            status=status,
        )
        self.store.update_self_improve_run_status(run["run_id"], "proposed")
        proposal = proposal_row(self.store.self_improve_proposal(proposal_id))
        self._event(
            "self_improve_proposal",
            {
                "run_id": run["run_id"],
                "proposal_id": proposal_id,
                "capability": capability["verdict"],
            },
        )
        return {
            "ok": capability["verdict"] != "block",
            "proposal": proposal,
            "capability": capability,
        }

    def archive(
        self, *, run_id: str | None = None, status: str | None = None, limit: int = 50
    ) -> dict[str, Any]:
        return {
            "ok": True,
            "proposals": [
                proposal_row(row)
                for row in self.store.self_improve_proposals(
                    run_id=run_id, status=status, limit=limit
                )
            ],
        }

    def show(self, proposal_id: str) -> dict[str, Any]:
        proposal = proposal_row(self.store.self_improve_proposal(proposal_id))
        if proposal is None:
            raise KeyError(f"self-improve proposal not found: {proposal_id}")
        return {
            "ok": True,
            "proposal": proposal,
            "flags": [
                flag_row(row) for row in self.store.self_improve_flags(proposal_id=proposal_id)
            ],
            "lineage": [
                lineage_row(row) for row in self.store.self_improve_lineage(proposal_id=proposal_id)
            ],
        }

    def evaluate(
        self,
        proposal_id: str,
        *,
        commands: list[str] | None = None,
    ) -> dict[str, Any]:
        proposal = self._proposal(proposal_id)
        overseer = inspect_proposal(
            proposal,
            protected_globs=list(self.config.protected_path_globs),
        )
        for flag in overseer["flags"]:
            self.store.write_self_improve_flag(
                run_id=proposal["run_id"],
                proposal_id=proposal_id,
                kind=flag["kind"],
                severity=flag["severity"],
                detail=flag["detail"],
            )
        if proposal["capability_verdict"] == "block" or not overseer["ok"]:
            evaluation = {
                "schema_version": "persistmind.self_improve_eval.v1",
                "ok": False,
                "status": "blocked",
                "reason": "capability_or_overseer_blocked",
            }
            self.store.update_self_improve_proposal(
                proposal_id,
                status="blocked",
                eval_result=evaluation,
                overseer_result=overseer,
                decided=True,
            )
            return {
                "ok": False,
                "proposal": self.show(proposal_id)["proposal"],
                "eval": evaluation,
                "overseer": overseer,
            }
        selected = commands if commands is not None else list(self.config.validation_commands)
        evaluation = evaluate_proposal(
            self.repo_root,
            proposal,
            commands=selected,
            timeout=int(self.config.validation_timeout_seconds),
        )
        reward = self._persist_reward_evidence(
            proposal_id=proposal_id,
            proposal=proposal,
            evaluation=evaluation,
            overseer=overseer,
        )
        status = "validated" if evaluation.get("ok") else str(evaluation.get("status") or "failed")
        self.store.update_self_improve_proposal(
            proposal_id,
            status=status,
            eval_result={**evaluation, "reward": reward},
            overseer_result=overseer,
            reward_run_id=reward.get("run_id"),
            benchmark_version=reward.get("benchmark_version"),
            config_hash=reward.get("config_hash"),
            reward_before=reward.get("before"),
            reward_after=reward.get("after"),
            reward_delta=reward.get("delta"),
            retention_status=reward.get("retention_status"),
            safety_verified=reward.get("safety_verified"),
            decided=True,
        )
        return {
            "ok": bool(evaluation.get("ok")),
            "proposal": self.show(proposal_id)["proposal"],
            "eval": evaluation,
            "overseer": overseer,
        }

    def adopt(self, proposal_id: str) -> dict[str, Any]:
        proposal = self._refresh_reward_before_adoption(self._proposal(proposal_id))
        blockers = self._adoption_blockers(proposal)
        if blockers:
            return {
                "ok": False,
                "reason": "adoption_blocked",
                "blockers": blockers,
                "proposal": proposal,
            }
        before = lineage_metrics(proposal)
        after = {**before, "proposal_status": "adopted"}
        productivity = clade_productivity(after)
        lineage_id = self.store.write_self_improve_lineage(
            proposal_id=proposal_id,
            parent_id=proposal.get("parent_id"),
            clade_root=proposal.get("parent_id") or proposal_id,
            before_metrics=before,
            after_metrics=after,
            clade_productivity=productivity,
            effectiveness={"source": "adoption_gate", "score": productivity},
        )
        self.store.update_self_improve_proposal(proposal_id, status="adopted", decided=True)
        return {
            "ok": True,
            "proposal": self.show(proposal_id)["proposal"],
            "lineage_id": lineage_id,
            "clade_productivity": productivity,
        }

    def reject(self, proposal_id: str, *, reason: str = "") -> dict[str, Any]:
        self._proposal(proposal_id)
        self.store.update_self_improve_proposal(
            proposal_id,
            status="rejected",
            eval_result={
                "ok": False,
                "status": "rejected",
                "reason": reason or "human_rejected",
            },
            decided=True,
        )
        return {"ok": True, "proposal": self.show(proposal_id)["proposal"]}

    def rollback(self, proposal_id: str, *, reason: str = "") -> dict[str, Any]:
        self._proposal(proposal_id)
        self.store.update_self_improve_proposal(
            proposal_id,
            status="rolled_back",
            eval_result={
                "ok": False,
                "status": "rolled_back",
                "reason": reason or "rollback_requested",
            },
            decided=True,
        )
        return {"ok": True, "proposal": self.show(proposal_id)["proposal"]}

    def lineage(self, *, proposal_id: str | None = None, limit: int = 100) -> dict[str, Any]:
        return {
            "ok": True,
            "lineage": [
                lineage_row(row)
                for row in self.store.self_improve_lineage(proposal_id=proposal_id, limit=limit)
            ],
        }

    def run(
        self,
        *,
        auto: bool = False,
        max_iters: int | None = None,
        budget_tokens: int | None = None,
    ) -> dict[str, Any]:
        if auto or self.config.full_auto or self.config.mode == "full-auto":
            lock = self._acquire_run_lock(owner="self-improve-run")
            if not lock["ok"]:
                return {
                    "ok": False,
                    "status": "blocked",
                    "reason": "self_improve_run_locked",
                    "lock": lock["lock"],
                }
            try:
                return run_archive_search(
                    self,
                    max_iters=max_iters or int(self.config.max_iters),
                    budget_tokens=budget_tokens or int(self.config.budget_tokens),
                )
            finally:
                self._release_run_lock(lock["run_id"], owner="self-improve-run")
        return self.brief(force=True)

    def doctor(self) -> dict[str, Any]:
        prereq = self.prerequisites_ready()
        return {
            "ok": True,
            "enabled": bool(self.config.enabled),
            "mode": self.config.mode,
            "full_auto": bool(self.config.full_auto),
            "prerequisites": prereq,
        }

    def verify_safety(self, *, confirm: bool = False, actor: str = "local-user") -> dict[str, Any]:
        if not confirm:
            return {
                "ok": False,
                "reason": "confirmation_required",
                "schema_version": "persistmind.self_improve_verify_safety.v1",
            }
        checks = {
            "advisory_engine": self._probe_advisory_engine(),
            "sandbox_evaluation": probe_sandbox_evaluation(self.repo_root),
            "overseer": self._probe_overseer(),
            "lineage": self._probe_lineage(),
        }
        if not all(bool(item.get("ok")) for item in checks.values()):
            return {
                "ok": False,
                "reason": "safety_prerequisites_failed",
                "checks": checks,
                "schema_version": "persistmind.self_improve_verify_safety.v1",
            }
        event_id = self.store.write_learning_event(
            phase="selfimprove",
            kind="safety_verified",
            ref=self._repo_id(),
            payload={
                "actor": actor,
                "mode": self.config.mode,
                "full_auto": bool(self.config.full_auto),
                "checks": checks,
                "git_rev": self.service.resolver.current_identity().base_commit_sha,
            },
        )
        return {
            "ok": True,
            "schema_version": "persistmind.self_improve_verify_safety.v1",
            "event_id": event_id,
            "actor": actor,
            "checks": checks,
        }

    def prerequisites_ready(self) -> dict[str, Any]:
        safety_verified = self._safety_verified()
        checks = {
            "advisory_engine": self._probe_advisory_engine(),
            "sandbox_evaluation": probe_sandbox_evaluation(self.repo_root),
            "overseer": self._probe_overseer(),
            "lineage": self._probe_lineage(),
            "safety_verified": {
                "ok": safety_verified["ok"],
                "status": "pass" if safety_verified["ok"] else "not_verified",
                "source": safety_verified["source"],
            },
        }
        ok = all(bool(item.get("ok")) for item in checks.values())
        return {
            "ok": ok,
            "checks": checks,
            "full_auto_allowed": bool(self.config.full_auto and ok),
        }

    def _repo_id(self) -> str:
        return self.service.resolver.current_identity().repo_id

    def _safety_verified(self) -> dict[str, Any]:
        if bool(self.config.safety_verified):
            return {"ok": True, "source": "config"}
        for row in self.store.learning_events(ref=self._repo_id(), limit=100):
            if row["phase"] == "selfimprove" and row["kind"] == "safety_verified":
                return {"ok": True, "source": "learning_event"}
        return {"ok": False, "source": "missing"}

    def _run_day(self) -> str:
        return self._clock()[:10]

    def _today_run(self) -> Any | None:
        return self.store.self_improve_run_for_day(
            repo_id=self._repo_id(),
            run_day=self._run_day(),
        )

    def _ensure_run(self) -> dict[str, Any]:
        row = self._today_run()
        if row is not None:
            return run_row(row) or {}
        result = self.brief(force=True)
        return result["run"]

    def _proposal(self, proposal_id: str) -> dict[str, Any]:
        proposal = proposal_row(self.store.self_improve_proposal(proposal_id))
        if proposal is None:
            raise KeyError(f"self-improve proposal not found: {proposal_id}")
        return proposal

    def _adoption_blockers(self, proposal: dict[str, Any]) -> list[str]:
        blockers: list[str] = []
        if proposal.get("capability_verdict") == "block":
            blockers.append("capability_policy_block")
        evaluation = proposal.get("eval") or {}
        if not evaluation.get("ok"):
            blockers.append("evaluation_not_passed")
        overseer = proposal.get("overseer") or {}
        if any(flag.get("severity") == "block" for flag in overseer.get("flags", [])):
            blockers.append("overseer_block")
        if not self._safety_verified()["ok"]:
            blockers.append("safety_not_verified")
        reward = proposal.get("reward") or {}
        if reward.get("run_id") is None:
            blockers.append("reward_evidence_missing")
        elif float(reward.get("delta") or 0.0) <= 0.0:
            blockers.append("reward_not_positive")
        if reward.get("retention_status") != "pass":
            blockers.append("retention_not_passed")
        if reward.get("safety_verified") is not True:
            blockers.append("reward_safety_not_verified")
        return blockers

    def _refresh_reward_before_adoption(self, proposal: dict[str, Any]) -> dict[str, Any]:
        evaluation = proposal.get("eval") or {}
        if not evaluation.get("ok"):
            return proposal
        overseer = proposal.get("overseer") or {}
        reward = proposal.get("reward") or {}
        current_safety_ok = self._safety_verified()["ok"]
        needs_refresh = reward.get("retention_status") != "pass" or bool(
            reward.get("safety_verified")
        ) != bool(current_safety_ok)
        if not needs_refresh:
            return proposal
        refreshed = self._persist_reward_evidence(
            proposal_id=proposal["proposal_id"],
            proposal=proposal,
            evaluation=evaluation,
            overseer=overseer,
        )
        self.store.update_self_improve_proposal(
            proposal["proposal_id"],
            eval_result={**evaluation, "reward": refreshed},
            reward_run_id=refreshed.get("run_id"),
            benchmark_version=refreshed.get("benchmark_version"),
            config_hash=refreshed.get("config_hash"),
            reward_before=refreshed.get("before"),
            reward_after=refreshed.get("after"),
            reward_delta=refreshed.get("delta"),
            retention_status=refreshed.get("retention_status"),
            safety_verified=refreshed.get("safety_verified"),
        )
        return self._proposal(proposal["proposal_id"])

    def _persist_reward_evidence(
        self,
        *,
        proposal_id: str,
        proposal: dict[str, Any],
        evaluation: dict[str, Any],
        overseer: dict[str, Any],
    ) -> dict[str, Any]:
        snapshot = self.service.resolver.resolve()
        safety = self._safety_verified()
        eval_ok = bool(evaluation.get("ok"))
        overseer_ok = bool(overseer.get("ok"))
        safety_ok = bool(safety.get("ok"))
        before = 0.0
        after = round(
            (0.60 if eval_ok else 0.0)
            + (0.25 if overseer_ok else 0.0)
            + (0.15 if safety_ok else 0.0),
            6,
        )
        benchmark_version = "persistmind.self_improve_sandbox_reward.v1"
        config_hash = stable_id(
            "self_improve_reward_config",
            benchmark_version,
            proposal_id,
            eval_ok,
            overseer_ok,
            safety_ok,
            tuple(self.config.validation_commands),
            self.config.validation_timeout_seconds,
        )
        run_id = self.store.write_bench_reward(
            repo_id=snapshot.repo_id,
            snapshot_id=snapshot.snapshot_id,
            benchmark_version=benchmark_version,
            config_hash=config_hash,
            headline=after,
            split="holdout",
            metrics={
                "sandbox_eval_ok": 1.0 if eval_ok else 0.0,
                "overseer_ok": 1.0 if overseer_ok else 0.0,
                "safety_verified": 1.0 if safety_ok else 0.0,
                "proposal_reward": after,
            },
            git_rev=self.service.resolver.current_identity().base_commit_sha,
        )
        retention = self.service.retention_check(
            task_set="selfimprove",
            run_id=run_id,
        )
        retention_status = "pass" if retention.get("ok") else str(retention.get("reason") or "fail")
        return {
            "schema_version": "persistmind.self_improve_reward_evidence.v1",
            "proposal_id": proposal_id,
            "run_id": run_id,
            "benchmark_version": benchmark_version,
            "config_hash": config_hash,
            "before": before,
            "after": after,
            "delta": round(after - before, 6),
            "retention_status": retention_status,
            "retention": retention,
            "safety_verified": safety_ok,
            "source": "sandbox_evaluation",
            "target_files": proposal.get("target_files") or [],
        }

    def _acquire_run_lock(self, *, owner: str, ttl_seconds: int = 900) -> dict[str, Any]:
        run = self._ensure_run()
        run_id = str(run["run_id"])
        now = self._clock()
        expires_at = _iso_plus(now, ttl_seconds)
        with self.store.conn:
            row = self.store.self_improve_run(run_id)
            lock = self._current_lock(_run_lock_dict(row))
            if lock:
                return {"ok": False, "run_id": run_id, "lock": lock}
            self.store.conn.execute(
                """
                UPDATE self_improve_runs
                SET lock_owner = ?, lock_expires_at = ?
                WHERE id = ?
                """,
                (owner, expires_at, run_id),
            )
        return {
            "ok": True,
            "run_id": run_id,
            "lock": {"owner": owner, "expires_at": expires_at},
        }

    def _release_run_lock(self, run_id: str, *, owner: str) -> None:
        with self.store.conn:
            self.store.conn.execute(
                """
                UPDATE self_improve_runs
                SET lock_owner = NULL, lock_expires_at = NULL
                WHERE id = ? AND lock_owner = ?
                """,
                (run_id, owner),
            )

    def _current_lock(self, run: dict[str, Any] | None) -> dict[str, Any] | None:
        if not run:
            return None
        owner = run.get("lock_owner")
        expires_at = run.get("lock_expires_at")
        if not owner or not expires_at:
            return None
        if str(expires_at) <= self._clock():
            return None
        return {"owner": owner, "expires_at": expires_at}

    def _probe_advisory_engine(self) -> dict[str, Any]:
        try:
            build_improvement_brief(
                {
                    "run_day": self._run_day(),
                    "snapshot_id": "probe",
                    "signals": {"doctor": {"status": "probe"}},
                    "regressions": [],
                },
                top_n=1,
            )
        except Exception as exc:  # noqa: BLE001 - probe reports readiness.
            return {"ok": False, "status": "fail", "error": str(exc)}
        return {"ok": True, "status": "pass"}

    def _probe_overseer(self) -> dict[str, Any]:
        try:
            result = inspect_proposal(
                {
                    "target_files": ["src/persistmind/selfimprove/engine.py"],
                    "evidence": {"diff": "diff --git a/eval/gate.py b/eval/gate.py\n"},
                },
                protected_globs=list(self.config.protected_path_globs),
            )
        except Exception as exc:  # noqa: BLE001 - probe reports readiness.
            return {"ok": False, "status": "fail", "error": str(exc)}
        protected = any(flag.get("kind") == "protected-path" for flag in result["flags"])
        metric = any(flag.get("kind") == "metric-gaming" for flag in result["flags"])
        return {
            "ok": protected and metric and not result["ok"],
            "status": "pass" if protected and metric and not result["ok"] else "fail",
            "flags": result["flags"],
        }

    def _probe_lineage(self) -> dict[str, Any]:
        try:
            metrics = lineage_metrics(
                {
                    "status": "validated",
                    "eval": {"ok": True, "status": "passed"},
                    "overseer": {"flags": []},
                }
            )
            productivity = clade_productivity(metrics)
        except Exception as exc:  # noqa: BLE001 - probe reports readiness.
            return {"ok": False, "status": "fail", "error": str(exc)}
        ok = bool(metrics.get("eval_ok")) and productivity > 0
        return {
            "ok": ok,
            "status": "pass" if ok else "fail",
            "metrics": metrics,
            "clade_productivity": productivity,
        }

    def _event(self, event_type: str, payload: dict[str, Any]) -> None:
        try:
            self.store.append_audit(
                pack_id=f"self-improve:{payload.get('run_id') or 'none'}",
                payload={"kind": event_type, **payload},
            )
        except Exception:
            return


def _counts(values: Any) -> dict[str, int]:
    counts: dict[str, int] = {}
    for value in values:
        counts[str(value)] = counts.get(str(value), 0) + 1
    return counts


def _iso_plus(value: str, seconds: int) -> str:
    try:
        base = datetime.fromisoformat(value)
    except ValueError:
        base = datetime.now(timezone.utc)
    if base.tzinfo is None:
        base = base.replace(tzinfo=timezone.utc)
    return (base + timedelta(seconds=max(1, int(seconds)))).isoformat(timespec="seconds")


def _run_lock_dict(row: Any | None) -> dict[str, Any] | None:
    if row is None:
        return None
    return {
        "lock_owner": row["lock_owner"],
        "lock_expires_at": row["lock_expires_at"],
    }
