from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path
from typing import Any, cast

from persistmind.runtime.command_spec import CommandSpec, minimal_environment
from persistmind.selfimprove.contracts import EVAL_SCHEMA


def evaluate_proposal(
    repo_root: Path,
    proposal: dict[str, Any],
    *,
    commands: list[str],
    timeout: int,
) -> dict[str, Any]:
    evidence = proposal.get("evidence") or {}
    diff = str(evidence.get("diff") or "")
    if not diff.strip():
        return {
            "schema_version": EVAL_SCHEMA,
            "ok": False,
            "status": "needs_patch",
            "reason": "proposal_diff_required",
            "attempts": [],
        }
    attempts: list[dict[str, Any]] = []
    with tempfile.TemporaryDirectory(prefix="persistmind-si-") as tmp:
        worktree = Path(tmp) / "worktree"
        added = _run(
            ["git", "worktree", "add", "--detach", "--quiet", str(worktree), "HEAD"],
            cwd=repo_root,
            timeout=60,
        )
        if added["returncode"] != 0:
            return {
                "schema_version": EVAL_SCHEMA,
                "ok": False,
                "status": "failed",
                "reason": "worktree_add_failed",
                "attempts": [added],
            }
        try:
            checked = _run(
                ["git", "apply", "--check", "-"],
                cwd=worktree,
                timeout=60,
                stdin=diff,
            )
            if checked["returncode"] != 0:
                return {
                    "schema_version": EVAL_SCHEMA,
                    "ok": False,
                    "status": "failed",
                    "reason": "patch_apply_check_failed",
                    "attempts": [checked],
                }
            applied = _run(["git", "apply", "-"], cwd=worktree, timeout=60, stdin=diff)
            attempts.append(applied)
            if applied["returncode"] != 0:
                return {
                    "schema_version": EVAL_SCHEMA,
                    "ok": False,
                    "status": "failed",
                    "reason": "patch_apply_failed",
                    "attempts": attempts,
                }
            for command in commands:
                result = _run(command, cwd=worktree, timeout=timeout)
                attempts.append(result)
                if result["returncode"] != 0:
                    return {
                        "schema_version": EVAL_SCHEMA,
                        "ok": False,
                        "status": "failed",
                        "reason": "command_failed",
                        "attempts": attempts,
                    }
            return {
                "schema_version": EVAL_SCHEMA,
                "ok": True,
                "status": "passed",
                "reason": "validated",
                "attempts": attempts,
            }
        finally:
            _run(
                ["git", "worktree", "remove", "--force", str(worktree)],
                cwd=repo_root,
                timeout=60,
            )


def probe_sandbox_evaluation(repo_root: Path) -> dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix="persistmind-si-probe-") as tmp:
        worktree = Path(tmp) / "worktree"
        added = _run(
            ["git", "worktree", "add", "--detach", "--quiet", str(worktree), "HEAD"],
            cwd=repo_root,
            timeout=60,
        )
        removed: dict[str, Any] | None = None
        if added["returncode"] == 0:
            removed = _run(
                ["git", "worktree", "remove", "--force", str(worktree)],
                cwd=repo_root,
                timeout=60,
            )
        ok = added["returncode"] == 0 and (removed is None or removed["returncode"] == 0)
        return {
            "ok": ok,
            "status": "pass" if ok else "fail",
            "worktree_add": _brief_attempt(added),
            "worktree_remove": _brief_attempt(removed) if removed else None,
        }


def _run(
    args: str | list[str],
    *,
    cwd: Path,
    timeout: int,
    stdin: str | None = None,
) -> dict[str, Any]:
    if isinstance(args, str):
        if stdin is not None:
            raise ValueError("structured local commands do not accept standard input")
        try:
            command_result = CommandSpec.from_local_command(
                args,
                cwd=cwd,
                timeout=timeout,
            ).run()
        except (FileNotFoundError, ValueError) as exc:
            return {
                "command": args,
                "returncode": 1,
                "stdout_tail": "",
                "stderr_tail": str(exc),
            }
        return {
            "command": command_result["argv"],
            "returncode": int(cast(Any, command_result.get("exit_code") or 0)),
            "stdout_tail": str(command_result["stdout"])[-4000:],
            "stderr_tail": str(command_result["stderr"])[-4000:],
            "executable_sha256": command_result["executable_sha256"],
        }
    try:
        result = subprocess.run(
            args,
            cwd=cwd,
            shell=False,
            env=minimal_environment(),
            input=stdin,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False,
        )
    except (FileNotFoundError, subprocess.SubprocessError) as exc:
        return {
            "command": args if isinstance(args, str) else " ".join(args),
            "returncode": 1,
            "stdout_tail": "",
            "stderr_tail": str(exc),
        }
    return {
        "command": args if isinstance(args, str) else " ".join(args),
        "returncode": result.returncode,
        "stdout_tail": result.stdout[-2000:],
        "stderr_tail": result.stderr[-2000:],
    }


def _brief_attempt(attempt: dict[str, Any] | None) -> dict[str, Any] | None:
    if attempt is None:
        return None
    return {
        "command": attempt.get("command"),
        "returncode": attempt.get("returncode"),
        "stderr_tail": attempt.get("stderr_tail", "")[-300:],
    }
