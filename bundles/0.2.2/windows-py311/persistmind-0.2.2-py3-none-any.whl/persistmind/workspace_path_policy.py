from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path, PureWindowsPath


@dataclass(frozen=True)
class WorkspacePathPolicy:
    repo_root: Path
    workspace: Path
    relative: str
    parent_path: Path
    parent_identity: tuple[int, int]

    def recheck_parent(self) -> None:
        """Fail if the validated parent was swapped or became a reparse point."""

        _reject_reparse(self.parent_path)
        current = _identity(self.parent_path)
        if current != self.parent_identity:
            raise RuntimeError(
                "workspace parent identity changed after validation; refusing mutation"
            )


def validate_workspace_path(repo_root: Path, configured: str) -> WorkspacePathPolicy:
    """Validate a project-local workspace without trusting path resolution alone.

    The lexical checks run first so traversal and absolute paths cannot be made
    harmless-looking by ``resolve()``. Existing components are then inspected
    for symlinks, junctions, and Windows reparse points before containment is
    established.
    """

    # Configuration/status callers may inspect a registered project path that
    # has not been created yet. Lexical containment remains enforceable without
    # mutating that path; installer entrypoints separately require an existing
    # repository before invoking this policy.
    repo = Path(repo_root).expanduser().resolve(strict=False)
    raw = str(configured).strip()
    if not raw:
        raise ValueError("workspace path must not be empty")
    windows = PureWindowsPath(raw)
    path = Path(raw).expanduser()
    if path.is_absolute() or windows.is_absolute() or windows.drive:
        raise ValueError("workspace path must be relative to the repository")
    lexical_parts = [part for part in raw.replace("\\", "/").split("/") if part]
    if (
        not lexical_parts
        or raw in {".", ".."}
        or any(part in {".", ".."} for part in lexical_parts)
    ):
        raise ValueError("workspace path must not be current-directory or parent traversal")

    candidate = repo.joinpath(*lexical_parts)
    _reject_reparse_chain(repo, lexical_parts)
    resolved = candidate.resolve(strict=False)
    try:
        relative = resolved.relative_to(repo)
    except ValueError as exc:
        raise ValueError("workspace path must remain inside the repository") from exc
    if not relative.parts:
        raise ValueError("workspace path must not be the repository root")
    anchor = Path(resolved.anchor).resolve(strict=False)
    if resolved == anchor:
        raise ValueError("workspace path must not be a filesystem root")
    try:
        home = Path.home().resolve(strict=True)
    except OSError:
        home = Path.home().resolve(strict=False)
    if resolved == home:
        raise ValueError("workspace path must not be the user home")

    parent = _nearest_existing_parent(candidate.parent)
    _reject_reparse(parent)
    return WorkspacePathPolicy(
        repo_root=repo,
        workspace=resolved,
        relative=relative.as_posix(),
        parent_path=parent,
        parent_identity=_identity(parent),
    )


def _reject_reparse_chain(repo: Path, parts: list[str]) -> None:
    current = repo
    _reject_reparse(current)
    for part in parts:
        current = current / part
        if current.exists() or current.is_symlink():
            _reject_reparse(current)
        else:
            break


def _reject_reparse(path: Path) -> None:
    if path.is_symlink():
        raise ValueError(f"workspace path contains a symlink or reparse point: {path}")
    is_junction = getattr(path, "is_junction", None)
    if callable(is_junction) and is_junction():
        raise ValueError(f"workspace path contains a symlink or reparse point: {path}")
    try:
        attributes = int(getattr(path.lstat(), "st_file_attributes", 0))
    except OSError:
        return
    if attributes & 0x400:  # FILE_ATTRIBUTE_REPARSE_POINT
        raise ValueError(f"workspace path contains a symlink or reparse point: {path}")


def _nearest_existing_parent(path: Path) -> Path:
    current = path
    while not current.exists():
        if current.parent == current:
            raise ValueError("workspace path has no existing parent")
        current = current.parent
    return current


def _identity(path: Path) -> tuple[int, int]:
    stat_result = os.stat(path, follow_symlinks=False)
    return int(stat_result.st_dev), int(stat_result.st_ino)
