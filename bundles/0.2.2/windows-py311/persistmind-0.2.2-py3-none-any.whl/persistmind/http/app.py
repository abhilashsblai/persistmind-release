from __future__ import annotations

import hashlib
import json
import os
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, cast
from urllib.parse import urlparse

from persistmind.composition.registry import OperationClient
from persistmind.http.auth import (
    authenticate_http,
    browser_request_allowed,
    validate_server_auth,
    validate_server_bind,
)
from persistmind.http.query import (
    bool_value as _bool,
)
from persistmind.http.query import (
    bounded_int as _bounded_int,
)
from persistmind.http.query import (
    csv as _csv,
)
from persistmind.http.query import (
    query_params as _query_params,
)
from persistmind.interfaces import exception_result, finalize_result, http_status_for_result
from persistmind.product import render_dashboard_html
from persistmind.security.actions import http_route_action
from persistmind.security.context import principal_scope
from persistmind.security.principals import Principal
from persistmind.security.rbac import require_authorized
from persistmind.storage.activity_service import ActivityService
from persistmind.storage.audit_service import AuditService
from persistmind.storage.control import (
    StorageControlPlane,
    WorkspaceMigrationRequired,
)
from persistmind.storage.knowledge_service import KnowledgeConflict, KnowledgeService
from persistmind.storage.learning_service import LearningConflict, LearningService
from persistmind.storage.pack_service import PackService
from persistmind.storage.policy_service import PolicyService
from persistmind.storage.runtime import StorageNotInitialized
from persistmind.storage.runtime_policy import SQLiteRuntimeUnsupported
from persistmind.storage.source_service import SourceService
from persistmind.storage.task_service import TaskConflict, TaskService

# Serializes mutating requests in the live server so concurrent agents never
# collide on the single SQLite writer. Read (GET) requests are not gated.
_WRITE_LOCK = threading.Lock()
_MAX_BODY_BYTES = 1_048_576
_MAX_RESPONSE_BYTES = 2_097_152
_MAX_HTTP_WORKERS = 16
_REQUEST_TIMEOUT_SECONDS = 30.0
_MAX_PAGE_SIZE = 1000
_TASK_PREFIXES = ("/v1/tasks", "/v1/plans", "/v1/continuations")
_PACK_PREFIXES = ("/v1/context-pack", "/v1/packs")
_LEARNING_PREFIXES = ("/v1/learning/manifest", "/v1/learning/versions")
_ACTIVITY_PREFIXES = ("/v1/activity", "/v1/outcomes")
PUBLIC_HTTP_READ_ROUTES = frozenset({"/v1/health"})


class BoundedThreadingHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 32

    def __init__(self, *args: Any, max_workers: int = _MAX_HTTP_WORKERS, **kwargs: Any) -> None:
        self._worker_slots = threading.BoundedSemaphore(max(1, max_workers))
        super().__init__(*args, **kwargs)

    def process_request(self, request: Any, client_address: Any) -> None:
        self._worker_slots.acquire()
        try:
            super().process_request(request, client_address)
        except BaseException:
            self._worker_slots.release()
            raise

    def process_request_thread(self, request: Any, client_address: Any) -> None:
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._worker_slots.release()


def handle_http_request(
    service: Any,
    method: str,
    path: str,
    body: dict[str, Any] | None = None,
    *,
    authorized: bool = True,
    principal: Principal | None = None,
) -> tuple[int, dict[str, Any]]:
    with principal_scope(principal):
        return _handle_http_request(
            service,
            method,
            path,
            body,
            authorized=authorized,
            principal=principal,
        )


def _handle_http_request(
    service: Any,
    method: str,
    path: str,
    body: dict[str, Any] | None = None,
    *,
    authorized: bool = True,
    principal: Principal | None = None,
) -> tuple[int, dict[str, Any]]:
    method = method.upper()
    payload = dict(body or {})
    if principal is not None:
        payload = _bind_principal_identity(payload, principal)
    parsed = urlparse(path)
    route = parsed.path.rstrip("/") or "/"
    query = _query_params(parsed.query)
    if "limit" in query:
        query["limit"] = str(_int(query["limit"], 100))
    if "limit" in payload:
        payload["limit"] = max(1, min(int(payload["limit"]), _MAX_PAGE_SIZE))
    parts = [part for part in route.split("/") if part]
    try:
        if method == "GET" and route == "/v1/health":
            return 200, {"ok": True}
        if parts[:2] == ["v1", "incidents"] or parts == ["v1", "feedback"]:
            if not authorized:
                return _unauthorized()
            from persistmind.reporting.service import ReportingService

            repo_root = Path(service.repo_root)
            mutating = method != "GET"
            with ReportingService(repo_root, create=mutating) as reporting:
                if method == "GET" and parts == ["v1", "incidents"]:
                    return 200, reporting.list(
                        kind=query.get("kind"),
                        status=query.get("status"),
                        severity=query.get("severity"),
                        category=query.get("category"),
                        limit=_int(query.get("limit"), 100),
                    )
                if method == "POST" and parts == ["v1", "incidents"]:
                    return 201, reporting.create_incident(**payload)
                if method == "GET" and len(parts) == 3:
                    return 200, reporting.show(parts[2])
                if method == "GET" and len(parts) == 4 and parts[3] == "validate":
                    result = reporting.validate(parts[2])
                    return (200 if result.get("ok") else 422), result
                if method == "POST" and len(parts) == 4 and parts[3] == "export":
                    return 200, reporting.export(
                        parts[2],
                        reviewer=str(payload.get("reviewed_by") or ""),
                        include_diagnostics=bool(payload.get("include_diagnostics", False)),
                        acknowledge_warnings=bool(payload.get("acknowledge_warnings", False)),
                    )
                if method == "POST" and parts == ["v1", "feedback"]:
                    return 201, reporting.feedback(
                        str(payload["reference"]),
                        rating=int(payload["rating"]),
                        reason=str(payload["reason"]),
                        summary=payload.get("summary"),
                    )
            return 404, {"ok": False, "status": "not_found"}
        if method == "GET" and route == "/v1/storage/topology":
            return 200, service.storage_topology()
        if method == "GET" and route == "/v1/storage/status":
            return 200, service.storage_status()
        if method == "GET" and route == "/v1/storage/resources":
            return 200, service.storage_resources_verify()
        if method == "GET" and route == "/v1/storage/memory-kinds":
            return 200, service.storage_memory_kinds()
        if method == "GET" and route == "/v1/storage/roles":
            return 200, service.storage_roles()
        if method == "GET" and route == "/v1/storage/models":
            return 200, service.storage_models_status()
        if method == "GET" and route == "/v1/storage/keys":
            return 200, service.storage_keys_status()
        if method == "GET" and route == "/v1/storage/schema":
            return 200, service.storage_schema_status()
        if method == "GET" and route == "/v1/storage/partitions":
            return 200, service.storage_partitions()
        if method == "POST" and route == "/v1/storage/partitions/rotate":
            if not authorized:
                return _unauthorized()
            if principal is None:
                raise PermissionError("partition rotation requires a transport-bound principal")
            require_authorized(principal, "storage.partition.rotate", service.repo_root)
            return 200, service.storage_partition_rotate(str(payload["role"]))
        if method == "POST" and route == "/v1/storage/repair":
            if not authorized:
                return _unauthorized()
            if principal is None:
                raise PermissionError("storage repair requires a transport-bound principal")
            require_authorized(principal, "storage.repair", service.repo_root)
            return 200, service.storage_repair(dry_run=bool(payload.get("dry_run", True)))
        if method == "POST" and route == "/v1/storage/gc":
            if not authorized:
                return _unauthorized()
            return 200, service.storage_gc(dry_run=bool(payload.get("dry_run", True)))
        if method == "POST" and route == "/v1/storage/retention":
            if not authorized:
                return _unauthorized()
            if not bool(payload.get("dry_run", True)):
                if principal is None:
                    raise PermissionError("retention apply requires a transport-bound principal")
                require_authorized(principal, "storage.retention.apply", service.repo_root)
            return 200, service.storage_retention(
                dry_run=bool(payload.get("dry_run", True)),
                keep_days=int(payload.get("keep_days", 30)),
            )
        if method == "POST" and route == "/v1/storage/export":
            if not authorized:
                return _unauthorized()
            return 200, service.storage_export(
                str(payload["scope"]), output=Path(str(payload["output"]))
            )
        if method == "POST" and route == "/v1/storage/delete":
            if not authorized:
                return _unauthorized()
            if not bool(payload.get("dry_run", True)):
                if principal is None:
                    raise PermissionError("storage delete requires a transport-bound principal")
                require_authorized(principal, "storage.delete", service.repo_root)
            return 200, service.storage_delete(
                str(payload["scope"]), dry_run=bool(payload.get("dry_run", True))
            )
        if method == "GET" and route == "/v1/storage/verify":
            result = service.storage_verify(full=query.get("full", "false").lower() == "true")
            return (200 if result.get("ok") else 409), result
        if method == "POST" and route == "/v1/storage/reconcile":
            if not authorized:
                return _unauthorized()
            return 200, service.storage_reconcile(limit=int(payload.get("limit", 100)))
        if method == "POST" and route == "/v1/storage/bootstrap":
            if not authorized:
                return _unauthorized()
            return 200, service.storage_bootstrap()
        if method == "POST" and route == "/v1/storage/backups":
            if not authorized:
                return _unauthorized()
            return 200, service.storage_backup_create(verify=bool(payload.get("verify", False)))
        if method == "GET" and len(parts) == 4 and parts[:3] == ["v1", "storage", "backups"]:
            return 200, service.storage_backup_verify(parts[3])
        if (
            method == "POST"
            and len(parts) == 5
            and parts[:3] == ["v1", "storage", "backups"]
            and parts[4] == "restore-stage"
        ):
            if not authorized:
                return _unauthorized()
            if bool(payload.get("verify_only", False)):
                return 200, service.storage_backup_verify(parts[3])
            if not bool(payload.get("confirm", False)):
                raise PermissionError("backup restore requires confirm=true")
            target = payload.get("target")
            if not isinstance(target, str) or not target.strip():
                raise ValueError("backup restore requires a target workspace root")
            return 200, service.storage_backup_restore_stage(parts[3], target=Path(target))
        if method == "POST" and route == "/v1/storage/catalog/recover":
            if not authorized:
                return _unauthorized()
            return 200, service.storage_catalog_recover()
        if (
            method == "GET"
            and route == "/v1/learning/manifest"
            and isinstance(service, LearningService)
        ):
            return 200, service.active_manifest()
        if (
            method == "GET"
            and route == "/v1/learning/versions"
            and isinstance(service, LearningService)
        ):
            return 200, service.versions(
                skill_id=query.get("skill_id"), limit=_int(query.get("limit"), 100)
            )
        if (
            method == "POST"
            and route == "/v1/learning/versions"
            and isinstance(service, LearningService)
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.version_propose(
                skill_id=str(payload["skill_id"]),
                benchmark_id=str(payload["benchmark_id"]),
                artifact_ref=payload.get("artifact_ref"),
                content=payload.get("content"),
                classification=str(payload.get("classification", "internal")),
            )
        if (
            method == "GET"
            and len(parts) == 4
            and parts[:3] == ["v1", "learning", "versions"]
            and isinstance(service, LearningService)
        ):
            return _status_from_ok(service.version_show(parts[3]))
        if (
            method == "POST"
            and len(parts) == 5
            and parts[:3] == ["v1", "learning", "versions"]
            and parts[4] == "evaluations"
            and isinstance(service, LearningService)
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.evaluation_record(
                parts[3],
                metrics=payload.get("metrics") or {},
                passed=bool(payload.get("passed")),
                benchmark_id=payload.get("benchmark_id"),
            )
        if (
            method == "POST"
            and len(parts) == 5
            and parts[:3] == ["v1", "learning", "versions"]
            and parts[4] in {"promote", "rollback"}
            and isinstance(service, LearningService)
        ):
            if not authorized:
                return _unauthorized()
            if principal is None:
                raise PermissionError("learning activation requires a transport-bound principal")
            require_authorized(principal, "learning.promote", service.repo_root)
            actor = str(payload.get("actor", "http"))
            signature = str(payload.get("signature") or "")
            if parts[4] == "promote":
                from persistmind.application.learning_requests import (
                    promotion_payload_kwargs,
                )

                return 200, service.promote(
                    parts[3],
                    **promotion_payload_kwargs(payload, default_actor=actor),
                )
            return 200, service.rollback(parts[3], approver=actor, signature=signature)
        if (
            method == "POST"
            and len(parts) == 5
            and parts[:3] == ["v1", "learning", "versions"]
            and parts[4] == "canary"
            and isinstance(service, LearningService)
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.canary_evaluate(
                parts[3],
                metrics=payload.get("metrics") or {},
                minimum_pass_rate=float(payload.get("minimum_pass_rate", 0.95)),
                maximum_regression=float(payload.get("maximum_regression", 0.02)),
            )
        if (
            method == "POST"
            and len(parts) == 5
            and parts[:3] == ["v1", "learning", "versions"]
            and parts[4] == "propagate"
            and isinstance(service, LearningService)
        ):
            if not authorized:
                return _unauthorized()
            if principal is None:
                raise PermissionError("learning propagation requires a transport-bound principal")
            require_authorized(principal, "learning.promote", service.repo_root)
            return 200, service.propagate(
                parts[3],
                targets=[str(item) for item in payload.get("targets") or []],
                approver=str(payload.get("actor", "http")),
                signature=str(payload.get("signature") or ""),
            )
        if method == "GET" and route == "/v1/audit/verify" and isinstance(service, AuditService):
            return 200, service.verify_audit()
        if method == "GET" and route == "/v1/audit/tip" and isinstance(service, AuditService):
            return 200, service.audit_tip()
        if (
            method == "GET"
            and route == "/v1/audit/gating-verify"
            and isinstance(service, AuditService)
        ):
            return _status_from_ok(service.verify_gating_integrity())
        if (
            method == "POST"
            and route == "/v1/audit/gating-baseline"
            and isinstance(service, AuditService)
        ):
            if not authorized:
                return _unauthorized()
            if principal is None:
                raise PermissionError("audit baseline requires a transport-bound principal")
            require_authorized(principal, "audit.gating_baseline", service.repo_root)
            return 200, service.record_gating_baseline(actor=str(payload.get("actor", "http")))
        if method == "POST" and route == "/v1/audit/rotate" and isinstance(service, AuditService):
            if not authorized:
                return _unauthorized()
            if principal is None:
                raise PermissionError("audit rotation requires a transport-bound principal")
            require_authorized(principal, "storage.partition.rotate", service.repo_root)
            return 200, service.rotate_partition(
                actor=str(payload.get("actor", "http")),
                signature=str(payload.get("signature") or ""),
            )
        if (
            method == "GET"
            and len(parts) == 3
            and parts[:2] == ["v1", "audit"]
            and isinstance(service, AuditService)
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.get_audit_record(parts[2])
        if (
            method == "POST"
            and route == "/v1/activity/events"
            and isinstance(service, ActivityService)
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.append_event(
                str(payload["event_type"]),
                payload.get("payload") or {},
                idempotency_key=payload.get("idempotency_key"),
                event_id=payload.get("event_id"),
                occurred_at=payload.get("occurred_at"),
                classification=str(payload.get("classification", "internal")),
            )
        if (
            method == "GET"
            and route == "/v1/activity/events"
            and isinstance(service, ActivityService)
        ):
            return 200, service.events(
                event_type=query.get("event_type"),
                since=query.get("since"),
                limit=_int(query.get("limit"), 100),
            )
        if (
            method == "GET"
            and len(parts) == 4
            and parts[:3] == ["v1", "activity", "events"]
            and isinstance(service, ActivityService)
        ):
            return _status_from_ok(service.event(parts[3], hydrate=query.get("hydrate") == "true"))
        if method == "POST" and route == "/v1/outcomes" and isinstance(service, ActivityService):
            if not authorized:
                return _unauthorized()
            return 200, service.record_outcome(
                str(payload["task_session_id"]),
                str(payload["result"]),
                pack_id=payload.get("pack_id"),
                files_changed=list(payload.get("files_changed") or []),
                summary=payload.get("summary"),
                actor=str(payload.get("actor", "http")),
                episode_eligible=bool(payload.get("episode_eligible", False)),
                evaluation_version_id=payload.get("evaluation_version_id"),
            )
        if (
            method == "POST"
            and route == "/v1/activity/rotate"
            and isinstance(service, ActivityService)
        ):
            if not authorized:
                return _unauthorized()
            if principal is None:
                raise PermissionError("activity rotation requires a transport-bound principal")
            require_authorized(principal, "storage.partition.rotate", service.repo_root)
            return 200, service.rotate_partition()
        if method == "POST" and route == "/v1/source/build" and isinstance(service, SourceService):
            if not authorized:
                return _unauthorized()
            return 200, service.build()
        if method == "GET" and route == "/v1/source/status" and isinstance(service, SourceService):
            return 200, service.status()
        if method == "GET" and route == "/v1/source/search" and isinstance(service, SourceService):
            return 200, service.search(
                str(query.get("q") or ""), limit=_int(query.get("limit"), 20)
            )
        if method == "POST" and route == "/v1/source/impact" and isinstance(service, SourceService):
            return 200, service.impact(
                list(payload.get("paths") or []), limit=_int(payload.get("limit"), 1000)
            )
        if method == "GET" and route == "/v1/policies" and isinstance(service, PolicyService):
            return 200, service.policy_applicable(query.get("scope"))
        if (
            method == "POST"
            and len(parts) == 5
            and parts[:3] == ["v1", "policies", "business-rules"]
            and parts[4] == "approve"
            and isinstance(service, PolicyService)
        ):
            if not authorized:
                return _unauthorized()
            if principal is None:
                raise PermissionError("policy approval requires a transport-bound principal")
            require_authorized(principal, "policy.approve", service.repo_root)
            return 200, service.policy_approve_business_rule(
                parts[3],
                approver=str(payload.get("approved_by", "http")),
                signature=str(payload.get("signature") or ""),
            )
        if method == "POST" and route == "/v1/tasks":
            if not authorized:
                return _unauthorized()
            return 200, service.task_start(str(payload["task"]))
        if method == "GET" and len(parts) == 3 and parts[:2] == ["v1", "tasks"]:
            return _status_from_ok(service.task_show(parts[2]))
        if (
            method == "POST"
            and len(parts) == 4
            and parts[:2] == ["v1", "tasks"]
            and parts[3] == "transition"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.task_transition(
                parts[2],
                str(payload["state"]),
                actor=str(payload.get("actor", "http-agent")),
                reason=payload.get("reason"),
                pack_id=payload.get("pack_id"),
            )
        if (
            method == "POST"
            and len(parts) == 4
            and parts[:2] == ["v1", "tasks"]
            and parts[3] == "remediation-attempt"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.remediation_attempt_record(
                parts[2],
                gate_id=str(payload.get("gate_id") or payload.get("gate") or ""),
                approach=str(payload.get("approach") or ""),
                outcome=str(payload.get("outcome") or ""),
                command_or_tool=payload.get("command_or_tool"),
                error=payload.get("error"),
                waited_seconds=_int(payload.get("waited_seconds"), 0),
                backoff_strategy=payload.get("backoff_strategy"),
                transient_recovery=payload.get("transient_recovery"),
                actor=str(payload.get("actor", "http-agent")),
            )
        if (
            method == "POST"
            and len(parts) == 4
            and parts[:2] == ["v1", "tasks"]
            and parts[3] == "close"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.task_close(
                parts[2],
                result=str(payload.get("result") or ""),
                reason=str(payload.get("reason") or ""),
                blocking_gate_id=payload.get("blocking_gate_id") or payload.get("blocking_gate"),
                actor=str(payload.get("actor", "http-agent")),
            )
        if method == "POST" and route == "/v1/plans/validate":
            if not authorized:
                return _unauthorized()
            return 200, service.plan_validate(
                dict(payload["plan"]),
                task_session_id=payload.get("task_session_id"),
                pack_id=payload.get("pack_id"),
            )
        if method == "POST" and route == "/v1/plans":
            if not authorized:
                return _unauthorized()
            return 200, service.plan_create(
                str(payload["task_session_id"]),
                dict(payload["plan"]),
                pack_id=payload.get("pack_id"),
                author=str(payload.get("author", "http-agent")),
            )
        if method == "GET" and len(parts) == 3 and parts[:2] == ["v1", "plans"]:
            return _status_from_ok(service.plan_show(parts[2]))
        if method == "PATCH" and len(parts) == 3 and parts[:2] == ["v1", "plans"]:
            if not authorized:
                return _unauthorized()
            return 200, service.plan_amend(
                parts[2],
                dict(payload["plan"]),
                author=str(payload.get("author", "http-agent")),
                reason=payload.get("reason"),
            )
        if (
            method == "POST"
            and len(parts) == 4
            and parts[:2] == ["v1", "plans"]
            and parts[3] == "checkpoints"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.plan_checkpoint(
                parts[2],
                str(payload["step_id"]),
                paths=list(payload.get("paths") or []),
            )
        if method == "GET" and route == "/v1/dashboard":
            return 200, service.dashboard_data()
        if method == "GET" and route == "/v1/metrics":
            return 200, service.bench()
        if method == "GET" and route == "/v1/capabilities":
            return 200, service.capability_matrix(query.get("format", "json"))
        if method == "POST" and route == "/v1/capabilities/claims/check":
            if not authorized:
                return _unauthorized()
            return 200, service.capability_claims_check(payload.get("claim"))
        if method == "GET" and route == "/v1/teacher/runtime":
            return 200, service.teacher_runtime_status(
                run_id=query.get("run_id"),
                task_session_id=query.get("task_session_id"),
            )
        if method == "POST" and route == "/v1/teacher/runtime":
            if not authorized:
                return _unauthorized()
            return 200, service.teacher_runtime_start(
                str(payload["task_session_id"]),
                str(payload["task"]),
                pack_id=payload.get("pack_id"),
                agent_session_id=payload.get("agent_session_id"),
            )
        if (
            method == "GET"
            and len(parts) == 5
            and parts[:3] == ["v1", "teacher", "runtime"]
            and parts[4] == "obligations"
        ):
            return 200, service.teacher_runtime_obligations(parts[3], query.get("status"))
        if method == "POST" and route == "/v1/teacher/runtime/resolve":
            if not authorized:
                return _unauthorized()
            return 200, service.teacher_runtime_resolve(
                str(payload["obligation_id"]),
                str(payload["evidence_ref"]),
                str(payload.get("actor", "http-agent")),
            )
        if method == "GET" and len(parts) == 4 and parts[:3] == ["v1", "teacher", "brief"]:
            return 200, service.teach_brief(parts[3])
        if method == "POST" and route == "/v1/teacher/events":
            if not authorized:
                return _unauthorized()
            return 200, service.teach_event(
                str(payload["event_type"]),
                str(payload.get("source", "http")),
                str(payload["summary"]),
                task_session_id=payload.get("task_session_id"),
                privacy_class=str(payload.get("privacy_class", "summary_only")),
            )
        if method == "POST" and route in {"/v1/teacher/exams", "/v1/teacher/reflections"}:
            if not authorized:
                return _unauthorized()
            task_session_id = str(payload["task_session_id"])
            body = dict(payload.get("exam") or payload.get("reflection") or payload)
            body.pop("task_session_id", None)
            if route.endswith("exams"):
                return 200, service.teach_exam(task_session_id, body)
            return 200, service.teach_reflection(task_session_id, body)
        if method == "GET" and route == "/v1/teacher/lessons":
            return 200, service.lesson_list(query.get("status"))
        if (
            method == "POST"
            and len(parts) == 5
            and parts[:3] == ["v1", "teacher", "lessons"]
            and parts[4] == "decision"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.lesson_decide(
                parts[3],
                str(payload["decision"]),
                str(payload.get("actor", "professional-teacher:http")),
                str(payload.get("rationale", "")),
            )
        if method == "GET" and route == "/v1/teacher/student":
            return 200, service.student_profile(query.get("agent_kind", "codex"))
        if method == "POST" and route == "/v1/teacher/curriculum":
            if not authorized:
                return _unauthorized()
            return 200, service.curriculum_recommend(
                str(payload["task_session_id"]), str(payload["objective"])
            )
        if method == "GET" and route == "/v1/teacher/graph":
            return 200, service.graph_status(query.get("branch"))
        if method == "POST" and route == "/v1/teacher/graph/update":
            if not authorized:
                return _unauthorized()
            return 200, service.graph_update(
                list(payload.get("paths") or []),
                branch=payload.get("branch"),
                deleted_paths=list(payload.get("deleted_paths") or []),
                renames=dict(payload.get("renames") or {}),
                source_ref=payload.get("source_ref"),
            )
        if method == "POST" and route == "/v1/teacher/graph/query":
            return 200, service.graph_query(
                str(payload.get("query", "")),
                graph_version_id=payload.get("graph_version_id"),
                node_type=payload.get("node_type"),
                limit=int(payload.get("limit", 50)),
                budget_ms=int(payload.get("budget_ms", 100)),
            )
        if method == "GET" and route == "/v1/teacher/reviews":
            return 200, service.teacher_review_list(query.get("status", "pending"))
        if method == "POST" and route == "/v1/teacher/reviews":
            if not authorized:
                return _unauthorized()
            return 200, service.teacher_review_request(
                str(payload["item_type"]),
                str(payload["item_id"]),
                str(payload.get("requested_by", "http-agent")),
                risk=str(payload.get("risk", "medium")),
            )
        if (
            method == "POST"
            and len(parts) == 5
            and parts[:3] == ["v1", "teacher", "reviews"]
            and parts[4] == "decision"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.teacher_review_decide(
                parts[3],
                str(payload["decision"]),
                str(payload["actor"]),
                str(payload.get("role", "professional_teacher")),
                str(payload.get("rationale", "")),
            )
        if method == "POST" and route == "/v1/teacher/orchestrations":
            if not authorized:
                return _unauthorized()
            return 200, service.orchestration_create(
                str(payload["parent_task_session_id"]),
                str(payload["objective"]),
                list(payload.get("tasks") or []),
                dependencies=list(payload.get("dependencies") or []),
                strategy=str(payload.get("strategy", "parallel")),
                budget=dict(payload.get("budget") or {}),
            )
        if method == "GET" and len(parts) == 4 and parts[:3] == ["v1", "teacher", "orchestrations"]:
            return 200, service.orchestration_status(parts[3])
        if method == "POST" and route == "/v1/teacher/benchmarks/suites":
            if not authorized:
                return _unauthorized()
            return 200, service.teacher_benchmark_suite_create(
                str(payload["name"]),
                str(payload.get("version", "1")),
                str(payload.get("purpose", "teacher evaluation")),
                list(payload.get("tasks") or []),
                config=dict(payload.get("config") or {}),
            )
        if method == "POST" and route == "/v1/teacher/benchmarks/runs":
            if not authorized:
                return _unauthorized()
            body = dict(payload)
            suite_id = str(body.pop("suite_id"))
            return 200, service.teacher_benchmark_run_start(suite_id, **body)
        if method == "POST" and route == "/v1/teacher/benchmarks/compare":
            return 200, service.teacher_benchmark_compare(
                str(payload["baseline_run_id"]),
                str(payload["candidate_run_id"]),
                dict(payload.get("thresholds") or {}),
            )
        if method == "POST" and route == "/v1/teacher/claims":
            if not authorized:
                return _unauthorized()
            return 200, service.teacher_claim_evaluate(
                str(payload["claim"]),
                str(payload["candidate_run_id"]),
                baseline_run_id=payload.get("baseline_run_id"),
            )
        if (
            method == "GET"
            and len(parts) == 5
            and parts[:3] == ["v1", "teacher", "benchmarks"]
            and parts[4] == "release-gate"
        ):
            return 200, service.teacher_release_gate(parts[3])
        if method == "GET" and route == "/v1/db/backend-status":
            return 200, service.db_backend_status()
        if method == "GET" and route == "/v1/db/benchmarks":
            return 200, service.db_bench(
                history=True,
                limit=int(query.get("limit", "20")),
            )
        if method == "GET" and route == "/v1/learning/recent":
            return 200, service.learning_recent(limit=int(query.get("limit", "20")))
        if (
            method == "GET"
            and len(parts) == 4
            and parts[:2] == ["v1", "tasks"]
            and parts[3] == "learned"
        ):
            return 200, service.task_learning_report(parts[2])
        if method == "GET" and len(parts) == 3 and parts[:2] == ["v1", "audit"]:
            if not authorized:
                return _unauthorized()
            return 200, service.get_audit_record(parts[2])
        if method == "GET" and route == "/v1/eval/scorecard":
            if not authorized:
                return _unauthorized()
            return 200, service.eval_scorecard(query.get("output"))
        if method == "GET" and route == "/v1/eval/scorecard/public":
            return 200, _public_scorecard(service.eval_scorecard())
        if method == "POST" and route == "/v1/eval/run":
            if not authorized:
                return _unauthorized()
            suite = str(payload.get("suite", "efficacy"))
            if suite != "efficacy":
                raise ValueError(f"unsupported eval suite: {suite}")
            return 200, service.eval_run_efficacy(
                str(payload["cases"]),
                str(payload["agent_command"]),
                baseline=str(payload.get("baseline", "no-pack")),
                candidate=str(payload.get("candidate", "ctx-pack")),
                limit=int(payload.get("limit", 10)),
                timeout=int(payload.get("timeout", 600)),
                keep_worktrees=bool(payload.get("keep_worktrees", False)),
            )
        if method == "POST" and route == "/v1/eval/loop-verify":
            if not authorized:
                return _unauthorized()
            paths = payload.get("paths")
            if paths is not None and not isinstance(paths, list):
                raise ValueError("paths must be a list when provided")
            return 200, service.eval_loop_verify(
                task=str(payload.get("task", "change greeting service")),
                paths=paths,
                result=str(payload.get("result", "pass")),
            )
        if method == "POST" and route == "/v1/context-pack":
            if not authorized:
                return _unauthorized()
            return 200, service.get_context_pack(
                payload.get("task"),
                payload.get("budget"),
                payload.get("seed_paths"),
                intent_id=payload.get("intent_id"),
                goal_id=payload.get("goal_id"),
                bind_snapshot=payload.get("bind_snapshot") or payload.get("bind_snapshot_id"),
                task_session_id=payload.get("task_session_id"),
            )
        if (
            method == "GET"
            and len(parts) == 3
            and parts[:2] == ["v1", "packs"]
            and isinstance(service, PackService)
        ):
            return _status_from_ok(service.get_pack_manifest(parts[2]))
        if method == "GET" and route == "/v1/snapshot/current":
            return 200, service.snapshot_current()
        if method == "GET" and route == "/v1/snapshot/lineage":
            return 200, service.snapshot_lineage(
                query.get("snapshot_id"),
                limit=int(query.get("limit", "50")),
            )
        if method == "GET" and route == "/v1/intent":
            return 200, service.intent_list(
                status=query.get("status"),
                limit=int(query.get("limit", "50")),
            )
        if method == "POST" and route == "/v1/intent":
            if not authorized:
                return _unauthorized()
            return 200, service.intent_start(
                str(payload["problem"]),
                llm_propose=bool(payload.get("llm_propose", False)),
            )
        if method == "GET" and len(parts) == 3 and parts[:2] == ["v1", "intent"]:
            return 200, service.intent_show(parts[2])
        if (
            method == "POST"
            and len(parts) == 4
            and parts[:2] == ["v1", "intent"]
            and parts[3] == "refine"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.intent_refine(
                parts[2],
                evidence=payload.get("evidence"),
                select_goal=payload.get("select_goal") or payload.get("goal_id"),
            )
        if method == "GET" and route == "/v1/goals":
            return 200, service.goal_list(
                status=query.get("status"),
                limit=int(query.get("limit", "50")),
            )
        if method == "POST" and route == "/v1/goals/evaluate":
            if not authorized:
                return _unauthorized()
            return 200, service.goal_evaluate(
                str(payload["intent_id"]),
                candidate_goal_id=payload.get("candidate_goal_id") or payload.get("candidate"),
                mode=payload.get("mode"),
            )
        if method == "GET" and len(parts) == 3 and parts[:2] == ["v1", "goals"]:
            return 200, service.goal_show(parts[2])
        if (
            method == "POST"
            and len(parts) == 4
            and parts[:2] == ["v1", "goals"]
            and parts[3] == "challenge"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.goal_challenge(parts[2])
        if (
            method == "POST"
            and len(parts) == 4
            and parts[:2] == ["v1", "goals"]
            and parts[3] == "accept-alternative"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.goal_accept_alternative(
                parts[2],
                str(payload["alt_id"]),
                str(payload.get("rationale") or ""),
            )
        if (
            method == "POST"
            and len(parts) == 4
            and parts[:2] == ["v1", "goals"]
            and parts[3] == "reject-alternative"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.goal_reject_alternative(
                parts[2],
                str(payload["alt_id"]),
                str(payload.get("rationale") or ""),
            )
        if method == "POST" and route == "/v1/impact-report":
            if not authorized:
                return _unauthorized()
            return 200, service.get_impact_report(
                payload.get("paths"),
                payload.get("pack_id"),
                payload.get("diff"),
                business=bool(payload.get("business", False)),
            )
        if method == "GET" and route == "/v1/business/entities":
            return 200, service.business_entity_list(
                status=query.get("status"),
                node_type=query.get("type"),
                limit=int(query.get("limit", "100")),
            )
        if method == "POST" and route == "/v1/business/entities":
            if not authorized:
                return _unauthorized()
            return 200, service.business_entity_add(
                node_type=str(payload["type"]),
                name=str(payload["name"]),
                attrs=dict(payload.get("attrs") or payload.get("metadata") or {}),
                origin=str(payload.get("origin", "manual")),
                source_type=payload.get("source_type"),
                source_ref=payload.get("source_ref"),
                proposed_by=str(payload.get("proposed_by", "user")),
                confidence=float(payload.get("confidence", 0.9)),
            )
        if (
            method == "POST"
            and len(parts) == 5
            and parts[:3] == ["v1", "business", "entities"]
            and parts[4] in {"approve", "reject"}
        ):
            if not authorized:
                return _unauthorized()
            if parts[4] == "approve":
                return 200, service.business_entity_approve(
                    parts[3],
                    approver=str(payload.get("approver", "human:http")),
                    notes=str(payload.get("notes", "")),
                )
            return 200, service.business_entity_reject(
                parts[3],
                approver=str(payload.get("approver", "human:http")),
                reason=str(payload.get("reason", "")),
            )
        if method == "POST" and route == "/v1/business/links":
            if not authorized:
                return _unauthorized()
            return 200, service.business_link(
                src_node_id=str(payload["src_node_id"]),
                dst_node_id=str(payload["dst_node_id"]),
                kind=str(payload["kind"]),
                source_ref=str(payload.get("source_ref") or "manual"),
                source_type=str(payload.get("source_type") or "manual_entry"),
                proposed_by=str(payload.get("proposed_by", "user")),
                confidence=(
                    float(payload["confidence"]) if payload.get("confidence") is not None else None
                ),
            )
        if method == "GET" and route == "/v1/org/connectors":
            return 200, service.org_connectors(kind=query.get("kind"))
        if method == "POST" and route == "/v1/org/connectors":
            if not authorized:
                return _unauthorized()
            return 200, service.org_connector_add(
                str(payload["kind"]),
                config=dict(payload.get("config") or {}),
                display_name=payload.get("display_name"),
                secret_ref=payload.get("secret_ref"),
                access_scope=str(payload.get("access_scope", "restricted")),
                remote_enabled=bool(payload.get("remote_enabled", False)),
            )
        if method == "POST" and route == "/v1/org/ingest":
            if not authorized:
                return _unauthorized()
            return 200, service.org_ingest(
                str(payload["connector"]),
                since=payload.get("since"),
                path=payload.get("path"),
                remote=bool(payload.get("remote", False)),
                actor=str(payload.get("actor", "system")),
            )
        if method == "GET" and route == "/v1/org/candidates":
            return 200, service.org_candidates(
                status=query.get("status", "quarantined"),
                source=query.get("source"),
                scope=query.get("scope"),
                actor=query.get("actor", "local-user"),
                limit=int(query.get("limit", "100")),
            )
        if (
            method == "POST"
            and len(parts) == 5
            and parts[:3] == ["v1", "org", "candidates"]
            and parts[4] in {"approve", "reject"}
        ):
            if not authorized:
                return _unauthorized()
            if parts[4] == "approve":
                return 200, service.org_approve(
                    parts[3],
                    actor=str(payload.get("actor", "codeowner:http")),
                    supersede=payload.get("supersede"),
                )
            return 200, service.org_reject(
                parts[3],
                actor=str(payload.get("actor", "codeowner:http")),
                reason=str(payload.get("reason", "rejected")),
            )
        if (
            method == "GET"
            and len(parts) == 5
            and parts[:3] == ["v1", "org", "candidates"]
            and parts[4] == "audit"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.org_audit(parts[3])
        if method == "POST" and route == "/v1/decision/start":
            if not authorized:
                return _unauthorized()
            return 200, service.decision_start(
                str(payload["question"]),
                options=payload.get("options") or [],
                seed_paths=payload.get("seed_paths") or [],
            )
        if method == "POST" and route == "/v1/decision/analyze":
            if not authorized:
                return _unauthorized()
            return 200, service.decision_analyze(str(payload["decision_id"]))
        if method == "POST" and route == "/v1/decision/record":
            if not authorized:
                return _unauthorized()
            return 200, service.decision_record(
                str(payload["decision_id"]),
                chosen_option_id=str(payload["chosen_option_id"]),
                rationale=str(payload["rationale"]),
                actor=str(payload.get("actor", "local-user")),
            )
        if method == "GET" and len(parts) == 3 and parts[:2] == ["v1", "decision"]:
            return 200, service.decision_show(parts[2])
        if method == "GET" and route == "/v1/decisions":
            return 200, service.decision_list(
                status=query.get("status"),
                limit=int(query.get("limit", "50")),
            )
        if method == "GET" and route == "/v1/metacognition/state":
            return 200, service.metacog_state(
                query.get("task", ""),
                paths=query.get("path", "").split(",") if query.get("path") else [],
                task_session_id=query.get("task_session_id"),
            )
        if method == "GET" and route == "/v1/clarifications":
            return 200, service.clarify_list(
                task_session_id=query.get("task_session_id"),
                status=query.get("status", "open"),
                limit=int(query.get("limit", "50")),
            )
        if method == "POST" and route == "/v1/clarifications":
            if not authorized:
                return _unauthorized()
            return 200, service.clarify_open(
                str(payload["question"]),
                task_session_id=payload.get("task_session_id"),
                pack_id=payload.get("pack_id"),
            )
        if (
            method == "POST"
            and len(parts) == 4
            and parts[:2] == ["v1", "clarifications"]
            and parts[3] == "answer"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.clarify_answer(parts[2], str(payload["answer"]))
        if (
            method == "POST"
            and len(parts) == 4
            and parts[:2] == ["v1", "clarifications"]
            and parts[3] == "withdraw"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.clarify_withdraw(parts[2], reason=payload.get("reason"))
        if method == "GET" and route == "/v1/judgment/heuristics":
            return 200, service.judgment_list(status=query.get("status"))
        if (
            method == "POST"
            and len(parts) == 5
            and parts[:3] == ["v1", "judgment", "heuristics"]
            and parts[4] == "adopt"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.judgment_adopt(
                parts[3],
                actor=str(payload.get("actor", "local-user")),
                reason=payload.get("reason"),
            )
        if (
            method == "POST"
            and len(parts) == 5
            and parts[:3] == ["v1", "judgment", "heuristics"]
            and parts[4] == "reject"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.judgment_reject(parts[3], reason=payload.get("reason"))
        if method == "GET" and route == "/v1/narrative":
            return 200, service.narrative_show()
        if method == "POST" and route == "/v1/check-diff":
            if not authorized:
                return _unauthorized()
            return 200, service.check_diff_against_pack(payload["pack_id"], payload.get("diff"))
        if method == "GET" and route == "/v1/sessions/conflicts":
            return 200, service.session_conflicts(status=query.get("status", "open"))
        if method == "GET" and route == "/v1/sessions/leases":
            return 200, service.session_leases(status=query.get("status", "active"))
        if (
            method == "POST"
            and len(parts) == 4
            and parts[:2] == ["v1", "sessions"]
            and parts[3] == "impact"
        ):
            if not authorized:
                return _unauthorized()
            return 200, service.session_declare_impact(parts[2], payload.get("paths") or [])
        if (
            method == "POST"
            and len(parts) == 4
            and parts[:2] == ["v1", "sessions"]
            and parts[3] in {"ack", "resolve"}
        ):
            if not authorized:
                return _unauthorized()
            status = "acknowledged" if parts[3] == "ack" else "resolved"
            return 200, service.session_conflict_update(parts[2], status)
        if method == "POST" and route == "/v1/semantic/accuracy-eval":
            if not authorized:
                return _unauthorized()
            return 200, service.semantic_accuracy_eval(payload.get("fixtures"))
        if method == "POST" and route in {
            "/v1/learning/loop-verify",
            "/learning/loop-verify",
        }:
            if not authorized:
                return _unauthorized()
            result = service.learning_loop_verify(
                payload.get("task"),
                probe=payload.get("probe"),
                require_closure=bool(payload.get("require_closure", False)),
            )
            response_status = (
                409
                if bool(payload.get("require_closure", False)) and not result.get("ok", False)
                else 200
            )
            return response_status, result
        if method == "POST" and route in {
            "/v1/security/ingest-redteam",
            "/security/ingest-redteam",
        }:
            if not authorized:
                return _unauthorized()
            result = service.security_ingest_redteam(
                payload.get("fixtures"),
                output=payload.get("output"),
                strict=bool(payload.get("strict", False)),
            )
            response_status = (
                409 if bool(payload.get("strict", False)) and not result.get("ok", False) else 200
            )
            return response_status, result
        if method == "GET" and route in {
            "/v1/security/defense-status",
            "/security/defense-status",
        }:
            return 200, service.security_status().get("ingest", {})
        if method == "GET" and route == "/v1/semantic/low-confidence":
            return 200, service.semantic_low_confidence(float(query.get("threshold", "0.5")))
        if method == "GET" and route == "/v1/architecture/drift":
            result = service.architecture_drift(strict=_bool(query.get("strict")))
            return (409 if result.get("status") == "fail" else 200), result
        if method == "GET" and route == "/v1/semantic/repair":
            return 200, service.semantic_repair_list(
                status=query.get("status", "open"),
                limit=int(query.get("limit", "100")),
            )
        if (
            method == "POST"
            and len(parts) == 5
            and parts[:3] == ["v1", "semantic", "repair"]
            and parts[4] in {"confirm", "reject"}
        ):
            if not authorized:
                return _unauthorized()
            if parts[4] == "confirm":
                return 200, service.semantic_repair_confirm(
                    parts[3],
                    actor=str(payload.get("actor", "human:http")),
                    rationale=str(payload.get("rationale", "")),
                )
            return 200, service.semantic_repair_reject(
                parts[3],
                actor=str(payload.get("actor", "human:http")),
                rationale=str(payload.get("rationale", "")),
            )
        handled = _handle_codex(service, method, parts, payload, authorized=authorized)
        if handled:
            return handled
        handled = _handle_governance(service, method, parts, query, payload, authorized=authorized)
        if handled:
            return handled
        handled = _handle_memory(service, method, parts, query, payload, authorized=authorized)
        if handled:
            return handled
        handled = _handle_guardrail(service, method, parts, payload, authorized=authorized)
        if handled:
            return handled
        handled = _handle_continuations(
            service, method, parts, query, payload, authorized=authorized
        )
        if handled:
            return handled
        handled = _handle_skills(service, method, parts, query, payload, authorized=authorized)
        if handled:
            return handled
        handled = _handle_cie(service, method, parts, query, payload, authorized=authorized)
        if handled:
            return handled
        handled = _handle_learning(service, method, parts, query, payload, authorized=authorized)
        if handled:
            return handled
        handled = _handle_security(service, method, parts, query, payload, authorized=authorized)
        if handled:
            return handled
    except KeyError as exc:
        return 404, {
            "ok": False,
            "status": "validation_failed",
            "error": str(exc).strip("'"),
        }
    except PermissionError as exc:
        return 403, {"ok": False, "status": "forbidden", "error": str(exc)}
    except WorkspaceMigrationRequired as exc:
        return 422, {
            "ok": False,
            "status": getattr(exc, "status", "validation_failed"),
            "error": str(exc),
        }
    except (StorageNotInitialized, SQLiteRuntimeUnsupported) as exc:
        return 409, {
            "ok": False,
            "status": getattr(exc, "status", "storage_not_initialized"),
            "error": str(exc),
        }
    except TaskConflict as exc:
        return 409, {"ok": False, "status": "conflict", "error": str(exc)}
    except KnowledgeConflict as exc:
        return 409, {"ok": False, "status": "conflict", "error": str(exc)}
    except LearningConflict as exc:
        return 409, {"ok": False, "status": "conflict", "error": str(exc)}
    except ValueError as exc:
        return 400, {
            "ok": False,
            "status": "validation_failed",
            "error": str(exc),
        }

    return 404, {"ok": False, "status": "validation_failed", "error": "not found"}


def _handle_codex(
    service: OperationClient,
    method: str,
    parts: list[str],
    payload: dict[str, Any],
    *,
    authorized: bool,
) -> tuple[int, dict[str, Any]] | None:
    if parts[:2] != ["v1", "codex"]:
        return None
    if method == "GET" and parts == ["v1", "codex", "enforcement-status"]:
        if not authorized:
            return _unauthorized()
        return 200, service.codex_enforcement_status()
    if method == "POST" and parts == ["v1", "codex", "hook-event"]:
        if not authorized:
            return _unauthorized()
        event = str(payload.get("event") or "")
        body = payload.get("payload")
        if not isinstance(body, dict):
            body = {key: value for key, value in payload.items() if key != "event"}
        return 200, service.codex_hook_event(event, body)
    if method != "POST":
        return None
    if not authorized:
        return _unauthorized()
    if parts == ["v1", "codex", "preflight"]:
        return 200, service.codex_preflight(
            str(payload["task"]),
            paths=payload.get("paths"),
            mode=str(payload.get("mode", "write")),
            probe=bool(payload.get("probe") or payload.get("fast")),
        )
    if parts == ["v1", "codex", "parallel-plan"]:
        return 200, service.codex_parallel_plan(
            str(payload["task_session_id"]),
            str(payload["pack_id"]),
            paths=payload.get("paths"),
        )
    if parts == ["v1", "codex", "subagents", "start"]:
        return 200, service.codex_child_start(
            str(payload["parent_task_session_id"]),
            str(payload["role"]),
            str(payload["objective"]),
            write_scope=payload.get("write_scope"),
            read_scope=payload.get("read_scope"),
            parent_pack_id=payload.get("parent_pack_id"),
        )
    if parts == ["v1", "codex", "subagents", "stop"]:
        return 200, service.codex_child_stop(
            str(payload["child_agent_session_id"]),
            str(payload.get("summary", "")),
            changed_files=payload.get("changed_files"),
            tests_run=payload.get("tests_run"),
            blockers=payload.get("blockers"),
        )
    if parts == ["v1", "codex", "subagents", "pack"]:
        return 200, service.codex_child_pack(
            str(payload["parent_pack_id"]),
            str(payload["role"]),
            scope=payload.get("scope"),
        )
    if parts == ["v1", "codex", "parallel-results", "merge"]:
        return 200, service.codex_merge_parallel_results(str(payload["parallel_run_id"]))
    return None


def _handle_governance(
    service: OperationClient,
    method: str,
    parts: list[str],
    query: dict[str, str],
    payload: dict[str, Any],
    *,
    authorized: bool,
) -> tuple[int, dict[str, Any]] | None:
    if parts[:2] != ["v1", "governance"]:
        return None
    if method == "GET" and parts == ["v1", "governance", "status"]:
        return 200, service.governance_status()
    if method == "POST" and parts == ["v1", "governance", "propose"]:
        if not authorized:
            return _unauthorized()
        min_samples = payload.get("min_samples")
        return 200, service.governance_propose(
            min_samples=int(min_samples) if min_samples is not None else None
        )
    if method == "GET" and parts == ["v1", "governance", "proposals"]:
        return 200, service.governance_list(status=query.get("status"))
    if (
        method == "GET"
        and len(parts) == 4
        and parts[:3]
        == [
            "v1",
            "governance",
            "proposals",
        ]
    ):
        return 200, service.governance_show(parts[3])
    if method == "POST" and len(parts) == 5 and parts[:3] == ["v1", "governance", "proposals"]:
        if not authorized:
            return _unauthorized()
        if parts[4] == "preview":
            return 200, service.governance_preview_adoption(parts[3])
        if parts[4] == "adopt":
            return 200, service.governance_adopt(
                parts[3],
                actor=str(payload.get("actor", "human:http")),
                reason=payload.get("reason"),
            )
        if parts[4] == "reject":
            return 200, service.governance_reject(parts[3], reason=payload.get("reason"))
    if (
        method == "POST"
        and len(parts) == 5
        and parts[:3] == ["v1", "governance", "adoptions"]
        and parts[4] == "rollback"
    ):
        if not authorized:
            return _unauthorized()
        return 200, service.governance_rollback(parts[3], reason=payload.get("reason"))
    return None


def _handle_memory(
    service: Any,
    method: str,
    parts: list[str],
    query: dict[str, str],
    payload: dict[str, Any],
    *,
    authorized: bool,
) -> tuple[int, dict[str, Any]] | None:
    if parts[:2] != ["v1", "memory"]:
        return None
    if isinstance(service, KnowledgeService):
        return _handle_nextgen_memory(service, method, parts, query, payload, authorized=authorized)
    if method == "GET" and len(parts) == 2:
        if query.get("query"):
            return 200, service.memory_search(
                query["query"],
                types=_csv(query.get("type") or query.get("types")),
                status=query.get("status"),
            )
        return 200, service.memory_records(
            status=query.get("status"),
            types=_csv(query.get("type") or query.get("types")),
        )
    if method == "POST" and len(parts) == 2:
        if not authorized:
            return _unauthorized()
        if "type" in payload and "assertion" in payload:
            return 200, service.memory_create_typed(payload)
        if "record_type" not in payload or "assertion" not in payload:
            raise ValueError("memory creation requires type+assertion or record_type+assertion")
        return 200, service.memory_propose(
            str(payload["record_type"]),
            str(payload["assertion"]),
            payload.get("evidence_refs"),
            str(payload.get("source_kind", "manual")),
            float(payload.get("confidence", 1.0)),
        )
    if method == "POST" and parts == ["v1", "memory", "recall"]:
        return 200, service.memory_recall(
            str(payload["query"]),
            paths=payload.get("paths"),
            types=payload.get("types") or payload.get("type"),
            limit=int(payload.get("limit", 8)),
            include_org=bool(payload.get("include_org", False)),
        )
    if method == "POST" and parts == ["v1", "memory", "extraction-eval"]:
        if not authorized:
            return _unauthorized()
        return 200, service.memory_extraction_eval(
            fixtures=payload.get("fixtures"),
            source_type=payload.get("source_type"),
        )
    if method == "POST" and parts == ["v1", "memory", "trust-calibrate"]:
        if not authorized:
            return _unauthorized()
        return 200, service.memory_trust_calibrate(apply=bool(payload.get("apply", False)))
    if method == "POST" and parts == ["v1", "memory", "maintain"]:
        if not authorized:
            return _unauthorized()
        return 200, service.memory_maintain(limit=int(payload.get("limit", 200)))
    if method == "POST" and parts == ["v1", "memory", "sweep"]:
        if not authorized:
            return _unauthorized()
        return 200, service.memory_sweep(
            limit=int(payload.get("limit", 500)),
            apply=bool(payload.get("apply", False)),
        )
    if method == "GET" and parts == ["v1", "memory", "enforcements"]:
        return 200, service.memory_enforcements(
            status=query.get("status"), paths=_csv(query.get("path") or "")
        )
    if method == "POST" and parts == ["v1", "memory", "enforcements"]:
        if not authorized:
            return _unauthorized()
        return 200, service.memory_enforce(
            str(payload["record_id"]),
            level=str(payload.get("level", "warn")),
            severity=str(payload.get("severity", "medium")),
            scope=payload.get("scope") or payload.get("paths") or [],
            anti_patterns=payload.get("anti_patterns") or [],
            required_patterns=payload.get("required_patterns") or [],
            remediation=payload.get("remediation"),
            rationale=payload.get("rationale"),
            approve=bool(payload.get("approve", False)),
            approved_by=str(payload.get("approved_by", "http")),
        )
    if method == "GET" and parts == ["v1", "memory", "review"]:
        return 200, service.memory_review(status=query.get("status", "open"))
    if method == "GET" and len(parts) == 4 and parts[:3] == ["v1", "memory", "utilization"]:
        return 200, service.memory_utilization(parts[3])
    if len(parts) < 3:
        return None
    record_id = parts[2]
    if method == "GET" and len(parts) == 3:
        return _status_from_ok(service.memory_show(record_id))
    if method == "GET" and len(parts) == 4 and parts[3] == "diff":
        return _status_from_ok(service.memory_diff(record_id))
    if method == "PATCH" and len(parts) == 3:
        if not authorized:
            return _unauthorized()
        patch_value = payload.get("patch")
        patch = patch_value if isinstance(patch_value, dict) else payload
        return 200, service.memory_update(
            record_id,
            patch,
            reason=str(payload.get("reason", "http update")),
            actor=str(payload.get("actor", "codeowner:http")),
        )
    if method == "POST" and len(parts) == 4 and parts[3] in {"approve", "validate"}:
        if not authorized:
            return _unauthorized()
        return 200, service.memory_validate(
            record_id,
            validator=str(payload.get("validator", "human:http")),
            evidence=payload.get("evidence"),
            actor=str(payload.get("actor", "codeowner:http")),
        )
    if method == "POST" and len(parts) == 4 and parts[3] == "quarantine":
        if not authorized:
            return _unauthorized()
        result = service.memory_quarantine(
            record_id,
            reason=str(payload.get("reason", "http quarantine")),
            severity=str(payload.get("severity", "high")),
            actor=str(payload.get("actor", "codeowner:http")),
        )
        if result.get("ok"):
            result["record"] = service.memory_show(record_id)["record"]
        return 200, result
    if method == "POST" and len(parts) == 4 and parts[3] == "promote":
        if not authorized:
            return _unauthorized()
        return 200, service.memory_promote(
            record_id,
            validator=str(payload["validator"]),
            actor=str(payload.get("actor", "codeowner:http")),
        )
    if method == "POST" and len(parts) == 4 and parts[3] == "expire":
        if not authorized:
            return _unauthorized()
        result = service.memory_expire(
            record_id,
            reason=str(payload.get("reason", "http expire")),
            actor=str(payload.get("actor", "codeowner:http")),
        )
        if result.get("ok"):
            result["record"] = service.memory_show(record_id)["record"]
        return 200, result
    return None


def _handle_nextgen_memory(
    service: KnowledgeService,
    method: str,
    parts: list[str],
    query: dict[str, str],
    payload: dict[str, Any],
    *,
    authorized: bool,
) -> tuple[int, dict[str, Any]] | None:
    """Split-native memory and Policy Authority HTTP surface."""

    if method == "GET" and len(parts) == 2:
        if query.get("query"):
            return 200, service.memory_search(
                query["query"],
                types=_csv(query.get("type") or query.get("types")),
                status=query.get("status"),
            )
        return 200, service.memory_records(
            status=query.get("status"),
            types=_csv(query.get("type") or query.get("types")),
        )
    if method == "POST" and len(parts) == 2:
        if not authorized:
            return _unauthorized()
        if "type" in payload and "assertion" in payload:
            return 200, service.memory_create_typed(payload)
        if "record_type" not in payload or "assertion" not in payload:
            raise ValueError("memory creation requires type+assertion or record_type+assertion")
        return 200, service.memory_propose(
            str(payload["record_type"]),
            str(payload["assertion"]),
            payload.get("evidence_refs"),
            str(payload.get("source_kind", "manual")),
            float(payload.get("confidence", 1.0)),
        )
    if method == "POST" and parts == ["v1", "memory", "recall"]:
        return 200, service.memory_recall(
            str(payload["query"]),
            paths=payload.get("paths"),
            types=payload.get("types") or payload.get("type"),
            limit=int(payload.get("limit", 8)),
            include_org=bool(payload.get("include_org", False)),
        )
    if method == "GET" and parts == ["v1", "memory", "candidates"]:
        return 200, service.memory_review(limit=int(query.get("limit", 100)))
    if method == "GET" and parts == ["v1", "memory", "metrics"]:
        return 200, service.memory_metrics()
    if method == "GET" and parts == ["v1", "memory", "graph"]:
        return 200, service.memory_graph(limit=int(query.get("limit", 100)))
    if method == "GET" and parts == ["v1", "memory", "conflicts"]:
        return 200, service.memory_conflicts()
    if method == "GET" and parts == ["v1", "memory", "stale"]:
        return 200, service.memory_stale()
    if method == "GET" and parts == ["v1", "memory", "verify"]:
        return 200, service.memory_verify()
    if method == "POST" and parts in (["v1", "memory", "sleep"], ["v1", "memory", "sweep"]):
        if not authorized:
            return _unauthorized()
        operation = service.memory_sleep if parts[-1] == "sleep" else service.memory_sweep
        return 200, operation(
            apply=bool(payload.get("apply", False)),
            limit=int(payload.get("limit", 100 if parts[-1] == "sleep" else 1000)),
        )
    if method == "POST" and parts == ["v1", "memory", "trust-calibrate"]:
        if not authorized:
            return _unauthorized()
        return 200, service.memory_trust_calibrate(apply=bool(payload.get("apply", False)))
    if method == "POST" and parts == ["v1", "memory", "extraction-eval"]:
        if not authorized:
            return _unauthorized()
        return 200, service.memory_extraction_eval(
            fixtures=payload.get("fixtures"),
            source_type=payload.get("source_type"),
        )
    if method == "POST" and parts == ["v1", "memory", "consolidate"]:
        if not authorized:
            return _unauthorized()
        record_ids = payload.get("record_ids")
        if not isinstance(record_ids, list):
            return 400, {
                "ok": False,
                "status": "explicit_record_ids_required",
                "error": "memory_consolidate requires record_ids; use memory_sleep to discover candidates",
            }
        return 200, service.memory_consolidate(record_ids, recent=int(payload.get("recent", 20)))
    if method == "POST" and parts == ["v1", "memory", "reflect"]:
        if not authorized:
            return _unauthorized()
        return 200, service.memory_reflect(
            session_id=payload.get("session_id"), recent=int(payload.get("recent", 10))
        )
    if method == "POST" and parts == ["v1", "memory", "maintain"]:
        if not authorized:
            return _unauthorized()
        return 200, service.memory_maintain(
            apply=bool(payload.get("apply", False)),
            limit=int(payload.get("limit", 1000)),
        )
    if len(parts) < 3:
        return None
    record_id = parts[2]
    if method == "GET" and len(parts) == 3:
        return _status_from_ok(service.memory_show(record_id))
    if method == "GET" and len(parts) == 4 and parts[3] == "diff":
        return _status_from_ok(service.memory_diff(record_id))
    if method == "GET" and len(parts) == 4 and parts[3] == "graph":
        return 200, service.memory_graph(record_id, limit=int(query.get("limit", 100)))
    if method == "PATCH" and len(parts) == 3:
        if not authorized:
            return _unauthorized()
        patch = cast(
            dict[str, Any],
            payload.get("patch") if isinstance(payload.get("patch"), dict) else payload,
        )
        return 200, service.memory_update(
            record_id,
            patch,
            reason=str(payload.get("reason", "http update")),
            actor=str(payload.get("actor", "codeowner:http")),
        )
    if method == "POST" and len(parts) == 4 and parts[3] == "approve":
        if not authorized:
            return _unauthorized()
        return 200, service.memory_approve(
            record_id,
            approved_by=str(payload.get("actor", "codeowner:http")),
            signature=payload.get("signature"),
        )
    if method == "POST" and len(parts) == 4 and parts[3] == "validate":
        if not authorized:
            return _unauthorized()
        return 200, service.memory_validate(
            record_id,
            validator=str(payload.get("validator", "human:http")),
            evidence=payload.get("evidence"),
            actor=str(payload.get("actor", "codeowner:http")),
        )
    if method == "POST" and len(parts) == 4 and parts[3] == "quarantine":
        if not authorized:
            return _unauthorized()
        result = service.memory_quarantine(
            record_id,
            reason=str(payload.get("reason", "http quarantine")),
            severity=str(payload.get("severity", "high")),
            actor=str(payload.get("actor", "codeowner:http")),
        )
        if result.get("ok"):
            result["record"] = service.memory_show(record_id)["record"]
        return 200, result
    if method == "POST" and len(parts) == 4 and parts[3] == "expire":
        if not authorized:
            return _unauthorized()
        result = service.memory_expire(
            record_id,
            reason=str(payload.get("reason", "http expire")),
            actor=str(payload.get("actor", "codeowner:http")),
        )
        if result.get("ok"):
            result["record"] = service.memory_show(record_id)["record"]
        return 200, result
    if method == "POST" and len(parts) == 4 and parts[3] == "reject":
        if not authorized:
            return _unauthorized()
        return 200, service.memory_reject(
            record_id, actor=str(payload.get("actor", "codeowner:http"))
        )
    if method == "POST" and len(parts) == 4 and parts[3] == "supersede":
        if not authorized:
            return _unauthorized()
        return 200, service.memory_supersede(
            record_id,
            str(payload["new_record_id"]),
            approved_by=str(payload.get("actor", "codeowner:http")),
        )
    if method == "POST" and len(parts) == 4 and parts[3] == "enforce":
        if not authorized:
            return _unauthorized()
        return 200, service.memory_enforce(
            record_id,
            level=str(payload.get("level", "warn")),
            severity=str(payload.get("severity", "medium")),
            scope=payload.get("scope") or [],
            anti_patterns=payload.get("anti_patterns") or [],
            required_patterns=payload.get("required_patterns") or [],
            remediation=payload.get("remediation"),
            rationale=payload.get("rationale"),
            approve=bool(payload.get("approve", False)),
            approved_by=str(payload.get("approved_by", "codeowner:http")),
        )
    if method == "POST" and len(parts) == 4 and parts[3] == "promote":
        return 409, {
            "ok": False,
            "status": "policy_authority_required",
            "error": "promotion is not a Knowledge mutation; use the Policy approval route",
            "record_id": record_id,
        }
    return None


def _handle_guardrail(
    service: OperationClient,
    method: str,
    parts: list[str],
    payload: dict[str, Any],
    *,
    authorized: bool,
) -> tuple[int, dict[str, Any]] | None:
    if parts[:2] != ["v1", "guardrail"]:
        return None
    if method == "POST" and parts == ["v1", "guardrail", "override"]:
        if not authorized:
            return _unauthorized()
        required = ("signature", "nonce", "issued_at", "expires_at")
        missing = [name for name in required if not payload.get(name)]
        if missing:
            raise ValueError("guardrail override requires " + ", ".join(missing))
        return 200, service.guardrail_override(
            str(payload["directive_id"]),
            rationale=str(payload.get("rationale", "")),
            task_session_id=payload.get("task_session_id"),
            session_id=payload.get("session_id"),
            target_paths=payload.get("target_paths") or payload.get("paths") or [],
            actor=str(payload.get("actor", "http")),
            signature=str(payload["signature"]),
            nonce=str(payload["nonce"]),
            issued_at=str(payload["issued_at"]),
            expires_at=str(payload["expires_at"]),
        )
    return None


def _handle_continuations(
    service: OperationClient,
    method: str,
    parts: list[str],
    query: dict[str, str],
    payload: dict[str, Any],
    *,
    authorized: bool,
) -> tuple[int, dict[str, Any]] | None:
    if parts[:2] != ["v1", "continuations"]:
        return None
    if method == "GET" and len(parts) == 2:
        return 200, service.continuation_list(
            status=query.get("status"),
            limit=_int(query.get("limit"), 20),
        )
    if method == "POST" and len(parts) == 3 and parts[2] == "resume":
        if not authorized:
            return _unauthorized()
        return 200, service.continuation_resume(
            str(payload["task"]),
            limit=int(payload.get("limit", 3)),
        )
    if len(parts) < 3:
        return None
    continuation_id = parts[2]
    if method == "GET" and len(parts) == 3:
        return _status_from_ok(service.continuation_show(continuation_id))
    if method == "PATCH" and len(parts) == 3:
        if not authorized:
            return _unauthorized()
        return 200, service.continuation_update(
            continuation_id,
            state=payload.get("state"),
            next_action=payload.get("next_action"),
            blockers=payload.get("blockers"),
            reason=str(payload.get("reason", "http continuation update")),
        )
    if method == "POST" and len(parts) == 4 and parts[3] == "abandon":
        if not authorized:
            return _unauthorized()
        return 200, service.continuation_abandon(
            continuation_id,
            reason=str(payload.get("reason", "http abandon")),
        )
    return None


def _handle_skills(
    service: OperationClient,
    method: str,
    parts: list[str],
    query: dict[str, str],
    payload: dict[str, Any],
    *,
    authorized: bool,
) -> tuple[int, dict[str, Any]] | None:
    if parts[:2] != ["v1", "skills"]:
        return None
    if method == "GET" and len(parts) == 2:
        if query.get("query"):
            return 200, service.skill_search(
                query["query"],
                limit=_int(query.get("limit"), 5),
                include_untrusted=_bool(query.get("include_untrusted")),
            )
        if query.get("metrics"):
            return 200, service.skill_metrics(query.get("skill_id"))
        if query.get("improvements"):
            return 200, service.skill_improvements(
                skill_id=query.get("skill_id"), status=query.get("status")
            )
        return 200, service.skill_list(status=query.get("status"), trust=query.get("trust"))
    if method == "POST" and len(parts) == 2:
        if not authorized:
            return _unauthorized()
        return 200, service.skill_induce(str(payload["session_id"]))
    if len(parts) < 3:
        return None
    skill_id = parts[2]
    if method == "POST" and len(parts) == 3 and skill_id == "artifacts":
        if not authorized:
            return _unauthorized()
        return 200, service.skill_artifact_register(
            skill_id=payload.get("skill_id"),
            artifact_kind=str(payload.get("kind", "task_output")),
            summary=str(payload.get("summary", "")),
            structure=(
                payload.get("structure") if isinstance(payload.get("structure"), dict) else None
            ),
            content=payload.get("content"),
            session_id=payload.get("session_id"),
            task_session_id=payload.get("task_session_id"),
            output_id=payload.get("output_id"),
        )
    if method == "POST" and len(parts) == 3 and skill_id == "revisions":
        if not authorized:
            return _unauthorized()
        return 200, service.skill_revision_capture(
            revision_text=str(payload.get("text", "")),
            output_id=payload.get("output_id"),
            skill_id=payload.get("skill_id"),
            session_id=payload.get("session_id"),
            task_session_id=payload.get("task_session_id"),
            actor=str(payload.get("actor", "user")),
            signal_kind=str(payload.get("signal_kind", "explicit_revision")),
        )
    if method == "POST" and len(parts) == 4 and skill_id == "revisions" and parts[3] == "classify":
        if not authorized:
            return _unauthorized()
        return 200, service.skill_revision_classify(
            payload.get("revision_id"), skill_id=payload.get("skill_id")
        )
    if method == "POST" and len(parts) == 4 and skill_id == "refinements":
        if not authorized:
            return _unauthorized()
        if parts[3] == "approve":
            return 200, service.skill_refinement_approve(
                str(payload["sir_id"]),
                approved_by=str(payload.get("approved_by", "http")),
            )
        if parts[3] == "benchmark":
            return 200, service.skill_refinement_benchmark(str(payload["sir_id"]))
    if method == "POST" and len(parts) == 4 and skill_id == "global":
        if not authorized:
            return _unauthorized()
        if parts[3] == "adopt":
            return 200, service.skill_global_adopt(
                str(payload["global_skill_id"]),
                approver=str(payload.get("approved_by", "http")),
            )
    if method == "GET" and len(parts) == 3:
        return _status_from_ok(service.skill_show(skill_id))
    if method == "GET" and len(parts) == 4 and parts[3] == "metrics":
        return 200, service.skill_metrics(skill_id)
    if method == "GET" and len(parts) == 4 and parts[3] == "improvements":
        return 200, service.skill_improvements(skill_id=skill_id, status=query.get("status"))
    if method == "POST" and len(parts) == 4 and parts[3] == "replay":
        if not authorized:
            return _unauthorized()
        return 200, service.skill_replay(skill_id, timeout=int(payload.get("timeout", 120)))
    if method == "POST" and len(parts) == 4 and parts[3] == "approve":
        if not authorized:
            return _unauthorized()
        return 200, service.skill_approve(
            skill_id, approved_by=str(payload.get("approved_by", "http"))
        )
    if method == "POST" and len(parts) == 4 and parts[3] == "reject":
        if not authorized:
            return _unauthorized()
        return 200, service.skill_reject(skill_id, reason=str(payload.get("reason", "http reject")))
    if method == "POST" and len(parts) == 4 and parts[3] == "accept":
        if not authorized:
            return _unauthorized()
        return 200, service.skill_accept_first_pass(str(payload["output_id"]))
    if method == "POST" and len(parts) == 4 and parts[3] == "rollback":
        if not authorized:
            return _unauthorized()
        return 200, service.skill_refinement_rollback(skill_id)
    if method == "POST" and len(parts) == 4 and parts[3] == "closure":
        if not authorized:
            return _unauthorized()
        return 200, service.skill_closure_verify(skill_id)
    if method == "POST" and len(parts) == 4 and parts[3] == "promote-global":
        if not authorized:
            return _unauthorized()
        return 200, service.skill_global_promote(
            skill_id, approver=str(payload.get("approved_by", "http"))
        )
    return None


def _handle_learning(
    service: OperationClient,
    method: str,
    parts: list[str],
    query: dict[str, str],
    payload: dict[str, Any] | None = None,
    *,
    authorized: bool = True,
) -> tuple[int, dict[str, Any]] | None:
    payload = payload or {}
    if parts == ["v1", "learning", "runs"]:
        if method != "GET":
            return None
        return 200, service.learning_archive(
            target=query.get("target"), limit=_int(query.get("limit"), 20)
        )
    if parts == ["v1", "selfmod", "runs"]:
        if method != "GET":
            return None
        return 200, service.learning_selfmod_archive(
            target=query.get("target"), limit=_int(query.get("limit"), 20)
        )
    if method == "GET" and len(parts) == 4 and parts[:3] == ["v1", "learning", "runs"]:
        return 200, service.learning_show(parts[3])
    if method == "POST" and len(parts) == 4 and parts[:3] == ["v1", "learning", "runs"]:
        if not authorized:
            return _unauthorized()
        run_id = parts[3]
        if payload.get("action") == "adopt":
            return 200, service.learning_adopt(run_id)
        if payload.get("action") == "promote":
            return 200, service.learning_adopt(run_id)
        if payload.get("action") == "revert":
            return 200, service.learning_revert(run_id)
        return None
    if method == "POST" and parts == ["v1", "learning", "rollback"]:
        if not authorized:
            return _unauthorized()
        return 200, service.learning_rollback(
            target=payload.get("target"),
            run_id=payload.get("run_id"),
        )
    if method == "POST" and len(parts) == 5 and parts[:3] == ["v1", "learning", "runs"]:
        if not authorized:
            return _unauthorized()
        run_id = parts[3]
        if parts[4] in {"adopt", "promote"}:
            return 200, service.learning_adopt(run_id)
        if parts[4] == "revert":
            return 200, service.learning_revert(run_id)
    if method == "POST" and parts == ["v1", "selfmod", "runs", "propose"]:
        if not authorized:
            return _unauthorized()
        return 200, service.learning_selfmod_propose(
            str(payload["target"]),
            weakness=str(payload.get("weakness", "")),
            ancestor_run_id=payload.get("ancestor_run_id"),
        )
    if method == "GET" and len(parts) == 4 and parts[:3] == ["v1", "selfmod", "runs"]:
        return 200, service.learning_selfmod_show(parts[3])
    if method == "POST" and len(parts) == 5 and parts[:3] == ["v1", "selfmod", "runs"]:
        if not authorized:
            return _unauthorized()
        run_id = parts[3]
        if parts[4] in {"adopt", "approve"}:
            return 200, service.learning_selfmod_adopt(
                run_id,
                approved_by=str(payload.get("approved_by", "http")),
            )
        if parts[4] == "reject":
            return 200, service.learning_selfmod_reject(
                run_id,
                reason=str(payload.get("reason", "http reject")),
                rejected_by=str(payload.get("rejected_by", "http")),
            )
        if parts[4] in {"revert", "rollback"}:
            return 200, service.learning_selfmod_revert(run_id)
    return None


def _handle_cie(
    service: OperationClient,
    method: str,
    parts: list[str],
    query: dict[str, str],
    payload: dict[str, Any] | None = None,
    *,
    authorized: bool = True,
) -> tuple[int, dict[str, Any]] | None:
    payload = payload or {}
    if parts[:2] != ["v1", "cie"]:
        return None
    if method == "GET" and parts == ["v1", "cie", "status"]:
        return 200, service.cie_status()
    if method == "POST" and parts == ["v1", "cie", "cycles"]:
        if not authorized:
            return _unauthorized()
        return 200, service.cie_cycle(
            limit=_int(payload.get("limit"), 20),
            target=str(payload.get("target", "cie")),
            task=str(payload.get("task", "")),
            paths=(payload.get("paths") if isinstance(payload.get("paths"), list) else []),
        )
    if method == "GET" and parts == ["v1", "cie", "cycles"]:
        return 200, service.cie_archive(
            target=query.get("target"),
            limit=_int(query.get("limit"), 20),
        )
    if method == "GET" and len(parts) == 4 and parts[:3] == ["v1", "cie", "cycles"]:
        return 200, service.cie_show(parts[3])
    if method == "POST" and parts == ["v1", "cie", "predict"]:
        return 200, service.cie_predict(
            task=str(payload.get("task", "")),
            paths=(payload.get("paths") if isinstance(payload.get("paths"), list) else []),
        )
    if method == "POST" and parts == ["v1", "cie", "checklist-preview"]:
        return 200, service.cie_checklist_preview(
            task=str(payload.get("task", "")),
            paths=(payload.get("paths") if isinstance(payload.get("paths"), list) else []),
        )
    if method == "GET" and parts == ["v1", "cie", "score"]:
        return 200, service.cie_score(period=query.get("period", "current"))
    if method == "GET" and parts == ["v1", "cie", "timeline"]:
        return 200, service.cie_timeline(run_id=query.get("run_id"))
    if (
        method == "GET"
        and len(parts) == 5
        and parts[:3] == ["v1", "cie", "cycles"]
        and parts[4] == "timeline"
    ):
        return 200, service.cie_timeline(run_id=parts[3])
    if len(parts) == 7 and parts[:3] == ["v1", "cie", "cycles"] and parts[4] == "interventions":
        if method != "POST":
            return None
        if not authorized:
            return _unauthorized()
        run_id = parts[3]
        intervention_id = parts[5]
        action = parts[6]
        if action == "preview":
            return 200, service.cie_preview_adoption(run_id, intervention_id)
        if action == "adopt":
            return 200, service.cie_adopt(
                run_id, intervention_id, str(payload.get("approved_by", "http"))
            )
        if action == "reject":
            return 200, service.cie_reject(
                run_id,
                intervention_id,
                str(payload.get("reason", "http reject")),
                str(payload.get("actor", "http")),
            )
        if action == "suspend":
            return 200, service.cie_suspend(
                run_id,
                intervention_id,
                str(payload.get("reason", "http suspend")),
                str(payload.get("actor", "http")),
            )
    return None


def _handle_security(
    service: OperationClient,
    method: str,
    parts: list[str],
    query: dict[str, str],
    payload: dict[str, Any],
    *,
    authorized: bool,
) -> tuple[int, dict[str, Any]] | None:
    if method == "GET" and parts == ["v1", "security", "reviews"]:
        return 200, service.memory_security_reviews(status=query.get("status", "open"))
    if (
        method == "POST"
        and len(parts) == 5
        and parts[:3] == ["v1", "security", "reviews"]
        and parts[4] == "resolve"
    ):
        if not authorized:
            return _unauthorized()
        return 200, service.memory_review_resolve(
            parts[3],
            resolution=str(payload["resolution"]),
            actor=str(payload.get("actor", "codeowner:http")),
            target_record_id=payload.get("target_record_id"),
            validator=str(payload.get("validator", "human:security-review")),
            reason=str(payload.get("reason", "http security review")),
        )
    return None


def _int(value: str | None, default: int) -> int:
    return _bounded_int(value, default, maximum=_MAX_PAGE_SIZE)


def _status_from_ok(payload: dict[str, Any]) -> tuple[int, dict[str, Any]]:
    return (200 if payload.get("ok") else 404), payload


def _unauthorized() -> tuple[int, dict[str, Any]]:
    return 401, {"ok": False, "status": "unauthorized", "error": "unauthorized"}


def _bind_principal_identity(payload: dict[str, Any], principal: Principal) -> dict[str, Any]:
    """Replace caller-selected authority fields with transport-bound identity."""
    result = dict(payload)
    subject_fields = {
        "actor",
        "approver",
        "approved_by",
        "author",
        "requested_by",
        "reviewer",
        "subject",
        "validator",
    }
    audit_actor = _principal_actor(principal)
    for key in subject_fields:
        result[key] = audit_actor
    result["role"] = sorted(principal.roles)[0] if principal.roles else "none"
    result["roles"] = sorted(principal.roles)
    return result


def _principal_actor(principal: Principal) -> str:
    for role in ("admin", "codeowner", "reviewer", "operator", "reader"):
        if role in principal.roles:
            return f"{role}:{principal.credential_id}"
    return f"authenticated:{principal.credential_id}"


def _public_scorecard(scorecard: dict[str, Any]) -> dict[str, Any]:
    if not scorecard.get("ok", True):
        return scorecard
    public_keys = {
        "ok",
        "schema_version",
        "created_at",
        "mode",
        "arms",
        "delta",
        "pack_quality",
        "loop_closure",
        "gate",
        "reproduction",
        "scorecard_id",
        "eval_run_id",
        "audit_hash",
    }
    return {key: scorecard[key] for key in public_keys if key in scorecard}


def create_http_server(
    workspace: str | Path,
    host: str = "127.0.0.1",
    port: int = 8765,
    token_env: str = "PERSISTMIND_TOKEN",
    auth_mode: str = "none",
) -> ThreadingHTTPServer:
    from persistmind.config import load_settings
    from persistmind.product.runtime_profile import (
        capability_status_document,
        http_feature_denial,
    )

    workspace_path = Path(workspace)
    settings = load_settings(workspace_path)
    from persistmind.release_identity import validate_internal_preview_server_binding

    validate_internal_preview_server_binding(settings.profile.name, host)
    team_preview = settings.profile.name == "team-preview"
    if team_preview and "DF-09" not in settings.deferred.enabled:
        raise PermissionError("team-preview HTTP server requires explicit deferred.enabled DF-09")
    validate_server_bind(
        host,
        auth_mode,
        profile=settings.profile.name,
        reverse_proxy_tls=settings.server.reverse_proxy_tls,
        remote_bind_authorized=settings.server.remote_bind_authorized,
    )
    validate_server_auth(
        auth_mode,
        token_env,
        oidc_issuer=settings.server.oidc_issuer,
        oidc_audience=settings.server.oidc_audience,
        oidc_key_env=settings.server.oidc_key_env,
        expected_tenant_id=settings.server.team_tenant_id,
    )
    startup_capabilities = capability_status_document(settings)
    if team_preview:
        from persistmind.deferred.team import TeamRateLimiter

        team_rate_limiter = TeamRateLimiter()
    else:
        team_rate_limiter = None

    class Handler(BaseHTTPRequestHandler):
        def setup(self) -> None:
            super().setup()
            self.connection.settimeout(_REQUEST_TIMEOUT_SECONDS)

        def _json(self, status: int, payload: dict[str, Any]) -> None:
            operation = f"http:{getattr(self, 'command', 'REQUEST')}:{urlparse(self.path).path}"
            envelope = finalize_result(payload, operation=operation)
            if not envelope["ok"]:
                status = http_status_for_result(envelope)
            body = json.dumps(envelope).encode("utf-8")
            if len(body) > _MAX_RESPONSE_BYTES:
                status = 507
                body = json.dumps(
                    {
                        "ok": False,
                        "status": "response_budget_exceeded",
                        "error": "response exceeds the configured byte budget",
                    }
                ).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _html(self, status: int, body: str) -> None:
            encoded = body.encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(encoded)))
            self.end_headers()
            self.wfile.write(encoded)

        def _body(self) -> dict[str, Any]:
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError as exc:
                raise ValueError("invalid Content-Length") from exc
            if length < 0 or length > _MAX_BODY_BYTES:
                raise OverflowError("request body exceeds 1048576 bytes")
            if not length:
                return {}
            value = json.loads(self.rfile.read(length).decode("utf-8"))
            if not isinstance(value, dict):
                raise ValueError("request JSON body must be an object")
            return value

        def _collector_body(self, maximum: int) -> bytes:
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError as exc:
                raise ValueError("invalid Content-Length") from exc
            if length <= 0 or length > maximum:
                raise OverflowError("collector package exceeds the configured size limit")
            value = self.rfile.read(length)
            declared = str(self.headers.get("X-PersistMind-Package-SHA256") or "")
            observed = hashlib.sha256(value).hexdigest()
            if not declared or declared != observed:
                raise ValueError("collector package checksum mismatch")
            return value

        def _browser_allowed(self) -> bool:
            return browser_request_allowed(
                self.headers.get("Host"),
                self.headers.get("Origin"),
                team_preview=team_preview,
            )

        def _dispatch(self, method: str) -> None:
            if not self._browser_allowed():
                self._json(
                    403, {"ok": False, "status": "forbidden", "error": "invalid Host or Origin"}
                )
                return
            try:
                request_path = urlparse(self.path).path.rstrip("/") or "/"
                authentication = authenticate_http(
                    self.headers.get("Authorization"),
                    workspace_path,
                    token_env,
                    auth_mode=auth_mode,
                    oidc_issuer=settings.server.oidc_issuer,
                    oidc_audience=settings.server.oidc_audience,
                    oidc_key_env=settings.server.oidc_key_env,
                    expected_tenant_id=settings.server.team_tenant_id,
                )
                public_read = method == "GET" and request_path in PUBLIC_HTTP_READ_ROUTES
                if (
                    auth_mode in {"token", "oidc"}
                    and not authentication.authenticated
                    and not public_read
                ):
                    self._json(
                        401,
                        {
                            "ok": False,
                            "status": "unauthorized",
                            "error": "missing or invalid bearer credential",
                        },
                    )
                    return
                if team_preview and method != "GET":
                    self._json(
                        405,
                        {
                            "ok": False,
                            "status": "team_preview_read_only",
                            "error": "remote mutations use a separately authorized capability broker",
                        },
                    )
                    return
                if public_read:
                    self._json(200, {"ok": True})
                    return
                if team_preview and (
                    authentication.principal is None
                    or team_rate_limiter is None
                    or not team_rate_limiter.allow(authentication.principal.tenant_id or "")
                ):
                    self._json(
                        429,
                        {
                            "ok": False,
                            "status": "rate_limited",
                            "error": "tenant request budget exceeded",
                        },
                    )
                    return
                if method != "GET" and not authentication.authenticated:
                    self._json(
                        403,
                        {
                            "ok": False,
                            "status": "transport_authority_required",
                            "error": (
                                "mutating HTTP requests require an authenticated "
                                "transport principal"
                            ),
                        },
                    )
                    return
                action = http_route_action(method, request_path)
                if action is None:
                    self._json(
                        404,
                        {
                            "ok": False,
                            "status": "not_found",
                            "error": "route is not registered",
                        },
                    )
                    return
                principal = authentication.principal
                if principal is None:
                    self._json(
                        403,
                        {
                            "ok": False,
                            "status": "forbidden",
                            "error": "route requires a transport principal",
                        },
                    )
                    return
                try:
                    require_authorized(principal, action, workspace_path)
                except PermissionError as exc:
                    self._json(
                        403,
                        {"ok": False, "status": "forbidden", "error": str(exc)},
                    )
                    return
                denial = http_feature_denial(load_settings(workspace_path), method, self.path)
                if denial is not None:
                    self._json(403, denial)
                    return
                if request_path == "/v1/collector/incidents" and method == "POST":
                    if os.environ.get("PERSISTMIND_COLLECTOR_MODE") != "1":
                        self._json(
                            403,
                            {
                                "ok": False,
                                "status": "forbidden",
                                "error": "collector authority is disabled for this server",
                            },
                        )
                        return
                    from persistmind.reporting.ingestion import CollectorIngestionService
                    from persistmind.utils import stable_id

                    reporting_config = load_settings(workspace_path).reporting
                    package = self._collector_body(reporting_config.max_package_bytes)
                    incoming = (
                        workspace_path / ".persistmind" / "diagnostics" / "collector" / "incoming"
                    )
                    incoming.mkdir(parents=True, exist_ok=True)
                    descriptor, temporary_name = tempfile.mkstemp(suffix=".zip", dir=incoming)
                    temporary = Path(temporary_name)
                    try:
                        with os.fdopen(descriptor, "wb") as handle:
                            handle.write(package)
                            handle.flush()
                            os.fsync(handle.fileno())
                        accepted = CollectorIngestionService(workspace_path).ingest(
                            temporary, source="https_collector"
                        )
                    finally:
                        temporary.unlink(missing_ok=True)
                    collector_status = str(accepted.get("status") or "rejected")
                    receipt_status = (
                        collector_status
                        if collector_status in {"accepted", "duplicate"}
                        else "rejected"
                    )
                    self._json(
                        202 if receipt_status != "rejected" else 422,
                        {
                            "ok": receipt_status != "rejected",
                            "status": receipt_status,
                            "receipt_id": "PM-RCP-"
                            + stable_id(
                                str(accepted.get("ingest_run_id") or ""),
                                hashlib.sha256(package).hexdigest(),
                            )[:24],
                            "occurrence_id": accepted.get("occurrence_id"),
                            "ingest_run_id": accepted.get("ingest_run_id"),
                        },
                    )
                    return
                if request_path == "/v1/capabilities/status":
                    # This is a fresh declarative profile projection. It is not
                    # a storage-readiness probe or release-qualification result.
                    self._json(
                        200,
                        capability_status_document(load_settings(workspace_path), workspace_path),
                    )
                    return
                body = self._body() if method != "GET" else None
                authorized = authentication.authenticated
                if request_path in {"/", "/dashboard"}:
                    with OperationClient(workspace_path) as service:
                        self._html(
                            200,
                            render_dashboard_html(service.dashboard_data()["dashboard"]),
                        )
                    return
                if request_path.startswith("/v1/storage"):
                    status, payload = handle_http_request(
                        StorageControlPlane(workspace_path),
                        method,
                        self.path,
                        body,
                        authorized=authorized,
                        principal=principal,
                    )
                elif _nextgen_request(request_path, workspace_path, _PACK_PREFIXES):
                    with PackService(workspace_path) as pack_service:
                        status, payload = handle_http_request(
                            pack_service,
                            method,
                            self.path,
                            body,
                            authorized=authorized,
                            principal=principal,
                        )
                elif _nextgen_request(request_path, workspace_path, _TASK_PREFIXES):
                    with TaskService(workspace_path) as task_service:
                        status, payload = handle_http_request(
                            task_service,
                            method,
                            self.path,
                            body,
                            authorized=authorized,
                            principal=principal,
                        )
                elif _nextgen_request(request_path, workspace_path, ("/v1/audit",)):
                    with AuditService(workspace_path) as audit_service:
                        status, payload = handle_http_request(
                            audit_service,
                            method,
                            self.path,
                            body,
                            authorized=authorized,
                            principal=principal,
                        )
                elif _nextgen_request(request_path, workspace_path, _ACTIVITY_PREFIXES):
                    with ActivityService(workspace_path) as activity_service:
                        status, payload = handle_http_request(
                            activity_service,
                            method,
                            self.path,
                            body,
                            authorized=authorized,
                            principal=principal,
                        )
                elif _nextgen_request(request_path, workspace_path, ("/v1/source",)):
                    with SourceService(workspace_path) as source_service:
                        status, payload = handle_http_request(
                            source_service,
                            method,
                            self.path,
                            body,
                            authorized=authorized,
                            principal=principal,
                        )
                elif _nextgen_request(request_path, workspace_path, _LEARNING_PREFIXES):
                    with LearningService(workspace_path) as learning_service:
                        status, payload = handle_http_request(
                            learning_service,
                            method,
                            self.path,
                            body,
                            authorized=authorized,
                            principal=principal,
                        )
                elif _nextgen_request(request_path, workspace_path, ("/v1/policies",)):
                    with PolicyService(workspace_path) as policy_service:
                        status, payload = handle_http_request(
                            policy_service,
                            method,
                            self.path,
                            body,
                            authorized=authorized,
                            principal=principal,
                        )
                elif _nextgen_request(request_path, workspace_path, ("/v1/memory",)):
                    with KnowledgeService(workspace_path) as knowledge_service:
                        status, payload = handle_http_request(
                            knowledge_service,
                            method,
                            self.path,
                            body,
                            authorized=authorized,
                            principal=principal,
                        )
                else:
                    with OperationClient(workspace_path) as service:
                        status, payload = handle_http_request(
                            service,
                            method,
                            self.path,
                            body,
                            authorized=authorized,
                            principal=principal,
                        )
                self._json(status, payload)
            except OverflowError as exc:
                self._json(413, {"ok": False, "status": "validation_failed", "error": str(exc)})
            except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
                self._json(400, {"ok": False, "status": "validation_failed", "error": str(exc)})
            except Exception as exc:  # noqa: BLE001 - normalize without exposing internals.
                envelope = exception_result(
                    exc,
                    operation=f"http:{method}:{urlparse(self.path).path}",
                    expose_error=False,
                )
                self._json(http_status_for_result(envelope), envelope)

        def do_GET(self) -> None:
            self._dispatch("GET")

        def do_PATCH(self) -> None:
            with _WRITE_LOCK:
                self._dispatch("PATCH")

        def do_POST(self) -> None:
            with _WRITE_LOCK:
                self._dispatch("POST")

        def do_DELETE(self) -> None:
            with _WRITE_LOCK:
                self._dispatch("DELETE")

    server = BoundedThreadingHTTPServer((host, port), Handler)
    # Expose the startup declaration for diagnostics without presenting it as
    # a live availability or release-evidence probe.
    server.persistmind_startup_capabilities = startup_capabilities  # type: ignore[attr-defined]
    return server


def serve(
    workspace: str | Path,
    host: str = "127.0.0.1",
    port: int = 8765,
    token_env: str = "PERSISTMIND_TOKEN",
    auth_mode: str = "none",
) -> None:
    server = create_http_server(workspace, host, port, token_env, auth_mode)
    try:
        server.serve_forever()
    finally:
        server.server_close()


def _nextgen_request(path: str, repo_root: Path, prefixes: tuple[str, ...]) -> bool:
    if not path.startswith(prefixes):
        return False
    from persistmind.config import load_settings
    from persistmind.storage.runtime import inspect_storage

    settings = load_settings(repo_root)
    return inspect_storage(repo_root / settings.toolchain.workspace_dir).initialized
