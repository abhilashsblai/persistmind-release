from __future__ import annotations

from urllib.parse import parse_qs


def query_params(raw_query: str) -> dict[str, str]:
    return {key: values[-1] for key, values in parse_qs(raw_query).items() if values}


def csv(value: str | None) -> list[str] | None:
    if not value:
        return None
    return [item.strip() for item in value.split(",") if item.strip()]


def bounded_int(value: str | None, default: int, *, maximum: int) -> int:
    if value is None or value == "":
        return default
    return max(1, min(int(value), maximum))


def bool_value(value: str | None) -> bool:
    return str(value).lower() in {"1", "true", "yes", "on"}
