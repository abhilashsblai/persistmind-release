from __future__ import annotations

import hmac
import ipaddress
import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

from persistmind.security.principals import Principal
from persistmind.utils import stable_id

AUTH_MODES = {"none", "token", "oidc"}


@dataclass(frozen=True)
class AuthenticationResult:
    status: str
    principal: Principal | None

    @property
    def authenticated(self) -> bool:
        return self.status == "authenticated" and self.principal is not None


def authenticate_http(
    header: str | None,
    repo: str | Path,
    token_env: str,
    *,
    auth_mode: str,
    oidc_issuer: str = "",
    oidc_audience: str = "persistmind",
    oidc_key_env: str = "PERSISTMIND_OIDC_KEY",
    expected_tenant_id: str = "",
) -> AuthenticationResult:
    """Authenticate once and construct authority only from that result."""

    if auth_mode not in AUTH_MODES:
        raise ValueError(f"unsupported server auth mode: {auth_mode}")
    if auth_mode == "none":
        from persistmind.security.principals import anonymous_principal

        return AuthenticationResult("anonymous", anonymous_principal(repo))
    if auth_mode == "oidc":
        supplied = header.removeprefix("Bearer ") if header else ""
        key = os.environ.get(oidc_key_env)
        if (
            not supplied
            or not key
            or not oidc_issuer
            or not oidc_audience
            or not expected_tenant_id
        ):
            return AuthenticationResult("unauthorized", None)
        from persistmind.deferred.team import verify_oidc_token

        try:
            verified = verify_oidc_token(
                supplied,
                key=key,
                issuer=oidc_issuer,
                audience=oidc_audience,
                algorithms=("RS256", "ES256", "HS256"),
            )
        except Exception:  # noqa: BLE001 - authentication always fails closed.
            return AuthenticationResult("unauthorized", None)
        if verified.tenant_id != expected_tenant_id:
            return AuthenticationResult("unauthorized", None)
        scope = str(Path(repo).resolve())
        repository_id = stable_id(scope)[:16]
        if repository_id not in verified.repository_ids and scope not in verified.repository_ids:
            return AuthenticationResult("unauthorized", None)
        roles = frozenset(set(verified.roles).intersection({"reader", "operator", "admin"}))
        if not roles:
            roles = frozenset({"reader"})
        return AuthenticationResult(
            "authenticated",
            Principal(
                subject=verified.subject,
                roles=roles,
                repo_scopes=frozenset({scope}),
                workspace_scopes=frozenset({scope}),
                auth_source="oidc",
                credential_id=stable_id("oidc", verified.issuer, verified.subject)[:16],
                expires_at=None,
                tenant_id=verified.tenant_id,
            ),
        )
    if not authorize(header, token_env, auth_mode=auth_mode):
        return AuthenticationResult("unauthorized", None)
    token = os.environ.get(token_env) or ""
    credential_id = stable_id("http_credential", token)[:16]
    scope = str(Path(repo).resolve())
    return AuthenticationResult(
        "authenticated",
        Principal(
            subject=f"authenticated:{credential_id}",
            roles=frozenset({"operator"}),
            repo_scopes=frozenset({scope}),
            workspace_scopes=frozenset({scope}),
            auth_source="http_bearer",
            credential_id=credential_id,
        ),
    )


def authorize(header: str | None, token_env: str, *, auth_mode: str) -> bool:
    if auth_mode not in AUTH_MODES:
        raise ValueError(f"unsupported server auth mode: {auth_mode}")
    if auth_mode == "none":
        return False
    expected = os.environ.get(token_env)
    if not expected:
        return False
    supplied = header.removeprefix("Bearer ") if header else ""
    return bool(supplied) and hmac.compare_digest(supplied, expected)


def validate_server_auth(
    auth_mode: str,
    token_env: str,
    *,
    oidc_issuer: str = "",
    oidc_audience: str = "persistmind",
    oidc_key_env: str = "PERSISTMIND_OIDC_KEY",
    expected_tenant_id: str = "",
) -> None:
    if auth_mode not in AUTH_MODES:
        raise ValueError(f"unsupported server auth mode: {auth_mode}")
    if auth_mode == "token" and not os.environ.get(token_env):
        raise PermissionError(
            f"auth=token requires a non-empty secret in environment variable {token_env}"
        )
    if auth_mode == "oidc" and (
        not oidc_issuer
        or not oidc_audience
        or not expected_tenant_id
        or not os.environ.get(oidc_key_env)
    ):
        raise PermissionError(
            "auth=oidc requires issuer, audience, expected tenant, and a verification key in "
            f"environment variable {oidc_key_env}"
        )


def is_loopback_host(host: str) -> bool:
    normalized = host.strip().strip("[]")
    if normalized.casefold() == "localhost":
        return True
    try:
        return ipaddress.ip_address(normalized).is_loopback
    except ValueError:
        return False


def validate_server_bind(
    host: str,
    auth_mode: str,
    *,
    profile: str = "core-local",
    reverse_proxy_tls: bool = False,
    remote_bind_authorized: bool = False,
) -> None:
    if profile == "team-preview":
        from persistmind.deferred.team import team_bind_policy

        result = team_bind_policy(
            profile=profile,
            auth=auth_mode,
            host=host,
            reverse_proxy_tls=reverse_proxy_tls,
            remote_bind_authorized=remote_bind_authorized,
        )
        if not result["ok"]:
            raise PermissionError(
                "team-preview server binding refused: " + ", ".join(result["reasons"])
            )
        return
    if not is_loopback_host(host):
        raise PermissionError(
            "the built-in HTTP server is a loopback-only local-development profile"
        )
    if auth_mode == "none" and not is_loopback_host(host):
        raise PermissionError("auth=none is loopback-only")


def browser_request_allowed(
    host_header: str | None, origin: str | None, *, team_preview: bool = False
) -> bool:
    host = (host_header or "").split(":", 1)[0].strip("[]")
    if team_preview:
        if not host:
            return False
        if not origin:
            return True
        parsed = urlparse(origin)
        return parsed.scheme == "https" and (parsed.hostname or "").casefold() == host.casefold()
    if not is_loopback_host(host):
        return False
    if not origin:
        return True
    parsed = urlparse(origin)
    return parsed.scheme in {"http", "https"} and is_loopback_host(parsed.hostname or "")


def http_principal(
    repo: str, token_env: str, *, auth_mode: str, header: str | None = None
) -> Principal:
    """Compatibility helper that now fails unless authentication succeeded."""

    result = authenticate_http(header, repo, token_env, auth_mode=auth_mode)
    if result.principal is None:
        raise PermissionError("request credential is missing or invalid")
    return result.principal
