from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from persistmind import __version__
from persistmind.agents.adapters import known_agent_names
from persistmind.cli_support import (
    agent_gate_thresholds as _agent_gate_thresholds,
)
from persistmind.cli_support import (
    changed_paths as _nextgen_task_changed_paths,
)
from persistmind.cli_support import (
    csv_or_space as _nextgen_csv_or_space,
)
from persistmind.cli_support import (
    nonblocking_constitution_bootstrap_gap as _nonblocking_constitution_bootstrap_gap,
)
from persistmind.cli_support import (
    normalize_global_args as _normalize_global_args,
)
from persistmind.cli_support import (
    npx_doctor as _npx_doctor_result,
)
from persistmind.cli_support import (
    npx_update as _npx_update_result,
)
from persistmind.config import load_settings
from persistmind.interfaces import exit_code_for_result, finalize_result
from persistmind.interfaces.token_surface import configure_token_parser, token_record_request
from persistmind.path_input import normalize_diff_input, normalize_path_records, read_path_records
from persistmind.runtime.operations import operations_status
from persistmind.storage.errors import classify_sqlite_error
from persistmind.workflow.classifier import PREFLIGHT_MODES, WORKFLOW_MODES

if TYPE_CHECKING:
    from persistmind.composition.registry import OperationClient
    from persistmind.runtime_invocation import RuntimeInvocation

class CliInputError(ValueError):
    status = "validation_failed"

    def __init__(self, message: str, *, path: Path | None = None, remediation: str | None = None):
        self.path = str(path) if path is not None else None
        self.remediation = remediation
        super().__init__(message)


def main(argv: list[str] | None = None, *, prog: str = "persistmind") -> None:
    normalized = _normalize_global_args(list(sys.argv[1:] if argv is None else argv))
    repo = Path(".")
    for index, value in enumerate(normalized):
        if value == "--repo" and index + 1 < len(normalized):
            repo = Path(normalized[index + 1])
            break
        if value.startswith("--repo="):
            repo = Path(value.split("=", 1)[1])
            break
    from persistmind.security.actions import local_cli_principal
    from persistmind.security.context import principal_scope

    with principal_scope(local_cli_principal(repo)):
        _main_impl(normalized, prog=prog)


def _main_impl(argv: list[str], *, prog: str) -> None:
    from persistmind.updater.dispatch import maybe_dispatch

    try:
        dispatched = maybe_dispatch(argv)
    except Exception as exc:  # bootstrap failures still use the public envelope
        from persistmind.updater.errors import UpdateError

        if not isinstance(exc, UpdateError):
            raise
        envelope = finalize_result(
            {
                "ok": False,
                "status": exc.status,
                "error": str(exc),
                "remediation": exc.remediation,
            },
            operation="bootstrap_dispatch",
            failed_stage="engine_selection",
        )
        print(json.dumps(envelope, indent=2), file=sys.stderr)
        raise SystemExit(exit_code_for_result(envelope)) from exc
    if dispatched is not None:
        raise SystemExit(dispatched)
    parser = argparse.ArgumentParser(prog=prog)
    display_name = "PersistMind" if prog == "persistmind" else prog
    from persistmind.release_identity import version_banner

    parser.add_argument("--version", action="version", version=version_banner(display_name))
    parser.add_argument("--repo", default=".", help="Repository root")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("version")
    sub.add_parser("status", help="Show runtime profile and immutable build identity")
    internal = sub.add_parser("internal", help=argparse.SUPPRESS)
    internal_sub = internal.add_subparsers(dest="internal_command", required=True)
    project_upgrade = internal_sub.add_parser("project-upgrade")
    project_upgrade_sub = project_upgrade.add_subparsers(
        dest="project_upgrade_action", required=True
    )
    project_upgrade_sub.add_parser("plan")
    project_apply = project_upgrade_sub.add_parser("apply")
    project_apply.add_argument("--transaction", required=True)
    project_verify = project_upgrade_sub.add_parser("verify")
    project_verify.add_argument("--transaction", required=True)
    update = sub.add_parser(
        "update", help="Update this project from a verified PersistMind release manifest"
    )
    update.add_argument("update_action", nargs="?", choices=["apply", "status"], default="apply")
    update.add_argument(
        "--check", action="store_true", help="Check for an update without changing state"
    )
    update.add_argument("--channel", choices=["stable", "preview"])
    update.add_argument("--version", dest="update_version")
    update.add_argument("--dry-run", action="store_true")
    update.add_argument("--force", action="store_true")
    update.add_argument("--rollback", action="store_true")
    sub.add_parser("init")
    index = sub.add_parser("index")
    index.add_argument(
        "--summary", action="store_true", help="Print only snapshot identity and status"
    )
    from persistmind.agent_runtime.operations import OPERATIONS

    agent_runtime = sub.add_parser("agent-runtime", help="Operate the protocol-v2 agent runtime")
    agent_runtime.add_argument("agent_runtime_operation", choices=OPERATIONS)
    agent_runtime.add_argument(
        "--request",
        default="{}",
        help="bounded JSON request object; use --request-file for secrets or large input",
    )
    agent_runtime.add_argument("--request-file", type=Path)
    coordinator = sub.add_parser("coordinator")
    coordinator.add_argument("coordinator_command", choices=["status", "drain"])
    coordinator.add_argument("--max-jobs", type=int, default=4)
    coordinator.add_argument("--max-seconds", type=float, default=2.0)
    sub.add_parser("resolve-snapshot")
    snapshot_cmd = sub.add_parser("snapshot")
    snapshot_cmd.add_argument("snapshot_command", choices=["current", "lineage"])
    snapshot_cmd.add_argument("--snapshot-id")
    snapshot_cmd.add_argument("--limit", type=int, default=50)

    bootstrap = sub.add_parser("bootstrap")
    bootstrap.add_argument("--agents", default="codex,claude")
    bootstrap.add_argument("--mcp-command", default="persistmind")
    bootstrap.add_argument("--absolute-mcp-repo", action="store_true")
    bootstrap.add_argument("--skip-index", action="store_true")
    _add_runtime_invocation_args(bootstrap)

    setup = sub.add_parser("setup")
    setup.add_argument("setup_command", nargs="?")
    setup.add_argument("--agents", default=None)
    setup.add_argument("--mcp-command", default="persistmind")
    setup.add_argument("--install-hooks", action="store_true")
    setup.add_argument("--no-git-hooks", dest="install_hooks", action="store_false")
    setup.add_argument("--configure-mcp", action="store_true")
    setup.add_argument("--init-git", action="store_true")
    setup.add_argument("--absolute-mcp-repo", action="store_true")
    setup.add_argument("--codex-config")
    setup.add_argument("--skip-index", action="store_true")
    _add_runtime_invocation_args(setup)

    quickstart = sub.add_parser("quickstart")
    quickstart.add_argument("--agents", default="codex")
    quickstart.add_argument("--mcp-command", default="persistmind")
    quickstart.add_argument("--install-hooks", action=argparse.BooleanOptionalAction, default=False)
    quickstart.add_argument("--configure-mcp", action=argparse.BooleanOptionalAction, default=False)
    quickstart.add_argument("--init-git", action="store_true")
    quickstart.add_argument("--absolute-mcp-repo", action=argparse.BooleanOptionalAction, default=False)
    quickstart.add_argument("--codex-config")
    _add_runtime_invocation_args(quickstart)

    install = sub.add_parser(
        "install",
        help="Install PersistMind next-generation storage and coding-agent surfaces in one transaction",
    )
    install.add_argument("--agents", default=None)
    install.add_argument(
        "--auto-agent",
        action="store_true",
        help="Detect supported coding agents from the current environment",
    )
    install.add_argument("--mcp-command", default="persistmind")
    install.add_argument("--install-hooks", action=argparse.BooleanOptionalAction, default=True)
    install.add_argument("--configure-mcp", action=argparse.BooleanOptionalAction, default=True)
    install.add_argument("--init-git", action="store_true")
    install.add_argument("--absolute-mcp-repo", action=argparse.BooleanOptionalAction, default=True)
    install.add_argument("--codex-config")
    install.add_argument("--skip-index", action="store_true")
    _add_runtime_invocation_args(install)

    config = sub.add_parser("config")
    config.add_argument("config_command", choices=["validate", "show-effective"])

    pack = sub.add_parser("pack")
    pack.add_argument("--task")
    pack.add_argument("--budget", type=int)
    pack.add_argument("--seed-path", action="append", default=[])
    pack.add_argument("--seed-from-diff", action="store_true")
    pack.add_argument("--intent-id")
    pack.add_argument("--goal-id")
    pack.add_argument("--task-session-id")
    pack.add_argument("--bind-snapshot")
    pack.add_argument("--no-rerank", action="store_true")
    pack.add_argument("--summary", action="store_true", help="Print only IDs and actionable status")
    pack.add_argument(
        "--verbose", action="store_true", help="Print the complete context-pack payload"
    )

    intent = sub.add_parser("intent")
    intent.add_argument("intent_command", choices=["start", "show", "refine", "list"])
    intent.add_argument("intent_arg", nargs="?")
    intent.add_argument("--problem")
    intent.add_argument("--llm-propose", action="store_true")
    intent.add_argument("--evidence", action="append", default=[])
    intent.add_argument("--select-goal")
    intent.add_argument("--status")
    intent.add_argument("--limit", type=int, default=50)

    goal = sub.add_parser("goal")
    goal.add_argument(
        "goal_command",
        choices=[
            "evaluate",
            "show",
            "challenge",
            "accept-alternative",
            "reject-alternative",
            "reevaluate",
            "list",
        ],
    )
    goal.add_argument("goal_arg", nargs="?")
    goal.add_argument("--candidate", dest="candidate_goal_id")
    goal.add_argument("--mode", choices=["silent", "warn", "pause-and-challenge"])
    goal.add_argument("--alt", dest="alt_id")
    goal.add_argument("--rationale")
    goal.add_argument("--status")
    goal.add_argument("--limit", type=int, default=50)
    goal.add_argument("--trigger", default="manual")

    manifest = sub.add_parser("manifest")
    manifest.add_argument("--pack-id", required=True)

    reconstruct = sub.add_parser("reconstruct-pack")
    reconstruct.add_argument("--pack-id", required=True)
    reconstruct.add_argument("--task-text")

    impact = sub.add_parser("impact")
    impact.add_argument("--pack-id")
    impact.add_argument("--paths", nargs="*", default=[])
    impact.add_argument("--paths-from-stdin", action="store_true")
    impact.add_argument("--diff-from-stdin", action="store_true")
    impact.add_argument("--business", action="store_true")
    impact.add_argument("--summary", action="store_true", help="Print a concise impact summary")

    anticipate = sub.add_parser("anticipate")
    anticipate.add_argument(
        "anticipate_command",
        choices=[
            "train",
            "score",
            "status",
            "doctor",
            "benchmark",
            "shadow-validate",
            "consult",
            "lookahead",
            "simulate",
            "ui-review",
            "transfer-export",
            "transfer-status",
            "gut",
        ],
    )
    anticipate.add_argument("anticipate_arg", nargs="?")
    anticipate.add_argument("--session", dest="anticipate_session")
    anticipate.add_argument("--task", dest="anticipate_task")
    anticipate.add_argument("--paths", nargs="*", default=[])
    anticipate.add_argument("--top-k", type=int, default=5)
    anticipate.add_argument("--depth", type=int, default=2)
    anticipate.add_argument("--beam", type=int, default=3)
    anticipate.add_argument("--arms", default="baseline,frequency_v0,embedding_v1")
    anticipate.add_argument("--threshold", type=float, default=0.55)
    anticipate.add_argument("--limit", type=int, default=200)
    anticipate.add_argument("--holdout-ratio", type=float, default=0.3)
    anticipate.add_argument("--ece-bins", type=int, default=10)
    anticipate.add_argument(
        "--semantic-model",
        default="sentence-transformers/all-MiniLM-L6-v2",
    )
    anticipate.add_argument("--semantic-backend", default="sentence-transformers")
    anticipate.add_argument("--mode", default="shadow")

    business = sub.add_parser("business")
    business.add_argument("business_command", choices=["entity", "link"])
    business.add_argument(
        "business_action", choices=["add", "list", "approve", "reject"], nargs="?"
    )
    business.add_argument("business_arg", nargs="?")
    business.add_argument("--type", dest="business_type")
    business.add_argument("--name")
    business.add_argument("--file")
    business.add_argument("--attrs", default="{}")
    business.add_argument("--origin", default="manual")
    business.add_argument("--source-type")
    business.add_argument("--source-ref")
    business.add_argument("--proposed-by", default="user")
    business.add_argument("--confidence", type=float, default=0.9)
    business.add_argument("--status")
    business.add_argument("--limit", type=int, default=100)
    business.add_argument("--approver", default="human")
    business.add_argument("--notes", default="")
    business.add_argument("--reason", default="")
    business.add_argument("--src")
    business.add_argument("--dst")
    business.add_argument("--kind")

    check = sub.add_parser("check-diff")
    check.add_argument("--pack-id", required=True)
    check.add_argument("--paths", nargs="*", default=[])
    check.add_argument("--paths-from-stdin", action="store_true")
    check.add_argument("--summary", action="store_true", help="Print a concise check summary")

    search = sub.add_parser("search")
    search.add_argument("query")
    search.add_argument("--limit", type=int, default=20)

    audit = sub.add_parser("audit")
    audit.add_argument(
        "audit_command",
        choices=[
            "verify",
            "record",
            "tip",
            "anchor",
            "gating-baseline",
            "gating-verify",
            "pack-manifest",
            "verify-hook-log",
        ],
    )
    audit.add_argument("--pack-id")
    audit.add_argument("--task-session")
    audit.add_argument("--output")
    audit.add_argument("--target", default="signed-file")
    audit.add_argument("--actor", default="local-user")
    audit.add_argument("--signature")
    audit.add_argument("--nonce")
    audit.add_argument("--issued-at")

    outcome = sub.add_parser("outcome")
    outcome.add_argument("--pack-id")
    outcome.add_argument("--task-session-id")
    outcome.add_argument("--result", required=True)
    outcome.add_argument("--files", nargs="*", default=None)
    outcome.add_argument("--session-id")
    outcome.add_argument("--summary", default=None)
    outcome.add_argument("--episode-eligible", action="store_true")
    outcome.add_argument("--evaluation-version-id")

    configure_token_parser(sub.add_parser("tokens"))

    activity = sub.add_parser("activity")
    activity.add_argument("activity_command", choices=["append", "show", "list", "rotate"])
    activity.add_argument("activity_arg", nargs="?")
    activity.add_argument("--type", dest="activity_type")
    activity.add_argument("--payload", default="{}")
    activity.add_argument("--idempotency-key")
    activity.add_argument("--occurred-at")
    activity.add_argument("--classification", default="internal")
    activity.add_argument("--since")
    activity.add_argument("--limit", type=int, default=100)
    activity.add_argument("--hydrate", action="store_true")

    bench = sub.add_parser("bench")
    bench.add_argument("bench_command", nargs="?", choices=["show", "retention"])
    bench.add_argument("bench_retention_command", nargs="?", choices=["set", "check"])
    bench.add_argument("--persist", dest="bench_persist", action="store_true", default=True)
    bench.add_argument("--no-persist", dest="bench_persist", action="store_false")
    bench.add_argument("--split", choices=["train", "holdout"], default="holdout")
    bench.add_argument("--limit", type=int, default=20)
    bench.add_argument("--task-set", default="default")
    bench.add_argument("--created-by", default="local-user")
    bench.add_argument("--run-id")
    bench.add_argument("--floor-ratio", type=float, default=1.0)
    bench.add_argument("--metric", dest="bench_metrics", action="append", default=[])

    working_memory = sub.add_parser("working-memory")
    working_memory.add_argument(
        "working_memory_command", choices=["capture", "list", "promote", "decline"]
    )
    working_memory.add_argument("working_memory_arg", nargs="?")
    working_memory.add_argument("--task-session-id")
    working_memory.add_argument("--cycle-id")
    working_memory.add_argument("--kind", default="observation")
    working_memory.add_argument("--text")
    working_memory.add_argument("--salience", type=float, default=0.5)
    working_memory.add_argument("--evidence", action="append", default=[])
    working_memory.add_argument("--expires-at")
    working_memory.add_argument("--limit", type=int, default=64)
    working_memory.add_argument("--actor", default="local-user")
    working_memory.add_argument("--validator", default="human:working-memory")

    foresight = sub.add_parser("foresight")
    foresight.add_argument("foresight_command", choices=["for"])
    foresight.add_argument("--path", dest="foresight_paths", action="append", default=[])
    foresight.add_argument("--limit", type=int, default=8)
    foresight.add_argument("--max-commits", type=int, default=300)

    reasoning = sub.add_parser("reasoning")
    reasoning.add_argument("reasoning_command", choices=["route", "checkpoint"])
    reasoning.add_argument("--task", required=True)
    reasoning.add_argument("--checkpoint", default="pre_write")
    reasoning.add_argument("--task-session-id")
    reasoning.add_argument("--surprise", type=float)
    reasoning.add_argument("--path", dest="reasoning_paths", action="append", default=[])

    experience = sub.add_parser("experience")
    experience.add_argument("experience_command", choices=["record", "list"])
    experience.add_argument("--task")
    experience.add_argument("--path", dest="experience_paths", action="append", default=[])
    experience.add_argument("--surprise", type=float, default=0.0)
    experience.add_argument("--trigger", default="manual")
    experience.add_argument("--evidence", action="append", default=[])
    experience.add_argument("--status")
    experience.add_argument("--limit", type=int, default=20)

    critique = sub.add_parser("critique")
    critique.add_argument("critique_command", choices=["workspace"])
    critique.add_argument("--task", required=True)
    critique.add_argument("--path", dest="critique_paths", action="append", default=[])
    critique.add_argument("--diff", default="")
    critique.add_argument("--risk-threshold", type=int, default=8)

    flywheel = sub.add_parser("flywheel")
    flywheel.add_argument("flywheel_command", choices=["status", "maintain"])
    db = sub.add_parser("db")
    db.add_argument("db_command", choices=["bench", "backend-status", "probe", "check", "repair"])
    db.add_argument("--history", action="store_true")
    db.add_argument("--limit", type=int, default=20)
    db.add_argument("--corpus", action="append", type=int, default=[])
    db.add_argument("--full", action="store_true")
    db.add_argument("--timeout", type=float, default=60.0)
    db.add_argument("--dry-run", action="store_true")
    db.add_argument("--yes", action="store_true")
    db.add_argument("--accept-skipped-manifest")
    operations = sub.add_parser("operations")
    operations.add_argument("operations_command", choices=["status"])
    doctor = sub.add_parser("doctor")
    doctor.add_argument("--full", action="store_true")
    doctor.add_argument("--summary", action="store_true")
    doctor.add_argument("--hook-coverage", action="store_true")
    sub.add_parser("db-stats")
    storage_report = sub.add_parser("storage-report")
    storage_report.add_argument("--limit", type=int, default=50)
    storage = sub.add_parser("storage")
    storage_sub = storage.add_subparsers(dest="storage_command", required=True)
    topology = storage_sub.add_parser("topology")
    topology.add_argument("topology_command", nargs="?", choices=["show"], default="show")
    storage_status = storage_sub.add_parser("status")
    storage_status.add_argument("--summary", action="store_true")
    storage_sub.add_parser("bootstrap")
    resources_storage = storage_sub.add_parser("resources")
    resources_storage.add_argument("resources_command", choices=["verify"])
    kinds_storage = storage_sub.add_parser("memory-kinds")
    kinds_storage.add_argument("memory_kinds_command", choices=["list"])
    roles_storage = storage_sub.add_parser("roles")
    roles_storage.add_argument("roles_command", choices=["list"])
    models_storage = storage_sub.add_parser("models")
    models_storage.add_argument("models_command", choices=["status", "install"])
    models_storage.add_argument("--source", type=Path)
    models_storage.add_argument("--yes", action="store_true")
    keys_storage = storage_sub.add_parser("keys")
    keys_storage.add_argument(
        "keys_command",
        choices=[
            "status",
            "rotate",
            "recovery-kit-create",
            "recovery-kit-verify",
            "approval-sign",
        ],
    )
    keys_storage.add_argument("--output", type=Path)
    keys_storage.add_argument("--kit", type=Path)
    keys_storage.add_argument("--yes", action="store_true")
    keys_storage.add_argument("--document", type=Path)
    keys_storage.add_argument("--principal")
    schema_storage = storage_sub.add_parser("schema")
    schema_storage.add_argument("schema_command", choices=["status", "plan", "upgrade"])
    schema_storage.add_argument("--output", type=Path)
    schema_storage.add_argument("--plan", type=Path)
    schema_storage.add_argument("--yes", action="store_true")
    partitions_storage = storage_sub.add_parser("partitions")
    partitions_storage.add_argument("partitions_command", choices=["list", "rotate"])
    partitions_storage.add_argument("--role", choices=["activity", "audit"])
    partitions_storage.add_argument("--yes", action="store_true")
    partitions_storage.add_argument("--actor", default="local-user")
    partitions_storage.add_argument("--signature")
    repair_storage = storage_sub.add_parser("repair")
    repair_storage.add_argument("--dry-run", action="store_true")
    repair_storage.add_argument("--yes", action="store_true")
    gc_storage = storage_sub.add_parser("gc")
    gc_storage.add_argument("--dry-run", action="store_true")
    gc_storage.add_argument("--yes", action="store_true")
    retention_storage = storage_sub.add_parser("retention")
    retention_storage.add_argument("retention_command", choices=["run"])
    retention_storage.add_argument("--keep-days", type=int, default=30)
    retention_storage.add_argument("--dry-run", action="store_true")
    retention_storage.add_argument("--yes", action="store_true")
    export_storage = storage_sub.add_parser("export")
    export_storage.add_argument("--scope", required=True)
    export_storage.add_argument("--output", type=Path, required=True)
    delete_storage = storage_sub.add_parser("delete")
    delete_storage.add_argument("--scope", required=True)
    delete_storage.add_argument("--dry-run", action="store_true")
    delete_storage.add_argument("--yes", action="store_true")
    holds_storage = storage_sub.add_parser("holds")
    holds_sub = holds_storage.add_subparsers(dest="holds_command", required=True)
    hold_create = holds_sub.add_parser("create")
    hold_create.add_argument("--scope", required=True)
    hold_create.add_argument("--reason", required=True)
    hold_release = holds_sub.add_parser("release")
    hold_release.add_argument("--hold", required=True)
    hold_release.add_argument("--yes", action="store_true")
    inventory_storage = storage_sub.add_parser("inventory")
    inventory_storage.add_argument("--output", type=Path)
    verify_storage = storage_sub.add_parser("verify")
    verify_storage.add_argument("--full", action="store_true")
    reconcile_storage = storage_sub.add_parser("reconcile")
    reconcile_storage.add_argument("--limit", type=int, default=100)
    recover_storage = storage_sub.add_parser("recover")
    recover_sub = recover_storage.add_subparsers(dest="recover_command", required=True)
    recover_sub.add_parser("catalog")
    recover_plan = recover_sub.add_parser("plan")
    recover_plan.add_argument("--authority", required=True)
    recover_plan.add_argument("--output", type=Path, required=True)
    recover_stage = recover_sub.add_parser("stage")
    recover_stage.add_argument("--plan", type=Path, required=True)
    recover_stage.add_argument("--backup-destination", type=Path, required=True)
    recover_stage.add_argument("--backup")
    recover_stage.add_argument("--yes", action="store_true")
    recover_status = recover_sub.add_parser("status")
    recover_status.add_argument("--stage", type=Path, required=True)
    recover_apply = recover_sub.add_parser("apply")
    recover_apply.add_argument("--stage", type=Path, required=True)
    recover_apply.add_argument("--loss-acceptance", type=Path)
    recover_apply.add_argument("--yes", action="store_true")
    recover_rollback = recover_sub.add_parser("rollback")
    recover_rollback.add_argument("--stage", type=Path, required=True)
    recover_rollback.add_argument("--yes", action="store_true")
    recover_finalize = recover_sub.add_parser("finalize")
    recover_finalize.add_argument("--stage", type=Path, required=True)
    recover_finalize.add_argument("--yes", action="store_true")
    backup_storage = storage_sub.add_parser("backup")
    backup_sub = backup_storage.add_subparsers(dest="backup_command", required=True)
    backup_create = backup_sub.add_parser("create")
    backup_create.add_argument("--verify", action="store_true")
    backup_verify = backup_sub.add_parser("verify")
    backup_verify.add_argument("--backup", required=True)
    backup_restore = backup_sub.add_parser("restore")
    backup_restore.add_argument("--backup", required=True)
    backup_restore.add_argument("--target", type=Path, required=True)
    backup_restore.add_argument("--verify-only", action="store_true")
    backup_restore.add_argument("--yes", action="store_true")
    gc = sub.add_parser("gc")
    gc.add_argument("--deep", action="store_true")
    gc.add_argument("--prune-snapshots", action="store_true")
    gc.add_argument("--archive-pruned-snapshots", action="store_true", default=None)
    gc.add_argument("--dry-run", action="store_true")

    retention = sub.add_parser("retention")
    retention.add_argument("retention_command", choices=["show", "set"])
    retention.add_argument("target", nargs="?")
    retention.add_argument("--keep-full-days", type=int)
    retention.add_argument("--keep-summary-days", type=int)
    retention.add_argument("--max-rows", type=int)
    retention.add_argument("--scope", default="global")
    retention.add_argument("--preset", choices=["conservative", "balanced", "aggressive"])

    maintenance = sub.add_parser("maintenance")
    maintenance.add_argument("maintenance_command", choices=["run", "history", "tick"])
    maintenance.add_argument("--light", action="store_true")
    maintenance.add_argument("--trigger", default="manual")
    maintenance.add_argument("--limit", type=int, default=50)

    hook = sub.add_parser("hook")
    hook.add_argument("hook_command", choices=["install"])

    constitution = sub.add_parser("constitution")
    constitution.add_argument("constitution_command", choices=["build", "show", "check"])
    constitution.add_argument("--staged", action="store_true")
    constitution.add_argument("--path", dest="constitution_paths", action="append", default=[])
    constitution.add_argument("--task-session-id")
    constitution.add_argument("--ci", action="store_true")
    constitution.add_argument("--fail-on-violation", action="store_true")
    constitution.add_argument("--actor", default="local-user")
    constitution.add_argument("--signature")
    constitution.add_argument("--nonce")
    constitution.add_argument("--issued-at")
    constitution.add_argument("--expires-at")

    task = sub.add_parser("task")
    task.add_argument(
        "task_command",
        choices=["start", "transition", "show", "learned", "close", "remediation-attempt"],
    )
    task.add_argument("task_arg", nargs="?")
    task.add_argument("--task")
    task.add_argument("--state")
    task.add_argument("--actor", default="local-user")
    task.add_argument("--reason")
    task.add_argument("--pack-id")
    task.add_argument("--result")
    task.add_argument("--blocking-gate")
    task.add_argument("--gate")
    task.add_argument("--approach")
    task.add_argument("--outcome")
    task.add_argument("--command-or-tool")
    task.add_argument("--error")
    task.add_argument("--waited-seconds", type=int)
    task.add_argument("--backoff-strategy")
    task.add_argument("--transient-recovery")
    task.add_argument(
        "--summary", action="store_true", help="Print only task/session IDs and state"
    )

    plan = sub.add_parser("plan")
    plan.add_argument("plan_command", choices=["validate", "create", "show", "amend", "checkpoint"])
    plan.add_argument("plan_arg", nargs="?")
    plan.add_argument("--file", dest="plan_file")
    plan.add_argument("--json", dest="plan_json")
    plan.add_argument("--task-session-id")
    plan.add_argument("--pack-id")
    plan.add_argument("--author", default="local-user")
    plan.add_argument("--reason")
    plan.add_argument("--step-id")
    plan.add_argument("--path", dest="plan_paths", action="append", default=[])
    plan.add_argument("--staged", action="store_true")
    plan.add_argument("--fail-on-violation", action="store_true")
    plan.add_argument(
        "--summary",
        action="store_true",
        help="Print only plan IDs and actionable status",
    )
    plan.add_argument(
        "--verbose", action="store_true", help="Print the complete plan and impact payload"
    )

    release = sub.add_parser("release")
    release.add_argument(
        "release_command",
        choices=[
            "check",
            "validate",
            "report",
            "compare",
            "gap-register",
            "gap-validate",
            "gap-write",
            "inventory-write",
            "checklist-write",
            "benchmark-write",
        ],
    )
    release.add_argument("--baseline")
    release.add_argument("--version", default="1.0.0")
    release.add_argument("--output")

    ci = sub.add_parser("ci")
    ci.add_argument("ci_command", choices=["check", "emit-github", "emit-gitlab", "explain"])
    ci.add_argument("--base", default="origin/main")
    ci.add_argument("--head", default="HEAD")
    ci.add_argument("--pack-id")
    ci.add_argument("--report")

    workspace = sub.add_parser("workspace")
    workspace.add_argument(
        "workspace_command",
        choices=[
            "init",
            "add-repo",
            "index",
            "impact",
            "status",
            "promotions",
            "explain",
        ],
    )
    workspace.add_argument("workspace_arg", nargs="?")
    workspace.add_argument("--repo-id")
    workspace.add_argument("--repo", dest="workspace_repo_alias")
    workspace.add_argument("--task")
    workspace.add_argument("--path", dest="workspace_paths", action="append", default=[])

    eval_cmd = sub.add_parser("eval")
    eval_cmd.add_argument(
        "eval_command",
        choices=[
            "replay",
            "tune",
            "components",
            "ab",
            "agent",
            "run",
            "efficacy",
            "loop-verify",
            "scorecard",
            "gate",
            "harvest",
            "compare",
            "diagnose",
        ],
    )
    eval_cmd.add_argument("eval_provider", nargs="?")
    eval_cmd.add_argument("--limit", type=int, default=50)
    eval_cmd.add_argument("--holdout-ratio", type=float, default=0.3)
    eval_cmd.add_argument("--provider-repo")
    eval_cmd.add_argument("--repo", dest="provider_repo_alias")
    eval_cmd.add_argument("--project")
    eval_cmd.add_argument("--task-source", action="append", default=[])
    eval_cmd.add_argument("--report")
    eval_cmd.add_argument("--ground-truth")
    eval_cmd.add_argument("--cases")
    eval_cmd.add_argument("--agent-command")
    eval_cmd.add_argument("--suite", default="efficacy")
    eval_cmd.add_argument("--baseline", default="no-pack")
    eval_cmd.add_argument("--candidate", default="ctx-pack")
    eval_cmd.add_argument("--output")
    eval_cmd.add_argument("--probe-task", default="change greeting service")
    eval_cmd.add_argument("--probe-path", action="append", default=[])
    eval_cmd.add_argument("--result", default="pass")
    eval_cmd.add_argument("--timeout", type=int, default=600)
    eval_cmd.add_argument("--keep-worktrees", action="store_true")
    eval_cmd.add_argument("--gate", action="store_true")
    eval_cmd.add_argument("--fail-on-regression", action="store_true")
    eval_cmd.add_argument("--min-cases", type=int, default=1)
    eval_cmd.add_argument("--min-success-rate-delta", type=float, default=0.0)
    eval_cmd.add_argument("--min-tests-pass-rate-delta", type=float, default=0.0)
    eval_cmd.add_argument("--min-wrong-files-reduction", type=float, default=0.0)
    eval_cmd.add_argument("--min-missing-files-reduction", type=float, default=0.0)
    eval_cmd.add_argument("--min-persistmind-success-rate", type=float, default=0.0)

    learning = sub.add_parser("learning")
    learning.add_argument(
        "learning_command",
        choices=[
            "status",
            "optimize",
            "archive",
            "benchmark-trends",
            "adopt",
            "revert",
            "selfmod-propose",
            "selfmod-archive",
            "selfmod-adopt",
            "selfmod-revert",
            "loop-verify",
            "recent",
            "versions",
            "show",
            "propose",
            "evaluate",
            "promote",
            "rollback",
            "manifest",
            "canary",
            "propagate",
        ],
    )
    learning.add_argument("learning_arg", nargs="?")
    learning.add_argument("--target", default="pack_weights")
    learning.add_argument("--weakness", default="")
    learning.add_argument("--ancestor-run-id")
    learning.add_argument("--approved-by", default="local-user")
    learning.add_argument("--iterations", type=int, default=1)
    learning.add_argument("--limit", type=int, default=20)
    learning.add_argument("--holdout-ratio", type=float, default=0.3)
    learning.add_argument("--adopt", action="store_true")
    learning.add_argument("--probe", choices=["ranking", "rule_status"], default=None)
    learning.add_argument("--all", dest="learning_all", action="store_true")
    learning.add_argument("--require-closure", action="store_true")
    learning.add_argument("--skill-id")
    learning.add_argument("--benchmark-id")
    learning.add_argument("--artifact-ref")
    learning.add_argument("--content")
    learning.add_argument(
        "--classification",
        choices=["public", "internal", "confidential", "secret"],
        default="internal",
    )
    learning.add_argument("--metrics")
    learning.add_argument("--passed", action="store_true")
    learning.add_argument("--rollback-version")
    learning.add_argument("--field-experiment-id")
    learning.add_argument("--policy-decision-id")
    learning.add_argument("--policy-decision-hash")
    learning.add_argument("--protected-surface-hash")
    learning.add_argument("--signature")
    learning.add_argument("--actor", default="local-user")
    learning.add_argument("--target-workspace", action="append", default=[])
    learning.add_argument("--minimum-pass-rate", type=float, default=0.95)
    learning.add_argument("--maximum-regression", type=float, default=0.02)

    selfimprove = sub.add_parser("selfimprove")
    selfimprove.add_argument(
        "selfimprove_command",
        choices=[
            "status",
            "audit",
            "brief",
            "list",
            "show",
            "propose",
            "evaluate",
            "adopt",
            "reject",
            "rollback",
            "lineage",
            "run",
            "doctor",
            "verify-safety",
        ],
    )
    selfimprove.add_argument("selfimprove_arg", nargs="?")
    selfimprove.add_argument("--title", default="")
    selfimprove.add_argument("--rationale", default="")
    selfimprove.add_argument(
        "--target-file", dest="selfimprove_target_files", action="append", default=[]
    )
    selfimprove.add_argument("--evidence", default="{}")
    selfimprove.add_argument("--diff", dest="selfimprove_diff")
    selfimprove.add_argument("--diff-file", dest="selfimprove_diff_file")
    selfimprove.add_argument("--predicted-effect", default="{}")
    selfimprove.add_argument("--parent-id")
    selfimprove.add_argument("--run-id")
    selfimprove.add_argument("--status")
    selfimprove.add_argument("--reason", default="")
    selfimprove.add_argument("--command", dest="selfimprove_commands", action="append")
    selfimprove.add_argument("--limit", type=int, default=50)
    selfimprove.add_argument("--force", action="store_true")
    selfimprove.add_argument("--auto", action="store_true")
    selfimprove.add_argument("--confirm", action="store_true")
    selfimprove.add_argument("--max-iters", type=int)
    selfimprove.add_argument("--budget", type=int)

    cie = sub.add_parser("cie")
    cie.add_argument(
        "cie_command",
        choices=[
            "status",
            "cycle",
            "archive",
            "show",
            "checklist-preview",
            "predict",
            "score",
            "timeline",
            "preview-adoption",
            "adopt",
            "reject",
            "suspend",
            "rollback",
            "export-state",
            "import-state",
            "rebuild-state",
        ],
    )
    cie.add_argument("cie_arg", nargs="?")
    cie.add_argument("--limit", type=int, default=20)
    cie.add_argument("--target", default="cie")
    cie.add_argument("--task", default="")
    cie.add_argument("--path", dest="cie_paths", action="append", default=[])
    cie.add_argument("--run-id")
    cie.add_argument("--intervention-id")
    cie.add_argument("--approved-by", default="local-user")
    cie.add_argument("--reason", default="")
    cie.add_argument("--actor", default="local-user")
    cie.add_argument("--period", default="current")
    cie.add_argument("--output")
    cie.add_argument("--input")
    cie.add_argument("--dry-run", action="store_true")
    cie.add_argument("--from-events", action="store_true")

    skill = sub.add_parser("skill")
    skill.add_argument(
        "skill_command",
        choices=[
            "induce",
            "list",
            "show",
            "replay",
            "approve",
            "reject",
            "prune",
            "maintain",
            "search",
            "artifact",
            "revision",
            "accept",
            "metrics",
            "classify",
            "improvements",
            "refine-approve",
            "refine-benchmark",
            "rollback",
            "closure",
            "promote-global",
            "adopt-global",
        ],
    )
    skill.add_argument("skill_arg", nargs="?")
    skill.add_argument("--session", "--session-id", dest="skill_session_id")
    skill.add_argument("--task-session-id")
    skill.add_argument("--skill-id")
    skill.add_argument("--output-id")
    skill.add_argument("--global-skill-id")
    skill.add_argument("--text", default="")
    skill.add_argument("--summary", default="")
    skill.add_argument("--kind", default="task_output")
    skill.add_argument("--signal-kind", default="explicit_revision")
    skill.add_argument("--actor", default="user")
    skill.add_argument("--status")
    skill.add_argument("--trust")
    skill.add_argument("--approved-by", default="local-user")
    skill.add_argument("--reason", default="manual reject")
    skill.add_argument("--limit", type=int, default=5)
    skill.add_argument("--include-untrusted", action="store_true")
    skill.add_argument("--timeout", type=int, default=120)
    skill.add_argument("--max-failures", type=int, default=3)
    skill.add_argument("--stale-after-days", type=int)

    security = sub.add_parser("security")
    security.add_argument(
        "security_command",
        choices=["scan", "status", "redact-audit", "quarantine-list", "ingest-redteam"],
    )
    security.add_argument("--status", default="open")
    security.add_argument("--fixtures")
    security.add_argument("--output")
    security.add_argument("--strict", action="store_true")

    memory = sub.add_parser("memory")
    memory.add_argument(
        "memory_command",
        choices=[
            "scan",
            "candidates",
            "explain",
            "list",
            "approve",
            "reject",
            "supersede",
            "conflicts",
            "stale",
            "verify",
            "explain-rule",
            "eval",
            "extraction-eval",
            "trust-calibrate",
            "search",
            "create",
            "update",
            "validate",
            "expire",
            "quarantine",
            "diff",
            "dream",
            "maintain",
            "sweep",
            "promote",
            "review",
            "propose",
            "recall",
            "consolidate",
            "reflect",
            "graph",
            "sleep",
            "prefetch",
            "utilization",
            "enforce",
            "enforcements",
            "unenforce",
            "bench",
        ],
    )
    memory.add_argument("rule_id", nargs="?")
    memory.add_argument("memory_eval_command", nargs="?")
    memory.add_argument("--status")
    memory.add_argument("--fixtures", default="eval/rules")
    memory.add_argument("--source-type")
    memory.add_argument("--apply", action="store_true")
    memory.add_argument("--dry-run", action="store_true")
    memory.add_argument("--approved-by", default="local-user")
    memory.add_argument("--with", dest="with_candidate")
    memory.add_argument("--type", dest="memory_type", action="append", default=[])
    memory.add_argument("--source-kind", default="manual")
    memory.add_argument("--confidence", type=float, default=1.0)
    memory.add_argument("--title")
    memory.add_argument("--json", dest="memory_json")
    memory.add_argument("--reason", default="manual")
    memory.add_argument("--validator", default="human")
    memory.add_argument("--severity", default="high")
    memory.add_argument("--level", default="warn")
    memory.add_argument("--anti-pattern", dest="anti_patterns", action="append", default=[])
    memory.add_argument("--required-pattern", dest="required_patterns", action="append", default=[])
    memory.add_argument("--remediation")
    memory.add_argument("--rationale")
    memory.add_argument("--approve", action="store_true")
    memory.add_argument("--path", dest="memory_paths", action="append", default=[])
    memory.add_argument("--limit", type=int, default=20)
    memory.add_argument("--samples", type=int, default=3)
    memory.add_argument("--recent", type=int, default=10)
    memory.add_argument("--session", "--session-id", dest="session_id")
    memory.add_argument("--task")
    memory.add_argument("--query", dest="memory_query")
    memory.add_argument("--top-k", type=int, default=5)
    memory.add_argument("--max-hops", type=int, default=2)
    memory.add_argument("--include-org", action="store_true")

    policy = sub.add_parser("policy")
    policy.add_argument("policy_command", choices=["approve-business-rule", "applicable"])
    policy.add_argument("policy_arg", nargs="?")
    policy.add_argument("--signature")
    policy.add_argument("--scope")
    policy.add_argument("--approved-by", default="local-user")

    guardrail = sub.add_parser("guardrail")
    guardrail.add_argument("guardrail_command", choices=["override"])
    guardrail.add_argument("directive_id", nargs="?")
    guardrail.add_argument("--rationale", required=True)
    guardrail.add_argument("--task-session-id")
    guardrail.add_argument("--session", "--session-id", dest="session_id")
    guardrail.add_argument("--path", dest="guardrail_paths", action="append", default=[])
    guardrail.add_argument("--actor", default="local-user")
    guardrail.add_argument("--signature")
    guardrail.add_argument("--nonce")
    guardrail.add_argument("--issued-at")
    guardrail.add_argument("--expires-at")

    continuation = sub.add_parser("continuation")
    continuation.add_argument(
        "continuation_command",
        choices=["list", "show", "update", "resume", "abandon"],
    )
    continuation.add_argument("continuation_arg", nargs="?")
    continuation.add_argument("--task")
    continuation.add_argument("--state")
    continuation.add_argument("--next-action")
    continuation.add_argument(
        "--blocker", dest="continuation_blockers", action="append", default=[]
    )
    continuation.add_argument("--reason", default="manual")
    continuation.add_argument("--status")
    continuation.add_argument("--limit", type=int, default=20)

    session = sub.add_parser("session")
    session.add_argument(
        "session_command",
        choices=[
            "start",
            "event",
            "finish",
            "explain",
            "leases",
            "declare-impact",
            "conflicts",
            "ack",
            "resolve",
        ],
    )
    session.add_argument("session_arg", nargs="?")
    session.add_argument("--task")
    session.add_argument("--agent", default="codex")
    session.add_argument("--session-id")
    session.add_argument("--type", dest="event_type")
    session.add_argument("--payload", default="{}")
    session.add_argument("--result", default="pass")
    session.add_argument("--path", dest="session_paths", action="append", default=[])
    session.add_argument("--status", default="open")

    loop = sub.add_parser("loop")
    loop.add_argument("loop_command", choices=["runbook"])
    loop.add_argument("--task", required=True)
    loop.add_argument("--path", dest="loop_paths", action="append", default=[])
    loop.add_argument("--test", dest="loop_tests", action="append", default=[])
    loop.add_argument("--result", default="pass")

    runtime = sub.add_parser("runtime")
    runtime.add_argument(
        "runtime_command",
        choices=[
            "ingest",
            "link-errors",
            "candidates",
            "start",
            "status",
            "obligations",
            "resolve",
            "events",
        ],
    )
    runtime.add_argument("runtime_source", nargs="?")
    runtime.add_argument("runtime_path", nargs="?")
    runtime.add_argument("--task")
    runtime.add_argument("--task-session-id")
    runtime.add_argument("--run-id")
    runtime.add_argument("--pack-id")
    runtime.add_argument("--agent-session-id")
    runtime.add_argument("--obligation-id")
    runtime.add_argument("--evidence")
    runtime.add_argument("--actor", default="codex")
    runtime.add_argument("--status")

    teach = sub.add_parser("teach")
    teach.add_argument(
        "teach_command",
        choices=["event", "brief", "coach", "exam", "reflection", "directives"],
    )
    teach.add_argument("teach_arg", nargs="?")
    teach.add_argument("--task-session-id")
    teach.add_argument("--type", dest="teach_type")
    teach.add_argument("--source", default="cli")
    teach.add_argument("--summary")
    teach.add_argument("--privacy-class", default="summary_only")
    teach.add_argument("--payload", default="{}")
    teach.add_argument("--status")

    lesson = sub.add_parser("lesson")
    lesson.add_argument(
        "lesson_command",
        choices=[
            "list",
            "show",
            "candidate",
            "approve",
            "reject",
            "benchmark",
            "activate",
            "rollback",
        ],
    )
    lesson.add_argument("lesson_id", nargs="?")
    lesson.add_argument("--summary")
    lesson.add_argument("--rule", default="")
    lesson.add_argument("--type", dest="lesson_type", default="technical")
    lesson.add_argument("--scope", default="repo")
    lesson.add_argument("--status")
    lesson.add_argument("--actor", default="local-user")
    lesson.add_argument("--rationale", default="")

    student = sub.add_parser("student")
    student.add_argument(
        "student_command",
        choices=["profile", "mastery", "autonomy-propose", "autonomy-decide"],
    )
    student.add_argument("student_arg", nargs="?")
    student.add_argument("--agent-kind", default="codex")
    student.add_argument("--success", action="store_true")
    student.add_argument("--evidence", action="append", default=[])
    student.add_argument("--actor", default="local-user")
    student.add_argument("--decision")
    student.add_argument("--benchmark-ref")
    student.add_argument("--rollback-ref")

    curriculum = sub.add_parser("curriculum")
    curriculum.add_argument("curriculum_command", choices=["recommend", "plan"])
    curriculum.add_argument("--task-session-id", required=True)
    curriculum.add_argument("--objective", required=True)

    graph = sub.add_parser("graph")
    graph.add_argument(
        "graph_command",
        choices=[
            "status",
            "update",
            "stale-check",
            "query",
            "node",
            "neighbors",
            "provenance",
            "validate",
            "fork",
            "merge-review",
            "merge-decide",
        ],
    )
    graph.add_argument("graph_arg", nargs="?")
    graph.add_argument("--graph-version-id")
    graph.add_argument("--source-version-id")
    graph.add_argument("--target-version-id")
    graph.add_argument("--path", dest="graph_paths", action="append", default=[])
    graph.add_argument("--deleted-path", action="append", default=[])
    graph.add_argument("--branch")
    graph.add_argument("--query", default="")
    graph.add_argument("--type", dest="graph_node_type")
    graph.add_argument("--limit", type=int, default=50)
    graph.add_argument("--budget-ms", type=int, default=100)
    graph.add_argument("--reason")
    graph.add_argument("--decision")
    graph.add_argument("--reviewer", default="local-user")

    teacher_review = sub.add_parser("teacher-review")
    teacher_review.add_argument(
        "review_command",
        choices=["request", "list", "decide", "export", "import", "import-decide"],
    )
    teacher_review.add_argument("review_arg", nargs="?")
    teacher_review.add_argument("--item-type")
    teacher_review.add_argument("--item-id")
    teacher_review.add_argument("--status", default="pending")
    teacher_review.add_argument("--decision")
    teacher_review.add_argument("--actor", default="local-user")
    teacher_review.add_argument("--role", default="professional_teacher")
    teacher_review.add_argument("--risk", default="medium")
    teacher_review.add_argument("--rationale", default="")
    teacher_review.add_argument("--lesson-id", action="append", default=[])
    teacher_review.add_argument("--scope", default="repo")
    teacher_review.add_argument("--source", default="local")
    teacher_review.add_argument("--file")

    orchestrator = sub.add_parser("orchestrator")
    orchestrator.add_argument(
        "orchestrator_command",
        choices=[
            "create",
            "status",
            "checkpoint",
            "output",
            "task",
            "integrate",
            "child-start",
            "child-stop",
        ],
    )
    orchestrator.add_argument("orchestrator_arg", nargs="?")
    orchestrator.add_argument("--task-session-id")
    orchestrator.add_argument("--objective")
    orchestrator.add_argument("--file")
    orchestrator.add_argument("--payload", default="{}")
    orchestrator.add_argument("--role-id")
    orchestrator.add_argument("--output-id")
    orchestrator.add_argument("--type", dest="orchestrator_type")
    orchestrator.add_argument("--action")
    orchestrator.add_argument("--decision")
    orchestrator.add_argument("--actor", default="local-user")
    orchestrator.add_argument("--verifier-status")
    orchestrator.add_argument("--rationale", default="")
    orchestrator.add_argument("--summary")
    orchestrator.add_argument("--child-session-id")
    orchestrator.add_argument("--changed-file", action="append", default=[])
    orchestrator.add_argument("--test", action="append", default=[])
    orchestrator.add_argument("--blocker", action="append", default=[])

    teacher_bench = sub.add_parser("teacher-bench")
    teacher_bench.add_argument(
        "teacher_bench_command",
        choices=[
            "suite-create",
            "suite-show",
            "run-start",
            "metric",
            "finish",
            "resume",
            "compare",
            "claim",
            "waive",
            "release-gate",
        ],
    )
    teacher_bench.add_argument("teacher_bench_arg", nargs="?")
    teacher_bench.add_argument("--name")
    teacher_bench.add_argument("--suite-version", default="1")
    teacher_bench.add_argument("--purpose", default="teacher runtime evaluation")
    teacher_bench.add_argument("--file")
    teacher_bench.add_argument("--baseline-run-id")
    teacher_bench.add_argument("--candidate-run-id")
    teacher_bench.add_argument("--metric")
    teacher_bench.add_argument("--value", type=float)
    teacher_bench.add_argument("--unit", default="count")
    teacher_bench.add_argument("--status", default="complete")
    teacher_bench.add_argument("--thresholds", default="{}")
    teacher_bench.add_argument("--claim")
    teacher_bench.add_argument("--actor", default="local-user")
    teacher_bench.add_argument("--reason", default="")
    teacher_bench.add_argument("--expires-at")

    org = sub.add_parser("org")
    org.add_argument(
        "org_command",
        choices=["connector", "ingest", "candidates", "approve", "reject", "audit"],
    )
    org.add_argument("org_arg", nargs="?")
    org.add_argument("org_arg2", nargs="?")
    org.add_argument("--config")
    org.add_argument("--display-name")
    org.add_argument("--secret-ref")
    org.add_argument("--scope", default="restricted")
    org.add_argument("--remote", action="store_true")
    org.add_argument("--since")
    org.add_argument("--path")
    org.add_argument("--status", default="quarantined")
    org.add_argument("--source")
    org.add_argument("--actor", default="local-user")
    org.add_argument("--supersede")
    org.add_argument("--reason", default="rejected")
    org.add_argument("--limit", type=int, default=100)

    decision = sub.add_parser("decision")
    decision.add_argument(
        "decision_command",
        choices=["start", "analyze", "record", "show", "list"],
    )
    decision.add_argument("decision_id", nargs="?")
    decision.add_argument("--question")
    decision.add_argument("--option", dest="decision_options", action="append", default=[])
    decision.add_argument("--seed-paths", dest="decision_seed_paths", action="append", default=[])
    decision.add_argument("--chosen", dest="chosen_option_id")
    decision.add_argument("--rationale")
    decision.add_argument("--actor", default="local-user")
    decision.add_argument("--status")
    decision.add_argument("--limit", type=int, default=50)

    dashboard = sub.add_parser("dashboard")
    dashboard.add_argument("dashboard_command", choices=["data", "render"])
    dashboard.add_argument("--output", default=".persistmind/dashboard.html")

    capability = sub.add_parser("capability")
    capability.add_argument("capability_command", choices=["matrix", "claims"])
    capability.add_argument("--format", choices=["json", "markdown"], default="json")
    capability.add_argument("--output")
    capability.add_argument("--claim")
    capability.add_argument("--check", action="store_true")

    rollup = sub.add_parser("rollup")
    rollup.add_argument("--label")
    rollup.add_argument("--limit", type=int, default=30)
    rollup.add_argument("--output")

    registry = sub.add_parser(
        "registry", help="Track projects where PersistMind is installed/updated"
    )
    registry.add_argument(
        "registry_command", choices=["register", "list", "remove", "prune", "health"]
    )
    registry.add_argument("--label", help="Friendly name (defaults to the repo folder name)")
    registry.add_argument("--action", choices=["install", "update"], default="install")
    registry.add_argument("--path", help="Project path for remove (defaults to --repo)")
    registry.add_argument("--path-root", help="Only include registered projects under this root")
    registry.add_argument(
        "--include-temp", action="store_true", help="Include temp/pytest projects"
    )
    registry.add_argument(
        "--include-rollup",
        action="store_true",
        help="Include per-project privacy-safe rollup checks",
    )
    registry.add_argument("--output", help="Write the health JSON to a file")

    semantic = sub.add_parser("semantic")
    semantic.add_argument(
        "semantic_command",
        choices=[
            "index",
            "search",
            "repo-search",
            "explain",
            "graph",
            "list",
            "stats",
            "accuracy-eval",
            "low-confidence",
            "repair",
        ],
    )
    semantic.add_argument("semantic_arg", nargs="?")
    semantic.add_argument("--path")
    semantic.add_argument("--fixtures")
    semantic.add_argument("--threshold", type=float, default=0.5)
    semantic.add_argument("--status", default="open")
    semantic.add_argument("--finding-id")
    semantic.add_argument("--rationale", default="")
    semantic.add_argument("--limit", type=int, default=20)
    semantic.add_argument("--max-hops", type=int, default=2)

    architecture = sub.add_parser("architecture")
    architecture.add_argument(
        "architecture_command",
        choices=["infer", "map", "explain", "drift", "critical-paths"],
    )
    architecture.add_argument("architecture_arg", nargs="?")
    architecture.add_argument("--service")
    architecture.add_argument("--strict", action="store_true")

    behavior = sub.add_parser("behavior")
    behavior.add_argument("behavior_command", choices=["check"])
    behavior.add_argument("--path", dest="behavior_paths", action="append", default=[])
    behavior.add_argument("--diff-from-stdin", action="store_true")
    behavior.add_argument("--pack-id")

    verify = sub.add_parser("verify")
    verify.add_argument("verify_command", choices=["run"])
    verify.add_argument("--command", dest="verify_commands", action="append", default=[])
    verify.add_argument("--pack-id")
    verify.add_argument("--plan-id")
    verify.add_argument("--name")
    verify.add_argument("--retry-budget", type=int, default=0)
    verify.add_argument("--timeout", type=int, default=120)

    migrate = sub.add_parser("migrate")
    migrate.add_argument("--verify", action="store_true")
    migrate.add_argument("--dry-run", action="store_true")

    agent = sub.add_parser("agent")
    agent.add_argument("agent_command", choices=["route"])
    agent.add_argument("--task", required=True)
    agent.add_argument("--risk-score", type=float, default=0.0)
    agent.add_argument("--capability", dest="agent_capabilities", action="append", default=[])
    agent.add_argument("--remote-review", action="store_true")

    workflow = sub.add_parser("workflow")
    workflow.add_argument(
        "workflow_command",
        choices=["recommend", "start", "next", "lint", "brief", "rebind"],
    )
    workflow.add_argument("--task")
    workflow.add_argument("--task-session-id")
    workflow.add_argument("--pack-id")
    workflow.add_argument("--mode", default="auto", choices=WORKFLOW_MODES)
    workflow.add_argument("--path", dest="workflow_paths", action="append", default=[])
    workflow.add_argument("--capability", dest="workflow_capabilities", action="append", default=[])
    workflow.add_argument("--intent-id")
    workflow.add_argument("--goal-id")
    workflow.add_argument(
        "--summary", action="store_true", help="Print only lifecycle IDs and status"
    )

    codex = sub.add_parser("codex")
    codex.add_argument(
        "codex_command",
        choices=[
            "preflight",
            "enforcement-status",
            "parallel-plan",
            "child-start",
            "child-stop",
            "child-pack",
            "merge-parallel-results",
            "install-surfaces",
            "hook",
        ],
    )
    codex.add_argument("--task")
    codex.add_argument("--mode", default="write", choices=PREFLIGHT_MODES)
    codex.add_argument("--path", dest="codex_paths", action="append", default=[])
    codex.add_argument("--task-session-id")
    codex.add_argument("--pack-id")
    codex.add_argument("--parallel-run-id")
    codex.add_argument("--role", default="ctx-worker")
    codex.add_argument("--objective")
    codex.add_argument("--write-scope", action="append", default=[])
    codex.add_argument("--read-scope", action="append", default=[])
    codex.add_argument("--child-agent-session-id")
    codex.add_argument("--summary-text", default="")
    codex.add_argument("--changed-file", action="append", default=[])
    codex.add_argument("--test-run", action="append", default=[])
    codex.add_argument("--blocker", action="append", default=[])
    codex.add_argument("--event")
    codex.add_argument("--payload", default="{}")
    codex.add_argument("--mcp-command", default="persistmind")
    codex.add_argument("--install-hooks", action="store_true")
    codex.add_argument("--configure-mcp", action="store_true")
    codex.add_argument("--init-git", action="store_true")
    codex.add_argument("--absolute-mcp-repo", action="store_true")
    codex.add_argument("--codex-config")
    codex.add_argument("--skip-index", action="store_true")
    _add_runtime_invocation_args(codex)
    codex.add_argument("--probe", action="store_true")
    codex.add_argument("--self-test", action="store_true")
    codex.add_argument("--fast", action="store_true")
    codex.add_argument("--summary", action="store_true", help="Print concise Codex command status")

    governance = sub.add_parser("governance")
    governance.add_argument(
        "governance_command",
        choices=[
            "status",
            "propose",
            "list",
            "show",
            "preview",
            "preview-adoption",
            "adopt",
            "reject",
            "rollback",
        ],
    )
    governance.add_argument("--proposal-id")
    governance.add_argument("--adoption-id")
    governance.add_argument("--status")
    governance.add_argument("--actor", default="local-user")
    governance.add_argument("--approved-by")
    governance.add_argument("--reason")
    governance.add_argument("--rationale")
    governance.add_argument("--min-samples", type=int)

    provider = sub.add_parser("provider")
    provider.add_argument("provider_command", choices=["status"])

    metacog = sub.add_parser("metacog")
    metacog.add_argument("metacog_command", choices=["state"])
    metacog.add_argument("--task", required=True)
    metacog.add_argument("--path", dest="metacog_paths", action="append", default=[])
    metacog.add_argument("--task-session-id")

    clarify = sub.add_parser("clarify")
    clarify.add_argument("clarify_command", choices=["open", "list", "answer", "withdraw"])
    clarify.add_argument("clarify_arg", nargs="?")
    clarify.add_argument("--question")
    clarify.add_argument("--answer")
    clarify.add_argument("--reason")
    clarify.add_argument("--task-session-id")
    clarify.add_argument("--pack-id")
    clarify.add_argument("--status", default="open")
    clarify.add_argument("--limit", type=int, default=50)

    judgment = sub.add_parser("judgment")
    judgment.add_argument(
        "judgment_command",
        choices=["status", "propose", "list", "adopt", "reject", "rollback"],
    )
    judgment.add_argument("judgment_id", nargs="?")
    judgment.add_argument("--actor", default="local-user")
    judgment.add_argument("--reason")
    judgment.add_argument("--status")

    narrative = sub.add_parser("narrative")
    narrative.add_argument("narrative_command", choices=["show"])

    npx = sub.add_parser("npx")
    npx.add_argument("npx_command", choices=["doctor", "update"])
    npx.add_argument("--source")
    npx.add_argument("--project", action="store_true")

    serve_parser = sub.add_parser("serve")
    serve_parser.add_argument("--workspace", default=".")
    serve_parser.add_argument("--host")
    serve_parser.add_argument("--port", type=int)
    serve_parser.add_argument("--auth", choices=["none", "token"], default=None)

    mcp = sub.add_parser("mcp")
    mcp.add_argument("--stdio", action="store_true", default=True)

    nextgen = sub.add_parser("nextgen")
    nextgen.add_argument(
        "nextgen_command",
        choices=["status", "scorecard", "security-scan", "drift"],
    )
    nextgen.add_argument("--text", default="")
    nextgen.add_argument("--source", default="cli")
    nextgen.add_argument("--spec", action="append", default=[])
    nextgen.add_argument("--path", dest="nextgen_paths", action="append", default=[])

    report = sub.add_parser("report", help="Create a privacy-reviewed local incident report")
    _add_reporting_create_args(report)

    incident = sub.add_parser("incident", help="Manage local PersistMind incidents")
    incident_sub = incident.add_subparsers(dest="incident_command", required=True)
    incident_create = incident_sub.add_parser("create")
    _add_reporting_create_args(incident_create)
    incident_list = incident_sub.add_parser("list")
    incident_list.add_argument("--kind", choices=["incident", "feedback"])
    incident_list.add_argument("--status")
    incident_list.add_argument("--severity")
    incident_list.add_argument("--category")
    incident_list.add_argument("--limit", type=int, default=100)
    for action in ("show", "validate"):
        command = incident_sub.add_parser(action)
        command.add_argument("occurrence_id")
    incident_export = incident_sub.add_parser("export")
    incident_export.add_argument("occurrence_id")
    incident_export.add_argument("--reviewed-by", required=True)
    incident_export.add_argument("--include-diagnostics", action="store_true")
    incident_export.add_argument("--acknowledge-warnings", action="store_true")
    incident_submit = incident_sub.add_parser("submit")
    incident_submit.add_argument("occurrence_id")
    incident_submit.add_argument("--export-id")
    incident_submit.add_argument("--confirm", action="store_true")
    incident_import = incident_sub.add_parser("import-legacy")
    incident_import.add_argument("path", type=Path)
    incident_erase = incident_sub.add_parser("erase")
    incident_erase.add_argument("occurrence_id")
    incident_erase.add_argument("--confirm", action="store_true")
    incident_reconcile = incident_sub.add_parser("reconcile")
    incident_reconcile.add_argument("--apply", action="store_true")
    incident_retention = incident_sub.add_parser("retention")
    incident_retention.add_argument("--apply", action="store_true")
    incident_retention.add_argument("--confirm", action="store_true")
    incident_sub.add_parser("doctor")

    feedback = sub.add_parser("feedback", help="Record quality feedback for an operation or pack")
    feedback.add_argument("reference")
    feedback.add_argument("--rating", type=int, required=True)
    feedback.add_argument("--reason", required=True)
    feedback.add_argument("--summary")

    collector = sub.add_parser("collector", help="Operate the central incident triage boundary")
    collector.add_argument(
        "collector_command",
        choices=[
            "ingest",
            "accept",
            "reject",
            "split",
            "analytics",
            "github-draft",
            "github-create",
        ],
    )
    collector.add_argument("collector_arg", nargs="?")
    collector.add_argument("collector_arg2", nargs="?")
    collector.add_argument("--dry-run", action="store_true")
    collector.add_argument("--reviewer")
    collector.add_argument("--confirm", action="store_true")
    collector.add_argument("--version")
    collector.add_argument("--component")
    collector.add_argument("--platform")
    collector.add_argument("--severity")

    args = parser.parse_args(argv)
    from persistmind.security.actions import cli_operation_action, local_cli_principal
    from persistmind.security.rbac import require_authorized

    cli_principal = local_cli_principal(Path(args.repo))
    args.transport_principal = cli_principal
    try:
        command_action = cli_operation_action(str(args.command))
        if command_action is None:
            raise PermissionError(f"unmapped CLI command denied: {args.command}")
        require_authorized(cli_principal, command_action, Path(args.repo))
        if args.command in {"version", "status"}:
            # Version reporting is metadata-only and must never construct the
            # generic fallback or create repository-local state.
            from persistmind.release_identity import maturity_warning, public_release_identity

            identity = public_release_identity()
            result = {
                "ok": True,
                "version": __version__,
                "active_profile": identity["runtime_profile"],
                "release_identity": identity,
                "maturity_warning": maturity_warning(),
            }
        elif args.command == "internal" and args.internal_command == "project-upgrade":
            from persistmind.update import apply_upgrade, plan_upgrade, verify_upgrade

            if args.project_upgrade_action == "plan":
                result = plan_upgrade(Path(args.repo))
            elif args.project_upgrade_action == "apply":
                result = apply_upgrade(Path(args.repo), args.transaction)
            else:
                result = verify_upgrade(Path(args.repo), args.transaction)
        elif args.command == "update":
            from persistmind.updater import run_update

            action = "rollback" if args.rollback else "check" if args.check else args.update_action
            result = run_update(
                Path(args.repo),
                action=action,
                channel=args.channel,
                exact_version=args.update_version,
                dry_run=args.dry_run,
                force=args.force,
            )
        elif args.command == "npx":
            result = _dispatch_npx(args)
        elif args.command == "db" and args.db_command in {"probe", "check", "repair"}:
            result = _dispatch_bootstrap_db(args)
        elif args.command == "operations":
            result = _dispatch_operations(args)
        elif args.command == "config":
            from persistmind.config import config_document

            document = config_document(Path(args.repo).resolve())
            result = (
                {
                    "ok": True,
                    "status": "ok",
                    "schema_version": document["schema_version"],
                    "effective": document["effective"],
                    "origins": document["origins"],
                }
                if args.config_command == "show-effective" and document.get("ok")
                else document
            )
        elif args.command in {"report", "incident", "feedback", "collector"}:
            result = _dispatch_reporting(args)
        elif args.command == "storage":
            result = _dispatch_storage_control(args)
        elif args.command == "install":
            result = _dispatch_install(args)
        elif args.command == "setup":
            result = _dispatch_setup(args)
        elif args.command == "storage-report":
            from persistmind.storage.control import StorageControlPlane

            result = StorageControlPlane(Path(args.repo)).status()
            result["limit"] = max(1, min(int(args.limit), 1000))
        elif args.command == "agent-runtime":
            from persistmind.agent_runtime.operations import run_agent_runtime_operation

            result = run_agent_runtime_operation(
                Path(args.repo),
                args.agent_runtime_operation,
                _agent_runtime_request(args),
            )
        elif args.command == "doctor" and _nextgen_task_is_initialized(Path(args.repo)):
            if args.hook_coverage:
                from persistmind.agent_runtime.hooks import hook_coverage_status

                result = hook_coverage_status(Path(args.repo))
            else:
                from persistmind.composition.registry import OperationClient

                with OperationClient(Path(args.repo), read_only=True) as service:
                    result = service.doctor()
        elif args.command == "audit" and _nextgen_task_is_initialized(Path(args.repo)):
            from persistmind.composition.registry import OperationClient

            with OperationClient(Path(args.repo)) as service:
                result = _dispatch_nextgen_audit(args, service)
        elif args.command == "learning" and _nextgen_task_is_initialized(Path(args.repo)):
            from persistmind.composition.registry import OperationClient

            with OperationClient(Path(args.repo)) as service:
                result = _dispatch_nextgen_learning(args, service)
        elif args.command in {"activity", "outcome", "tokens"} and _nextgen_task_is_initialized(
            Path(args.repo)
        ):
            from persistmind.composition.registry import OperationClient

            with OperationClient(Path(args.repo)) as service:
                result = _dispatch_nextgen_activity(args, service)
        elif args.command == "check-diff" and _nextgen_task_is_initialized(Path(args.repo)):
            from persistmind.composition.registry import OperationRegistry

            paths = normalize_path_records(args.paths)
            diff = None
            if args.paths_from_stdin:
                paths.extend(read_path_records(sys.stdin))
            else:
                diff = normalize_diff_input(sys.stdin.read())
                if diff:
                    from persistmind.git_utils import paths_from_diff

                    paths.extend(paths_from_diff(diff))
            result = OperationRegistry(Path(args.repo)).invoke(
                "check_diff_against_pack",
                {"pack_id": args.pack_id, "paths": paths, "diff": diff},
            )
        elif args.command in {"index", "search", "impact"} and _nextgen_task_is_initialized(
            Path(args.repo)
        ):
            from persistmind.composition.registry import OperationRegistry

            operation_registry = OperationRegistry(Path(args.repo))
            if args.command == "index":
                result = operation_registry.invoke("refresh_index", {})
            elif args.command == "search":
                result = operation_registry.invoke(
                    "search", {"args": [args.query], "limit": args.limit}
                )
            else:
                paths = normalize_path_records(args.paths)
                if args.paths_from_stdin:
                    paths.extend(read_path_records(sys.stdin))
                elif args.diff_from_stdin:
                    from persistmind.git_utils import paths_from_diff

                    paths.extend(paths_from_diff(normalize_diff_input(sys.stdin.read())))
                if args.pack_id and _nextgen_task_is_initialized(Path(args.repo)):
                    result = operation_registry.invoke(
                        "get_impact_report",
                        {"pack_id": args.pack_id, "paths": paths},
                    )
                else:
                    result = operation_registry.invoke("impact", {"args": [paths]})
        elif args.command == "metacog" and _nextgen_task_is_initialized(Path(args.repo)):
            from persistmind.composition.registry import OperationClient

            with OperationClient(Path(args.repo)) as service:
                result = service.metacog_state(
                    args.task,
                    paths=args.metacog_paths,
                    task_session_id=args.task_session_id,
                )
        elif args.command in {
            "pack",
            "manifest",
            "reconstruct-pack",
        } and _nextgen_task_is_initialized(Path(args.repo)):
            from persistmind.composition.registry import OperationRegistry

            operation_registry = OperationRegistry(Path(args.repo))
            if args.command == "pack":
                result = operation_registry.invoke(
                    "get_context_pack",
                    {
                        "args": [args.task, args.budget, args.seed_path],
                        "task_session_id": args.task_session_id,
                        "seed_from_diff": args.seed_from_diff,
                    },
                )
            elif args.command == "manifest":
                result = operation_registry.invoke("get_pack_manifest", {"args": [args.pack_id]})
            else:
                result = operation_registry.invoke(
                    "reconstruct_pack", {"args": [args.pack_id, args.task_text]}
                )
        elif args.command in {"memory", "policy"} and _nextgen_task_is_initialized(
            Path(args.repo)
        ):
            from persistmind.composition.registry import OperationClient

            with OperationClient(Path(args.repo)) as service:
                result = _dispatch_nextgen_knowledge(args, service)
        elif (
            (args.command == "task" and args.task_command == "show")
            or (args.command == "plan" and args.plan_command == "show")
        ) and _nextgen_task_is_initialized(Path(args.repo)):
            from persistmind.storage.task_queries import execute_task_query

            identifier = args.task_arg if args.command == "task" else args.plan_arg
            result = execute_task_query(Path(args.repo), args.command, identifier)
        elif args.command in {
            "task",
            "plan",
            "continuation",
            "intent",
            "goal",
            "working-memory",
            "reasoning",
            "experience",
        } and _nextgen_task_is_initialized(Path(args.repo)):
            from persistmind.composition.registry import OperationClient

            with OperationClient(Path(args.repo)) as service:
                result = _dispatch_nextgen_task(args, service)
        elif (
            args.command == "codex"
            and args.codex_command == "preflight"
            and _nextgen_task_is_initialized(Path(args.repo))
        ):
            if not args.task:
                raise ValueError("codex preflight requires --task")
            from persistmind.composition.registry import OperationClient

            with OperationClient(Path(args.repo)) as service:
                result = service.codex_preflight(
                    args.task,
                    paths=args.codex_paths,
                    mode=args.mode,
                    probe=args.probe or args.fast,
                    task_session_id=args.task_session_id,
                )
        elif (
            args.command == "workflow"
            and args.workflow_command in {"start", "next", "brief"}
            and _nextgen_task_is_initialized(Path(args.repo))
        ):
            from persistmind.composition.registry import OperationClient

            with OperationClient(Path(args.repo)) as service:
                result = _dispatch_nextgen_workflow(args, service)
        elif args.command == "verify" and _nextgen_task_is_initialized(Path(args.repo)):
            from persistmind.composition.registry import OperationClient

            with OperationClient(Path(args.repo)) as service:
                if not args.verify_commands:
                    raise ValueError("verify run requires at least one --command")
                result = service.verify_run(
                    args.verify_commands,
                    pack_id=args.pack_id,
                    plan_id=args.plan_id,
                    name=args.name,
                    retry_budget=args.retry_budget,
                    timeout=args.timeout,
                )
        elif args.command in {
            "anticipate",
            "bench",
            "foresight",
            "critique",
            "flywheel",
            "selfimprove",
            "cie",
            "teach",
            "lesson",
            "student",
            "curriculum",
            "teacher-review",
            "teacher-bench",
        } and _nextgen_task_is_initialized(Path(args.repo)):
            from persistmind.storage.intelligence_service import (
                QUERY_ACTIONS,
                IntelligenceService,
            )

            intelligence_capability, intelligence_action = _intelligence_operation(args)
            with IntelligenceService(
                Path(args.repo), read_only=intelligence_action in QUERY_ACTIONS
            ) as service:
                result = service.execute(intelligence_capability, intelligence_action, vars(args))
        elif args.command == "coordinator":
            from persistmind.agent_runtime.coordinator import RepositoryCoordinator
            from persistmind.agent_runtime.events import AgentEventProjector
            from persistmind.agent_runtime.hooks import drain_hook_observations
            from persistmind.agent_runtime.identity import repository_context
            from persistmind.agent_runtime.jobs import DurableJobService
            from persistmind.storage.agent_runtime_ports import AgentRuntimePorts

            context = repository_context(Path(args.repo))
            hook_drain = (
                drain_hook_observations(Path(args.repo), limit=max(1, args.max_jobs * 64))
                if args.coordinator_command == "drain"
                else None
            )
            with AgentRuntimePorts(Path(args.repo)) as ports:
                coordinator_runtime = RepositoryCoordinator(
                    DurableJobService(ports.task, context),
                    {
                        "observation.project": lambda payload: {
                            "projected": True,
                            "digest": payload.get("event_id"),
                        }
                    },
                )
                if args.coordinator_command == "status":
                    result = coordinator_runtime.status()
                    result["unsettled_agent_events"] = ports.activity.unsettled_agent_event_count()
                else:
                    projection = AgentEventProjector(ports.activity, ports.audit).drain(
                        limit=max(1, args.max_jobs * 64)
                    )
                    jobs = coordinator_runtime.drain(
                        max_jobs=args.max_jobs, max_seconds=args.max_seconds
                    )
                    result = {
                        "ok": bool(
                            hook_drain and hook_drain["ok"] and projection["ok"] and jobs["ok"]
                        ),
                        "schema_version": "persistmind.repository_coordinator_drain.v2",
                        "hook_observations": hook_drain,
                        "agent_event_projection": projection,
                        "jobs": jobs,
                    }
        elif args.command == "serve":
            from persistmind.http import serve
            from persistmind.release_identity import validate_internal_preview_server_binding
            settings = load_settings(Path(args.repo).resolve())
            selected_host = args.host or settings.server.host
            validate_internal_preview_server_binding(settings.profile.name, selected_host)
            serve(
                args.workspace,
                host=selected_host,
                port=args.port or settings.server.port,
                token_env=settings.server.token_env,
                auth_mode=args.auth or settings.server.auth,
            )
            result = None
        elif args.command == "mcp":
            from persistmind.server.mcp_server import run_mcp
            result = run_mcp(Path(args.repo))
        elif args.command == "eval" and args.eval_command == "components":
            result = __import__("persistmind.eval.component", fromlist=["run_source_component_eval"]).run_source_component_eval(Path(args.repo), Path(args.ground_truth or Path(args.repo) / "eval/persistmind_component_ground_truth.json"))
        else:
            from persistmind.composition.registry import OperationClient

            with OperationClient(Path(args.repo)) as service:
                result = _dispatch(args, service)
    except Exception as exc:
        status = getattr(exc, "status", None)
        if status is None and (
            exc.__class__.__module__.split(".", 1)[0] in {"sqlite3", "apsw"}
            or any(
                token in str(exc).casefold() for token in ("database is locked", "database is busy")
            )
        ):
            status = classify_sqlite_error(exc)
        if (result := _nonblocking_constitution_bootstrap_gap(args, status)) is not None:
            print(json.dumps(finalize_result(result, operation=args.command), indent=2, sort_keys=True))
            if args.fail_on_violation and not result.get("ok"):
                raise SystemExit(exit_code_for_result(result))
            return
        raw_envelope = {
            "ok": False,
            "status": status
            or (
                "validation_failed"
                if isinstance(exc, (ValueError, KeyError))
                else "not_authorized"
                if isinstance(exc, PermissionError)
                else "timeout"
                if isinstance(exc, TimeoutError)
                else "internal_error"
            ),
            "error": str(exc),
            "error_type": type(exc).__name__,
        }
        error_path = getattr(exc, "path", None)
        if error_path:
            raw_envelope["path"] = str(error_path)
        for reference_name in (
            "task_session_id",
            "agent_session_id",
            "pack_id",
            "snapshot_id",
            "generation_id",
        ):
            reference_value = getattr(args, reference_name, None)
            if reference_value:
                raw_envelope[reference_name] = str(reference_value)
        remediation = getattr(exc, "remediation", None)
        if remediation:
            raw_envelope["remediation"] = remediation
        if status in {"database_malformed", "database_locator_invalid"}:
            raw_envelope["remediation"] = (
                "persistmind --repo . db check; then review persistmind --repo . db repair --dry-run"
            )
        envelope = finalize_result(raw_envelope, operation=args.command, failed_stage="dispatch")
        if args.command not in {"report", "incident", "feedback", "collector"}:
            from persistmind.reporting.automatic import maybe_capture_result

            maybe_capture_result(
                Path(args.repo), envelope, operation=str(args.command), surface="cli"
            )
        print(json.dumps(envelope, indent=2), file=sys.stderr)
        raise SystemExit(exit_code_for_result(envelope)) from exc
    if result is not None:
        from persistmind.agent_runtime.policy_snapshot import refresh_fast_policy_snapshot

        refresh_fast_policy_snapshot(args, result)
        if _should_summarize_result(args):
            result = _summary_result(args, result)
        result = finalize_result(result, operation=args.command)
        if args.command not in {"report", "incident", "feedback", "collector"}:
            from persistmind.reporting.automatic import maybe_capture_result

            maybe_capture_result(
                Path(args.repo), result, operation=str(args.command), surface="cli"
            )
        bindable_route = _bindable_cli_route(args)
        if bindable_route:
            from persistmind.agents.workflow_binding import build_hook_bindable_result

            result = build_hook_bindable_result(
                bindable_route,
                result,
                repo_root=Path(args.repo),
                command_argv=argv,
            )
        print(json.dumps(result, indent=2, sort_keys=True))
        exit_code = exit_code_for_result(result)
        if exit_code:
            raise SystemExit(exit_code)

def _add_reporting_create_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--category")
    parser.add_argument(
        "--severity",
        choices=["critical", "high", "medium", "low", "informational"],
        default="medium",
    )
    parser.add_argument("--summary")
    parser.add_argument("--expected")
    parser.add_argument("--actual")
    parser.add_argument("--operation-id")
    parser.add_argument("--correlation-id")
    parser.add_argument("--pack-id")
    parser.add_argument("--task-session-id")
    parser.add_argument("--agent-session-id")
    parser.add_argument("--snapshot-id")
    parser.add_argument("--generation-id")
    parser.add_argument("--reproducibility", default="unknown")
    parser.add_argument("--step", dest="steps", action="append", default=[])
    parser.add_argument("--affected-file", dest="affected_files", action="append", default=[])
    parser.add_argument("--affected-symbol", dest="affected_symbols", action="append", default=[])
    parser.add_argument("--incorrect-code", action="store_true")
    parser.add_argument("--task-blocked", action="store_true")
    parser.add_argument("--security-impact", action="store_true")
    parser.add_argument("--rework-minutes", type=int)
    parser.add_argument("--suspected-cause")
    parser.add_argument("--workaround")
    parser.add_argument("--label", dest="labels", action="append", default=[])
    parser.add_argument("--json-file", type=Path)


def _dispatch_reporting(args: argparse.Namespace) -> dict[str, Any]:
    repo = Path(args.repo).resolve()
    if args.command == "collector":
        if args.collector_command == "ingest":
            if not args.collector_arg:
                raise ValueError("collector ingest requires a package path")
            from persistmind.reporting.ingestion import CollectorIngestionService

            return CollectorIngestionService(repo).ingest(
                Path(args.collector_arg), dry_run=bool(args.dry_run)
            )
        if args.collector_command in {"github-draft", "github-create"}:
            if not args.collector_arg:
                raise ValueError(
                    f"collector {args.collector_command} requires a canonical issue ID"
                )
            from persistmind.config import load_settings
            from persistmind.reporting.central_storage import CentralTriageStore
            from persistmind.reporting.downstream import create_github_issue, github_issue_draft

            if args.collector_command == "github-create":
                return create_github_issue(
                    repo,
                    issue_id=args.collector_arg,
                    reviewer=str(args.reviewer or ""),
                    config=load_settings(repo).reporting,
                    confirm=bool(args.confirm),
                )
            with CentralTriageStore.open(repo) as store:
                return {
                    "ok": True,
                    "status": "drafted",
                    **github_issue_draft(store, args.collector_arg),
                }
        from persistmind.reporting.central_storage import CentralTriageStore

        with CentralTriageStore.open(repo) as store:
            if args.collector_command == "analytics":
                return {
                    "ok": True,
                    "status": "ok",
                    **store.analytics(
                        filters={
                            "version": args.version,
                            "component": args.component,
                            "platform": args.platform,
                            "severity": args.severity,
                        }
                    ),
                }
            if not args.collector_arg or not args.collector_arg2:
                raise ValueError(
                    f"collector {args.collector_command} requires issue and occurrence IDs"
                )
            return {
                "ok": True,
                "status": "updated",
                **store.decide_link(
                    args.collector_arg,
                    args.collector_arg2,
                    decision={"accept": "accepted", "reject": "rejected", "split": "split"}[
                        args.collector_command
                    ],
                    reviewer=str(args.reviewer or ""),
                ),
            }
    from persistmind.reporting.service import ReportingService

    create = args.command in {"report", "feedback"} or (
        args.command == "incident"
        and args.incident_command
        in {"create", "export", "submit", "import-legacy", "erase", "doctor"}
    )
    create = create or (
        args.command == "incident"
        and args.incident_command in {"reconcile", "retention"}
        and bool(args.apply)
    )
    with ReportingService(repo, create=create) as service:
        if args.command == "feedback":
            return service.feedback(
                args.reference,
                rating=args.rating,
                reason=args.reason,
                summary=args.summary,
            )
        if args.command == "report":
            if args.json_file:
                return service.create_from_file(args.json_file)
            request = _reporting_request(args, interactive=True)
            return service.create_incident(**request)
        if args.incident_command == "create":
            if args.json_file:
                return service.create_from_file(args.json_file)
            return service.create_incident(**_reporting_request(args, interactive=False))
        if args.incident_command == "list":
            return service.list(
                kind=args.kind,
                status=args.status,
                severity=args.severity,
                category=args.category,
                limit=args.limit,
            )
        if args.incident_command == "show":
            return service.show(args.occurrence_id)
        if args.incident_command == "validate":
            return service.validate(args.occurrence_id)
        if args.incident_command == "export":
            return service.export(
                args.occurrence_id,
                reviewer=args.reviewed_by,
                include_diagnostics=args.include_diagnostics,
                acknowledge_warnings=args.acknowledge_warnings,
            )
        if args.incident_command == "submit":
            if service.index is None:
                raise RuntimeError("reporting index is unavailable")
            from persistmind.reporting.submission import submit_export

            return submit_export(
                occurrence_id=args.occurrence_id,
                export_id=args.export_id,
                index=service.index,
                config=service.settings.reporting,
                confirm=args.confirm,
            )
        if args.incident_command == "import-legacy":
            return service.import_legacy(args.path)
        if args.incident_command == "erase":
            return service.erase(args.occurrence_id, confirm=args.confirm)
        if args.incident_command == "reconcile":
            return service.reconcile(apply=bool(args.apply))
        if args.incident_command == "retention":
            return service.retention(apply=bool(args.apply), confirm=bool(args.confirm))
        if args.incident_command == "doctor":
            return service.doctor()
    raise ValueError("unknown reporting command")


def _reporting_request(args: argparse.Namespace, *, interactive: bool) -> dict[str, Any]:
    category = args.category
    summary = args.summary
    expected = args.expected
    actual = args.actual
    if interactive and (not category or not summary):
        if not (sys.stdin.isatty() and sys.stdout.isatty()):
            raise ValueError(
                "noninteractive report requires --category and --summary or --json-file"
            )
        category = category or input("Category: ").strip()
        summary = summary or input("What happened? ").strip()
        expected = expected or input("What did you expect? ").strip() or None
        actual = actual or input("What did PersistMind return? ").strip() or None
        preview = {"category": category, "severity": args.severity, "summary": summary}
        print(json.dumps({"privacy_preview": preview}, indent=2))
        if input("Create this local report? [y/N] ").strip().casefold() not in {"y", "yes"}:
            raise PermissionError("report creation cancelled")
    if not category or not summary:
        raise ValueError("incident create requires --category and --summary")
    return {
        "category": category,
        "severity": args.severity,
        "summary": summary,
        "expected": expected,
        "actual": actual,
        "operation_id": args.operation_id,
        "correlation_id": args.correlation_id,
        "pack_id": args.pack_id,
        "task_session_id": args.task_session_id,
        "agent_session_id": args.agent_session_id,
        "snapshot_id": args.snapshot_id,
        "generation_id": args.generation_id,
        "reproducibility": args.reproducibility,
        "steps": args.steps,
        "affected_files": args.affected_files,
        "affected_symbols": args.affected_symbols,
        "impact": {
            "incorrect_code_generated": True if args.incorrect_code else None,
            "task_blocked": True if args.task_blocked else None,
            "security_impact": True if args.security_impact else None,
            "estimated_rework_minutes": args.rework_minutes,
            "manual_rework_required": True if args.rework_minutes is not None else None,
        },
        "suspected_cause": args.suspected_cause,
        "workaround": args.workaround,
        "labels": args.labels,
    }


def _bindable_cli_route(args: argparse.Namespace) -> str | None:
    command = str(getattr(args, "command", "") or "")
    if command == "task" and getattr(args, "task_command", None) in {
        "start",
        "transition",
    }:
        return f"task.{args.task_command}"
    if command == "plan" and getattr(args, "plan_command", None) in {
        "create",
        "amend",
        "checkpoint",
    }:
        return f"plan.{args.plan_command}"
    if command in {"pack", "manifest", "outcome"}:
        return command
    if command in {"check-diff", "impact"}:
        return command.replace("-", "_")
    if command == "codex" and getattr(args, "codex_command", None) == "preflight":
        return "codex.preflight"
    if command == "workflow" and getattr(args, "workflow_command", None) in {
        "start",
        "next",
        "rebind",
    }:
        return f"workflow.{args.workflow_command}"
    return None


def _agent_runtime_request(args: argparse.Namespace) -> dict[str, Any]:
    if args.request_file is not None and args.request != "{}":
        raise ValueError("use either --request or --request-file, not both")
    if args.request_file is not None:
        path = Path(args.request_file)
        raw = sys.stdin.read() if str(path) == "-" else path.read_text(encoding="utf-8")
    else:
        raw = str(args.request)
    if len(raw.encode("utf-8")) > 1024 * 1024:
        raise ValueError("agent-runtime request exceeds 1 MiB")
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError("agent-runtime request is not valid JSON") from exc
    if not isinstance(value, dict):
        raise ValueError("agent-runtime request must be a JSON object")
    return value


def _dispatch_bootstrap_db(args: argparse.Namespace) -> dict[str, Any]:
    repo_root = Path(args.repo).resolve()
    from persistmind.storage.control import StorageControlPlane

    control = StorageControlPlane(repo_root)
    if args.db_command == "repair":
        return control.repair(dry_run=not bool(args.yes and not args.dry_run))
    if args.db_command == "probe":
        return control.topology()
    return control.verify(full=bool(args.full))


def _dispatch_operations(args: argparse.Namespace) -> dict[str, Any]:
    repo_root = Path(args.repo).resolve()
    settings = load_settings(repo_root)
    workspace_dir = repo_root / settings.toolchain.workspace_dir
    return operations_status(workspace_dir / "operations")


def _intelligence_operation(args: argparse.Namespace) -> tuple[str, str]:
    capability_map = {
        "anticipate": "anticipation",
        "bench": "benchmark",
        "teacher-bench": "teaching",
        "teacher-review": "teaching",
        "teach": "teaching",
        "lesson": "teaching",
        "selfimprove": "self_improvement",
        "metacog": "metacognition",
    }
    capability = capability_map.get(args.command, args.command.replace("-", "_"))
    action = "status"
    for name in (
        "anticipate_command",
        "bench_command",
        "foresight_command",
        "critique_command",
        "flywheel_command",
        "selfimprove_command",
        "cie_command",
        "teach_command",
        "lesson_command",
        "student_command",
        "curriculum_command",
        "teacher_review_command",
        "teacher_bench_command",
        "metacog_command",
    ):
        value = getattr(args, name, None)
        if value:
            action = str(value)
            break
    return capability, action


def _dispatch(args: argparse.Namespace, service: OperationClient) -> dict[str, Any] | None:
    from persistmind.security.context import principal_scope

    transport_principal = getattr(args, "transport_principal", None)
    if transport_principal is None:
        return _dispatch_impl(args, service)
    with principal_scope(transport_principal):
        return _dispatch_impl(args, service)


def _dispatch_impl(args: argparse.Namespace, service: OperationClient) -> dict[str, Any] | None:
    if args.command == "version":
        return {"ok": True, "version": __version__}
    if args.command == "config":
        from persistmind.config import config_document

        document = config_document(Path(args.repo).resolve())
        if args.config_command == "show-effective" and document.get("ok"):
            return {
                "ok": True,
                "status": "ok",
                "schema_version": document["schema_version"],
                "effective": document["effective"],
                "origins": document["origins"],
            }
        return document
    if args.command == "init":
        return service.init()
    if args.command == "bootstrap":
        return service.bootstrap(
            agents=args.agents,
            mcp_command=args.mcp_command,
            absolute_mcp_repo=args.absolute_mcp_repo,
            skip_index=args.skip_index,
            runtime=_runtime_invocation_from_args(args),
        )
    if args.command == "setup":
        return _dispatch_setup(args)
    if args.command == "quickstart":
        return _dispatch_quickstart(args, service)
    if args.command in {"index", "resolve-snapshot"}:
        return service.refresh_index() if args.command == "index" else service.resolve_snapshot()
    if args.command == "snapshot":
        if args.snapshot_command == "current":
            return service.snapshot_current()
        if args.snapshot_command == "lineage":
            return service.snapshot_lineage(args.snapshot_id, limit=args.limit)
    if args.command == "pack":
        return service.get_context_pack(
            args.task,
            args.budget,
            args.seed_path,
            rerank=not args.no_rerank,
            intent_id=args.intent_id,
            goal_id=args.goal_id,
            task_session_id=args.task_session_id,
            bind_snapshot=args.bind_snapshot,
            seed_from_diff=args.seed_from_diff,
            allow_legacy_auto_index=False,
        )
    if args.command == "intent":
        if args.intent_command == "start":
            problem = args.problem or args.intent_arg
            if not problem:
                raise ValueError("intent start requires --problem")
            return service.intent_start(problem, llm_propose=args.llm_propose)
        if args.intent_command == "show":
            if not args.intent_arg:
                raise ValueError("intent show requires an intent id")
            return service.intent_show(args.intent_arg)
        if args.intent_command == "refine":
            if not args.intent_arg:
                raise ValueError("intent refine requires an intent id")
            return service.intent_refine(
                args.intent_arg,
                evidence=args.evidence,
                select_goal=args.select_goal,
            )
        if args.intent_command == "list":
            return service.intent_list(status=args.status, limit=args.limit)
    if args.command == "goal":
        if args.goal_command == "evaluate":
            if not args.goal_arg:
                raise ValueError("goal evaluate requires an intent id")
            return service.goal_evaluate(
                args.goal_arg,
                candidate_goal_id=args.candidate_goal_id,
                mode=args.mode,
            )
        if args.goal_command == "show":
            if not args.goal_arg:
                raise ValueError("goal show requires a goal id")
            return service.goal_show(args.goal_arg)
        if args.goal_command == "challenge":
            if not args.goal_arg:
                raise ValueError("goal challenge requires a goal id")
            return service.goal_challenge(args.goal_arg)
        if args.goal_command == "accept-alternative":
            if not args.goal_arg or not args.alt_id or not args.rationale:
                raise ValueError("goal accept-alternative requires goal id, --alt, and --rationale")
            return service.goal_accept_alternative(args.goal_arg, args.alt_id, args.rationale)
        if args.goal_command == "reject-alternative":
            if not args.goal_arg or not args.alt_id or not args.rationale:
                raise ValueError("goal reject-alternative requires goal id, --alt, and --rationale")
            return service.goal_reject_alternative(args.goal_arg, args.alt_id, args.rationale)
        if args.goal_command == "reevaluate":
            if not args.goal_arg:
                raise ValueError("goal reevaluate requires a goal id")
            return service.goal_reevaluate(args.goal_arg, trigger=args.trigger)
        if args.goal_command == "list":
            return service.goal_list(status=args.status, limit=args.limit)
    if args.command == "manifest":
        return service.get_pack_manifest(args.pack_id)
    if args.command == "reconstruct-pack":
        return service.reconstruct_pack(args.pack_id, args.task_text)
    if args.command == "impact":
        paths = normalize_path_records(args.paths)
        diff = None
        if args.paths_from_stdin:
            paths.extend(read_path_records(sys.stdin))
        if args.diff_from_stdin:
            diff = normalize_diff_input(sys.stdin.read())
        return service.get_impact_report(
            paths=paths,
            pack_id=args.pack_id,
            diff=diff,
            business=args.business,
        )
    if args.command == "anticipate":
        if args.anticipate_command == "train":
            return service.anticipate_train()
        if args.anticipate_command == "status":
            return service.anticipate_status()
        if args.anticipate_command == "doctor":
            return service.anticipate_doctor()
        if args.anticipate_command == "benchmark":
            return service.anticipate_benchmark(
                arms=_nextgen_csv_or_space(args.arms),
                threshold=args.threshold,
                limit=args.limit,
                holdout_ratio=args.holdout_ratio,
                ece_bins=args.ece_bins,
                semantic_model=args.semantic_model,
                semantic_backend=args.semantic_backend,
            )
        if args.anticipate_command == "shadow-validate":
            return service.anticipate_shadow_validate(
                limit=args.limit,
                mode=args.mode,
            )
        if args.anticipate_command == "consult":
            task = args.anticipate_task or args.anticipate_arg
            if not task:
                raise ValueError("anticipate consult requires --task")
            return service.anticipate_consult(
                task=task,
                paths=list(args.paths),
                session_id=args.anticipate_session,
            )
        if args.anticipate_command == "ui-review":
            task = args.anticipate_task or args.anticipate_arg or ""
            return service.anticipate_ui_review(task=task, paths=list(args.paths))
        if args.anticipate_command == "score":
            session_id = args.anticipate_session or args.anticipate_arg
            if not session_id:
                raise ValueError("anticipate score requires --session")
            return service.anticipate_score(session_id)
        if args.anticipate_command == "lookahead":
            task = args.anticipate_task or args.anticipate_arg
            if not task:
                raise ValueError("anticipate lookahead requires --task")
            return service.anticipate_lookahead(task=task, paths=list(args.paths), top_k=args.top_k)
        if args.anticipate_command == "simulate":
            task = args.anticipate_task or args.anticipate_arg
            if not task:
                raise ValueError("anticipate simulate requires --task")
            return service.anticipate_simulate(
                task=task,
                paths=list(args.paths),
                depth=args.depth,
                beam=args.beam,
            )
        if args.anticipate_command == "transfer-export":
            return service.anticipate_transfer_export()
        if args.anticipate_command == "transfer-status":
            return service.anticipate_transfer_import_status()
        if args.anticipate_command == "gut":
            session_id = args.anticipate_session or args.anticipate_arg
            if not session_id:
                raise ValueError("anticipate gut requires --session")
            return service.anticipate_gut(session_id=session_id, paths=list(args.paths))
    if args.command == "business":
        if args.business_command == "entity":
            if args.business_action == "add":
                if args.file and not args.name and not args.business_type:
                    return service.business_entity_bulk_add(
                        file=args.file,
                        origin=args.origin,
                        proposed_by=args.proposed_by,
                    )
                if not args.business_type or not args.name:
                    raise ValueError("business entity add requires --type and --name, or --file")
                attrs = json.loads(args.attrs or "{}")
                if args.file:
                    path = Path(args.file)
                    attrs = json.loads(path.read_text(encoding="utf-8"))
                return service.business_entity_add(
                    node_type=args.business_type,
                    name=args.name,
                    attrs=attrs,
                    origin=args.origin,
                    source_type=args.source_type,
                    source_ref=args.source_ref or args.file,
                    proposed_by=args.proposed_by,
                    confidence=args.confidence,
                )
            if args.business_action == "list":
                return service.business_entity_list(
                    status=args.status,
                    node_type=args.business_type,
                    limit=args.limit,
                )
            if args.business_action == "approve":
                if not args.business_arg:
                    raise ValueError("business entity approve requires a node id")
                return service.business_entity_approve(
                    args.business_arg,
                    approver=args.approver,
                    notes=args.notes,
                )
            if args.business_action == "reject":
                if not args.business_arg:
                    raise ValueError("business entity reject requires a node id")
                return service.business_entity_reject(
                    args.business_arg,
                    approver=args.approver,
                    reason=args.reason,
                )
        if args.business_command == "link":
            if not args.src or not args.dst or not args.kind:
                raise ValueError("business link requires --src, --dst, and --kind")
            return service.business_link(
                src_node_id=args.src,
                dst_node_id=args.dst,
                kind=args.kind,
                source_ref=args.source_ref or "manual",
                source_type=args.source_type or "manual_entry",
                proposed_by=args.proposed_by,
                confidence=args.confidence,
            )
    if args.command == "check-diff":
        paths = normalize_path_records(args.paths)
        diff = None
        if args.paths_from_stdin:
            paths.extend(read_path_records(sys.stdin))
        else:
            diff = normalize_diff_input(sys.stdin.read())
        return service.check_diff_against_pack(args.pack_id, diff=diff, paths=paths or None)
    if args.command == "guardrail":
        if args.guardrail_command == "override":
            if not args.directive_id:
                raise ValueError("guardrail override requires directive_id")
            if not all((args.signature, args.nonce, args.issued_at, args.expires_at)):
                raise ValueError(
                    "guardrail override requires --signature, --nonce, --issued-at, and --expires-at"
                )
            return service.guardrail_override(
                args.directive_id,
                rationale=args.rationale,
                task_session_id=args.task_session_id,
                session_id=args.session_id,
                target_paths=args.guardrail_paths,
                actor=args.actor,
                signature=args.signature,
                nonce=args.nonce,
                issued_at=args.issued_at,
                expires_at=args.expires_at,
            )
    if args.command == "search":
        return service.search_code(args.query, args.limit)
    if args.command == "audit":
        if args.audit_command == "verify":
            return service.verify_audit()
        if args.audit_command == "tip":
            return service.export_audit_tip(args.output)
        if args.audit_command == "anchor":
            if not all((args.signature, args.nonce, args.issued_at)):
                raise ValueError("audit anchor requires --signature, --nonce, and --issued-at")
            return service.anchor_audit(
                actor=args.actor,
                signature=args.signature,
                nonce=args.nonce,
                issued_at=args.issued_at,
            )
        if not args.pack_id:
            raise ValueError("--pack-id is required for audit record")
        return service.get_audit_record(args.pack_id)
    if args.command == "outcome":
        if not args.pack_id:
            raise ValueError("outcome requires --pack-id")
        if not args.session_id:
            raise ValueError("outcome requires --session-id")
        return service.record_outcome(
            args.session_id,
            args.result,
            pack_id=args.pack_id,
            files_changed=args.files,
            summary=args.summary,
        )
    if args.command == "bench":
        if args.bench_command == "show":
            return service.bench_show(limit=args.limit)
        if args.bench_command == "retention":
            if not args.bench_retention_command:
                raise ValueError("bench retention requires set or check")
            metrics: dict[str, float] = {}
            for item in args.bench_metrics:
                if "=" not in item:
                    raise ValueError("--metric must be formatted as key=value")
                key, value = item.split("=", 1)
                metrics[key] = float(value)
            if args.bench_retention_command == "set":
                return service.retention_baseline_set(
                    task_set=args.task_set,
                    created_by=args.created_by,
                    run_id=args.run_id,
                    metrics=metrics or None,
                    floor_ratio=args.floor_ratio,
                )
            return service.retention_check(task_set=args.task_set, run_id=args.run_id)
        return service.bench(persist=args.bench_persist, split=args.split)
    if args.command == "working-memory":
        if args.working_memory_command == "capture":
            if not args.task_session_id:
                raise ValueError("working-memory capture requires --task-session-id")
            text = args.text or args.working_memory_arg
            if not text:
                raise ValueError("working-memory capture requires --text")
            evidence_refs = []
            for raw in args.evidence:
                evidence_refs.append(json.loads(raw))
            return service.working_memory_capture(
                task_session_id=args.task_session_id,
                cycle_id=args.cycle_id,
                kind=args.kind,
                text=text,
                salience=args.salience,
                evidence_refs=evidence_refs,
                expires_at=args.expires_at,
            )
        if args.working_memory_command == "list":
            if not args.task_session_id:
                raise ValueError("working-memory list requires --task-session-id")
            return service.working_memory_list(
                task_session_id=args.task_session_id,
                cycle_id=args.cycle_id,
                limit=args.limit,
            )
        note_id = args.working_memory_arg
        if not note_id:
            raise ValueError(f"working-memory {args.working_memory_command} requires note_id")
        if args.working_memory_command == "decline":
            return service.working_memory_decline(
                note_id,
                actor=args.actor,
                reason=args.reason or args.text or "not promotable",
            )
        return service.working_memory_promote(
            note_id,
            actor=args.actor,
            validator=args.validator,
        )
    if args.command == "foresight":
        if args.foresight_command == "for":
            return service.foresight_for(
                paths=args.foresight_paths,
                limit=args.limit,
                max_commits=args.max_commits,
            )
    if args.command == "reasoning":
        if args.reasoning_command == "route":
            return service.reasoning_route(
                task=args.task,
                paths=args.reasoning_paths,
            )
        return service.reasoning_checkpoint(
            task=args.task,
            checkpoint=args.checkpoint,
            paths=args.reasoning_paths,
            task_session_id=args.task_session_id,
            surprise=args.surprise,
        )
    if args.command == "experience":
        if args.experience_command == "record":
            if not args.task:
                raise ValueError("experience record requires --task")
            evidence = [json.loads(raw) for raw in args.evidence]
            return service.experience_record(
                task=args.task,
                paths=args.experience_paths,
                surprise=args.surprise,
                trigger=args.trigger,
                evidence=evidence,
            )
        return service.experience_list(
            task=args.task,
            paths=args.experience_paths,
            status=args.status,
            limit=args.limit,
        )
    if args.command == "critique":
        if args.critique_command == "workspace":
            return service.workspace_critique(
                task=args.task,
                paths=args.critique_paths,
                diff=args.diff,
                risk_threshold=args.risk_threshold,
            )
    if args.command == "flywheel":
        if args.flywheel_command == "status":
            return service.flywheel_status()
        if args.flywheel_command == "maintain":
            return service.flywheel_maintain()
    if args.command == "db":
        if args.db_command == "backend-status":
            return service.db_backend_status()
        if args.db_command == "bench":
            return service.db_bench(
                history=args.history,
                limit=args.limit,
                corpus=args.corpus or None,
            )
    if args.command == "doctor":
        return service.doctor(full=bool(args.full))
    if args.command == "db-stats":
        return service.db_stats()
    if args.command == "gc":
        return service.gc(
            deep=args.deep,
            prune_snapshots=args.prune_snapshots,
            archive_pruned_snapshots=args.archive_pruned_snapshots,
            dry_run=args.dry_run,
        )
    if args.command == "retention":
        if args.retention_command == "show":
            return service.retention_show()
        if not args.target and not args.preset:
            raise ValueError("retention set requires target")
        return service.retention_set(
            target=args.target,
            preset=args.preset,
            keep_full_days=args.keep_full_days,
            keep_summary_days=args.keep_summary_days,
            max_rows=args.max_rows,
            scope=args.scope,
        )
    if args.command == "maintenance":
        if args.maintenance_command == "run":
            return service.maintenance_run(full=not args.light, trigger=args.trigger)
        if args.maintenance_command == "history":
            return service.maintenance_history(limit=args.limit)
        if args.maintenance_command == "tick":
            return service.maintenance_tick(full=not args.light)
    if args.command == "hook":
        if args.hook_command == "install":
            return service.install_post_commit_hook()
    if args.command == "constitution":
        if args.constitution_command == "build":
            if not all(
                (
                    args.signature,
                    args.nonce,
                    args.issued_at,
                    args.expires_at,
                )
            ):
                raise ValueError(
                    "constitution build requires --signature, --nonce, --issued-at, and --expires-at"
                )
            return service.constitution_build(
                actor=args.actor,
                signature=args.signature,
                nonce=args.nonce,
                issued_at=args.issued_at,
                expires_at=args.expires_at,
            )
        if args.constitution_command == "show":
            return service.constitution_show()
        if args.constitution_command == "check":
            result = service.constitution_check(
                args.constitution_paths,
                staged=args.staged,
                task_session_id=args.task_session_id,
                for_ci=args.ci,
            )
            if args.fail_on_violation and not result.get("ok"):
                details = result.get("details") if isinstance(result.get("details"), dict) else {}
                failing = details.get("failing_capabilities") or []
                suffix = f": {', '.join(failing)}" if failing else ""
                raise CliInputError(
                    f"constitution capability check failed{suffix}",
                    remediation=str(
                        result.get("remediation")
                        or "Review constitution check details and rerun the command."
                    ),
                )
            return result
    if args.command == "task":
        if args.task_command == "start":
            task_text = args.task or args.task_arg
            if not task_text:
                raise ValueError("task start requires --task")
            return service.task_start(task_text)
        if args.task_command == "transition":
            task_session_id = args.task_arg
            if not task_session_id or not args.state:
                raise ValueError("task transition requires task_session_id and --state")
            return service.task_transition(
                task_session_id,
                args.state,
                actor=args.actor,
                reason=args.reason,
                pack_id=args.pack_id,
            )
        if args.task_command == "learned":
            if not args.task_arg:
                raise ValueError("task learned requires task_session_id")
            return service.task_learning_report(args.task_arg)
        if args.task_command == "remediation-attempt":
            if not args.task_arg:
                raise ValueError("task remediation-attempt requires task_session_id")
            return service.remediation_attempt_record(
                args.task_arg,
                gate_id=args.gate or args.blocking_gate or "",
                approach=args.approach or "",
                outcome=args.outcome or "",
                command_or_tool=args.command_or_tool,
                error=args.error,
                waited_seconds=args.waited_seconds,
                backoff_strategy=args.backoff_strategy,
                transient_recovery=args.transient_recovery,
                actor=args.actor,
            )
        if args.task_command == "close":
            if not args.task_arg:
                raise ValueError("task close requires task_session_id")
            return service.task_close(
                args.task_arg,
                result=args.result or "",
                reason=args.reason or "",
                blocking_gate_id=args.blocking_gate,
                actor=args.actor,
            )
    if args.command == "plan":
        if args.plan_command == "validate":
            plan = _load_plan_arg(args)
            result = service.plan_validate(
                plan,
                task_session_id=args.task_session_id,
                pack_id=args.pack_id,
            )
            if args.fail_on_violation and not result.get("ok"):
                raise ValueError("task plan validation failed")
            return result
        if args.plan_command == "create":
            if not args.task_session_id:
                raise ValueError("plan create requires --task-session-id")
            plan = _load_plan_arg(args)
            result = service.plan_create(
                args.task_session_id,
                plan,
                pack_id=args.pack_id,
                author=args.author,
            )
            if args.fail_on_violation and not result.get("ok"):
                raise ValueError("task plan validation failed")
            return result
        if args.plan_command == "show":
            if not args.plan_arg:
                raise ValueError("plan show requires plan_id")
            return service.plan_show(args.plan_arg)
        if args.plan_command == "amend":
            if not args.plan_arg:
                raise ValueError("plan amend requires plan_id")
            plan = _load_plan_arg(args, allow_positional_json=False)
            result = service.plan_amend(
                args.plan_arg,
                plan,
                author=args.author,
                reason=args.reason,
            )
            if args.fail_on_violation and not result.get("ok"):
                raise ValueError("task plan validation failed")
            return result
        if args.plan_command == "checkpoint":
            if not args.plan_arg or not args.step_id:
                raise ValueError("plan checkpoint requires plan_id and --step-id")
            result = service.plan_checkpoint(
                args.plan_arg,
                args.step_id,
                paths=args.plan_paths,
                staged=args.staged,
            )
            if args.fail_on_violation and not result.get("ok"):
                raise ValueError("task plan checkpoint failed")
            return result
    if args.command == "eval":
        if args.eval_command == "replay":
            return service.eval_replay(args.limit, args.holdout_ratio)
        if args.eval_command == "tune":
            return service.eval_tune(args.limit, args.holdout_ratio)
        if args.eval_command == "components":
            return service.eval_components(args.ground_truth)
        if args.eval_command == "ab":
            return service.eval_ab_baseline(args.limit)
        if args.eval_command == "agent":
            if not args.cases or not args.agent_command:
                raise ValueError("eval agent requires --cases and --agent-command")
            result = service.eval_agent_benchmark(
                args.cases,
                args.agent_command,
                limit=args.limit,
                timeout=args.timeout,
                keep_worktrees=args.keep_worktrees,
                gate=args.gate,
                gate_thresholds=_agent_gate_thresholds(args) if args.gate else None,
            )
            if args.fail_on_regression and result.get("gate", {}).get("status") == "fail":
                raise ValueError("agent benchmark regression gate failed")
            return result
        if args.eval_command in {"run", "efficacy"}:
            if args.eval_command == "run" and args.suite != "efficacy":
                raise ValueError(f"unsupported eval suite: {args.suite}")
            if not args.cases or not args.agent_command:
                raise ValueError(f"eval {args.eval_command} requires --cases and --agent-command")
            result = service.eval_run_efficacy(
                args.cases,
                args.agent_command,
                baseline=args.baseline,
                candidate=args.candidate,
                limit=args.limit,
                timeout=args.timeout,
                keep_worktrees=args.keep_worktrees,
            )
            if args.fail_on_regression and result.get("gate", {}).get("status") == "fail":
                raise ValueError("efficacy scorecard gate failed")
            return result
        if args.eval_command == "scorecard":
            return service.eval_scorecard(args.output)
        if args.eval_command == "loop-verify":
            return service.eval_loop_verify(
                task=args.probe_task,
                paths=args.probe_path or ["app/service.py"],
                result=args.result,
            )
        if args.eval_command == "gate":
            if not args.report:
                raise ValueError("eval gate requires --report")
            result = service.eval_agent_gate(args.report, thresholds=_agent_gate_thresholds(args))
            if args.fail_on_regression and result.get("status") == "fail":
                raise ValueError("agent benchmark regression gate failed")
            return result
        if args.eval_command == "harvest":
            provider = args.eval_provider
            project = args.provider_repo or args.provider_repo_alias or args.project
            if not provider or not project:
                raise ValueError("eval harvest requires provider and --provider-repo/--project")
            return service.eval_harvest(provider, project, args.limit)
        if args.eval_command == "compare":
            return service.eval_compare(args.task_source or ["git-only", "provider"], args.limit)
        if args.eval_command == "diagnose":
            if not args.report:
                raise ValueError("eval diagnose requires --report")
            return service.eval_diagnose(json.loads(Path(args.report).read_text(encoding="utf-8")))
    if args.command == "cie":
        if args.cie_command == "status":
            return service.cie_status()
        if args.cie_command == "cycle":
            return service.cie_cycle(
                limit=args.limit,
                target=args.target,
                task=args.task,
                paths=args.cie_paths,
            )
        if args.cie_command == "archive":
            return service.cie_archive(
                target=args.target if args.target else None, limit=args.limit
            )
        if args.cie_command == "show":
            run_id = args.run_id or args.cie_arg
            if not run_id:
                raise ValueError("cie show requires run_id")
            return service.cie_show(run_id)
        if args.cie_command == "checklist-preview":
            return service.cie_checklist_preview(
                task=args.task or args.cie_arg or "", paths=args.cie_paths
            )
        if args.cie_command == "predict":
            return service.cie_predict(task=args.task or args.cie_arg or "", paths=args.cie_paths)
        if args.cie_command == "score":
            return service.cie_score(period=args.period)
        if args.cie_command == "timeline":
            return service.cie_timeline(run_id=args.run_id or args.cie_arg)
        if args.cie_command in {
            "preview-adoption",
            "adopt",
            "reject",
            "suspend",
            "rollback",
        }:
            run_id = args.run_id
            intervention_id = args.intervention_id or args.cie_arg
            if not run_id or not intervention_id:
                raise ValueError(f"cie {args.cie_command} requires --run-id and intervention_id")
            if args.cie_command == "preview-adoption":
                return service.cie_preview_adoption(run_id, intervention_id)
            if args.cie_command == "adopt":
                return service.cie_adopt(run_id, intervention_id, args.approved_by)
            if args.cie_command == "reject":
                return service.cie_reject(run_id, intervention_id, args.reason, args.actor)
            if args.cie_command == "suspend":
                return service.cie_suspend(run_id, intervention_id, args.reason, args.actor)
            if args.cie_command == "rollback":
                return service.cie_rollback(run_id, intervention_id, args.approved_by)
        if args.cie_command == "export-state":
            return service.cie_export_state(output=args.output)
        if args.cie_command == "import-state":
            input_path = args.input or args.cie_arg
            if not input_path:
                raise ValueError("cie import-state requires --input")
            return service.cie_import_state(input_path, dry_run=args.dry_run or True)
        if args.cie_command == "rebuild-state":
            return service.cie_rebuild_state(
                from_events=args.from_events or True, dry_run=args.dry_run or True
            )
    if args.command == "learning":
        if args.learning_command == "status":
            return service.learning_status()
        if args.learning_command == "optimize":
            return service.learning_optimize(
                args.target,
                iterations=args.iterations,
                limit=args.limit,
                holdout_ratio=args.holdout_ratio,
                adopt=args.adopt,
            )
        if args.learning_command == "archive":
            return service.learning_archive(
                target=args.target if args.target else None, limit=args.limit
            )
        if args.learning_command == "benchmark-trends":
            return service.learning_benchmark_trends(limit=args.limit)
        if args.learning_command == "recent":
            return service.learning_recent(limit=args.limit)
        if args.learning_command == "adopt":
            run_id = args.learning_arg
            if not run_id:
                raise ValueError("learning adopt requires run_id")
            return service.learning_adopt(run_id)
        if args.learning_command == "revert":
            run_id = args.learning_arg
            if not run_id:
                raise ValueError("learning revert requires run_id")
            return service.learning_revert(run_id)
        if args.learning_command == "selfmod-propose":
            return service.learning_selfmod_propose(
                args.target,
                weakness=args.weakness,
                ancestor_run_id=args.ancestor_run_id,
            )
        if args.learning_command == "selfmod-archive":
            return service.learning_selfmod_archive(
                target=args.target if args.target else None,
                limit=args.limit,
            )
        if args.learning_command == "selfmod-adopt":
            run_id = args.learning_arg
            if not run_id:
                raise ValueError("learning selfmod-adopt requires run_id")
            return service.learning_selfmod_adopt(run_id, approved_by=args.approved_by)
        if args.learning_command == "selfmod-revert":
            run_id = args.learning_arg
            if not run_id:
                raise ValueError("learning selfmod-revert requires run_id")
            return service.learning_selfmod_revert(run_id)
        if args.learning_command == "loop-verify":
            probe = "all" if args.learning_all else args.probe
            result = service.learning_loop_verify(
                args.learning_arg,
                probe=probe,
                require_closure=args.require_closure,
            )
            if args.require_closure and not result.get("ok", False):
                raise SystemExit(json.dumps(result, indent=2, sort_keys=True))
            return result
    if args.command == "selfimprove":
        if args.selfimprove_command == "status":
            return service.self_improve_status()
        if args.selfimprove_command == "audit":
            return service.self_improve_audit(force=args.force)
        if args.selfimprove_command == "brief":
            return service.self_improve_brief(force=args.force)
        if args.selfimprove_command == "list":
            return service.self_improve_list(
                run_id=args.run_id,
                status=args.status,
                limit=args.limit,
            )
        if args.selfimprove_command == "show":
            proposal_id = args.selfimprove_arg
            if not proposal_id:
                raise ValueError("selfimprove show requires proposal_id")
            return service.self_improve_show(proposal_id)
        if args.selfimprove_command == "propose":
            evidence = json.loads(args.evidence or "{}")
            if args.selfimprove_diff_file:
                evidence["diff"] = Path(args.selfimprove_diff_file).read_text(encoding="utf-8")
            if args.selfimprove_diff is not None:
                evidence["diff"] = args.selfimprove_diff
            return service.self_improve_capture(
                title=args.title,
                rationale=args.rationale,
                target_files=args.selfimprove_target_files,
                evidence=evidence,
                predicted_effect=json.loads(args.predicted_effect or "{}"),
                parent_id=args.parent_id,
            )
        if args.selfimprove_command == "evaluate":
            proposal_id = args.selfimprove_arg
            if not proposal_id:
                raise ValueError("selfimprove evaluate requires proposal_id")
            return service.self_improve_evaluate(
                proposal_id,
                commands=args.selfimprove_commands,
            )
        if args.selfimprove_command == "adopt":
            proposal_id = args.selfimprove_arg
            if not proposal_id:
                raise ValueError("selfimprove adopt requires proposal_id")
            return service.self_improve_adopt(proposal_id)
        if args.selfimprove_command == "reject":
            proposal_id = args.selfimprove_arg
            if not proposal_id:
                raise ValueError("selfimprove reject requires proposal_id")
            return service.self_improve_reject(proposal_id, reason=args.reason)
        if args.selfimprove_command == "rollback":
            proposal_id = args.selfimprove_arg
            if not proposal_id:
                raise ValueError("selfimprove rollback requires proposal_id")
            return service.self_improve_rollback(proposal_id, reason=args.reason)
        if args.selfimprove_command == "lineage":
            return service.self_improve_lineage(
                proposal_id=args.selfimprove_arg,
                limit=args.limit,
            )
        if args.selfimprove_command == "run":
            return service.self_improve_run(
                auto=args.auto,
                max_iters=args.max_iters,
                budget_tokens=args.budget,
            )
        if args.selfimprove_command == "doctor":
            return service.self_improve_doctor()
        if args.selfimprove_command == "verify-safety":
            return service.self_improve_verify_safety(confirm=args.confirm)
    if args.command == "skill":
        if args.skill_command == "induce":
            session_id = args.skill_session_id or args.skill_arg
            if not session_id:
                raise ValueError("skill induce requires --session")
            return service.skill_induce(session_id)
        if args.skill_command == "list":
            return service.skill_list(status=args.status, trust=args.trust)
        if args.skill_command == "show":
            if not args.skill_arg:
                raise ValueError("skill show requires skill_id")
            return service.skill_show(args.skill_arg)
        if args.skill_command == "replay":
            if not args.skill_arg:
                raise ValueError("skill replay requires skill_id")
            return service.skill_replay(args.skill_arg, timeout=args.timeout)
        if args.skill_command == "approve":
            if not args.skill_arg:
                raise ValueError("skill approve requires skill_id")
            return service.skill_approve(args.skill_arg, approved_by=args.approved_by)
        if args.skill_command == "reject":
            if not args.skill_arg:
                raise ValueError("skill reject requires skill_id")
            return service.skill_reject(args.skill_arg, reason=args.reason)
        if args.skill_command == "prune":
            return service.skill_prune(max_failures=args.max_failures)
        if args.skill_command == "maintain":
            return service.skill_maintain(
                max_failures=args.max_failures,
                stale_after_days=args.stale_after_days,
            )
        if args.skill_command == "search":
            if not args.skill_arg:
                raise ValueError("skill search requires query")
            return service.skill_search(
                args.skill_arg,
                limit=args.limit,
                include_untrusted=args.include_untrusted,
            )
        if args.skill_command == "artifact":
            skill_id = args.skill_id or args.skill_arg
            return service.skill_artifact_register(
                skill_id=skill_id,
                artifact_kind=args.kind,
                summary=args.summary,
                content=args.text,
                session_id=args.skill_session_id,
                task_session_id=args.task_session_id,
                output_id=args.output_id,
            )
        if args.skill_command == "revision":
            revision_text = args.text or args.summary
            if not revision_text:
                raise ValueError("skill revision requires --text")
            return service.skill_revision_capture(
                revision_text=revision_text,
                output_id=args.output_id,
                skill_id=args.skill_id or args.skill_arg,
                session_id=args.skill_session_id,
                task_session_id=args.task_session_id,
                actor=args.actor,
                signal_kind=args.signal_kind,
            )
        if args.skill_command == "accept":
            output_id = args.output_id or args.skill_arg
            if not output_id:
                raise ValueError("skill accept requires output_id")
            return service.skill_accept_first_pass(output_id)
        if args.skill_command == "metrics":
            return service.skill_metrics(args.skill_id or args.skill_arg)
        if args.skill_command == "classify":
            return service.skill_revision_classify(args.skill_arg, skill_id=args.skill_id)
        if args.skill_command == "improvements":
            return service.skill_improvements(
                skill_id=args.skill_id or args.skill_arg, status=args.status
            )
        if args.skill_command == "refine-approve":
            if not args.skill_arg:
                raise ValueError("skill refine-approve requires sir_id")
            return service.skill_refinement_approve(args.skill_arg, approved_by=args.approved_by)
        if args.skill_command == "refine-benchmark":
            if not args.skill_arg:
                raise ValueError("skill refine-benchmark requires sir_id")
            return service.skill_refinement_benchmark(args.skill_arg)
        if args.skill_command == "rollback":
            skill_id = args.skill_id or args.skill_arg
            if not skill_id:
                raise ValueError("skill rollback requires skill_id")
            return service.skill_refinement_rollback(skill_id)
        if args.skill_command == "closure":
            return service.skill_closure_verify(args.skill_id or args.skill_arg)
        if args.skill_command == "promote-global":
            skill_id = args.skill_id or args.skill_arg
            if not skill_id:
                raise ValueError("skill promote-global requires skill_id")
            return service.skill_global_promote(skill_id, approver=args.approved_by)
        if args.skill_command == "adopt-global":
            global_skill_id = args.global_skill_id or args.skill_arg
            if not global_skill_id:
                raise ValueError("skill adopt-global requires global_skill_id")
            return service.skill_global_adopt(global_skill_id, approver=args.approved_by)
    if args.command == "release":
        if args.release_command in {"check", "validate"}:
            return service.release_check(args.version)
        if args.release_command == "report":
            return service.release_report()
        if args.release_command == "compare":
            if not args.baseline:
                raise ValueError("release compare requires --baseline")
            return service.release_compare(args.baseline)
        if args.release_command == "gap-register":
            return service.release_gap_register()
        if args.release_command == "gap-validate":
            return service.release_gap_validate()
        if args.release_command == "gap-write":
            return service.release_gap_write(args.output)
        if args.release_command == "inventory-write":
            return service.release_dead_code_inventory_write(args.output)
        if args.release_command == "checklist-write":
            return service.release_no_v0_checklist_write(args.output)
        if args.release_command == "benchmark-write":
            return service.release_benchmark_artifacts_write(args.output)
    if args.command == "ci":
        if args.ci_command == "check":
            return service.ci_check(args.base, args.head, args.pack_id)
        if args.ci_command == "emit-github":
            return service.ci_emit_github()
        if args.ci_command == "emit-gitlab":
            return service.ci_emit_gitlab()
        if args.ci_command == "explain":
            if not args.report:
                raise ValueError("ci explain requires --report")
            return service.ci_explain(args.report)
    if args.command == "workspace":
        if args.workspace_command == "init":
            return service.workspace_init()
        if args.workspace_command == "add-repo":
            if not args.workspace_arg:
                raise ValueError("workspace add-repo requires a path")
            return service.workspace_add_repo(args.workspace_arg)
        if args.workspace_command == "index":
            return service.workspace_index()
        if args.workspace_command == "impact":
            repo_id = args.repo_id or args.workspace_repo_alias or args.workspace_arg
            if not repo_id:
                raise ValueError("workspace impact requires --repo-id")
            return service.workspace_impact(repo_id)
        if args.workspace_command == "status":
            return service.workspace_status()
        if args.workspace_command == "promotions":
            return service.workspace_rule_promotions()
        if args.workspace_command == "explain":
            if not args.task:
                raise ValueError("workspace explain requires --task")
            return service.workspace_explain(args.task, paths=args.workspace_paths)
    if args.command == "security":
        if args.security_command == "scan":
            return service.security_scan()
        if args.security_command == "status":
            return service.security_status()
        if args.security_command == "redact-audit":
            return {
                "ok": True,
                "message": "audit text storage is hashed by default; no plaintext redaction needed",
            }
        if args.security_command == "quarantine-list":
            return service.memory_security_reviews(args.status)
        if args.security_command == "ingest-redteam":
            result = service.security_ingest_redteam(
                args.fixtures,
                output=args.output,
                strict=args.strict,
            )
            if args.strict and not result.get("ok", False):
                raise SystemExit(json.dumps(result, indent=2, sort_keys=True))
            return result
    if args.command == "memory":
        if args.memory_command == "scan":
            result = service.memory_candidates(args.status)
            result["schema_version"] = "persistmind.memory_scan.v1"
            return result
        if args.memory_command == "bench":
            return service.memory_bench(samples=args.samples)
        if args.memory_command == "candidates":
            return service.memory_candidates(args.status)
        if args.memory_command == "explain":
            if not args.rule_id:
                raise ValueError("memory explain requires candidate_id")
            return service.memory_explain(args.rule_id)
        if args.memory_command == "list":
            return service.memory_list(args.status)
        if args.memory_command == "approve":
            if not args.rule_id:
                raise ValueError("memory approve requires candidate_id")
            return service.memory_approve(args.rule_id, args.approved_by)
        if args.memory_command == "reject":
            if not args.rule_id:
                raise ValueError("memory reject requires candidate_id")
            return service.memory_reject(args.rule_id)
        if args.memory_command == "supersede":
            if not args.rule_id or not args.with_candidate:
                raise ValueError("memory supersede requires old_rule_id --with new_candidate_id")
            return service.memory_supersede(args.rule_id, args.with_candidate, args.approved_by)
        if args.memory_command == "conflicts":
            return service.memory_conflicts()
        if args.memory_command == "stale":
            return service.memory_stale()
        if args.memory_command == "verify":
            return service.memory_verify()
        if args.memory_command == "explain-rule":
            if not args.rule_id:
                raise ValueError("memory explain-rule requires rule_id")
            return service.memory_explain(args.rule_id)
        if args.memory_command == "eval":
            if not args.rule_id:
                raise ValueError("memory eval requires harvest|replay|report")
            return service.memory_eval(args.rule_id)
        if args.memory_command == "extraction-eval":
            return service.memory_extraction_eval(args.fixtures, args.source_type)
        if args.memory_command == "trust-calibrate":
            return service.memory_trust_calibrate(apply=bool(args.apply and not args.dry_run))
        if args.memory_command == "search":
            query = _memory_query(args)
            if not query:
                raise ValueError("memory search requires a query")
            return service.memory_search(query, args.memory_type or None, args.status)
        if args.memory_command == "recall":
            query = _memory_query(args)
            if not query:
                raise ValueError("memory recall requires a query")
            return service.memory_recall(
                query,
                paths=args.memory_paths,
                types=args.memory_type or None,
                limit=args.limit,
                include_org=args.include_org,
            )
        if args.memory_command == "create":
            if args.memory_json:
                payload = json.loads(args.memory_json)
            else:
                if not args.rule_id or not args.memory_type:
                    raise ValueError("memory create requires --type and assertion")
                payload = {
                    "type": args.memory_type[0],
                    "assertion": args.rule_id,
                    "title": args.title,
                    "source_kind": args.source_kind,
                    "confidence": args.confidence,
                    "scope_refs": args.memory_paths,
                }
            return service.memory_create_typed(payload)
        if args.memory_command == "update":
            if not args.rule_id or not args.memory_json:
                raise ValueError("memory update requires record_id and --json patch")
            return service.memory_update(args.rule_id, json.loads(args.memory_json), args.reason)
        if args.memory_command == "validate":
            if not args.rule_id:
                raise ValueError("memory validate requires record_id")
            return service.memory_validate(args.rule_id, args.validator, actor=args.approved_by)
        if args.memory_command == "expire":
            if not args.rule_id:
                raise ValueError("memory expire requires record_id")
            return service.memory_expire(args.rule_id, args.reason, actor=args.approved_by)
        if args.memory_command == "quarantine":
            if not args.rule_id:
                raise ValueError("memory quarantine requires record_id")
            return service.memory_quarantine(
                args.rule_id,
                args.reason,
                severity=args.severity,
                actor=args.approved_by,
            )
        if args.memory_command == "diff":
            if not args.rule_id:
                raise ValueError("memory diff requires record_id")
            return service.memory_diff(args.rule_id)
        if args.memory_command == "dream":
            return service.memory_dream(args.session_id or args.rule_id, args.recent)
        if args.memory_command == "maintain":
            return service.memory_maintain(args.limit)
        if args.memory_command == "sweep":
            return service.memory_sweep(limit=args.limit, apply=args.apply)
        if args.memory_command == "graph":
            if not args.rule_id:
                raise ValueError("memory graph requires record_id")
            return service.memory_graph(args.rule_id, max_hops=args.max_hops, limit=args.limit)
        if args.memory_command == "sleep":
            return service.memory_sleep(apply=args.apply, limit=args.limit)
        if args.memory_command == "prefetch":
            task = args.task or args.rule_id
            if not task:
                raise ValueError("memory prefetch requires --task or task text")
            return service.nextgen_prefetch_memory(
                args.session_id,
                task,
                current_paths=args.memory_paths,
                top_k=args.top_k,
            )
        if args.memory_command == "promote":
            if not args.rule_id or not args.validator:
                raise ValueError("memory promote requires record_id and --validator")
            return service.memory_promote(args.rule_id, args.validator, actor=args.approved_by)
        if args.memory_command == "review":
            return service.memory_review(args.status)
        if args.memory_command == "consolidate":
            if not args.rule_id or not args.with_candidate:
                raise ValueError("memory consolidate requires record_id --with other_record_id")
            return service.memory_consolidate([args.rule_id, args.with_candidate], args.recent)
        if args.memory_command == "reflect":
            return service.memory_reflect(args.session_id or args.rule_id, args.recent)
        if args.memory_command == "utilization":
            if not args.rule_id:
                raise ValueError("memory utilization requires pack_id")
            return service.memory_utilization(args.rule_id)
        if args.memory_command == "enforce":
            if not args.rule_id:
                raise ValueError("memory enforce requires record_id")
            return service.memory_enforce(
                args.rule_id,
                level=args.level,
                severity=args.severity,
                scope=args.memory_paths,
                anti_patterns=args.anti_patterns,
                required_patterns=args.required_patterns,
                remediation=args.remediation,
                rationale=args.rationale,
                approve=args.approve,
                approved_by=args.approved_by,
            )
        if args.memory_command == "enforcements":
            return service.memory_enforcements(
                status=args.status,
                paths=args.memory_paths,
            )
        if args.memory_command == "unenforce":
            if not args.rule_id:
                raise ValueError("memory unenforce requires directive_id")
            return service.memory_unenforce(
                args.rule_id,
                reason=args.reason,
                actor=args.approved_by,
            )
        if args.memory_command == "propose":
            if not args.rule_id or not args.memory_type:
                raise ValueError("memory propose requires --type and assertion")
            return service.memory_propose(
                args.memory_type[0],
                args.rule_id,
                source_kind=args.source_kind,
                confidence=args.confidence,
            )
    if args.command == "continuation":
        if args.continuation_command == "list":
            return service.continuation_list(args.status, args.limit)
        if args.continuation_command == "show":
            if not args.continuation_arg:
                raise ValueError("continuation show requires continuation_id")
            return service.continuation_show(args.continuation_arg)
        if args.continuation_command == "update":
            if not args.continuation_arg:
                raise ValueError("continuation update requires continuation_id")
            return service.continuation_update(
                args.continuation_arg,
                state=args.state,
                next_action=args.next_action,
                blockers=args.continuation_blockers or None,
                reason=args.reason,
            )
        if args.continuation_command == "resume":
            task = args.task or args.continuation_arg
            if not task:
                raise ValueError("continuation resume requires --task")
            return service.continuation_resume(task, args.limit)
        if args.continuation_command == "abandon":
            if not args.continuation_arg:
                raise ValueError("continuation abandon requires continuation_id")
            return service.continuation_abandon(args.continuation_arg, args.reason)
    if args.command == "session":
        if args.session_command == "start":
            task = args.task or args.session_arg
            if not task:
                raise ValueError("session start requires --task")
            return service.session_start(task, args.agent)
        if args.session_command == "event":
            session_id = args.session_id or args.session_arg
            if not session_id or not args.event_type:
                raise ValueError("session event requires session_id and --type")
            return service.session_event(session_id, args.event_type, json.loads(args.payload))
        if args.session_command == "finish":
            session_id = args.session_id or args.session_arg
            if not session_id:
                raise ValueError("session finish requires session_id")
            return service.session_finish(session_id, args.result)
        if args.session_command == "explain":
            session_id = args.session_id or args.session_arg
            if not session_id:
                raise ValueError("session explain requires session_id")
            return service.session_explain(session_id)
        if args.session_command == "leases":
            return service.session_leases(status=args.status or None)
        if args.session_command == "declare-impact":
            session_id = args.session_id or args.session_arg
            if not session_id:
                raise ValueError("session declare-impact requires session_id")
            return service.session_declare_impact(session_id, args.session_paths)
        if args.session_command == "conflicts":
            return service.session_conflicts(status=args.status or None)
        if args.session_command in {"ack", "resolve"}:
            if not args.session_arg:
                raise ValueError(f"session {args.session_command} requires conflict_id")
            status = "acknowledged" if args.session_command == "ack" else "resolved"
            return service.session_conflict_update(args.session_arg, status)
    if args.command == "loop":
        if args.loop_command == "runbook":
            return service.loop_runbook(
                args.task,
                args.loop_paths,
                tests=args.loop_tests,
                result=args.result,
            )
    if args.command == "runtime":
        if args.runtime_command == "ingest":
            if not args.runtime_source:
                raise ValueError("runtime ingest requires source")
            return service.runtime_ingest(args.runtime_source, args.runtime_path)
        if args.runtime_command == "link-errors":
            return service.runtime_link_errors()
        if args.runtime_command == "candidates":
            return service.runtime_candidates()
        if args.runtime_command == "start":
            if not args.task or not args.task_session_id:
                raise ValueError("runtime start requires --task and --task-session-id")
            return service.teacher_runtime_start(
                args.task_session_id,
                args.task,
                pack_id=args.pack_id,
                agent_session_id=args.agent_session_id,
            )
        if args.runtime_command == "status":
            return service.teacher_runtime_status(
                run_id=args.run_id, task_session_id=args.task_session_id
            )
        if args.runtime_command == "obligations":
            if not args.run_id:
                raise ValueError("runtime obligations requires --run-id")
            return service.teacher_runtime_obligations(args.run_id, args.status)
        if args.runtime_command == "resolve":
            if not args.obligation_id or not args.evidence:
                raise ValueError("runtime resolve requires --obligation-id and --evidence")
            return service.teacher_runtime_resolve(args.obligation_id, args.evidence, args.actor)
        if args.runtime_command == "events":
            if not args.run_id:
                raise ValueError("runtime events requires --run-id")
            return service.teacher_runtime_events(args.run_id)
    if args.command == "teach":
        task_session_id = args.task_session_id or args.teach_arg
        if args.teach_command == "event":
            if not args.teach_type or not args.summary:
                raise ValueError("teach event requires --type and --summary")
            return service.teach_event(
                args.teach_type,
                args.source,
                args.summary,
                task_session_id=task_session_id,
                privacy_class=args.privacy_class,
            )
        if not task_session_id:
            raise ValueError(f"teach {args.teach_command} requires --task-session-id")
        if args.teach_command == "brief":
            return service.teach_brief(task_session_id)
        if args.teach_command == "coach":
            return service.teach_coach(task_session_id, json.loads(args.payload))
        if args.teach_command == "exam":
            return service.teach_exam(task_session_id, json.loads(args.payload))
        if args.teach_command == "reflection":
            return service.teach_reflection(task_session_id, json.loads(args.payload))
        if args.teach_command == "directives":
            raise ValueError(
                "teach directives is not implemented by the current teaching service"
            )
    if args.command == "lesson":
        if args.lesson_command == "list":
            return service.lesson_list(args.status)
        if args.lesson_command == "candidate":
            if not args.summary:
                raise ValueError("lesson candidate requires --summary")
            return service.lesson_candidate(
                args.summary, rule_text=args.rule, lesson_type=args.lesson_type, scope=args.scope
            )
        if not args.lesson_id:
            raise ValueError(f"lesson {args.lesson_command} requires lesson_id")
        if args.lesson_command == "show":
            return service.lesson_show(args.lesson_id)
        return service.lesson_decide(
            args.lesson_id, args.lesson_command, args.actor, args.rationale
        )
    if args.command == "student":
        if args.student_command == "profile":
            return service.student_profile(args.agent_kind)
        if args.student_command == "mastery":
            if not args.student_arg:
                raise ValueError("student mastery requires a skill key")
            return service.student_mastery(
                args.student_arg, args.success, args.evidence[0] if args.evidence else None
            )
        if args.student_command == "autonomy-propose":
            if not args.student_arg:
                raise ValueError("student autonomy-propose requires an autonomy level")
            return service.student_autonomy_propose(args.student_arg, args.actor, args.evidence)
        if not args.student_arg or not args.decision:
            raise ValueError("student autonomy-decide requires decision id and --decision")
        return service.student_autonomy_decide(
            args.student_arg,
            args.decision,
            args.actor,
            benchmark_ref=args.benchmark_ref,
            rollback_ref=args.rollback_ref,
        )
    if args.command == "curriculum":
        return service.curriculum_recommend(args.task_session_id, args.objective)
    if args.command == "graph":
        if args.graph_command == "status":
            return service.graph_status(args.branch)
        if args.graph_command == "update":
            return service.graph_update(
                args.graph_paths, branch=args.branch, deleted_paths=args.deleted_path
            )
        if args.graph_command == "stale-check":
            graph_status = service.graph_status(args.branch)
            if args.reason and graph_status.get("graph_version_id"):
                living_graph = cast(Any, service).living_graph
                return living_graph.mark_stale(graph_status["graph_version_id"], args.reason)
            return {
                "schema_version": "persistmind.graph_stale_check.v1",
                "stale": graph_status.get("freshness") == "stale",
                "graph": graph_status,
            }
        if args.graph_command == "query":
            return service.graph_query(
                args.query,
                graph_version_id=args.graph_version_id,
                node_type=args.graph_node_type,
                limit=args.limit,
                budget_ms=args.budget_ms,
            )
        if args.graph_command in {"node", "neighbors", "provenance"}:
            if not args.graph_arg:
                raise ValueError(f"graph {args.graph_command} requires node_id")
            if args.graph_command == "node":
                return service.graph_node(args.graph_arg, args.graph_version_id)
            if args.graph_command == "neighbors":
                return service.living_graph_neighbors(
                    args.graph_arg, graph_version_id=args.graph_version_id, limit=args.limit
                )
            return service.graph_provenance(args.graph_arg, args.graph_version_id)
        if args.graph_command == "validate":
            return service.graph_validate(args.graph_version_id)
        if args.graph_command == "fork":
            source = args.source_version_id or args.graph_version_id
            if not source or not args.branch:
                raise ValueError("graph fork requires --source-version-id and --branch")
            return service.graph_fork(source, args.branch)
        if args.graph_command == "merge-review":
            if not args.source_version_id or not args.target_version_id:
                raise ValueError("graph merge-review requires source and target version ids")
            return service.graph_merge_review(args.source_version_id, args.target_version_id)
        if not args.graph_arg or not args.decision:
            raise ValueError("graph merge-decide requires review id and --decision")
        return service.graph_merge_decide(args.graph_arg, args.decision, args.reviewer)
    if args.command == "teacher-review":
        if args.review_command == "list":
            return service.teacher_review_list(args.status)
        if args.review_command == "request":
            if not args.item_type or not args.item_id:
                raise ValueError("teacher-review request requires --item-type and --item-id")
            return service.teacher_review_request(
                args.item_type, args.item_id, args.actor, risk=args.risk
            )
        if args.review_command == "decide":
            if not args.review_arg or not args.decision:
                raise ValueError("teacher-review decide requires review id and --decision")
            return service.teacher_review_decide(
                args.review_arg, args.decision, args.actor, args.role, args.rationale
            )
        if args.review_command == "export":
            return service.team_lesson_export(args.lesson_id, args.scope, args.actor)
        if args.review_command == "import-decide":
            if not args.review_arg or not args.decision:
                raise ValueError("teacher-review import-decide requires import id and --decision")
            return service.team_lesson_import_decide(
                args.review_arg, args.decision, args.actor, args.role
            )
        if not args.file:
            raise ValueError("teacher-review import requires --file")
        return service.team_lesson_import(
            args.source, json.loads(Path(args.file).read_text(encoding="utf-8"))
        )
    if args.command == "orchestrator":
        if args.orchestrator_command == "create":
            if not args.task_session_id or not args.objective or not args.file:
                raise ValueError("orchestrator create requires task session, objective, and --file")
            body = json.loads(Path(args.file).read_text(encoding="utf-8"))
            return service.orchestration_create(
                args.task_session_id,
                args.objective,
                body.get("tasks", []),
                dependencies=body.get("dependencies", []),
                strategy=body.get("strategy", "parallel"),
                budget=body.get("budget", {}),
            )
        if args.orchestrator_command == "status":
            if not args.orchestrator_arg:
                raise ValueError("orchestrator status requires orchestration id")
            return service.orchestration_status(args.orchestrator_arg)
        if args.orchestrator_command == "checkpoint":
            if not args.orchestrator_arg:
                raise ValueError("orchestrator checkpoint requires orchestration id")
            return service.orchestration_checkpoint(
                args.orchestrator_arg,
                role_id=args.role_id,
                changed_files=args.changed_file,
                tests=args.test,
                blockers=args.blocker,
            )
        if args.orchestrator_command == "output":
            if not args.orchestrator_arg or not args.orchestrator_type:
                raise ValueError("orchestrator output requires orchestration id and --type")
            return service.orchestration_output(
                args.orchestrator_arg,
                args.orchestrator_type,
                json.loads(args.payload),
                role_id=args.role_id,
            )
        if args.orchestrator_command == "task":
            if not args.orchestrator_arg or not args.action:
                raise ValueError("orchestrator task requires task id and --action")
            return service.orchestration_transition(args.orchestrator_arg, args.action)
        if args.orchestrator_command == "child-start":
            if not args.orchestrator_arg:
                raise ValueError("orchestrator child-start requires orchestration task id")
            return service.orchestration_child_start(args.orchestrator_arg)
        if args.orchestrator_command == "child-stop":
            if not args.child_session_id or not args.summary:
                raise ValueError(
                    "orchestrator child-stop requires --child-session-id and --summary"
                )
            return service.orchestration_child_stop(
                args.child_session_id,
                args.summary,
                changed_files=args.changed_file,
                tests_run=args.test,
                blockers=args.blocker,
            )
        if not args.orchestrator_arg or not args.output_id or not args.decision:
            raise ValueError(
                "orchestrator integrate requires orchestration id, output id, and decision"
            )
        return service.orchestration_integrate(
            args.orchestrator_arg,
            args.output_id,
            args.decision,
            args.actor,
            rationale=args.rationale,
            verifier_status=args.verifier_status,
        )
    if args.command == "teacher-bench":
        if args.teacher_bench_command == "suite-create":
            if not args.name or not args.file:
                raise ValueError("teacher-bench suite-create requires --name and --file")
            tasks = json.loads(Path(args.file).read_text(encoding="utf-8"))
            return service.teacher_benchmark_suite_create(
                args.name, args.suite_version, args.purpose, tasks
            )
        if args.teacher_bench_command == "suite-show":
            return cast(Any, service).teacher_bench.suite_show(args.teacher_bench_arg)
        if args.teacher_bench_command == "run-start":
            return service.teacher_benchmark_run_start(
                args.teacher_bench_arg, baseline_run_id=args.baseline_run_id
            )
        if args.teacher_bench_command == "metric":
            if not args.teacher_bench_arg or not args.metric or args.value is None:
                raise ValueError("teacher-bench metric requires run id, --metric, and --value")
            return service.teacher_benchmark_metric(
                args.teacher_bench_arg, args.metric, args.value, args.unit
            )
        if args.teacher_bench_command == "finish":
            return service.teacher_benchmark_finish(args.teacher_bench_arg, status=args.status)
        if args.teacher_bench_command == "resume":
            return service.teacher_benchmark_resume(args.teacher_bench_arg)
        if args.teacher_bench_command == "compare":
            if not args.baseline_run_id or not args.candidate_run_id:
                raise ValueError("teacher-bench compare requires baseline and candidate run ids")
            return service.teacher_benchmark_compare(
                args.baseline_run_id, args.candidate_run_id, json.loads(args.thresholds)
            )
        if args.teacher_bench_command == "waive":
            if not args.teacher_bench_arg or not args.expires_at:
                raise ValueError("teacher-bench waive requires regression id and --expires-at")
            return service.teacher_benchmark_waive(
                args.teacher_bench_arg,
                args.actor,
                args.reason,
                args.expires_at,
            )
        if args.teacher_bench_command == "release-gate":
            if not args.teacher_bench_arg:
                raise ValueError("teacher-bench release-gate requires suite id")
            return service.teacher_release_gate(args.teacher_bench_arg)
        if not args.claim or not args.candidate_run_id:
            raise ValueError("teacher-bench claim requires --claim and --candidate-run-id")
        return service.teacher_claim_evaluate(
            args.claim, args.candidate_run_id, baseline_run_id=args.baseline_run_id
        )
    if args.command == "org":
        if args.org_command == "connector":
            action = args.org_arg or "list"
            if action == "add":
                if not args.org_arg2:
                    raise ValueError("org connector add requires a connector kind")
                config = {}
                if args.config:
                    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
                return service.org_connector_add(
                    args.org_arg2,
                    config=config,
                    display_name=args.display_name,
                    secret_ref=args.secret_ref,
                    access_scope=args.scope,
                    remote_enabled=args.remote,
                )
            if action == "list":
                return service.org_connectors()
            raise ValueError(f"unknown org connector action: {action}")
        if args.org_command == "ingest":
            if not args.org_arg:
                raise ValueError("org ingest requires a connector kind or id")
            return service.org_ingest(
                args.org_arg,
                since=args.since,
                path=args.path,
                remote=args.remote,
                actor=args.actor,
            )
        if args.org_command == "candidates":
            return service.org_candidates(
                status=args.status,
                source=args.source,
                scope=None if args.scope == "restricted" else args.scope,
                actor=args.actor,
                limit=args.limit,
            )
        if args.org_command == "approve":
            if not args.org_arg:
                raise ValueError("org approve requires candidate_id")
            return service.org_approve(args.org_arg, actor=args.actor, supersede=args.supersede)
        if args.org_command == "reject":
            if not args.org_arg:
                raise ValueError("org reject requires candidate_id")
            return service.org_reject(args.org_arg, actor=args.actor, reason=args.reason)
        if args.org_command == "audit":
            if not args.org_arg:
                raise ValueError("org audit requires candidate_id")
            return service.org_audit(args.org_arg)
    if args.command == "decision":
        if args.decision_command == "start":
            if not args.question:
                raise ValueError("decision start requires --question")
            return service.decision_start(
                args.question,
                options=args.decision_options,
                seed_paths=args.decision_seed_paths,
            )
        if args.decision_command == "analyze":
            if not args.decision_id:
                raise ValueError("decision analyze requires decision_id")
            return service.decision_analyze(args.decision_id)
        if args.decision_command == "record":
            if not args.decision_id:
                raise ValueError("decision record requires decision_id")
            if not args.chosen_option_id:
                raise ValueError("decision record requires --chosen")
            if not args.rationale:
                raise ValueError("decision record requires --rationale")
            return service.decision_record(
                args.decision_id,
                chosen_option_id=args.chosen_option_id,
                rationale=args.rationale,
                actor=args.actor,
            )
        if args.decision_command == "show":
            if not args.decision_id:
                raise ValueError("decision show requires decision_id")
            return service.decision_show(args.decision_id)
        if args.decision_command == "list":
            return service.decision_list(status=args.status, limit=args.limit)
    if args.command == "dashboard":
        if args.dashboard_command == "data":
            return service.dashboard_data()
        if args.dashboard_command == "render":
            return service.dashboard_render(args.output)
    if args.command == "capability":
        if args.capability_command == "claims":
            if not args.check:
                raise ValueError("capability claims requires --check")
            return service.capability_claims_check(args.claim)
        result = service.capability_matrix(args.format)
        if args.output:
            content = (
                result["rendered"]
                if args.format == "markdown"
                else json.dumps(result, indent=2, sort_keys=True) + "\n"
            )
            Path(args.output).write_text(content, encoding="utf-8")
            result["output"] = args.output
        return result
    if args.command == "rollup":
        return service.metrics_rollup(
            label=args.label,
            limit=args.limit,
            output=args.output,
        )
    if args.command == "registry":
        if args.registry_command == "register":
            return service.registry_register(label=args.label, action=args.action)
        if args.registry_command == "list":
            return service.registry_list()
        if args.registry_command == "remove":
            return service.registry_remove(args.path)
        if args.registry_command == "prune":
            return service.registry_prune()
        if args.registry_command == "health":
            return service.registry_health(
                include_temp=args.include_temp,
                path_root=args.path_root,
                include_rollup=args.include_rollup,
                output=args.output,
            )
    if args.command == "semantic":
        if args.semantic_command == "index":
            return service.semantic_index()
        if args.semantic_command == "search":
            if not args.semantic_arg:
                raise ValueError("semantic search requires a query")
            return service.semantic_search(args.semantic_arg, args.limit)
        if args.semantic_command == "repo-search":
            if not args.semantic_arg:
                raise ValueError("semantic repo-search requires a query")
            return service.search_repo(args.semantic_arg, max_hops=args.max_hops, limit=args.limit)
        if args.semantic_command == "explain":
            if not args.semantic_arg:
                raise ValueError("semantic explain requires a node_id")
            return service.semantic_explain(args.semantic_arg)
        if args.semantic_command == "graph":
            path = args.path or args.semantic_arg
            if not path:
                raise ValueError("semantic graph requires --path or path argument")
            return service.semantic_graph_for_path(path)
        if args.semantic_command == "list":
            return service.semantic_list()
        if args.semantic_command == "stats":
            return service.graph_stats()
        if args.semantic_command == "accuracy-eval":
            return service.semantic_accuracy_eval(args.fixtures)
        if args.semantic_command == "low-confidence":
            return service.semantic_low_confidence(args.threshold)
        if args.semantic_command == "repair":
            action = args.semantic_arg or "list"
            if action == "list":
                return service.semantic_repair_list(status=args.status, limit=args.limit)
            finding_id = args.finding_id
            if not finding_id:
                raise ValueError("semantic repair confirm/reject requires --finding-id")
            if action == "confirm":
                return service.semantic_repair_confirm(finding_id, rationale=args.rationale)
            if action == "reject":
                return service.semantic_repair_reject(finding_id, rationale=args.rationale)
            raise ValueError("semantic repair action must be list, confirm, or reject")
    if args.command == "architecture":
        if args.architecture_command in {"infer", "map"}:
            return service.architecture_infer()
        if args.architecture_command == "explain":
            service_name = args.service or args.architecture_arg
            if not service_name:
                raise ValueError("architecture explain requires --service")
            return service.architecture_explain(service_name)
        if args.architecture_command == "drift":
            result = service.architecture_drift(strict=args.strict)
            if args.strict and result.get("status") == "fail":
                raise SystemExit(json.dumps(result, indent=2, sort_keys=True))
            return result
        if args.architecture_command == "critical-paths":
            return service.architecture_critical_paths()
    if args.command == "behavior":
        diff = normalize_diff_input(sys.stdin.read()) if args.diff_from_stdin else None
        return service.behavior_check(
            args.behavior_paths,
            diff=diff,
            pack_id=args.pack_id,
        )
    if args.command == "verify":
        if not args.verify_commands:
            raise ValueError("verify run requires at least one --command")
        return service.verify_run(
            args.verify_commands,
            pack_id=args.pack_id,
            plan_id=args.plan_id,
            name=args.name,
            retry_budget=args.retry_budget,
            timeout=args.timeout,
        )
    if args.command == "nextgen":
        if args.nextgen_command == "status":
            return service.nextgen_status()
        if args.nextgen_command == "scorecard":
            return service.nextgen_scorecard()
        if args.nextgen_command == "security-scan":
            return service.nextgen_security_scan(
                text=args.text,
                source=args.source,
            )
        if args.nextgen_command == "drift":
            return service.nextgen_drift(
                specs=args.spec,
                paths=args.nextgen_paths,
            )
    if args.command == "agent":
        return service.agent_route(
            args.task,
            risk_score=args.risk_score,
            capabilities=args.agent_capabilities,
            remote_review_enabled=args.remote_review,
        )
    if args.command == "migrate":
        migrated = service.migrate_project(dry_run=bool(args.dry_run))
        if args.verify and migrated.get("ok"):
            migrated["verification"] = service.migrate_verify()
            migrated["ok"] = bool(migrated["verification"].get("ok"))
        return migrated
    if args.command == "workflow":
        if args.workflow_command == "lint":
            return service.workflow_lint()
        if args.workflow_command == "rebind":
            if not args.task_session_id or not args.pack_id:
                raise ValueError("workflow rebind requires --task-session-id and --pack-id")
            return service.rebind_task_pack(
                task_session_id=args.task_session_id, pack_id=args.pack_id
            )
        if args.workflow_command in {"recommend", "start"} and not args.task:
            raise ValueError(f"workflow {args.workflow_command} requires --task")
        if args.workflow_command == "brief" and not (args.task or args.task_session_id):
            raise ValueError("workflow brief requires --task or --task-session-id")
        workflow_mode = "write" if args.mode == "auto" else args.mode
        if args.workflow_command == "brief":
            return service.workflow_brief(
                args.task,
                mode=args.mode,
                paths=args.workflow_paths,
                task_session_id=args.task_session_id,
            )
        if args.workflow_command == "recommend":
            return service.workflow_recommend(
                args.task,
                mode=workflow_mode,
                paths=args.workflow_paths,
                capabilities=args.workflow_capabilities,
                intent_id=args.intent_id,
                goal_id=args.goal_id,
            )
        if args.workflow_command == "start":
            return service.workflow_start(
                args.task,
                mode=workflow_mode,
                paths=args.workflow_paths,
                capabilities=args.workflow_capabilities,
                intent_id=args.intent_id,
                goal_id=args.goal_id,
            )
        if not args.task_session_id:
            raise ValueError("workflow next requires --task-session-id")
        return service.workflow_next(task_session_id=args.task_session_id)
    if args.command == "codex":
        if args.codex_command == "preflight":
            if not args.task:
                raise ValueError("codex preflight requires --task")
            return service.codex_preflight(
                args.task,
                paths=args.codex_paths,
                mode=args.mode,
                probe=args.probe or args.fast,
                task_session_id=args.task_session_id,
            )
        if args.codex_command == "enforcement-status":
            return service.codex_enforcement_status(probe=args.probe, self_test=args.self_test)
        if args.codex_command == "parallel-plan":
            if not args.task_session_id or not args.pack_id:
                raise ValueError("codex parallel-plan requires --task-session-id and --pack-id")
            return service.codex_parallel_plan(
                args.task_session_id,
                args.pack_id,
                paths=args.codex_paths,
            )
        if args.codex_command == "child-start":
            if not args.task_session_id or not args.objective:
                raise ValueError("codex child-start requires --task-session-id and --objective")
            return service.codex_child_start(
                args.task_session_id,
                args.role,
                args.objective,
                write_scope=args.write_scope,
                read_scope=args.read_scope,
                parent_pack_id=args.pack_id,
            )
        if args.codex_command == "child-stop":
            if not args.child_agent_session_id:
                raise ValueError("codex child-stop requires --child-agent-session-id")
            return service.codex_child_stop(
                args.child_agent_session_id,
                args.summary_text,
                changed_files=args.changed_file,
                tests_run=args.test_run,
                blockers=args.blocker,
            )
        if args.codex_command == "child-pack":
            if not args.pack_id:
                raise ValueError("codex child-pack requires --pack-id")
            return service.codex_child_pack(args.pack_id, args.role, scope=args.codex_paths)
        if args.codex_command == "merge-parallel-results":
            if not args.parallel_run_id:
                raise ValueError("codex merge-parallel-results requires --parallel-run-id")
            return service.codex_merge_parallel_results(args.parallel_run_id)
        if args.codex_command == "install-surfaces":
            return service.codex_install_surfaces(
                mcp_command=args.mcp_command,
                install_hooks=args.install_hooks,
                configure_mcp=args.configure_mcp,
                init_git=args.init_git,
                absolute_mcp_repo=args.absolute_mcp_repo,
                codex_config=args.codex_config,
                skip_index=args.skip_index,
                runtime=_runtime_invocation_from_args(args),
            )
        if args.codex_command == "hook":
            if not args.event:
                raise ValueError("codex hook requires --event")
            return service.codex_hook_event(args.event, json.loads(args.payload or "{}"))
    if args.command == "governance":
        if args.governance_command == "status":
            return service.governance_status()
        if args.governance_command == "propose":
            return service.governance_propose(min_samples=args.min_samples)
        if args.governance_command == "list":
            return service.governance_list(status=args.status)
        if args.governance_command in {
            "show",
            "preview",
            "preview-adoption",
            "adopt",
            "reject",
        }:
            if not args.proposal_id:
                raise ValueError(f"governance {args.governance_command} requires --proposal-id")
            if args.governance_command == "show":
                return service.governance_show(args.proposal_id)
            if args.governance_command in {"preview", "preview-adoption"}:
                return service.governance_preview_adoption(args.proposal_id)
            if args.governance_command == "adopt":
                return service.governance_adopt(
                    args.proposal_id,
                    actor=args.approved_by or args.actor,
                    reason=args.rationale or args.reason,
                )
            return service.governance_reject(args.proposal_id, reason=args.rationale or args.reason)
        if not args.adoption_id:
            raise ValueError("governance rollback requires --adoption-id")
        return service.governance_rollback(args.adoption_id, reason=args.rationale or args.reason)
    if args.command == "provider":
        return service.provider_status()
    if args.command == "metacog":
        return service.metacog_state(
            args.task,
            paths=args.metacog_paths,
            task_session_id=args.task_session_id,
        )
    if args.command == "clarify":
        if args.clarify_command == "list":
            return service.clarify_list(
                task_session_id=args.task_session_id,
                status=args.status,
                limit=args.limit,
            )
        if args.clarify_command == "open":
            if not args.question:
                raise ValueError("clarify open requires --question")
            return service.clarify_open(
                args.question,
                task_session_id=args.task_session_id,
                pack_id=args.pack_id,
            )
        if not args.clarify_arg:
            raise ValueError(f"clarify {args.clarify_command} requires request_id")
        if args.clarify_command == "answer":
            if not args.answer:
                raise ValueError("clarify answer requires --answer")
            return service.clarify_answer(args.clarify_arg, args.answer)
        return service.clarify_withdraw(args.clarify_arg, reason=args.reason)
    if args.command == "judgment":
        if args.judgment_command == "status":
            return service.judgment_status()
        if args.judgment_command == "propose":
            return service.judgment_propose()
        if args.judgment_command == "list":
            return service.judgment_list(status=args.status)
        if not args.judgment_id:
            raise ValueError(f"judgment {args.judgment_command} requires heuristic_id")
        if args.judgment_command == "adopt":
            return service.judgment_adopt(args.judgment_id, actor=args.actor, reason=args.reason)
        if args.judgment_command == "reject":
            return service.judgment_reject(args.judgment_id, reason=args.reason)
        return service.judgment_rollback(args.judgment_id, reason=args.reason)
    if args.command == "narrative":
        return service.narrative_show()
    raise ValueError(f"unknown command: {args.command}")


def _prompt_setup_agents() -> str:
    names = known_agent_names()
    if not sys.stdin.isatty():
        raise ValueError(
            "setup requires --agents, a setup target, or auto when stdin is not interactive"
        )
    print("Select PersistMind agents to configure:", file=sys.stderr)
    for index, name in enumerate(names, start=1):
        print(f"  {index}. {name}", file=sys.stderr)
    raw = input("Agents (comma names or numbers): ").strip()
    if not raw:
        raise ValueError("no agents selected")
    selected: list[str] = []
    for part in raw.replace(",", " ").split():
        if part.isdigit():
            idx = int(part)
            if idx < 1 or idx > len(names):
                raise ValueError(f"agent selection out of range: {part}")
            selected.append(names[idx - 1])
        else:
            selected.append(part)
    return ",".join(selected)


def _add_runtime_invocation_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--runtime-executable", help=argparse.SUPPRESS)
    parser.add_argument(
        "--runtime-prefix-arg",
        action="append",
        default=None,
        help=argparse.SUPPRESS,
    )
    parser.add_argument("--runtime-source", help=argparse.SUPPRESS)


def _runtime_invocation_from_args(
    args: argparse.Namespace,
) -> RuntimeInvocation | None:
    executable = getattr(args, "runtime_executable", None)
    prefix_args = getattr(args, "runtime_prefix_arg", None)
    source = getattr(args, "runtime_source", None)
    if executable is None and prefix_args is None and source is None:
        return None
    from persistmind.runtime_invocation import runtime_invocation

    return runtime_invocation(
        executable=executable,
        prefix_args=prefix_args,
        source=source,
    )


def _dispatch_install(args: argparse.Namespace) -> dict[str, Any]:
    from persistmind.agents.adapters import detect_running
    from persistmind.installer import InstallOptions, install_project

    agents = args.agents
    if args.auto_agent:
        detected = detect_running(os.environ)
        if not detected:
            raise ValueError("no supported running coding agent was detected")
        agents = ",".join(adapter.name for adapter in detected)
    if not agents:
        agents = _prompt_setup_agents()
    options = InstallOptions(
        agents=tuple(item.strip() for item in agents.split(",") if item.strip()),
        mcp_command=args.mcp_command,
        runtime_invocation=_runtime_invocation_from_args(args),
        install_hooks=bool(args.install_hooks),
        configure_mcp=bool(args.configure_mcp),
        init_git=bool(args.init_git),
        absolute_mcp_repo=bool(args.absolute_mcp_repo),
        codex_config=args.codex_config,
        skip_index=bool(args.skip_index),
    )
    return install_project(Path(args.repo), options)


def _dispatch_setup(args: argparse.Namespace) -> dict[str, Any]:
    from persistmind.agents.adapters import known_agent_names
    from persistmind.application.setup_service import SetupService

    service = SetupService(Path(args.repo))
    options = {
        "mcp_command": args.mcp_command,
        "install_hooks": bool(args.install_hooks),
        "configure_mcp": bool(args.configure_mcp),
        "init_git": bool(args.init_git),
        "absolute_mcp_repo": bool(args.absolute_mcp_repo),
        "codex_config": args.codex_config,
        "skip_index": bool(args.skip_index),
        "runtime": _runtime_invocation_from_args(args),
    }
    if args.setup_command == "auto":
        return service.setup_auto(**options)
    agents = args.agents
    if args.setup_command:
        known = set(known_agent_names())
        if args.setup_command not in known:
            raise ValueError(
                f"unknown setup target '{args.setup_command}' "
                f"(known: auto, {', '.join(sorted(known))})"
            )
        agents = f"{agents},{args.setup_command}" if agents else args.setup_command
    if not agents:
        agents = _prompt_setup_agents()
    return service.setup(
        [item.strip() for item in agents.split(",") if item.strip()],
        **options,
    )


def _dispatch_quickstart(args: argparse.Namespace, service: OperationClient) -> dict[str, Any]:
    from persistmind.application.setup_service import SetupService

    agents = [item.strip() for item in str(args.agents or "codex").split(",") if item.strip()]
    if not agents:
        raise CliInputError("quickstart requires at least one agent", remediation="Pass --agents codex")
    repo = Path(args.repo).resolve()
    setup = SetupService(repo).setup(
        agents,
        mcp_command=args.mcp_command,
        install_hooks=bool(args.install_hooks),
        configure_mcp=bool(args.configure_mcp),
        init_git=bool(args.init_git),
        absolute_mcp_repo=bool(args.absolute_mcp_repo),
        codex_config=args.codex_config,
        skip_index=True,
        runtime=_runtime_invocation_from_args(args),
    )
    initialized = service.init()
    indexed = service.refresh_index()
    ok = bool(setup.get("ok")) and bool(initialized.get("ok")) and bool(indexed.get("ok"))
    return {
        "ok": ok,
        "status": "ready" if ok else "incomplete",
        "schema_version": "persistmind.quickstart_result.v1",
        "sequence": ["setup", "init", "index"],
        "setup": setup,
        "init": initialized,
        "index": indexed,
        "remediation": None
        if ok
        else "Inspect the setup, init, and index sections and rerun the failed command.",
    }


def _dispatch_npx(args: argparse.Namespace) -> dict[str, Any]:
    if args.npx_command == "doctor":
        return _npx_doctor_result(Path(__file__).resolve().parents[2])
    if args.npx_command == "update":
        return _npx_update_result(Path(__file__).resolve().parents[2], args.source, args.project)
    raise ValueError(f"unknown npx command: {args.npx_command}")


def _load_plan_arg(
    args: argparse.Namespace, *, allow_positional_json: bool = True
) -> dict[str, Any]:
    if args.plan_file:
        path = Path(args.plan_file)
        try:
            raw = path.read_text(encoding="utf-8-sig")
        except FileNotFoundError as exc:
            raise CliInputError(
                f"plan file does not exist: {path}",
                path=path,
                remediation="Create the plan JSON file or pass an existing path with --file.",
            ) from exc
        except (OSError, UnicodeError) as exc:
            raise CliInputError(
                f"plan file is not readable: {path}: {exc}",
                path=path,
                remediation="Check the path, permissions, and UTF-8 encoding, then retry.",
            ) from exc
        try:
            value = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise CliInputError(
                f"plan file contains invalid JSON at line {exc.lineno}, column {exc.colno}: {path}",
                path=path,
                remediation="Correct the JSON syntax and rerun plan validate or plan create.",
            ) from exc
        if not isinstance(value, dict):
            raise CliInputError(
                f"plan file must contain a JSON object: {path}",
                path=path,
                remediation="Wrap the objective and steps in one JSON object.",
            )
        return value
    if args.plan_json:
        try:
            value = json.loads(args.plan_json)
        except json.JSONDecodeError as exc:
            raise CliInputError(
                f"--json contains invalid plan JSON at column {exc.colno}",
                remediation="Correct the JSON syntax and retry.",
            ) from exc
        if not isinstance(value, dict):
            raise CliInputError("--json must contain a plan JSON object")
        return value
    if allow_positional_json and args.plan_arg:
        try:
            value = json.loads(args.plan_arg)
        except json.JSONDecodeError as exc:
            raise CliInputError(f"positional plan JSON is invalid at column {exc.colno}") from exc
        if not isinstance(value, dict):
            raise CliInputError("positional plan JSON must be an object")
        return value
    raise CliInputError(
        "plan JSON is required via --file or --json",
        remediation="Pass a readable UTF-8 plan file with --file or a JSON object with --json.",
    )


def _memory_query(args: argparse.Namespace) -> str | None:
    """Resolve all documented memory query spellings to one parser contract."""

    value = getattr(args, "memory_query", None) or getattr(args, "task", None) or args.rule_id
    return str(value).strip() if value and str(value).strip() else None


def _summary_result(args: argparse.Namespace, result: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(result, dict):
        return result
    if result.get("ok") is False and args.command not in {"check-diff", "doctor"}:
        finalized = finalize_result(result, operation=str(args.command))
        failure_summary = {
            key: finalized[key]
            for key in (
                "ok",
                "status",
                "interface_status",
                "interface_schema_version",
                *("operation_id", "correlation_id", "task_session_id", "pack_id"),
                "failed_stage",
                "path",
                "error",
                "error_code",
                "remediation",
                "retryable",
                "release_identity",
                "maturity_warning",
            )
            if key in finalized
        }
        diagnostics = finalized.get("diagnostics")
        if not isinstance(diagnostics, list):
            diagnostics = finalized.get("schema_errors")
        validation = finalized.get("validation")
        if not isinstance(diagnostics, list) and isinstance(validation, dict):
            diagnostics = validation.get("schema_errors")
        bounded = diagnostics if isinstance(diagnostics, list) else []
        failure_summary["diagnostic_count"] = len(bounded)
        if bounded:
            failure_summary["diagnostic"] = bounded[0]
            failure_summary["diagnostics"] = bounded
        return failure_summary
    ok = result.get("ok")
    summary: dict[str, Any] = {"ok": bool(ok) if ok is not None else True}
    if args.command == "task" and getattr(args, "task_command", None) == "start":
        for key in ("task_session_id", "agent_session_id", "state"):
            if key in result:
                summary[key] = result[key]
        return summary
    if args.command == "index":
        for key in (
            "snapshot_id",
            "repo_id",
            "base_commit_sha",
            "worktree_state",
            "generation_id",
            "status",
        ):
            if key in result:
                summary[key] = result[key]
        return summary
    if args.command == "doctor":
        for key in (
            "operational",
            "ready_for_work",
            "local_core_ready",
            "local_full_ready",
            "release_ready",
            "setup_complete",
            "setup_status",
            "setup_blocking_missing",
            "setup_advisory_missing",
            "repo",
            "status",
        ):
            if key in result:
                summary[key] = result[key]
        profile_readiness = result.get("profile_readiness")
        if isinstance(profile_readiness, dict):
            summary["local_core_blockers"] = profile_readiness.get("local_core", {}).get(
                "blockers", []
            )
        storage = result.get("storage_report")
        if isinstance(storage, dict):
            summary["storage_warnings"] = storage.get("warnings", [])
        if result.get("remediation"):
            summary["remediation"] = result["remediation"]
        return summary
    if args.command == "pack":
        from persistmind.context_snippets import matched_snippet_previews

        for key in (
            "pack_id",
            "agent_session_id",
            "snapshot_id",
            "base_commit_sha",
            "low_confidence",
        ):
            if key in result:
                summary[key] = result[key]
        summary["item_count"] = len(result.get("items", []) or [])
        summary["matched_snippets"] = matched_snippet_previews(result)
        summary["seed_paths"] = result.get("seed_paths", [])
        if result.get("seed_coverage"):
            coverage = result["seed_coverage"]
            summary["seed_coverage"] = {
                "edit_scope_confidence": coverage.get("edit_scope_confidence"),
                "seeded_paths": coverage.get("seeded_paths", []),
                "selected_seed_paths": coverage.get("selected_seed_paths", []),
                "unselected_seed_paths": coverage.get("unselected_seed_paths", []),
                "unindexed_seed_paths": coverage.get("unindexed_seed_paths", []),
            }
        if result.get("warnings"):
            summary["warnings"] = result["warnings"]
        return summary
    if args.command == "impact":
        risk = result.get("risk", {}) if isinstance(result.get("risk"), dict) else {}
        summary.update(
            {
                "risk_score": risk.get("score"),
                "input_path_count": len(result.get("input_paths", []) or []),
                "analyzed_path_count": len(
                    result.get("analyzed_paths", result.get("input_paths", [])) or []
                ),
                "impacted_path_count": len(result.get("impacted_paths", []) or []),
                "test_count": len(result.get("tests", []) or []),
            }
        )
        if result.get("excluded_paths"):
            summary["excluded_paths"] = result["excluded_paths"]
        if result.get("pack_awareness"):
            pack_awareness = result["pack_awareness"]
            summary["pack_id"] = pack_awareness.get("pack_id")
            summary["out_of_pack_paths"] = pack_awareness.get("out_of_pack_paths", [])
        if result.get("business_exposure"):
            exposure = result["business_exposure"]
            summary["business_exposure"] = {
                "lowest_trust_tier": exposure.get("lowest_trust_tier"),
                "exposure_summary": exposure.get("exposure_summary", {}),
                "authoritative": exposure.get("authoritative"),
                "requires_human_review": exposure.get("requires_human_review"),
            }
        return summary
    if args.command == "check-diff":
        report = (
            result.get("impact_report", {}) if isinstance(result.get("impact_report"), dict) else {}
        )
        risk = report.get("risk", {}) if isinstance(report.get("risk"), dict) else {}
        violations = result.get("violations", []) or []
        summary.update(
            {
                "status": result.get("status"),
                "pack_id": getattr(args, "pack_id", None),
                "violation_count": len(violations),
                "violations": violations[:10],
                "risk_score": risk.get("score"),
            }
        )
        assessment = result.get("scope_assessment")
        if isinstance(assessment, dict) and assessment.get("incomplete_reasons"):
            summary["incomplete_reasons"] = assessment["incomplete_reasons"]
        if report.get("excluded_paths"):
            summary["excluded_paths"] = report["excluded_paths"]
        pack_awareness = report.get("pack_awareness")
        if isinstance(pack_awareness, dict):
            summary["out_of_pack_paths"] = pack_awareness.get("out_of_pack_paths", [])
            summary["uncovered_noncode"] = pack_awareness.get("uncovered_noncode", [])
            summary["planned_new_paths"] = pack_awareness.get("planned_new_paths", [])
        if report.get("remediation"):
            summary["remediation"] = report["remediation"]
        if report.get("performance"):
            summary["performance"] = report["performance"]
        return summary
    if args.command == "codex" and getattr(args, "codex_command", None) == "preflight":
        for key in (
            "probe_only",
            "fast",
            "preflight_ready",
            "setup_ready",
            "task_session_id",
            "agent_session_id",
            "pack_id",
            "memory_retrieval_id",
            "setup_status",
            "ready_for_work",
            "setup_blocking_missing",
            "setup_advisory_missing",
            "required_next_step",
            "performance",
            "matched_snippets",
        ):
            if key in result:
                summary[key] = result[key]
        enforcement = result.get("enforcement_status")
        if isinstance(enforcement, dict):
            summary["enforcement_status"] = {
                "ok": enforcement.get("ok"),
                "status": enforcement.get("status"),
                "blocking_reasons": enforcement.get("blocking_reasons", []),
            }
        return summary
    if args.command == "workflow":
        for key in (
            "schema_version",
            "task_session_id",
            "pack_id",
            "agent_session_id",
            "complete",
            "completed",
            "blocked",
            "memory_recall_count",
            "impact_report_id",
        ):
            if key in result:
                summary[key] = result[key]
        if result.get("remediation"):
            summary["remediation"] = result["remediation"]
        next_action = result.get("next_action")
        if isinstance(next_action, dict):
            summary["next_action"] = {
                "feature_id": next_action.get("feature_id"),
                "gate_id": next_action.get("gate_id"),
                "command": next_action.get("command"),
                "blocked": next_action.get("blocked"),
            }
        gates = result.get("gates")
        if isinstance(gates, dict):
            summary["gates"] = {
                gate_id: status.get("status")
                for gate_id, status in gates.items()
                if isinstance(status, dict)
            }
        return summary
    if args.command == "plan":
        for key in (
            "plan_id",
            "task_session_id",
            "revision_id",
            "revision_number",
            "plan_hash",
            "previous_plan_hash",
            "checkpoint_id",
            "status",
            "step_id",
            "agent_session_id",
        ):
            if key in result:
                summary[key] = result[key]
        validation = (
            result.get("validation", {}) if isinstance(result.get("validation"), dict) else {}
        )
        if validation:
            summary["schema_error_count"] = len(validation.get("schema_errors", []) or [])
            summary["warning_count"] = len(validation.get("warnings", []) or [])
        if result.get("violations"):
            summary["violations"] = result["violations"][:10]
        return summary
    return result


def _should_summarize_result(args: argparse.Namespace) -> bool:
    return bool(getattr(args, "summary", False)) or (
        args.command in {"pack", "plan"} and not bool(getattr(args, "verbose", False))
    )


def _dispatch_storage_control(args: argparse.Namespace) -> dict[str, Any]:
    """Run Control-plane commands before the retired product service exists."""

    if args.storage_command == "recover" and args.recover_command != "catalog":
        from persistmind.composition.recovery_cli import dispatch_storage_recovery

        return dispatch_storage_recovery(Path(args.repo), args)

    from persistmind.storage.control import StorageControlPlane
    from persistmind.storage.resources import load_json

    control = StorageControlPlane(Path(args.repo))
    if args.storage_command == "topology":
        return control.topology()
    if args.storage_command == "status":
        return control.status()
    if args.storage_command == "bootstrap":
        return control.bootstrap()
    if args.storage_command == "resources":
        return control.resources_verify()
    if args.storage_command == "memory-kinds":
        return control.memory_kinds()
    if args.storage_command == "roles":
        return control.roles()
    if args.storage_command == "models":
        if args.models_command == "status":
            return control.models_status()
        if args.source is None:
            raise ValueError("model install requires --source")
        if not args.yes:
            raise PermissionError("model install requires --yes")
        return control.models_install(args.source)
    if args.storage_command == "keys":
        if args.keys_command == "status":
            return control.keys_status()
        if args.keys_command == "rotate":
            if not args.yes:
                raise PermissionError("key rotation requires --yes")
            return control.keys_rotate()
        if args.keys_command == "approval-sign":
            if args.document is None:
                raise ValueError("approval signing requires --document")
            return control.approval_sign(args.document, principal=args.principal)
        if args.keys_command == "recovery-kit-create":
            if args.output is None or not args.yes:
                raise PermissionError("recovery kit creation requires --output and --yes")
            import sys

            if not sys.stderr.isatty():
                raise PermissionError(
                    "recovery passphrase requires a controlling TTY secret display"
                )
            result, passphrase = control.recovery_kit_create(args.output)
            print(f"CTX recovery passphrase (shown once): {passphrase}", file=sys.stderr)
            return result
        if args.kit is None:
            raise ValueError("recovery kit verification requires --kit")
        import getpass

        passphrase = getpass.getpass("CTX recovery passphrase: ")
        return control.recovery_kit_verify(args.kit, passphrase)
    if args.storage_command == "schema":
        if args.schema_command == "status":
            return control.schema_status()
        if args.schema_command == "plan":
            return control.schema_plan(output=args.output)
        if args.plan is None:
            raise ValueError("schema upgrade requires --plan")
        if not args.yes:
            raise PermissionError("schema upgrade requires --yes")
        return control.schema_upgrade(plan_path=args.plan)
    if args.storage_command == "partitions":
        if args.partitions_command == "list":
            return control.partitions()
        if not args.role:
            raise ValueError("partition rotation requires --role")
        if not args.yes:
            raise PermissionError("partition rotation requires --yes")
        if args.role == "audit" and not args.signature:
            raise ValueError("audit partition rotation requires --signature")
        return control.rotate_partition(
            args.role,
            actor=args.actor,
            signature=args.signature,
        )
    if args.storage_command == "repair":
        if not args.dry_run and not args.yes:
            raise PermissionError("storage repair apply requires --yes")
        return control.repair(dry_run=bool(args.dry_run))
    if args.storage_command == "gc":
        if not args.dry_run and not args.yes:
            raise PermissionError("storage gc apply requires --yes")
        return control.gc(dry_run=bool(args.dry_run))
    if args.storage_command == "retention":
        if not args.dry_run and not args.yes:
            raise PermissionError("storage retention apply requires --yes")
        return control.retention(dry_run=bool(args.dry_run), keep_days=args.keep_days)
    if args.storage_command == "export":
        return control.export(args.scope, output=args.output)
    if args.storage_command == "delete":
        if not args.dry_run and not args.yes:
            raise PermissionError("storage delete apply requires --yes")
        return control.delete(args.scope, dry_run=bool(args.dry_run))
    if args.storage_command == "holds":
        if args.holds_command == "create":
            return control.legal_hold_create(args.scope, args.reason)
        if not args.yes:
            raise PermissionError("legal hold release requires --yes")
        return control.legal_hold_release(args.hold)
    if args.storage_command == "inventory":
        document = load_json("authority-inventory.v1.json")
        result = {
            "ok": True,
            "schema_version": "persistmind.storage_inventory.v1",
            "counts": document.get("counts", {}),
            "objects": document.get("objects", []),
        }
        if args.output is not None:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(
                json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
            )
            result["output"] = str(args.output.resolve())
        return result
    if args.storage_command == "verify":
        return control.verify(full=bool(args.full))
    if args.storage_command == "reconcile":
        from persistmind.composition.registry import OperationRegistry

        return OperationRegistry(Path(args.repo)).invoke("storage_reconcile", {"limit": args.limit})
    if args.storage_command == "recover":
        return control.recover_catalog()
    if args.storage_command == "backup":
        if args.backup_command == "create":
            return control.backup_create(verify=bool(args.verify))
        if args.backup_command == "verify":
            return control.backup_verify(args.backup)
        if args.verify_only:
            return control.backup_verify(args.backup)
        if not args.yes:
            raise PermissionError("backup restore requires --yes")
        return control.backup_restore_stage(args.backup, target=args.target)
    raise ValueError(f"unsupported storage command: {args.storage_command}")


def _nextgen_task_is_initialized(repo_root: Path) -> bool:
    """Select the Task port before retired service construction."""

    from persistmind.config import load_settings
    from persistmind.storage.runtime import inspect_storage

    root = repo_root.resolve()
    settings = load_settings(root)
    return inspect_storage(root / settings.toolchain.workspace_dir).initialized


def _dispatch_nextgen_workflow(args: argparse.Namespace, service: Any) -> dict[str, Any]:
    if args.workflow_command == "start":
        if not args.task:
            raise ValueError("workflow start requires --task")
        return service.workflow_start(
            args.task,
            mode="write" if args.mode == "auto" else args.mode,
            paths=args.workflow_paths,
            capabilities=args.workflow_capabilities,
            intent_id=args.intent_id,
            goal_id=args.goal_id,
        )
    if args.workflow_command == "brief":
        return service.workflow_brief(
            args.task,
            paths=args.workflow_paths,
            mode=args.mode,
            task_session_id=args.task_session_id,
        )
    if not args.task_session_id:
        raise ValueError("workflow next requires --task-session-id")
    return service.workflow_next(args.task_session_id)


def _dispatch_nextgen_activity(args: argparse.Namespace, service: Any) -> dict[str, Any]:
    if args.command == "tokens":
        if args.tokens_command == "record":
            return service.token_usage_record(**token_record_request(args))
        return service.token_usage_report(args.task_session_id, limit=args.limit)
    if args.command == "outcome":
        if not args.task_session_id:
            raise ValueError("outcome requires --task-session-id")
        return service.record_outcome(
            args.task_session_id,
            args.result,
            pack_id=args.pack_id,
            files_changed=args.files,
            summary=args.summary,
            episode_eligible=bool(args.episode_eligible),
            evaluation_version_id=args.evaluation_version_id,
        )
    if args.activity_command == "append":
        if not args.activity_type:
            raise ValueError("activity append requires --type")
        return service.append_event(
            args.activity_type,
            json.loads(args.payload),
            idempotency_key=args.idempotency_key,
            occurred_at=args.occurred_at,
            classification=args.classification,
        )
    if args.activity_command == "show":
        if not args.activity_arg:
            raise ValueError("activity show requires event_id")
        return service.activity_event(args.activity_arg, hydrate=bool(args.hydrate))
    if args.activity_command == "rotate":
        return service.rotate_partition()
    return service.activity_events(
        event_type=args.activity_type, since=args.since, limit=args.limit
    )


def _dispatch_nextgen_audit(args: argparse.Namespace, service: Any) -> dict[str, Any]:
    if args.audit_command == "pack-manifest":
        if not args.task_session:
            raise ValueError("audit pack-manifest requires --task-session")
        from persistmind.storage.audit_service import AuditService

        with AuditService(Path(args.repo)) as audit:
            return audit.pack_manifest_evidence(task_session_id=args.task_session)
    if args.audit_command == "verify-hook-log":
        from persistmind.storage.audit_service import AuditService

        with AuditService(Path(args.repo)) as audit:
            return audit.verify_hook_log()
    if args.audit_command == "verify":
        return service.verify_audit()
    if args.audit_command == "tip":
        return service.audit_tip(args.output)
    if args.audit_command == "record":
        if not args.pack_id:
            raise ValueError("--pack-id is required for audit record")
        return service.get_audit_record(args.pack_id)
    if args.audit_command == "gating-baseline":
        return service.record_gating_baseline(actor=args.actor)
    if args.audit_command == "gating-verify":
        return service.audit_gating_verify()
    if not args.signature:
        raise ValueError("audit anchor requires --signature")
    return service.rotate_partition(actor=args.actor, signature=args.signature)


def _dispatch_nextgen_learning(args: argparse.Namespace, service: Any) -> dict[str, Any]:
    from persistmind.application.learning_requests import promotion_cli_kwargs

    command = args.learning_command
    if command == "status":
        return service.learning_status()
    if command == "manifest":
        return service.learning_active_manifest()
    if command == "versions":
        return service.learning_versions(skill_id=args.skill_id, limit=args.limit)
    if command == "show":
        if not args.learning_arg:
            raise ValueError("learning show requires version_id")
        return service.learning_version_show(args.learning_arg)
    if command == "propose":
        if not args.skill_id or not args.benchmark_id:
            raise ValueError("learning propose requires --skill-id and --benchmark-id")
        return service.version_propose(
            skill_id=args.skill_id,
            benchmark_id=args.benchmark_id,
            artifact_ref=args.artifact_ref,
            content=args.content,
            classification=args.classification,
        )
    if command == "evaluate":
        if not args.learning_arg or not args.metrics:
            raise ValueError("learning evaluate requires version_id and --metrics JSON")
        return service.evaluation_record(
            args.learning_arg,
            metrics=json.loads(args.metrics),
            passed=bool(args.passed),
            benchmark_id=args.benchmark_id,
        )
    if command == "promote":
        return service.promote(args.learning_arg, **promotion_cli_kwargs(args))
    if command == "rollback":
        if not args.learning_arg or not args.signature:
            raise ValueError("learning rollback requires version_id and --signature")
        return service.rollback(args.learning_arg, approver=args.actor, signature=args.signature)
    if command == "canary":
        if not args.learning_arg or not args.metrics:
            raise ValueError("learning canary requires version_id and --metrics JSON")
        return service.canary_evaluate(
            args.learning_arg,
            metrics=json.loads(args.metrics),
            minimum_pass_rate=args.minimum_pass_rate,
            maximum_regression=args.maximum_regression,
        )
    if command == "propagate":
        if not args.learning_arg or not args.signature or not args.target_workspace:
            raise ValueError(
                "learning propagate requires version_id, --target-workspace, and --signature"
            )
        return service.propagate(
            args.learning_arg,
            targets=args.target_workspace,
            approver=args.actor,
            signature=args.signature,
        )
    if command in {"archive", "recent", "selfmod-archive"}:
        operation = service.learning_recent if command == "recent" else service.learning_archive
        return operation(target=args.target, limit=args.limit)
    if command == "benchmark-trends":
        return service.learning_benchmark_trends(limit=args.limit)
    if command in {"loop-verify", "optimize"}:
        return service.verify_closure()
    if command in {"adopt", "selfmod-adopt"}:
        return service.promote(args.learning_arg, **promotion_cli_kwargs(args))
    if command in {"revert", "selfmod-revert"}:
        if not args.learning_arg or not args.signature:
            raise ValueError(f"learning {command} requires version_id and --signature")
        return service.rollback(args.learning_arg, approver=args.actor, signature=args.signature)
    if command == "selfmod-propose":
        skill_id = args.skill_id or args.target
        benchmark_id = args.benchmark_id or "selfmod-safety-v1"
        content = args.content or json.dumps(
            {
                "target": args.target,
                "weakness": args.weakness,
                "ancestor_run_id": args.ancestor_run_id,
            },
            sort_keys=True,
        )
        return service.version_propose(
            skill_id=skill_id,
            benchmark_id=benchmark_id,
            content=content,
            classification=args.classification,
        )
    raise ValueError(f"unsupported Learning operation: {command}")


def _dispatch_nextgen_knowledge(args: argparse.Namespace, service: Any) -> dict[str, Any]:
    """Run the currently ported Knowledge/Policy operations without fallback.

    A next-generation catalog intentionally rejects the long tail of legacy memory
    commands.  Routing one of those commands through ``OperationClient`` would
    bypass the declared authority boundary.
    """

    if args.command == "policy":
        if args.policy_command == "approve-business-rule":
            if not args.policy_arg:
                raise ValueError("policy approve-business-rule requires candidate_id")
            if not args.signature:
                raise ValueError("policy approve-business-rule requires --signature")
            return service.policy_approve_business_rule(
                args.policy_arg,
                approver=args.approved_by,
                signature=args.signature,
            )
        return service.policy_applicable(args.scope or args.policy_arg)

    if args.memory_command in {"explain", "explain-rule"}:
        if not args.rule_id:
            raise ValueError("memory explain requires record_id")
        return service.memory_explain(args.rule_id)
    if args.memory_command == "list":
        return service.memory_list(args.status)
    if args.memory_command == "approve":
        if not args.rule_id:
            raise ValueError("memory approve requires record_id")
        return service.memory_approve(args.rule_id, args.approved_by)
    if args.memory_command == "reject":
        if not args.rule_id:
            raise ValueError("memory reject requires record_id")
        return service.memory_reject(args.rule_id, actor=args.approved_by)
    if args.memory_command == "supersede":
        if not args.rule_id or not args.with_candidate:
            raise ValueError("memory supersede requires old_record_id --with new_record_id")
        return service.memory_supersede(args.rule_id, args.with_candidate, args.approved_by)
    if args.memory_command == "conflicts":
        return service.memory_conflicts()
    if args.memory_command == "stale":
        return service.memory_stale()
    if args.memory_command == "verify":
        return service.memory_verify()
    if args.memory_command == "search":
        query = _memory_query(args)
        if not query:
            raise ValueError("memory search requires a query")
        return service.memory_search(query, args.memory_type or None, args.status)
    if args.memory_command == "recall":
        query = _memory_query(args)
        if not query:
            raise ValueError("memory recall requires a query")
        return service.memory_recall(
            query,
            paths=args.memory_paths,
            types=args.memory_type or None,
            limit=args.limit,
            include_org=args.include_org,
        )
    if args.memory_command == "create":
        if args.memory_json:
            payload = json.loads(args.memory_json)
            if args.memory_type and not payload.get("type"):
                payload["type"] = args.memory_type[0]
            if args.rule_id and not payload.get("assertion"):
                payload["assertion"] = args.rule_id
            if args.title and not payload.get("title"):
                payload["title"] = args.title
            if args.source_kind and not payload.get("source_kind"):
                payload["source_kind"] = args.source_kind
            if args.confidence is not None and not payload.get("confidence"):
                payload["confidence"] = args.confidence
            if args.memory_paths and not payload.get("scope_refs"):
                payload["scope_refs"] = args.memory_paths
        else:
            if not args.rule_id or not args.memory_type:
                raise ValueError("memory create requires --type and assertion")
            payload = {
                "type": args.memory_type[0],
                "assertion": args.rule_id,
                "title": args.title,
                "source_kind": args.source_kind,
                "confidence": args.confidence,
                "scope_refs": args.memory_paths,
            }
        return service.memory_create_typed(payload)
    if args.memory_command == "update":
        if not args.rule_id or not args.memory_json:
            raise ValueError("memory update requires record_id and --json patch")
        return service.memory_update(
            args.rule_id,
            json.loads(args.memory_json),
            args.reason,
            actor=args.approved_by,
        )
    if args.memory_command == "validate":
        if not args.rule_id:
            raise ValueError("memory validate requires record_id")
        return service.memory_validate(args.rule_id, args.validator, actor=args.approved_by)
    if args.memory_command == "expire":
        if not args.rule_id:
            raise ValueError("memory expire requires record_id")
        return service.memory_expire(args.rule_id, args.reason, actor=args.approved_by)
    if args.memory_command == "quarantine":
        if not args.rule_id:
            raise ValueError("memory quarantine requires record_id")
        return service.memory_quarantine(
            args.rule_id,
            args.reason,
            severity=args.severity,
            actor=args.approved_by,
        )
    if args.memory_command == "diff":
        if not args.rule_id:
            raise ValueError("memory diff requires record_id")
        return service.memory_diff(args.rule_id)
    if args.memory_command == "propose":
        if not args.rule_id or not args.memory_type:
            raise ValueError("memory propose requires --type and assertion")
        return service.memory_propose(
            args.memory_type[0],
            args.rule_id,
            source_kind=args.source_kind,
            confidence=args.confidence,
        )
    if args.memory_command == "scan":
        result = service.memory_candidates(args.status)
        result["schema_version"] = "persistmind.memory_scan.v1"
        return result
    if args.memory_command == "candidates":
        return service.memory_candidates(args.status)
    if args.memory_command == "review":
        return service.memory_review(status=args.status, limit=args.limit)
    if args.memory_command in {"eval", "bench"}:
        return service.memory_metrics()
    if args.memory_command == "extraction-eval":
        return service.memory_extraction_eval(args.fixtures, args.source_type)
    if args.memory_command == "trust-calibrate":
        return service.memory_trust_calibrate(apply=bool(args.apply) and not bool(args.dry_run))
    if args.memory_command == "utilization":
        return service.memory_utilization(args.rule_id)
    if args.memory_command == "reflect":
        return service.memory_reflect(args.session_id or args.rule_id, args.recent)
    if args.memory_command == "dream":
        return _unsupported_memory_operation("dream")
    if args.memory_command == "maintain":
        return service.memory_maintain(
            apply=bool(args.apply) and not bool(args.dry_run), limit=args.limit
        )
    if args.memory_command == "sweep":
        return service.memory_sweep(apply=bool(args.apply) and not bool(args.dry_run), limit=args.limit)
    if args.memory_command == "consolidate":
        if not args.rule_id or not args.with_candidate:
            raise ValueError("memory consolidate requires record_id --with other_record_id")
        return service.memory_consolidate([args.rule_id, args.with_candidate], args.recent)
    if args.memory_command == "sleep":
        return service.memory_sleep(apply=bool(args.apply) and not bool(args.dry_run), limit=args.limit)
    if args.memory_command == "graph":
        return service.memory_graph(args.rule_id, limit=args.limit, max_hops=args.max_hops)
    if args.memory_command == "prefetch":
        query = args.task or args.rule_id
        if not query:
            raise ValueError("memory prefetch requires --task or query")
        return service.memory_recall(
            query,
            paths=args.memory_paths,
            types=args.memory_type or None,
            limit=args.top_k,
            include_org=args.include_org,
        )
    if args.memory_command == "enforce":
        if not args.rule_id:
            raise ValueError("memory enforce requires record_id")
        return service.memory_enforce(
            args.rule_id,
            level=args.level,
            severity=args.severity,
            scope=args.memory_paths,
            anti_patterns=args.anti_patterns,
            required_patterns=args.required_patterns,
            remediation=args.remediation,
            rationale=args.rationale,
            approve=bool(args.approve),
            approved_by=args.approved_by,
        )
    if args.memory_command == "enforcements":
        return service.memory_enforcements(status=args.status, paths=args.memory_paths)
    if args.memory_command == "unenforce":
        if not args.rule_id:
            raise ValueError("memory unenforce requires directive_id")
        return service.memory_unenforce(args.rule_id, reason=args.reason, actor=args.approved_by)
    raise ValueError(f"unsupported Knowledge operation: {args.memory_command}")


def _unsupported_memory_operation(operation: str) -> dict[str, Any]:
    return {
        "ok": False,
        "status": "unsupported_operation",
        "operation": f"memory_{operation.replace('-', '_')}",
        "schema_version": "persistmind.unsupported_operation.v1",
        "reason": "This memory operation is not safely wired in the next-generation Knowledge service.",
        "nextgen_v1": True,
    }


def _dispatch_nextgen_task(args: argparse.Namespace, service: Any) -> dict[str, Any]:
    if args.command == "intent":
        if args.intent_command == "start":
            problem = args.problem or args.intent_arg
            if not problem:
                raise ValueError("intent start requires --problem")
            return service.intent_start(problem)
        if args.intent_command == "show":
            if not args.intent_arg:
                raise ValueError("intent show requires an intent id")
            return service.state_show(args.intent_arg)
        if args.intent_command == "refine":
            if not args.intent_arg:
                raise ValueError("intent refine requires an intent id")
            return service.state_update(
                args.intent_arg, {"evidence": args.evidence, "selected_goal_id": args.select_goal}
            )
        return service.state_list("intent", status=args.status, limit=args.limit)
    if args.command == "goal":
        if args.goal_command == "evaluate":
            if not args.goal_arg:
                raise ValueError("goal evaluate requires an intent id")
            return service.goal_evaluate(
                args.goal_arg, candidate_goal_id=args.candidate_goal_id, mode=args.mode
            )
        if args.goal_command == "show":
            if not args.goal_arg:
                raise ValueError("goal show requires a goal id")
            return service.state_show(args.goal_arg)
        if args.goal_command == "list":
            return service.state_list("goal", status=args.status, limit=args.limit)
        if not args.goal_arg:
            raise ValueError(f"goal {args.goal_command} requires a goal id")
        status = {
            "accept-alternative": "accepted",
            "reject-alternative": "rejected",
            "challenge": "challenged",
            "reevaluate": "reevaluated",
        }[args.goal_command]
        return service.state_update(
            args.goal_arg,
            {
                "status": status,
                "alternative_id": args.alt_id,
                "rationale": args.rationale,
                "trigger": args.trigger,
            },
        )
    if args.command == "reasoning":
        return service.reasoning_record(
            args.task,
            checkpoint=("route" if args.reasoning_command == "route" else args.checkpoint),
            paths=args.reasoning_paths,
            task_session_id=args.task_session_id,
            surprise=args.surprise,
        )
    if args.command == "experience":
        if args.experience_command == "record":
            if not args.task:
                raise ValueError("experience record requires --task")
            return service.experience_record(
                args.task,
                paths=args.experience_paths,
                surprise=args.surprise,
                trigger=args.trigger,
                evidence=[json.loads(raw) for raw in args.evidence],
            )
        return service.state_list("experience", status=args.status, limit=args.limit)
    if args.command == "working-memory":
        if args.working_memory_command == "capture":
            if not args.task_session_id:
                raise ValueError("working-memory capture requires --task-session-id")
            value = args.text or args.working_memory_arg
            if not value:
                raise ValueError("working-memory capture requires --text")
            return service.state_create(
                "working_memory",
                {
                    "task_session_id": args.task_session_id,
                    "cycle_id": args.cycle_id,
                    "note_kind": args.kind,
                    "text": value,
                    "salience": args.salience,
                    "evidence": [json.loads(raw) for raw in args.evidence],
                    "expires_at": args.expires_at,
                    "status": "active",
                },
            )
        if args.working_memory_command == "list":
            return service.state_list("working_memory", limit=args.limit)
        if not args.working_memory_arg:
            raise ValueError(f"working-memory {args.working_memory_command} requires note_id")
        if args.working_memory_command == "decline":
            return service.working_memory_decline(
                args.working_memory_arg,
                actor=args.actor,
                reason=args.reason or args.text or "not promotable",
            )
        return service.working_memory_promote(args.working_memory_arg, actor=args.actor)
    if args.command == "task":
        if args.task_command == "start":
            task_text = args.task or args.task_arg
            if not task_text:
                raise ValueError("task start requires --task")
            return service.task_start(task_text)
        if args.task_command == "transition":
            if not args.task_arg or not args.state:
                raise ValueError("task transition requires task_session_id and --state")
            return service.task_transition(
                args.task_arg,
                args.state,
                actor=args.actor,
                reason=args.reason,
                pack_id=args.pack_id,
            )
        if args.task_command == "show":
            if not args.task_arg:
                raise ValueError("task show requires task_session_id")
            return service.task_show(args.task_arg)
        if args.task_command == "learned":
            if not args.task_arg:
                raise ValueError("task learned requires task_session_id")
            return service.task_learning_report(args.task_arg)
        if args.task_command == "remediation-attempt":
            if not args.task_arg:
                raise ValueError("task remediation-attempt requires task_session_id")
            return service.remediation_attempt_record(
                args.task_arg,
                gate_id=args.gate or args.blocking_gate or "",
                approach=args.approach or "",
                outcome=args.outcome or "",
                command_or_tool=args.command_or_tool,
                error=args.error,
                waited_seconds=args.waited_seconds,
                backoff_strategy=args.backoff_strategy,
                transient_recovery=args.transient_recovery,
                actor=args.actor,
            )
        if args.task_command == "close":
            if not args.task_arg:
                raise ValueError("task close requires task_session_id")
            return service.task_close(
                args.task_arg,
                result=args.result or "",
                reason=args.reason or "",
                blocking_gate_id=args.blocking_gate,
                actor=args.actor,
            )
        raise ValueError(f"unsupported Task operation: {args.task_command}")
    if args.command == "continuation":
        if args.continuation_command == "list":
            return service.continuation_list(args.status, args.limit)
        if args.continuation_command == "show":
            if not args.continuation_arg:
                raise ValueError("continuation show requires continuation_id")
            return service.continuation_show(args.continuation_arg)
        if args.continuation_command == "update":
            if not args.continuation_arg:
                raise ValueError("continuation update requires continuation_id")
            return service.continuation_update(
                args.continuation_arg,
                state=args.state,
                next_action=args.next_action,
                blockers=args.continuation_blockers or None,
                reason=args.reason,
            )
        if args.continuation_command == "resume":
            task = args.task or args.continuation_arg
            if not task:
                raise ValueError("continuation resume requires --task")
            return service.continuation_resume(task, args.limit)
        if not args.continuation_arg:
            raise ValueError("continuation abandon requires continuation_id")
        return service.continuation_abandon(args.continuation_arg, args.reason)
    if args.plan_command == "validate":
        plan = _load_plan_arg(args)
        result = service.plan_validate(
            plan,
            task_session_id=args.task_session_id,
            pack_id=args.pack_id,
        )
        if args.fail_on_violation and not result.get("ok"):
            raise ValueError("task plan validation failed")
        return result
    if args.plan_command == "create":
        if not args.task_session_id:
            raise ValueError("plan create requires --task-session-id")
        result = service.plan_create(
            args.task_session_id,
            _load_plan_arg(args),
            pack_id=args.pack_id,
            author=args.author,
        )
        if args.fail_on_violation and not result.get("ok"):
            raise ValueError("task plan validation failed")
        return result
    if args.plan_command == "amend":
        if not args.plan_arg:
            raise ValueError("plan amend requires plan_id")
        result = service.plan_amend(
            args.plan_arg,
            _load_plan_arg(args, allow_positional_json=False),
            author=args.author,
            reason=args.reason,
        )
        if args.fail_on_violation and not result.get("ok"):
            raise ValueError("task plan validation failed")
        return result
    if not args.plan_arg or not args.step_id:
        raise ValueError("plan checkpoint requires plan_id and --step-id")
    paths = args.plan_paths or _nextgen_task_changed_paths(Path(args.repo), staged=args.staged)
    result = service.plan_checkpoint(args.plan_arg, args.step_id, paths=paths)
    if args.fail_on_violation and not result.get("ok"):
        raise ValueError("task plan checkpoint failed")
    return result
