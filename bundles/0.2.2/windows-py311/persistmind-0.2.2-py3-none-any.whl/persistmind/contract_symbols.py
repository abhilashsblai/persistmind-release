from __future__ import annotations

import re

IDENTIFIER_PATTERN = r"[A-Za-z_][A-Za-z0-9_]*"
STOPWORDS = frozenset(
    {
        "a",
        "an",
        "and",
        "as",
        "by",
        "csv",
        "deterministic",
        "for",
        "focused",
        "from",
        "in",
        "into",
        "of",
        "on",
        "or",
        "that",
        "the",
        "to",
        "with",
    }
)


def clean_contract_identifier(value: str) -> str:
    return str(value).strip().removesuffix("()")


def is_plausible_contract_symbol(value: str) -> bool:
    cleaned = clean_contract_identifier(value)
    if not cleaned:
        return False
    parts = cleaned.split(".")
    if any(not re.fullmatch(IDENTIFIER_PATTERN, part) for part in parts):
        return False
    if any(part.casefold() in STOPWORDS for part in parts):
        return False
    if len(parts) > 1:
        return True
    return "_" in cleaned or any(char.isdigit() for char in cleaned) or any(
        char.isupper() for char in cleaned
    )


__all__ = ["IDENTIFIER_PATTERN", "clean_contract_identifier", "is_plausible_contract_symbol"]
