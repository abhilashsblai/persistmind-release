from __future__ import annotations

from typing import Any

from .assembly import TRUST_CONFIDENCE

DIMENSIONS = ("impact", "risk", "revenue", "strategic_alignment")


def score_option(option: dict[str, Any]) -> dict[str, Any]:
    unknowns: list[dict[str, str]] = list(option.get("unknowns") or [])
    scores = {
        "impact": _impact_score(option, unknowns),
        "risk": _risk_score(option, unknowns),
        "revenue": _revenue_score(option, unknowns),
        "strategic_alignment": _strategic_score(option, unknowns),
    }
    _validate_scores(scores, unknowns)
    return {**option, "scores": scores, "unknowns": unknowns}


def _impact_score(option: dict[str, Any], unknowns: list[dict[str, str]]) -> dict[str, Any]:
    technical = option.get("technical_impact") or {}
    impacted = technical.get("impacted_paths") or []
    value = max(0.0, 10.0 - min(10.0, len(impacted) / 2.0))
    return _score(value, [f"{option['id']}:technical"], [technical.get("trust_tier")])


def _risk_score(option: dict[str, Any], unknowns: list[dict[str, str]]) -> dict[str, Any]:
    technical = option.get("technical_impact") or {}
    risk = technical.get("risk") or {}
    value = max(0.0, 10.0 - min(10.0, float(risk.get("score") or 0.0)))
    return _score(value, [f"{option['id']}:technical"], [technical.get("trust_tier")])


def _revenue_score(option: dict[str, Any], unknowns: list[dict[str, str]]) -> dict[str, Any]:
    business = option.get("business_exposure") or {}
    exposure = business.get("exposure") or {}
    tier = str(business.get("trust_tier") or "unknown")
    if not exposure:
        _unknown(unknowns, "revenue", "no business entity linked")
        return _score(None, [f"{option['id']}:business"], [tier])
    if tier in {"low", "untrusted", "unknown"}:
        _unknown(unknowns, "revenue", "business exposure is low trust")
        return _score(None, [f"{option['id']}:business"], [tier])
    weighted = 0.0
    for kind, items in exposure.items():
        multiplier = 2.5 if kind in {"customer", "revenue", "contract"} else 1.0
        weighted += len(items or []) * multiplier
    value = min(10.0, weighted)
    return _score(value, [f"{option['id']}:business"], [tier])


def _strategic_score(option: dict[str, Any], unknowns: list[dict[str, str]]) -> dict[str, Any]:
    goal = option.get("goal_alignment") or {}
    if not goal.get("goal_id"):
        _unknown(unknowns, "strategic_alignment", "no matching goal governance record")
        return _score(None, [f"{option['id']}:goal"], [goal.get("trust_tier")])
    value = min(10.0, max(0.0, float(goal.get("confidence") or 0.0) * 10.0))
    return _score(value, [f"{option['id']}:goal"], [goal.get("trust_tier")])


def _score(value: float | None, refs: list[str], trusts: list[Any]) -> dict[str, Any]:
    return {
        "value": None if value is None else round(float(value), 4),
        "basis_evidence_refs": refs,
        "inputs_trust": [str(item or "unknown") for item in trusts],
    }


def _unknown(unknowns: list[dict[str, str]], dimension: str, reason: str) -> None:
    if not any(
        item.get("dimension") == dimension and item.get("reason") == reason for item in unknowns
    ):
        unknowns.append({"dimension": dimension, "reason": reason})


def _validate_scores(scores: dict[str, Any], unknowns: list[dict[str, str]]) -> None:
    unknown_dimensions = {item.get("dimension") for item in unknowns}
    for dimension, score in scores.items():
        value = score.get("value")
        if value is None:
            if dimension not in unknown_dimensions:
                raise ValueError(f"score {dimension} is null without a matching unknown")
            continue
        if not 0.0 <= float(value) <= 10.0:
            raise ValueError(f"score {dimension} out of range: {value}")


def trust_weight(tier: str) -> float:
    return TRUST_CONFIDENCE.get(str(tier or "unknown"), 0.0)
