from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Mapping

PRODUCT_ID = "c8ee8be4-1cc8-4e78-972f-c73f8615f2f7"
PRODUCT_NAME = "PersistMind"
PRODUCT_TAGLINE = "Persistent project intelligence for AI engineering."
TRANSITION_NAME = PRODUCT_NAME

CLI_NAME = "persistmind"
PYTHON_DISTRIBUTION = "persistmind"
NPM_PACKAGE = "@persistmind/cli"
SOURCE_REPOSITORY = "abhilashsblai/PersistMind"
RELEASE_REPOSITORY = "abhilashsblai/persistmind-release"
RELEASE_REPOSITORIES = (RELEASE_REPOSITORY,)
RELEASE_TRANSPORT = "google_drive"
RELEASE_DRIVE_FOLDER_ID = "1aOOJ7fEE9Bv8yS-jzFVvTuBwlx0q7Nz9"
RELEASE_DRIVE_FOLDER_URL = (
    "https://drive.google.com/drive/folders/1aOOJ7fEE9Bv8yS-jzFVvTuBwlx0q7Nz9"
)

PROJECT_STATE_DIR = ".persistmind"
CONFIG_FILE = "persistmind.toml"
CAPABILITIES_FILE = "persistmind.capabilities.yaml"
PROTECTED_GOVERNANCE_PATHS = frozenset({CONFIG_FILE, CAPABILITIES_FILE})

HOME_ENV = "PERSISTMIND_HOME"
NO_REGISTRY_ENV = "PERSISTMIND_NO_REGISTRY"
KEYRING_SERVICE = "persistmind.storage.kek.v1"
MCP_SERVER_NAME = "persistmind"
GIT_NOTES_REF = "refs/notes/persistmind"

UPDATE_MANIFEST_SCHEMA = "persistmind.update_manifest.v2"
UPDATE_MANIFEST_V3_SCHEMA = "persistmind.update_manifest.v3"
UPDATE_MANIFEST_V4_SCHEMA = "persistmind.update_manifest.v4"
INSTALLATION_SCHEMA = "persistmind.installation.v1"
ACTIVE_ENV = "PERSISTMIND_ACTIVE"


class BrandStateConflict(RuntimeError):
    status = "brand_state_conflict"


def first_env(
    canonical: str,
    aliases: tuple[str, ...] = (),
    *,
    env: Mapping[str, str] | None = None,
) -> str | None:
    values = os.environ if env is None else env
    value = values.get(canonical)
    if value:
        return value
    return next((values[name] for name in aliases if values.get(name)), None)


def canonical_user_home(*, env: Mapping[str, str] | None = None) -> Path:
    values = os.environ if env is None else env
    override = values.get(HOME_ENV)
    if override:
        return Path(override).expanduser().resolve()
    if os.name == "nt" and values.get("APPDATA"):
        return (Path(values["APPDATA"]) / PRODUCT_NAME).resolve()
    return (Path(values.get("HOME") or Path.home()) / PROJECT_STATE_DIR).resolve()


def migrate_user_home(*, env: Mapping[str, str] | None = None) -> dict[str, str | bool]:
    """Return the canonical home without mutating historical product locations."""
    path = canonical_user_home(env=env)
    return {
        "migrated": False,
        "status": "canonical" if path.exists() else "not_initialized",
        "path": str(path),
    }


def project_state(repo: Path) -> Path:
    return repo.expanduser().resolve() / PROJECT_STATE_DIR


def resolve_project_state(repo: Path, *, require_existing: bool = False) -> Path:
    override = os.environ.get("PERSISTMIND_PROJECT_STATE")
    authority = os.environ.get("PERSISTMIND_CANONICAL_REPO")
    if override or authority:
        if not override or not authority:
            raise BrandStateConflict(
                "PERSISTMIND_PROJECT_STATE and PERSISTMIND_CANONICAL_REPO must be set together"
            )
        requested = repo.expanduser().resolve()
        authority_root = Path(authority).expanduser().resolve()
        bound_state = Path(override).expanduser().resolve()
        if bound_state != project_state(authority_root):
            raise BrandStateConflict(
                "PERSISTMIND_PROJECT_STATE is not owned by PERSISTMIND_CANONICAL_REPO"
            )
        if _git_common_dir(requested) != _git_common_dir(authority_root):
            raise BrandStateConflict(
                "project-state authority does not share the requested Git common directory"
            )
        if require_existing and not bound_state.exists():
            raise FileNotFoundError(
                f"bound PersistMind project state does not exist: {bound_state}"
            )
        return bound_state
    state = project_state(repo)
    if require_existing and not state.exists():
        raise FileNotFoundError(f"no {PRODUCT_NAME} project state exists under {repo}")
    return state


def _git_common_dir(repo: Path) -> Path:
    completed = subprocess.run(
        ["git", "-C", str(repo), "rev-parse", "--git-common-dir"],
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="strict",
    )
    if completed.returncode != 0 or not completed.stdout.strip():
        raise BrandStateConflict(f"project-state binding requires a Git repository: {repo}")
    common = Path(completed.stdout.strip())
    return (common if common.is_absolute() else repo / common).resolve()


def resolve_config(repo: Path) -> Path:
    return repo / CONFIG_FILE


def resolve_capabilities(repo: Path) -> Path:
    return repo / CAPABILITIES_FILE
