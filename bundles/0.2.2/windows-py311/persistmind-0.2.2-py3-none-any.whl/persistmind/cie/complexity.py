from __future__ import annotations

from typing import Any

TASK_TYPES = (
    "api",
    "database",
    "frontend_ui",
    "browser_validation",
    "migration",
    "security_sensitive",
    "release",
    "documentation",
    "selfmod",
    "memory",
    "skill",
    "unknown",
)


def infer_task_type(task: str = "", paths: list[str] | None = None) -> str:
    text = " ".join([task, *(paths or [])]).lower()
    checks = [
        ("security_sensitive", ("auth", "secret", "pii", "security", "token", "oauth")),
        ("database", ("migration", "schema", "sqlite", "database", "db")),
        (
            "frontend_ui",
            ("frontend", "ui", "css", "react", "dashboard", ".tsx", ".jsx"),
        ),
        ("browser_validation", ("browser", "screenshot", "playwright")),
        ("release", ("release", "version", "changelog")),
        ("documentation", ("docs/", ".md", "documentation")),
        ("selfmod", ("selfmod", "optimizer")),
        ("memory", ("memory", "recall")),
        ("skill", ("skill",)),
        ("api", ("api", "http", "route", "endpoint")),
    ]
    for task_type, tokens in checks:
        if any(token in text for token in tokens):
            return task_type
    return "unknown"


def estimate_complexity(
    task: str = "",
    paths: list[str] | None = None,
    history: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    paths = paths or []
    task_type = infer_task_type(task, paths)
    text = " ".join([task, *paths]).lower()
    files_factor = min(20, len(paths) * 4)
    services_factor = 10 if len({path.split("/")[1] for path in paths if "/" in path}) > 2 else 0
    dependency_factor = (
        10
        if any(token in text for token in ("dependency", "package", "provider", "integration"))
        else 0
    )
    architecture_factor = (
        12 if any(token in text for token in ("architecture", "cross", "service")) else 0
    )
    surface_factor = (
        10 if any(token in text for token in ("cli", "http", "mcp", "dashboard", "rollup")) else 0
    )
    security_factor = 15 if task_type == "security_sensitive" else 0
    migration_factor = 15 if task_type in {"database", "migration"} else 0
    historical_failure_factor = min(12, len(history or []) * 2)
    agent_capability_factor = 5
    score = min(
        100,
        files_factor
        + services_factor
        + dependency_factor
        + architecture_factor
        + surface_factor
        + security_factor
        + migration_factor
        + historical_failure_factor
        + agent_capability_factor,
    )
    band = "low"
    if score >= 75:
        band = "critical"
    elif score >= 50:
        band = "high"
    elif score >= 25:
        band = "medium"
    return {
        "task_type": task_type,
        "task_complexity_score": score,
        "complexity_band": band,
        "files_touched_estimate": len(paths),
        "services_touched_estimate": services_factor // 10,
        "dependency_count": dependency_factor // 10,
        "architectural_impact": architecture_factor,
        "surface_count": surface_factor // 10,
        "security_sensitivity": security_factor,
        "migration_or_data_risk": migration_factor,
        "historical_failure_rate": min(1.0, len(history or []) / 10),
        "agent_capability_confidence": max(0.2, 1.0 - agent_capability_factor / 20),
        "evidence_refs": [
            item.get("error_id", "") for item in history or [] if item.get("error_id")
        ],
    }
