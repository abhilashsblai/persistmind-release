from __future__ import annotations

from persistmind.cie.contracts import (
    CognitivePatternRecord,
    RootCauseRecord,
    deterministic_id,
)

PATTERN_BY_ROOT = {
    "verification_gap": "verification_avoidance",
    "risk_calibration_failure": "premature_confidence",
    "planning_weakness": "insufficient_exploration",
    "surface_parity_failure": "surface_drift",
    "execution_discipline_failure": "unsafe_mutation_pressure",
    "context_retrieval_failure": "context_underselection",
    "impact_analysis_failure": "weak_uncertainty_handling",
}


def discover_patterns(
    root_causes: list[RootCauseRecord],
) -> list[CognitivePatternRecord]:
    patterns: dict[str, CognitivePatternRecord] = {}
    for root in root_causes:
        pattern_type = PATTERN_BY_ROOT.get(root.root_cause, "insufficient_exploration")
        existing = patterns.get(pattern_type)
        if existing:
            existing.root_cause_ids.extend(root.root_cause_id for _ in [0])
            existing.recurrence_count += root.recurrence_count
            existing.evidence_refs.extend(
                ref for ref in root.evidence_refs if ref not in existing.evidence_refs
            )
            existing.confidence = min(0.95, existing.confidence + 0.05)
            continue
        patterns[pattern_type] = CognitivePatternRecord(
            pattern_id=deterministic_id("pattern", pattern_type),
            pattern_type=pattern_type,
            root_cause_ids=[root.root_cause_id],
            confidence=min(0.9, 0.45 + root.recurrence_count * 0.1),
            recurrence_count=root.recurrence_count,
            evidence_refs=list(root.evidence_refs),
            status="candidate",
        )
    return [patterns[key] for key in sorted(patterns)]
