from __future__ import annotations

from itertools import combinations

from persistmind.cie.contracts import (
    HypothesisRecord,
    HypothesisRelationship,
    deterministic_id,
)


def detect_hypothesis_relationships(
    hypotheses: list[HypothesisRecord],
) -> list[HypothesisRelationship]:
    relationships: list[HypothesisRelationship] = []
    for left, right in combinations(hypotheses, 2):
        relation = "unrelated"
        explanation = "no deterministic overlap detected"
        left_terms = set(left.statement.lower().split())
        right_terms = set(right.statement.lower().split())
        overlap = left_terms & right_terms
        if left.statement.lower() == right.statement.lower():
            relation = "duplicates"
            explanation = "statements normalize to the same text"
        elif left.pattern_id == right.pattern_id:
            relation = "refines"
            explanation = "hypotheses share a pattern and differ in scope"
        elif overlap & {"verification", "confidence", "complexity", "surface"}:
            relation = "supports"
            explanation = "hypotheses predict compatible observations"
        if relation != "unrelated":
            relationships.append(
                HypothesisRelationship(
                    relationship_id=deterministic_id(
                        "hypothesis_relationship",
                        left.hypothesis_id,
                        right.hypothesis_id,
                        relation,
                    ),
                    source_hypothesis_id=left.hypothesis_id,
                    target_hypothesis_id=right.hypothesis_id,
                    relation_type=relation,
                    evidence_refs=sorted(set(left.evidence_refs + right.evidence_refs)),
                    confidence=0.6,
                    explanation=explanation,
                )
            )
    return relationships
