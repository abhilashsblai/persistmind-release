from __future__ import annotations

from collections import defaultdict

from persistmind.cie.contracts import (
    FailureClassification,
    RootCauseRecord,
    deterministic_id,
)

ROOT_CAUSE_BY_CATEGORY = {
    "context_selection": "context_retrieval_failure",
    "impact_prediction": "impact_analysis_failure",
    "memory_quality": "memory_recall_failure",
    "skill_quality": "skill_trigger_failure",
    "loop_closure": "execution_discipline_failure",
    "eval_regression": "risk_calibration_failure",
    "selfmod_safety": "execution_discipline_failure",
    "security": "risk_calibration_failure",
    "goal_alignment": "planning_weakness",
    "surface_parity": "surface_parity_failure",
    "system_health": "planning_weakness",
    "requirement_analysis": "planning_weakness",
    "verification_gap": "verification_gap",
    "execution_discipline": "execution_discipline_failure",
}


def infer_root_causes(
    classifications: list[FailureClassification],
) -> list[RootCauseRecord]:
    grouped: dict[str, list[FailureClassification]] = defaultdict(list)
    for classification in classifications:
        grouped[classification.category].append(classification)
    roots: list[RootCauseRecord] = []
    for category in sorted(grouped):
        items = grouped[category]
        root = ROOT_CAUSE_BY_CATEGORY.get(category, "planning_weakness")
        roots.append(
            RootCauseRecord(
                root_cause_id=deterministic_id("root_cause", category, root),
                source_error_ids=[item.error_id for item in items],
                category=category,
                root_cause=root,
                confidence=min(0.95, 0.45 + (len(items) * 0.1)),
                recurrence_count=len(items),
                cognitive_debt_score=float(len(items) * 10),
                evidence_refs=sorted({ref for item in items for ref in item.evidence_refs}),
            )
        )
    return roots
