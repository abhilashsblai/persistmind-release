from __future__ import annotations

from persistmind.cie.contracts import LearningQualityCheck, deterministic_id


def detect_false_learning(
    raw_improvement: float,
    difficulty_adjusted_improvement: float,
    hard_before: float,
    hard_after: float,
) -> LearningQualityCheck:
    reasons: list[str] = []
    if raw_improvement > 0 and difficulty_adjusted_improvement <= 0:
        reasons.append("difficulty_adjusted_improvement_not_positive")
    if hard_after < hard_before:
        reasons.append("hard_task_attempt_rate_fell")
    status = "healthy"
    if reasons:
        status = "suspected_false_learning"
    elif raw_improvement < 0:
        status = "watch"
    return LearningQualityCheck(
        learning_quality_id=deterministic_id(
            "learning_quality",
            raw_improvement,
            difficulty_adjusted_improvement,
            hard_before,
            hard_after,
        ),
        raw_improvement=raw_improvement,
        difficulty_adjusted_improvement=difficulty_adjusted_improvement,
        hard_task_attempt_rate_before=hard_before,
        hard_task_attempt_rate_after=hard_after,
        suspected_false_learning_reasons=reasons,
        status=status,
    )
