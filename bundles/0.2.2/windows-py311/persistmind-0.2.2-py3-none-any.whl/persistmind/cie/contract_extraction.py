from __future__ import annotations

import re
from typing import Any

from persistmind.cie.contracts import deterministic_id
from persistmind.contract_symbols import (
    IDENTIFIER_PATTERN,
    clean_contract_identifier,
    is_plausible_contract_symbol,
)

_IDENTIFIER = IDENTIFIER_PATTERN
_DOTTED_IDENTIFIER = rf"{_IDENTIFIER}(?:\.{_IDENTIFIER})+"
_QUOTED_IDENTIFIER_RE = re.compile(rf"['\"](({_DOTTED_IDENTIFIER})|({_IDENTIFIER}))(\(\))?['\"]")
_DOTTED_IDENTIFIER_RE = re.compile(rf"\b({_DOTTED_IDENTIFIER})\b")
_RENAME_RE = re.compile(
    rf"\brename\s+({_DOTTED_IDENTIFIER}|{_IDENTIFIER})(?:\(\))?\s+to\s+"
    rf"({_DOTTED_IDENTIFIER}|{_IDENTIFIER})(?:\(\))?",
    re.IGNORECASE,
)
_PUBLIC_SYMBOL_RE = re.compile(
    rf"\b(?:add|create|expose|export|implement)\s+(?:a\s+|an\s+|the\s+)?"
    rf"(?:public\s+)?(?:function\s+|api\s+|alias\s+)?"
    rf"({_DOTTED_IDENTIFIER}|{_IDENTIFIER})(?:\(\))?",
    re.IGNORECASE,
)


def extract_named_symbols(task: str) -> list[dict[str, Any]]:
    """Extract concrete task contract items without model calls."""

    text = str(task or "")
    items: dict[tuple[str, str], dict[str, Any]] = {}

    def add(kind: str, value: str, source_ref: str) -> None:
        cleaned = _clean_identifier(value)
        if not cleaned or kind in {"symbol", "alias"} and not is_plausible_contract_symbol(cleaned):
            return
        key = (kind, cleaned)
        items.setdefault(
            key,
            {
                "id": deterministic_id("acceptance_contract", kind, cleaned, source_ref),
                "kind": kind,
                "value": cleaned,
                "source_ref": source_ref,
                "satisfied": False,
            },
        )

    for match in _DOTTED_IDENTIFIER_RE.finditer(text):
        add("symbol", match.group(1), "task:dotted_identifier")
    for match in _QUOTED_IDENTIFIER_RE.finditer(text):
        add("symbol", match.group(1), "task:quoted_identifier")
    for match in _RENAME_RE.finditer(text):
        add("alias", match.group(1), "task:rename_source")
        add("symbol", match.group(2), "task:rename_target")
    for match in _PUBLIC_SYMBOL_RE.finditer(text):
        add("symbol", match.group(1), "task:public_symbol")

    return sorted(items.values(), key=lambda item: (item["kind"], item["value"]))


def _clean_identifier(value: str) -> str:
    return clean_contract_identifier(value)


__all__ = ["extract_named_symbols"]
