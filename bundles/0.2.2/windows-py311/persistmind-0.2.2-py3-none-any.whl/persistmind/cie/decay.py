from __future__ import annotations

from persistmind.cie.contracts import LearningDecayRecord, deterministic_id


def decay_guidance(
    target_id: str,
    *,
    target_type: str = "rule",
    effectiveness: float = 1.0,
    contradiction_count: int = 0,
    usage_count: int = 0,
) -> LearningDecayRecord:
    action = "keep"
    reason = "guidance remains effective"
    if contradiction_count:
        action = "request_review"
        reason = "contradicting evidence exists"
    if usage_count == 0:
        action = "lower_rank"
        reason = "unused guidance"
    if effectiveness < 0:
        action = "retire"
        reason = "negative measured effectiveness"
    elif effectiveness < 0.2:
        action = "mark_stale"
        reason = "low measured effectiveness"
    return LearningDecayRecord(
        decay_id=deterministic_id("decay", target_type, target_id, action),
        target_id=target_id,
        target_type=target_type,
        action=action,
        reason=reason,
    )
