from __future__ import annotations

from persistmind.cie.contracts import CognitiveImprovementScore, deterministic_id

WEIGHTS = {
    "error_recurrence_index": 0.25,
    "cognitive_debt_index": 0.20,
    "rule_effectiveness_index": 0.15,
    "prediction_accuracy_index": 0.15,
    "confidence_calibration_index": 0.10,
    "learning_quality_index": 0.05,
    "near_miss_severity_index": 0.05,
    "decision_quality_index": 0.05,
}


def compute_improvement_score(
    components: dict[str, float],
    *,
    previous_score: float = 0.0,
    sample_size: int = 0,
    warnings: list[str] | None = None,
) -> CognitiveImprovementScore:
    normalized = {key: max(0.0, min(100.0, float(components.get(key, 0.0)))) for key in WEIGHTS}
    score = round(sum(normalized[key] * weight for key, weight in WEIGHTS.items()), 3)
    return CognitiveImprovementScore(
        score_id=deterministic_id("score", normalized, previous_score, sample_size),
        score=score,
        previous_score=previous_score,
        delta=round(score - previous_score, 3),
        components=normalized,
        sample_size=sample_size,
        confidence=round(min(1.0, sample_size / 20), 3),
        explanation="weighted deterministic CIE component score",
        false_learning_warnings=warnings or [],
        provisional=sample_size < 10,
    )
