from __future__ import annotations

from collections.abc import Iterable
from typing import TextIO

_UTF8_BOM = "\ufeff"
_MOJIBAKE_UTF8_BOM = "ï»¿"


def normalize_path_record(value: str, *, first_record: bool = False) -> str:
    """Normalize one newline-free path record from a CLI or text pipeline.

    PowerShell can prefix redirected UTF-8 output with a BOM.  When that byte
    sequence was decoded through a legacy code page it arrives as ``ï»¿``.
    Both forms are metadata only at the start of the first record; elsewhere a
    BOM is rejected so a real filename is never silently rewritten.
    """

    record = str(value).strip()
    if first_record:
        if record.startswith(_UTF8_BOM):
            record = record.removeprefix(_UTF8_BOM)
        elif record.startswith(_MOJIBAKE_UTF8_BOM):
            record = record.removeprefix(_MOJIBAKE_UTF8_BOM)
        record = record.strip()
    if not record:
        return ""
    if _UTF8_BOM in record or _MOJIBAKE_UTF8_BOM in record:
        raise ValueError("path input contains an unexpected UTF-8 BOM marker")
    invalid = [char for char in record if ord(char) < 32 or ord(char) == 127]
    if invalid:
        raise ValueError("path input contains a control character")
    return record


def normalize_path_records(values: Iterable[str]) -> list[str]:
    result: list[str] = []
    first_record = True
    for value in values:
        normalized = normalize_path_record(value, first_record=first_record)
        if not normalized:
            continue
        result.append(normalized)
        first_record = False
    return result


def read_path_records(stream: TextIO) -> list[str]:
    return normalize_path_records(stream)


def normalize_diff_input(value: str) -> str:
    """Remove only a leading BOM marker from a complete diff stream."""

    if value.startswith(_UTF8_BOM):
        return value.removeprefix(_UTF8_BOM)
    if value.startswith(_MOJIBAKE_UTF8_BOM):
        return value.removeprefix(_MOJIBAKE_UTF8_BOM)
    return value
