from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from typing import Any


_QUERY_TERM = re.compile(r"[A-Za-z0-9_][A-Za-z0-9_-]{2,}")
_QUERY_STOP_WORDS = {
    "and",
    "about",
    "briefly",
    "explain",
    "for",
    "from",
    "into",
    "project",
    "that",
    "the",
    "their",
    "then",
    "these",
    "this",
    "what",
    "when",
    "where",
    "which",
    "with",
}
_QUERY_ALIASES = {
    "authentication": ("auth",),
    "authorization": ("authz",),
    "guards": ("guard",),
    "handling": ("handle", "handler"),
    "implementation": ("implement",),
    "providers": ("provider",),
    "routes": ("route",),
    "sessions": ("session",),
}


def query_terms(query: str) -> tuple[str, ...]:
    raw_terms = {match.group(0).casefold() for match in _QUERY_TERM.finditer(query)}
    terms = raw_terms - _QUERY_STOP_WORDS
    if not terms:
        terms = raw_terms
    for term in tuple(terms):
        terms.update(_QUERY_ALIASES.get(term, ()))
    return tuple(sorted(terms))


def context_relevance(query: str, item: Mapping[str, Any]) -> tuple[int, tuple[str, ...]]:
    """Score one source record without inventing semantic evidence."""

    text = str(item.get("text") or "")
    path = str(item.get("path") or "")
    searchable = text.casefold()
    terms = query_terms(query)
    matched = tuple(term for term in terms if term in searchable)
    phrase = " ".join(query.casefold().split())
    phrase_match = bool(phrase and phrase in " ".join(searchable.split()))
    occurrences = sum(min(searchable.count(term), 8) for term in matched)
    path_matches = sum(1 for term in matched if term in path.casefold())
    positions = sorted(searchable.find(term) for term in matched)
    proximity = max(0, 60 - (positions[-1] - positions[0]) // 80) if len(positions) >= 2 else 0
    source_chunk = str(item.get("kind") or "") == "source_chunk"
    chunk_bonus = 35 if source_chunk else 0
    whole_file_penalty = 0 if source_chunk else min(100, len(text) // 500)
    return (
        (100 if phrase_match else 0)
        + len(matched) * 20
        + occurrences
        + path_matches * 5
        + proximity
        + chunk_bonus
        - whole_file_penalty,
        matched,
    )


def matched_snippet_previews(
    pack: Mapping[str, Any], *, limit: int = 8, max_chars: int = 800
) -> list[dict[str, Any]]:
    """Return bounded, ranked excerpts from a context-pack manifest."""

    query = str(pack.get("task") or "")
    raw_items = pack.get("items")
    items: Iterable[Any] = raw_items if isinstance(raw_items, list) else ()
    ranked: list[tuple[int, int, Mapping[str, Any], tuple[str, ...]]] = []
    for index, raw_item in enumerate(items):
        if not isinstance(raw_item, Mapping):
            continue
        text = str(raw_item.get("text") or "")
        path = str(raw_item.get("path") or "")
        if not text or not path:
            continue
        score, matched = context_relevance(query, raw_item)
        ranked.append((score, -index, raw_item, matched))
    ranked.sort(key=lambda entry: (-entry[0], -entry[1], str(entry[2].get("path") or "")))

    previews: list[dict[str, Any]] = []
    for score, _negative_index, item, matched in ranked[: max(1, min(limit, 20))]:
        text = str(item.get("text") or "")
        snippet, relative_start, relative_end = _matched_excerpt(
            text,
            matched,
            max_chars=max(160, min(max_chars, 2_000)),
        )
        stored_start = int(item.get("start_line") or 1)
        preview = {
            "path": str(item.get("path") or ""),
            "kind": str(item.get("kind") or item.get("category") or "source"),
            "start_line": stored_start + relative_start - 1,
            "end_line": stored_start + relative_end - 1,
            "matched_terms": list(matched),
            "relevance_score": score,
            "snippet": snippet,
        }
        if item.get("symbol_identity_id"):
            preview["symbol_identity_id"] = item["symbol_identity_id"]
        previews.append(preview)
    return previews


def _matched_excerpt(
    text: str, matched_terms: tuple[str, ...], *, max_chars: int
) -> tuple[str, int, int]:
    folded = text.casefold()
    positions = [folded.find(term) for term in matched_terms if folded.find(term) >= 0]
    focus = min(positions) if positions else 0
    start = max(0, focus - max_chars // 3)
    end = min(len(text), start + max_chars)
    if end - start < max_chars:
        start = max(0, end - max_chars)
    if start:
        newline = text.find("\n", start)
        start = newline + 1 if 0 <= newline < focus else start
    if end < len(text):
        newline = text.rfind("\n", start, end)
        end = newline if newline > start else end
    excerpt = text[start:end].strip()
    if start:
        excerpt = "...\n" + excerpt
    if end < len(text):
        excerpt += "\n..."
    relative_start = text.count("\n", 0, start) + 1
    relative_end = relative_start + max(
        0, excerpt.count("\n") - int(start > 0) - int(end < len(text))
    )
    return excerpt, relative_start, relative_end
