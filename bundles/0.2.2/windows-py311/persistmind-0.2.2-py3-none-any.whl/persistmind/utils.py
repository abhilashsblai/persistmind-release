from __future__ import annotations

import fnmatch
import hashlib
import json
import ntpath
import os
import posixpath
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


def utc_now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8", errors="surrogateescape"))


def stable_id(*parts: object) -> str:
    payload = "\x1f".join(str(part) for part in parts)
    return sha256_text(payload)


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def read_text_lossy(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def relpath(path: Path, root: Path) -> str:
    return os.path.relpath(path, root).replace("\\", "/")


def normalize_repo_relative_path(path: str) -> str:
    """Normalize separators and one explicit relative prefix without eating dotdirs."""
    p = str(path).replace("\\", "/")
    while p.startswith("./"):
        p = p[2:]
    return p


def canonical_repo_path(path: str, repo_root: Path, *, reject_outside: bool = False) -> str:
    p = normalize_repo_relative_path(path)
    if not p:
        if reject_outside:
            raise ValueError(f"path is outside repository: {path}")
        return p

    root = str(repo_root).replace("\\", "/")
    win_p = ntpath.normpath(p)
    win_root = ntpath.normpath(root)
    if ntpath.isabs(win_p):
        try:
            common = ntpath.commonpath([ntpath.normcase(win_p), ntpath.normcase(win_root)])
        except ValueError:
            common = ""
        if common == ntpath.normcase(win_root):
            return ntpath.relpath(win_p, win_root).replace("\\", "/")
        if reject_outside:
            raise ValueError(f"path is outside repository: {path}")
        return p

    posix_p = posixpath.normpath(p)
    posix_root = posixpath.normpath(root)
    if posixpath.isabs(posix_p):
        try:
            common = posixpath.commonpath([posix_p, posix_root])
        except ValueError:
            common = ""
        if common == posix_root:
            return posixpath.relpath(posix_p, posix_root)
        return p

    collapsed = posixpath.normpath(p)
    if collapsed in {"", "."} or collapsed == ".." or collapsed.startswith("../"):
        if reject_outside:
            raise ValueError(f"path escapes repository: {path}")
        return p
    return collapsed


def canonical_repo_scope(scope: str, repo_root: Path) -> tuple[str, bool]:
    """Return a safe repository-relative plan scope and its directory intent.

    A trailing slash is an explicit directory declaration. Existing directories
    are also treated as directory scopes so plans can approve a bounded output
    tree without enumerating files that do not exist yet.
    """

    raw = normalize_repo_relative_path(scope).strip()
    explicit_directory = raw.endswith("/")
    normalized = canonical_repo_path(raw.rstrip("/"), repo_root, reject_outside=True)
    if not normalized:
        raise ValueError(f"repository scope is empty: {scope}")
    target = (repo_root.resolve() / Path(normalized)).resolve()
    try:
        target.relative_to(repo_root.resolve())
    except ValueError as exc:
        raise ValueError(f"path escapes repository: {scope}") from exc
    return normalized, explicit_directory or target.is_dir()


def repo_path_matches_scope(path: str, scope: str, repo_root: Path) -> bool:
    """Match an actual file against one safe file, glob, or directory scope."""

    actual = canonical_repo_path(path, repo_root, reject_outside=True)
    declared, directory = canonical_repo_scope(scope, repo_root)
    if actual == declared:
        return True
    if any(character in declared for character in "*?["):
        return fnmatch.fnmatchcase(actual, declared)
    return directory and actual.startswith(declared.rstrip("/") + "/")


def estimate_tokens(text: str) -> int:
    return max(1, (len(text) + 3) // 4)


def split_identifier_text(text: str) -> str:
    out: list[str] = []
    prev = ""
    for char in text:
        if char in "_-./\\":
            out.append(" ")
        elif prev and char.isupper() and (prev.islower() or prev.isdigit()):
            out.append(" ")
            out.append(char.lower())
        else:
            out.append(char.lower())
        prev = char
    return "".join(out)
