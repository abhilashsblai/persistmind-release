from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any

ACTIONABLE_METADATA_KEYS = frozenset(
    {
        "code_interface",
        "decision",
        "external_evidence",
        "identifiers",
        "reusable_fact",
        "root_cause",
        "steps",
    }
)

GENERIC_COMPLETION_PHRASES = (
    "task completed with pass",
    "task completed successfully",
    "completed with pass",
    "outcome pass",
)

_IDENTIFIER_RE = re.compile(
    r"\b(?:[a-z]+_[a-z0-9_]+|[A-Z][A-Za-z0-9]*[A-Z][A-Za-z0-9]*|"
    r"[a-zA-Z_][\w]*\.[a-zA-Z_][\w.]*|[a-zA-Z_][\w]*\(\))\b"
)


def actionable_memory_content(
    *,
    summary: str | None = None,
    assertion: str | None = None,
    metadata: Mapping[str, Any] | None = None,
) -> bool:
    data = dict(metadata or {})
    if any(data.get(key) for key in ACTIONABLE_METADATA_KEYS):
        return True
    text = " ".join(str(item or "") for item in (summary, assertion)).strip()
    return bool(_IDENTIFIER_RE.search(text))


def is_generic_completion_episode(record: Mapping[str, Any]) -> bool:
    if str(record.get("type") or "") != "episode":
        return False
    text = _record_text(record).casefold()
    if not any(phrase in text for phrase in GENERIC_COMPLETION_PHRASES):
        return False
    metadata = record.get("metadata")
    metadata_map = metadata if isinstance(metadata, Mapping) else {}
    return not actionable_memory_content(
        summary=str(record.get("summary") or ""),
        assertion=str(record.get("assertion") or ""),
        metadata=metadata_map,
    )


def _record_text(record: Mapping[str, Any]) -> str:
    parts = [
        str(record.get("title") or ""),
        str(record.get("summary") or ""),
        str(record.get("assertion") or ""),
    ]
    metadata = record.get("metadata")
    if isinstance(metadata, Mapping):
        parts.extend(str(value) for value in metadata.values() if isinstance(value, str))
    return " ".join(part for part in parts if part)
