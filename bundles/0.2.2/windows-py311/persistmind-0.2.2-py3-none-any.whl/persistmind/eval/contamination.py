from __future__ import annotations

from collections.abc import Iterable, Mapping
from datetime import UTC, datetime
from typing import Any

# Benchmark honesty. Static benchmark cases that predate a model's training cutoff may be
# memorized, inflating scores (SWE-rebench, arXiv:2505.20411). We tag each case by whether its
# source commit is AFTER the agent/judge model cutoff (clean) or BEFORE (possibly contaminated),
# and auto-score task quality so lift attribution is measured on clean, strong-oracle ground
# truth. Pure functions — timestamps are passed in, never read from the clock here.


def _parse(date: str | None) -> datetime | None:
    if not date:
        return None
    text = str(date).strip().replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        # Fall back to date-only.
        try:
            parsed = datetime.strptime(text[:10], "%Y-%m-%d")
        except ValueError:
            return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed


def classify_contamination(commit_date: str | None, model_cutoff: str | None) -> str:
    """Return 'clean_post_cutoff', 'possibly_contaminated', or 'unknown'."""
    commit = _parse(commit_date)
    cutoff = _parse(model_cutoff)
    if commit is None or cutoff is None:
        return "unknown"
    return "clean_post_cutoff" if commit > cutoff else "possibly_contaminated"


def annotate_cases(
    cases: Iterable[Mapping[str, Any]],
    *,
    model_cutoff: str | None,
    date_key: str = "source_commit_date",
) -> list[dict[str, Any]]:
    """Attach a contamination tag and a task-quality score to each benchmark case."""
    annotated: list[dict[str, Any]] = []
    for case in cases:
        contamination = classify_contamination(case.get(date_key), model_cutoff)
        annotated.append(
            {
                **case,
                "contamination": contamination,
                "quality": score_case_quality(case),
            }
        )
    return annotated


def holdout_is_clean(
    cases: Iterable[Mapping[str, Any]],
    *,
    split_key: str = "split",
    contamination_key: str = "contamination",
) -> dict[str, Any]:
    """Verify the holdout split contains no possibly-contaminated cases."""
    holdout = [c for c in cases if str(c.get(split_key)) == "holdout"]
    contaminated = [c for c in holdout if c.get(contamination_key) == "possibly_contaminated"]
    return {
        "ok": not contaminated,
        "holdout_cases": len(holdout),
        "contaminated_holdout": len(contaminated),
        "reason": "holdout_clean" if not contaminated else "holdout_contaminated",
    }


def score_case_quality(case: Mapping[str, Any]) -> dict[str, Any]:
    """Heuristic task-quality / oracle-strength score (SWE-rebench-style auto-annotation).

    Strong cases have a clear task description, a concrete expected-files oracle, and an
    executable test command. Weak-oracle cases should be dropped so lift attribution is clean.
    """
    reasons: list[str] = []
    score = 0.0
    task = str(case.get("task") or "")
    if len(task.strip()) >= 12:
        score += 0.34
    else:
        reasons.append("task_too_short")
    expected = case.get("expected_files") or []
    if isinstance(expected, list) and expected:
        score += 0.33
    else:
        reasons.append("no_expected_files")
    if str(case.get("test_command") or "").strip():
        score += 0.33
    else:
        reasons.append("no_test_command")
    score = round(score, 4)
    return {
        "score": score,
        "strong_oracle": score >= 0.66,
        "weaknesses": reasons,
    }
