from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any

from persistmind.parsing.tree_sitter_registry import status as tree_sitter_status
from persistmind.semantic.extractors import SemanticGraphBuilder
from persistmind.utils import canonical_json


NODE_THRESHOLDS = {
    "service_boundary": {"precision": 0.9, "recall": 0.9},
    "api_contract": {"precision": 0.85, "recall": 0.85},
    "data_entity": {"precision": 0.85, "recall": 0.85},
    "overall": {"precision": 0.85, "recall": 0.85},
}

EDGE_THRESHOLDS = {
    "frontend_consumer": {"precision": 0.8, "recall": 0.8},
    "overall": {"precision": 0.8, "recall": 0.8},
}


class GraphAccuracyHarness:
    def __init__(self, repo_root: Path, store: Any):
        self.repo_root = repo_root
        self.store = store

    def run(self, *, repo_id: str, fixtures: str | Path | None = None) -> dict[str, Any]:
        fixture_root = Path(fixtures) if fixtures else self.repo_root / "eval" / "graph"
        if not fixture_root.is_absolute():
            fixture_root = self.repo_root / fixture_root
        fixture_reports = []
        totals = _empty_totals()
        backend_totals: dict[str, dict[str, Any]] = defaultdict(_empty_totals)
        for fixture in _fixture_dirs(fixture_root):
            report = self._run_fixture(fixture)
            fixture_reports.append(report)
            _merge_totals(totals, report["raw_counts"])
            _merge_totals(backend_totals[report["parser_backend"]], report["raw_counts"])

        metrics = _summarize_totals(totals)
        metrics["by_parser_backend"] = {
            backend: _summarize_totals(raw) for backend, raw in sorted(backend_totals.items())
        }
        metrics["fixture_count"] = len(fixture_reports)
        passed = gate_graph_accuracy({"metrics": metrics})["ok"]
        run_id = self.store.write_semantic_accuracy_run(
            repo_id=repo_id,
            fixture_set=str(fixture_root),
            metrics=metrics,
            passed=passed,
        )
        return {
            "ok": True,
            "schema_version": "persistmind.semantic_accuracy.v1",
            "repo_id": repo_id,
            "fixture_set": str(fixture_root),
            "accuracy_run_id": run_id,
            "passed": passed,
            "metrics": metrics,
            "fixtures": fixture_reports,
            "gate": gate_graph_accuracy({"metrics": metrics}),
        }

    def _run_fixture(self, fixture: Path) -> dict[str, Any]:
        meta = _load_json(fixture / "meta.json")
        expected = _load_json(fixture / "expected.json")
        repo = fixture / "repo"
        parser = _parser_status()
        fixture_id = str(expected.get("fixture_id") or meta.get("fixture_id") or fixture.name)
        paths = [
            str(path.relative_to(repo)).replace("\\", "/")
            for path in sorted(repo.rglob("*"))
            if path.is_file()
            and ".persistmind" not in path.parts
            and ".persistmind" not in path.parts
        ]
        builder = SemanticGraphBuilder(repo, fixture_id)
        nodes, edges, _evidence = builder.scan_files(paths)
        raw_counts = _score_fixture(expected, nodes, edges)
        return {
            "fixture_id": fixture_id,
            "description": meta.get("description", ""),
            "parser_backend": parser["backend"],
            "parser_requirement": meta.get("parser_requirement", "any"),
            "raw_counts": raw_counts,
            "metrics": _summarize_totals(raw_counts),
            "inferred": {
                "nodes": len(nodes),
                "edges": len(edges),
            },
        }


def gate_graph_accuracy(report: dict[str, Any]) -> dict[str, Any]:
    metrics = report.get("metrics") or {}
    failures: list[dict[str, Any]] = []
    nodes = metrics.get("nodes", {})
    edges = metrics.get("edges", {})
    for segment, thresholds in NODE_THRESHOLDS.items():
        actual = nodes.get(segment, {})
        for key, threshold in thresholds.items():
            if float(actual.get(key) or 0.0) < threshold:
                failures.append(
                    {
                        "kind": "node",
                        "segment": segment,
                        "metric": key,
                        "actual": actual.get(key, 0.0),
                        "threshold": threshold,
                    }
                )
    for segment, thresholds in EDGE_THRESHOLDS.items():
        actual = edges.get(segment, {})
        for key, threshold in thresholds.items():
            if float(actual.get(key) or 0.0) < threshold:
                failures.append(
                    {
                        "kind": "edge",
                        "segment": segment,
                        "metric": key,
                        "actual": actual.get(key, 0.0),
                        "threshold": threshold,
                    }
                )
    return {
        "ok": not failures,
        "schema_version": "persistmind.semantic_accuracy_gate.v1",
        "failures": failures,
    }


def _score_fixture(
    expected: dict[str, Any],
    nodes: list[dict[str, Any]],
    edges: list[dict[str, Any]],
) -> dict[str, Any]:
    expected_nodes = {_node_match_key(item) for item in expected.get("nodes", [])}
    inferred_nodes = {_node_match_key(item) for item in nodes}
    node_types = {
        "service_boundary",
        "api_contract",
        "data_entity",
        *{key.split(":", 1)[0] for key in expected_nodes | inferred_nodes},
    }
    by_id = {node["node_id"]: _node_match_key(node) for node in nodes}
    expected_edges = {_edge_match_key(item) for item in expected.get("edges", [])}
    inferred_edges = {
        _edge_match_key(
            {
                "kind": edge["kind"],
                "src_match_key": by_id.get(edge["src_node_id"], ""),
                "dst_match_key": by_id.get(edge["dst_node_id"], ""),
                "category": (edge.get("metadata") or {}).get("category")
                or ("boundary" if edge["kind"] == "owns_boundary" else edge["kind"]),
            }
        )
        for edge in edges
        if by_id.get(edge["src_node_id"]) and by_id.get(edge["dst_node_id"])
    }
    edge_categories = {
        "frontend_consumer",
        *{key.rsplit(":", 1)[-1] for key in expected_edges | inferred_edges},
    }
    raw = _empty_totals()
    for node_type in node_types:
        exp = {key for key in expected_nodes if key.startswith(f"{node_type}:")}
        inf = {key for key in inferred_nodes if key.startswith(f"{node_type}:")}
        raw["nodes"][node_type] = _counts(exp, inf)
    raw["nodes"]["overall"] = _counts(expected_nodes, inferred_nodes)
    for category in edge_categories:
        exp = {key for key in expected_edges if key.endswith(f":{category}")}
        inf = {key for key in inferred_edges if key.endswith(f":{category}")}
        raw["edges"][category] = _counts(exp, inf)
    raw["edges"]["overall"] = _counts(expected_edges, inferred_edges)
    return raw


def _empty_totals() -> dict[str, dict[str, dict[str, int]]]:
    return {"nodes": {}, "edges": {}}


def _merge_totals(target: dict[str, Any], incoming: dict[str, Any]) -> None:
    for section in ("nodes", "edges"):
        for segment, counts in incoming.get(section, {}).items():
            bucket = target[section].setdefault(segment, {"tp": 0, "fp": 0, "fn": 0})
            bucket["tp"] += int(counts.get("tp", 0))
            bucket["fp"] += int(counts.get("fp", 0))
            bucket["fn"] += int(counts.get("fn", 0))


def _summarize_totals(raw: dict[str, Any]) -> dict[str, Any]:
    return {
        section: {segment: _metrics(counts) for segment, counts in sorted(values.items())}
        for section, values in raw.items()
    }


def _counts(expected: set[str], inferred: set[str]) -> dict[str, int]:
    return {
        "tp": len(expected & inferred),
        "fp": len(inferred - expected),
        "fn": len(expected - inferred),
    }


def _metrics(counts: dict[str, int]) -> dict[str, Any]:
    tp = int(counts.get("tp", 0))
    fp = int(counts.get("fp", 0))
    fn = int(counts.get("fn", 0))
    precision = tp / (tp + fp) if tp + fp else 1.0
    recall = tp / (tp + fn) if tp + fn else 1.0
    f1 = (2 * precision * recall / (precision + recall)) if precision + recall else 0.0
    return {
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "precision": round(precision, 6),
        "recall": round(recall, 6),
        "f1": round(f1, 6),
    }


def _fixture_dirs(root: Path) -> list[Path]:
    return [
        path
        for path in sorted(root.iterdir())
        if path.is_dir() and (path / "repo").is_dir() and (path / "expected.json").exists()
    ]


def _node_match_key(item: dict[str, Any]) -> str:
    if item.get("match_key"):
        return _normalize_key(str(item["match_key"]))
    return _normalize_key(f"{item['node_type']}:{item['name']}")


def _edge_match_key(item: dict[str, Any]) -> str:
    return _normalize_key(
        ":".join(
            [
                str(item.get("kind", "")),
                str(item.get("src_match_key", "")),
                str(item.get("dst_match_key", "")),
                str(item.get("category", "uncategorized")),
            ]
        )
    )


def _normalize_key(value: str) -> str:
    return " ".join(value.lower().replace("\\", "/").split())


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _parser_status() -> dict[str, Any]:
    current = tree_sitter_status()
    return {
        "backend": "tree_sitter" if current.available else "regex_fallback",
        "tree_sitter_available": current.available,
        "tree_sitter_languages": current.languages,
        "fallback": not current.available,
        "error": current.error,
        "calibration_fingerprint": canonical_json(current.languages),
    }
