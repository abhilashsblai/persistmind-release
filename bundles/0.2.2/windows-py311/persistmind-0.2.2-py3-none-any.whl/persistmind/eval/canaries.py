from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

DEFAULT_CANARIES_PATH = "eval/canaries.json"


def load_canaries(repo_root: Path, *, path: str = DEFAULT_CANARIES_PATH) -> dict[str, Any]:
    """Load the reward-hacking canary signatures. Returns an empty spec if absent."""
    canary_path = repo_root / path
    if not canary_path.is_file():
        return {"schema_version": "persistmind.canaries.v1", "diff_signatures": []}
    try:
        data = json.loads(canary_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {"schema_version": "persistmind.canaries.v1", "diff_signatures": []}
    return data if isinstance(data, dict) else {"diff_signatures": []}


def check_diff_canaries(diff: str, canaries: dict[str, Any]) -> dict[str, Any]:
    """Scan a unified diff for metric-gaming signatures.

    Returns ``{"ok": bool, "flagged": [...]}``. ``ok`` is False when any signature matches,
    meaning the change is taking a gaming path rather than genuinely improving.
    """
    flagged: list[dict[str, Any]] = []
    signatures = canaries.get("diff_signatures") or []
    for signature in signatures:
        if not isinstance(signature, dict):
            continue
        patterns = signature.get("patterns") or []
        matched: list[str] = []
        for pattern in patterns:
            if not isinstance(pattern, str):
                continue
            try:
                if re.search(pattern, diff, re.MULTILINE):
                    matched.append(pattern)
            except re.error:
                continue
        if matched:
            flagged.append(
                {
                    "id": signature.get("id"),
                    "reason": signature.get("reason"),
                    "matched_patterns": matched,
                }
            )
    return {"ok": not flagged, "flagged": flagged}


def check_selfmod_canaries(
    repo_root: Path,
    diff: str,
    *,
    path: str = DEFAULT_CANARIES_PATH,
) -> dict[str, Any]:
    """Convenience wrapper: load canaries and check a self-mod diff against them."""
    canaries = load_canaries(repo_root, path=path)
    result = check_diff_canaries(diff, canaries)
    result["reason"] = "canaries_clear" if result["ok"] else "reward_hacking_canary_triggered"
    return result
