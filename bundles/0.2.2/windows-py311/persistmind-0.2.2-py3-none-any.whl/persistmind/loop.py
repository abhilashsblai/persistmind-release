from __future__ import annotations

import json
from typing import Any


CORE_LOOP_DEFINITION_OF_DONE = [
    "pack is created for the task before edits",
    "task session is started and tied to the pack",
    "structured plan is created before coding",
    "changed files are checkpointed against the active plan step",
    "diff is checked against the served pack",
    "impact report is generated from the final diff",
    "declared or impact-selected tests are run",
    "outcome is recorded against the pack",
    "session memory can explain the task, pack, plan, verification, and outcome",
]


def core_loop_runbook(
    *,
    task: str,
    paths: list[str],
    tests: list[str] | None = None,
    result: str = "pass",
) -> dict[str, Any]:
    normalized_paths = sorted({_normalize_path(path) for path in paths if path.strip()})
    if not normalized_paths:
        raise ValueError("loop runbook requires at least one --path")
    normalized_tests = sorted({test.strip() for test in (tests or []) if test.strip()})
    if not normalized_tests:
        normalized_tests = ["python -m pytest -q"]
    plan = {
        "objective": task,
        "steps": [
            {
                "id": "edit",
                "title": "Implement the requested change",
                "intended_files": normalized_paths,
                "intended_tests": normalized_tests,
                "capabilities": ["edit_source", "run_tests"],
                "risk": "medium",
            }
        ],
    }
    plan_json = json.dumps(plan, indent=2, sort_keys=True)
    checkpoint_args = " ".join(f"--path {_ps_quote(path)}" for path in normalized_paths)
    test_commands = [
        {"name": f"test-{index}", "command": command}
        for index, command in enumerate(normalized_tests, start=1)
    ]
    commands = [
        {"name": "set-task", "command": "$task = @'\n" + task + "\n'@"},
        {
            "name": "pack",
            "command": "$pack = persistmind --repo . pack --task $task | ConvertFrom-Json",
        },
        {
            "name": "task-start",
            "command": (
                "$taskSession = persistmind --repo . task start --task $task | ConvertFrom-Json"
            ),
        },
        {
            "name": "write-plan",
            "command": (
                "$planPath = Join-Path $env:TEMP 'persistmind-plan.json'\n"
                "$planJson = @'\n" + plan_json + "\n'@\n"
                "$planJson | Set-Content -Path $planPath -Encoding ascii"
            ),
        },
        {
            "name": "plan-create",
            "command": (
                "$plan = persistmind --repo . plan create "
                "--task-session-id $taskSession.task_session_id "
                "--pack-id $pack.pack_id --file $planPath | ConvertFrom-Json\n"
                "Remove-Item $planPath -ErrorAction SilentlyContinue"
            ),
        },
        {
            "name": "checkpoint",
            "command": (
                "persistmind --repo . plan checkpoint $plan.plan_id "
                f"--step-id edit {checkpoint_args}"
            ),
        },
        {
            "name": "check-diff",
            "command": "git diff HEAD | persistmind --repo . check-diff --pack-id $pack.pack_id",
        },
        {
            "name": "impact",
            "command": "git diff --name-only HEAD | persistmind --repo . impact --paths-from-stdin",
        },
        *test_commands,
        {
            "name": "outcome",
            "command": f"persistmind --repo . outcome --pack-id $pack.pack_id --result {result}",
        },
        {
            "name": "session-explain",
            "command": (
                "persistmind --repo . session explain --session-id $taskSession.agent_session_id"
            ),
        },
    ]
    return {
        "ok": True,
        "schema_version": "persistmind.core_loop_runbook.v1",
        "task": task,
        "paths": normalized_paths,
        "tests": normalized_tests,
        "result": result,
        "definition_of_done": CORE_LOOP_DEFINITION_OF_DONE,
        "plan_template": plan,
        "shell": "powershell",
        "manual_fixups_required": False,
        "commands": commands,
    }


def _normalize_path(path: str) -> str:
    return path.strip().replace("\\", "/")


def _ps_quote(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"
