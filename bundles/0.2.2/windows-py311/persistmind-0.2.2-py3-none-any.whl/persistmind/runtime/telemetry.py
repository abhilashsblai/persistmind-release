from __future__ import annotations

import hashlib
import json
import time
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any


TELEMETRY_SCHEMA_VERSION = "persistmind.operational_telemetry.v1"
METRIC_SUMMARY_SCHEMA_VERSION = "persistmind.operational_metric_summary.v1"
HEALTH_SCHEMA_VERSION = "persistmind.dependency_health.v1"
RETENTION_SCHEMA_VERSION = "persistmind.telemetry_retention.v1"

_REDACTED = "[redacted]"
_SECRET_TOKENS = (
    "api_key",
    "authorization",
    "bearer",
    "client_secret",
    "credential",
    "password",
    "private_key",
    "secret",
    "signing_key",
    "token",
)
_MAX_STRING = 512
_MAX_LIST_ITEMS = 32
_MAX_MAPPING_ITEMS = 64


@dataclass(frozen=True)
class TelemetryEvent:
    name: str
    operation_id: str
    correlation_id: str
    status: str
    metrics: Mapping[str, float] = field(default_factory=dict)
    details: Mapping[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": TELEMETRY_SCHEMA_VERSION,
            "name": self.name,
            "operation_id": self.operation_id,
            "correlation_id": self.correlation_id,
            "status": self.status,
            "timestamp": self.timestamp,
            "metrics": numeric_metrics(self.metrics),
            "details": redact(self.details),
        }


def event(
    name: str,
    *,
    operation_id: str | None = None,
    correlation_id: str | None = None,
    status: str = "ok",
    metrics: Mapping[str, Any] | None = None,
    details: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Return a bounded, redacted event suitable for logs or JSON results."""

    stable_operation_id = operation_id or _stable_id(name, status, details or {})
    return TelemetryEvent(
        name=name,
        operation_id=stable_operation_id,
        correlation_id=correlation_id or stable_operation_id,
        status=status,
        metrics=numeric_metrics(metrics or {}),
        details=details or {},
    ).as_dict()


def metric_summary(
    name: str,
    samples: list[float] | tuple[float, ...],
    *,
    budget: float | None = None,
) -> dict[str, Any]:
    values = sorted(float(item) for item in samples)
    if not values:
        raise ValueError("metric summary requires at least one sample")
    p95_index = min(len(values) - 1, int((len(values) - 1) * 0.95))
    summary: dict[str, Any] = {
        "schema_version": METRIC_SUMMARY_SCHEMA_VERSION,
        "name": name,
        "samples": len(values),
        "min": values[0],
        "max": values[-1],
        "median": values[len(values) // 2],
        "p95": values[p95_index],
    }
    if budget is not None:
        summary["budget"] = float(budget)
        summary["ok"] = values[p95_index] <= float(budget)
    return summary


def dependency_health(dependencies: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
    rows = {
        str(name): {
            "ok": bool(value.get("ok")),
            "status": str(value.get("status") or ("ok" if value.get("ok") else "unhealthy")),
            "detail": redact(value.get("detail") or {}),
        }
        for name, value in sorted(dependencies.items())
    }
    unhealthy = [name for name, value in rows.items() if not value["ok"]]
    return {
        "schema_version": HEALTH_SCHEMA_VERSION,
        "ok": not unhealthy,
        "status": "healthy" if not unhealthy else "degraded",
        "dependencies": rows,
        "unhealthy": unhealthy,
    }


def retention_summary(records: list[Mapping[str, Any]], *, max_records: int) -> dict[str, Any]:
    if max_records < 1:
        raise ValueError("max_records must be positive")
    retained = records[-max_records:]
    return {
        "schema_version": RETENTION_SCHEMA_VERSION,
        "ok": True,
        "status": "bounded",
        "input_records": len(records),
        "retained_records": len(retained),
        "dropped_records": max(0, len(records) - len(retained)),
        "records": [redact(record) for record in retained],
    }


def numeric_metrics(values: Mapping[str, Any]) -> dict[str, float]:
    metrics: dict[str, float] = {}
    for key, value in values.items():
        if isinstance(value, bool):
            metrics[str(key)] = 1.0 if value else 0.0
        elif isinstance(value, int | float):
            metrics[str(key)] = float(value)
    return metrics


def redact(value: Any) -> Any:
    if isinstance(value, Mapping):
        output: dict[str, Any] = {}
        for index, (key, item) in enumerate(value.items()):
            if index >= _MAX_MAPPING_ITEMS:
                output["_truncated"] = True
                break
            key_text = str(key)
            output[key_text] = _REDACTED if _sensitive_key(key_text) else redact(item)
        return output
    if isinstance(value, list | tuple | set | frozenset):
        items = list(value)
        redacted_items = [redact(item) for item in items[:_MAX_LIST_ITEMS]]
        if len(items) > _MAX_LIST_ITEMS:
            redacted_items.append({"_truncated": True})
        return redacted_items
    if isinstance(value, str):
        if _looks_secret(value):
            return _REDACTED
        return value if len(value) <= _MAX_STRING else value[:_MAX_STRING] + "...[truncated]"
    if isinstance(value, int | float | bool) or value is None:
        return value
    return str(value)[:_MAX_STRING]


def _sensitive_key(key: str) -> bool:
    lowered = key.lower().replace("-", "_")
    return any(token in lowered for token in _SECRET_TOKENS)


def _looks_secret(value: str) -> bool:
    lowered = value.lower()
    if any(token in lowered for token in ("bearer ", "-----begin private key-----")):
        return True
    return (
        len(value) >= 40
        and any(char.isdigit() for char in value)
        and any(char.isalpha() for char in value)
    )


def _stable_id(*parts: Any) -> str:
    return hashlib.sha256(json.dumps(redact(parts), sort_keys=True).encode()).hexdigest()[:32]
