from __future__ import annotations

from pathlib import Path
from typing import Any


def load(path: Path) -> list[dict[str, Any]]:
    text = path.read_text(encoding="utf-8", errors="replace")
    return [
        {
            "title": "CI failure",
            "message": text[:1000],
            "path": None,
            "severity": "medium",
        }
    ]
