from __future__ import annotations

import hashlib
import json
import os
import signal
import sys
import threading
import time
from collections.abc import Callable
from contextlib import AbstractContextManager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, cast

from persistmind.runtime.telemetry import event, metric_summary

_ACTIVE_OPERATION_METADATA: dict[str, dict[str, Any]] = {}
_ACTIVE_OPERATION_METADATA_LOCK = threading.Lock()


class OperationBusyError(RuntimeError):
    def __init__(self, operation: str, owner: dict[str, Any]):
        super().__init__(f"{operation} is already owned by pid {owner.get('pid', 'unknown')}")
        self.operation = operation
        self.owner = owner

    def as_result(self) -> dict[str, Any]:
        started = float(self.owner.get("started_monotonic") or 0.0)
        elapsed = max(0.0, time.monotonic() - started) if started else None
        metrics = {"elapsed_seconds": elapsed or 0.0, "active_owner": 1.0}
        return {
            "ok": False,
            "status": "operation_busy",
            "operation": self.operation,
            "owner": self.owner,
            "elapsed_seconds": elapsed,
            "deadline_at": self.owner.get("deadline_at"),
            "telemetry": event(
                "operation_busy",
                operation_id=str(self.owner.get("operation_id") or self.operation),
                correlation_id=str(self.owner.get("scope") or self.operation),
                status="operation_busy",
                metrics=metrics,
                details={"operation": self.operation, "owner": self.owner},
            ),
            "retryable": True,
            "remediation": "wait for the owner to finish, then retry; do not kill it automatically",
            "schema_version": "persistmind.operation_result.v1",
        }


class OperationTimeoutError(TimeoutError):
    def __init__(self, stage: str, elapsed: float, limit: float):
        super().__init__(f"{stage} exceeded its {limit:.3f}s deadline")
        self.stage = stage
        self.elapsed = elapsed
        self.limit = limit

    def as_result(self) -> dict[str, Any]:
        return {
            "ok": False,
            "status": "timeout",
            "stage": self.stage,
            "elapsed_seconds": self.elapsed,
            "limit_seconds": self.limit,
            "telemetry": event(
                "operation_timeout",
                operation_id=self.stage,
                correlation_id=self.stage,
                status="timeout",
                metrics={"elapsed_seconds": self.elapsed, "limit_seconds": self.limit},
                details={"stage": self.stage},
            ),
            "retryable": True,
            "remediation": "retry with an explicit larger timeout after checking operation status",
            "schema_version": "persistmind.operation_result.v1",
        }


@dataclass
class Deadline:
    timeout_seconds: float
    operation: str = "operation"
    started_monotonic: float = field(default_factory=time.monotonic)
    _cancelled: threading.Event = field(default_factory=threading.Event)
    _cancel_reason: str = "cancelled"

    @property
    def limit(self) -> float:
        return max(0.0, float(self.timeout_seconds))

    @property
    def expires_monotonic(self) -> float:
        return self.started_monotonic + self.limit

    @property
    def cleanup_allowance(self) -> float:
        return min(5.0, self.limit * 0.1)

    def remaining(self) -> float:
        return max(0.0, self.expires_monotonic - time.monotonic())

    def expired(self) -> bool:
        return self._cancelled.is_set() or time.monotonic() >= self.expires_monotonic

    def cancel(self, reason: str = "cancelled") -> None:
        self._cancel_reason = reason
        self._cancelled.set()

    def check(self, stage: str | None = None) -> None:
        if not self.expired():
            return
        elapsed = time.monotonic() - self.started_monotonic
        raise OperationTimeoutError(stage or self._cancel_reason, elapsed, self.limit)

    def sqlite_progress_handler(self, stage: str) -> Callable[[], int]:
        def progress() -> int:
            if self.expired():
                self._cancel_reason = stage
                return 1
            return 0

        return progress


class OperationCoordinator(AbstractContextManager["OperationCoordinator"]):
    """Cross-process single-flight lock independent of workspace SQLite health.

    Repair, source indexing, deep maintenance, and full graph rebuild share one
    workspace-long lock. Incremental graph work can use a branch-specific scope.
    """

    _WORKSPACE_EXCLUSIVE = {"repair", "index", "maintenance", "graph_rebuild"}

    def __init__(
        self,
        operations_dir: Path,
        operation: str,
        *,
        scope: str | None = None,
        timeout_seconds: float = 0.0,
        deadline_seconds: float | None = None,
        command: str | None = None,
    ):
        self.operations_dir = operations_dir
        self.operation = operation
        self.scope = scope
        self.timeout_seconds = max(0.0, timeout_seconds)
        self.deadline_seconds = deadline_seconds
        self.command = command or " ".join(sys.argv)
        lock_name = self._lock_name(operation, scope)
        self.path = operations_dir / f"{lock_name}.lock"
        self.handle: Any | None = None
        self.metadata: dict[str, Any] = {}

    def __enter__(self) -> OperationCoordinator:
        self.operations_dir.mkdir(parents=True, exist_ok=True)
        self.handle = self.path.open("a+", encoding="utf-8")
        acquire_deadline = time.monotonic() + self.timeout_seconds
        while True:
            try:
                _lock(self.handle)
                started_monotonic = time.monotonic()
                started_at = time.time()
                operation_id = hashlib.sha256(
                    f"{self.operation}:{os.getpid()}:{started_at}".encode()
                ).hexdigest()
                self.metadata = {
                    "operation_id": operation_id,
                    "operation": self.operation,
                    "scope": self.scope,
                    "pid": os.getpid(),
                    "process_start_fingerprint": _process_fingerprint(),
                    "command": self.command,
                    "started_at": started_at,
                    "started_monotonic": started_monotonic,
                    "deadline_at": (
                        started_at + float(self.deadline_seconds)
                        if self.deadline_seconds is not None
                        else None
                    ),
                    "lock_path": str(self.path),
                }
                self.handle.seek(0)
                self.handle.truncate()
                json.dump(self.metadata, self.handle, sort_keys=True)
                self.handle.flush()
                os.fsync(self.handle.fileno())
                with _ACTIVE_OPERATION_METADATA_LOCK:
                    _ACTIVE_OPERATION_METADATA[str(self.path)] = dict(self.metadata)
                return self
            except OSError:
                if time.monotonic() >= acquire_deadline:
                    owner = _read_owner(self.path)
                    self.handle.close()
                    self.handle = None
                    raise OperationBusyError(self.operation, owner)
                time.sleep(0.05)

    def __exit__(self, *_: object) -> None:
        if self.handle is not None:
            with _ACTIVE_OPERATION_METADATA_LOCK:
                _ACTIVE_OPERATION_METADATA.pop(str(self.path), None)
            _unlock(self.handle)
            self.handle.close()
            self.handle = None

    @classmethod
    def _lock_name(cls, operation: str, scope: str | None) -> str:
        if operation in cls._WORKSPACE_EXCLUSIVE:
            return "workspace-long"
        normalized = "".join(
            char if char.isalnum() or char in "-_" else "-" for char in (scope or "global")
        )
        return f"{operation}-{normalized}"


def operations_status(operations_dir: Path) -> dict[str, Any]:
    operations: list[dict[str, Any]] = []
    elapsed_samples: list[float] = []
    if operations_dir.is_dir():
        for path in sorted(operations_dir.glob("*.lock")):
            owner = _read_owner(path)
            if not owner:
                with _ACTIVE_OPERATION_METADATA_LOCK:
                    owner = dict(_ACTIVE_OPERATION_METADATA.get(str(path), {}))
            active = _is_locked(path)
            started = float(owner.get("started_monotonic") or 0.0)
            elapsed = max(0.0, time.monotonic() - started) if active and started else None
            if elapsed is not None:
                elapsed_samples.append(elapsed)
            operations.append(
                {
                    **owner,
                    "active": active,
                    "elapsed_seconds": elapsed,
                    "lock_path": str(path),
                }
            )
    active_count = sum(bool(item.get("active")) for item in operations)
    metrics = {
        "active_count": float(active_count),
        "known_operations": float(len(operations)),
    }
    telemetry = event(
        "operations_status",
        operation_id="operations_status",
        correlation_id="operations",
        status="ok",
        metrics=metrics,
        details={"operations": operations},
    )
    summaries = []
    if elapsed_samples:
        summaries.append(metric_summary("operation_elapsed_seconds", elapsed_samples))
    return {
        "ok": True,
        "status": "ok",
        "active_count": active_count,
        "operations": operations,
        "metrics": metrics,
        "metric_summaries": summaries,
        "telemetry": telemetry,
        "schema_version": "persistmind.operation_status.v1",
    }


class SignalCancellation(AbstractContextManager["SignalCancellation"]):
    def __init__(self, deadline: Deadline):
        self.deadline = deadline
        self._previous: dict[int, Any] = {}

    def __enter__(self) -> SignalCancellation:
        if threading.current_thread() is not threading.main_thread():
            return self
        for signum in (signal.SIGINT, signal.SIGTERM):
            self._previous[signum] = signal.getsignal(signum)
            signal.signal(signum, self._handle)
        return self

    def __exit__(self, *_: object) -> None:
        for signum, handler in self._previous.items():
            signal.signal(signum, handler)
        self._previous.clear()

    def _handle(self, signum: int, _frame: Any) -> None:
        self.deadline.cancel(f"signal_{signum}")


def _process_fingerprint() -> str:
    return hashlib.sha256(f"{os.getpid()}:{sys.executable}".encode()).hexdigest()[:16]


def _read_owner(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8") or "{}")
    except (OSError, json.JSONDecodeError):
        with _ACTIVE_OPERATION_METADATA_LOCK:
            return dict(_ACTIVE_OPERATION_METADATA.get(str(path), {}))


def _is_locked(path: Path) -> bool:
    try:
        with path.open("a+", encoding="utf-8") as handle:
            _lock(handle)
            _unlock(handle)
        return False
    except OSError:
        return True


def _lock(handle: Any) -> None:
    if os.name == "nt":
        import msvcrt

        handle.seek(0)
        if not handle.read(1):
            handle.write(" ")
            handle.flush()
        handle.seek(0)
        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
    else:
        import fcntl

        fcntl_module = cast(Any, fcntl)
        fcntl_module.flock(handle.fileno(), fcntl_module.LOCK_EX | fcntl_module.LOCK_NB)


def _unlock(handle: Any) -> None:
    if os.name == "nt":
        import msvcrt

        handle.seek(0)
        msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
    else:
        import fcntl

        fcntl_module = cast(Any, fcntl)
        fcntl_module.flock(handle.fileno(), fcntl_module.LOCK_UN)
