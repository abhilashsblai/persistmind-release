from .resolver import SnapshotInfo

__all__ = ["SnapshotInfo"]
