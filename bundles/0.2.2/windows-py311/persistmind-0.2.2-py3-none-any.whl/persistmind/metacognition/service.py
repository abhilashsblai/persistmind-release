from __future__ import annotations

from pathlib import Path
from typing import Any

from persistmind.config import load_settings

from .controller import MetacognitiveController


class MetacognitionService:
    """Catalog adapter for the pure metacognitive state calculation."""

    def __init__(self, repo_root: Path, *, read_only: bool = False) -> None:
        self.repo_root = repo_root.resolve()
        self.read_only = read_only
        self.settings = load_settings(self.repo_root)

    def close(self) -> None:
        return None

    def __enter__(self) -> MetacognitionService:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def metacog_state(
        self,
        task: str,
        *,
        paths: list[str] | None = None,
        task_session_id: str | None = None,
    ) -> dict[str, Any]:
        signals = {
            "path_count": len(paths or []),
            "has_task_session": bool(task_session_id),
            "task_length": len(task.strip()),
        }
        return MetacognitiveController(self.settings.metacognition).tick(
            task=task,
            checkpoint="explicit_state_query",
            signals=signals,
            task_session_id=task_session_id,
        )
