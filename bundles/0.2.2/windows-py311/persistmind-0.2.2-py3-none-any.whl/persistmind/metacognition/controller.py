from __future__ import annotations

from typing import Any

from persistmind.config import MetacognitionConfig
from persistmind.utils import stable_id

from .clarify import decide_resolution
from .state import classify_state
from .uncertainty import compute_uncertainty


class MetacognitiveController:
    def __init__(self, config: MetacognitionConfig):
        self.config = config

    def tick(
        self,
        *,
        task: str,
        checkpoint: str,
        signals: dict[str, Any],
        task_session_id: str | None = None,
        open_clarification_count: int = 0,
    ) -> dict[str, Any]:
        if not self.config.enabled:
            return {
                "ok": True,
                "active": False,
                "reason": "metacognition_disabled",
                "schema_version": "persistmind.metacognition.v1",
            }
        uncertainty = compute_uncertainty({**signals, "task": task})
        self_state = classify_state(uncertainty, signals)
        resolution = decide_resolution(
            task=task,
            uncertainty=uncertainty,
            self_state=self_state,
            gather_threshold=self.config.uncertainty_threshold_gather,
            ask_threshold=self.config.uncertainty_threshold_ask,
            clarification_budget_remaining=max(
                0, self.config.max_clarifications_per_session - open_clarification_count
            ),
        )
        state_id = stable_id(
            "metacognition",
            task_session_id or "",
            checkpoint,
            task,
            uncertainty["score"],
            resolution["action"],
        )
        return {
            "ok": True,
            "active": True,
            "schema_version": "persistmind.metacognition.v1",
            "state_id": state_id,
            "checkpoint": checkpoint,
            "self_state": self_state,
            "uncertainty": uncertainty["score"],
            "action": resolution["action"],
            "resolvable_by": resolution["resolvable_by"],
            "drivers": uncertainty["drivers"],
            "recommended_next": _recommended_next(resolution["action"]),
            "question": resolution.get("question"),
            "clarification_budget_remaining": max(
                0, self.config.max_clarifications_per_session - open_clarification_count
            ),
            "budget_exhausted": bool(resolution.get("budget_exhausted")),
            "signals": signals,
        }


def _recommended_next(action: str) -> str:
    if action == "ask_human":
        return "Ask the open clarification before writing."
    if action == "gather_more":
        return "Retrieve or search for more grounding before writing."
    if action == "replan":
        return "Revise the active plan before continuing."
    return "Proceed under the current CTX workflow gates."
