from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Sequence
from pathlib import Path
from typing import Any

import anyio

MCP_PROBE_SCHEMA = "persistmind.mcp_activation_probe.v1"
DEFAULT_REQUIRED_TOOLS = ("codex_enforcement_status", "workflow_brief")


def probe_stdio_mcp(
    command: str,
    args: Sequence[str],
    *,
    repo: Path,
    required_tools: Sequence[str] = DEFAULT_REQUIRED_TOOLS,
    timeout_seconds: float = 30.0,
) -> dict[str, Any]:
    """Initialize the exact rendered stdio server and list its real tools."""

    argv = [str(command), *(str(item) for item in args)]
    argv_sha256 = hashlib.sha256(
        json.dumps(argv, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    required = tuple(dict.fromkeys(str(item) for item in required_tools))

    async def _run() -> dict[str, Any]:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        parameters = StdioServerParameters(
            command=str(command),
            args=[str(item) for item in args],
            cwd=repo,
            env={
                **os.environ,
                "PYTHONIOENCODING": "utf-8",
                "PYTHONUTF8": "1",
            },
            encoding="utf-8",
            encoding_error_handler="replace",
        )
        with open(os.devnull, "w", encoding="utf-8") as stderr:
            with anyio.fail_after(timeout_seconds):
                async with stdio_client(parameters, errlog=stderr) as streams:
                    async with ClientSession(*streams) as session:
                        initialized = await session.initialize()
                        listed = await session.list_tools()
        names = sorted(str(tool.name) for tool in listed.tools)
        missing = [name for name in required if name not in names]
        server_info = initialized.serverInfo
        return {
            "schema_version": MCP_PROBE_SCHEMA,
            "ok": not missing,
            "transport": "stdio",
            "argv_sha256": argv_sha256,
            "protocol_version": str(initialized.protocolVersion),
            "server_name": str(server_info.name),
            "server_version": str(server_info.version),
            "tool_count": len(names),
            "required_tools": list(required),
            "missing_tools": missing,
        }

    try:
        return anyio.run(_run)
    except Exception as exc:  # noqa: BLE001 - probes return stable diagnostics
        return {
            "schema_version": MCP_PROBE_SCHEMA,
            "ok": False,
            "transport": "stdio",
            "argv_sha256": argv_sha256,
            "required_tools": list(required),
            "missing_tools": list(required),
            "error": f"mcp_activation_probe_error:{type(exc).__name__}",
        }


__all__ = ["DEFAULT_REQUIRED_TOOLS", "MCP_PROBE_SCHEMA", "probe_stdio_mcp"]
