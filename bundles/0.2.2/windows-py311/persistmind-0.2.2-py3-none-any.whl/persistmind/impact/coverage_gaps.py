from __future__ import annotations

import json
import tomllib
from pathlib import Path
from typing import Any

DEFAULT_MIGRATION_PATH_PATTERNS = ("migrations/", "alembic/", "supabase/migrations/")
DEFAULT_GENERATED_PREFIXES = ("generated/", "src/generated/")
DEFAULT_GENERATED_MARKERS = (
    "@generated",
    "auto-generated",
    "automatically generated",
    "do not edit",
)


def detect_migration_paths(
    paths: list[str],
    *,
    patterns: list[str] | tuple[str, ...] = DEFAULT_MIGRATION_PATH_PATTERNS,
) -> list[str]:
    normalized_patterns = tuple(_normalize_pattern(pattern) for pattern in patterns if pattern)
    return sorted(
        path
        for path in paths
        if any(pattern in path.replace("\\", "/") for pattern in normalized_patterns)
    )


def detect_cli_facade_paths(paths: list[str], repo_root: Path) -> list[str]:
    entry_points = _load_cli_entry_points(repo_root)
    if not entry_points:
        return []
    normalized = {path.replace("\\", "/") for path in paths}
    return sorted(path for path in normalized if path in entry_points)


def detect_generated_client_paths(
    paths: list[str],
    repo_root: Path,
    *,
    prefixes: list[str] | tuple[str, ...] = DEFAULT_GENERATED_PREFIXES,
    markers: list[str] | tuple[str, ...] = DEFAULT_GENERATED_MARKERS,
) -> list[str]:
    normalized_prefixes = tuple(_normalize_pattern(prefix) for prefix in prefixes if prefix)
    normalized_markers = tuple(marker.casefold() for marker in markers if marker)
    result: list[str] = []
    for path in paths:
        normalized = path.replace("\\", "/")
        if any(normalized.startswith(prefix) for prefix in normalized_prefixes):
            result.append(normalized)
            continue
        candidate = repo_root / normalized
        try:
            head = candidate.read_text(encoding="utf-8", errors="ignore")[:4096].casefold()
        except OSError:
            continue
        if any(marker in head for marker in normalized_markers):
            result.append(normalized)
    return sorted(set(result))


def _load_cli_entry_points(repo_root: Path) -> set[str]:
    paths: set[str] = set()
    pyproject = repo_root / "pyproject.toml"
    if pyproject.is_file():
        try:
            data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
        except (OSError, tomllib.TOMLDecodeError):
            data = {}
        scripts = ((data.get("project") or {}).get("scripts") or {})
        if isinstance(scripts, dict):
            for target in scripts.values():
                module = str(target).split(":", 1)[0].replace(".", "/")
                paths.add(f"src/{module}.py")
                paths.add(f"{module}.py")
    package = repo_root / "package.json"
    if package.is_file():
        try:
            data = json.loads(package.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            data = {}
        bin_value: Any = data.get("bin") if isinstance(data, dict) else None
        if isinstance(bin_value, str):
            paths.add(bin_value.replace("\\", "/").lstrip("./"))
        elif isinstance(bin_value, dict):
            for target in bin_value.values():
                paths.add(str(target).replace("\\", "/").lstrip("./"))
    return paths


def _normalize_pattern(pattern: str) -> str:
    return pattern.replace("\\", "/").lstrip("./")
