from __future__ import annotations

from typing import Any, Protocol

from persistmind.snapshot import SnapshotInfo


class ImpactReporter(Protocol):
    def report(
        self,
        *,
        snapshot: SnapshotInfo,
        paths: list[str],
        pack_id: str | None = None,
        business: bool = False,
    ) -> dict[str, Any]:
        ...


__all__ = ["ImpactReporter"]
