from __future__ import annotations

import fnmatch
import json
import re
from pathlib import Path
from typing import Any

from persistmind.config import Settings
from persistmind.branding import (
    CAPABILITIES_FILE,
    resolve_capabilities,
)

BLOCKING_CI_MODES = {"approval_required", "acknowledge_rule", "forbidden"}
BLOCKING_LOCAL_MODES = {"forbidden"}


class CapabilityPolicy:
    def __init__(self, repo_root: Path, settings: Settings):
        self.repo_root = repo_root
        self.settings = settings
        self.path = resolve_capabilities(repo_root)
        self.manifest = _load_manifest(repo_root, settings)
        self.capabilities = self.manifest.get("capabilities", {})

    def check_paths(
        self,
        paths: list[str],
        *,
        deleted_paths: list[str] | None = None,
        task_session_id: str | None = None,
        for_ci: bool = False,
    ) -> dict[str, Any]:
        deleted = {path.replace("\\", "/") for path in deleted_paths or []}
        violations: list[dict[str, Any]] = []
        for path in sorted({item.replace("\\", "/") for item in paths}):
            checks = self._capabilities_for_path(path, deleted)
            for capability in checks:
                rule = self.capabilities.get(capability, {})
                mode = rule.get("mode", "warn")
                if mode == "free":
                    continue
                blocking_modes = BLOCKING_CI_MODES if for_ci else BLOCKING_LOCAL_MODES
                violations.append(
                    {
                        "type": "capability_violation",
                        "capability": capability,
                        "path": path,
                        "mode": mode,
                        "severity": "high" if mode in blocking_modes else "medium",
                        "blocking": mode in blocking_modes,
                        "reason": rule.get("reason") or _default_reason(capability, mode),
                    }
                )
        if self.manifest.get("require_task_session") and not task_session_id:
            mode = self.manifest.get("missing_session_mode", "warn")
            blocking_modes = BLOCKING_CI_MODES if for_ci else BLOCKING_LOCAL_MODES
            violations.append(
                {
                    "type": "missing_task_session",
                    "capability": "task_session",
                    "path": "",
                    "mode": mode,
                    "severity": "high" if mode in blocking_modes else "medium",
                    "blocking": mode in blocking_modes,
                    "reason": "Governance policy requires a task session for this change.",
                }
            )
        return {
            "ok": not any(item["blocking"] for item in violations),
            "violations": violations,
            "capabilities_file": str(self.path),
            "policy": self.manifest,
        }

    def _capabilities_for_path(self, path: str, deleted: set[str]) -> list[str]:
        capabilities = []
        if path in deleted:
            capabilities.append("delete_file")
        if _matches_any(path, self.capabilities.get("edit_critical_path", {}).get("paths", [])):
            capabilities.append("edit_critical_path")
        if _matches_any(path, self.capabilities.get("modify_migration", {}).get("paths", [])):
            capabilities.append("modify_migration")
        if _matches_any(path, self.capabilities.get("modify_ci_config", {}).get("paths", [])):
            capabilities.append("modify_ci_config")
        if _matches_any(path, self.capabilities.get("touch_env_secrets", {}).get("paths", [])):
            capabilities.append("touch_env_secrets")
        if _looks_like_dependency_file(path):
            capabilities.append("add_dependency")
        return sorted(set(capabilities))


def default_capabilities(settings: Settings) -> dict[str, Any]:
    return {
        "schema_version": "persistmind.capabilities.v1",
        "require_task_session": False,
        "missing_session_mode": "warn",
        "goal_governance": {
            "mode": "warn",
            "challenge_min_confidence": 0.6,
        },
        "capabilities": {
            "edit_source": {"mode": "free"},
            "edit_tests": {"mode": "free"},
            "add_dependency": {
                "mode": "warn",
                "paths": [
                    "package.json",
                    "package-lock.json",
                    "pnpm-lock.yaml",
                    "yarn.lock",
                    "pyproject.toml",
                    "requirements*.txt",
                ],
            },
            "modify_migration": {
                "mode": "warn",
                "paths": ["migrations/**", "**/migrations/**"],
            },
            "delete_file": {"mode": "warn"},
            "edit_critical_path": {
                "mode": "warn",
                "paths": settings.ci.critical_paths,
            },
            "modify_ci_config": {
                "mode": "warn",
                "paths": [
                    ".github/**",
                    ".gitlab-ci.yml",
                    "persistmind.toml",
                    CAPABILITIES_FILE,
                ],
            },
            "touch_env_secrets": {
                "mode": "forbidden",
                "paths": [
                    ".env",
                    ".env.*",
                    "**/.env",
                    "**/.env.*",
                    "**/*.pem",
                    "**/*.key",
                ],
            },
            "run_destructive_command": {"mode": "forbidden"},
        },
    }


def _load_manifest(repo_root: Path, settings: Settings) -> dict[str, Any]:
    defaults = default_capabilities(settings)
    path = resolve_capabilities(repo_root)
    if not path.exists():
        return defaults
    text = path.read_text(encoding="utf-8")
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        parsed = _parse_capabilities_yaml(text)
    return _merge_capabilities(defaults, parsed)


def _merge_capabilities(defaults: dict[str, Any], parsed: dict[str, Any]) -> dict[str, Any]:
    merged = {
        **defaults,
        **{key: value for key, value in parsed.items() if key != "capabilities"},
    }
    capabilities = dict(defaults.get("capabilities", {}))
    for name, rule in parsed.get("capabilities", {}).items():
        base = dict(capabilities.get(name, {}))
        base.update(rule if isinstance(rule, dict) else {"mode": str(rule)})
        capabilities[name] = base
    merged["capabilities"] = capabilities
    return merged


def _parse_capabilities_yaml(text: str) -> dict[str, Any]:
    parsed: dict[str, Any] = {"capabilities": {}}
    current_block: str | None = None
    current_capability: str | None = None
    current_list: tuple[str, str] | None = None
    for raw in text.splitlines():
        if not raw.strip() or raw.strip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        line = raw.strip()
        if indent == 0:
            current_capability = None
            current_list = None
            current_block = None
            if line == "capabilities:":
                current_block = "capabilities"
                parsed.setdefault("capabilities", {})
                continue
            if line.endswith(":"):
                current_block = line[:-1]
                parsed.setdefault(current_block, {})
                continue
            key, value = _nextgen_key_value(line)
            parsed[key] = _parse_scalar(value)
        elif indent == 2 and current_block and current_block != "capabilities":
            key, value = _nextgen_key_value(line)
            parsed.setdefault(current_block, {})[key] = _parse_scalar(value)
        elif indent == 2 and line.endswith(":"):
            current_capability = line[:-1]
            parsed.setdefault("capabilities", {}).setdefault(current_capability, {})
            current_list = None
        elif indent == 4 and current_capability:
            key, value = _nextgen_key_value(line)
            if value == "":
                current_list = (current_capability, key)
                parsed["capabilities"][current_capability][key] = []
            else:
                current_list = None
                parsed["capabilities"][current_capability][key] = _parse_scalar(value)
        elif indent >= 6 and line.startswith("- ") and current_list:
            capability, key = current_list
            parsed["capabilities"][capability][key].append(_strip_quotes(line[2:].strip()))
    return parsed


def _nextgen_key_value(line: str) -> tuple[str, str]:
    if ":" not in line:
        return line, ""
    key, value = line.split(":", 1)
    return key.strip(), value.strip()


def _parse_scalar(value: str) -> Any:
    value = _strip_quotes(value)
    if value.lower() == "true":
        return True
    if value.lower() == "false":
        return False
    if value.startswith("[") and value.endswith("]"):
        inner = value[1:-1].strip()
        if not inner:
            return []
        return [_strip_quotes(part.strip()) for part in inner.split(",")]
    return value


def _strip_quotes(value: str) -> str:
    return value.strip().strip("\"'")


def _matches_any(path: str, globs: list[str]) -> bool:
    return any(fnmatch.fnmatch(path, glob) for glob in globs)


def _looks_like_dependency_file(path: str) -> bool:
    name = Path(path).name
    return bool(
        re.fullmatch(r"requirements.*\.txt", name)
        or name
        in {
            "package.json",
            "package-lock.json",
            "pnpm-lock.yaml",
            "yarn.lock",
            "pyproject.toml",
        }
    )


def _default_reason(capability: str, mode: str) -> str:
    return f"Capability {capability} is configured as {mode}."
