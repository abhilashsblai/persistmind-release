from __future__ import annotations

import fnmatch
import json
from pathlib import Path
from typing import Any

from persistmind.config import Settings
from persistmind.governance.policy import CapabilityPolicy
from persistmind.utils import canonical_json, stable_id

ALLOWED_RISKS = {"low", "medium", "high", "critical"}


class TaskPlanGovernance:
    def __init__(
        self,
        repo_root: Path,
        store: Any,
        settings: Settings,
        *,
        workspace_id: str,
        repo_id: str | None,
    ):
        self.repo_root = repo_root
        self.store = store
        self.settings = settings
        self.workspace_id = workspace_id
        self.repo_id = repo_id

    def validate(
        self,
        plan: dict[str, Any],
        *,
        task_session_id: str | None = None,
        pack_id: str | None = None,
        impact_report: dict[str, Any] | None = None,
        behavior_report: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        normalized, schema_errors = normalize_plan(plan)
        normalized = _apply_governed_defaults(normalized, self.settings)
        constitution_hash = None
        if task_session_id:
            session = self.store.task_session(task_session_id)
            constitution_hash = session["constitution_hash"] if session else None
        intended_paths = intended_files(normalized)
        policy = CapabilityPolicy(self.repo_root, self.settings).check_paths(
            intended_paths,
            task_session_id=task_session_id,
            for_ci=True,
        )
        warnings = _impact_warnings(normalized, impact_report)
        applicable_guardrails = _applicable_guardrails_by_step(
            self.store,
            normalized,
            repo_id=self.repo_id,
            enabled=(self.settings.guardrails.enabled and self.settings.guardrails.plan_time_check),
        )
        behavior_findings = (behavior_report or {}).get("findings", [])
        blocking_behavior = [finding for finding in behavior_findings if finding.get("blocking")]
        return {
            "ok": not schema_errors and policy["ok"] and not blocking_behavior,
            "schema_version": "persistmind.task_plan_validation.v1",
            "schema_errors": schema_errors,
            "policy": policy,
            "impact_report": impact_report,
            "behavior_report": behavior_report,
            "warnings": warnings,
            "applicable_guardrails": applicable_guardrails,
            "behavior_findings": behavior_findings,
            "plan_hash": plan_hash(normalized),
            "pack_id": pack_id,
            "constitution_hash": constitution_hash,
            "normalized_plan": normalized,
        }

    def create(
        self,
        *,
        task_session_id: str,
        plan: dict[str, Any],
        author: str = "local-user",
        pack_id: str | None = None,
        impact_report: dict[str, Any] | None = None,
        behavior_report: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        if not self.store.task_session(task_session_id):
            raise KeyError(f"task session not found: {task_session_id}")
        validation = self.validate(
            plan,
            task_session_id=task_session_id,
            pack_id=pack_id,
            impact_report=impact_report,
            behavior_report=behavior_report,
        )
        if not validation["ok"]:
            return {"ok": False, "validation": _public_validation(validation)}
        normalized = validation["normalized_plan"]
        stored = self.store.write_task_plan(
            workspace_id=self.workspace_id,
            repo_id=self.repo_id,
            task_session_id=task_session_id,
            plan_hash=validation["plan_hash"],
            plan=normalized,
            validation=_public_validation(validation),
            author=author,
            metadata={"pack_id": pack_id} if pack_id else {},
            required_verifications=required_verification_names(normalized),
            governed_class=normalized.get("governed_class"),
        )
        return {
            "ok": True,
            **stored,
            "task_session_id": task_session_id,
            "validation": _public_validation(validation),
            "plan": normalized,
        }

    def amend(
        self,
        *,
        plan_id: str,
        plan: dict[str, Any],
        author: str = "local-user",
        reason: str | None = None,
        impact_report: dict[str, Any] | None = None,
        behavior_report: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        row = self.store.task_plan(plan_id)
        if not row:
            raise KeyError(f"task plan not found: {plan_id}")
        validation = self.validate(
            plan,
            task_session_id=row["task_session_id"],
            impact_report=impact_report,
            behavior_report=behavior_report,
        )
        if not validation["ok"]:
            return {
                "ok": False,
                "plan_id": plan_id,
                "validation": _public_validation(validation),
            }
        normalized = validation["normalized_plan"]
        stored = self.store.write_task_plan(
            workspace_id=row["workspace_id"],
            repo_id=row["repo_id"],
            task_session_id=row["task_session_id"],
            plan_id=plan_id,
            plan_hash=validation["plan_hash"],
            previous_plan_hash=row["plan_hash"],
            plan=normalized,
            validation=_public_validation(validation),
            author=author,
            reason=reason,
            status=row["status"],
            metadata=_json_dict(row["metadata_json"]),
            required_verifications=required_verification_names(normalized),
            governed_class=normalized.get("governed_class"),
        )
        return {
            "ok": True,
            **stored,
            "validation": _public_validation(validation),
            "plan": normalized,
        }

    def show(self, plan_id: str) -> dict[str, Any]:
        row = self.store.task_plan(plan_id)
        if not row:
            return {"ok": False, "error": "task plan not found", "plan_id": plan_id}
        revisions = [_revision_dict(item) for item in self.store.task_plan_revisions(plan_id)]
        checkpoints = [_checkpoint_dict(item) for item in self.store.task_plan_checkpoints(plan_id)]
        return {
            "ok": True,
            "plan": {**dict(row), "metadata": _json_dict(row["metadata_json"])},
            "revisions": revisions,
            "checkpoints": checkpoints,
        }

    def checkpoint(
        self,
        *,
        plan_id: str,
        step_id: str,
        changed_paths: list[str],
        task_session_id: str | None = None,
    ) -> dict[str, Any]:
        row = self.store.task_plan(plan_id)
        if not row:
            raise KeyError(f"task plan not found: {plan_id}")
        revisions = self.store.task_plan_revisions(plan_id)
        if not revisions:
            raise KeyError(f"task plan has no revisions: {plan_id}")
        plan = _json_dict(revisions[-1]["plan_json"])
        step = _find_step(plan, step_id)
        normalized_paths = sorted({_normalize_path(path) for path in changed_paths if path})
        violations: list[dict[str, Any]] = []
        if step is None:
            violations.append(
                {
                    "type": "unknown_step",
                    "step_id": step_id,
                    "blocking": True,
                    "reason": "Checkpoint step is not declared in the active task plan.",
                }
            )
            intended = []
        else:
            intended = list(step.get("intended_files", []))
            for path in normalized_paths:
                if not _matches_any(path, intended):
                    violations.append(
                        {
                            "type": "out_of_step_edit",
                            "step_id": step_id,
                            "path": path,
                            "blocking": True,
                            "reason": "Changed path is outside this step's intended_files.",
                            "declared_files": intended,
                        }
                    )
        policy = CapabilityPolicy(self.repo_root, self.settings).check_paths(
            normalized_paths,
            task_session_id=task_session_id or row["task_session_id"],
            for_ci=False,
        )
        violations.extend(policy["violations"])
        status = "pass" if not any(item.get("blocking") for item in violations) else "fail"
        checkpoint_id = self.store.record_task_plan_checkpoint(
            plan_id=plan_id,
            step_id=step_id,
            status=status,
            changed_paths=normalized_paths,
            violations=violations,
        )
        return {
            "ok": status == "pass",
            "checkpoint_id": checkpoint_id,
            "plan_id": plan_id,
            "step_id": step_id,
            "status": status,
            "changed_paths": normalized_paths,
            "declared_files": intended,
            "violations": violations,
            "policy": policy,
        }


def normalize_plan(plan: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    errors: list[dict[str, Any]] = []
    if not isinstance(plan, dict):
        return {"objective": "", "steps": []}, [_schema_error("$", "plan must be an object")]
    objective = plan.get("objective")
    if not isinstance(objective, str) or not objective.strip():
        errors.append(_schema_error("objective", "objective must be a non-empty string"))
        objective = ""
    steps = plan.get("steps")
    if not isinstance(steps, list) or not steps:
        errors.append(_schema_error("steps", "steps must be a non-empty list"))
        steps = []
    normalized_steps = []
    seen_ids: set[str] = set()
    for index, raw_step in enumerate(steps):
        path = f"steps[{index}]"
        if not isinstance(raw_step, dict):
            errors.append(_schema_error(path, "step must be an object"))
            continue
        step_id = _string_field(raw_step, "id")
        title = _string_field(raw_step, "title")
        if not step_id:
            errors.append(_schema_error(f"{path}.id", "step id must be a non-empty string"))
            step_id = f"step-{index + 1}"
        if step_id in seen_ids:
            errors.append(_schema_error(f"{path}.id", "step id must be unique"))
        seen_ids.add(step_id)
        if not title:
            errors.append(_schema_error(f"{path}.title", "step title must be a non-empty string"))
        files = _string_list(raw_step.get("intended_files", raw_step.get("files")))
        tests = _string_list(raw_step.get("intended_tests", raw_step.get("tests")))
        capabilities = _string_list(raw_step.get("capabilities"))
        if not files:
            errors.append(
                _schema_error(f"{path}.intended_files", "intended_files must list planned files")
            )
        if not isinstance(raw_step.get("capabilities"), list):
            errors.append(
                _schema_error(f"{path}.capabilities", "capabilities must be a list of strings")
            )
        risk = _string_field(raw_step, "risk").lower()
        if risk not in ALLOWED_RISKS:
            errors.append(
                _schema_error(
                    f"{path}.risk",
                    "risk must be one of: critical, high, medium, low",
                )
            )
            risk = "medium"
        normalized_steps.append(
            {
                "id": step_id,
                "title": title,
                "intended_files": sorted({_normalize_path(item) for item in files}),
                "intended_tests": sorted(set(tests)),
                "capabilities": sorted(set(capabilities)),
                "risk": risk,
            }
        )
    normalized = {
        "schema_version": "persistmind.task_plan.v1",
        "objective": objective.strip() if isinstance(objective, str) else "",
        "steps": normalized_steps,
    }
    governed_class = _string_field(plan, "governed_class")
    if governed_class:
        normalized["governed_class"] = governed_class
    required_verifications = _required_verifications(plan.get("required_verifications"))
    if plan.get("required_verifications") is not None and not isinstance(
        plan.get("required_verifications"), list
    ):
        errors.append(
            _schema_error(
                "required_verifications",
                "required_verifications must be a list of strings or objects",
            )
        )
    if required_verifications:
        normalized["required_verifications"] = required_verifications
    acceptance_checklist = _acceptance_checklist(plan.get("acceptance_checklist"))
    if plan.get("acceptance_checklist") is not None and not isinstance(
        plan.get("acceptance_checklist"), list
    ):
        errors.append(
            _schema_error(
                "acceptance_checklist",
                "acceptance_checklist must be a list of contract item objects",
            )
        )
    normalized["acceptance_checklist"] = acceptance_checklist
    normalized["checklist_status"] = "populated" if acceptance_checklist else "empty"
    for key in ("description", "verification"):
        if isinstance(plan.get(key), str) and plan[key].strip():
            normalized[key] = plan[key].strip()
    return normalized, errors


def intended_files(plan: dict[str, Any]) -> list[str]:
    paths: set[str] = set()
    for step in plan.get("steps", []):
        if isinstance(step, dict):
            paths.update(_normalize_path(path) for path in step.get("intended_files", []))
    return sorted(path for path in paths if path)


def required_verification_names(plan: dict[str, Any]) -> list[str]:
    return sorted(
        {
            str(item.get("name") or item.get("command") or "").strip()
            for item in plan.get("required_verifications", [])
            if isinstance(item, dict) and str(item.get("name") or item.get("command") or "").strip()
        }
    )


def required_contract_items(plan: dict[str, Any]) -> list[dict[str, Any]]:
    return _acceptance_checklist(plan.get("acceptance_checklist"))


def plan_hash(plan: dict[str, Any]) -> str:
    return stable_id(canonical_json(plan))


def _public_validation(validation: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in validation.items() if key not in {"normalized_plan"}}


def _applicable_guardrails_by_step(
    store: Any,
    plan: dict[str, Any],
    *,
    repo_id: str | None,
    enabled: bool,
) -> dict[str, Any]:
    if not enabled:
        return {"enabled": False, "steps": []}
    steps = []
    for step in plan.get("steps", []):
        if not isinstance(step, dict):
            continue
        paths = [str(path) for path in step.get("intended_files", []) if path]
        directives = [_guardrail_dict(item) for item in store.directives_for_paths(paths, repo_id)]
        if directives:
            steps.append(
                {
                    "step_id": step.get("id"),
                    "intended_files": paths,
                    "directives": directives,
                }
            )
    return {"enabled": True, "steps": steps}


def _guardrail_dict(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["path_globs"] = _json_list(item.pop("path_globs_json", "[]"))
    item["anti_patterns"] = _json_list(item.pop("anti_patterns_json", "[]"))
    item["required_patterns"] = _json_list(item.pop("required_patterns_json", "[]"))
    item.pop("symbol_ids_json", None)
    item.pop("created_at", None)
    item.pop("updated_at", None)
    return item


def _impact_warnings(
    plan: dict[str, Any],
    impact_report: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    if not impact_report:
        return []
    impact_tests = {
        item.get("command")
        for item in impact_report.get("tests", [])
        if isinstance(item, dict) and item.get("command")
    }
    declared_tests: set[str] = set()
    for step in plan.get("steps", []):
        if isinstance(step, dict):
            declared_tests.update(step.get("intended_tests", []))
    missing = sorted(str(item) for item in impact_tests - declared_tests if item is not None)
    if not missing:
        return []
    return [
        {
            "type": "impact_tests_not_declared",
            "blocking": False,
            "reason": "Impact report selected tests that are not declared in intended_tests.",
            "commands": missing,
        }
    ]


def _revision_dict(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["plan"] = _json_dict(item.pop("plan_json"))
    item["validation"] = _json_dict(item.pop("validation_json"))
    return item


def _checkpoint_dict(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["changed_paths"] = _json_list(item.pop("changed_paths_json"))
    item["violations"] = _json_list(item.pop("violations_json"))
    return item


def _find_step(plan: dict[str, Any], step_id: str) -> dict[str, Any] | None:
    for step in plan.get("steps", []):
        if isinstance(step, dict) and step.get("id") == step_id:
            return step
    return None


def _matches_any(path: str, patterns: list[str]) -> bool:
    return any(path == pattern or fnmatch.fnmatch(path, pattern) for pattern in patterns)


def _normalize_path(path: str) -> str:
    normalized = path.replace("\\", "/")
    return normalized.removeprefix("./")


def _string_field(data: dict[str, Any], key: str) -> str:
    value = data.get(key)
    return value.strip() if isinstance(value, str) else ""


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [item.strip() for item in value if isinstance(item, str) and item.strip()]


def _required_verifications(value: Any) -> list[dict[str, str]]:
    if not isinstance(value, list):
        return []
    normalized: list[dict[str, str]] = []
    seen: set[str] = set()
    for raw in value:
        if isinstance(raw, str):
            name = raw.strip()
            command = raw.strip()
        elif isinstance(raw, dict):
            name = str(raw.get("name") or raw.get("command") or "").strip()
            command = str(raw.get("command") or name).strip()
        else:
            continue
        if not name or name in seen:
            continue
        seen.add(name)
        normalized.append({"name": name, "command": command})
    return sorted(normalized, key=lambda item: item["name"])


def _acceptance_checklist(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    normalized: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for index, raw in enumerate(value):
        if not isinstance(raw, dict):
            continue
        kind = str(raw.get("kind") or "").strip().casefold()
        if kind not in {"symbol", "path", "alias"}:
            continue
        item_value = str(raw.get("value") or raw.get("text") or "").strip()
        if not item_value:
            continue
        if kind == "path":
            item_value = _normalize_path(item_value)
        source_ref = str(raw.get("source_ref") or "plan").strip() or "plan"
        key = (kind, item_value)
        if key in seen:
            continue
        seen.add(key)
        item_id = str(raw.get("id") or "").strip() or stable_id(
            "acceptance_contract", kind, item_value, source_ref, index
        )
        normalized.append(
            {
                "id": item_id,
                "kind": kind,
                "value": item_value,
                "source_ref": source_ref,
                "satisfied": bool(raw.get("satisfied", False)),
            }
        )
    return sorted(normalized, key=lambda item: (item["kind"], item["value"], item["id"]))


def _apply_governed_defaults(plan: dict[str, Any], settings: Settings) -> dict[str, Any]:
    governed_class = str(plan.get("governed_class") or "").strip()
    if not governed_class:
        return plan
    existing = {
        str(item.get("name") or item.get("command") or "").strip(): dict(item)
        for item in plan.get("required_verifications", [])
        if isinstance(item, dict)
    }
    defaults = settings.governance.governed_classes.get(governed_class, [])
    for name in defaults:
        key = str(name).strip()
        if key and key not in existing:
            existing[key] = {"name": key, "command": key}
    return {
        **plan,
        "required_verifications": sorted(existing.values(), key=lambda item: item["name"]),
    }


def _schema_error(path: str, message: str) -> dict[str, Any]:
    return {"type": "schema_error", "path": path, "message": message, "blocking": True}


def _json_dict(value: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _json_list(value: str) -> list[Any]:
    try:
        parsed = json.loads(value or "[]")
    except json.JSONDecodeError:
        return []
    return parsed if isinstance(parsed, list) else []
