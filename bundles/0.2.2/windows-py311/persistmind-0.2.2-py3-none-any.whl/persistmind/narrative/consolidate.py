from __future__ import annotations

from typing import Any

from persistmind.utils import stable_id


def build_project_narrative(
    *,
    repo_id: str,
    episodes: list[Any],
    prior: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if not episodes and not prior:
        return {
            "ok": True,
            "schema_version": "persistmind.narrative.v1",
            "active": False,
            "reason": "no_narrative_yet",
        }
    summaries = []
    for row in episodes[:5]:
        item = dict(row)
        title = str(item.get("title") or item.get("assertion") or "").strip()
        if title:
            summaries.append(title)
    prior_summary = str((prior or {}).get("summary") or "").strip()
    summary = prior_summary or "Project narrative has started from recent CTX episodes."
    if summaries:
        summary = "Recent project experience: " + "; ".join(summaries[:3])
    narrative_id = stable_id("narrative", repo_id, summary)
    return {
        "ok": True,
        "schema_version": "persistmind.narrative.v1",
        "active": True,
        "narrative_id": narrative_id,
        "repo_id": repo_id,
        "summary": summary,
        "posture": {
            "evidence_count": len(summaries),
            "prior_narrative_id": (prior or {}).get("narrative_id"),
        },
    }
