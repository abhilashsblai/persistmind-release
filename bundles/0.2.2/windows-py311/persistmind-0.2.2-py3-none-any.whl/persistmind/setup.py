from __future__ import annotations

import ast
import json
import os
import re
import subprocess
import tomllib
from pathlib import Path
from typing import Any

from persistmind.branding import PROJECT_STATE_DIR, resolve_capabilities, resolve_project_state

import persistmind

from persistmind.agents.adapters import resolve
from persistmind.agents.adapters.base import BootstrapContext
from persistmind.agents.adapters.codex import (
    CodexAdapter,
    default_codex_config_path as codex_default_config_path,
)
from persistmind.agents.contract import HOOK_COMMAND_TIMEOUT_SECONDS
from persistmind.mcp_probe import probe_stdio_mcp
from persistmind.runtime_invocation import RuntimeInvocation, runtime_invocation


def is_git_repo(repo_root: Path) -> bool:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            cwd=repo_root,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=10,
        )
    except (FileNotFoundError, subprocess.SubprocessError):
        return False
    return result.returncode == 0 and result.stdout.strip() == "true"


def init_git_repo(repo_root: Path) -> dict[str, Any]:
    result = subprocess.run(
        ["git", "init"],
        cwd=repo_root,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=30,
    )
    return {
        "ok": result.returncode == 0,
        "command": ["git", "init"],
        "returncode": result.returncode,
        "stdout": result.stdout.strip(),
        "stderr": result.stderr.strip(),
    }


def default_codex_config_path() -> Path:
    return codex_default_config_path()


def merge_codex_mcp_config(
    config_path: Path,
    *,
    command: str = "persistmind",
    mcp_repo: str = ".",
    invocation: RuntimeInvocation | None = None,
) -> dict[str, Any]:
    runtime = invocation or runtime_invocation()
    if command not in {"persistmind"} and invocation is None:
        runtime = runtime_invocation(
            executable=command,
            prefix_args=("-I", "-m", "persistmind"),
        )
    ctx = BootstrapContext(
        repo_root=Path.cwd(),
        workspace_root=resolve_project_state(Path.cwd()),
        runtime_invocation=runtime,
        mcp_repo=mcp_repo,
        shell="powershell",
        agent_names=["codex"],
    )
    return CodexAdapter().configure_mcp(ctx, config_path=config_path)


def setup_readiness(
    repo_root: Path,
    agents: list[str] | None = None,
    *,
    probe_mcp: bool = True,
    live_probes: bool = True,
) -> dict[str, Any]:
    repo_root = repo_root.resolve()
    workspace = resolve_project_state(repo_root)
    adapters = resolve(agents or ["codex"])
    agent_names = {adapter.name for adapter in adapters}
    agents_path = repo_root / "AGENTS.md"
    agents_text = agents_path.read_text(encoding="utf-8") if agents_path.exists() else ""
    hooks_dir = repo_root / ".git" / "hooks"
    capabilities_path = resolve_capabilities(repo_root)
    checks = {
        "git_repo": is_git_repo(repo_root) if live_probes else (repo_root / ".git").is_dir(),
        "capabilities_file": capabilities_path.exists(),
        "pre_commit_hook": (hooks_dir / "pre-commit").exists(),
        "post_commit_hook": (hooks_dir / "post-commit").exists(),
        "persistmind_ignored": _gitignore_has_persistmind(repo_root),
        "self_bootstrap_fallback": not _is_persistmind_source_checkout(repo_root)
        or (repo_root / "scripts" / "persistmind-self-repair.ps1").exists(),
    }
    if "codex" in agent_names:
        checks.update(
            {
                "agents_file": agents_path.exists(),
                "agents_contract": "<!-- persistmind-agent-contract -->" in agents_text,
                "codex_mcp_snippet": (workspace / "mcp" / "codex.config.toml").exists(),
                "codex_project_config": (repo_root / ".codex" / "config.toml").exists(),
                "codex_hooks": (repo_root / ".codex" / "hooks.json").exists()
                and (workspace / "codex" / "hooks" / "persistmind_hook.py").exists(),
                "codex_agents": all(
                    (repo_root / ".codex" / "agents" / name).exists()
                    for name in [
                        "persistmind-explorer.toml",
                        "persistmind-worker.toml",
                        "persistmind-reviewer.toml",
                        "persistmind-verifier.toml",
                    ]
                ),
            }
        )
        semantic = _codex_semantic_readiness(
            repo_root,
            probe_mcp=probe_mcp and live_probes,
            live_probes=live_probes,
        )
        checks.update(semantic["checks"])
    else:
        semantic = {"checks": {}, "details": {}}
    agent_readiness = {adapter.name: adapter.readiness(repo_root) for adapter in adapters}
    for readiness in agent_readiness.values():
        checks.update(readiness.get("checks", {}))
    advisory = {"pre_commit_hook", "post_commit_hook"}
    missing = [name for name, ok in checks.items() if not ok and name not in advisory]
    advisory_missing = [name for name, ok in checks.items() if not ok and name in advisory]
    return {
        "ok": not missing,
        "checks": checks,
        "missing": missing,
        "advisory_missing": advisory_missing,
        "agents": agent_readiness,
        "semantic": semantic["details"],
        "governance": {
            "capabilities_file": str(capabilities_path),
            "canonical": capabilities_path.name == "persistmind.capabilities.yaml",
        },
        "self_bootstrap": {
            "mode": "pinned_artifact_disposable_environment",
            "script": str(repo_root / "scripts" / "persistmind-self-repair.ps1"),
            "requires": ["artifact", "sha256"],
            "governance_bypass": False,
        },
    }


def _replace_toml_table(existing: str, table_name: str, block: str) -> str:
    lines = existing.splitlines()
    header = f"[{table_name}]"
    output: list[str] = []
    idx = 0
    replaced = False
    while idx < len(lines):
        if lines[idx].strip() == header:
            if output and output[-1].strip():
                output.append("")
            output.extend(block.strip().splitlines())
            replaced = True
            idx += 1
            while idx < len(lines):
                stripped = lines[idx].strip()
                if stripped.startswith("[") and stripped.endswith("]"):
                    break
                idx += 1
            continue
        output.append(lines[idx])
        idx += 1

    if not replaced:
        if output and output[-1].strip():
            output.append("")
        output.extend(block.strip().splitlines())

    return "\n".join(output).rstrip() + "\n"


def _gitignore_has_persistmind(repo_root: Path) -> bool:
    gitignore = repo_root / ".gitignore"
    if not gitignore.exists():
        return False
    lines = gitignore.read_text(encoding="utf-8").splitlines()
    return f"{PROJECT_STATE_DIR}/" in lines or ".persistmind/" in lines


def _is_persistmind_source_checkout(repo_root: Path) -> bool:
    project = _toml_file(repo_root / "pyproject.toml").get("project") or {}
    return str(project.get("name") or "").casefold() in {
        "persistmind",
        "advanced-persistmind",
    }


def _codex_semantic_readiness(
    repo_root: Path,
    *,
    probe_mcp: bool = True,
    live_probes: bool = True,
) -> dict[str, Any]:
    workspace = resolve_project_state(repo_root)
    project_config = repo_root / ".codex" / "config.toml"
    mcp_snippet = workspace / "mcp" / "codex.config.toml"
    hooks_path = repo_root / ".codex" / "hooks.json"
    hook_script_path = workspace / "codex" / "hooks" / "persistmind_hook.py"
    project = _toml_file(project_config)
    snippet = _toml_file(mcp_snippet)
    hooks = _json_file(hooks_path)
    project_mcp = _mcp_table(project)
    snippet_mcp = _mcp_table(snippet)
    project_command = str(project_mcp.get("command") or "")
    snippet_command = str(snippet_mcp.get("command") or "")
    project_args = [str(item) for item in project_mcp.get("args") or []]
    snippet_args = [str(item) for item in snippet_mcp.get("args") or []]
    expected_repo = str(repo_root)
    project_repo = _repo_arg(project_args)
    snippet_repo = _repo_arg(snippet_args)
    hook_commands = _hook_commands(hooks)
    hook_timeouts = _hook_timeouts(hooks)
    windows_hook_paths = [
        match.group(1)
        for command in hook_commands
        if (match := re.search(r"-File\s+['\"]([^'\"]+)['\"]", command))
    ]
    hook_paths_match = bool(windows_hook_paths) and all(
        _same_path(Path(path).parent.parent.parent.parent, repo_root)
        or _is_within(Path(path), repo_root)
        for path in windows_hook_paths
    )
    hook_script_valid = _python_syntax_valid(hook_script_path)
    if live_probes:
        hook_gate_smoke = _codex_hook_gate_smoke(hook_script_path, executable=project_command)
        project_runtime_probe = _mcp_runtime_probe(project_command, project_args, repo_root)
        snippet_runtime_probe = _mcp_runtime_probe(snippet_command, snippet_args, repo_root)
    else:
        hook_gate_smoke = {
            "ok": hook_script_valid,
            "status": "deferred_nonrecursive",
        }
        project_runtime_probe = _static_mcp_runtime_probe(project_command, project_args)
        snippet_runtime_probe = _static_mcp_runtime_probe(snippet_command, snippet_args)
    same_mcp_invocation = (
        project_runtime_probe["ok"]
        and snippet_runtime_probe["ok"]
        and project_command == snippet_command
        and project_args == snippet_args
    )
    if probe_mcp and same_mcp_invocation:
        project_mcp_probe = probe_stdio_mcp(
            project_command,
            project_args,
            repo=repo_root,
        )
        snippet_mcp_probe = dict(project_mcp_probe)
    elif probe_mcp:
        project_mcp_probe = (
            probe_stdio_mcp(project_command, project_args, repo=repo_root)
            if project_runtime_probe["ok"]
            else {"ok": False, "error": "runtime_probe_failed"}
        )
        snippet_mcp_probe = (
            probe_stdio_mcp(snippet_command, snippet_args, repo=repo_root)
            if snippet_runtime_probe["ok"]
            else {"ok": False, "error": "runtime_probe_failed"}
        )
    else:
        # An MCP tool must not recursively initialize its own configured MCP
        # server.  The exact executable/version/repo checks above remain live;
        # setup/install performs the deep stdio probe and records its evidence.
        deferred_ok = bool(
            same_mcp_invocation and project_args[:4] == ["-I", "-m", "persistmind", "mcp"]
        )
        project_mcp_probe = {
            "ok": deferred_ok,
            "status": "deferred_nonrecursive",
        }
        snippet_mcp_probe = dict(project_mcp_probe)
    package_version = str(getattr(persistmind, "__version__", ""))
    from persistmind.agent_runtime.activation import activation_status

    host_activation = activation_status(repo_root, expected_version=package_version)
    pyproject = _toml_file(repo_root / "pyproject.toml")
    project_metadata = pyproject.get("project") or {}
    project_name = str(project_metadata.get("name") or "").casefold()
    declared_version = (
        str(project_metadata.get("version") or "")
        if project_name in {"persistmind", "advanced-persistmind"}
        else ""
    )
    version_matches = not declared_version or declared_version == package_version
    command_resolves = project_runtime_probe["ok"] and snippet_runtime_probe["ok"]
    checks = {
        "codex_project_config_valid_toml": bool(project),
        "codex_mcp_snippet_valid_toml": bool(snippet),
        "codex_hooks_valid_json": bool(hooks),
        "codex_hook_timeouts_sufficient": bool(hook_timeouts)
        and all(value >= HOOK_COMMAND_TIMEOUT_SECONDS for value in hook_timeouts),
        "codex_project_repo_matches": _same_path_text(project_repo, expected_repo),
        "codex_mcp_repo_matches": _same_path_text(snippet_repo, expected_repo),
        "codex_mcp_command_resolves": command_resolves,
        "codex_mcp_initialization_smoke": command_resolves
        and project_args[:4] == ["-I", "-m", "persistmind", "mcp"]
        and snippet_args[:4] == ["-I", "-m", "persistmind", "mcp"]
        and bool(project_mcp_probe.get("ok"))
        and bool(snippet_mcp_probe.get("ok")),
        "codex_mcp_server_version_matches": not probe_mcp
        or (
            str(project_mcp_probe.get("server_version") or "") == package_version
            and str(snippet_mcp_probe.get("server_version") or "") == package_version
        ),
        "codex_hook_commands_match_repo": hook_paths_match,
        "codex_hook_gate_smoke": hook_script_valid and hook_gate_smoke["ok"],
        "persistmind_version_matches_checkout": version_matches,
    }
    return {
        "checks": checks,
        "details": {
            "project_config": str(project_config),
            "mcp_snippet": str(mcp_snippet),
            "hooks": str(hooks_path),
            "project_repo": project_repo,
            "snippet_repo": snippet_repo,
            "expected_repo": expected_repo,
            "mcp_command": project_command,
            "project_runtime_probe": project_runtime_probe,
            "snippet_runtime_probe": snippet_runtime_probe,
            "project_mcp_probe": project_mcp_probe,
            "snippet_mcp_probe": snippet_mcp_probe,
            "host_activation": host_activation,
            "imported_version": package_version,
            "declared_version": declared_version or None,
            "windows_hook_paths": windows_hook_paths,
            "hook_timeouts_seconds": hook_timeouts,
            "minimum_hook_timeout_seconds": HOOK_COMMAND_TIMEOUT_SECONDS,
            "hook_gate_smoke": hook_gate_smoke,
        },
    }


def _toml_file(path: Path) -> dict[str, Any]:
    try:
        value = tomllib.loads(path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def _json_file(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def _mcp_table(value: dict[str, Any]) -> dict[str, Any]:
    servers = value.get("mcp_servers")
    if not isinstance(servers, dict):
        return {}
    ctx = servers.get("persistmind")
    return ctx if isinstance(ctx, dict) else {}


def _repo_arg(args: list[str]) -> str | None:
    try:
        return args[args.index("--repo") + 1]
    except (ValueError, IndexError):
        return None


def _hook_commands(payload: dict[str, Any]) -> list[str]:
    commands: list[str] = []
    events = payload.get("hooks")
    if not isinstance(events, dict):
        return commands
    for groups in events.values():
        if not isinstance(groups, list):
            continue
        for group in groups:
            for hook in group.get("hooks", []) if isinstance(group, dict) else []:
                if not isinstance(hook, dict):
                    continue
                for key in ("command", "commandWindows"):
                    if hook.get(key):
                        commands.append(str(hook[key]))
    return commands


def _hook_timeouts(payload: dict[str, Any]) -> list[float]:
    timeouts: list[float] = []
    events = payload.get("hooks")
    if not isinstance(events, dict):
        return timeouts
    for groups in events.values():
        if not isinstance(groups, list):
            continue
        for group in groups:
            for hook in group.get("hooks", []) if isinstance(group, dict) else []:
                if not isinstance(hook, dict):
                    continue
                value = hook.get("timeout")
                if isinstance(value, (int, float)) and not isinstance(value, bool):
                    timeouts.append(float(value))
    return timeouts


def _mcp_runtime_probe(command: str, args: list[str], repo_root: Path) -> dict[str, Any]:
    if len(args) < 4 or args[:4] != ["-I", "-m", "persistmind", "mcp"]:
        return {"ok": False, "error": "runtime_prefix_not_managed"}
    try:
        invocation = RuntimeInvocation(
            executable=command,
            prefix_args=tuple(args[:3]),
            source="setup-readiness",
        )
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    return invocation.validate(repo=repo_root).to_dict()


def _static_mcp_runtime_probe(command: str, args: list[str]) -> dict[str, Any]:
    """Validate managed runtime identity without spawning from an MCP request."""

    if len(args) < 4 or args[:4] != ["-I", "-m", "persistmind", "mcp"]:
        return {"ok": False, "error": "runtime_prefix_not_managed"}
    try:
        invocation = RuntimeInvocation(
            executable=command,
            prefix_args=tuple(args[:3]),
            source="setup-readiness-static",
        )
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    return {
        "ok": Path(invocation.executable).is_file(),
        "executable": invocation.executable,
        "argv_sha256": invocation.invocation_sha256,
        "status": "deferred_nonrecursive",
    }


def _codex_hook_gate_smoke(path: Path, *, executable: str) -> dict[str, Any]:
    if not path.exists():
        return {"ok": False, "reason": "hook_script_missing"}
    try:
        runtime_path = Path(executable).expanduser()
    except (OSError, ValueError):
        return {"ok": False, "reason": "runtime_executable_invalid"}
    if not runtime_path.is_absolute() or not runtime_path.is_file():
        return {"ok": False, "reason": "runtime_executable_missing"}
    try:
        result = subprocess.run(
            [
                str(runtime_path),
                "-I",
                "-X",
                "utf8",
                str(path),
                "PreToolUse",
            ],
            cwd=path.parents[3],
            env={**os.environ, "PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"},
            input=json.dumps({"_persistmind_hook_self_test": True}),
            text=True,
            encoding="utf-8",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=10,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return {"ok": False, "reason": "hook_smoke_error", "error": str(exc)}
    try:
        output = json.loads(result.stdout or "{}")
    except json.JSONDecodeError:
        output = {}
    hook_output = output.get("hookSpecificOutput") if isinstance(output, dict) else None
    ok = (
        result.returncode == 0
        and isinstance(hook_output, dict)
        and hook_output.get("hookEventName") == "PreToolUse"
        and hook_output.get("permissionDecision") == "deny"
        and bool(hook_output.get("permissionDecisionReason"))
    )
    return {
        "ok": ok,
        "returncode": result.returncode,
        "reason": None if ok else "invalid_block_contract",
        "stderr": (result.stderr or "")[:1000],
    }


def _same_path_text(left: str | None, right: str) -> bool:
    if not left:
        return False
    if left == ".":
        # Project-local MCP configuration is launched with the project as its
        # working directory, so the portable relative form names repo_root.
        return True
    return _same_path(Path(left), Path(right))


def _same_path(left: Path, right: Path) -> bool:
    try:
        return left.resolve() == right.resolve()
    except OSError:
        return False


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
    except (OSError, ValueError):
        return False
    return True


def _python_syntax_valid(path: Path) -> bool:
    try:
        ast.parse(path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError, UnicodeDecodeError):
        return False
    return True
