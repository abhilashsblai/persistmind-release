from __future__ import annotations

import json
import os
import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from persistmind.identifiers import KIND_BY_KEY, parse_workflow_id, validate_host_session_id
from persistmind.runtime_invocation import load_project_runtime_invocation
from persistmind.utils import stable_id

HOOK_COMMAND_EVIDENCE_SCHEMA = "persistmind.hook_command_evidence.v1"
HOOK_BINDABLE_RESULT_SCHEMA = "persistmind.hook_bindable_result.v1"
MAX_RESPONSE_BYTES = 2 * 1024 * 1024
MAX_CANDIDATE_STARTS = 200
MAX_DEPTH = 16
MAX_VISITED_NODES = 10_000

_SHELL_TOOL_NAMES = {
    "bash",
    "shell",
    "powershell",
    "pwsh",
    "terminal",
    "command",
}
_WRAPPER_NAMES = {
    "cmd",
    "cmd.exe",
    "powershell",
    "powershell.exe",
    "pwsh",
    "pwsh.exe",
    "sh",
    "bash",
}
_PYTHON_NAMES = {"python", "python.exe", "python3", "python3.exe"}
_PRODUCT_NAMES = {"persistmind", "persistmind.exe"}
_BINDING_KEYS = tuple(KIND_BY_KEY) + ("agent_session_id",)
_LIFECYCLE_EVENT_RE = re.compile(r"^evt_[0-9a-f]{32}$")
_EXECUTION_RECEIPT_RE = re.compile(r"^receipt_[0-9a-f]{32}$")
_MCP_TOOL_RE = re.compile(
    r"^mcp__(?P<server>persistmind|persistmind)__(?P<method>[a-z][a-z0-9_]*)$",
    re.IGNORECASE,
)
_MCP_ROUTE_BY_METHOD = {
    "task_start": "task.start",
    "task_transition": "task.transition",
    "get_context_pack": "pack",
    "get_pack_manifest": "manifest",
    "plan_create": "plan.create",
    "plan_amend": "plan.amend",
    "plan_checkpoint": "plan.checkpoint",
    "check_diff_against_pack": "check_diff",
    "get_impact_report": "impact",
    "record_outcome": "outcome",
}


@dataclass(frozen=True, slots=True)
class HookBindingParse:
    ok: bool
    reason: str
    route: str | None = None
    identifiers: Mapping[str, str] = field(default_factory=dict)
    argv: tuple[str, ...] = ()
    evidence_mode: str = "strict"
    result_schema: str | None = None
    cwd: str | None = None
    host_session_id: str | None = None
    lifecycle_event_id: str | None = None
    lifecycle_sequence: int | None = None
    execution_receipt_id: str | None = None
    tool_call_id: str | None = None
    turn_id: str | None = None
    mcp_method: str | None = None
    mcp_input: Mapping[str, Any] = field(default_factory=dict)
    result_document: Mapping[str, Any] = field(default_factory=dict)


class _DuplicateKey(ValueError):
    pass


def parse_post_tool_binding(payload: Mapping[str, Any]) -> HookBindingParse:
    tool_name = str(payload.get("tool_name") or payload.get("tool") or "")
    evidence = (
        _mcp_evidence(payload)
        if tool_name.casefold().startswith("mcp__")
        else _command_evidence(payload)
    )
    if not evidence.ok:
        return evidence
    turn_id = payload.get("turn_id")
    if not isinstance(turn_id, str) or not turn_id.strip():
        return HookBindingParse(
            False,
            "missing_turn_id",
            argv=evidence.argv,
            evidence_mode=evidence.evidence_mode,
        )
    route = (
        _MCP_ROUTE_BY_METHOD.get(str(evidence.mcp_method))
        if evidence.mcp_method
        else _route_from_argv(evidence.argv)
    )
    if route is None:
        return HookBindingParse(
            False,
            "not_lifecycle_command",
            argv=evidence.argv,
            evidence_mode=evidence.evidence_mode,
        )
    response = payload.get("tool_response")
    if evidence.mcp_method:
        response = _unwrap_mcp_response(response)
    parsed = _parse_response(response, route)
    return HookBindingParse(
        parsed.ok,
        parsed.reason,
        route=route,
        identifiers=parsed.identifiers,
        argv=evidence.argv,
        evidence_mode=evidence.evidence_mode,
        result_schema=parsed.result_schema,
        cwd=evidence.cwd,
        host_session_id=evidence.host_session_id,
        lifecycle_event_id=parsed.lifecycle_event_id,
        lifecycle_sequence=parsed.lifecycle_sequence,
        execution_receipt_id=parsed.execution_receipt_id,
        tool_call_id=evidence.tool_call_id,
        turn_id=turn_id.strip(),
        mcp_method=evidence.mcp_method,
        mcp_input=evidence.mcp_input,
        result_document=parsed.result_document,
    )


def build_hook_bindable_result(
    route: str,
    result: Mapping[str, Any],
    *,
    repo_root: Path,
    command_argv: Iterable[str] | None = None,
    mcp_method: str | None = None,
    mcp_input: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Promote one successful CLI result to the frozen hook binding schema."""

    document = dict(result)
    if document.get("ok") is not True:
        return document
    try:
        identifiers = _collect_identifiers(document, recurse=True)
    except ValueError:
        return document
    required = _required_identifiers(route)
    if not required <= set(identifiers):
        return document
    if set(identifiers) - _allowed_identifiers(route):
        return document
    lifecycle_event_id = document.get("lifecycle_event_id")
    lifecycle_sequence = document.get("lifecycle_sequence")
    if (
        (command_argv is None and mcp_method is None)
        or (command_argv is not None and mcp_method is not None)
        or not isinstance(lifecycle_event_id, str)
        or not _LIFECYCLE_EVENT_RE.fullmatch(lifecycle_event_id)
        or not isinstance(lifecycle_sequence, int)
        or lifecycle_sequence < 1
    ):
        return document
    task_session_id = identifiers.get("task_session_id")
    if task_session_id is None:
        try:
            from persistmind.storage.workflow_identity import WorkflowIdentityResolver

            identity = WorkflowIdentityResolver(repo_root).resolve(
                pack_id=identifiers.get("pack_id"),
                plan_id=identifiers.get("plan_id"),
                checkpoint_id=identifiers.get("checkpoint_id"),
                outcome_id=identifiers.get("outcome_id"),
            )
        except Exception:
            return document
        task_session_id = identity.task_session_id
        identifiers = {**identifiers, "task_session_id": task_session_id}
    original_schema = str(document.get("schema_version") or "") or None
    from persistmind.repo_identity import canonical_repo_hash
    from persistmind.storage.execution_receipts import (
        ExecutionReceiptStore,
        new_execution_receipt_id,
    )

    receipt_id = new_execution_receipt_id()
    try:
        receipts = ExecutionReceiptStore(repo_root)
    except Exception:
        return document
    try:
        engine_generation = int(receipts.runtime.topology.generation)
        envelope = {
            **document,
            "schema_version": HOOK_BINDABLE_RESULT_SCHEMA,
            "result_schema_version": original_schema,
            "route": route,
            "canonical_repo_hash": canonical_repo_hash(repo_root),
            "ids": identifiers,
            **identifiers,
            "execution_receipt_id": receipt_id,
            "engine_generation": engine_generation,
        }
        envelope["project_uuid"] = stable_id("persistmind-project", envelope["canonical_repo_hash"])
        envelope["lifecycle_event_id"] = lifecycle_event_id
        envelope["lifecycle_sequence"] = lifecycle_sequence
        receipts.issue(
            receipt_id=receipt_id,
            route=route,
            task_session_id=task_session_id,
            command_argv=(tuple(command_argv) if command_argv is not None else None),
            result=envelope,
            lifecycle_event_id=lifecycle_event_id,
            lifecycle_sequence=lifecycle_sequence,
            mcp_method=mcp_method,
            mcp_input=mcp_input,
        )
    except Exception:
        return document
    finally:
        receipts.close()
    return envelope


def build_mcp_bindable_result(
    route: str,
    result: Mapping[str, Any],
    *,
    repo_root: Path,
    method: str,
    params: Mapping[str, Any],
) -> dict[str, Any]:
    return build_hook_bindable_result(
        route,
        result,
        repo_root=repo_root,
        mcp_method=method,
        mcp_input=params,
    )


def _command_evidence(payload: Mapping[str, Any]) -> HookBindingParse:
    raw = payload.get("persistmind_command_evidence") or payload.get("command_evidence")
    if isinstance(raw, Mapping):
        if raw.get("schema_version") != HOOK_COMMAND_EVIDENCE_SCHEMA:
            return HookBindingParse(False, "unsupported_command_evidence")
        if not isinstance(raw.get("tool_call_id"), str) or not str(raw.get("tool_call_id")).strip():
            return HookBindingParse(False, "missing_tool_call_id")
        tool_name = str(raw.get("tool_name") or "").casefold()
        dialect = str(raw.get("shell_dialect") or "").casefold()
        if tool_name not in _SHELL_TOOL_NAMES or dialect not in {"posix", "powershell"}:
            return HookBindingParse(False, "unsupported_shell_evidence")
        if not isinstance(raw.get("exit_code"), int):
            return HookBindingParse(False, "missing_exit_status")
        if int(raw["exit_code"]) != 0:
            return HookBindingParse(False, "command_failed")
        if raw.get("timed_out") is not False or raw.get("output_truncated") is not False:
            return HookBindingParse(False, "incomplete_command_output")
        try:
            host_session_id = validate_host_session_id(raw.get("host_session_id"))
        except ValueError:
            return HookBindingParse(False, "invalid_host_session_id")
        cwd = raw.get("cwd")
        if not isinstance(cwd, str) or not cwd:
            return HookBindingParse(False, "missing_command_cwd")
        argv_value = raw.get("argv")
        command = raw.get("command")
        try:
            from_argv = _literal_argv(argv_value) if argv_value is not None else None
            from_command = (
                _lex_simple_command(str(command), dialect=dialect) if command is not None else None
            )
        except ValueError as exc:
            return HookBindingParse(False, str(exc))
        if from_argv is not None and from_command is not None and from_argv != from_command:
            return HookBindingParse(False, "command_argv_mismatch")
        argv = from_argv or from_command
        if not argv:
            return HookBindingParse(False, "missing_command_argv")
        try:
            invocation = load_project_runtime_invocation(Path(cwd))
        except ValueError as exc:
            return HookBindingParse(False, str(exc))
        if invocation is None:
            return HookBindingParse(False, "runtime_invocation_unavailable")
        try:
            invocation.match_argv(argv)
        except ValueError as exc:
            return HookBindingParse(False, str(exc))
        return HookBindingParse(
            True,
            "ok",
            argv=argv,
            evidence_mode="strict",
            cwd=str(Path(cwd).resolve()),
            host_session_id=host_session_id,
            tool_call_id=str(raw["tool_call_id"]).strip(),
        )

    # Compatibility for hook hosts that have not yet adopted the v1 evidence
    # object. It is deliberately constrained to one literal simple command.
    tool_input = payload.get("tool_input")
    command = (
        tool_input.get("command") if isinstance(tool_input, Mapping) else payload.get("command")
    )
    tool_name = str(payload.get("tool_name") or payload.get("tool") or "").casefold()
    if tool_name and tool_name not in _SHELL_TOOL_NAMES:
        return HookBindingParse(False, "not_shell_tool")
    if not isinstance(command, str) or not command.strip():
        return HookBindingParse(False, "missing_command_argv")
    dialect = "powershell" if os.name == "nt" else "posix"
    try:
        argv = _lex_simple_command(command, dialect=dialect)
    except ValueError as exc:
        return HookBindingParse(False, str(exc))
    cwd = payload.get("cwd")
    if not isinstance(cwd, str) or not cwd:
        return HookBindingParse(False, "missing_command_cwd")
    try:
        host_session_id = validate_host_session_id(payload.get("session_id"))
    except ValueError:
        return HookBindingParse(False, "invalid_host_session_id")
    tool_call_id = payload.get("tool_use_id")
    if not isinstance(tool_call_id, str) or not tool_call_id.strip():
        return HookBindingParse(False, "missing_tool_call_id")
    try:
        invocation = load_project_runtime_invocation(Path(cwd))
    except ValueError as exc:
        return HookBindingParse(False, str(exc))
    if invocation is None:
        return HookBindingParse(False, "runtime_invocation_unavailable")
    try:
        invocation.match_argv(argv)
    except ValueError as exc:
        return HookBindingParse(False, str(exc))
    return HookBindingParse(
        True,
        "ok",
        argv=argv,
        evidence_mode="receipt",
        cwd=str(Path(cwd).resolve()),
        host_session_id=host_session_id,
        tool_call_id=tool_call_id.strip(),
    )


def _mcp_evidence(payload: Mapping[str, Any]) -> HookBindingParse:
    tool_name = str(payload.get("tool_name") or payload.get("tool") or "")
    match = _MCP_TOOL_RE.fullmatch(tool_name)
    if match is None:
        return HookBindingParse(False, "unsupported_mcp_tool")
    method = match.group("method").casefold()
    if method not in _MCP_ROUTE_BY_METHOD:
        return HookBindingParse(False, "not_lifecycle_command")
    raw_input = payload.get("tool_input")
    if not isinstance(raw_input, Mapping):
        return HookBindingParse(False, "missing_mcp_input")
    try:
        _bounded_walk(raw_input)
    except ValueError as exc:
        return HookBindingParse(False, str(exc))
    cwd = payload.get("cwd")
    if not isinstance(cwd, str) or not cwd:
        return HookBindingParse(False, "missing_command_cwd")
    try:
        host_session_id = validate_host_session_id(payload.get("session_id"))
    except ValueError:
        return HookBindingParse(False, "invalid_host_session_id")
    tool_call_id = payload.get("tool_use_id")
    if not isinstance(tool_call_id, str) or not tool_call_id.strip():
        return HookBindingParse(False, "missing_tool_call_id")
    return HookBindingParse(
        True,
        "ok",
        evidence_mode="mcp_receipt",
        cwd=str(Path(cwd).resolve()),
        host_session_id=host_session_id,
        tool_call_id=tool_call_id.strip(),
        mcp_method=method,
        mcp_input=dict(raw_input),
    )


def _literal_argv(value: Any) -> tuple[str, ...]:
    if not isinstance(value, list) or not value:
        raise ValueError("invalid_command_argv")
    if any(not isinstance(item, str) or not item for item in value):
        raise ValueError("invalid_command_argv")
    return tuple(value)


def _lex_simple_command(command: str, *, dialect: str) -> tuple[str, ...]:
    if not command or "\n" in command or "\r" in command or "\x00" in command:
        raise ValueError("unsafe_compound_command")
    words: list[str] = []
    current: list[str] = []
    quote: str | None = None
    index = 0
    while index < len(command):
        character = command[index]
        if quote:
            if character == quote:
                quote = None
            elif dialect == "posix" and character == "\\" and quote == '"' or dialect == "powershell" and character == "`":
                index += 1
                if index >= len(command):
                    raise ValueError("invalid_command_quoting")
                current.append(command[index])
            else:
                current.append(character)
            index += 1
            continue
        if character in {'"', "'"}:
            quote = character
            index += 1
            continue
        if character.isspace():
            if current:
                words.append("".join(current))
                current = []
            index += 1
            continue
        if character in ";|<>":
            raise ValueError("unsafe_compound_command")
        if character == "&":
            if dialect == "powershell" and not words and not current:
                words.append("&")
                index += 1
                continue
            raise ValueError("unsafe_compound_command")
        if character in {"$", "`"}:
            raise ValueError("unsafe_command_expansion")
        current.append(character)
        index += 1
    if quote is not None:
        raise ValueError("invalid_command_quoting")
    if current:
        words.append("".join(current))
    if words and words[0] == "&":
        words = words[1:]
    if not words:
        raise ValueError("missing_command_argv")
    if any(word.startswith("@") for word in words):
        raise ValueError("unsafe_response_file")
    if any(re.search(r"%[^%]+%", word) for word in words):
        raise ValueError("unsafe_command_expansion")
    return tuple(words)


def _route_from_argv(argv: tuple[str, ...]) -> str | None:
    if not argv:
        return None
    executable = Path(argv[0]).name.casefold()
    if executable in _WRAPPER_NAMES:
        return None
    offset = 1
    if executable in _PYTHON_NAMES:
        module_index = None
        for index in range(1, min(len(argv), 5)):
            if argv[index] == "-m":
                module_index = index
                break
        if module_index is None or module_index + 1 >= len(argv):
            return None
        if argv[module_index + 1].casefold() not in {"persistmind"}:
            return None
        offset = module_index + 2
    elif executable not in _PRODUCT_NAMES:
        return None

    tokens = list(argv[offset:])
    command_tokens: list[str] = []
    index = 0
    value_options = {
        "--repo",
        "--workspace",
        "--config",
        "--task",
        "--task-session-id",
        "--pack-id",
        "--plan-id",
        "--file",
        "--path",
        "--step-id",
        "--state",
        "--result",
        "--mode",
    }
    while index < len(tokens):
        token = tokens[index]
        if token.startswith("--"):
            option = token.split("=", 1)[0]
            if "=" not in token and option in value_options:
                index += 2
            else:
                index += 1
            continue
        command_tokens.append(token.casefold())
        index += 1
    if not command_tokens:
        return None
    first = command_tokens[0]
    second = command_tokens[1] if len(command_tokens) > 1 else ""
    if first == "task" and second in {"start", "transition"}:
        return f"task.{second}"
    if first in {"pack", "manifest", "check-diff", "impact", "outcome"}:
        return first.replace("-", "_")
    if first == "codex" and second == "preflight":
        return "codex.preflight"
    if first == "plan" and second in {"create", "amend", "checkpoint"}:
        return f"plan.{second}"
    if first == "workflow" and second in {"start", "next", "rebind"}:
        return f"workflow.{second}"
    return None


def _parse_response(response: Any, route: str) -> HookBindingParse:
    try:
        candidates = _response_candidates(response)
    except (UnicodeDecodeError, ValueError, json.JSONDecodeError) as exc:
        return HookBindingParse(False, str(exc) or "invalid_workflow_output", route=route)
    if not candidates:
        return HookBindingParse(False, "not_workflow_output", route=route)
    if len(candidates) != 1:
        return HookBindingParse(False, "ambiguous_workflow_output", route=route)
    document = candidates[0]
    if not isinstance(document, Mapping) or document.get("ok") is not True:
        return HookBindingParse(False, "workflow_command_not_successful", route=route)
    schema = str(document.get("schema_version") or "") or None
    if schema == HOOK_BINDABLE_RESULT_SCHEMA:
        result_route = str(document.get("route") or "").replace("-", "_")
        if result_route != route:
            return HookBindingParse(False, "binding_route_mismatch", route=route)
        source: Mapping[str, Any] = document
        if isinstance(document.get("ids"), Mapping):
            source = {**document, **dict(document["ids"])}
        try:
            identifiers = _collect_identifiers(source, recurse=False)
        except ValueError as exc:
            return HookBindingParse(False, str(exc), route=route)
    else:
        return HookBindingParse(False, "binding_requires_receipt", route=route)
    required = _required_identifiers(route)
    if not required <= set(identifiers):
        return HookBindingParse(False, "missing_binding_identifier", route=route)
    if set(identifiers) - _allowed_identifiers(route):
        return HookBindingParse(False, "route_identifier_mismatch", route=route)
    lifecycle_event_id = document.get("lifecycle_event_id")
    lifecycle_sequence = document.get("lifecycle_sequence")
    if lifecycle_event_id is not None and (
        not isinstance(lifecycle_event_id, str)
        or not _LIFECYCLE_EVENT_RE.fullmatch(lifecycle_event_id)
    ):
        return HookBindingParse(False, "invalid_lifecycle_event", route=route)
    if lifecycle_sequence is not None and (
        not isinstance(lifecycle_sequence, int) or lifecycle_sequence < 1
    ):
        return HookBindingParse(False, "invalid_lifecycle_sequence", route=route)
    if (lifecycle_event_id is None) != (lifecycle_sequence is None):
        return HookBindingParse(False, "incomplete_lifecycle_event", route=route)
    execution_receipt_id = document.get("execution_receipt_id")
    if not isinstance(execution_receipt_id, str) or not _EXECUTION_RECEIPT_RE.fullmatch(
        execution_receipt_id
    ):
        return HookBindingParse(False, "binding_requires_receipt", route=route)
    return HookBindingParse(
        True,
        "ok",
        route=route,
        identifiers=identifiers,
        result_schema=schema,
        lifecycle_event_id=lifecycle_event_id,
        lifecycle_sequence=lifecycle_sequence,
        execution_receipt_id=execution_receipt_id,
        result_document=dict(document),
    )


def _required_identifiers(route: str) -> set[str]:
    return _identifier_contract(route)[0]


def _allowed_identifiers(route: str) -> set[str]:
    return _identifier_contract(route)[1]


def _identifier_contract(route: str) -> tuple[set[str], set[str]]:
    required = {
        "task.start": {"task_session_id"},
        "task.transition": {"task_session_id"},
        "pack": {"task_session_id", "pack_id"},
        "manifest": {"task_session_id", "pack_id"},
        "codex.preflight": {"task_session_id", "pack_id"},
        "plan.create": {"task_session_id", "pack_id", "plan_id"},
        "plan.amend": {"task_session_id", "pack_id", "plan_id"},
        "plan.checkpoint": {"task_session_id", "plan_id", "checkpoint_id"},
        "check_diff": {"task_session_id", "pack_id", "plan_id"},
        "impact": {"task_session_id", "pack_id", "plan_id"},
        "outcome": {"task_session_id", "pack_id", "plan_id", "outcome_id"},
        "workflow.start": {"task_session_id", "pack_id"},
        "workflow.next": {"task_session_id"},
        "workflow.rebind": {"task_session_id", "pack_id"},
    }.get(route, set())
    allowed = set(required)
    allowed.add("agent_session_id")
    if route in {"task.transition", "plan.checkpoint", "workflow.next"}:
        allowed.add("pack_id")
    return set(required), allowed


def _response_candidates(response: Any) -> list[Any]:
    if isinstance(response, Mapping) and isinstance(response.get("stdout"), str):
        response = response["stdout"]
    if isinstance(response, (dict, list)):
        _bounded_walk(response)
        return [response]
    if not isinstance(response, str):
        return []
    encoded = response.encode("utf-8", errors="strict")
    if len(encoded) > MAX_RESPONSE_BYTES:
        raise ValueError("workflow_output_too_large")
    text = encoded.decode("utf-8")
    try:
        parsed = json.loads(text, object_pairs_hook=_unique_object)
    except json.JSONDecodeError:
        decoder = json.JSONDecoder(object_pairs_hook=_unique_object)
        parsed_values: list[Any] = []
        for start in [index for index, char in enumerate(text) if char == "{"][
            :MAX_CANDIDATE_STARTS
        ]:
            try:
                value, _end = decoder.raw_decode(text[start:])
            except json.JSONDecodeError:
                continue
            if isinstance(value, Mapping) and value.get("ok") is True:
                parsed_values.append(value)
        # Multiple embedded success documents are ambiguous even when equal: the
        # hook cannot prove which stdout record belongs to the command result.
        if len(parsed_values) > 1:
            raise ValueError("ambiguous_workflow_output")
        if not parsed_values:
            return []
        parsed = parsed_values[0]
    _bounded_walk(parsed)
    return [parsed]


def _unwrap_mcp_response(response: Any) -> Any:
    if not isinstance(response, Mapping):
        return response
    for key in ("structuredContent", "structured_content"):
        structured = response.get(key)
        if isinstance(structured, Mapping):
            return structured
    content = response.get("content")
    if not isinstance(content, list) or len(content) != 1:
        return response
    block = content[0]
    if (
        isinstance(block, Mapping)
        and block.get("type") == "text"
        and isinstance(block.get("text"), str)
    ):
        return block["text"]
    return response


def _unique_object(pairs: Iterable[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise _DuplicateKey("ambiguous_workflow_output")
        result[key] = value
    return result


def _bounded_walk(value: Any) -> None:
    stack: list[tuple[Any, int]] = [(value, 0)]
    visited = 0
    while stack:
        current, depth = stack.pop()
        visited += 1
        if visited > MAX_VISITED_NODES or depth > MAX_DEPTH:
            raise ValueError("workflow_output_structure_limit")
        if isinstance(current, Mapping):
            stack.extend((item, depth + 1) for item in current.values())
        elif isinstance(current, list):
            stack.extend((item, depth + 1) for item in current)


def _collect_identifiers(value: Mapping[str, Any], *, recurse: bool) -> dict[str, str]:
    found: dict[str, set[str]] = {key: set() for key in _BINDING_KEYS}
    stack: list[Any] = [value]
    while stack:
        current = stack.pop()
        if isinstance(current, Mapping):
            for key, item in current.items():
                if key in found and isinstance(item, str):
                    found[key].add(item)
                if recurse and isinstance(item, (Mapping, list)):
                    stack.append(item)
        elif recurse and isinstance(current, list):
            stack.extend(current)
    identifiers: dict[str, str] = {}
    for key, values in found.items():
        if len(values) > 1:
            raise ValueError("ambiguous_workflow_output")
        if not values:
            continue
        item = next(iter(values))
        if key == "agent_session_id":
            validate_host_session_id(item)
        else:
            parse_workflow_id(KIND_BY_KEY[key], item, allow_legacy=True)
        identifiers[key] = item
    return identifiers


__all__ = [
    "HOOK_BINDABLE_RESULT_SCHEMA",
    "HOOK_COMMAND_EVIDENCE_SCHEMA",
    "HookBindingParse",
    "build_hook_bindable_result",
    "build_mcp_bindable_result",
    "parse_post_tool_binding",
]
