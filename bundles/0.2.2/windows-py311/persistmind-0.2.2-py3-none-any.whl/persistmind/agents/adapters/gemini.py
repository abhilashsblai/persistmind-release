from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any, Mapping

from persistmind.agents.adapters.base import BootstrapContext
from persistmind.agents.contract import ensure_instruction_contract, hook_script, write_if_changed
from persistmind.branding import resolve_project_state


GEMINI_HOOK_EVENTS = (
    "SessionStart",
    "BeforeAgent",
    "BeforeTool",
    "AfterTool",
    "AfterAgent",
    "PreCompress",
    "SessionEnd",
)
_SETTINGS_SCHEMA = (
    "https://raw.githubusercontent.com/google-gemini/gemini-cli/main/schemas/settings.schema.json"
)


class GeminiAdapter:
    name = "gemini"
    aliases = ("gemini-cli", "google-gemini")
    supports_hooks = True
    supports_subagents = False
    supports_skills = True
    instruction_file = "GEMINI.md"

    def detect(self, env: Mapping[str, str]) -> bool:
        return any(key.startswith("GEMINI_") or key.startswith("GOOGLE_GENAI_") for key in env)

    def render(self, ctx: BootstrapContext) -> list[Path]:
        instruction, _ = ensure_instruction_contract(
            ctx.repo_root / self.instruction_file,
            ctx.agent_names,
            agent_label="Gemini CLI",
            invocation=ctx.runtime_invocation,
        )
        hook_path = ctx.workspace_root / "gemini" / "hooks" / "persistmind_hook.py"
        written = [instruction, write_if_changed(hook_path, hook_script())]
        settings_path = ctx.repo_root / ".gemini" / "settings.json"
        existing = _json_object(settings_path)
        settings = _merge_settings(existing, ctx, hook_path)
        written.append(
            write_if_changed(
                settings_path,
                json.dumps(settings, indent=2, sort_keys=True) + "\n",
            )
        )
        return written

    def configure_mcp(
        self, ctx: BootstrapContext, *, config_path: Path | None = None
    ) -> dict[str, Any]:
        target = config_path or ctx.repo_root / ".gemini" / "settings.json"
        existing = _json_object(target)
        updated = _merge_mcp(existing, ctx)
        changed = updated != existing
        if changed:
            write_if_changed(target, json.dumps(updated, indent=2, sort_keys=True) + "\n")
        return {
            "ok": True,
            "agent": self.name,
            "changed": changed,
            "project_config": str(target),
            "hint": self.mcp_setup_hint(ctx),
        }

    def readiness(self, repo_root: Path) -> dict[str, Any]:
        workspace = resolve_project_state(repo_root)
        settings = _json_object(repo_root / ".gemini" / "settings.json")
        hooks_value = settings.get("hooks")
        hooks = hooks_value if isinstance(hooks_value, dict) else {}
        servers_value = settings.get("mcpServers")
        servers = servers_value if isinstance(servers_value, dict) else {}
        persistmind_server_value = servers.get("persistmind")
        persistmind_server = (
            persistmind_server_value if isinstance(persistmind_server_value, dict) else {}
        )
        hooks_config_value = settings.get("hooksConfig")
        hooks_config = hooks_config_value if isinstance(hooks_config_value, dict) else {}
        checks = {
            "gemini_instruction": (repo_root / "GEMINI.md").is_file(),
            "gemini_settings": bool(settings),
            "gemini_mcp": bool(persistmind_server.get("command"))
            and "mcp" in list(persistmind_server.get("args") or []),
            "gemini_hooks_enabled": hooks_config.get("enabled") is True,
            "gemini_lifecycle_hooks": all(
                _has_owned_hook(hooks.get(event), event) for event in GEMINI_HOOK_EVENTS
            ),
            "gemini_hook_script": (
                workspace / "gemini" / "hooks" / "persistmind_hook.py"
            ).is_file(),
            "gemini_workspace": workspace.is_dir(),
        }
        missing = [name for name, passed in checks.items() if not passed]
        return {
            "agent": self.name,
            "ok": not missing,
            "checks": checks,
            "missing": missing,
            "enforcement_level": "hooks",
            "hook_events": list(GEMINI_HOOK_EVENTS),
        }

    def mcp_setup_hint(self, ctx: BootstrapContext) -> str:
        return "Start Gemini CLI in the project and run `/mcp list` and `/hooks list`."


def _merge_settings(
    existing: dict[str, Any],
    ctx: BootstrapContext,
    hook_path: Path,
) -> dict[str, Any]:
    result = _merge_mcp(existing, ctx)
    result.setdefault("$schema", _SETTINGS_SCHEMA)
    hooks_config = result.get("hooksConfig")
    hooks_config = dict(hooks_config) if isinstance(hooks_config, dict) else {}
    hooks_config["enabled"] = True
    result["hooksConfig"] = hooks_config
    hooks = result.get("hooks")
    hooks = dict(hooks) if isinstance(hooks, dict) else {}
    for event in GEMINI_HOOK_EVENTS:
        current = hooks.get(event)
        groups = list(current) if isinstance(current, list) else []
        groups = [
            group
            for group in groups
            if "persistmind" not in json.dumps(group, sort_keys=True).casefold()
        ]
        command = subprocess.list2cmdline(
            [
                str(ctx.runtime_invocation.executable),
                "-I",
                "-X",
                "utf8",
                str(hook_path),
                event,
                "gemini",
            ]
        )
        groups.append(
            {
                "matcher": "*",
                "hooks": [
                    {
                        "name": f"persistmind-{event.casefold()}",
                        "type": "command",
                        "command": command,
                        "timeout": 10,
                    }
                ],
            }
        )
        hooks[event] = groups
    result["hooks"] = hooks
    return result


def _merge_mcp(existing: dict[str, Any], ctx: BootstrapContext) -> dict[str, Any]:
    result = dict(existing)
    servers = result.get("mcpServers")
    servers = dict(servers) if isinstance(servers, dict) else {}
    servers["persistmind"] = {
        "command": str(ctx.runtime_invocation.executable),
        "args": [
            *ctx.runtime_invocation.prefix_args,
            "mcp",
            "--repo",
            ctx.mcp_repo,
        ],
    }
    result["mcpServers"] = servers
    return result


def _json_object(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except OSError as exc:
        raise ValueError(f"Gemini project settings are unreadable: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"Gemini project settings are not valid JSON: {path}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"Gemini project settings must be a JSON object: {path}")
    return value


def _has_owned_hook(value: Any, event: str) -> bool:
    if not isinstance(value, list):
        return False
    marker = f"persistmind-{event.casefold()}"
    return any(marker in json.dumps(group, sort_keys=True).casefold() for group in value)


__all__ = ["GEMINI_HOOK_EVENTS", "GeminiAdapter"]
