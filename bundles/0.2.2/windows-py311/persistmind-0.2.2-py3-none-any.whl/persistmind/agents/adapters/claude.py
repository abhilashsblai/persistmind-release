from __future__ import annotations

import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from persistmind.agents.adapters.base import BootstrapContext
from persistmind.agents.contract import (
    HOOK_EVENTS,
    SUBAGENT_SPECS,
    claude_agent_markdown,
    claude_command,
    claude_mcp_json,
    claude_settings_json,
    claude_skill,
    ensure_instruction_contract,
    hook_script,
    write_if_changed,
)
from persistmind.branding import resolve_project_state


class ClaudeAdapter:
    name = "claude"
    aliases = ("claude-code", "claudecode")
    supports_hooks = True
    supports_subagents = True
    supports_skills = True
    instruction_file = "CLAUDE.md"

    def detect(self, env: Mapping[str, str]) -> bool:
        return bool(env.get("CLAUDECODE")) or any(key.startswith("CLAUDE_") for key in env)

    def render(self, ctx: BootstrapContext) -> list[Path]:
        written: list[Path] = []
        path, _changed = ensure_instruction_contract(
            ctx.repo_root / self.instruction_file,
            ctx.agent_names,
            agent_label="Claude Code",
            invocation=ctx.runtime_invocation,
        )
        written.append(path)
        written.extend(
            [
                write_if_changed(
                    ctx.workspace_root / "mcp" / "claude-code.ps1",
                    claude_command(ctx.runtime_invocation, ctx.mcp_repo),
                ),
                write_if_changed(
                    ctx.repo_root / ".mcp.json",
                    claude_mcp_json(ctx.runtime_invocation, ctx.mcp_repo),
                ),
                write_if_changed(
                    ctx.repo_root / ".claude" / "skills" / "persistmind-loop" / "SKILL.md",
                    claude_skill(ctx.runtime_invocation, ctx.mcp_repo),
                ),
                write_if_changed(
                    ctx.workspace_root / "claude" / "hooks" / "persistmind_hook.py",
                    hook_script(),
                ),
            ]
        )
        settings_path = ctx.repo_root / ".claude" / "settings.json"
        settings = _merge_settings(
            _json_object(settings_path),
            json.loads(claude_settings_json(ctx.repo_root, ctx.runtime_invocation)),
        )
        written.append(
            write_if_changed(settings_path, json.dumps(settings, indent=2, sort_keys=True) + "\n")
        )
        for spec in SUBAGENT_SPECS:
            written.append(
                write_if_changed(
                    ctx.repo_root / ".claude" / "agents" / f"{spec.name}.md",
                    claude_agent_markdown(spec),
                )
            )
        return written

    def configure_mcp(
        self, ctx: BootstrapContext, *, config_path: Path | None = None
    ) -> dict[str, Any]:
        return {
            "ok": True,
            "agent": self.name,
            "changed": False,
            "hint": self.mcp_setup_hint(ctx),
            "project_config": str(ctx.repo_root / ".mcp.json"),
        }

    def readiness(self, repo_root: Path) -> dict[str, Any]:
        workspace = resolve_project_state(repo_root)
        claude = repo_root / ".claude"
        settings = claude / "settings.json"
        checks = {
            "claude_instruction": (repo_root / "CLAUDE.md").exists(),
            "claude_mcp_project": (repo_root / ".mcp.json").exists(),
            "claude_settings": settings.exists(),
            "claude_hooks": settings.exists()
            and (workspace / "claude" / "hooks" / "persistmind_hook.py").exists(),
            "claude_agents": all(
                (claude / "agents" / f"{name}.md").exists()
                for name in [
                    "persistmind-explorer",
                    "persistmind-worker",
                    "persistmind-reviewer",
                    "persistmind-verifier",
                ]
            ),
            "claude_skill": (claude / "skills" / "persistmind-loop" / "SKILL.md").exists(),
        }
        missing = [name for name, ok in checks.items() if not ok]
        return {
            "agent": self.name,
            "ok": not missing,
            "checks": checks,
            "missing": missing,
            "enforcement_level": "hooks",
            "hook_events": list(HOOK_EVENTS),
        }

    def mcp_setup_hint(self, ctx: BootstrapContext) -> str:
        command = ctx.runtime_invocation.render_powershell("mcp", "--repo", ctx.mcp_repo)
        return f"Run `claude mcp add persistmind -- {command}`."


def _merge_settings(existing: dict[str, Any], generated: dict[str, Any]) -> dict[str, Any]:
    result = dict(existing)
    generated_hooks = generated.get("hooks") if isinstance(generated.get("hooks"), dict) else {}
    hooks = result.get("hooks")
    hooks = dict(hooks) if isinstance(hooks, dict) else {}
    for event, generated_groups in generated_hooks.items():
        current = hooks.get(event)
        groups = list(current) if isinstance(current, list) else []
        groups = [
            group
            for group in groups
            if "persistmind_hook.py" not in json.dumps(group, sort_keys=True).casefold()
        ]
        groups.extend(generated_groups if isinstance(generated_groups, list) else [])
        hooks[event] = groups
    result["hooks"] = hooks
    return result


def _json_object(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except OSError as exc:
        raise ValueError(f"Claude project settings are unreadable: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"Claude project settings are not valid JSON: {path}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"Claude project settings must be a JSON object: {path}")
    return value
