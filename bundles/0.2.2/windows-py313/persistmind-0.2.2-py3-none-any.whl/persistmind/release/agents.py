from __future__ import annotations

import json
from pathlib import Path
from typing import Any


AGENT_COMPATIBILITY_PATH = Path("plan/agent-compatibility.v1.json")
AGENT_COMPATIBILITY_SCHEMA = "persistmind.agent_compatibility.v1"
SUPPORTED_AGENTS = frozenset({"claude", "codex", "gemini", "grok"})


def load_agent_compatibility(repo_root: Path) -> dict[str, Any]:
    path = repo_root.resolve() / AGENT_COMPATIBILITY_PATH
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"agent compatibility artifact is unavailable: {path}") from exc
    if not isinstance(value, dict):
        raise ValueError("agent compatibility artifact must be an object")
    return value


def validate_agent_compatibility(
    value: dict[str, Any],
    *,
    require_qualified: bool,
    required_agents: set[str] | frozenset[str] | None = None,
) -> list[str]:
    violations: list[str] = []
    if value.get("schema_version") != AGENT_COMPATIBILITY_SCHEMA:
        violations.append("schema_version_mismatch")
    agents = value.get("agents")
    if not isinstance(agents, list):
        return [*violations, "agents_missing"]
    identifiers = {
        str(agent.get("id") or "")
        for agent in agents
        if isinstance(agent, dict) and agent.get("id")
    }
    if identifiers != SUPPORTED_AGENTS:
        violations.append("supported_agents_mismatch")
    qualification_scope = (
        SUPPORTED_AGENTS if required_agents is None else frozenset(required_agents)
    )
    if not qualification_scope or not qualification_scope <= SUPPORTED_AGENTS:
        violations.append("qualification_scope_mismatch")
    if any(
        not isinstance(agent, dict)
        or not isinstance(agent.get("capabilities"), list)
        or not agent.get("capabilities")
        for agent in agents
    ):
        violations.append("capabilities_missing")
    if require_qualified:
        missing_policy = sorted(
            str(agent.get("id") or "unknown")
            for agent in agents
            if (
                not isinstance(agent, dict)
                or str(agent.get("id") or "") in qualification_scope
                and (
                    agent.get("windows_release_scope") != "supported"
                    or agent.get("windows_smoke_required") is not True
                )
            )
        )
        if missing_policy:
            violations.append("qualification_policy_missing:" + ",".join(missing_policy))
    return violations


__all__ = [
    "AGENT_COMPATIBILITY_PATH",
    "AGENT_COMPATIBILITY_SCHEMA",
    "SUPPORTED_AGENTS",
    "load_agent_compatibility",
    "validate_agent_compatibility",
]
